internal/ = what every process and object can see in Blue Prism without it being in the release.

internal.json   Blue Prism's built-in objects (Work Queues, Credentials, Environment Locking, Calendars, ...)
                with their actions. Seeded from memory: replace with the dump from docs/copilot_internal_objects_handoff.md.
estate.json     the simulated estate Run uses outside a release: {"environment": {name: value},
                "credentials": {name: ["user", "pass"]}, "queues": {name: [{"Key": "..", ...}, ...]}}.
                A release's own env vars and queues are added on top when running one of its members.
*.xml           exports of the Blue Prism supplied objects (Utility - Strings, Utility - Collection Manipulation,
                MS Excel VBO, ...): export them from Studio once and drop them here. Every page then lists them
                under Objects known, and Run executes their code stages like any other object.
