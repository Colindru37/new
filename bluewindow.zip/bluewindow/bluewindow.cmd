@echo off
rem Double-click: starts bluewindow and opens it in the browser. Keep the window open while you work.
node "%~dp0bluewindow.js" %*
if errorlevel 1 pause
