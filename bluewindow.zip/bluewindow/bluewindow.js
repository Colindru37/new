#!/usr/bin/env node
// bluewindow: Blue Prism Studio-lite for an export .xml, offline, in the browser, with versions.
//   node bluewindow.js render <file.xml> [--out <folder>] [--incident <incident.json>]
//       -> <folder>/<base>/<base>.vN.xml (copied) + <base>.vN.html (the editor), diff against vN-1,
//          validate.py (strict estate profile) when python + the skill lib are reachable.
//   node bluewindow.js watch <folder> [--downloads <dir>]
//       -> every new <base>.vN.xml dropped in <folder>/<base>/ (or found in --downloads and moved) is rendered.
//   node bluewindow.js            (or: serve)  -> the everyday way: opens the browser on a home page. Drop exports into
//       inbox\ (or onto the page), click Open; Save writes <base>.v(N+1).xml into projects\<base>\ and reopens it with the diff.
// Opened from disk (no server) the editor saves the next version as a download instead.
// Standalone: validate.py + compile_check.py ship in lib\ next to this file; bluewindow.json (optional) holds the settings.
'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process');
const D = require('./bpdraw'), E = require('./bpedit'), R = require('./bprelease');
const HERE = __dirname;
const SRC = ['bpdraw.js', 'bpedit.js', 'bpui.js'].map(f => fs.readFileSync(path.join(HERE, f), 'utf8'));

// settings: bluewindow.json next to this file, every key optional
//   { "bp": "C:\\Program Files\\Blue Prism Limited\\Blue Prism Automate", "with": ["C:\\exports\\objects"],
//     "inbox": "inbox", "projects": "projects", "port": 7788, "browser": true }
function config() {
  let c = {}; const f = path.join(HERE, 'bluewindow.json');
  if (fs.existsSync(f)) { try { c = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { console.log('bluewindow.json unreadable (' + e.message + '), using defaults'); } }
  const abs = p => path.isAbsolute(p) ? p : path.join(HERE, p);
  return { bp: c.bp ? [c.bp] : [], with: (c.with || []).map(abs), inbox: abs(c.inbox || 'inbox'), projects: abs(c.projects || 'projects'),
           port: c.port || 7788, browser: c.browser !== false };
}
// Blue Prism's install folder (its Roslyn compiler + DLLs make the compile check exact): config, BP_HOME, then the usual places
function bpHome(given) {
  if (given && given.length) return given;
  const c = config().bp; if (c.length) return c;
  if (process.env.BP_HOME) return [process.env.BP_HOME];
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)'].filter(Boolean);
  for (const r of roots) for (const sub of ['Blue Prism Limited\\Blue Prism Automate', 'SS&C Blue Prism\\Blue Prism Automate', 'Blue Prism Limited\\Blue Prism']) {
    const d = path.join(r, sub); try { if (fs.existsSync(path.join(d, 'Automate.exe'))) return [d]; } catch (e) { }
  }
  return [];
}
function libFile(name) {
  const cands = [path.join(HERE, 'lib', name), path.join(HERE, '..', '..', 'lib', name), process.env.RPA_BP_SKILL ? path.join(process.env.RPA_BP_SKILL, 'lib', name) : null].filter(Boolean);
  return cands.find(p => fs.existsSync(p)) || null;
}

function baseAndVersion(file) {
  const n = path.basename(file).replace(/\.xml$/i, '');
  const m = /^(.*)\.v(\d+)$/.exec(n);
  return m ? { base: m[1], ver: +m[2] } : { base: n, ver: 0 };
}
function versionsIn(dir, base) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).map(f => /^(.*)\.v(\d+)\.xml$/i.exec(f)).filter(m => m && m[1] === base).map(m => +m[2]).sort((a, b) => a - b);
}
function findValidator() { return libFile('validate.py'); }
function validate(xmlFile) {
  const v = findValidator(); if (!v) return { ran: false, text: 'validate.py not found (expected in lib\\ next to bluewindow.js)' };
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'bw-')); fs.copyFileSync(xmlFile, path.join(tmp, path.basename(xmlFile).replace(/\.v\d+\.xml$/i, '.xml')));
  for (const py of ['python', 'python3', 'py']) {
    try { const r = cp.spawnSync(py, [v, tmp, '--flow', '--estate', '--strict'], { encoding: 'utf8', timeout: 60000 }); if (r.error) continue; return { ran: true, ok: /ALL CLEAN/.test(r.stdout), text: (r.stdout + r.stderr).trim() }; } catch (e) { }
  }
  return { ran: false, text: 'python not found' };
}

function findCompiler() { return libFile('compile_check.py'); }
// objects only: compile every code stage + shared code the way Blue Prism does. bpDirs = Blue Prism install folder(s), where its own
// Roslyn csc.exe and the referenced DLLs live; without one compile_check falls back to a development compiler and says so.
function compile(xmlFile, bpDirs) {
  const xml = fs.readFileSync(xmlFile, 'utf8');
  if (!/<process [^>]*type="object"/.test(xml.slice(0, 2000))) return null;
  if (!/type="Code"/.test(xml)) return { ran: true, ok: true, bp: false, text: 'no code stages in this object' };
  const c = findCompiler(); if (!c) return { ran: false, ok: null, text: 'compile_check.py not found (expected in lib\\ next to bluewindow.js)' };
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'bwc-')); fs.copyFileSync(xmlFile, path.join(tmp, path.basename(xmlFile).replace(/\.v\d+\.xml$/i, '.xml')));
  const args = [c, tmp]; for (const d of bpDirs || []) args.push('--ref-dir', d);
  for (const py of ['python', 'python3', 'py']) {
    try { const r = cp.spawnSync(py, args, { encoding: 'utf8', timeout: 120000 }); if (r.error) continue; const text = (r.stdout + r.stderr).trim(); return { ran: true, ok: /ALL COMPILED/.test(text), bp: /roslyn/i.test(text), text: text.split('\n').filter(l => !/^(C#|VB) compiler:/.test(l) || /roslyn/i.test(l)).join('\n') }; } catch (e) { }
  }
  return { ran: false, ok: null, text: 'python not found' };
}
// pages carry relative links to their neighbours (release members / other exports under Projects), so a page opened
// straight from the folder can still reach them. Each project folder has an index.html that forwards to its newest version.
const PAGE_VERSION = 4;
const relLink = base => '../' + encodeURIComponent(base) + '/index.html';
function writeIndex(dir, base) {
  const vs = versionsIn(dir, base).filter(v => fs.existsSync(path.join(dir, base + '.v' + v + '.html'))); if (!vs.length) return;
  const target = encodeURIComponent(base + '.v' + vs[vs.length - 1] + '.html');
  fs.writeFileSync(path.join(dir, 'index.html'), '<!doctype html><meta charset="utf-8"><title>' + base.replace(/[<&]/g, '') + '</title><script>location.replace(' + JSON.stringify(target) + ' + location.hash)</script><a href="' + target + '">open</a>', 'utf8');
}
function staticLinks(outRoot, selfBase) {   // other exports next to this one that are objects: name -> their folder
  const links = {};
  for (const o of projectObjects({ projects: outRoot })) if (o.base !== selfBase) addObjKey(links, o.name, relLink(o.base));
  return links;
}
function page(opts) {
  const { xml, base, ver, diff, incident, validation, compile } = opts; const objects = opts.objects || [];
  const diffJson = diff ? { added: diff.added.map(s => s.name), removed: diff.removed.map(s => s.name), renamed: diff.renamed.map(r => [r[0].name, r[1].name]), changed: diff.changed.map(s => s.name), moved: diff.moved.map(s => s.name), changedIds: [...diff.changedIds] } : null;
  const J = o => JSON.stringify(o).replace(/<\/script/gi, '<\\/script');
  const vlines = t => { const L = String(t).split('\n').filter(l => l.trim() && !/^\s+'/.test(l) && !/^\s*--/.test(l)); const verdict = L.filter(l => /ALL CLEAN|PROBLEMS|FAIL/.test(l)).pop(); return (verdict ? verdict.trim() + '\n' : '') + L.filter(l => l !== verdict).slice(-10).join('\n'); };
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(base)} v${ver} - bluewindow</title><style>
body{margin:0;font-family:Segoe UI,Arial,sans-serif;font-size:13px;display:flex;flex-direction:column;height:100vh;overflow:hidden}
*{scrollbar-width:thin;scrollbar-color:#8a94a0 transparent}body.dark *{scrollbar-color:#3a4458 transparent}
.tb{display:flex;align-items:center;gap:8px;padding:5px 10px;background:#1f2933;color:#eceff1;border-bottom:1px solid #0d141a}
.tb .brand{font-weight:600;letter-spacing:.04em;color:#9fb3c8;font-size:12px}.tb .file{font-size:12px;color:#eceff1}.tb .file em{font-style:normal;color:#9fb3c8;margin-left:6px;font-size:11px}
.tb button{background:transparent;color:#cfd8dc;border:1px solid transparent;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px;display:inline-flex;align-items:center;gap:6px}.tb button:hover{background:#2c3a47}
.tb .seg{display:inline-flex;border:1px solid #3a4a58;border-radius:5px;overflow:hidden;margin-left:12px}.tb .seg button{border-radius:0;border:none;border-right:1px solid #3a4a58}.tb .seg button:last-child{border-right:none}
.tb button.on{background:#2f5f9e;color:#fff}.tb button:disabled{opacity:.35;cursor:default}.tb button.primary{background:#2e7d32;color:#fff;border-color:#2e7d32}.tb button.primary:disabled{background:#3a4a58;border-color:#3a4a58;opacity:.6}
.tb kbd{font:10px/1 Consolas,monospace;color:#9fb3c8;background:rgba(255,255,255,.08);border-radius:3px;padding:2px 4px}.tb button.on kbd{color:#dbe6fb}.tb .sp{flex:1}
#runpanel .ck{display:flex;flex-wrap:wrap;align-items:center;gap:8px}#runpanel .ck button{font-size:11px;padding:1px 7px;border:1px solid #bbb;border-radius:3px;background:#fff;cursor:pointer}#run-sum{flex-basis:100%}#run-log{flex-basis:100%;max-height:260px;overflow:auto;margin:0;font-size:11px;line-height:1.35;white-space:pre-wrap;background:#f6f7f9;border:1px solid #e3e6ea;border-radius:4px;padding:6px 8px}body.dark #run-log{background:#0f1115;border-color:var(--line)}body.dark #runpanel .ck button{background:var(--panel);color:var(--ink);border-color:var(--line)}#runb.on{background:#2e7d32;color:#fff}
#dot{width:8px;height:8px;border-radius:50%;background:#9e9e9e;display:inline-block}#checks.good #dot{background:#66bb6a}#checks.meh #dot{background:#ffca28}#checks.bad #dot{background:#ef5350}
#help{position:fixed;right:12px;top:44px;z-index:5;background:#fff;border:1px solid #bbb;border-radius:6px;padding:10px 12px;box-shadow:0 6px 24px rgba(0,0,0,.3);font-size:12px;max-width:520px}#help table{border-collapse:collapse;margin:6px 0}#help td{padding:2px 8px 2px 0;vertical-align:top}#help td:first-child{font:11px Consolas,monospace;white-space:nowrap;color:#1565c0}#help button{margin-top:4px}
.band{fill:#2f5f9e;fill-opacity:.12;stroke:#2f5f9e;stroke-dasharray:3,2}.rsz{fill:#fff;stroke:#2f5f9e;cursor:nwse-resize}
#diff{background:#fff8e1;border-bottom:1px solid #ffe082;padding:4px 10px;font-size:12px}
#checkpanel{background:#fff;border-bottom:1px solid #ddd;max-height:40vh;overflow:auto;font-size:12px;display:flex}#checkpanel[hidden]{display:none}#checkpanel .ck{flex:1;padding:6px 10px;min-width:0}#checkpanel .ck+.ck{border-left:1px solid #ddd}
#rules{list-style:none;margin:4px 0 0;padding:0}#rules li{padding:1px 0}#rules li.error{color:#c62828}#rules li.warn{color:#ef6c00}#rules li.ok{color:#2e7d32}
#valid,#compile{margin:4px 0 0;white-space:pre-wrap;font:11px Consolas,monospace;color:#2e7d32}#valid.bad,#compile.bad{color:#c62828}
svg .grid{display:none}body.grid svg .grid{display:block}svg .gdot{fill:var(--griddot)}svg .bg{fill:var(--bg)}
.row{display:flex;flex:1;min-height:0}nav{width:240px;min-width:180px;overflow:auto;border-right:1px solid #ddd;background:#f6f6f6}
nav h1{font-size:12px;margin:8px;color:#333;word-break:break-word}nav input{width:calc(100% - 16px);margin:8px 8px 6px;box-sizing:border-box}nav ul{list-style:none;margin:0;padding:0}
nav li{padding:7px 10px;border-bottom:1px solid #e5e5e5;cursor:pointer}
nav .mini{padding:0 8px 6px}nav .mini input{width:100%;box-sizing:border-box;font-size:12px;padding:3px 6px;margin:0 0 4px}nav .mini ul{max-height:220px;overflow:auto;margin:0;padding:0;list-style:none}
nav .mini li{padding:3px 6px;font-size:12px;border:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}nav .mini li b{display:inline-block;width:14px;font-size:10px;opacity:.6}nav .mini li.on{font-weight:600}
nav .mini .more{font-size:11px;opacity:.6;padding:2px 6px}nav details summary{cursor:pointer;list-style:none}nav details summary::-webkit-details-marker{display:none}
a.jump{display:inline-block;margin-top:2px;font-size:12px;color:#fff;background:#3f6db3;border-radius:4px;padding:3px 9px;text-decoration:none}a.jump:hover{background:#4f8cff}.navh{display:flex;align-items:center;gap:6px;padding:8px 10px 4px;font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.04em}.navh .muted{text-transform:none;letter-spacing:0;font-size:11px}.navh button.nm{margin-left:4px}.navh button{margin-left:auto;font-size:11px;padding:1px 7px;border:1px solid #bbb;border-radius:3px;background:#fff;cursor:pointer}
#palette{display:flex;flex-wrap:wrap;gap:4px;padding:2px 10px 8px}#palette button{font-size:11px;padding:3px 8px;border:1px solid #ccc;border-radius:3px;background:#fff;cursor:pointer}#palette button.on{background:#2f5f9e;color:#fff;border-color:#2f5f9e}body.placing svg{cursor:crosshair}nav li:hover{background:#e8f0fe}nav li.on{background:#dbe6fb;font-weight:600}
main{flex:1;overflow:auto;padding:0;position:relative}main h2{font-size:12px;margin:0;padding:6px 10px;color:#444;position:sticky;top:0;left:0;z-index:2}svg{display:block;border:none;background:#fafafa;transform-origin:0 0;user-select:none}
g.st.on rect,g.st.on polygon,g.st.on circle,g.blk.on rect{filter:drop-shadow(0 0 4px #1565c0)}
aside#sheet{width:400px;min-width:320px;border-left:1px solid #ddd;background:#fff;overflow:auto;font-size:12px}
aside .sh{position:sticky;top:0;background:#e8f0fe;padding:8px 10px;border-bottom:1px solid #c5d3ea;display:flex;align-items:center;gap:8px;z-index:1}
aside .sh span{font-size:10px;color:#fff;background:#1565c0;border-radius:3px;padding:1px 5px}aside .sh b{flex:1;word-break:break-word}aside .sh button{border:none;background:none;font-size:18px;cursor:pointer;color:#555}
#sh-body{padding:8px 10px}#sh-body h4{margin:12px 0 4px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid #eee}
#sh-body dl{margin:0;display:grid;grid-template-columns:100px 1fr;gap:4px 8px;align-items:center}#sh-body dt{color:#666}#sh-body dd{margin:0;word-break:break-word;font-family:Consolas,monospace;font-size:11px}
#sh-body input,#sh-body select,#sh-body textarea{width:100%;box-sizing:border-box;font-family:Consolas,monospace;font-size:11px;border:1px solid #ccc;border-radius:2px;padding:3px}#sh-body textarea{min-height:48px}#sh-body textarea.code{min-height:200px}
#sh-body table{border-collapse:collapse;width:100%;font-size:11px}#sh-body th{text-align:left;background:#f3f3f3;padding:3px 4px;border:1px solid #e3e3e3}#sh-body td{padding:2px 3px;border:1px solid #e3e3e3;vertical-align:top;font-family:Consolas,monospace}
.apply button{background:#1565c0;color:#fff;border:none;border-radius:3px;padding:5px 12px;cursor:pointer}.muted{color:#888}
.zoom{position:fixed;left:250px;bottom:10px;display:flex;gap:4px}.zoom button{background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:4px;padding:3px 9px;cursor:pointer;opacity:.85}#toast{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:#263238;color:#fff;padding:6px 12px;border-radius:4px;font-size:12px}
#yesno{position:fixed;left:50%;top:40%;transform:translateX(-50%);background:#fff;border:1px solid #999;border-radius:4px;padding:12px;box-shadow:0 4px 16px rgba(0,0,0,.25)}#yesno button{margin:0 6px;padding:4px 14px}

/* ---- theme: the canvas and the chrome. Light = Studio-like paper. Dark = default, ink on slate. ---- */
:root{--griddot:#c9ced6;--bg:#f4f5f7;--panel:#ffffff;--panel2:#f6f6f6;--line:#dddddd;--ink:#222;--muted:#666;--accent:#1565c0;--sel:#dbe6fb;--hover:#e8f0fe;--canvas:#fafafa;--canvasline:#dddddd}
body.dark{--griddot:#34405a;--bg:#0f1217;--panel:#161a22;--panel2:#12151c;--line:#232a36;--ink:#d6dbe6;--muted:#8b94a7;--accent:#7aa2f7;--sel:#1f2a44;--hover:#1a2230;--canvas:#141821;--canvasline:#232a36}
body{background:var(--bg);color:var(--ink)}nav{background:var(--panel2);border-color:var(--line)}nav h1{color:var(--ink)}nav li{border-color:var(--line)}nav li:hover{background:var(--hover)}nav li.on{background:var(--sel)}
nav input,#sh-body input,#sh-body select,#sh-body textarea{background:var(--panel);color:var(--ink);border-color:var(--line)}
main h2{color:var(--muted);background:var(--bg)}svg{background-color:var(--bg)}
aside#sheet{background:var(--panel);border-color:var(--line);color:var(--ink)}body.dark aside .sh{background:#1b2436;border-color:#2a3650}body.dark aside .sh button{color:#aab}
#sh-body h4{color:var(--muted);border-color:var(--line)}#sh-body dt{color:var(--muted)}#sh-body th{background:var(--panel2);border-color:var(--line)}#sh-body td{border-color:var(--line)}
body.dark .tb{background:#0c0f14;border-color:#000}body.dark #status{background:var(--panel2);border-color:var(--line);color:var(--muted)}body.dark #checkpanel{background:var(--panel);border-color:var(--line)}body.dark #checkpanel .ck+.ck{border-color:var(--line)}body.dark #diff{background:#2a2410;border-color:#4a3e14;color:#e0c070}body.dark #valid,body.dark #compile{color:#a5d6a7}body.dark #valid.bad,body.dark #compile.bad{color:#ef9a9a}body.dark svg .infor{fill:#171c27;stroke:#3a4a6b}body.dark svg .infoh{fill:#2b3f66}body.dark svg .infot{fill:#dbe6fb}body.dark svg .infod{fill:#aab3c5}body.dark #rules li.ok{color:#9ece6a}body.dark #rules li.error{color:#f7768e}body.dark #rules li.warn{color:#e0af68}
body.dark #help{background:var(--panel);color:var(--ink);border-color:var(--line)}body.dark #help td:first-child{color:#7aa2f7}body.dark .rsz{fill:#1b2029}
body.dark .navh{color:var(--muted)}body.dark .navh button,body.dark #palette button{background:var(--panel);color:var(--ink);border-color:var(--line)}body.dark #palette button.on{background:#2f5f9e;color:#fff}
body.dark .zoom button,body.dark #yesno{background:var(--panel);color:var(--ink);border:1px solid var(--line)}
/* ---- theme: the drawing. Fills and strokes per stage type; the SVG attributes are the light fallback. ---- */
body.dark svg .lbl{fill:#d6dbe6}body.dark svg .lbl.fail{fill:#fff}body.dark svg .anchor{fill:#8b94a7}
body.dark svg .lab.yes,body.dark svg .lab.no{display:none}body.dark svg .lnk{stroke:#8089a0}body.dark svg .lnk.yes{stroke:#9ece6a}body.dark svg .lnk.no{stroke:#f7768e}body.dark svg .lnk.loop{stroke:#bb9af7}body.dark svg .lnk.red{stroke:#ff5a72}
body.dark svg .lab{fill:#8089a0}body.dark svg .lab.yes{fill:#9ece6a}body.dark svg .lab.no{fill:#f7768e}body.dark svg .grp{stroke:#4b5366}body.dark svg .grp.loop{stroke:#bb9af7}
body.dark svg marker#arr path{fill:#8089a0}body.dark svg marker#arrR path{fill:#ff5a72}
body.dark svg .blkr{fill:#7aa2f7;fill-opacity:.06;stroke:#3b4a6b}body.dark svg .blkt{fill:#7aa2f7}body.dark svg .cpt{fill:#e0af68;stroke:#8a6d3b}body.dark svg .cptl{fill:#8b94a7}
body.dark svg .val{fill:#7dcfff}body.dark svg .seq{fill:#5c6680}body.dark svg .inner{stroke:#8b94a7}
body.dark svg .shape{fill:#1b2029;stroke:#8d97ab;stroke-width:1.1}body.dark svg .deco{stroke:#8d97ab}body.dark svg .glyph{fill:#8d97ab}
body.dark svg .t-Start{stroke:#9ece6a}body.dark svg .t-End{stroke:#f7768e}
body.dark svg .t-Decision,body.dark svg .t-ChoiceStart{fill:#221e14;stroke:#e0af68}
body.dark svg .t-Exception{fill:#2a1a1e;stroke:#f7768e;stroke-width:1.8}
body.dark svg .t-Data,body.dark svg .t-Collection{fill:#151920;stroke:#5a6478}
body.dark svg .t-Note{fill:#26231a;stroke:#9a8a4a}
body.dark svg .t-Recover,body.dark svg .t-Resume{fill:#1d1a2e;stroke:#bb9af7}
body.dark svg .shape.changed{stroke:#ff9e64;stroke-width:2}body.dark svg .shape.path{stroke:#ff5a72;stroke-width:2}
body.dark svg .shape.fail{fill:#c23b4e;stroke:#ff8a9c;stroke-width:3}
body.dark g.st.on rect,body.dark g.st.on polygon,body.dark g.st.on circle,body.dark g.blk.on rect{filter:drop-shadow(0 0 5px #7aa2f7)}
</style></head><body>
<div class="tb"><span class="brand">bluewindow</span><span class="file">${esc(base)}<em>v${ver}</em></span>
<span class="seg"><button data-mode="select" onclick="setMode('select')" title="V">Select<kbd>V</kbd></button><button data-mode="link" onclick="setMode('link')" title="L">Link<kbd>L</kbd></button><button data-mode="delete" onclick="setMode('delete')" title="D">Delete<kbd>D</kbd></button></span>
<span class="sp"></span>
<button id="checks" onclick="toggleChecks()" title="live rules + the full check from render time"><i id="dot"></i><span id="rulecount"></span></button>${diff ? '<button onclick="toggleDiff()" title="what changed since v' + (ver - 1) + '">diff</button>' : ''}
<button id="runb" onclick="runFlow()" title="run this flow here: the real pages and code stages, Work Queues / Credentials / locks simulated (internal\\estate.json + the release's items)" hidden>Run</button><button id="gridb" onclick="toggleGrid()" title="G: snap to the 15px Studio grid">grid</button><button id="helpb" onclick="toggleHelp()" title="keys and how-to">?</button><button onclick="copyXml()" title="copy the current XML">Copy</button><button id="save" class="primary" onclick="saveXml()">Save v${ver + 1}</button></div>
${diff ? '<div id="diff"></div>' : '<div id="diff" hidden></div>'}
<div id="runpanel" hidden><div class="ck"><b id="run-title">Run</b> <span id="run-status" class="muted"></span> <button onclick="clearRun()" style="margin-left:auto">clear</button><button onclick="document.getElementById('runpanel').hidden=true">hide</button><div id="run-sum" class="muted"></div><pre id="run-log"></pre></div></div>
<div id="checkpanel" hidden><div class="ck"><b>While you edit</b> <span class="muted">(the browser checks the estate rules after every change; errors block Save)</span><ul id="rules"></ul></div>
${compile ? `<div class="ck"><b>Code stages compile?</b> <span class="muted">(compile_check.py${compile.ran ? ', ' + (compile.bp ? "Blue Prism's own compiler" : 'a development compiler, indicative only: pass --bp "<Blue Prism folder>" for the real one') : ' was not found'})</span><pre id="compile" class="${compile.ok ? '' : 'bad'}">${esc(compile.text)}</pre></div>` : ''}
${validation ? `<div class="ck"><b>Full check of this version</b> <span class="muted">(validate.py --flow --estate --strict, the same gate the skill uses, ran when this page was made${validation.ran ? '' : ' - it was not found'})</span><pre id="valid" class="${validation.ok ? '' : 'bad'}">${esc(vlines(validation.text))}</pre></div>` : ''}</div>
<div class="row"><nav><div id="relnav"></div><input id="q" placeholder="find a stage (Enter)"><div class="navh">Pages <button onclick="addPage()" title="add a page">+ page</button><button onclick="removePage()" title="remove the open page" class="nm">&minus; page</button></div><ul id="pages"></ul><div class="navh">Add a stage</div><div id="palette"></div><div id="objknown"></div></nav><main id="panes"></main>
<aside id="sheet" hidden><div class="sh"><span id="sh-type"></span><b id="sh-name"></b><button onclick="closeSheet()" title="close">&times;</button></div><div id="sh-body"></div></aside></div>
<div class="zoom"><button onclick="z(1.25)" title="Ctrl+wheel zooms too">+</button> <button onclick="z(0.8)">&minus;</button></div>
<div id="help" hidden><b>bluewindow</b><table>
<tr><td>drag</td><td>move a stage; a Block takes what is inside it</td></tr><tr><td>drag on empty space</td><td>select many; Shift+click adds one; then drag or Del</td></tr>
<tr><td>corner handle</td><td>resize a Block or Note</td></tr><tr><td>click</td><td>open the properties sheet; Enter in a field applies</td></tr>
<tr><td>V / L / D</td><td>Select, Link, Delete mode; in Link click the source then the target</td></tr><tr><td>A</td><td>place an Action; the palette on the left has every other kind</td></tr>
<tr><td>Del</td><td>remove the selected stage(s); a loop or wait pair goes together</td></tr><tr><td>Ctrl+Z</td><td>undo, up to 50 steps</td></tr><tr><td>Ctrl+Y</td><td>redo (also Ctrl+Shift+Z); a new change clears it</td></tr><tr><td>Esc</td><td>cancel placing or linking, close the sheet</td></tr>
<tr><td>G</td><td>grid on/off: Studio's 15px grid, moves snap to it (off = free placement; Blue Prism imports either)</td></tr><tr><td>Shift+L</td><td>light: Blue Prism Studio's own shapes and colours; dark is the default</td></tr><tr><td>Ctrl+wheel</td><td>zoom (the +/&minus; buttons do the same)</td></tr><tr><td>Checks</td><td>live rules (errors block Save), the validate.py verdict, and for an object whether its code stages compile</td></tr><tr><td>Save</td><td>downloads the next version; render it and the diff ribbon shows what changed</td></tr>
</table><button onclick="toggleHelp()">close</button></div><div id="toast" hidden></div><div id="yesno" hidden>Decision link: <button class="y">Yes</button><button class="n">No</button></div>
<script>(function(){var t='dark',g='1';try{t=localStorage.getItem('bluewindow:theme')||'dark';g=localStorage.getItem('bluewindow:grid')||'1'}catch(e){}if(t==='dark')document.body.classList.add('dark');if(g==='1')document.body.classList.add('grid')})();</script>
<script>var BW_XML=${J(xml)},BW_BASE=${J(base)},BW_VER=${ver},BW_DIFF=${J(diffJson)},BW_INCIDENT=${J(incident || null)},BW_OBJECTS=${J(objects)},BW_LINKS=${J(opts.links || {})},BW_MEMBERS=${J(opts.members || [])},BW_RELNAME=${J(opts.relName || '')},BW_PAGEVER=${PAGE_VERSION},BW_STATIC=${J({ validate: validation ? validation.ok : null, compile: compile && compile.ran ? compile.ok : null })};</script>
<script>${SRC[0].replace(/<\/script/gi, '<\\/script')}</script>
<script>${SRC[1].replace(/<\/script/gi, '<\\/script')}</script>
<script>${SRC[2].replace(/<\/script/gi, '<\\/script')}</script>
</body></html>`;
}

// internal/: Blue Prism's built-in objects (internal.json) + exports of the supplied VBOs dropped there; visible from every page, like in Blue Prism
const internalDir = () => path.join(HERE, 'internal');
function internalCatalog() {
  try { const j = JSON.parse(fs.readFileSync(path.join(internalDir(), 'internal.json'), 'utf8'));
    return (j.objects || []).map(o => ({ object: o.object, actions: (o.actions || []).map(a => ({ name: a.name, inputs: a.inputs || [], outputs: a.outputs || [] })), internal: true, verified: !!o.verified })); } catch (e) { return []; }
}
// the action catalog: every object export found next to the file, in the out folder, in --with folders/files, and in internal/
function catalog(places, self) {
  const files = new Set();
  for (const p of places.concat([internalDir()])) {
    if (!p || !fs.existsSync(p)) continue;
    if (fs.statSync(p).isFile()) { files.add(path.resolve(p)); continue; }
    for (const f of fs.readdirSync(p)) if (/\.xml$/i.test(f) && path.resolve(p, f) !== path.resolve(self)) files.add(path.resolve(p, f));
  }
  const xmls = [];
  for (const f of files) { try { const t = fs.readFileSync(f, 'utf8'); if (/<process [^>]*type="object"/.test(t.slice(0, 2000))) xmls.push(t); } catch (e) { } }
  const out = E.catalogFrom(xmls), have = new Set(out.map(o => o.object.toLowerCase()));
  for (const o of internalCatalog()) if (!have.has(o.object.toLowerCase())) out.push(o);
  return out.sort((a, b) => a.object.localeCompare(b.object));
}
function render(file, opts) {
  opts = opts || {};
  const { base, ver: fileVer } = baseAndVersion(file);
  const outRoot = opts.out || path.dirname(file), dir = path.join(outRoot, base);
  fs.mkdirSync(dir, { recursive: true });
  const have = versionsIn(dir, base);
  let ver = fileVer;
  const inPlace = path.resolve(path.dirname(file)) === path.resolve(dir) && fileVer > 0;
  if (!inPlace) { ver = (have.length ? have[have.length - 1] : 0) + 1; fs.copyFileSync(file, path.join(dir, `${base}.v${ver}.xml`)); }
  const xmlFile = path.join(dir, `${base}.v${ver}.xml`);
  const xml = fs.readFileSync(xmlFile, 'utf8');
  const prevVer = versionsIn(dir, base).filter(v => v < ver).pop();
  let diff = null;
  if (prevVer) { try { diff = E.diff(D.parseBp(fs.readFileSync(path.join(dir, `${base}.v${prevVer}.xml`), 'utf8')), D.parseBp(xml)); } catch (e) { diff = null; } }
  const incident = opts.incident ? JSON.parse(fs.readFileSync(opts.incident, 'utf8')) : null;
  const validation = opts.validate === false ? null : validate(xmlFile);
  let objects = catalog([path.dirname(file), outRoot].concat(opts.with || [], config().with), xmlFile);
  if (opts.catalog) { const have = new Set(objects.map(o => o.object)); objects = objects.concat(opts.catalog.filter(o => !have.has(o.object))).sort((a, b) => a.object.localeCompare(b.object)); }
  const compiled = opts.validate === false ? null : compile(xmlFile, bpHome(opts.bp));
  const html = page({ xml, base, ver, diff, incident, validation, objects, compile: compiled, links: opts.links || staticLinks(outRoot, base), members: opts.members, relName: opts.relName });
  const htmlFile = path.join(dir, `${base}.v${ver}.html`);
  fs.writeFileSync(htmlFile, html, 'utf8');
  try { writeIndex(dir, base); } catch (e) { }
  return { htmlFile, xmlFile, ver, diff, validation, objects, compile: compiled };
}

function watch(folder, opts) {
  const seen = new Set();
  const scan = () => {
    // downloads: the editor saves <base>.vN.xml there; move it next to its siblings
    if (opts.downloads && fs.existsSync(opts.downloads)) for (const f of fs.readdirSync(opts.downloads)) {
      const m = /^(.*)\.v(\d+)\.xml$/i.exec(f); if (!m) continue;
      const dir = path.join(folder, m[1]); if (!fs.existsSync(dir)) continue;
      const dst = path.join(dir, f); if (fs.existsSync(dst)) continue;
      try { fs.renameSync(path.join(opts.downloads, f), dst); console.log('moved ' + f + ' -> ' + dir); } catch (e) { try { fs.copyFileSync(path.join(opts.downloads, f), dst); fs.unlinkSync(path.join(opts.downloads, f)); } catch (e2) { } }
    }
    for (const d of fs.readdirSync(folder)) {
      const dir = path.join(folder, d); if (!fs.statSync(dir).isDirectory()) continue;
      for (const f of fs.readdirSync(dir)) {
        const m = /^(.*)\.v(\d+)\.xml$/i.exec(f); if (!m || m[1] !== d) continue;
        const html = path.join(dir, f.replace(/\.xml$/i, '.html'));
        if (fs.existsSync(html) || seen.has(path.join(dir, f))) continue;
        seen.add(path.join(dir, f));
        try { const r = render(path.join(dir, f), { out: folder, with: opts.with, bp: opts.bp }); console.log('rendered ' + path.basename(r.htmlFile) + (r.validation && r.validation.ran ? (r.validation.ok ? '  validate: ALL CLEAN' : '  validate: PROBLEMS') : '') + (r.compile && r.compile.ran ? (r.compile.ok ? '  compile: OK' : '  compile: PROBLEMS') : '')); }
        catch (e) { console.log('render failed for ' + f + ': ' + e.message); }
      }
    }
  };
  console.log('bluewindow watching ' + folder + (opts.downloads ? ' and ' + opts.downloads : '') + ' (Ctrl+C to stop)');
  scan(); setInterval(scan, 2000);
}

// ---------------- serve: inbox -> click -> page; Save -> next version on disk ----------------
function home(cfg, msg, st) {
  st = st || { busy: null, failed: {} };
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const inbox = fs.existsSync(cfg.inbox) ? fs.readdirSync(cfg.inbox).filter(f => /\.xml$/i.test(f)).sort() : [];
  const projects = fs.existsSync(cfg.projects) ? fs.readdirSync(cfg.projects).filter(d => { if (d === '_releases') return false; try { return fs.statSync(path.join(cfg.projects, d)).isDirectory(); } catch (e) { return false; } }) : [];
  const relRoot = path.join(cfg.projects, '_releases');
  const releases = fs.existsSync(relRoot) ? fs.readdirSync(relRoot).map(k => { try { const j = JSON.parse(fs.readFileSync(path.join(relRoot, k, 'index.json'), 'utf8')); return { k, j, edited: editedMembers(cfg, k, j).length }; } catch (e) { return null; } }).filter(Boolean) : [];
  const parents = new Set(releases.map(r => r.j.from).filter(Boolean));
  const rows = projects.map(d => {
    const vs = versionsIn(path.join(cfg.projects, d), d), last = vs[vs.length - 1]; if (!last) return null;
    const t = fs.statSync(path.join(cfg.projects, d, `${d}.v${last}.xml`)).mtime;
    return { d, vs, last, t };
  }).filter(Boolean).sort((a, b) => b.t - a.t);
  const bp = bpHome([]);
  return `<!doctype html><html><head><meta charset="utf-8"><title>bluewindow</title><style>
:root{--bg:#14161b;--panel:#1c1f26;--line:#2c313c;--text:#d9dde6;--muted:#8a93a6;--acc:#4f8cff;--bad:#e5484d}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui,Segoe UI,sans-serif}
main{max-width:860px;margin:0 auto;padding:28px 16px}h1{font-size:20px;margin:0 0 4px}h1 b{color:var(--acc)}
.muted{color:var(--muted)}section{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px 16px;margin:16px 0}
h2{font-size:14px;margin:0 0 10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.row{display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid var(--line)}.row:first-of-type{border-top:0}
.row .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
a.btn,button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:5px 12px;font:inherit;cursor:pointer;text-decoration:none}
a.ghost{background:transparent;color:var(--muted);padding:2px 4px}a.ghost:hover{color:var(--text)}
#drop{border:2px dashed var(--line);border-radius:8px;padding:18px;text-align:center;color:var(--muted)}#drop.on{border-color:var(--acc);color:var(--text)}
.msg{background:#2a1f12;border:1px solid #6b4a1c;border-radius:6px;padding:8px 12px}code{background:#0f1115;padding:1px 5px;border-radius:4px}
</style></head><body><main>
<h1><b>blue</b>window</h1><div class="muted">compile check: ${bp.length ? "Blue Prism's own compiler (" + esc(bp[0]) + ')' : 'Blue Prism folder not found, development compiler (set "bp" in bluewindow.json)'}</div>
${msg ? `<p class="msg">${esc(msg)}</p>` : ''}
<section><h2>Inbox</h2><div id="drop">drop Blue Prism exports (.xml) or releases (.bprelease) here, or put them in <code>${esc(cfg.inbox)}</code></div>
${inbox.length ? inbox.map(f => `<div class="row"><span class="n">${esc(f)} <span class="muted">${st.busy === f ? 'rendering...' : st.failed[f] ? 'skipped: ' + esc(st.failed[f].why) : 'waiting'}</span></span></div>`).join('') : '<div class="muted" style="padding-top:8px">empty: everything dropped here is rendered into Projects by itself</div>'}</section>
${releases.length ? `<section><h2>Releases</h2>${releases.map(r => `<div class="row"><span class="n">${esc(r.j.name)}${r.j.from ? ' trimmed' : ''}${/\(\d+\)$/.test(r.k) ? ' ' + esc(r.k.match(/\(\d+\)$/)[0]) : ''} <span class="muted">${r.j.members.filter(m => m.type === 'process').length} processes, ${r.j.members.filter(m => m.type === 'object').length} objects · ${esc(r.j.created || '')}${r.edited ? ' · ' + r.edited + ' edited' : ''}${parents.has(r.k) ? ' · original, trimmed copy below' : ''}</span></span><a class="btn" target="_blank" href="/r/${encodeURIComponent(r.k)}">Open</a></div>`).join('')}</section>` : ''}
<section><h2>Projects</h2>${rows.length ? rows.map(r => `<div class="row"><span class="n">${esc(r.d)} <span class="muted">v${r.last} · ${r.t.getFullYear()}-${String(r.t.getMonth() + 1).padStart(2, '0')}-${String(r.t.getDate()).padStart(2, '0')} ${String(r.t.getHours()).padStart(2, '0')}:${String(r.t.getMinutes()).padStart(2, '0')}</span></span>
${r.vs.slice(-6, -1).map(v => `<a class="ghost" target="_blank" href="/p/${encodeURIComponent(r.d)}/${encodeURIComponent(r.d)}.v${v}.html">v${v}</a>`).join('')}
<a class="btn" target="_blank" href="/p/${encodeURIComponent(r.d)}/${encodeURIComponent(r.d)}.v${r.last}.html">Open v${r.last}</a></div>`).join('') : '<div class="muted">none yet</div>'}
<div class="muted" style="margin-top:10px">files: <code>${esc(cfg.projects)}</code> (import the .vN.xml from there into Blue Prism)</div></section>
</main><script>
var d=document.getElementById('drop');
['dragenter','dragover'].forEach(function(e){document.addEventListener(e,function(ev){ev.preventDefault();d.classList.add('on');});});
document.addEventListener('dragleave',function(){d.classList.remove('on');});
document.addEventListener('drop',function(ev){ev.preventDefault();d.classList.remove('on');var fs=[].slice.call(ev.dataTransfer.files).filter(function(f){return /\\.(xml|bprelease)$/i.test(f.name);});
 if(!fs.length){alert('only .xml exports or .bprelease files');return;}
 Promise.all(fs.map(function(f){return f.text().then(function(t){return fetch('/upload?name='+encodeURIComponent(f.name),{method:'POST',body:t});});})).then(function(){location.reload();});});
// live: the server renders the inbox by itself; reload when anything changed
var stamp=null;setInterval(function(){fetch('/state').then(function(r){return r.text();}).then(function(t){if(stamp!==null&&t!==stamp)location.reload();stamp=t;},function(){});},1500);
</script></body></html>`;
}
// what a served page gets told: where it lives, and for every object it could want to open, the address of that object's page.
// Keys are forgiving: the name as the release lists it, the object's own name, both also lower-cased and space-collapsed.
const normName = n => String(n == null ? '' : n).replace(/\s+/g, ' ').trim().toLowerCase();
function addObjKey(map, name, url) { if (!name) return; if (!map[name]) map[name] = url; const k = '~' + normName(name); if (!map[k]) map[k] = url; }
function projectObjects(cfg) {   // single exports under Projects that are objects: name -> latest page
  const out = [];
  try { for (const d of fs.readdirSync(cfg.projects)) {
    if (d === '_releases') continue; const dir = path.join(cfg.projects, d), vs = versionsIn(dir, d); if (!vs.length) continue;
    const f = path.join(dir, d + '.v' + vs[vs.length - 1] + '.xml'); let head = '';
    try { const fd = fs.openSync(f, 'r'), b = Buffer.alloc(6000); const n = fs.readSync(fd, b, 0, 6000, 0); fs.closeSync(fd); head = b.toString('utf8', 0, n); } catch (e) { continue; }
    const tagM = /<process [^>]*>/.exec(head); if (!tagM || !/\btype="object"/i.test(tagM[0])) continue;
    out.push({ name: D.attr(tagM[0], 'name'), base: d, file: f, url: '/p/' + encodeURIComponent(d) + '/' + encodeURIComponent(d + '.v' + vs[vs.length - 1] + '.html') });
  } } catch (e) { }
  return out;
}
function injectServe(html, info) { const js = '<head><script>window.BW_SERVE=' + JSON.stringify(info).replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--') + '</script>'; return html.replace(/<head>/i, () => js); }

// ---------------- releases ----------------
const safeName = n => String(n || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+$/, '').slice(0, 120) || '_';
function relDir(cfg, k) { return path.join(cfg.projects, '_releases', safeName(k)); }
function memberDir(cfg, k, base) { return path.join(relDir(cfg, k), 'members', safeName(base)); }
function relVersions(dir) { return fs.existsSync(dir) ? fs.readdirSync(dir).map(f => /^release\.v(\d+)\.bprelease$/.exec(f)).filter(Boolean).map(m => +m[1]).sort((a, b) => a - b) : []; }
function editedMembers(cfg, k, j) { return j.members.filter(m => { const v = versionsIn(memberDir(cfg, k, m.base), m.base); return v.length && v[v.length - 1] > 1; }); }
/// a .bprelease from the inbox: stored as release.v1.bprelease, indexed, its objects turned into the action catalog. Members open on demand.
// one background renderer for all releases: members without a page yet, one at a time (each runs the checks, so it takes a while)
const renderQueue = [], queued = new Set(); let rendering = false;
function memberReady(cfg, k, m) { const d = memberDir(cfg, k, m.base); return fs.existsSync(path.join(d, m.base + '.v1.html')) || fs.existsSync(path.join(d, 'render-failed.txt')); }
function memberFailed(cfg, k, m) { const f = path.join(memberDir(cfg, k, m.base), 'render-failed.txt'); try { return fs.existsSync(f) && !fs.existsSync(path.join(memberDir(cfg, k, m.base), m.base + '.v1.html')) ? fs.readFileSync(f, 'utf8') : null; } catch (e) { return null; } }
/// Which members get rendered without a click: the processes always; the objects only those the processes use (the trim set),
/// and none at all once a trimmed copy of this release exists (the trimmed one renders them). Unused objects: on Open only.
// releases imported before the "True" fix carry a catalog with 0 actions per object, and pages rendered with it:
// rebuild the catalog + checks once and drop the rendered pages (the queue renders them again; saved versions stay)
const CATALOG_VERSION = 5;
function upgradeRelease(cfg, k) {
  const dir = relDir(cfg, k); let j; try { j = JSON.parse(fs.readFileSync(path.join(dir, 'index.json'), 'utf8')); } catch (e) { return; }
  if ((j.catalogVersion || 1) >= CATALOG_VERSION) return;
  try {
    const text = fs.readFileSync(path.join(dir, 'release.v1.bprelease'), 'utf8'), cat = [];
    const fi = R.index(text), fresh = new Map(fi.members.map(m => [m.id, m]));   // read again with the current reader: types, own names, other items
    j.items = fi.items; j.other = fi.other;
    for (const m of j.members) { const f = fresh.get(m.id); if (f) { m.type = f.type; m.innerName = f.innerName; } }
    delete j.trimPlan;
    for (const m of j.members) if (m.type === 'object') { try { cat.push(...E.catalogFrom([R.extract(text, m)])); } catch (e) { } }
    fs.writeFileSync(path.join(dir, 'catalog.json'), JSON.stringify(cat), 'utf8');
    j.checks = R.checks(text, j, cat); j.catalogVersion = CATALOG_VERSION;
    const md = path.join(dir, 'members');
    if (fs.existsSync(md)) for (const d of fs.readdirSync(md)) for (const f of fs.readdirSync(path.join(md, d))) if (/\.html$/i.test(f) || f === 'render-failed.txt') fs.unlinkSync(path.join(md, d, f));
    fs.writeFileSync(path.join(dir, 'index.json'), JSON.stringify(j), 'utf8');
    console.log('release ' + k + ': catalog rebuilt (' + cat.reduce((t, o) => t + o.actions.length, 0) + ' actions), pages render again');
  } catch (e) { console.log('could not upgrade release ' + k + ': ' + e.message); }
}
function ensureTrimPlan(cfg, k, j) {   // releases imported by an older bluewindow have none yet
  if (j.trimPlan) return j;
  try { const t = fs.readFileSync(path.join(relDir(cfg, k), 'release.v1.bprelease'), 'utf8'); const cl = R.closure(j, R.uses(t, j), j.members.filter(m => m.type === 'process').map(m => m.id));
        j.trimPlan = { keep: [...cl.keep], missing: cl.missing }; fs.writeFileSync(path.join(relDir(cfg, k), 'index.json'), JSON.stringify(j), 'utf8'); }
  catch (e) { j.trimPlan = { keep: j.members.filter(m => m.type === 'process').map(m => m.id), missing: [], error: e.message }; }
  return j;
}
function renderTargets(cfg, k, j) {
  ensureTrimPlan(cfg, k, j);
  const procs = j.members.filter(m => m.type === 'process');
  let trimmedChild = false;
  try { for (const o of fs.readdirSync(path.join(cfg.projects, '_releases'))) { if (o === k) continue; try { if (JSON.parse(fs.readFileSync(path.join(relDir(cfg, o), 'index.json'), 'utf8')).from === k) { trimmedChild = true; break; } } catch (e) { } } } catch (e) { }
  if (trimmedChild) return [];   // the trimmed copy is the working one
  const keep = new Set((j.trimPlan && j.trimPlan.keep) || j.members.map(m => m.id));
  return procs.concat(j.members.filter(m => m.type === 'object' && keep.has(m.id)));
}
function queueRelease(cfg, k) {
  let j; try { j = JSON.parse(fs.readFileSync(path.join(relDir(cfg, k), 'index.json'), 'utf8')); } catch (e) { return; }
  for (const m of renderTargets(cfg, k, j)) { const key = k + '\u0001' + m.id; if (!queued.has(key) && !memberReady(cfg, k, m)) { queued.add(key); renderQueue.push({ cfg, k, id: m.id, key, type: m.type }); } }
  if (!rendering) { rendering = true; setTimeout(renderNext, 10); }
}
function renderNext() {
  const job = renderQueue.shift();
  if (!job) { rendering = false; return; }
  try { openMember(job.cfg, job.k, job.id); }
  catch (e) {
    console.log('could not render a member of ' + job.k + ': ' + e.message);
    try { const j = JSON.parse(fs.readFileSync(path.join(relDir(job.cfg, job.k), 'index.json'), 'utf8')), m = j.members.find(x => x.id === job.id);
          fs.mkdirSync(memberDir(job.cfg, job.k, m.base), { recursive: true }); fs.writeFileSync(path.join(memberDir(job.cfg, job.k, m.base), 'render-failed.txt'), e.message, 'utf8'); } catch (e2) { }
  }
  queued.delete(job.key);
  if (!renderQueue.length) console.log('all members rendered');
  setTimeout(renderNext, 10);
}
function importRelease(cfg, file, opts) {
  opts = opts || {};
  const text = fs.readFileSync(file, 'utf8');
  const info = R.index(text);
  const hash = require('crypto').createHash('sha1').update(text).digest('hex');
  const base = safeName((info.name || path.basename(file).replace(/\.\w+$/, '')) + ' ' + String(info.created || '').replace(/[^0-9]/g, '').slice(0, 14) + (opts.label ? ' ' + opts.label : ''));
  // the same bytes again = already here (the file stays where it is); different bytes under the same name = its own release
  let k = base;
  for (let n = 2; fs.existsSync(path.join(relDir(cfg, k), 'index.json')); n++) {
    let old = null; try { old = JSON.parse(fs.readFileSync(path.join(relDir(cfg, k), 'index.json'), 'utf8')).hash; } catch (e) { }
    if (old === hash) return { k, again: true };
    k = safeName(base + ' (' + n + ')');
  }
  const dir = relDir(cfg, k);
  fs.mkdirSync(path.join(dir, 'members'), { recursive: true });
  const used = new Set();
  for (const m of info.members) { let b = safeName(m.name); if (used.has(b.toLowerCase())) b = safeName(m.name + ' ~' + String(m.id).slice(0, 8)); used.add(b.toLowerCase()); m.base = b; }
  const cat = [];
  for (const m of info.members) if (m.type === 'object') { try { cat.push(...E.catalogFrom([R.extract(text, m)])); } catch (e) { } }
  const probs = R.checks(text, info, cat);
  try { const cl = R.closure(info, R.uses(text, info), info.members.filter(m => m.type === 'process').map(m => m.id)); info.trimPlan = { keep: [...cl.keep], missing: cl.missing }; } catch (e) { }
  if (opts.copy) fs.copyFileSync(file, path.join(dir, 'release.v1.bprelease'));
  else { try { fs.renameSync(file, path.join(dir, 'release.v1.bprelease')); } catch (e) { fs.copyFileSync(file, path.join(dir, 'release.v1.bprelease')); fs.unlinkSync(file); } }
  fs.writeFileSync(path.join(dir, 'catalog.json'), JSON.stringify(cat), 'utf8');
  fs.writeFileSync(path.join(dir, 'index.json'), JSON.stringify(Object.assign(info, { checks: probs, file: path.basename(file), hash, from: opts.from || null, catalogVersion: CATALOG_VERSION })), 'utf8');
  // a release carrying objects its processes never use: trim it right away; the trimmed copy is the one that gets rendered
  const keepIds = new Set((info.trimPlan && info.trimPlan.keep) || info.members.map(m => m.id));
  if (!opts.from && info.members.some(m => m.type === 'object' && !keepIds.has(m.id))) {
    const b = buildRelease(cfg, k, { trim: true });
    if (b.release) { console.log('release ' + k + ': ' + b.trimmed.dropped + ' unused objects, trimmed copy "' + b.release + '"'); return { k, trimmedTo: b.release }; }
    console.log('release ' + k + ': could not trim (' + (b.error || 'unknown') + '), rendering it as it is');
  }
  // the processes are what you came for: their pages are ready right away
  for (const m of info.members) if (m.type === 'process') { try { openMember(cfg, k, m.id); } catch (e) { console.log('could not render ' + m.name + ': ' + e.message); } }
  // then the objects, in the background one at a time, so the page opens right away
  if (opts.from) for (let i = renderQueue.length - 1; i >= 0; i--) if (renderQueue[i].k === opts.from && renderQueue[i].type === 'object') { queued.delete(renderQueue[i].key); renderQueue.splice(i, 1); }
  queueRelease(cfg, k);
  return { k };
}
function releaseStatic(cfg, k, selfBase) {   // what a member page carries for folder use: the release's members and its objects, as relative links
  const j = JSON.parse(fs.readFileSync(path.join(relDir(cfg, k), 'index.json'), 'utf8')), links = {};
  const ms = j.members.filter(m => m.type === 'process').concat(j.members.filter(m => m.type === 'object'));
  for (const m of ms) if (m.type === 'object') { addObjKey(links, m.name, relLink(m.base)); addObjKey(links, m.innerName, relLink(m.base)); }
  return { links, members: ms.map(m => ({ name: m.name, type: m.type, base: m.base, url: relLink(m.base) })), relName: j.name + (j.from ? ' trimmed' : ''),
           catalog: JSON.parse(fs.readFileSync(path.join(relDir(cfg, k), 'catalog.json'), 'utf8')) };
}
function openMember(cfg, k, id) {
  const dir = relDir(cfg, k), j = JSON.parse(fs.readFileSync(path.join(dir, 'index.json'), 'utf8'));
  const m = j.members.find(x => x.id === id); if (!m) throw new Error('no member ' + id);
  const md = memberDir(cfg, k, m.base); fs.mkdirSync(md, { recursive: true });
  const v1 = path.join(md, m.base + '.v1.xml');
  if (!fs.existsSync(v1)) { const t = fs.readFileSync(path.join(dir, 'release.v1.bprelease'), 'utf8'); fs.writeFileSync(v1, R.extract(t, m), 'utf8'); }
  const vs = versionsIn(md, m.base), last = vs[vs.length - 1];
  const html = path.join(md, m.base + '.v' + last + '.html');
  if (!fs.existsSync(html)) render(path.join(md, m.base + '.v' + last + '.xml'), Object.assign({ out: path.join(dir, 'members'), with: cfg.with, bp: cfg.bp }, releaseStatic(cfg, k, m.base)));
  try { fs.unlinkSync(path.join(md, 'render-failed.txt')); } catch (e) { }
  return '/m/' + encodeURIComponent(k) + '/' + encodeURIComponent(m.base) + '/' + encodeURIComponent(m.base + '.v' + last + '.html');
}
/// release.v(N+1).bprelease = v1 with every edited member's latest version spliced in; nothing else changes.
function buildRelease(cfg, k, opts) {
  opts = opts || {};
  const dir = relDir(cfg, k), j = JSON.parse(fs.readFileSync(path.join(dir, 'index.json'), 'utf8'));
  const text = fs.readFileSync(path.join(dir, 'release.v1.bprelease'), 'utf8'), rep = {}, names = [];
  for (const m of editedMembers(cfg, k, j)) { const v = versionsIn(memberDir(cfg, k, m.base), m.base).pop(); rep[m.id] = fs.readFileSync(path.join(memberDir(cfg, k, m.base), m.base + '.v' + v + '.xml'), 'utf8'); names.push(m.name + ' v' + v); }
  if (!names.length && !opts.trim && !(j.adds || []).length && !(j.drops || []).length) return { error: 'nothing edited yet: open a member, change it, Save, then build' };
  let out = R.rebuild(text, j, rep);
  const again = R.index(out); if (again.members.length !== j.members.length) return { error: 'rebuild check failed: ' + again.members.length + ' members instead of ' + j.members.length + ' (nothing written)' };
  let trimmed = null;
  if (opts.trim) {
    const cl = R.closure(again, R.uses(out, again), again.members.filter(m => m.type === 'process').map(m => m.id));
    const t = R.trim(out, again, cl.keep); const chk = R.index(t.text);
    if (chk.members.length !== again.members.length - t.dropped) return { error: 'trim check failed (nothing written)' };
    out = t.text; trimmed = { kept: chk.members.length, dropped: t.dropped, missing: cl.missing };
  }
  const adds = j.adds || [], drops = j.drops || [];
  if (adds.length || drops.length) {
    const cur = R.index(out), byKey = new Map((j.items || []).map(it => [it.kind + '\u0001' + it.name, it.start]));
    const dropNow = cur.items.filter(it => drops.includes(byKey.get(it.kind + '\u0001' + it.name))).map(it => it.start);   // same items, offsets of this text
    out = R.editItems(out, cur, dropNow, adds.map(a => a.xml));
    const chk = R.index(out); if (chk.items.length !== cur.items.length - dropNow.length + adds.length || chk.members.length !== cur.members.length) return { error: 'item check failed: ' + chk.items.length + ' items after the edit (nothing written)' };
    names.push(...adds.map(a => '+ ' + kindLabel(a.kind) + ' ' + a.name), ...(j.items || []).filter(it => drops.includes(it.start)).map(it => '- ' + kindLabel(it.kind) + ' ' + it.name));
  }
  const n = (relVersions(dir).pop() || 1) + 1, f = path.join(dir, 'release.v' + n + '.bprelease');
  fs.writeFileSync(f, out, 'utf8');
  try { fs.writeFileSync(f + '.json', JSON.stringify({ edited: names, trimmed }), 'utf8'); } catch (e) { }
  let release = null;
  if (trimmed) { try { release = importRelease(cfg, f, { copy: true, label: 'trimmed', from: k }).k; } catch (e) { console.log('trimmed release built but not opened: ' + e.message); } }
  return { file: f, name: path.basename(f), members: names, trimmed, release };
}
const KIND_LABEL = { 'environment-variable': 'env var', 'work-queue': 'queue', 'credential': 'credential', 'calendar': 'calendar', 'font': 'font', 'process-group': 'group', 'object-group': 'group', 'dashboard': 'dashboard', 'tile': 'tile', 'webapiservice': 'web api', 'webservice': 'web service', 'skill': 'skill', 'environment-lock': 'env lock', 'data-source': 'data source' };
function kindLabel(k) { return KIND_LABEL[String(k).toLowerCase()] || String(k).replace(/[-_]/g, ' '); }
/// ", 4 env vars, 2 queues" for the release header; nothing when the release holds only processes and objects.
function otherKinds(j) {
  const items = j.items; if (!items) return j.other ? ', ' + j.other + ' other items' : '';
  const c = {}; for (const it of items) { const k = kindLabel(it.kind); c[k] = (c[k] || 0) + 1; }
  return Object.keys(c).sort().map(k => ', ' + c[k] + ' ' + k + (c[k] === 1 ? '' : k.endsWith('s') ? '' : 's')).join('');
}
function releasePage(cfg, k) {
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const dir = relDir(cfg, k), j = JSON.parse(fs.readFileSync(path.join(dir, 'index.json'), 'utf8'));
  const edited = new Map(editedMembers(cfg, k, j).map(m => [m.id, versionsIn(memberDir(cfg, k, m.base), m.base).pop()]));
  const built = relVersions(dir).filter(v => v > 1);
  const K = encodeURIComponent(k), procs = j.members.filter(m => m.type === 'process'), objs = j.members.filter(m => m.type === 'object');
  ensureTrimPlan(cfg, k, j);
  let child = null; try { for (const o of fs.readdirSync(path.join(cfg.projects, '_releases'))) { try { if (JSON.parse(fs.readFileSync(path.join(relDir(cfg, o), 'index.json'), 'utf8')).from === k) child = o; } catch (e) { } } } catch (e) { }
  const targets = renderTargets(cfg, k, j), readyN = targets.filter(m => memberReady(cfg, k, m)).length, targetN = targets.length;
  const keepSet = new Set(j.trimPlan.keep), usedObjs = objs.filter(m => keepSet.has(m.id)), unused = objs.length - usedObjs.length;
  const builtNote = v => { try { const b = JSON.parse(fs.readFileSync(path.join(dir, 'release.v' + v + '.bprelease.json'), 'utf8')); return [b.edited && b.edited.length ? 'edited: ' + b.edited.join(', ') : '', b.trimmed ? 'trimmed to ' + b.trimmed.kept + ' members' : ''].filter(Boolean).join(' · '); } catch (e) { return ''; } };
  const row = m => `<div class="row" data-n="${esc(m.name.toLowerCase())}"><span class="t">${m.type === 'object' ? 'object' : 'process'}</span><span class="n">${esc(m.name)}${m.base !== safeName(m.name) ? ' <span class="muted">(' + esc(m.base.slice(m.name.length).trim()) + ')</span>' : ''}${String(m.published).toLowerCase() === 'true' ? ' <span class="muted">published</span>' : ''}${edited.has(m.id) ? ` <b class="ed">edited v${edited.get(m.id)}</b>` : ''}${memberFailed(cfg, k, m) ? ' <b style="color:var(--bad)">could not render: ' + esc(memberFailed(cfg, k, m)).slice(0, 120) + '</b>' : memberReady(cfg, k, m) ? ' <span class="muted">ready</span>' : ''}</span><a class="btn" target="_blank" href="/r/${K}/open?id=${encodeURIComponent(m.id)}">Open</a></div>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(j.name)} - bluewindow</title><style>
:root{--bg:#14161b;--panel:#1c1f26;--line:#2c313c;--text:#d9dde6;--muted:#8a93a6;--acc:#4f8cff;--bad:#e5484d;--warn:#e0a63a}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui,Segoe UI,sans-serif}main{max-width:960px;margin:0 auto;padding:24px 16px}
a{color:var(--acc)}h1{font-size:20px;margin:0}.muted{color:var(--muted)}section{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px 16px;margin:16px 0}
h2{font-size:14px;margin:0 0 10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}.row{display:flex;align-items:center;gap:10px;padding:6px 0;border-top:1px solid var(--line)}
.row .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row .t{width:56px;color:var(--muted);font-size:12px}
a.btn,button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:5px 12px;font:inherit;cursor:pointer;text-decoration:none}b.ed{color:var(--warn);font-weight:600}
input{background:#0f1115;color:var(--text);border:1px solid var(--line);border-radius:6px;padding:6px 10px;font:inherit;width:100%;box-sizing:border-box}
li.error{color:var(--bad)}li.warn{color:var(--warn)}code{background:#0f1115;padding:1px 5px;border-radius:4px}#out{margin-top:8px}
</style></head><body><main>
${child ? `<p class="msg" style="background:#1f2a3d;border:1px solid #3f6db3;border-radius:6px;padding:8px 12px">This is the original as dropped in. ${j.members.length - (j.trimPlan ? j.trimPlan.keep.length : 0)} objects are not used by its process${procs.length === 1 ? '' : 'es'}, so bluewindow made a trimmed copy: <a href="/r/${encodeURIComponent(child)}">${esc(child)}</a>. Work there.</p>` : ''}
<div class="muted"><a href="/">bluewindow</a> / release${j.from ? ` · trimmed from <a href="/r/${encodeURIComponent(j.from)}">${esc(j.from)}</a>` : ''}</div><h1>${esc(j.name)}${j.from ? ' <span class="muted">trimmed</span>' : ''}</h1>
<div class="muted">${procs.length} process${procs.length === 1 ? '' : 'es'}, ${objs.length} objects${otherKinds(j)} · created ${esc(j.created)} by ${esc(j.by)} · ${esc(j.package)}${j.notes ? ' · ' + esc(j.notes) : ''}</div>
<section><h2>Build</h2><div>${edited.size || (j.adds || []).length || (j.drops || []).length ? [edited.size ? edited.size + ' member' + (edited.size === 1 ? '' : 's') + ' edited' : '', (j.adds || []).length ? (j.adds || []).length + ' item' + ((j.adds || []).length === 1 ? '' : 's') + ' to add' : '', (j.drops || []).length ? (j.drops || []).length + ' item' + ((j.drops || []).length === 1 ? '' : 's') + ' to drop' : ''].filter(Boolean).join(', ') + '. Build writes a new release with only that changed; every other byte stays as it was.' : 'Nothing edited yet. Open a member, change it, Save; or add / drop an item below; then build here.'}</div>
<div style="margin-top:8px"><button id="build" ${edited.size || (j.adds || []).length || (j.drops || []).length ? '' : 'disabled'}>Build release v${(relVersions(dir).pop() || 1) + 1}</button></div><div id="out" class="muted"></div>
${built.length ? '<div style="margin-top:10px">' + built.map(v => `<div class="row"><span class="n">release.v${v}.bprelease <span class="muted">${esc(builtNote(v))}</span></span><a href="/r/${K}/file/release.v${v}.bprelease">download</a></div>`).join('') + `<div class="muted">on disk: <code>${esc(dir)}</code> (import the newest one in Blue Prism)</div></div>` : ''}</section>
<section><h2>Other items</h2><div class="muted">Packaged with the release and kept byte for byte; Blue Prism creates them on import. Drop one or add an environment variable or a work queue, then Build.</div>
${(j.items || []).map(it => { const d = (j.drops || []).includes(it.start); return `<div class="row"><span class="t">${esc(kindLabel(it.kind))}</span><span class="n"${d ? ' style="text-decoration:line-through;color:var(--muted)"' : ''}>${esc(it.name || '(no name)')}</span><a class="muted" target="_blank" href="/r/${K}/item?start=${it.start}">xml</a> <button class="it" data-op="${d ? 'undrop' : 'drop'}" data-start="${it.start}" style="background:${d ? 'var(--line)' : '#5a2a2a'}">${d ? 'keep' : 'drop'}</button></div>`; }).join('')}
${(j.adds || []).map((a, i) => `<div class="row"><span class="t">${esc(kindLabel(a.kind))}</span><span class="n"><b class="ed">+ ${esc(a.name)}</b></span><a class="muted" target="_blank" href="/r/${K}/item?add=${i}">xml</a> <button class="it" data-op="unadd" data-i="${i}" style="background:var(--line)">remove</button></div>`).join('')}
<form id="addf" style="margin-top:10px;display:grid;grid-template-columns:110px 1fr 1fr 1fr auto;gap:6px;align-items:center"><select name="kind"><option value="environment-variable">env var</option><option value="work-queue">work queue</option></select><input name="name" placeholder="name" required><input name="value" placeholder="value (env var) / key field (queue)"><input name="description" placeholder="description (env var) / max attempts (queue)"><button>Add</button></form><div id="iout" class="muted"></div></section>
<section><h2>Trim</h2><div>${unused ? `The process${procs.length === 1 ? '' : 'es'} use <b>${usedObjs.length}</b> of the ${objs.length} objects (counting what those objects call in turn). A trimmed release keeps ${procs.length === 1 ? 'the process' : 'every process'} and only those, plus any other items as they are.` : 'Every object in this release is used: nothing to trim.'}</div>
${j.trimPlan.missing.length ? `<div class="muted" style="margin-top:6px">called but not in this release (must already exist on the target): ${j.trimPlan.missing.map(esc).join(', ')}</div>` : ''}
${unused ? `<details style="margin-top:6px"><summary class="muted">the ${usedObjs.length} objects kept</summary><div class="muted">${usedObjs.map(m => esc(m.name)).join(', ')}</div></details>
<div style="margin-top:8px"><button id="trim">Build trimmed release v${(relVersions(dir).pop() || 1) + 1}</button> <span class="muted">${edited.size ? 'includes the ' + edited.size + ' edited member' + (edited.size === 1 ? '' : 's') : ''}</span></div><div id="tout" class="muted"></div>` : ''}</section>
<section><h2>Release checks</h2>${(j.checks || []).length ? '<ul>' + j.checks.map(c => `<li class="${c.level}">${esc(c.member)} / <b>${esc(c.stage)}</b>: ${esc(c.msg)}</li>`).join('') + '</ul>' : '<div class="muted">every Action stage calls an object + published action this release carries (Blue Prism internal objects skipped)</div>'}</section>
<section><h2>Members <span style="text-transform:none;letter-spacing:0">${child ? '· trimmed copy: <a href="/r/' + encodeURIComponent(child) + '">' + esc(child) + '</a> (members here render when opened)' : readyN < targetN ? '· rendering ' + readyN + ' of ' + targetN + (targetN < j.members.length ? ' (the ones in use)' : '') + ', Open works on any member now' : targetN < j.members.length ? '· the ' + targetN + ' in use are ready; the rest render when opened' : '· all ' + j.members.length + ' ready'}</span></h2><input id="q" placeholder="filter by name"><div id="list">${procs.map(row).join('')}${objs.map(row).join('')}</div></section>
</main><script>
${readyN < targetN ? "setTimeout(function(){if(!document.getElementById('q').value)location.reload();},4000);" : ''}
document.getElementById('q').oninput=function(){var q=this.value.toLowerCase();[].forEach.call(document.querySelectorAll('#list .row'),function(r){r.style.display=r.getAttribute('data-n').indexOf(q)>=0?'':'none';});};
var tb=document.getElementById('trim');if(tb)tb.onclick=function(){var o=document.getElementById('tout');o.textContent='building...';fetch('/r/${K}/build?trim=1',{method:'POST'}).then(function(r){return r.json();}).then(function(j){if(j.error){o.textContent=j.error;return;}location.href=j.release?'/r/'+encodeURIComponent(j.release):location.href;},function(e){o.textContent='failed: '+e;});};
[].forEach.call(document.querySelectorAll('button.it'),function(b){b.onclick=function(){fetch('/r/${K}/item',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op:b.dataset.op,start:+b.dataset.start,i:+b.dataset.i})}).then(function(r){return r.json();}).then(function(j){if(j.error){document.getElementById('iout').textContent=j.error;return;}location.reload();});};});
document.getElementById('addf').onsubmit=function(e){e.preventDefault();var f=e.target,o=document.getElementById('iout'),k=f.kind.value,sp={op:'add',kind:k,name:f.name.value};if(k==='work-queue'){sp.keyField=f.value.value;sp.maxAttempts=f.description.value;}else{sp.value=f.value.value;sp.description=f.description.value;}fetch('/r/${K}/item',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(sp)}).then(function(r){return r.json();}).then(function(j){if(j.error){o.textContent=j.error;return;}location.reload();},function(e){o.textContent='failed: '+e;});};
document.getElementById('build').onclick=function(){var o=document.getElementById('out');o.textContent='building...';fetch('/r/${K}/build',{method:'POST'}).then(function(r){return r.json();}).then(function(j){if(j.error){o.textContent=j.error;return;}location.reload();},function(e){o.textContent='failed: '+e;});};
</script></body></html>`;
}

// ---------------- appdef digest: what Blue Spy needs to know about a spy mode, from an export or a release ----------------
// For every object with an Application Modeller: its launch info, then ONE complete element per shape (base type + the set of
// attributes it carries), then a census of attribute names with how many elements use each and how many match on it (inuse).
// Image blobs are cut to their first 80 characters. --full prints every element instead of one per shape.
function appdefDigest(text, opts) {
  opts = opts || {}; const out = [];
  const objs = [];
  if (R.isRelease(text)) { const info = R.index(text); for (const m of info.members) if (m.type === 'object') objs.push({ name: m.name, xml: text.slice(m.innerStart, m.innerEnd) }); }
  else objs.push({ name: D.unx(D.attr((/<process [^>]*>/.exec(text) || [''])[0], 'name') || '?'), xml: text });
  const cut = v => v.length > 80 && /^[A-Za-z0-9+/=]{80,}$/.test(v) ? v.slice(0, 80) + '... (' + v.length + ' chars)' : v;
  for (const o of objs) {
    const ad = /<appdef>([\s\S]*?)<\/appdef>/.exec(o.xml); if (!ad) continue;
    const body = ad[1], els = []; const re = /<element name="([^"]*)">([\s\S]*?)(?=<element name=|<\/element>)/g; let m;
    while ((m = re.exec(body))) {
      const head = m[2], attrs = []; const ra = /<attribute name="([^"]*)"([^>]*)>\s*<ProcessValue datatype="([^"]*)" value="([^"]*)"\s*\/>\s*<\/attribute>/g; let x;
      while ((x = ra.exec(head))) attrs.push({ name: x[1], inuse: /inuse="True"/i.test(x[2]), cmp: (/comparisontype="([^"]*)"/.exec(x[2]) || [])[1] || '', type: x[3], value: cut(D.unx(x[4])) });
      els.push({ name: D.unx(m[1]), type: (/<type>([^<]*)<\/type>/.exec(head) || [])[1] || '', base: (/<basetype>([^<]*)<\/basetype>/.exec(head) || [])[1] || '', dtype: (/<datatype>([^<]*)<\/datatype>/.exec(head) || [])[1] || '', attrs, raw: head });
    }
    const spied = els.filter(e => e.attrs.length); if (!spied.length && !/<apptypeinfo>/.test(body)) continue;
    out.push('=== ' + o.name + ': ' + els.length + ' elements, ' + spied.length + ' spied');
    const ati = /<apptypeinfo>([\s\S]*?)<\/apptypeinfo>/.exec(body);
    if (ati) { out.push('--- application'); out.push('  mode: ' + ((/<id>([^<]*)<\/id>/.exec(ati[1]) || [])[1] || '?')); const rp = /<parameter>\s*<name>([^<]*)<\/name>\s*<value>([^<]*)<\/value>/g; let pm; while ((pm = rp.exec(ati[1]))) out.push('  ' + pm[1] + ' = ' + D.unx(pm[2])); }
    const shapes = new Map();
    for (const e of spied) { const k = e.base + '|' + e.attrs.map(a => a.name).join(','); if (!shapes.has(k)) shapes.set(k, []); shapes.get(k).push(e); }
    out.push('--- ' + shapes.size + ' element shapes (base type + attribute set)' + (opts.full ? ', every element' : ', first of each'));
    for (const [k, group] of shapes) for (const e of opts.full ? group : [group[0]]) {
      out.push('  [' + e.base + (e.type !== e.base ? '/' + e.type : '') + ' ' + e.dtype + '] "' + e.name + '"' + (group.length > 1 && !opts.full ? ' (+' + (group.length - 1) + ' like it)' : ''));
      for (const at of e.attrs) out.push('    ' + (at.inuse ? '* ' : '  ') + at.name + (at.cmp ? ' [' + at.cmp + ']' : '') + ' (' + at.type + ') = ' + JSON.stringify(at.value));
    }
    const census = new Map();
    for (const e of spied) for (const at of e.attrs) { const c = census.get(at.name) || { n: 0, inuse: 0, types: new Set() }; c.n++; if (at.inuse) c.inuse++; c.types.add(at.type); census.set(at.name, c); }
    out.push('--- attribute census: name  elements  matched-on  type');
    for (const [n, c] of [...census].sort((a, b) => b[1].inuse - a[1].inuse || b[1].n - a[1].n)) out.push('  ' + n.padEnd(22) + String(c.n).padStart(4) + String(c.inuse).padStart(6) + '  ' + [...c.types].join('/'));
    out.push('');
  }
  return out.length ? out.join('\n') + '\n' : 'no Application Modeller elements with attributes found\n';
}
// ---------------- Run: bprun on the open flow, with the estate simulated ----------------
function pyRun(args, opts, cb) {   // first python that starts; async so the server keeps serving
  const cands = ['python', 'python3', 'py']; let i = 0;
  const next = () => { if (i >= cands.length) return cb(new Error('python not found'));
    const py = cands[i++]; let child; try { child = cp.execFile(py, args, Object.assign({ encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 }, opts), (err, stdout, stderr) => { if (err && err.code === 'ENOENT') return next(); cb(err, stdout, stderr); }); } catch (e) { next(); } };
  next();
}
function envFromItems(text, items) {   // a release's environment variables + queues as the simulated estate
  const env = { environment: {}, queues: {} };
  for (const it of items || []) {
    const xml = text.slice(it.start, it.end);
    if (it.kind === 'environment-variable') { let v = D.attr(/^<[^>]*>/.exec(xml)[0], 'value'); if (v == null || v === '') { const m = /<value>([^<]*)<\/value>/.exec(xml); if (m) v = m[1]; } env.environment[it.name] = D.unx(v || ''); }
    else if (it.kind === 'work-queue') env.queues[it.name] = [];
  }
  return env;
}
function runFlow(cfg, o, cb) {
  try {
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 15), dir = path.join(cfg.projects, '_runs', stamp), xmlDir = path.join(dir, 'xml');
    fs.mkdirSync(xmlDir, { recursive: true });
    const base = safeName(o.base), srcDir = o.rel ? memberDir(cfg, o.rel, base) : path.join(cfg.projects, base), vs = versionsIn(srcDir, base);
    let targetXml = null;
    if (vs.length) targetXml = fs.readFileSync(path.join(srcDir, base + '.v' + vs[vs.length - 1] + '.xml'), 'utf8');
    else if (o.rel) { const j0 = JSON.parse(fs.readFileSync(path.join(relDir(cfg, o.rel), 'index.json'), 'utf8')), m0 = j0.members.find(m => m.base === o.base || safeName(m.base) === base); if (m0) targetXml = R.extract(fs.readFileSync(path.join(relDir(cfg, o.rel), 'release.v1.bprelease'), 'utf8'), m0); }
    if (targetXml == null) return cb(null, { error: 'no saved version of ' + base });
    fs.writeFileSync(path.join(xmlDir, base + '.xml'), targetXml, 'utf8');
    const head = /<process [^>]*>/.exec(targetXml); if (!head) return cb(null, { error: 'not a Blue Prism export' });   // attribute values never hold a raw '>' in an export, however long the narrative
    const name = D.unx(D.attr(head[0], 'name')), isObject = /\btype="object"/i.test(head[0]);
    let env = { environment: {}, credentials: {}, queues: {} };
    try { Object.assign(env, JSON.parse(fs.readFileSync(path.join(internalDir(), 'estate.json'), 'utf8'))); } catch (e) { }
    const dirs = [xmlDir];
    if (o.rel) {   // every other member of the release, as last saved (edited) or straight out of the release
      const j = JSON.parse(fs.readFileSync(path.join(relDir(cfg, o.rel), 'index.json'), 'utf8')), text = fs.readFileSync(path.join(relDir(cfg, o.rel), 'release.v1.bprelease'), 'utf8');
      for (const m of j.members) { if (m.base === base) continue; const md = memberDir(cfg, o.rel, m.base), mv = versionsIn(md, m.base);
        try { if (mv.length) fs.copyFileSync(path.join(md, m.base + '.v' + mv[mv.length - 1] + '.xml'), path.join(xmlDir, safeName(m.base) + '.xml')); else fs.writeFileSync(path.join(xmlDir, safeName(m.base) + '.xml'), R.extract(text, m), 'utf8'); } catch (e) { } }
      const re = envFromItems(text, j.items); Object.assign(env.environment, re.environment); for (const q of Object.keys(re.queues)) if (!env.queues[q]) env.queues[q] = re.queues[q];
    } else {
      for (const po of projectObjects(cfg)) if (po.base !== base) { try { fs.copyFileSync(po.file, path.join(xmlDir, safeName(po.base) + '.xml')); } catch (e) { } }
      for (const w of cfg.with || []) { try { if (fs.statSync(w).isDirectory()) dirs.push(w); else fs.copyFileSync(w, path.join(xmlDir, path.basename(w))); } catch (e) { } }
    }
    dirs.push(internalDir());
    fs.writeFileSync(path.join(dir, 'env.json'), JSON.stringify(env), 'utf8');
    const out = path.join(dir, 'out.json'), args = [libFile('bprun_run.py'), '--xml'].concat(dirs, ['--run', name, '--env', path.join(dir, 'env.json'), '--json', out]);
    if (isObject) { if (!o.action) return cb(null, { error: 'an object runs one action: pick one' }); args.push('--action', o.action); }
    if (o.inputs) args.push('--inputs', JSON.stringify(o.inputs));
    const bp = bpHome(cfg.bp); if (bp) args.push('--bp', bp);
    if (!libFile('bprun_run.py')) return cb(null, { error: 'lib\\bprun_run.py not found next to bluewindow.js' });
    console.log('run ' + name + (o.action ? ' / ' + o.action : '') + ' -> ' + dir);
    pyRun(args, { cwd: dir, timeout: 30 * 60 * 1000 }, (err, stdout, stderr) => {
      let res; try { res = JSON.parse(fs.readFileSync(out, 'utf8')); } catch (e) { return cb(null, { error: 'run did not produce a result: ' + ((err && err.message) || '') + '\n' + String(stdout || '') + String(stderr || '') }); }
      const page = p => p === 'Main' ? 'Main Page' : p, trace = (res.trace || []).map(t => ({ process: t[0], page: page(t[1]), stage: t[2], seq: t[3] }));
      const seen = {}, pathRows = trace.filter(t => { const k = t.process + '|' + t.page + '|' + t.stage; seen[k] = (seen[k] || 0) + 1; return seen[k] <= 3; });
      const th = (res.throws || [])[0];
      const incident = { process: th ? th[0] : name, page: th ? page(th[1]) : (o.action || 'Main Page'), exception: res.exception ? { type: res.exception.type, detail: res.exception.detail, stage: th ? th[2] : res.exception.stage } : null,
                         exception_path: pathRows, stage_log: trace.slice(-400), throws: (res.throws || []).map(t => ({ object: t[0], stage: t[2], type: t[3], detail: t[4] })) };
      cb(null, { ok: !!res.ok, name, action: o.action || null, exception: res.exception || null, stages: res.stages || 0, outputs: res.outputs || {}, skipped: res.skipped || [], host: res.host || null, queues: res.queues || {},
                 log: (res.log || []).slice(-600), stderr: res.stderr || '', incident, dir });
    });
  } catch (e) { cb(null, { error: e.message }); }
}
function serve(cfg) {
  const http = require('http'); cfg = cfg || config();
  fs.mkdirSync(cfg.inbox, { recursive: true }); fs.mkdirSync(cfg.projects, { recursive: true });
  const safe = n => path.basename(String(n || '')).replace(/[<>:"|?*\x00-\x1f]/g, '_');
  const send = (res, code, type, body) => { res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
  const body = req => new Promise((ok, no) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > 1024 * 1024 * 1024) { no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch).toString('utf8'))); req.on('error', no); });
  const pageUrl = r => '/p/' + encodeURIComponent(path.basename(path.dirname(r.htmlFile))) + '/' + encodeURIComponent(path.basename(r.htmlFile));
  const looksBp = t => /<process\b[^>]*\bname=/.test(t.slice(0, 4000)) || /<bpr:release\b|<release\b/.test(t.slice(0, 4000));
  const st = { busy: null, failed: {} };   // failed: name -> { mtime, why }, retried only when the file changes
  const looksBpFile = f => { try { return looksBp(fs.readFileSync(f, 'utf8')); } catch (e) { return false; } };
  const tick = () => {
    if (st.busy) return;
    let files; try { files = fs.readdirSync(cfg.inbox).filter(f => /\.(xml|bprelease)$/i.test(f)).sort(); } catch (e) { return; }
    for (const f of files) {
      const full = path.join(cfg.inbox, f); let m; try { m = fs.statSync(full).mtimeMs; } catch (e) { continue; }
      if (st.failed[f] && st.failed[f].mtime === m) continue;
      if (Date.now() - m < 800) continue;          // still being copied in
      let head = ''; try { const fd = fs.openSync(full, 'r'), b = Buffer.alloc(4000); fs.readSync(fd, b, 0, 4000, 0); fs.closeSync(fd); head = b.toString('utf8'); } catch (e) { continue; }
      if (R.isRelease(head)) {
        st.busy = f;
        setImmediate(() => {
          try { const r = importRelease(cfg, full); if (r.again) { st.failed[f] = { mtime: m, why: 'already imported as "' + r.k + '" (see Releases); the same file, left here untouched' }; console.log('already imported: ' + r.k); } else { delete st.failed[f]; console.log('release imported: ' + r.k); } }
          catch (e) { st.failed[f] = { mtime: m, why: 'release: ' + e.message }; console.log('could not read release ' + f + ': ' + e.message); }
          st.busy = null;
        });
        return;
      }
      if (/\.bprelease$/i.test(f) || !looksBpFile(full)) { st.failed[f] = { mtime: m, why: 'not a Blue Prism process/object export or release' }; continue; }
      st.busy = f;
      setImmediate(() => {
        try { const r = render(full, { out: cfg.projects, with: cfg.with.concat(projectObjects(cfg).map(o => o.file)), bp: cfg.bp }); try { fs.unlinkSync(full); } catch (e) { } delete st.failed[f]; console.log('rendered ' + path.basename(r.xmlFile)); }
        catch (e) { st.failed[f] = { mtime: m, why: e.message }; console.log('could not render ' + f + ': ' + e.message); }
        st.busy = null;
      });
      return;                                       // one at a time; the next tick takes the next file
    }
  };
  const stamp = () => {
    const parts = [st.busy || ''];
    try { for (const f of fs.readdirSync(cfg.inbox).sort()) parts.push('i:' + f + ':' + (st.failed[f] ? 'x' : '')); } catch (e) { }
    try { for (const d of fs.readdirSync(cfg.projects).sort()) { const v = versionsIn(path.join(cfg.projects, d), d); parts.push('p:' + d + ':' + (v[v.length - 1] || 0)); } } catch (e) { }
    try { for (const d of fs.readdirSync(path.join(cfg.projects, '_releases')).sort()) parts.push('r:' + d); } catch (e) { }
    return parts.join('|');
  };
  const timer = setInterval(tick, 700);
  try { for (const k of fs.readdirSync(path.join(cfg.projects, '_releases'))) { upgradeRelease(cfg, k); queueRelease(cfg, k); } } catch (e) { }   // carry on where the last run stopped
  const stale = [];
  try { for (const d of fs.readdirSync(cfg.projects)) { if (d === '_releases') continue; const dir = path.join(cfg.projects, d), vs = versionsIn(dir, d); if (!vs.length) continue;
          const h = path.join(dir, d + '.v' + vs[vs.length - 1] + '.html'); let old = true; try { old = !fs.readFileSync(h, 'utf8').includes('BW_PAGEVER=' + PAGE_VERSION); } catch (e) { }
          if (old) stale.push(path.join(dir, d + '.v' + vs[vs.length - 1] + '.xml')); } } catch (e) { }
  const freshen = () => { const f = stale.shift(); if (!f) return; try { render(f, { out: cfg.projects, with: cfg.with.concat(projectObjects(cfg).map(o => o.file)), bp: cfg.bp }); console.log('refreshed ' + path.basename(f)); } catch (e) { } setTimeout(freshen, 20); };
  if (stale.length) setTimeout(freshen, 500);
  const srv = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://localhost'), q = u.searchParams;
      if (req.method === 'GET' && u.pathname === '/') return send(res, 200, 'text/html; charset=utf-8', home(cfg, null, st));
      if (req.method === 'GET' && u.pathname === '/state') return send(res, 200, 'text/plain', stamp());
      if (req.method === 'POST' && u.pathname === '/upload') {
        const name = safe(q.get('name')); if (!/\.(xml|bprelease)$/i.test(name)) return send(res, 400, 'text/plain', 'only .xml or .bprelease');
        fs.writeFileSync(path.join(cfg.inbox, name), await body(req), 'utf8'); return send(res, 200, 'text/plain', 'ok');
      }
      if (req.method === 'GET' && u.pathname === '/open') {
        const f = path.join(cfg.inbox, safe(q.get('f')));
        if (!fs.existsSync(f)) return send(res, 404, 'text/html; charset=utf-8', home(cfg, 'not in the inbox any more: ' + safe(q.get('f'))));
        if (!looksBp(fs.readFileSync(f, 'utf8'))) return send(res, 400, 'text/html; charset=utf-8', home(cfg, safe(q.get('f')) + ' is not a Blue Prism process/object export'));
        const r = render(f, { out: cfg.projects, with: cfg.with, bp: cfg.bp });
        try { fs.unlinkSync(f); } catch (e) { }   // it now lives in projects\<base>\ as .vN.xml
        console.log('opened ' + path.basename(r.xmlFile));
        res.writeHead(303, { Location: pageUrl(r) }); return res.end();
      }
      if (req.method === 'POST' && u.pathname === '/run') {
        let o = {}; try { o = JSON.parse(await body(req) || '{}'); } catch (e) { }
        o.base = q.get('base'); o.rel = q.get('rel') || null;
        return runFlow(cfg, o, (err, r) => { if (r && r.ok != null) console.log('run ' + r.name + ': ' + (r.ok ? 'finished' : 'failed') + ' after ' + r.stages + ' stages' + (r.skipped.length ? ', ' + r.skipped.length + ' code stages skipped' : '')); send(res, 200, 'application/json', JSON.stringify(r || { error: String(err) })); });
      }
      if (req.method === 'POST' && u.pathname === '/save') {
        const rel = q.get('rel'), base = safe(q.get('base')), dir = rel ? memberDir(cfg, rel, base) : path.join(cfg.projects, base);
        if (!base || !fs.existsSync(dir)) return send(res, 404, 'application/json', JSON.stringify({ error: 'no project ' + base }));
        const xml = await body(req); const have = versionsIn(dir, base); const ver = (have.length ? have[have.length - 1] : 0) + 1;
        const file = path.join(dir, `${base}.v${ver}.xml`); fs.writeFileSync(file, xml, 'utf8');
        const r = rel ? render(file, Object.assign({ out: path.dirname(dir), with: cfg.with, bp: cfg.bp }, releaseStatic(cfg, rel, base)))
                      : render(file, { out: cfg.projects, with: cfg.with.concat(projectObjects(cfg).filter(o => o.base !== base).map(o => o.file)), bp: cfg.bp });
        console.log('saved ' + path.basename(file));
        const url = rel ? '/m/' + encodeURIComponent(rel) + '/' + encodeURIComponent(base) + '/' + encodeURIComponent(path.basename(r.htmlFile)) : pageUrl(r);
        return send(res, 200, 'application/json', JSON.stringify({ url, file, name: path.basename(file) }));
      }
      const rm = /^\/r\/([^/]+)(\/.*)?$/.exec(u.pathname);
      if (rm) {
        const k = decodeURIComponent(rm[1]), sub = rm[2] || '';
        if (!fs.existsSync(path.join(relDir(cfg, k), 'index.json'))) return send(res, 404, 'text/html; charset=utf-8', home(cfg, 'no release ' + k, st));
        if (req.method === 'GET' && (sub === '' || sub === '/')) return send(res, 200, 'text/html; charset=utf-8', releasePage(cfg, k));
        if (req.method === 'GET' && sub === '/open') { res.writeHead(303, { Location: openMember(cfg, k, q.get('id')) }); return res.end(); }
        if (req.method === 'POST' && sub === '/build') { const b = buildRelease(cfg, k, { trim: q.get('trim') === '1' }); if (b.file) console.log('built ' + b.name + (b.members.length ? ' (' + b.members.join(', ') + ')' : '') + (b.trimmed ? ' trimmed to ' + b.trimmed.kept + ' members' : '')); return send(res, 200, 'application/json', JSON.stringify(b)); }
        if (sub === '/item') {
          const dir = relDir(cfg, k), jf = path.join(dir, 'index.json'), j = JSON.parse(fs.readFileSync(jf, 'utf8')), text = fs.readFileSync(path.join(dir, 'release.v1.bprelease'), 'utf8');
          if (req.method === 'GET') {
            const it = q.has('add') ? (j.adds || [])[+q.get('add')] : (j.items || []).find(x => x.start === +q.get('start'));
            if (!it) return send(res, 404, 'text/plain', 'no such item');
            return send(res, 200, 'text/plain; charset=utf-8', it.xml || text.slice(it.start, it.end));
          }
          if (req.method === 'POST') {
            let sp; try { sp = JSON.parse(await body(req)); } catch (e) { return send(res, 400, 'application/json', JSON.stringify({ error: 'bad request' })); }
            try {
              j.adds = j.adds || []; j.drops = j.drops || [];
              if (sp.op === 'add') { if (j.adds.some(a => a.kind === sp.kind && a.name.toLowerCase() === String(sp.name).trim().toLowerCase())) throw new Error('already added'); const it = R.makeItem(text, j, sp); j.adds.push({ kind: sp.kind, name: String(sp.name).trim(), xml: it.xml, verified: it.verified }); }
              else if (sp.op === 'unadd') j.adds.splice(sp.i, 1);
              else if (sp.op === 'drop') { if (!(j.items || []).some(x => x.start === sp.start)) throw new Error('no such item'); if (!j.drops.includes(sp.start)) j.drops.push(sp.start); }
              else if (sp.op === 'undrop') j.drops = j.drops.filter(x => x !== sp.start);
              else throw new Error('unknown op');
              fs.writeFileSync(jf, JSON.stringify(j), 'utf8'); return send(res, 200, 'application/json', JSON.stringify({ ok: true, adds: j.adds.length, drops: j.drops.length }));
            } catch (e) { return send(res, 200, 'application/json', JSON.stringify({ error: e.message })); }
          }
        }
        const fm = /^\/file\/(release\.v\d+\.bprelease)$/.exec(sub);
        if (req.method === 'GET' && fm) { const f = path.join(relDir(cfg, k), fm[1]); if (!fs.existsSync(f)) return send(res, 404, 'text/plain', 'not found'); res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': 'attachment; filename="' + safeName(k) + '.' + fm[1].replace(/^release\./, '') + '"' }); return fs.createReadStream(f).pipe(res); }
        return send(res, 404, 'text/plain', 'not found');
      }
      const mm = /^\/m\/([^/]+)\/([^/]+)\/([^/]+)$/.exec(u.pathname);
      if (req.method === 'GET' && mm) {
        const k = decodeURIComponent(mm[1]), base = safe(decodeURIComponent(mm[2])), f = path.join(memberDir(cfg, k, base), safe(decodeURIComponent(mm[3])));
        if (!fs.existsSync(f) || !/\.html$/i.test(f)) return send(res, 404, 'text/plain', 'not found');
        let members = [], objects = {}, rname = k, problem = null;
        try { const j = JSON.parse(fs.readFileSync(path.join(relDir(cfg, k), 'index.json'), 'utf8')); rname = j.name + (j.from ? ' trimmed' : '');
              const ms = j.members.filter(m => m.type === 'process').concat(j.members.filter(m => m.type === 'object'));
              const murl = m => '/r/' + encodeURIComponent(k) + '/open?id=' + encodeURIComponent(m.id);
              members = ms.map(m => ({ id: m.id, name: m.name, type: m.type, base: m.base, url: murl(m) }));
              for (const m of ms) if (m.type === 'object') { addObjKey(objects, m.name, murl(m)); addObjKey(objects, m.innerName, murl(m)); } }
        catch (e) { problem = 'release index unreadable: ' + e.message; console.log('member page ' + base + ': ' + problem); }
        for (const o of projectObjects(cfg)) addObjKey(objects, o.name, o.url);   // objects opened on their own are reachable too
        const t = injectServe(fs.readFileSync(f, 'utf8'), { base, rel: k, relName: rname, home: '/r/' + encodeURIComponent(k), members, objects, problem });
        return send(res, 200, 'text/html; charset=utf-8', t);
      }
      if (req.method === 'GET' && u.pathname.startsWith('/p/')) {
        const parts = u.pathname.slice(3).split('/').map(decodeURIComponent).map(safe); if (parts.length !== 2) return send(res, 404, 'text/plain', 'not found');
        const f = path.join(cfg.projects, parts[0], parts[1]);
        if (!fs.existsSync(f)) return send(res, 404, 'text/plain', 'not found');
        let t = fs.readFileSync(f, 'utf8');
        if (/\.html$/i.test(f)) { const objects = {}; for (const o of projectObjects(cfg)) if (o.base !== parts[0]) addObjKey(objects, o.name, o.url); t = injectServe(t, { base: parts[0], objects }); }
        return send(res, 200, /\.html$/i.test(f) ? 'text/html; charset=utf-8' : 'text/xml; charset=utf-8', t);
      }
      send(res, 404, 'text/plain', 'not found');
    } catch (e) { send(res, 500, 'text/plain', 'bluewindow: ' + e.message); }
  });
  srv.on('close', () => clearInterval(timer));
  srv.on('error', e => { if (e.code === 'EADDRINUSE') { console.log('port ' + cfg.port + ' busy: bluewindow is probably already running, opening it'); openBrowser('http://localhost:' + cfg.port + '/', cfg); setTimeout(() => process.exit(0), 500); } else throw e; });
  srv.listen(cfg.port, '127.0.0.1', () => {
    const url = 'http://localhost:' + cfg.port + '/';
    console.log('bluewindow on ' + url + '\n  inbox:    ' + cfg.inbox + '\n  projects: ' + cfg.projects + '\n  (keep this window open; Ctrl+C stops it)');
    openBrowser(url, cfg);
  });
  return srv;
}
function openBrowser(url, cfg) {
  if (!cfg.browser) return;
  try {
    if (process.platform === 'win32') cp.spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore' }).unref();
    else cp.spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) { console.log('open ' + url + ' in the browser'); }
}

if (require.main === module) {
  const a = process.argv.slice(2), cmd = a.shift();
  if (cmd === 'appdef' && a[0]) { process.stdout.write(appdefDigest(fs.readFileSync(a[0], 'utf8'), { full: a.includes('--full') })); return; }
  if (!cmd || cmd === 'serve') { const c = config(); const p = a.indexOf('--port'); if (p >= 0) c.port = +a[p + 1]; if (a.includes('--no-browser')) c.browser = false; serve(c); return; }
  const opt = (k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : null; };
  if (cmd === 'render' && a[0]) {
    const withs = [], bps = []; for (let i = 0; i < a.length; i++) { if (a[i] === '--with' && a[i + 1]) withs.push(a[i + 1]); if (a[i] === '--bp' && a[i + 1]) bps.push(a[i + 1]); }
    const r = render(a[0], { out: opt('--out'), incident: opt('--incident'), with: withs, bp: bps });
    if (r.compile) console.log('compile: ' + (r.compile.ran ? (r.compile.ok ? 'ALL COMPILED' : 'COMPILE PROBLEMS\n' + r.compile.text) : r.compile.text));
    console.log('wrote ' + r.htmlFile + ' (v' + r.ver + ')');
    if (r.diff) console.log('diff vs previous: +' + r.diff.added.length + ' -' + r.diff.removed.length + ' ~' + r.diff.changed.length + ' moved ' + r.diff.moved.length + ' renamed ' + r.diff.renamed.length);
    if (r.validation) console.log('validate: ' + (r.validation.ran ? (r.validation.ok ? 'ALL CLEAN' : 'PROBLEMS FOUND\n' + r.validation.text) : r.validation.text));
  } else if (cmd === 'watch' && a[0]) { const withs = [], bps = []; for (let i = 0; i < a.length; i++) { if (a[i] === '--with' && a[i + 1]) withs.push(a[i + 1]); if (a[i] === '--bp' && a[i + 1]) bps.push(a[i + 1]); } watch(a[0], { downloads: opt('--downloads'), with: withs, bp: bps }); }
  else { console.log('usage:\n  node bluewindow.js                (serve: home page in the browser, inbox -> Open, Save writes the next version)\n  node bluewindow.js appdef <object.xml | release.bprelease> [--full]   (Application Modeller digest: launch info, one element per shape, attribute census)\n  node bluewindow.js render <file.xml> [--out <folder>] [--incident <incident.json>] [--with <object exports folder>] [--bp "<Blue Prism install folder>"]\n  node bluewindow.js watch <folder> [--downloads <dir>] [--with <folder>] [--bp "<Blue Prism folder>"]'); process.exit(2); }
}
module.exports = { render, page, validate, compile, baseAndVersion, serve, config, bpHome, libFile, importRelease, buildRelease, openMember };
