#!/usr/bin/env node
// bluewindow: Blue Prism Studio-lite for an export .xml, offline, in the browser, with versions.
//   node bluewindow.js render <file.xml> [--out <folder>] [--incident <incident.json>]
//       -> <folder>/<base>/<base>.vN.xml (copied) + <base>.vN.html (the editor), diff against vN-1,
//          validate.py (strict estate profile) when python + the skill lib are reachable.
//   node bluewindow.js watch <folder> [--downloads <dir>]
//       -> every new <base>.vN.xml dropped in <folder>/<base>/ (or found in --downloads and moved) is rendered.
//   node bluewindow.js            (or: serve)  -> the everyday way: opens the browser on a home page. Drop exports into
//       inbox\ (or onto the page), click Open; Save writes <base>.v(N+1).xml into projects\<base>\ and reopens it with the diff.
// Opened from disk (no server) the editor saves the next version as a download instead.
// Standalone: validate.py + compile_check.py ship in lib\ next to this file; bluewindow.json (optional) holds the settings.
'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process');
const D = require('./bpdraw'), E = require('./bpedit');
const HERE = __dirname;
const SRC = ['bpdraw.js', 'bpedit.js', 'bpui.js'].map(f => fs.readFileSync(path.join(HERE, f), 'utf8'));

// settings: bluewindow.json next to this file, every key optional
//   { "bp": "C:\\Program Files\\Blue Prism Limited\\Blue Prism Automate", "with": ["C:\\exports\\objects"],
//     "inbox": "inbox", "projects": "projects", "port": 7788, "browser": true }
function config() {
  let c = {}; const f = path.join(HERE, 'bluewindow.json');
  if (fs.existsSync(f)) { try { c = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { console.log('bluewindow.json unreadable (' + e.message + '), using defaults'); } }
  const abs = p => path.isAbsolute(p) ? p : path.join(HERE, p);
  return { bp: c.bp ? [c.bp] : [], with: (c.with || []).map(abs), inbox: abs(c.inbox || 'inbox'), projects: abs(c.projects || 'projects'),
           port: c.port || 7788, browser: c.browser !== false };
}
// Blue Prism's install folder (its Roslyn compiler + DLLs make the compile check exact): config, BP_HOME, then the usual places
function bpHome(given) {
  if (given && given.length) return given;
  const c = config().bp; if (c.length) return c;
  if (process.env.BP_HOME) return [process.env.BP_HOME];
  const roots = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)'].filter(Boolean);
  for (const r of roots) for (const sub of ['Blue Prism Limited\\Blue Prism Automate', 'SS&C Blue Prism\\Blue Prism Automate', 'Blue Prism Limited\\Blue Prism']) {
    const d = path.join(r, sub); try { if (fs.existsSync(path.join(d, 'Automate.exe'))) return [d]; } catch (e) { }
  }
  return [];
}
function libFile(name) {
  const cands = [path.join(HERE, 'lib', name), path.join(HERE, '..', '..', 'lib', name), process.env.RPA_BP_SKILL ? path.join(process.env.RPA_BP_SKILL, 'lib', name) : null].filter(Boolean);
  return cands.find(p => fs.existsSync(p)) || null;
}

function baseAndVersion(file) {
  const n = path.basename(file).replace(/\.xml$/i, '');
  const m = /^(.*)\.v(\d+)$/.exec(n);
  return m ? { base: m[1], ver: +m[2] } : { base: n, ver: 0 };
}
function versionsIn(dir, base) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).map(f => /^(.*)\.v(\d+)\.xml$/i.exec(f)).filter(m => m && m[1] === base).map(m => +m[2]).sort((a, b) => a - b);
}
function findValidator() { return libFile('validate.py'); }
function validate(xmlFile) {
  const v = findValidator(); if (!v) return { ran: false, text: 'validate.py not found (expected in lib\\ next to bluewindow.js)' };
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'bw-')); fs.copyFileSync(xmlFile, path.join(tmp, path.basename(xmlFile).replace(/\.v\d+\.xml$/i, '.xml')));
  for (const py of ['python', 'python3', 'py']) {
    try { const r = cp.spawnSync(py, [v, tmp, '--flow', '--estate', '--strict'], { encoding: 'utf8', timeout: 60000 }); if (r.error) continue; return { ran: true, ok: /ALL CLEAN/.test(r.stdout), text: (r.stdout + r.stderr).trim() }; } catch (e) { }
  }
  return { ran: false, text: 'python not found' };
}

function findCompiler() { return libFile('compile_check.py'); }
// objects only: compile every code stage + shared code the way Blue Prism does. bpDirs = Blue Prism install folder(s), where its own
// Roslyn csc.exe and the referenced DLLs live; without one compile_check falls back to a development compiler and says so.
function compile(xmlFile, bpDirs) {
  const xml = fs.readFileSync(xmlFile, 'utf8');
  if (!/<process [^>]*type="object"/.test(xml.slice(0, 2000))) return null;
  if (!/type="Code"/.test(xml)) return { ran: true, ok: true, bp: false, text: 'no code stages in this object' };
  const c = findCompiler(); if (!c) return { ran: false, ok: null, text: 'compile_check.py not found (expected in lib\\ next to bluewindow.js)' };
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'bwc-')); fs.copyFileSync(xmlFile, path.join(tmp, path.basename(xmlFile).replace(/\.v\d+\.xml$/i, '.xml')));
  const args = [c, tmp]; for (const d of bpDirs || []) args.push('--ref-dir', d);
  for (const py of ['python', 'python3', 'py']) {
    try { const r = cp.spawnSync(py, args, { encoding: 'utf8', timeout: 120000 }); if (r.error) continue; const text = (r.stdout + r.stderr).trim(); return { ran: true, ok: /ALL COMPILED/.test(text), bp: /roslyn/i.test(text), text: text.split('\n').filter(l => !/^(C#|VB) compiler:/.test(l) || /roslyn/i.test(l)).join('\n') }; } catch (e) { }
  }
  return { ran: false, ok: null, text: 'python not found' };
}
function page(opts) {
  const { xml, base, ver, diff, incident, validation, compile } = opts; const objects = opts.objects || [];
  const diffJson = diff ? { added: diff.added.map(s => s.name), removed: diff.removed.map(s => s.name), renamed: diff.renamed.map(r => [r[0].name, r[1].name]), changed: diff.changed.map(s => s.name), moved: diff.moved.map(s => s.name), changedIds: [...diff.changedIds] } : null;
  const J = o => JSON.stringify(o).replace(/<\/script/gi, '<\\/script');
  const vlines = t => { const L = String(t).split('\n').filter(l => l.trim() && !/^\s+'/.test(l) && !/^\s*--/.test(l)); const verdict = L.filter(l => /ALL CLEAN|PROBLEMS|FAIL/.test(l)).pop(); return (verdict ? verdict.trim() + '\n' : '') + L.filter(l => l !== verdict).slice(-10).join('\n'); };
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(base)} v${ver} - bluewindow</title><style>
body{margin:0;font-family:Segoe UI,Arial,sans-serif;font-size:13px;display:flex;flex-direction:column;height:100vh;overflow:hidden}
*{scrollbar-width:thin;scrollbar-color:#8a94a0 transparent}body.dark *{scrollbar-color:#3a4458 transparent}
.tb{display:flex;align-items:center;gap:8px;padding:5px 10px;background:#1f2933;color:#eceff1;border-bottom:1px solid #0d141a}
.tb .brand{font-weight:600;letter-spacing:.04em;color:#9fb3c8;font-size:12px}.tb .file{font-size:12px;color:#eceff1}.tb .file em{font-style:normal;color:#9fb3c8;margin-left:6px;font-size:11px}
.tb button{background:transparent;color:#cfd8dc;border:1px solid transparent;border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px;display:inline-flex;align-items:center;gap:6px}.tb button:hover{background:#2c3a47}
.tb .seg{display:inline-flex;border:1px solid #3a4a58;border-radius:5px;overflow:hidden;margin-left:12px}.tb .seg button{border-radius:0;border:none;border-right:1px solid #3a4a58}.tb .seg button:last-child{border-right:none}
.tb button.on{background:#2f5f9e;color:#fff}.tb button:disabled{opacity:.35;cursor:default}.tb button.primary{background:#2e7d32;color:#fff;border-color:#2e7d32}.tb button.primary:disabled{background:#3a4a58;border-color:#3a4a58;opacity:.6}
.tb kbd{font:10px/1 Consolas,monospace;color:#9fb3c8;background:rgba(255,255,255,.08);border-radius:3px;padding:2px 4px}.tb button.on kbd{color:#dbe6fb}.tb .sp{flex:1}
#dot{width:8px;height:8px;border-radius:50%;background:#9e9e9e;display:inline-block}#checks.good #dot{background:#66bb6a}#checks.meh #dot{background:#ffca28}#checks.bad #dot{background:#ef5350}
#help{position:fixed;right:12px;top:44px;z-index:5;background:#fff;border:1px solid #bbb;border-radius:6px;padding:10px 12px;box-shadow:0 6px 24px rgba(0,0,0,.3);font-size:12px;max-width:520px}#help table{border-collapse:collapse;margin:6px 0}#help td{padding:2px 8px 2px 0;vertical-align:top}#help td:first-child{font:11px Consolas,monospace;white-space:nowrap;color:#1565c0}#help button{margin-top:4px}
.band{fill:#2f5f9e;fill-opacity:.12;stroke:#2f5f9e;stroke-dasharray:3,2}.rsz{fill:#fff;stroke:#2f5f9e;cursor:nwse-resize}
#diff{background:#fff8e1;border-bottom:1px solid #ffe082;padding:4px 10px;font-size:12px}
#checkpanel{background:#fff;border-bottom:1px solid #ddd;max-height:40vh;overflow:auto;font-size:12px;display:flex}#checkpanel[hidden]{display:none}#checkpanel .ck{flex:1;padding:6px 10px;min-width:0}#checkpanel .ck+.ck{border-left:1px solid #ddd}
#rules{list-style:none;margin:4px 0 0;padding:0}#rules li{padding:1px 0}#rules li.error{color:#c62828}#rules li.warn{color:#ef6c00}#rules li.ok{color:#2e7d32}
#valid,#compile{margin:4px 0 0;white-space:pre-wrap;font:11px Consolas,monospace;color:#2e7d32}#valid.bad,#compile.bad{color:#c62828}
svg .grid{display:none}body.grid svg .grid{display:block}svg .gdot{fill:var(--griddot)}svg .bg{fill:var(--bg)}
.row{display:flex;flex:1;min-height:0}nav{width:240px;min-width:180px;overflow:auto;border-right:1px solid #ddd;background:#f6f6f6}
nav h1{font-size:12px;margin:8px;color:#333;word-break:break-word}nav input{width:calc(100% - 16px);margin:8px 8px 6px;box-sizing:border-box}nav ul{list-style:none;margin:0;padding:0}
nav li{padding:7px 10px;border-bottom:1px solid #e5e5e5;cursor:pointer}.navh{display:flex;align-items:center;gap:6px;padding:8px 10px 4px;font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.04em}.navh .muted{text-transform:none;letter-spacing:0;font-size:11px}.navh button.nm{margin-left:4px}.navh button{margin-left:auto;font-size:11px;padding:1px 7px;border:1px solid #bbb;border-radius:3px;background:#fff;cursor:pointer}
#palette{display:flex;flex-wrap:wrap;gap:4px;padding:2px 10px 8px}#palette button{font-size:11px;padding:3px 8px;border:1px solid #ccc;border-radius:3px;background:#fff;cursor:pointer}#palette button.on{background:#2f5f9e;color:#fff;border-color:#2f5f9e}body.placing svg{cursor:crosshair}nav li:hover{background:#e8f0fe}nav li.on{background:#dbe6fb;font-weight:600}
main{flex:1;overflow:auto;padding:0;position:relative}main h2{font-size:12px;margin:0;padding:6px 10px;color:#444;position:sticky;top:0;left:0;z-index:2}svg{display:block;border:none;background:#fafafa;transform-origin:0 0;user-select:none}
g.st.on rect,g.st.on polygon,g.st.on circle,g.blk.on rect{filter:drop-shadow(0 0 4px #1565c0)}
aside#sheet{width:400px;min-width:320px;border-left:1px solid #ddd;background:#fff;overflow:auto;font-size:12px}
aside .sh{position:sticky;top:0;background:#e8f0fe;padding:8px 10px;border-bottom:1px solid #c5d3ea;display:flex;align-items:center;gap:8px;z-index:1}
aside .sh span{font-size:10px;color:#fff;background:#1565c0;border-radius:3px;padding:1px 5px}aside .sh b{flex:1;word-break:break-word}aside .sh button{border:none;background:none;font-size:18px;cursor:pointer;color:#555}
#sh-body{padding:8px 10px}#sh-body h4{margin:12px 0 4px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid #eee}
#sh-body dl{margin:0;display:grid;grid-template-columns:100px 1fr;gap:4px 8px;align-items:center}#sh-body dt{color:#666}#sh-body dd{margin:0;word-break:break-word;font-family:Consolas,monospace;font-size:11px}
#sh-body input,#sh-body select,#sh-body textarea{width:100%;box-sizing:border-box;font-family:Consolas,monospace;font-size:11px;border:1px solid #ccc;border-radius:2px;padding:3px}#sh-body textarea{min-height:48px}#sh-body textarea.code{min-height:200px}
#sh-body table{border-collapse:collapse;width:100%;font-size:11px}#sh-body th{text-align:left;background:#f3f3f3;padding:3px 4px;border:1px solid #e3e3e3}#sh-body td{padding:2px 3px;border:1px solid #e3e3e3;vertical-align:top;font-family:Consolas,monospace}
.apply button{background:#1565c0;color:#fff;border:none;border-radius:3px;padding:5px 12px;cursor:pointer}.muted{color:#888}
.zoom{position:fixed;left:250px;bottom:10px;display:flex;gap:4px}.zoom button{background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:4px;padding:3px 9px;cursor:pointer;opacity:.85}#toast{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);background:#263238;color:#fff;padding:6px 12px;border-radius:4px;font-size:12px}
#yesno{position:fixed;left:50%;top:40%;transform:translateX(-50%);background:#fff;border:1px solid #999;border-radius:4px;padding:12px;box-shadow:0 4px 16px rgba(0,0,0,.25)}#yesno button{margin:0 6px;padding:4px 14px}

/* ---- theme: the canvas and the chrome. Light = Studio-like paper. Dark = default, ink on slate. ---- */
:root{--griddot:#c9ced6;--bg:#f4f5f7;--panel:#ffffff;--panel2:#f6f6f6;--line:#dddddd;--ink:#222;--muted:#666;--accent:#1565c0;--sel:#dbe6fb;--hover:#e8f0fe;--canvas:#fafafa;--canvasline:#dddddd}
body.dark{--griddot:#34405a;--bg:#0f1217;--panel:#161a22;--panel2:#12151c;--line:#232a36;--ink:#d6dbe6;--muted:#8b94a7;--accent:#7aa2f7;--sel:#1f2a44;--hover:#1a2230;--canvas:#141821;--canvasline:#232a36}
body{background:var(--bg);color:var(--ink)}nav{background:var(--panel2);border-color:var(--line)}nav h1{color:var(--ink)}nav li{border-color:var(--line)}nav li:hover{background:var(--hover)}nav li.on{background:var(--sel)}
nav input,#sh-body input,#sh-body select,#sh-body textarea{background:var(--panel);color:var(--ink);border-color:var(--line)}
main h2{color:var(--muted);background:var(--bg)}svg{background-color:var(--bg)}
aside#sheet{background:var(--panel);border-color:var(--line);color:var(--ink)}body.dark aside .sh{background:#1b2436;border-color:#2a3650}body.dark aside .sh button{color:#aab}
#sh-body h4{color:var(--muted);border-color:var(--line)}#sh-body dt{color:var(--muted)}#sh-body th{background:var(--panel2);border-color:var(--line)}#sh-body td{border-color:var(--line)}
body.dark .tb{background:#0c0f14;border-color:#000}body.dark #status{background:var(--panel2);border-color:var(--line);color:var(--muted)}body.dark #checkpanel{background:var(--panel);border-color:var(--line)}body.dark #checkpanel .ck+.ck{border-color:var(--line)}body.dark #diff{background:#2a2410;border-color:#4a3e14;color:#e0c070}body.dark #valid,body.dark #compile{color:#a5d6a7}body.dark #valid.bad,body.dark #compile.bad{color:#ef9a9a}body.dark svg .infor{fill:#171c27;stroke:#3a4a6b}body.dark svg .infoh{fill:#2b3f66}body.dark svg .infot{fill:#dbe6fb}body.dark svg .infod{fill:#aab3c5}body.dark #rules li.ok{color:#9ece6a}body.dark #rules li.error{color:#f7768e}body.dark #rules li.warn{color:#e0af68}
body.dark #help{background:var(--panel);color:var(--ink);border-color:var(--line)}body.dark #help td:first-child{color:#7aa2f7}body.dark .rsz{fill:#1b2029}
body.dark .navh{color:var(--muted)}body.dark .navh button,body.dark #palette button{background:var(--panel);color:var(--ink);border-color:var(--line)}body.dark #palette button.on{background:#2f5f9e;color:#fff}
body.dark .zoom button,body.dark #yesno{background:var(--panel);color:var(--ink);border:1px solid var(--line)}
/* ---- theme: the drawing. Fills and strokes per stage type; the SVG attributes are the light fallback. ---- */
body.dark svg .lbl{fill:#d6dbe6}body.dark svg .lbl.fail{fill:#fff}body.dark svg .anchor{fill:#8b94a7}
body.dark svg .lnk{stroke:#8089a0}body.dark svg .lnk.yes{stroke:#9ece6a}body.dark svg .lnk.no{stroke:#f7768e}body.dark svg .lnk.loop{stroke:#bb9af7}body.dark svg .lnk.red{stroke:#ff5a72}
body.dark svg .lab{fill:#8089a0}body.dark svg .lab.yes{fill:#9ece6a}body.dark svg .lab.no{fill:#f7768e}body.dark svg .grp{stroke:#4b5366}
body.dark svg marker#arr path{fill:#8089a0}body.dark svg marker#arrR path{fill:#ff5a72}
body.dark svg .blkr{fill:#7aa2f7;fill-opacity:.06;stroke:#3b4a6b}body.dark svg .blkt{fill:#7aa2f7}body.dark svg .cpt{fill:#e0af68;stroke:#8a6d3b}body.dark svg .cptl{fill:#8b94a7}
body.dark svg .val{fill:#7dcfff}body.dark svg .seq{fill:#5c6680}body.dark svg .inner{stroke:#8b94a7}
body.dark svg .shape{fill:#1b2029;stroke:#8d97ab;stroke-width:1.1}body.dark svg .deco{stroke:#8d97ab}body.dark svg .glyph{fill:#8d97ab}
body.dark svg .t-Start{stroke:#9ece6a}body.dark svg .t-End{stroke:#f7768e}
body.dark svg .t-Decision,body.dark svg .t-ChoiceStart{fill:#221e14;stroke:#e0af68}
body.dark svg .t-Exception{fill:#2a1a1e;stroke:#f7768e;stroke-width:1.8}
body.dark svg .t-Data,body.dark svg .t-Collection{fill:#151920;stroke:#5a6478}
body.dark svg .t-Note{fill:#26231a;stroke:#9a8a4a}
body.dark svg .t-Recover,body.dark svg .t-Resume{fill:#1d1a2e;stroke:#bb9af7}
body.dark svg .shape.changed{stroke:#ff9e64;stroke-width:2}body.dark svg .shape.path{stroke:#ff5a72;stroke-width:2}
body.dark svg .shape.fail{fill:#c23b4e;stroke:#ff8a9c;stroke-width:3}
body.dark g.st.on rect,body.dark g.st.on polygon,body.dark g.st.on circle,body.dark g.blk.on rect{filter:drop-shadow(0 0 5px #7aa2f7)}
</style></head><body>
<div class="tb"><span class="brand">bluewindow</span><span class="file">${esc(base)}<em>v${ver}</em></span>
<span class="seg"><button data-mode="select" onclick="setMode('select')" title="V">Select<kbd>V</kbd></button><button data-mode="link" onclick="setMode('link')" title="L">Link<kbd>L</kbd></button><button data-mode="delete" onclick="setMode('delete')" title="D">Delete<kbd>D</kbd></button></span>
<span class="sp"></span>
<button id="checks" onclick="toggleChecks()" title="live rules + the full check from render time"><i id="dot"></i><span id="rulecount"></span></button>${diff ? '<button onclick="toggleDiff()" title="what changed since v' + (ver - 1) + '">diff</button>' : ''}
<button id="gridb" onclick="toggleGrid()" title="G: snap to the 15px Studio grid">grid</button><button id="helpb" onclick="toggleHelp()" title="keys and how-to">?</button><button onclick="copyXml()" title="copy the current XML">Copy</button><button id="save" class="primary" onclick="saveXml()">Save v${ver + 1}</button></div>
${diff ? '<div id="diff"></div>' : '<div id="diff" hidden></div>'}
<div id="checkpanel" hidden><div class="ck"><b>While you edit</b> <span class="muted">(the browser checks the estate rules after every change; errors block Save)</span><ul id="rules"></ul></div>
${compile ? `<div class="ck"><b>Code stages compile?</b> <span class="muted">(compile_check.py${compile.ran ? ', ' + (compile.bp ? "Blue Prism's own compiler" : 'a development compiler, indicative only: pass --bp "<Blue Prism folder>" for the real one') : ' was not found'})</span><pre id="compile" class="${compile.ok ? '' : 'bad'}">${esc(compile.text)}</pre></div>` : ''}
${validation ? `<div class="ck"><b>Full check of this version</b> <span class="muted">(validate.py --flow --estate --strict, the same gate the skill uses, ran when this page was made${validation.ran ? '' : ' - it was not found'})</span><pre id="valid" class="${validation.ok ? '' : 'bad'}">${esc(vlines(validation.text))}</pre></div>` : ''}</div>
<div class="row"><nav><input id="q" placeholder="find a stage (Enter)"><div class="navh">Pages <button onclick="addPage()" title="add a page">+ page</button><button onclick="removePage()" title="remove the open page" class="nm">&minus; page</button></div><ul id="pages"></ul><div class="navh">Add a stage</div><div id="palette"></div>${objects.length ? `<div class="navh">Objects known <span class="muted">${objects.map(o => esc(o.object)).join(', ')}</span></div>` : ''}</nav><main id="panes"></main>
<aside id="sheet" hidden><div class="sh"><span id="sh-type"></span><b id="sh-name"></b><button onclick="closeSheet()" title="close">&times;</button></div><div id="sh-body"></div></aside></div>
<div class="zoom"><button onclick="z(1.25)" title="Ctrl+wheel zooms too">+</button> <button onclick="z(0.8)">&minus;</button></div>
<div id="help" hidden><b>bluewindow</b><table>
<tr><td>drag</td><td>move a stage; a Block takes what is inside it</td></tr><tr><td>drag on empty space</td><td>select many; Shift+click adds one; then drag or Del</td></tr>
<tr><td>corner handle</td><td>resize a Block or Note</td></tr><tr><td>click</td><td>open the properties sheet; Enter in a field applies</td></tr>
<tr><td>V / L / D</td><td>Select, Link, Delete mode; in Link click the source then the target</td></tr><tr><td>A</td><td>place an Action; the palette on the left has every other kind</td></tr>
<tr><td>Del</td><td>remove the selected stage(s); a loop or wait pair goes together</td></tr><tr><td>Ctrl+Z</td><td>undo, up to 50 steps</td></tr><tr><td>Esc</td><td>cancel placing or linking, close the sheet</td></tr>
<tr><td>G</td><td>grid on/off: Studio's 15px grid, moves snap to it (off = free placement; Blue Prism imports either)</td></tr><tr><td>Shift+L</td><td>light: Blue Prism Studio's own shapes and colours; dark is the default</td></tr><tr><td>Ctrl+wheel</td><td>zoom (the +/&minus; buttons do the same)</td></tr><tr><td>Checks</td><td>live rules (errors block Save), the validate.py verdict, and for an object whether its code stages compile</td></tr><tr><td>Save</td><td>downloads the next version; render it and the diff ribbon shows what changed</td></tr>
</table><button onclick="toggleHelp()">close</button></div><div id="toast" hidden></div><div id="yesno" hidden>Decision link: <button class="y">Yes</button><button class="n">No</button></div>
<script>(function(){var t='dark',g='1';try{t=localStorage.getItem('bluewindow:theme')||'dark';g=localStorage.getItem('bluewindow:grid')||'1'}catch(e){}if(t==='dark')document.body.classList.add('dark');if(g==='1')document.body.classList.add('grid')})();</script>
<script>var BW_XML=${J(xml)},BW_BASE=${J(base)},BW_VER=${ver},BW_DIFF=${J(diffJson)},BW_INCIDENT=${J(incident || null)},BW_OBJECTS=${J(objects)},BW_STATIC=${J({ validate: validation ? validation.ok : null, compile: compile && compile.ran ? compile.ok : null })};</script>
<script>${SRC[0].replace(/<\/script/gi, '<\\/script')}</script>
<script>${SRC[1].replace(/<\/script/gi, '<\\/script')}</script>
<script>${SRC[2].replace(/<\/script/gi, '<\\/script')}</script>
</body></html>`;
}

// the action catalog: every object export found next to the file, in the out folder, or in --with folders/files
function catalog(places, self) {
  const files = new Set();
  for (const p of places) {
    if (!p || !fs.existsSync(p)) continue;
    if (fs.statSync(p).isFile()) { files.add(path.resolve(p)); continue; }
    for (const f of fs.readdirSync(p)) if (/\.xml$/i.test(f) && path.resolve(p, f) !== path.resolve(self)) files.add(path.resolve(p, f));
  }
  const xmls = [];
  for (const f of files) { try { const t = fs.readFileSync(f, 'utf8'); if (/<process [^>]*type="object"/.test(t.slice(0, 2000))) xmls.push(t); } catch (e) { } }
  return E.catalogFrom(xmls);
}
function render(file, opts) {
  opts = opts || {};
  const { base, ver: fileVer } = baseAndVersion(file);
  const outRoot = opts.out || path.dirname(file), dir = path.join(outRoot, base);
  fs.mkdirSync(dir, { recursive: true });
  const have = versionsIn(dir, base);
  let ver = fileVer;
  const inPlace = path.resolve(path.dirname(file)) === path.resolve(dir) && fileVer > 0;
  if (!inPlace) { ver = (have.length ? have[have.length - 1] : 0) + 1; fs.copyFileSync(file, path.join(dir, `${base}.v${ver}.xml`)); }
  const xmlFile = path.join(dir, `${base}.v${ver}.xml`);
  const xml = fs.readFileSync(xmlFile, 'utf8');
  const prevVer = versionsIn(dir, base).filter(v => v < ver).pop();
  let diff = null;
  if (prevVer) { try { diff = E.diff(D.parseBp(fs.readFileSync(path.join(dir, `${base}.v${prevVer}.xml`), 'utf8')), D.parseBp(xml)); } catch (e) { diff = null; } }
  const incident = opts.incident ? JSON.parse(fs.readFileSync(opts.incident, 'utf8')) : null;
  const validation = opts.validate === false ? null : validate(xmlFile);
  const objects = catalog([path.dirname(file), outRoot].concat(opts.with || [], config().with), xmlFile);
  const compiled = opts.validate === false ? null : compile(xmlFile, bpHome(opts.bp));
  const html = page({ xml, base, ver, diff, incident, validation, objects, compile: compiled });
  const htmlFile = path.join(dir, `${base}.v${ver}.html`);
  fs.writeFileSync(htmlFile, html, 'utf8');
  return { htmlFile, xmlFile, ver, diff, validation, objects, compile: compiled };
}

function watch(folder, opts) {
  const seen = new Set();
  const scan = () => {
    // downloads: the editor saves <base>.vN.xml there; move it next to its siblings
    if (opts.downloads && fs.existsSync(opts.downloads)) for (const f of fs.readdirSync(opts.downloads)) {
      const m = /^(.*)\.v(\d+)\.xml$/i.exec(f); if (!m) continue;
      const dir = path.join(folder, m[1]); if (!fs.existsSync(dir)) continue;
      const dst = path.join(dir, f); if (fs.existsSync(dst)) continue;
      try { fs.renameSync(path.join(opts.downloads, f), dst); console.log('moved ' + f + ' -> ' + dir); } catch (e) { try { fs.copyFileSync(path.join(opts.downloads, f), dst); fs.unlinkSync(path.join(opts.downloads, f)); } catch (e2) { } }
    }
    for (const d of fs.readdirSync(folder)) {
      const dir = path.join(folder, d); if (!fs.statSync(dir).isDirectory()) continue;
      for (const f of fs.readdirSync(dir)) {
        const m = /^(.*)\.v(\d+)\.xml$/i.exec(f); if (!m || m[1] !== d) continue;
        const html = path.join(dir, f.replace(/\.xml$/i, '.html'));
        if (fs.existsSync(html) || seen.has(path.join(dir, f))) continue;
        seen.add(path.join(dir, f));
        try { const r = render(path.join(dir, f), { out: folder, with: opts.with, bp: opts.bp }); console.log('rendered ' + path.basename(r.htmlFile) + (r.validation && r.validation.ran ? (r.validation.ok ? '  validate: ALL CLEAN' : '  validate: PROBLEMS') : '') + (r.compile && r.compile.ran ? (r.compile.ok ? '  compile: OK' : '  compile: PROBLEMS') : '')); }
        catch (e) { console.log('render failed for ' + f + ': ' + e.message); }
      }
    }
  };
  console.log('bluewindow watching ' + folder + (opts.downloads ? ' and ' + opts.downloads : '') + ' (Ctrl+C to stop)');
  scan(); setInterval(scan, 2000);
}

// ---------------- serve: inbox -> click -> page; Save -> next version on disk ----------------
function home(cfg, msg) {
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const inbox = fs.existsSync(cfg.inbox) ? fs.readdirSync(cfg.inbox).filter(f => /\.xml$/i.test(f)).sort() : [];
  const projects = fs.existsSync(cfg.projects) ? fs.readdirSync(cfg.projects).filter(d => { try { return fs.statSync(path.join(cfg.projects, d)).isDirectory(); } catch (e) { return false; } }) : [];
  const rows = projects.map(d => {
    const vs = versionsIn(path.join(cfg.projects, d), d), last = vs[vs.length - 1]; if (!last) return null;
    const t = fs.statSync(path.join(cfg.projects, d, `${d}.v${last}.xml`)).mtime;
    return { d, vs, last, t };
  }).filter(Boolean).sort((a, b) => b.t - a.t);
  const bp = bpHome([]);
  return `<!doctype html><html><head><meta charset="utf-8"><title>bluewindow</title><style>
:root{--bg:#14161b;--panel:#1c1f26;--line:#2c313c;--text:#d9dde6;--muted:#8a93a6;--acc:#4f8cff;--bad:#e5484d}
body{margin:0;background:var(--bg);color:var(--text);font:14px/1.45 system-ui,Segoe UI,sans-serif}
main{max-width:860px;margin:0 auto;padding:28px 16px}h1{font-size:20px;margin:0 0 4px}h1 b{color:var(--acc)}
.muted{color:var(--muted)}section{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px 16px;margin:16px 0}
h2{font-size:14px;margin:0 0 10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.row{display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid var(--line)}.row:first-of-type{border-top:0}
.row .n{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
a.btn,button{background:var(--acc);color:#fff;border:0;border-radius:6px;padding:5px 12px;font:inherit;cursor:pointer;text-decoration:none}
a.ghost{background:transparent;color:var(--muted);padding:2px 4px}a.ghost:hover{color:var(--text)}
#drop{border:2px dashed var(--line);border-radius:8px;padding:18px;text-align:center;color:var(--muted)}#drop.on{border-color:var(--acc);color:var(--text)}
.msg{background:#2a1f12;border:1px solid #6b4a1c;border-radius:6px;padding:8px 12px}code{background:#0f1115;padding:1px 5px;border-radius:4px}
</style></head><body><main>
<h1><b>blue</b>window</h1><div class="muted">compile check: ${bp.length ? "Blue Prism's own compiler (" + esc(bp[0]) + ')' : 'Blue Prism folder not found, development compiler (set "bp" in bluewindow.json)'}</div>
${msg ? `<p class="msg">${esc(msg)}</p>` : ''}
<section><h2>Inbox</h2><div id="drop">drop Blue Prism exports (.xml) here, or put them in <code>${esc(cfg.inbox)}</code></div>
${inbox.length ? inbox.map(f => `<div class="row"><span class="n">${esc(f)}</span><a class="btn" href="/open?f=${encodeURIComponent(f)}">Open</a></div>`).join('') : '<div class="muted" style="padding-top:8px">empty</div>'}</section>
<section><h2>Projects</h2>${rows.length ? rows.map(r => `<div class="row"><span class="n">${esc(r.d)} <span class="muted">v${r.last} · ${r.t.getFullYear()}-${String(r.t.getMonth() + 1).padStart(2, '0')}-${String(r.t.getDate()).padStart(2, '0')} ${String(r.t.getHours()).padStart(2, '0')}:${String(r.t.getMinutes()).padStart(2, '0')}</span></span>
${r.vs.slice(-6, -1).map(v => `<a class="ghost" href="/p/${encodeURIComponent(r.d)}/${encodeURIComponent(r.d)}.v${v}.html">v${v}</a>`).join('')}
<a class="btn" href="/p/${encodeURIComponent(r.d)}/${encodeURIComponent(r.d)}.v${r.last}.html">Open v${r.last}</a></div>`).join('') : '<div class="muted">none yet</div>'}
<div class="muted" style="margin-top:10px">files: <code>${esc(cfg.projects)}</code> (import the .vN.xml from there into Blue Prism)</div></section>
</main><script>
var d=document.getElementById('drop');
['dragenter','dragover'].forEach(function(e){document.addEventListener(e,function(ev){ev.preventDefault();d.classList.add('on');});});
document.addEventListener('dragleave',function(){d.classList.remove('on');});
document.addEventListener('drop',function(ev){ev.preventDefault();d.classList.remove('on');var fs=[].slice.call(ev.dataTransfer.files).filter(function(f){return /\\.xml$/i.test(f.name);});
 if(!fs.length){alert('only .xml exports');return;}
 Promise.all(fs.map(function(f){return f.text().then(function(t){return fetch('/upload?name='+encodeURIComponent(f.name),{method:'POST',body:t});});})).then(function(){
  if(fs.length===1)location.href='/open?f='+encodeURIComponent(fs[0].name);else location.reload();});});
</script></body></html>`;
}
function serve(cfg) {
  const http = require('http'); cfg = cfg || config();
  fs.mkdirSync(cfg.inbox, { recursive: true }); fs.mkdirSync(cfg.projects, { recursive: true });
  const safe = n => path.basename(String(n || '')).replace(/[<>:"|?*\x00-\x1f]/g, '_');
  const send = (res, code, type, body) => { res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(body); };
  const body = req => new Promise((ok, no) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > 64 * 1024 * 1024) { no(new Error('too big')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch).toString('utf8'))); req.on('error', no); });
  const pageUrl = r => '/p/' + encodeURIComponent(path.basename(path.dirname(r.htmlFile))) + '/' + encodeURIComponent(path.basename(r.htmlFile));
  const looksBp = t => /<process\b[^>]*\bname=/.test(t.slice(0, 4000)) || /<bpr:release\b|<release\b/.test(t.slice(0, 4000));
  const srv = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://localhost'), q = u.searchParams;
      if (req.method === 'GET' && u.pathname === '/') return send(res, 200, 'text/html; charset=utf-8', home(cfg));
      if (req.method === 'POST' && u.pathname === '/upload') {
        const name = safe(q.get('name')); if (!/\.xml$/i.test(name)) return send(res, 400, 'text/plain', 'only .xml');
        fs.writeFileSync(path.join(cfg.inbox, name), await body(req), 'utf8'); return send(res, 200, 'text/plain', 'ok');
      }
      if (req.method === 'GET' && u.pathname === '/open') {
        const f = path.join(cfg.inbox, safe(q.get('f')));
        if (!fs.existsSync(f)) return send(res, 404, 'text/html; charset=utf-8', home(cfg, 'not in the inbox any more: ' + safe(q.get('f'))));
        if (!looksBp(fs.readFileSync(f, 'utf8'))) return send(res, 400, 'text/html; charset=utf-8', home(cfg, safe(q.get('f')) + ' is not a Blue Prism process/object export'));
        const r = render(f, { out: cfg.projects, with: cfg.with, bp: cfg.bp });
        try { fs.unlinkSync(f); } catch (e) { }   // it now lives in projects\<base>\ as .vN.xml
        console.log('opened ' + path.basename(r.xmlFile));
        res.writeHead(303, { Location: pageUrl(r) }); return res.end();
      }
      if (req.method === 'POST' && u.pathname === '/save') {
        const base = safe(q.get('base')), dir = path.join(cfg.projects, base);
        if (!base || !fs.existsSync(dir)) return send(res, 404, 'application/json', JSON.stringify({ error: 'no project ' + base }));
        const xml = await body(req); const have = versionsIn(dir, base); const ver = (have.length ? have[have.length - 1] : 0) + 1;
        const file = path.join(dir, `${base}.v${ver}.xml`); fs.writeFileSync(file, xml, 'utf8');
        const r = render(file, { out: cfg.projects, with: cfg.with, bp: cfg.bp });
        console.log('saved ' + path.basename(file));
        return send(res, 200, 'application/json', JSON.stringify({ url: pageUrl(r), file, name: path.basename(file) }));
      }
      if (req.method === 'GET' && u.pathname.startsWith('/p/')) {
        const parts = u.pathname.slice(3).split('/').map(decodeURIComponent).map(safe); if (parts.length !== 2) return send(res, 404, 'text/plain', 'not found');
        const f = path.join(cfg.projects, parts[0], parts[1]);
        if (!fs.existsSync(f)) return send(res, 404, 'text/plain', 'not found');
        let t = fs.readFileSync(f, 'utf8');
        if (/\.html$/i.test(f)) t = t.replace(/<head>/i, '<head><script>window.BW_SERVE=' + JSON.stringify({ base: parts[0] }) + '</script>');
        return send(res, 200, /\.html$/i.test(f) ? 'text/html; charset=utf-8' : 'text/xml; charset=utf-8', t);
      }
      send(res, 404, 'text/plain', 'not found');
    } catch (e) { send(res, 500, 'text/plain', 'bluewindow: ' + e.message); }
  });
  srv.on('error', e => { if (e.code === 'EADDRINUSE') { console.log('port ' + cfg.port + ' busy: bluewindow is probably already running, opening it'); openBrowser('http://localhost:' + cfg.port + '/', cfg); setTimeout(() => process.exit(0), 500); } else throw e; });
  srv.listen(cfg.port, '127.0.0.1', () => {
    const url = 'http://localhost:' + cfg.port + '/';
    console.log('bluewindow on ' + url + '\n  inbox:    ' + cfg.inbox + '\n  projects: ' + cfg.projects + '\n  (keep this window open; Ctrl+C stops it)');
    openBrowser(url, cfg);
  });
  return srv;
}
function openBrowser(url, cfg) {
  if (!cfg.browser) return;
  try {
    if (process.platform === 'win32') cp.spawn('cmd', ['/c', 'start', '', url], { detached: true, stdio: 'ignore' }).unref();
    else cp.spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) { console.log('open ' + url + ' in the browser'); }
}

if (require.main === module) {
  const a = process.argv.slice(2), cmd = a.shift();
  if (!cmd || cmd === 'serve') { const c = config(); const p = a.indexOf('--port'); if (p >= 0) c.port = +a[p + 1]; if (a.includes('--no-browser')) c.browser = false; serve(c); return; }
  const opt = (k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : null; };
  if (cmd === 'render' && a[0]) {
    const withs = [], bps = []; for (let i = 0; i < a.length; i++) { if (a[i] === '--with' && a[i + 1]) withs.push(a[i + 1]); if (a[i] === '--bp' && a[i + 1]) bps.push(a[i + 1]); }
    const r = render(a[0], { out: opt('--out'), incident: opt('--incident'), with: withs, bp: bps });
    if (r.compile) console.log('compile: ' + (r.compile.ran ? (r.compile.ok ? 'ALL COMPILED' : 'COMPILE PROBLEMS\n' + r.compile.text) : r.compile.text));
    console.log('wrote ' + r.htmlFile + ' (v' + r.ver + ')');
    if (r.diff) console.log('diff vs previous: +' + r.diff.added.length + ' -' + r.diff.removed.length + ' ~' + r.diff.changed.length + ' moved ' + r.diff.moved.length + ' renamed ' + r.diff.renamed.length);
    if (r.validation) console.log('validate: ' + (r.validation.ran ? (r.validation.ok ? 'ALL CLEAN' : 'PROBLEMS FOUND\n' + r.validation.text) : r.validation.text));
  } else if (cmd === 'watch' && a[0]) { const withs = [], bps = []; for (let i = 0; i < a.length; i++) { if (a[i] === '--with' && a[i + 1]) withs.push(a[i + 1]); if (a[i] === '--bp' && a[i + 1]) bps.push(a[i + 1]); } watch(a[0], { downloads: opt('--downloads'), with: withs, bp: bps }); }
  else { console.log('usage:\n  node bluewindow.js                (serve: home page in the browser, inbox -> Open, Save writes the next version)\n  node bluewindow.js render <file.xml> [--out <folder>] [--incident <incident.json>] [--with <object exports folder>] [--bp "<Blue Prism install folder>"]\n  node bluewindow.js watch <folder> [--downloads <dir>] [--with <folder>] [--bp "<Blue Prism folder>"]'); process.exit(2); }
}
module.exports = { render, page, validate, compile, baseAndVersion, serve, config, bpHome, libFile };
