// bprelease: read and rebuild a Blue Prism .bprelease without parsing it as one XML document.
// Shape (7.2.1, seen on the estate 2026-11-10):
//   <?xml ...?><bpr:release xmlns:bpr="http://www.blueprism.co.uk/product/release"> <bpr:name>..</bpr:name> ... metadata ...
//   <bpr:contents count="N">
//     <process id=".." name=".." published=".." xmlns="http://www.blueprism.co.uk/product/process"><process name=".." ...>...</process></process>
//     <object  id=".." name=".." published=".." xmlns="..."><process name=".." type="object" ...>...</process></object>
//     (other item kinds may sit between them: they are kept byte for byte)
// Rebuild = splice: only the inner <process> of an edited member is replaced; every other byte stays as it was
// (BOM, line endings, control characters such as 0x1B that strict XML parsers refuse).
'use strict';
const DECL = '<?xml version="1.0" encoding="utf-8"?>\n';
const unent = s => String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const tag = (t, name) => { const m = new RegExp('<bpr:' + name + '>([\\s\\S]*?)</bpr:' + name + '>').exec(t.slice(0, 20000)); return m ? unent(m[1]) : null; };
const attr = (s, a) => { const m = new RegExp('\\b' + a + '="([^"]*)"').exec(s); return m ? unent(m[1]) : null; };

function isRelease(text) { return /<bpr:release\b/.test(text.slice(0, 4000)); }

/// Members with the offsets of their inner definition. Never throws on odd content: unknown items are counted and skipped.
function index(text) {
  const start = text.indexOf('<bpr:contents'); if (start < 0) throw new Error('no <bpr:contents> in this release');
  const end = text.lastIndexOf('</bpr:contents>');
  const info = { name: tag(text, 'name'), notes: tag(text, 'release-notes'), created: tag(text, 'created'), by: tag(text, 'user-created-by'),
                 package: tag(text, 'package-name'), count: +(attr(text.slice(start, start + 200), 'count') || 0), members: [], other: 0 };
  const re = /<(process|object)\s+(id="[^"]*"[^>]*)>/g; re.lastIndex = start;
  let m;
  while ((m = re.exec(text)) && m.index < end) {
    const wrap = m[1], a = m[2], innerStart = m.index + m[0].length;
    const close = '</process></' + wrap + '>';
    const cEnd = text.indexOf(close, innerStart); if (cEnd < 0) break;
    const innerEnd = cEnd + '</process>'.length;
    // the inner <process ...> opening tag, however long its narrative: attribute values never hold a raw '>' in an export
    const tagEnd = text.indexOf('>', innerStart), head = text.slice(innerStart, tagEnd > 0 && tagEnd < innerEnd ? tagEnd + 1 : innerEnd);
    info.members.push({ kind: wrap, id: attr(a, 'id'), name: attr(a, 'name'), innerName: attr(head, 'name'), published: attr(a, 'published'),
                        type: /\btype="object"/i.test(head) || wrap === 'object' ? 'object' : 'process', wrapStart: m.index, innerStart, innerEnd, wrapEnd: cEnd + close.length });
    re.lastIndex = cEnd + close.length;
  }
  // items that are neither process nor object wrappers (work queues, credentials, ...): counted for the page, never touched.
  // Only the gaps between members are scanned, so text inside a definition (code, narratives) can never count.
  // Each top-level element in a gap is one item (its children are not counted again): kind = tag name, name = its name attribute.
  const contentsOpen = text.indexOf('>', start) + 1; let pos = contentsOpen; info.items = [];
  for (const mb of info.members.concat([{ wrapStart: end, wrapEnd: end }])) {
    const gap = text.slice(pos, mb.wrapStart), base = pos; pos = mb.wrapEnd;
    const rt = /<(\/?)([A-Za-z_][\w.:-]*)(?:"[^"]*"|'[^']*'|[^>'"])*?(\/?)>|<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<\?[\s\S]*?\?>/g; let t, depth = 0, open = null;
    while ((t = rt.exec(gap))) {
      if (!t[2]) continue;
      if (t[1]) { depth--; if (depth === 0 && open) { open.end = base + t.index + t[0].length; open = null; } continue; }
      if (depth === 0) { open = { kind: t[2], name: attr(t[0], 'name') || attr(t[0], 'id') || '', id: attr(t[0], 'id'), start: base + t.index, end: base + t.index + t[0].length }; info.items.push(open); }
      if (t[3]) { if (depth === 0) open = null; } else depth++;
    }
  }
  info.other = info.items.length;
  return info;
}
/// One member as a normal standalone export (what Studio's Export gives), so bluewindow and Blue Prism read it as usual.
function extract(text, m) { return DECL + text.slice(m.innerStart, m.innerEnd); }
/// The inner definition of an edited standalone export, ready to go back into the wrapper.
function innerOf(xml) {
  const s = String(xml).replace(/^﻿/, '').replace(/^\s*<\?xml[^?]*\?>\s*/, '');
  const a = s.indexOf('<process'), b = s.lastIndexOf('</process>');
  if (a < 0 || b < 0) throw new Error('not a Blue Prism export');
  return s.slice(a, b + '</process>'.length);
}
/// New release text: replacements = { memberId: standaloneXml }. Untouched members and everything around them stay identical.
function rebuild(text, info, replacements) {
  const ms = info.members.filter(m => replacements[m.id] != null).sort((x, y) => y.innerStart - x.innerStart);
  let out = text;
  for (const m of ms) out = out.slice(0, m.innerStart) + innerOf(replacements[m.id]) + out.slice(m.innerEnd);
  return out;
}
// Blue Prism's own business objects: never exported, always there. internal/internal.json (seed or Copilot's dump) names them
// and their actions; verified ones get their action names checked like any object.
const INTERNAL_SEED = ['work queues', 'credentials', 'environment locking', 'calendars', 'collections', 'session variables', 'data gateways', 'encryption', 'environment', 'event log', 'sessions', 'licensing'];
let _internal = null;
function internalObjects() {   // Map lower-name -> { verified, actions: Set } ; read once per process
  if (_internal) return _internal;
  _internal = new Map(); for (const n of INTERNAL_SEED) _internal.set(n, { verified: false, actions: null });
  try { const fs = require('fs'), path = require('path'), j = JSON.parse(fs.readFileSync(path.join(__dirname, 'internal', 'internal.json'), 'utf8'));
    for (const o of j.objects || []) _internal.set(String(o.object).toLowerCase(), { verified: !!o.verified, actions: new Set((o.actions || []).map(a => a.name)) }); } catch (e) { }
  return _internal;
}
const INTERNAL = { has: n => internalObjects().has(String(n).toLowerCase()) };
/// Release-level checks: every Action stage in a member (process or object) calls an object + action this release carries (and publishes).
function checks(text, info, catalog) {
  const objs = new Map(catalog.map(o => [o.object, new Set(o.actions.map(a => a.name))]));
  const probs = [];
  for (const m of info.members) {
    const body = text.slice(m.innerStart, m.innerEnd), seen = new Set();
    const re = /<stage [^>]*name="([^"]*)"[^>]*type="Action"(?:(?!<\/stage>)[\s\S])*?<resource object="([^"]*)" action="([^"]*)"/g; let r;
    while ((r = re.exec(body))) {
      const st = unent(r[1]), ob = unent(r[2]), ac = unent(r[3]), k = ob + '\u0001' + ac; if (seen.has(k)) continue; seen.add(k);
      const internal = internalObjects().get(ob.toLowerCase());
      if (internal) { if (internal.verified && internal.actions && !internal.actions.has(ac)) probs.push({ level: 'error', member: m.name, stage: st, msg: 'calls "' + ob + ' / ' + ac + '": Blue Prism\'s ' + ob + ' has no action with that name' }); continue; }
      if (!objs.has(ob)) probs.push({ level: 'warn', member: m.name, stage: st, msg: 'calls object "' + ob + '", which is not in this release (fine if the target environment already has it)' });
      else if (!objs.get(ob).has(ac)) probs.push({ level: 'error', member: m.name, stage: st, msg: 'calls "' + ob + ' / ' + ac + '": the object is in the release but has no published action with that name' });
    }
  }
  return probs;
}
/// What each member calls: object names (Action stages, in processes AND objects) and process ids (Process stages).
function uses(text, info) {
  const out = {};
  for (const m of info.members) {
    const body = text.slice(m.innerStart, m.innerEnd), objs = new Set(), procs = new Set(); let r;
    const ra = /<resource object="([^"]*)"/g; while ((r = ra.exec(body))) objs.add(unent(r[1]));
    const rp = /<stage [^>]*type="Process"(?:(?!<\/stage>)[\s\S])*?<processid>([^<]+)<\/processid>/g; while ((r = rp.exec(body))) procs.add(r[1].trim().toLowerCase());
    out[m.id] = { objects: objs, processes: procs };
  }
  return out;
}
/// Members reachable from the roots: what they call, what that calls, ... Objects match by name, processes by id.
/// missing = names called that the release does not carry (Blue Prism internal objects left out).
function closure(info, use, rootIds) {
  const byName = new Map(), byId = new Map();
  // an Action stage names the object by the object's own name; the release wrapper normally carries the same one. Both count.
  const norm = x => String(x == null ? '' : x).replace(/\s+/g, ' ').trim().toLowerCase();
  for (const m of info.members) {
    byId.set(String(m.id).toLowerCase(), m);
    if (m.type !== 'object') continue;
    for (const nm of new Set([norm(m.name), norm(m.innerName || m.name)])) { if (!byName.has(nm)) byName.set(nm, []); byName.get(nm).push(m); }
  }
  const keep = new Set(), missing = new Set(), todo = rootIds.slice();
  while (todo.length) {
    const id = todo.pop(); if (keep.has(id)) continue; keep.add(id);
    const u = use[id]; if (!u) continue;
    for (const o of u.objects) { const ms = byName.get(norm(o)); if (ms) ms.forEach(x => todo.push(x.id)); else if (!INTERNAL.has(o.toLowerCase())) missing.add(o); }
    for (const p of u.processes) { const x = byId.get(p); if (x) todo.push(x.id); }
  }
  return { keep, missing: [...missing].sort() };
}
/// The release with only the kept members (and every non-member item). Dropped members leave with their own line;
/// bpr:contents count goes down by the number dropped. Everything else is byte-identical.
function trim(text, info, keep) {
  const drop = info.members.filter(m => !keep.has(m.id)).sort((x, y) => y.wrapStart - x.wrapStart);
  let out = text;
  for (const m of drop) {
    let a = m.wrapStart; while (a > 0 && (out[a - 1] === ' ' || out[a - 1] === '\t')) a--;
    if (out[a - 1] === '\n') { a--; if (out[a - 1] === '\r') a--; }
    out = out.slice(0, a) + out.slice(m.wrapEnd);
  }
  out = out.replace(/(<bpr:contents\b[^>]*\bcount=")(\d+)(")/, (x, p1, n, p3) => p1 + Math.max(0, +n - drop.length) + p3);
  return { text: out, dropped: drop.length };
}
/// ---- other items: environment variables and work queues, written the way this release already writes them ----
const ent = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
function guid() { const h = '0123456789abcdef'; let g = ''; for (let i = 0; i < 36; i++) g += (i === 8 || i === 13 || i === 18 || i === 23) ? '-' : (i === 14 ? '4' : i === 19 ? h[8 + Math.floor(Math.random() * 4)] : h[Math.floor(Math.random() * 16)]); return g; }
const FALLBACK = {   // the shape Blue Prism itself writes (read from a real export: id = name for an env var, queues carry their numeric id)
  'environment-variable': sp => '<environment-variable id="' + ent(sp.name) + '" name="' + ent(sp.name) + '" type="' + ent(sp.type || 'text') + '" value="' + ent(sp.value) + '" xmlns="http://www.blueprism.co.uk/product/environment-variable"><description>' + ent(sp.description) + '</description></environment-variable>',
  'work-queue': (sp, info) => '<work-queue id="' + nextQueueId(info) + '" name="' + ent(sp.name) + '" key-field="' + ent(sp.keyField) + '" xmlns="http://www.blueprism.co.uk/product/work-queue" />'
};
function nextQueueId(info) { let n = 0; for (const it of (info && info.items) || []) if (it.kind === 'work-queue' && /^\d+$/.test(it.id || '')) n = Math.max(n, +it.id); return n + 1; }
function setAttr(tag, name, value) { const re = new RegExp('(\\s' + name + '=")[^"]*(")'); return re.test(tag) ? tag.replace(re, '$1' + ent(value) + '$2') : tag.replace(/(\s*\/?>)$/, ' ' + name + '="' + ent(value) + '"$1'); }
function setText(xml, el, value) {   // first <el ...>text</el> whose content holds no element; appended before the closing tag when absent
  const re = new RegExp('(<' + el + '(?:\\s[^>]*)?>)([^<]*)(</' + el + '>)'); if (re.test(xml)) return xml.replace(re, '$1' + ent(value) + '$3');
  const se = new RegExp('<' + el + '(?:\\s[^>]*)?/>'); if (se.test(xml)) return xml.replace(se, '<' + el + '>' + ent(value) + '</' + el + '>');
  return null;
}
/// One new item as XML. spec = { kind, name, value, type, description, keyField, maxAttempts }.
/// A sibling of the same kind already in the release is the template (every attribute Blue Prism wrote stays, only what the user typed changes).
function makeItem(text, info, spec) {
  const kind = spec.kind; if (!FALLBACK[kind]) throw new Error('cannot author a ' + kind);
  if (!spec.name || !/\S/.test(spec.name)) throw new Error('name is empty');
  const name = spec.name.trim();
  if ((info.items || []).some(it => it.kind === kind && it.name.toLowerCase() === name.toLowerCase())) throw new Error('a ' + kind + ' named "' + name + '" is already in the release');
  const tpl = (info.items || []).find(it => it.kind === kind);
  if (!tpl) return { xml: FALLBACK[kind](spec, info), verified: true };
  let xml = text.slice(tpl.start, tpl.end), head = /^<[^>]*>/.exec(xml)[0], h2 = setAttr(head, 'name', name);
  if (kind === 'work-queue') { h2 = setAttr(h2, 'id', String(nextQueueId(info))); h2 = setAttr(h2, 'key-field', spec.keyField || ''); if (spec.maxAttempts && /\smax-attempts="/.test(h2)) h2 = setAttr(h2, 'max-attempts', spec.maxAttempts); }
  let body = xml.slice(head.length);
  if (kind === 'environment-variable') {
    h2 = setAttr(h2, 'id', name);
    if (/\svalue="/.test(h2)) { h2 = setAttr(h2, 'value', spec.value || ''); h2 = setAttr(h2, 'type', spec.type || 'text'); }
    else { let b = setText(body, 'value', spec.value || ''); if (b == null) b = setText(body, 'data', spec.value || ''); if (b == null) return { xml: FALLBACK[kind](spec, info), verified: true }; body = b.replace(/(<data\b[^>]*\stype=")[^"]*(")/, '$1' + ent(spec.type || 'text') + '$2'); }
    const d = setText(body, 'description', spec.description || ''); if (d != null) body = d; else if (/<\/environment-variable>\s*$/.test(body)) body = body.replace(/(<\/environment-variable>\s*)$/, '<description>' + ent(spec.description || '') + '</description>$1');
  }
  return { xml: h2 + body, verified: true };
}
/// New release text with items dropped (by their start offset in `text`) and new ones appended before </bpr:contents>; count follows.
function editItems(text, info, drops, adds) {
  const end = text.lastIndexOf('</bpr:contents>'); if (end < 0) throw new Error('no </bpr:contents>');
  const nl = /\r\n/.test(text.slice(0, 2000)) ? '\r\n' : '\n';
  let out = text;
  const gone = (info.items || []).filter(it => drops.includes(it.start)).sort((a, b) => b.start - a.start);
  for (const it of gone) { let s = it.start; while (s > 0 && /[ \t]/.test(out[s - 1])) s--; if (out.slice(s - nl.length, s) === nl) s -= nl.length; out = out.slice(0, s) + out.slice(it.end); }
  if (adds.length) {
    const e2 = out.lastIndexOf('</bpr:contents>'); let ins = e2; while (ins > 0 && /[ \t]/.test(out[ins - 1])) ins--;
    const indent = out.slice(ins, e2).length ? out.slice(ins, e2) : '  ';
    const line = ins > 0 && out.slice(ins - nl.length, ins) === nl ? ins - nl.length : ins;
    out = out.slice(0, line) + adds.map(x => nl + indent + '  ' + x).join('') + out.slice(line);
  }
  out = out.replace(/(<bpr:contents\s+count=")(\d+)(")/, (m, a, n, b) => a + (Number(n) - gone.length + adds.length) + b);
  return out;
}
module.exports = { isRelease, index, extract, innerOf, rebuild, checks, uses, closure, trim, makeItem, editItems, guid, internalObjects };
