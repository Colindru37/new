Put Blue Prism exports (.xml) here, then click Open on the bluewindow home page.
