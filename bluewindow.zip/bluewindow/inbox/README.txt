Drop .xml exports or .bprelease files here while bluewindow.cmd is running; they render on their own.
