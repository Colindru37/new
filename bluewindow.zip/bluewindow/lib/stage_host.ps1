# Stage host for bluewindow's Run on Windows: compiles the code-stage classes bprun_run.py extracted (plus StageServer.cs)
# in-process with Add-Type (the C# 5 compiler that ships with .NET, same route as Radar) and serves them on stdin/stdout.
# No binary is written or shipped. Usage (bprun_run.py does this): powershell -NoProfile -ExecutionPolicy Bypass -File stage_host.ps1 <sources dir> <refs file>
param([string]$src, [string]$refs)
$ErrorActionPreference = 'Stop'
$files = @(Get-ChildItem -Path $src -Filter *.cs | ForEach-Object { $_.FullName })
$ra = @('System.dll', 'System.Core.dll', 'System.Xml.dll', 'System.Data.dll', 'System.Web.Extensions.dll', 'System.Drawing.dll', 'System.Net.Http.dll', 'System.IO.Compression.dll', 'System.IO.Compression.FileSystem.dll')
if ($refs -and (Test-Path $refs)) { foreach ($r in Get-Content $refs) { if ($r.Trim() -ne '' -and $ra -notcontains $r.Trim()) { $ra += $r.Trim() } } }
Add-Type -Path $files -ReferencedAssemblies $ra -IgnoreWarnings
[StageServer]::Main()
