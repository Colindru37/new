// bprelease: read and rebuild a Blue Prism .bprelease without parsing it as one XML document.
// Shape (7.2.1, seen on the estate 2026-11-10):
//   <?xml ...?><bpr:release xmlns:bpr="http://www.blueprism.co.uk/product/release"> <bpr:name>..</bpr:name> ... metadata ...
//   <bpr:contents count="N">
//     <process id=".." name=".." published=".." xmlns="http://www.blueprism.co.uk/product/process"><process name=".." ...>...</process></process>
//     <object  id=".." name=".." published=".." xmlns="..."><process name=".." type="object" ...>...</process></object>
//     (other item kinds may sit between them: they are kept byte for byte)
// Rebuild = splice: only the inner <process> of an edited member is replaced; every other byte stays as it was
// (BOM, line endings, control characters such as 0x1B that strict XML parsers refuse).
'use strict';
const DECL = '<?xml version="1.0" encoding="utf-8"?>\n';
const unent = s => String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const tag = (t, name) => { const m = new RegExp('<bpr:' + name + '>([\\s\\S]*?)</bpr:' + name + '>').exec(t.slice(0, 20000)); return m ? unent(m[1]) : null; };
const attr = (s, a) => { const m = new RegExp('\\b' + a + '="([^"]*)"').exec(s); return m ? unent(m[1]) : null; };

function isRelease(text) { return /<bpr:release\b/.test(text.slice(0, 4000)); }

/// Members with the offsets of their inner definition. Never throws on odd content: unknown items are counted and skipped.
function index(text) {
  const start = text.indexOf('<bpr:contents'); if (start < 0) throw new Error('no <bpr:contents> in this release');
  const end = text.lastIndexOf('</bpr:contents>');
  const info = { name: tag(text, 'name'), notes: tag(text, 'release-notes'), created: tag(text, 'created'), by: tag(text, 'user-created-by'),
                 package: tag(text, 'package-name'), count: +(attr(text.slice(start, start + 200), 'count') || 0), members: [], other: 0 };
  const re = /<(process|object)\s+(id="[^"]*"[^>]*)>/g; re.lastIndex = start;
  let m;
  while ((m = re.exec(text)) && m.index < end) {
    const wrap = m[1], a = m[2], innerStart = m.index + m[0].length;
    const close = '</process></' + wrap + '>';
    const cEnd = text.indexOf(close, innerStart); if (cEnd < 0) break;
    const innerEnd = cEnd + '</process>'.length;
    const head = text.slice(innerStart, Math.min(innerEnd, innerStart + 3000));
    info.members.push({ kind: wrap, id: attr(a, 'id'), name: attr(a, 'name'), published: attr(a, 'published'),
                        type: /<process\b[^>]*\btype="object"/.test(head) ? 'object' : 'process', wrapStart: m.index, innerStart, innerEnd, wrapEnd: cEnd + close.length });
    re.lastIndex = cEnd + close.length;
  }
  // items that are neither process nor object wrappers (work queues, credentials, ...): counted for the page, never touched.
  // Only the gaps between members are scanned, so text inside a definition (code, narratives) can never count.
  const contentsOpen = text.indexOf('>', start) + 1; let pos = contentsOpen;
  for (const mb of info.members.concat([{ wrapStart: end, wrapEnd: end }])) {
    const gap = text.slice(pos, mb.wrapStart); info.other += (gap.match(/<(?![\/!?])/g) || []).length; pos = mb.wrapEnd;
  }
  return info;
}
/// One member as a normal standalone export (what Studio's Export gives), so bluewindow and Blue Prism read it as usual.
function extract(text, m) { return DECL + text.slice(m.innerStart, m.innerEnd); }
/// The inner definition of an edited standalone export, ready to go back into the wrapper.
function innerOf(xml) {
  const s = String(xml).replace(/^﻿/, '').replace(/^\s*<\?xml[^?]*\?>\s*/, '');
  const a = s.indexOf('<process'), b = s.lastIndexOf('</process>');
  if (a < 0 || b < 0) throw new Error('not a Blue Prism export');
  return s.slice(a, b + '</process>'.length);
}
/// New release text: replacements = { memberId: standaloneXml }. Untouched members and everything around them stay identical.
function rebuild(text, info, replacements) {
  const ms = info.members.filter(m => replacements[m.id] != null).sort((x, y) => y.innerStart - x.innerStart);
  let out = text;
  for (const m of ms) out = out.slice(0, m.innerStart) + innerOf(replacements[m.id]) + out.slice(m.innerEnd);
  return out;
}
// Blue Prism's own business objects: never exported, always there
const INTERNAL = new Set(['work queues', 'credentials', 'environment locking', 'calendars', 'collections', 'session variables', 'data gateways', 'encryption', 'environment', 'event log', 'sessions', 'licensing']);
/// Release-level checks: every Action stage in a process member calls an object + action this release carries (and publishes).
function checks(text, info, catalog) {
  const objs = new Map(catalog.map(o => [o.object, new Set(o.actions.map(a => a.name))]));
  const probs = [];
  for (const m of info.members) {
    if (m.type !== 'process') continue;
    const body = text.slice(m.innerStart, m.innerEnd), seen = new Set();
    const re = /<stage [^>]*name="([^"]*)"[^>]*type="Action"(?:(?!<\/stage>)[\s\S])*?<resource object="([^"]*)" action="([^"]*)"/g; let r;
    while ((r = re.exec(body))) {
      const st = unent(r[1]), ob = unent(r[2]), ac = unent(r[3]), k = ob + '\u0001' + ac; if (seen.has(k)) continue; seen.add(k);
      if (INTERNAL.has(ob.toLowerCase())) continue;
      if (!objs.has(ob)) probs.push({ level: 'warn', member: m.name, stage: st, msg: 'calls object "' + ob + '", which is not in this release (fine if the target environment already has it)' });
      else if (!objs.get(ob).has(ac)) probs.push({ level: 'error', member: m.name, stage: st, msg: 'calls "' + ob + ' / ' + ac + '": the object is in the release but has no published action with that name' });
    }
  }
  return probs;
}
/// What each member calls: object names (Action stages, in processes AND objects) and process ids (Process stages).
function uses(text, info) {
  const out = {};
  for (const m of info.members) {
    const body = text.slice(m.innerStart, m.innerEnd), objs = new Set(), procs = new Set(); let r;
    const ra = /<resource object="([^"]*)"/g; while ((r = ra.exec(body))) objs.add(unent(r[1]));
    const rp = /<stage [^>]*type="Process"(?:(?!<\/stage>)[\s\S])*?<processid>([^<]+)<\/processid>/g; while ((r = rp.exec(body))) procs.add(r[1].trim().toLowerCase());
    out[m.id] = { objects: objs, processes: procs };
  }
  return out;
}
/// Members reachable from the roots: what they call, what that calls, ... Objects match by name, processes by id.
/// missing = names called that the release does not carry (Blue Prism internal objects left out).
function closure(info, use, rootIds) {
  const byName = new Map(), byId = new Map();
  for (const m of info.members) { byId.set(String(m.id).toLowerCase(), m); if (m.type === 'object' && !byName.has(m.name)) byName.set(m.name, []); if (m.type === 'object') byName.get(m.name).push(m); }
  const keep = new Set(), missing = new Set(), todo = rootIds.slice();
  while (todo.length) {
    const id = todo.pop(); if (keep.has(id)) continue; keep.add(id);
    const u = use[id]; if (!u) continue;
    for (const o of u.objects) { const ms = byName.get(o); if (ms) ms.forEach(x => todo.push(x.id)); else if (!INTERNAL.has(o.toLowerCase())) missing.add(o); }
    for (const p of u.processes) { const x = byId.get(p); if (x) todo.push(x.id); }
  }
  return { keep, missing: [...missing].sort() };
}
/// The release with only the kept members (and every non-member item). Dropped members leave with their own line;
/// bpr:contents count goes down by the number dropped. Everything else is byte-identical.
function trim(text, info, keep) {
  const drop = info.members.filter(m => !keep.has(m.id)).sort((x, y) => y.wrapStart - x.wrapStart);
  let out = text;
  for (const m of drop) {
    let a = m.wrapStart; while (a > 0 && (out[a - 1] === ' ' || out[a - 1] === '\t')) a--;
    if (out[a - 1] === '\n') { a--; if (out[a - 1] === '\r') a--; }
    out = out.slice(0, a) + out.slice(m.wrapEnd);
  }
  out = out.replace(/(<bpr:contents\b[^>]*\bcount=")(\d+)(")/, (x, p1, n, p3) => p1 + Math.max(0, +n - drop.length) + p3);
  return { text: out, dropped: drop.length };
}
module.exports = { isRelease, index, extract, innerOf, rebuild, checks, uses, closure, trim };
