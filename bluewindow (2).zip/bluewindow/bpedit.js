// bpedit: the editing model behind bluewindow. Pure functions (node + browser) plus the browser UI at the end.
// The model keeps every stage's ORIGINAL xml and rewrites only what was edited, so a round trip through the
// editor leaves untouched stages byte-identical. Save = serialize(model) -> the next version's .xml.
(function (root) {
'use strict';
const D = (typeof BPDRAW !== 'undefined') ? BPDRAW : require('./bpdraw');
const { tag, attr, unx, esc } = D;
const escText = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---------- model ----------
function modelFrom(xml) {
  const bp = D.parseBp(xml);
  const stages = bp.stages.map(st => Object.assign({}, st, D.geom(st.body), { orig: { name: st.name, body: st.body }, deleted: false, edits: {} }));
  return { xml, name: bp.name, type: bp.type, pages: bp.pages, elements: bp.elements, stages, byId: Object.fromEntries(stages.map(s => [s.id, s])) };
}
function pagesOf(m) { return [...new Set(m.stages.filter(s => !s.deleted).map(s => s.page))]; }
function linkOf(st, kind) { return st.edits['link:' + kind] !== undefined ? st.edits['link:' + kind] : (tag(st.orig.body, kind).trim() || null); }

// ---------- edits (pure) ----------
function move(st, x, y) { st.x = Math.round(x); st.y = Math.round(y); st.edits.moved = true; }
function resize(st, w, h) { st.w = Math.round(w); st.h = Math.round(h); st.edits.moved = true; }
function rename(st, name) { st.name = name; st.edits.name = name; }
function setLink(st, kind, targetId) { st.edits['link:' + kind] = targetId || null; }
function remove(m, st) { st.deleted = true; for (const o of m.stages) for (const k of ['onsuccess', 'ontrue', 'onfalse']) if (linkOf(o, k) === st.id) setLink(o, k, null); }
function setField(st, key, value) { st.edits[key] = value; }
// the stages a block holds: centre inside the rectangle (Studio's rule, membership is geometric)
function membersOf(m, blk) { return m.stages.filter(s => !s.deleted && s !== blk && s.page === blk.page && s.type !== 'Block' && s.x >= blk.x && s.x <= blk.x + blk.w && s.y >= blk.y && s.y <= blk.y + blk.h); }
// the other half of a pair (LoopStart/LoopEnd, WaitStart/WaitEnd, ChoiceStart/ChoiceEnd) by groupid
function partnerOf(m, st) { if (!/^(Loop|Wait|Choice)(Start|End)$/.test(st.type)) return null; const gid = groupOf(st); if (!gid) return null; const want = st.type.replace(/Start$|End$/, x => x === 'Start' ? 'End' : 'Start'); return m.stages.find(s => !s.deleted && s !== st && s.type === want && groupOf(s) === gid) || null; }
function groupOf(st) { return (tag(st.orig.body, 'groupid') || '').trim(); }
// a whole page: its stages go, its declaration goes; page calls that pointed at it are flagged by the rules
function removePage(m, page) {
  const ssid = ssidOf(m, page);
  for (const st of m.stages.filter(s => !s.deleted && s.page === page)) remove(m, st);
  if (m.addedPages && m.addedPages.some(p => p.ssid === ssid)) m.addedPages = m.addedPages.filter(p => p.ssid !== ssid); else (m.removedPages = m.removedPages || []).push(ssid);
  delete m.pages[ssid];
}


// ---------- new stages and pages (slice 2) ----------
const FONT = '<font family="Segoe UI" size="10" style="Regular" color="000000" />';
const FONT_TITLE = '<font family="Segoe UI" size="10" style="Bold" color="3366FF" />';
const FONT_NOTE = '<font family="Segoe UI" size="10" style="Regular" color="008000" />';
function guid() {
  const c = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : null; if (c) return c;
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, ch => { const r = Math.random() * 16 | 0; return (ch === 'x' ? r : (r & 3 | 8)).toString(16); });
}
// what the palette offers: default box, default name, and the body (verified shapes from reference/stage-schemas.md)
const SIZE = { Start: [60, 30], End: [60, 30], Action: [150, 30], Decision: [150, 30], Calculation: [150, 30], MultipleCalculation: [150, 30], SubSheet: [150, 30],
  Exception: [120, 30], Recover: [60, 30], Resume: [60, 30], Data: [120, 30], Collection: [120, 30], Note: [200, 60], Anchor: [10, 10], LoopStart: [90, 30], LoopEnd: [90, 30], Block: [300, 180], Code: [150, 30] };
const DEFAULT_NAME = { Start: 'Start', End: 'End', Action: 'Do Thing', Decision: 'Condition Holds?', Calculation: 'Set Value', MultipleCalculation: 'Set Values', SubSheet: 'Call Page', Exception: 'Raise Error',
  Recover: 'Recover', Resume: 'Resume', Data: 'Value', Collection: 'col_Rows', Note: 'Note', Anchor: 'Anchor', LoopStart: 'Loop Start', LoopEnd: 'Loop End', Block: 'Block', Code: 'Run Code' };
const PALETTE = ['Action', 'Decision', 'Calculation', 'MultipleCalculation', 'SubSheet', 'Code', 'Data', 'Collection', 'Exception', 'Recover', 'Resume', 'Anchor', 'LoopStart', 'LoopEnd', 'Note', 'Block', 'Start', 'End'];
function template(type, o) {
  const ss = o.ssid ? `\n  <subsheetid>${o.ssid}</subsheetid>` : '';
  const disp = `\n  <display x="${o.x}" y="${o.y}" w="${o.w}" h="${o.h}" />`;
  const li = /^(Decision|Calculation|MultipleCalculation|Anchor|LoopStart|LoopEnd|Code)$/.test(type) ? '\n  <loginhibit />' : /^(Exception|Recover|Resume|SubSheet)$/.test(type) ? '\n  <loginhibit onsuccess="true" />' : '';
  let mid = '';
  switch (type) {
    case 'Decision': mid = '\n  <decision expression="" />'; break;
    case 'Calculation': mid = '\n  <calculation expression="" stage="" />'; break;
    case 'MultipleCalculation': mid = '\n  <steps>\n  </steps>'; break;
    case 'Exception': mid = '\n  <exception type="System Exception" detail="" />'; break;
    case 'Data': mid = `\n  <datatype>${o.datatype || 'text'}</datatype>\n  <initialvalue>${escText(o.initialvalue || '')}</initialvalue>\n  <private />\n  <alwaysinit />`; break;
    case 'Collection': mid = '\n  <datatype>collection</datatype>\n  <private />\n  <alwaysinit />'; break;
    case 'Note': mid = `\n  <narrative>${escText(o.text || '')}</narrative>`; break;
    case 'LoopStart': mid = `\n  <groupid>${o.groupid || guid()}</groupid>\n  <looptype>ForEach</looptype>\n  <loopdata>${escText(o.loopdata || '')}</loopdata>`; break;
    case 'LoopEnd': mid = `\n  <groupid>${o.groupid || ''}</groupid>`; break;
    case 'Code': mid = '\n  <inputs>\n  </inputs>\n  <outputs>\n  </outputs>\n  <code><![CDATA[]]></code>'; break;
    case 'SubSheetInfo': mid = `\n  <narrative>${escText(o.text || '')}</narrative>`; break;
  }
  const font = type === 'Note' ? FONT_NOTE : type === 'SubSheetInfo' ? FONT_TITLE : type === 'Block' ? '<font family="Segoe UI" size="10" style="Regular" color="33CCCC" />' : FONT;
  if (type === 'SubSheetInfo') return `${ss}${mid}${disp}\n  ${font}\n  <published>true</published>\n`;
  if (type === 'Block') return `${disp}\n  ${font}\n`.replace(/^\n/, ss ? ss + '\n' : '\n');
  return `${ss}${li}${disp}\n  ${font}${mid}\n`;
}
const ssidOf = (m, page) => { for (const k of Object.keys(m.pages)) if (m.pages[k] === page) return k; return ''; };
function addStage(m, type, page, x, y, o) {
  o = o || {};
  const [w, h] = SIZE[type] || [150, 30]; const ssid = page === 'Main Page' && m.type === 'process' && !ssidOf(m, page) ? '' : ssidOf(m, page);
  const st = { id: guid(), name: o.name || DEFAULT_NAME[type] || type, type, page, ssid, x: Math.round(x), y: Math.round(y), w: o.w || w, h: o.h || h, deleted: false, edits: {}, added: true };
  st.orig = { name: st.name, body: template(type, { ssid, x: st.x, y: st.y, w: st.w, h: st.h, datatype: o.datatype, initialvalue: o.initialvalue, text: o.text, loopdata: o.loopdata, groupid: o.groupid }) };
  m.stages.push(st); m.byId[st.id] = st; return st;
}
// a new page: declaration + SubSheetInfo + Start -> End, like the generator makes them
function addPage(m, name, o) {
  o = o || {}; const ssid = guid(); m.pages[ssid] = name; m.addedPages = m.addedPages || []; m.addedPages.push({ ssid, name, published: o.published !== undefined ? o.published : m.type === 'object' });
  const info = addStage(m, 'SubSheetInfo', name, -345, -135, { name, text: o.text || '', w: 220, h: 120 });
  const start = addStage(m, 'Start', name, 15, -30), end = addStage(m, 'End', name, 15, 90);
  setLink(start, 'onsuccess', end.id);
  return { ssid, info, start, end };
}
// an Action stage's target: object + action, with the inputs/outputs the catalog says that action has
function setResource(st, object, action, inputs, outputs) { st.edits.resource = { object, action, inputs: inputs || [], outputs: outputs || [] }; }
// a SubSheet stage's target page (processid = the page's subsheetid), params from that page's Start/End
function setPageCall(m, st, page) {
  const ssid = ssidOf(m, page); const live = m.stages.filter(s => !s.deleted && s.page === page);
  const start = live.find(s => s.type === 'Start'), end = live.find(s => s.type === 'End');
  const ins = [], outs = []; let mm;
  if (start) { const re = /<input ([^>]*)\/>/g; while ((mm = re.exec(stageBody(start)))) ins.push({ name: attr(mm[1], 'name'), type: attr(mm[1], 'type') }); }
  if (end) { const re = /<output ([^>]*)\/>/g; while ((mm = re.exec(stageBody(end)))) outs.push({ name: attr(mm[1], 'name'), type: attr(mm[1], 'type') }); }
  st.edits.pagecall = { ssid, inputs: ins, outputs: outs };
}
// the action catalog from object exports: every published page = an action, its Start inputs / End outputs = the parameters
function catalogFrom(xmls) {
  const out = [];
  for (const xml of xmls) {
    const bp = D.parseBp(xml); if (bp.type !== 'object') continue;
    const pub = new Set(); const re = /<subsheet subsheetid="([^"]+)"[^>]*published="true"/g; let mm; while ((mm = re.exec(xml))) pub.add(mm[1]);
    const actions = [];
    for (const ssid of Object.keys(bp.pages)) {
      if (!pub.has(ssid)) continue;
      const ps = bp.stages.filter(s => s.ssid === ssid), start = ps.find(s => s.type === 'Start'), end = ps.find(s => s.type === 'End');
      const ins = [], outs = [];
      if (start) { const r = /<input ([^>]*)\/>/g; while ((mm = r.exec(start.body))) ins.push({ name: attr(mm[1], 'name'), type: attr(mm[1], 'type') }); }
      if (end) { const r = /<output ([^>]*)\/>/g; while ((mm = r.exec(end.body))) outs.push({ name: attr(mm[1], 'name'), type: attr(mm[1], 'type') }); }
      actions.push({ name: bp.pages[ssid], inputs: ins, outputs: outs });
    }
    actions.sort((a, b) => a.name.localeCompare(b.name));
    out.push({ object: bp.name, actions });
  }
  return out.sort((a, b) => a.object.localeCompare(b.object));
}

// ---------- serialize ----------
function replaceOrInsert(body, re, replacement, afterRe) {
  if (re.test(body)) return body.replace(re, replacement);
  const m = afterRe.exec(body);
  if (m) return body.slice(0, m.index + m[0].length) + '\n  ' + replacement + body.slice(m.index + m[0].length);
  return body.replace(/\s*$/, '') + '\n  ' + replacement + '\n';
}
const AFTER_HEAD = /<font [^>]*\/>|<display [^>]*\/>|<subsheetid>[^<]*<\/subsheetid>/;
// the last head element present: a link goes after the parameters, else after the font, display, subsheetid
const afterHead = (b, kind) => [...(kind === 'onfalse' ? [/<\/ontrue>/, /<decision [^>]*\/>/] : kind === 'ontrue' ? [/<decision [^>]*\/>/] : []), /<\/outputs>/, /<\/inputs>/, /<font [^>]*\/>/, /<display [^>]*\/>/, /<subsheetid>[^<]*<\/subsheetid>/].find(r => r.test(b)) || AFTER_HEAD;
const afterFont = b => [/<font [^>]*\/>/, /<display [^>]*\/>/].find(r => r.test(b)) || AFTER_HEAD;
function stageBody(st) {
  let b = st.orig.body;
  const e = st.edits;
  if (e.moved) b = b.replace(/<display x="[^"]*" y="[^"]*"( w="[^"]*")?( h="[^"]*")?\s*\/>/, m => `<display x="${st.x}" y="${st.y}"` + (/ w=/.test(m) ? ` w="${st.w}"` : '') + (/ h=/.test(m) ? ` h="${st.h}"` : '') + ' />');
  for (const kind of ['onsuccess', 'ontrue', 'onfalse']) {
    if (e['link:' + kind] === undefined) continue;
    const v = e['link:' + kind];
    if (v) b = replaceOrInsert(b, new RegExp('<' + kind + '>[^<]*</' + kind + '>'), `<${kind}>${v}</${kind}>`, afterHead(b, kind));
    else b = b.replace(new RegExp('\\s*<' + kind + '>[^<]*</' + kind + '>'), '');
  }
  if (e.narrative !== undefined) b = replaceOrInsert(b, /<narrative>[\s\S]*?<\/narrative>/, `<narrative>${escText(e.narrative)}</narrative>`, /<subsheetid>[^<]*<\/subsheetid>/);
  if (e.decision !== undefined) b = replaceOrInsert(b, /<decision expression="[^"]*" \/>/, `<decision expression="${esc(e.decision)}" />`, afterFont(b));
  if (e.calcs !== undefined) {
    const rows = e.calcs.filter(r => r[0] !== '' || r[1] !== '');
    if (st.type === 'Calculation') b = replaceOrInsert(b, /<calculation expression="[^"]*" stage="[^"]*" \/>/, `<calculation expression="${esc(rows[0] ? rows[0][0] : '')}" stage="${esc(rows[0] ? rows[0][1] : '')}" />`, AFTER_HEAD);
    else b = replaceOrInsert(b, /<steps>[\s\S]*?<\/steps>/, '<steps>\n' + rows.map(r => `    <calculation expression="${esc(r[0])}" stage="${esc(r[1])}" />`).join('\n') + '\n  </steps>', AFTER_HEAD);
  }
  if (e.exception !== undefined) b = b.replace(/<exception ([^>]*)\/>/, m => {
    let a = m.slice(0, -2);
    a = /\btype="/.test(a) ? a.replace(/\btype="[^"]*"/, `type="${esc(e.exception.type)}"`) : a + ` type="${esc(e.exception.type)}"`;
    a = /\bdetail="/.test(a) ? a.replace(/\bdetail="[^"]*"/, `detail="${esc(e.exception.detail)}"`) : a + ` detail="${esc(e.exception.detail)}"`;
    return a + '/>';
  });
  if (e.datatype !== undefined) b = replaceOrInsert(b, /<datatype>[^<]*<\/datatype>/, `<datatype>${escText(e.datatype)}</datatype>`, AFTER_HEAD);
  if (e.initialvalue !== undefined) b = replaceOrInsert(b, /<initialvalue>[\s\S]*?<\/initialvalue>/, `<initialvalue>${escText(e.initialvalue)}</initialvalue>`, /<datatype>[^<]*<\/datatype>/);
  for (const k of Object.keys(e)) {
    if (k.startsWith('in:')) { const n = k.slice(3); b = b.replace(new RegExp('(<input [^>]*\\bname="' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^>]*\\bexpr=")[^"]*(")'), `$1${esc(e[k])}$2`); }
    if (k.startsWith('out:')) { const n = k.slice(4); b = b.replace(new RegExp('(<output [^>]*\\bname="' + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '"[^>]*\\bstage=")[^"]*(")'), `$1${esc(e[k])}$2`); }
  }
  if (e.code !== undefined) b = replaceOrInsert(b, /<code>[\s\S]*?<\/code>/, '<code><![CDATA[' + e.code.replace(/\]\]>/g, ']]]]><![CDATA[>') + ']]></code>', AFTER_HEAD);
  if (e.resource !== undefined) {
    const r = e.resource;
    b = b.replace(/\s*<inputs>[\s\S]*?<\/inputs>/, '').replace(/\s*<outputs>[\s\S]*?<\/outputs>/, '').replace(/\s*<resource [^>]*\/>/, '');
    const keep = {}; for (const k of Object.keys(e)) if (k.startsWith('in:') || k.startsWith('out:')) keep[k] = e[k];
    const ins = r.inputs.map(i => `    <input type="${esc(i.type)}" name="${esc(i.name)}" friendlyname="${esc(i.name)}" expr="${esc(keep['in:' + i.name] !== undefined ? keep['in:' + i.name] : (i.expr || ''))}" />`).join('\n');
    const outs = r.outputs.map(i => `    <output type="${esc(i.type)}" name="${esc(i.name)}" friendlyname="${esc(i.name)}" stage="${esc(keep['out:' + i.name] !== undefined ? keep['out:' + i.name] : (i.stage || ''))}" />`).join('\n');
    const block = (r.inputs.length ? `<inputs>\n${ins}\n  </inputs>\n  ` : '') + (r.outputs.length ? `<outputs>\n${outs}\n  </outputs>\n  ` : '');
    b = replaceOrInsert(b, /<onsuccess>[^<]*<\/onsuccess>/, (block + (linkOf(st, 'onsuccess') ? `<onsuccess>${linkOf(st, 'onsuccess')}</onsuccess>` : '')).replace(/\n  $/, ''), afterFont(b));
    b = b.replace(/\n  \n/g, '\n').replace(/\s*$/, '') + `\n  <resource object="${esc(r.object)}" action="${esc(r.action)}" />\n`;
  }
  if (e.pagecall !== undefined) {
    const r = e.pagecall;
    b = b.replace(/\s*<inputs>[\s\S]*?<\/inputs>/, '').replace(/\s*<outputs>[\s\S]*?<\/outputs>/, '').replace(/\s*<processid>[^<]*<\/processid>/, '');
    const keep = {}; for (const k of Object.keys(e)) if (k.startsWith('in:') || k.startsWith('out:')) keep[k] = e[k];
    const ins = r.inputs.map(i => `    <input type="${esc(i.type)}" name="${esc(i.name)}" expr="${esc(keep['in:' + i.name] !== undefined ? keep['in:' + i.name] : '')}" />`).join('\n');
    const outs = r.outputs.map(i => `    <output type="${esc(i.type)}" name="${esc(i.name)}" stage="${esc(keep['out:' + i.name] !== undefined ? keep['out:' + i.name] : '')}" />`).join('\n');
    const block = (r.inputs.length ? `<inputs>\n${ins}\n  </inputs>\n  ` : '') + (r.outputs.length ? `<outputs>\n${outs}\n  </outputs>\n  ` : '');
    b = replaceOrInsert(b, /<onsuccess>[^<]*<\/onsuccess>/, (block + (linkOf(st, 'onsuccess') ? `<onsuccess>${linkOf(st, 'onsuccess')}</onsuccess>` : '')).replace(/\n  $/, ''), afterFont(b));
    b = b.replace(/\n  \n/g, '\n').replace(/\s*$/, '') + `\n  <processid>${r.ssid}</processid>\n`;
  }
  if (e.language !== undefined) b = replaceOrInsert(b, /<language>[^<]*<\/language>/, `<language>${escText(e.language)}</language>`, /<\/imports>/);
  if (e.references !== undefined) b = replaceOrInsert(b, /<references>[\s\S]*?<\/references>/, '<references>\n' + e.references.map(r => `    <reference>${escText(r)}</reference>`).join('\n') + '\n  </references>', /<display [^>]*\/>/);
  if (e.imports !== undefined) b = replaceOrInsert(b, /<imports>[\s\S]*?<\/imports>/, '<imports>\n' + e.imports.map(r => `    <import>${escText(r)}</import>`).join('\n') + '\n  </imports>', /<\/references>/);
  if (e.loopdata !== undefined) b = replaceOrInsert(b, /<loopdata>[^<]*<\/loopdata>/, `<loopdata>${escText(e.loopdata)}</loopdata>`, /<looptype>[^<]*<\/looptype>/);
  if (e.note !== undefined) b = replaceOrInsert(b, /<note>[\s\S]*?<\/note>/, `<note>${escText(e.note)}</note>`, AFTER_HEAD);
  if (e.loginhibit !== undefined) {
    b = b.replace(/\s*<loginhibit[^>]*\/>/, '');
    if (e.loginhibit === 'off') b = b.replace(/(<subsheetid>[^<]*<\/subsheetid>)/, '$1\n  <loginhibit />');
    else if (e.loginhibit === 'error') b = b.replace(/(<subsheetid>[^<]*<\/subsheetid>)/, '$1\n  <loginhibit onsuccess="true" />');
  }
  return b;
}
function stageXml(st) { return `<stage stageid="${esc(st.id)}" name="${esc(st.name)}" type="${esc(st.type)}">${stageBody(st)}</stage>`; }
function serialize(m) {
  const byId = m.byId;
  const added = m.stages.filter(s => s.added && !s.deleted);
  const byPage = {}; for (const s of added) (byPage[s.page] = byPage[s.page] || []).push(s);
  // the file's last existing stage per page = where that page's new stages go
  const lastOf = {}; m.xml.replace(/<stage stageid="([^"]+)"/g, (w, id) => { const st = byId[id]; if (st && !st.added) lastOf[st.page] = id; return w; });
  const nl = /\r\n/.test(m.xml) ? '\r\n' : '\n';
  const tail = [];
  for (const pg of Object.keys(byPage)) if (!lastOf[pg]) tail.push(...byPage[pg]);
  let out = m.xml.replace(/([ \t]*)<stage stageid="([^"]+)" name="[^"]*" type="[^"]+">[\s\S]*?<\/stage>\r?\n?/g, (whole, indent, id) => {
    const st = byId[id]; if (!st) return whole;
    const end = whole.endsWith('\r\n') ? '\r\n' : whole.endsWith('\n') ? '\n' : '';
    let extra = '';
    for (const pg of Object.keys(lastOf)) if (lastOf[pg] === id && byPage[pg]) extra = byPage[pg].map(a => indent + stageXml(a) + nl).join('');
    if (st.deleted) return extra;
    return indent + stageXml(st) + end + extra;
  });
  if (tail.length) {
    const block = tail.map(a => stageXml(a) + nl).join('');
    const i = out.lastIndexOf('</stage>');
    if (i >= 0) { const j = out.indexOf('\n', i) + 1; out = out.slice(0, j) + block + out.slice(j); }
    else { const k = out.indexOf('<appdef'); const k2 = k >= 0 ? k : out.lastIndexOf('</process>'); out = out.slice(0, k2) + block + out.slice(k2); }
  }
  for (const ssid of m.removedPages || []) out = out.replace(new RegExp('[ \\t]*<subsheet subsheetid="' + ssid + '"[^>]*>[\\s\\S]*?</subsheet>\\r?\\n?'), '');
  for (const pg of m.addedPages || []) {
    const decl = `<subsheet subsheetid="${pg.ssid}" type="Normal" published="${pg.published ? 'true' : 'false'}">${nl}  <name>${esc(pg.name)}</name>${nl}  <view><camerax>0</camerax><cameray>0</cameray><zoom version="2">1.00</zoom></view>${nl}</subsheet>${nl}`;
    const i = out.lastIndexOf('</subsheet>');
    if (i >= 0) { const j = out.indexOf('\n', i) + 1; out = out.slice(0, j) + decl + out.slice(j); }
    else { const k = out.indexOf('<stage '); out = out.slice(0, k) + decl + out.slice(k); }
  }
  return out;
}
// a bp object for the renderer, with the CURRENT bodies (edits applied)
function bpOf(m) { return { name: m.name, type: m.type, pages: m.pages, elements: m.elements, stages: m.stages.filter(s => !s.deleted).map(s => ({ id: s.id, name: s.name, type: s.type, page: s.page, ssid: s.ssid, body: stageBody(s) })) }; }

// ---------- rules (the estate conventions the editor can check live) ----------
const EXC_TYPES = new Set(['System Exception', 'Business Exception', 'Runtime Exception']);
function checkRules(m) {
  const out = [], live = m.stages.filter(s => !s.deleted), byId = m.byId;
  const E = (st, msg) => out.push({ level: 'error', stage: st ? st.name : '', page: st ? st.page : '', msg });
  const W = (st, msg) => out.push({ level: 'warn', stage: st ? st.name : '', page: st ? st.page : '', msg });
  if (!live.some(s => s.type === 'ProcessInfo')) E(null, 'no Code Options (ProcessInfo) stage on the main page: objects null-ref at the first call, processes cannot be published');
  for (const pg of pagesOf(m)) {
    const ps = live.filter(s => s.page === pg);
    const nStart = ps.filter(s => s.type === 'Start').length, nEnd = ps.filter(s => s.type === 'End').length;
    if (!nStart) E(null, `page "${pg}" has no Start stage`);
    if (nStart > 1) E(null, `page "${pg}" has ${nStart} Start stages: Blue Prism allows exactly one (copied a page's contents? delete the extra Start)`);
    if (nEnd > 1 && m.type === 'process') W(null, `page "${pg}" has ${nEnd} End stages: legal, but the estate keeps one End per page`);
    if (!ps.some(s => s.type === 'End') && !ps.every(s => /^(SubSheetInfo|ProcessInfo|Data|Collection|Block|Note)$/.test(s.type))) E(null, `page "${pg}" has no End stage`);
  }
  for (const st of live) {
    if (m.type === 'process' && st.type === 'Code') E(st, 'Code stage in a process: Blue Prism never compiles code for a process, move it to a utility object');
    if (st.type === 'Decision' && !/\?$/.test(st.name)) E(st, 'Decision names must end with "?"');
    if (st.type === 'Exception') { const t = st.edits.exception ? st.edits.exception.type : attr((/<exception ([^>]*)\/>/.exec(st.orig.body) || ['', ''])[1], 'type'); const cur = /usecurrent="(yes|true)"/i.test(st.orig.body); if (!cur && !EXC_TYPES.has(t)) E(st, `exception type "${t}" is not System / Business / Runtime Exception`); }
    if (st.type === 'Collection' && !/(^|_)col_/.test(st.name)) W(st, 'collection names carry a col_ prefix');
    if (st.type === 'Calculation' && !/^[A-Z][\w&'-]*( [A-Z0-9][\w&'-]*)*$/.test(st.name)) W(st, 'Calculation names are <Verb> <Target> in Title Case');
    if (st.type === 'WaitStart' && !live.some(o => o.type === 'WaitEnd' && tag(o.orig.body, 'groupid').trim() === tag(st.orig.body, 'groupid').trim())) E(st, 'WaitStart without its WaitEnd (Time Out - ...)');
    for (const k of ['onsuccess', 'ontrue', 'onfalse']) { const v = linkOf(st, k); if (v && (!byId[v] || byId[v].deleted)) E(st, `${k} points at a stage that no longer exists`); }
    const needsOut = /^(Start|Action|Calculation|MultipleCalculation|Code|Navigate|Read|Write|SubSheet|Recover|Resume|Anchor|Alert|LoopEnd|ChoiceEnd|WaitEnd|LoopStart)$/.test(st.type);
    if (needsOut && !linkOf(st, 'onsuccess')) E(st, st.type + ' stage has no outgoing link');
    if (st.type === 'Decision' && (!linkOf(st, 'ontrue') || !linkOf(st, 'onfalse'))) E(st, 'Decision needs both a Yes and a No link');
    if (st.type === 'SubSheet') { const pid = st.edits.pagecall ? st.edits.pagecall.ssid : tag(st.orig.body, 'processid').trim(); if (!pid || !m.pages[pid]) E(st, 'calls a page that does not exist (pick one in its sheet)'); }
    if (/^(Loop|Wait|Choice)Start$/.test(st.type) && st.type !== 'WaitStart' && !partnerOf(m, st)) E(st, st.type + ' without its ' + st.type.replace('Start', 'End'));
    if (st.type === 'LoopStart' && !(st.edits.loopdata !== undefined ? st.edits.loopdata : tag(st.orig.body, 'loopdata').trim())) E(st, 'Loop has no collection to loop over');
  }
  // every non-start stage with flow should be reachable: anything no link points at
  const targets = new Set(); for (const st of live) for (const k of ['onsuccess', 'ontrue', 'onfalse']) { const v = linkOf(st, k); if (v) targets.add(v); }
  for (const st of live) if (/^(Action|Calculation|MultipleCalculation|Code|Navigate|Read|Write|SubSheet|Decision|Exception|End|Anchor|Alert)$/.test(st.type) && !targets.has(st.id) && !(st.type === 'Exception' || st.type === 'Resume')) {
    // recover and the choice points reach stages without a plain link tag; only flag when the page has no such source
    const pg = live.filter(s => s.page === st.page);
    if (!pg.some(s => /^(Recover|WaitStart|ChoiceStart)$/.test(s.type))) W(st, 'nothing links to this stage');
  }
  return out;
}

// ---------- version diff (node side, also usable in the page) ----------
function diff(prev, cur) {
  const out = { added: [], removed: [], moved: [], changed: [], renamed: [], changedIds: new Set() };
  const norm = b => b.replace(/<display [^>]*\/>/, '').replace(/\s+/g, ' ').trim();
  const pmap = Object.fromEntries(prev.stages.map(s => [s.id, s])), cmap = Object.fromEntries(cur.stages.map(s => [s.id, s]));
  for (const s of cur.stages) {
    const p = pmap[s.id];
    if (!p) { out.added.push(s); out.changedIds.add(s.id); continue; }
    if (p.name !== s.name) { out.renamed.push([p, s]); out.changedIds.add(s.id); }
    if (norm(p.body) !== norm(s.body)) { out.changed.push(s); out.changedIds.add(s.id); }
    else { const g1 = D.geom(p.body), g2 = D.geom(s.body); if (g1.x !== g2.x || g1.y !== g2.y || g1.w !== g2.w || g1.h !== g2.h) out.moved.push(s); }
  }
  for (const p of prev.stages) if (!cmap[p.id]) out.removed.push(p);
  return out;
}

const api = { membersOf, partnerOf, removePage, modelFrom, pagesOf, linkOf, move, resize, rename, setLink, remove, setField, stageBody, stageXml, serialize, bpOf, checkRules, diff, addStage, addPage, setResource, setPageCall, catalogFrom, template, guid, PALETTE, SIZE, DEFAULT_NAME };
if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.BPEDIT = api;
})(typeof window !== 'undefined' ? window : this);
