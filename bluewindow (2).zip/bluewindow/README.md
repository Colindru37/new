# bluewindow: Studio-lite for a Blue Prism export, offline, with history

One export .xml in, one self-contained .html out: every page drawn the way Studio draws it, a properties sheet
per stage, and editing: move stages, draw links, delete, change expressions, inputs, outputs, exception type and
detail, data item type and initial value, descriptions, logging. Save produces the next version's .xml; render it
and the history grows by one .html with a diff ribbon against the previous version. Needs node only; the browser
is Edge or anything else, no network.

## Everyday use (standalone: this folder is all it needs, plus node; python for the two checks)
1. Double-click `bluewindow.cmd` (or run `node bluewindow.js`). A window stays open and Edge opens the home page.
   If .cmd files are blocked: make a desktop shortcut to `node.exe "<this folder>\bluewindow.js"`, or type that command.
2. Put Blue Prism exports in `inbox\` (or drag them onto the home page), as many as you like. Each one is rendered by
   itself, one after the other, and appears under Projects; the page updates live. **Open** opens a project in a new tab.
   A file that is not a process/object export stays in the inbox marked skipped. Same name again = the next version.
3. Edit, click **Save**: the next version goes straight into `projects\<name>\<name>.vN.xml`, renders, and reopens
   with the diff against the previous one. Import that .vN.xml into Blue Prism. The home page lists every project
   with its versions.
Releases: a `.bprelease` in the inbox becomes a release (home page, Releases). Its page lists every member; **Open** a
member to see/edit it like any export (its objects fill the action catalog), Save as usual, then **Build release**:
`release.vN.bprelease` = the original with only the edited members' definitions replaced, every other byte identical
(other items, BOM, line endings, odd control characters). Release checks: each Action stage of a process member must
call an object in the release (warning otherwise) and an action that object publishes (error). Blue Prism internal
objects are skipped. Links are drawn straight, as Studio does; only a link whose straight line would cross another stage gets an elbow route
around it (and two such routes never share a stretch). If no clean route exists it stays straight. Loop back-links keep their curve.
A trimmed release also opens as its own release ("<name> trimmed"). Every imported release renders all its members:
processes first, then the objects in the background one at a time (progress on the release page; it carries on after a restart). A release that is already imported stays in the inbox, marked; nothing is ever deleted.
**Trim**: the release page shows how many objects the processes actually use (following what those objects call in
turn) and builds a release with only those (other items kept as they are, edits included). Import the built release into a DEV environment first.
Settings (all optional) in `bluewindow.json`, see `bluewindow.json.example`: `bp` = Blue Prism install folder for the
exact compile check (otherwise found in Program Files automatically), `with` = folders of object exports for the
action catalog, `inbox`, `projects`, `port` (7788), `browser`. No environment variables needed.
`lib\validate.py` + `lib\compile_check.py` are copies of the rpa-bp skill's (the test checks they are identical).

Scripted use, unchanged:
```
node bluewindow.js render "BPA Process - X.xml" [--out <folder>] [--incident incident.json] [--with <objects folder>] [--bp "<Blue Prism folder>"]
   -> <folder>/X/X.v1.xml  (copied)   <folder>/X/X.v1.html  (the editor)
node bluewindow.js watch <folder> [--downloads %USERPROFILE%\Downloads]
   -> every X.vN.xml the editor saved is picked up (moved out of Downloads when told) and rendered as X.vN.html
```
An .html opened straight from disk (no server) still saves as a download, as before.

Keys: V select/move, L link, D delete, A place an Action, Ctrl+Z undo, Del deletes the selection, Esc cancels/closes.
The Checks button opens two columns: the live rules the browser checks while you edit (errors block Save) and
the full `validate.py --flow --estate --strict` verdict for this version, run when the page was rendered.
Each version shows what changed: added, removed, renamed, changed, moved; changed stages are outlined orange.

What the round trip guarantees: every stage keeps its original XML and only the edited parts are rewritten, so an
untouched stage is byte-identical after any number of versions, and the rest of the file (application model, code
options, page declarations) is never touched. The test proves it on a real export.

Rules checked live, errors block Save: Code Options stage present; no Code stage in a process; Decision names end
with `?`; exception types are System / Business / Runtime; exactly one Start on every page (the palette refuses a second one) and an End; every flow stage has an
outgoing link, Decisions both Yes and No; links point at stages that exist; WaitStart has its WaitEnd. Warnings:
`col_` prefix on collections, Title Case calculations, stages nothing links to. `validate.py --flow --estate --strict`
runs on every render when python and the skill lib are reachable (this folder lives in the skill, so it is).

Adding (slice 2): `+ page` makes a page with its declaration, SubSheetInfo, Start and End. The palette under the
pages lists every stage kind (templates = the verified shapes in reference/stage-schemas.md): click a kind, click
the page, the stage is there and its sheet opens; `A` is the shortcut for an Action. An Action's sheet offers the
Business Object and Action as pick-lists with the inputs/outputs the action really has, from the catalog: every
object export found next to the .xml, in the out folder, or in `--with <folder>` at render time. A Page call's
sheet offers the pages of this process, parameters from that page's Start/End. New stages are inserted after the
last stage of their page, new pages after the last declaration; the rest of the file still never moves.

Geometry (slice 3): drag on empty canvas selects many (Shift+click adds), the selection moves together and Del
removes it. A Block moves what is inside it (membership is geometric, as in Studio) and has a corner handle to
resize, so does a Note. Placing a Loop start places its Loop end with the same groupid; deleting one removes
the pair; the loop's collection is in its sheet. `- page` removes the open page, its declaration goes with it
and page calls that pointed at it turn into an error in Checks. The `?` button lists the keys.

Info boxes and code: the page info box (SubSheetInfo) and the object's Code Options (ProcessInfo) are drawn like
Studio draws them and open in the sheet: description, language, references, namespaces, shared code. On every
render of an object `compile_check.py` compiles its code stages + shared code; pass `--bp "<Blue Prism install
folder>"` (or set BP_HOME) and it uses Blue Prism's own Roslyn csc.exe and DLLs from that folder, exactly what
Studio compiles; without it a development compiler answers and the Checks panel says so. A compile failure
counts as a problem on the Checks button.

Grid: on by default, G toggles. Stages snap to Studio's 15px grid on move and resize and the dots show it. Off =
free placement; Blue Prism imports either, the grid is only how Studio looks. Shift+L toggles the light look, which
uses Blue Prism Studio's own plain shapes and colours; dark is the default. Ctrl+wheel zooms.

Not yet: new application model elements (spying stays in Studio).

Sheriff's sketch and this editor share the renderer (bpdraw.js). Sheriff ships its own frozen copy.
