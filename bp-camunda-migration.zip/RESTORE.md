# Restore placeholders (laptop side)

Public transfer: these house names were replaced. Find -> replace back, in this order, AFTER `python selftest.py` passes:

| placeholder | original |
|---|---|
| `<PROCESS-A NAME>` | `Upload Datasheets for KYC RR` |
| `<PROCESS-A NAME>` | `Upload Datasheets` |
| `PROC-A` | `DB161` |
| `AREA-A` | `KYC RR` |
| `APP-C` | `Glue-PartnerData` |
| `APP-B` | `MyWorkspace` |
| `APP-A` | `Orinoco` |
| `GROUP-A` | `IDAM_RPA` |

Files touched: RESTORE.md
