# Mapping Blue Prism control flow → target error boundaries

Target-neutral design note. It maps the three control-flow structures the
analyzer now lifts out of a Blue Prism export — loops, exception handlers, and
cross-page exception propagation — onto the generic, BPMN-shaped constructs any
workflow engine provides (subprocesses, boundary events, call activities). It is
deliberately written against *no* specific target: when the uFlow ingest format
is known, each row of the mapping table binds to a concrete uFlow element, and
the risk register says where a faithful binding may not exist.

Everything here is grounded in what the analyzer already emits — the
`loop_regions`, `exception_handlers`, and `exception_propagation` sections of
`estate.json`, produced by `src/bp_estate/regions.py` — and in Blue Prism's
**confirmed** exception semantics (see below). Nothing is speculative about how
BP behaves; the open questions are all about the *target*.

## Confirmed Blue Prism semantics this rests on

1. **`Resume` ends recovery mode** and clears the exception; flow continues
   normally after it.
2. **Recovers are not 1:1 with Resumes.** Several Recovers can funnel into one
   shared handling flow; a Recover with no Resume never clears the exception.
   (On the real 1109-stage process: 23 Recovers, 21 resuming, 2 escaping.)
3. **No Resume ⇒ the exception propagates up the call stack** — out of the page
   to its caller, and on up until some caller catches it or the session
   terminates (`ExceptionHandler.escapes`, then `exception_propagation`).
4. **Recovery scope is GEOMETRIC — Block containment (confirmed on real data).**
   The scope a Recover protects is the `Block` stage it sits inside. This was
   ground-truthed against the 1109-stage process, after two wrong guesses were
   killed by the data:
   - A documentation answer said catch is forward link-flow → DISPROVEN: every
     one of the 23 Recovers had an empty backward-reachable set; **Recover stages
     have no inbound links.**
   - Document order (guard the stages after the Recover to the next
     Recover/Resume) → DISPROVEN: that gap ranged 0..80 (avg ~8, several 0) — not
     a scope.
   - Block containment → CONFIRMED: a Recover is a POINT (23/23 had a `<display>`
     with x,y but **no w,h**), and **22/23 Recovers sat inside a `Block`
     rectangle** (the lone loose one is the top-level, last-resort handler that
     protects the whole page). Block sizes were 1..38 stages (avg ~14) — a real
     region. The Resume is placed OUTSIDE the Block (0/22 Blocks-with-a-Recover
     contained their Resume): recovery exits the scope, then Resume re-enters
     normal flow. So the TRY scope is geometric and the CATCH is link-flow — two
     orthogonal facts, both now supplied by the analyzer
     (`scope_block`/`scope_stage_count` and `recovery_path`/`resumes`).

## The mapping

| Blue Prism construct | Analyzer field(s) | Target-neutral (BPMN-shaped) construct |
|---|---|---|
| `LoopStart`/`LoopEnd` bracket over a collection | `LoopRegion.collection`, `body_stage_count`, `start_stage`/`end_stage` | **Sequential multi-instance subprocess** iterating the collection; the body stages become its content |
| `Recover` (handler entry) | `ExceptionHandler.recover_stage`, `scope_block`, `scope_stage_count` | **Interrupting error boundary event** on the scope of the enclosing `Block` (→ a subprocess); `scope_kind = "page"` means it attaches to the whole page (last-resort handler) |
| Recovery flow | `ExceptionHandler.recovery_path` | The boundary event's **outgoing handler flow** |
| `Resume` reached | `resumes = true` | Handler **rejoins normal flow** after the scope (error handled, continue) |
| No `Resume` | `escapes = true` | Handler ends in an **error end event** (re-raise / escalate to the parent scope) |
| `Exception` stage (a throw) | `exception_type` (System/Business), `exception_detail` | **Throw / error end event**, typed by System vs Business (distinct error codes) |
| `SubSheet` call / `Action` call receiving an escape | `ExceptionPropagation` (from/to page, `via_stage`, `kind`) | **Call activity** at which the escaped error surfaces — the site to attach an interrupting error boundary. Whether BP catches it there is now decidable: it does iff the call site falls inside a `Block` that also holds a Recover (the caller's geometric scope) |

### Loops

A BP loop is a strictly sequential for-each over the rows of a collection. That
is a **sequential multi-instance subprocess**: `loopDataInputRef` = the
`collection` (a BP expression, kept verbatim — resolve it to a concrete
collection at emit time), the subprocess body = the stages the analyzer counted
between the brackets. Sequential, never parallel: BP processes one row at a time
and later rows may depend on earlier side effects.

An unmatched bracket (`LoopRegion.resolved = false`) is a **malformed loop** —
surface it for manual review; do not emit a loop with no terminator.

### Exception handlers

BP recovery scope is a `Block` rectangle, which is exactly BPMN's block-structured
model (a boundary event attaches to a *scope*), so the binding is direct. The
analyzer supplies both halves: the TRY scope (`scope_block` / `scope_stage_count`,
or `scope_kind = "page"` for a last-resort handler) → the subprocess the boundary
attaches to; and the CATCH (`recover_stage`, `recovery_path`, `resumes`/`escapes`)
→ the boundary's handler flow. `resumes` decides the tail — rejoin (handled) vs.
error end event (re-raise); several Recovers sharing one handler still become
several boundary events into one handler subprocess. The Resume sitting OUTSIDE
the Block is expected — it is the "continue normal flow after the scope" target,
i.e. the boundary's outgoing normal path, not part of the protected region.

### Cross-page / cross-artifact propagation

Each `exception_propagation` row marks **where an escaped error surfaces** — a
BPMN **call activity** at which to attach an interrupting error boundary. It is
one hop (escaping page → its direct call sites). Whether the caller catches it is
now decidable per site: the call site is caught iff it falls inside a `Block`
that holds a Recover (the caller's geometric scope). The rows still tell the
emitter *where the boundaries go*; the catch-here-vs-propagate decision is a
containment test the emitter runs against the same Block geometry.

## Risk register (where a faithful binding may not exist)

- **Non-SESE scopes.** A `Block` is a rectangle, not guaranteed to be a
  single-entry/single-exit region, which a BPMN scope needs. Flow may enter or
  leave a Block mid-region. The emitter restructures such a Block into a
  subprocess or falls back to an event subprocess; flag Blocks whose boundary is
  crossed by a link at emit time. (This is now the biggest open item — the scope
  itself is known; making it SESE is the remaining work.)
- **Nested Blocks.** A Recover inside nested Blocks is scoped to the SMALLEST
  (innermost) one. Confirm the emitter honours nesting when a Block sits inside
  another Block's rectangle; the analyzer already picks the innermost by area.
- **Typed errors.** System vs Business Exception must map to distinct target
  error definitions/codes; a target without typed errors needs a convention
  (e.g. an error-code data field) to preserve the distinction.
- **Multi-instance semantics.** If the target lacks sequential multi-instance,
  loops fall back to an explicit while + collection-cursor pattern.

## Gated on the uFlow ingest format (the only open dependency)

Binding this note to a concrete emitter needs to know, for the target:
1. the ingest syntax (BPMN XML? proprietary JSON/DSL? an API?);
2. whether it supports **error boundary events**, **sequential multi-instance
   loops**, **call activities**, **typed errors**, and **error propagation
   across called processes**; and
3. whether it is **block-structured** (needs the SESE restructuring above) or
   **graph-based** (can mirror BP's flow more directly, less restructuring).

Until those are answered, the analyzer output is target-neutral and complete for
this layer; this note is the contract the emitter will implement against.
