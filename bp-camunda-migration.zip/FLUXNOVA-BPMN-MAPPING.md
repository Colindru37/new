# Blue Prism → Fluxnova (Camunda 7) BPMN emission map

> **2026-10-19:** the emitted contract as it is NOW (page calls with mapped parameters, `Object::item` state, `Init:` tasks, script slots, `Coll#row`, `bpErrorCode`/`bpErrorMessage`, per-throw errors) is in `skill-bp-to-camunda/reference/conventions.md`. Where this document and that file disagree, that file is right; this one keeps the reasoning.

The concrete emitter contract. It binds every construct the estate analyzer lifts
out of a Blue Prism export to a specific BPMN 2.0 element and vendor-extension
attribute, targeting **Fluxnova** — the FINOS fork of **Camunda 7** Community
Edition that Deutsche Bank co-maintains.

This **supersedes DESIGN.md §8–9 and §10**, which were written against Camunda 8 /
Zeebe / FEEL before the target was known. Two corrections propagate through
everything below:

- **It is Camunda 7, not 8.** Process-level expressions are **JUEL** (`${...}`),
  not FEEL. FEEL appears *only* inside DMN decision tables.
- **Service work binds as an external task**, not a Zeebe job worker — the
  `camunda:type="external"` + `camunda:topic` pattern.

It builds on, and does not repeat, `EXCEPTION-LOOP-MAPPING.md`, which already
grounds loops / exception handlers / cross-page propagation in the analyzer's
`loop_regions`, `exception_handlers`, and `exception_propagation` sections. Where
that note said "when the target format is known, each row binds to a concrete
element" — this doc *is* that binding.

---

## 1. Locked target conventions (from the fork's source, not the brochure)

Read directly from `finos/fluxnova-bpm-platform` (`BpmnModelConstants.java`, module
layout, external-task client) on 2026-08-13:

| Concern | Value |
|---|---|
| Standard BPMN 2.0 namespace | `http://www.omg.org/spec/BPMN/20100524/MODEL` — unchanged |
| DI namespaces | OMG `BPMNDI` / `DC` / `DI` — unchanged |
| Vendor extension namespace | **both** retained: `camunda:` = `http://camunda.org/schema/1.0/bpmn`, `fluxnova:` = `http://fluxnova.finos.org/schema/1.0/bpmn` (identical local names) |
| Engine | Spring Boot, Java 21; module layout = stock Camunda 7 (`engine`, `engine-rest`, `engine-dmn`, `model-api/bpmn-model`, `webapps`, `spring-boot-starter`, `quarkus-extension`) |
| Java packages | renamed `org.camunda` → `org.finos.fluxnova` (engine-side only — does **not** touch our XML) |
| Service binding | external-task client shipped (`clients/java/client`) → external tasks are first-class |
| Expression language | Camunda 7 JUEL `${...}` at process level; FEEL in DMN only |

### The namespace decision

The vendor-extension attribute **local names are identical** across `camunda:` and
`fluxnova:` — only the URI differs. So the emitter carries the extension namespace
in **one config constant**:

- **Default: `fluxnova:`** — target-native, forward-proof against a future
  deprecation of the compat `camunda:` namespace.
- **`--ns camunda` flag** — for tooling interop (Camunda Modeler, bpmn.io, a local
  Camunda 7 "Run" jar). Because Fluxnova *retains* `CAMUNDA_NS`, a `camunda:`
  file we emit **deploys to Fluxnova unmodified today** — which is what lets us
  validate against a free local Camunda 7 before Fluxnova is even reachable.

Everything downstream references `EXT_NS`; nothing hard-codes `camunda:`.

---

## 2. Stage-by-stage mapping

Confidence: **High** = mechanical, deterministic; **Medium** = deterministic but a
semantic hazard flagged in §5; **Blocker** = never auto-converted, surfaced for a
human.

| Blue Prism | Analyzer field(s) | BPMN element | Conf. | Binding notes |
|---|---|---|---|---|
| Process / page (`SubSheet`) | `artifact`, `pages[]` | `process` (top page) / `subProcess` or callable `process` (sub-pages) | High | "Main Page" → the process; other pages → callable processes referenced by call activity |
| Page reference (`<processid>`) | IR `PageRef {in[], out[]}` | `callActivity calledElement=…` | High | **Thread ALL data items, incl. implicitly read**, via `EXT:in`/`EXT:out` (§3) |
| Start / End | stage type `Start`/`End` | `startEvent` / `endEvent` | High | Multiple End stages → multiple end events (or one, joined) |
| Decision (`ChoiceStart` 2-way) | `expr` | `exclusiveGateway` (2 flows) | High | `conditionExpression` = translated JUEL (§4); `default` = the false branch |
| Choice (`ChoiceStart`/`ChoiceEnd`, n-way) | `branches[]` **ORDERED** | `exclusiveGateway` (n flows) | Medium | **Preserve top-down priority**; emit conditions so exactly one wins; last = `default`. R1 |
| Calculation | `expr`, `target` | `scriptTask` (or inline on a flow) writing one var | Medium | One assignment; JUEL or a `groovy`/`feel`-free script; unknown fn → hard fail (§4) |
| Multiple Calculation (`MultipleCalculation`) | ordered `{expr,target}[]` | `scriptTask` with N ordered assignments | Medium | Order matters (later rows read earlier targets) — keep sequence |
| Loop (`LoopStart`/`LoopEnd`) over a collection | `LoopRegion.collection`, `body_stage_count` | sequential **multi-instance** `subProcess` | Medium | `isSequential="true"`; `EXT:collection` + `EXT:elementVariable` (§3). Unmatched bracket → manual. See EXCEPTION-LOOP §Loops |
| Action → **internal** VBO (Work Queues / Credentials / Env-Lock / Collections) | `object_tier="internal"`, detector | native BPMN feature (see §2a) | High/Medium | Not a service task — maps to queue pattern, vault ref, lock, or data op |
| Action → **shipped** VBO (Excel/Outlook/PDF/…) | `object_tier="shipped"` | external `serviceTask` (topic = connector) | Medium | Re-host as a connector/worker; topic names the capability |
| Action → **custom** VBO (UI automation) | `object_tier="custom"` | external `serviceTask` **stub** | Medium | The RPA re-host seam (§3); topic = `object.action`; carries the `ActionSpec` as documentation |
| Data item | `data_items[]` `{name,type,scope}` | process variable (typed, §6) | High | session scope → process var; local → block-scoped |
| Work queue | `queues[]` | queue/item pattern | Medium | BP retry ≠ engine retry; item status = idempotency guard. R8 |
| Exception stage (throw) | `exception_type` (System/Business), `exception_detail` | `error endEvent` / intermediate throw, typed | Medium | System vs Business → distinct `bpmn:error` codes (§5) |
| Recover (handler entry) | `scope_block`, `recovery_path` | interrupting **error boundary event** on the scope subprocess | Medium | See EXCEPTION-LOOP §Exception handlers — TRY = Block geometry, CATCH = link-flow |
| Resume reached | `resumes=true` | boundary's outgoing **normal** flow (error handled) | Medium | Resume sits *outside* the Block by design |
| No Resume | `escapes=true` | `error endEvent` (re-raise to parent scope) | Medium | Propagates up call stack (§ propagation) |
| Cross-page propagation | `exception_propagation[]` | error boundary on the `callActivity` where it surfaces | Medium | Catch-here iff the call site is inside a Block holding a Recover |
| Environment lock | internal-VBO detector | **external distributed lock** | Blocker-ish | **No native BPMN equivalent** — external lock service + flag. R14 |
| Credentials VBO | detector | vault lookup at run time | High | Never a plaintext variable; `Password` type → PII/vault path |
| Code stage / DLL | `blockers` (code-stage) | **BLOCKER** — surfaced, never emitted | Blocker | R4 — a `.NET`/VB fragment has no faithful BPMN form |
| Wait / timer | `Wait {condition,timeout}` | `timerEvent` / `receiveTask` | Medium | Condition wait → message/receive; fixed wait → timer |
| Manual / approval queue item | human-step detection | **`userTask`** | Medium | Do NOT auto-classify as a service task; preserves SoD / four-eyes. R9 |
| Note / Anchor / Block (non-scope) | — | dropped / lane hint / subprocess boundary | High | Notes are documentation; Anchors are routing only; a Block that isn't a recovery scope is a grouping hint |

### 2a. Internal-VBO calls do NOT become service tasks

The three object tiers (from `vbo_registry.yaml`) route differently — this is the
single most important classification, because misfiling an internal call as a
service task both invents a nonexistent integration and hides a native feature:

- **internal** (`clsWorkQueuesActions`, `clsCredentialsActions`,
  `clsEnvLockingActions`, `clsCollectionActions`) → a **native construct**: queue
  pattern, vault lookup, external lock, or an in-model data operation.
- **shipped** (Excel/Outlook/PDF/Web Services) → an **external `serviceTask`**
  bound to a connector/worker (a real integration exists to re-point).
- **custom** → an **external `serviceTask` stub** — the UI automation that must be
  re-hosted or replaced by an API. This is where the VMs actually die.

---

## 3. Emission patterns (the load-bearing XML)

Namespace prefix shown as `ext:` = the configured `EXT_NS` (`fluxnova:` default).

**Custom/shipped VBO call → external service task** (the RPA re-host seam):

```xml
<bpmn:serviceTask id="Task_ValidateIban" name="Validate IBAN"
                  ext:type="external" ext:topic="orinoco.validate-iban">
  <bpmn:extensionElements>
    <ext:inputOutput>
      <ext:inputParameter name="iban">${customerIban}</ext:inputParameter>
      <ext:outputParameter name="ibanValid">${result.valid}</ext:outputParameter>
    </ext:inputOutput>
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

**Choice (n-way) → priority-preserving exclusive gateway:**

```xml
<bpmn:exclusiveGateway id="Gw_Route" default="Flow_else"/>
<bpmn:sequenceFlow id="Flow_high" sourceRef="Gw_Route" targetRef="...">
  <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression"
    >${amount &gt; 100000}</bpmn:conditionExpression>
</bpmn:sequenceFlow>
<bpmn:sequenceFlow id="Flow_mid" sourceRef="Gw_Route" targetRef="...">
  <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression"
    >${amount &gt; 1000}</bpmn:conditionExpression>
</bpmn:sequenceFlow>
<bpmn:sequenceFlow id="Flow_else" sourceRef="Gw_Route" targetRef="..."/>
```

Branches are emitted in BP's top-down order; `default` is the terminal else so the
gateway is total (never a stuck token). R1's mutual-exclusion check runs at emit.

**Loop → sequential multi-instance subprocess:**

```xml
<bpmn:subProcess id="Sub_ForEachRow">
  <bpmn:multiInstanceLoopCharacteristics isSequential="true"
      ext:collection="${invoiceRows}" ext:elementVariable="row"/>
  <!-- body stages the analyzer counted between the brackets -->
</bpmn:subProcess>
```

Sequential, never parallel — BP processes one row at a time and later rows may
depend on earlier side effects (R7).

**Recover → interrupting error boundary on the scope subprocess:**

```xml
<bpmn:subProcess id="Sub_Block17"><!-- the Block's stages --></bpmn:subProcess>
<bpmn:boundaryEvent id="Bnd_Recover" attachedToRef="Sub_Block17" cancelActivity="true">
  <bpmn:errorEventDefinition errorRef="Err_Business"/>
</bpmn:boundaryEvent>
<bpmn:error id="Err_Business" name="BusinessException" errorCode="BP_BUSINESS"/>
<bpmn:error id="Err_System"   name="SystemException"   errorCode="BP_SYSTEM"/>
```

`resumes=true` → the boundary's outgoing flow rejoins normal flow after the scope;
`escapes=true` → it ends in an `error endEvent` re-raising to the parent.

**Page reference → call activity, threading all vars:**

```xml
<bpmn:callActivity id="Call_PostPayment" calledElement="PostPayment">
  <bpmn:extensionElements>
    <ext:in  source="paymentId"     target="paymentId"/>
    <ext:in  source="ledgerContext" target="ledgerContext"/>
    <ext:out source="postingRef"    target="postingRef"/>
  </bpmn:extensionElements>
</bpmn:callActivity>
```

Explicit per-variable `in`/`out` (not `variables="all"`) so R5 — implicitly-read
globals silently dropped — is caught by the analyzer's data-flow set, not left to
the engine's ambient scope.

---

## 4. Expression translation — JUEL, not FEEL

- BP expression language is VBA/VBScript-flavored (`&` concat, `Left`, `Mid`,
  `Trim`, `Today`, `Now`, `IsNull`, …). Target at process level is **Camunda 7
  JUEL** (`${...}`), the language of `conditionExpression` and inline task
  expressions.
- Strategy unchanged from DESIGN §9: a **curated mapping table**, never LLM
  guessing. Unknown function → **hard fail**, flagged for manual translation. No
  invented equivalents. Keep a golden set of `BP expr → JUEL` pairs as regression
  tests.
- **Where JUEL is a poor fit** (string-heavy manipulation, `Mid`/`InStr` chains):
  emit a `scriptTask` instead of an inline expression, keeping the BP source
  verbatim in a comment for review. Do not stretch JUEL past readability.
- **DMN is the escape hatch for decision-heavy Choices.** A large ordered Choice
  that is really a decision table → a DMN table (where **FEEL** is correct) called
  via `businessRuleTask`. Optional, flagged, never automatic.

---

## 5. Semantic hazards carried forward (unchanged, still critical)

These are the DESIGN §11 risks that the mapping must actively defend, not the
"schema-valid ⇒ done" illusion (R11):

- **R6 Money math — Camunda 7 has no decimal variable type.** BP `Number` = .NET
  `decimal`; the engine's numeric vars are `integer`/`long`/`double`. **Never
  carry money as `double`.** Money variables are typed objects (serialized
  `BigDecimal`) or explicit decimal-string with parse/format at every boundary.
  Financial test cases gate this.
- **R1 Choice ordering** — priority-preserving gateway + mutual-exclusion check.
- **R2 Exception mis-scope** — manual review gate on every Recover/Resume; the
  Block-geometry scope (EXCEPTION-LOOP §4) makes the TRY precise, but the CATCH
  rejoin still needs eyes.
- **R8 Idempotency** — reconstruct queue-status guards; item status is the
  double-post guard, not decoration.
- **R9 Human step** — approval/manual queue items → `userTask`, never a service
  task; SoD / four-eyes preserved.
- **Typed errors** — System vs Business must be distinct `bpmn:error` codes so a
  handler can discriminate.
- **Dates/timezones** — `Today()`/`Now()` were resource-VM local time; make TZ and
  business-calendar explicit.

---

## 6. Data & type mapping (BP datatype → engine variable)

| BP datatype | Engine variable | Note |
|---|---|---|
| Text | `String` | |
| Number | **serialized `BigDecimal` / decimal-string** | **never `double`** — R6 |
| Flag | `Boolean` | |
| Date / DateTime / Time | `Date` (+ explicit TZ) | preserve Date vs DateTime vs Time distinction |
| TimeSpan | ISO-8601 `Duration` | |
| Password | **vault reference, not a variable** | PII path; withheld from any emitted value |
| Binary / Image | `bytes` / file ref | |
| Collection | JSON object / `List<Map>` | model the current-row pointer for loops |

---

## 7. Validation

- **Structural** — validate against the BPMN 2.0 XSD; no dangling tokens, joins
  matched, every gateway total.
- **Deploy check** — emit with `--ns camunda` and deploy to a local Camunda 7 "Run"
  jar (free, no Fluxnova access needed); a clean deployment proves the XML is
  engine-valid. Then re-emit `fluxnova:` for delivery.
- **Semantic** — golden set of `BP fragment → expected BPMN + JUEL`, regression
  tested.
- **Coverage** — every stage classified converted / stubbed / blocked with a
  reason; no stage unaccounted for (mirrors the stage-ledger discipline from the
  documentation pipeline).

---

## 8. Biggest open item (unchanged from EXCEPTION-LOOP §Risk)

**SESE restructuring.** A BP `Block` is a rectangle, not guaranteed single-entry /
single-exit, which a BPMN scope needs. Flow may cross a Block boundary mid-region.
The emitter restructures such Blocks into a subprocess (or an event subprocess) and
**flags any Block whose boundary a link crosses**. The scope itself is known
(geometry); making it SESE is the remaining engineering. This is the one place the
mapping is "known but not yet mechanical."
