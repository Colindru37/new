// Port of Code stage "Build Task RITM URL" (GK Revoke ServiceNow).
// Uri.EscapeDataString escapes everything but RFC 3986 unreserved (A-Z a-z 0-9 - _ . ~);
// encodeURIComponent leaves ! * ' ( ) alone, so they are escaped by hand.
function escapeDataString(s) {
  return encodeURIComponent(s).replace(/[!'()*]/g, function (c) {
    return '%' + c.charCodeAt(0).toString(16).toUpperCase();
  });
}
var u = String(execution.getVariable('SNOW_URL')).trim();
var q = u.indexOf('?'); if (q >= 0) u = u.substring(0, q);
u = u.substring(0, u.lastIndexOf('/') + 1);
var ritm = execution.getVariable('RITM'); ritm = (ritm == null ? '' : String(ritm)).trim();
execution.setVariable('RITM_URL', u + 'nav_to.do?uri=%2Fsc_req_item.do%3Fsysparm_query%3Dnumber%3D' + escapeDataString(ritm));
