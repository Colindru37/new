// inputs: SNOW_URL (text), RITM (text)   output: RITM_URL (text)
// the instance root = the folder nav_to.do lives in (https://host/ on the estate)
string u = SNOW_URL.Trim();
int q = u.IndexOf('?'); if (q >= 0) u = u.Substring(0, q);
u = u.Substring(0, u.LastIndexOf('/') + 1);
RITM_URL = u + "nav_to.do?uri=%2Fsc_req_item.do%3Fsysparm_query%3Dnumber%3D" + Uri.EscapeDataString((RITM ?? "").Trim());
