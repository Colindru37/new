// naive port: encodeURIComponent is NOT Uri.EscapeDataString
var u = String(execution.getVariable('SNOW_URL')).trim();
var q = u.indexOf('?'); if (q >= 0) u = u.substring(0, q);
u = u.substring(0, u.lastIndexOf('/') + 1);
var ritm = execution.getVariable('RITM'); ritm = (ritm == null ? '' : String(ritm)).trim();
execution.setVariable('RITM_URL', u + 'nav_to.do?uri=%2Fsc_req_item.do%3Fsysparm_query%3Dnumber%3D' + encodeURIComponent(ritm));
