# Prompt for GitHub Copilot: finish one Blue Prism -> Camunda migration

Paste everything below the line into Copilot Chat (VS Code, agent/edit mode if
available) with this folder open. Fill the two paths. Copilot cannot run
commands on this machine: it writes the files, you run the commands and paste
the output back when it asks. Keep that loop short: one command, its output,
next step.

---

You are finishing a Blue Prism to Camunda 7 (Fluxnova) migration. A
deterministic toolchain in this folder has already converted the process; your
job is only what it deliberately leaves open, and every open item is labelled
in the output. Read `skill-bp-to-camunda/SKILL.md` first, then
`skill-bp-to-camunda/reference/conventions.md` and
`reference/modelling-rules.md`. Follow `skill-copilot-discipline/SKILL.md`:
map, ask, plan, do, verify, report; never guess, never paraphrase a file you
were asked to copy.

Inputs:
- process export: `PROCESS=<path to m.bprelease>`
- object pack (all objects; the tool keeps only the ones the process uses):
  `OBJECTS=<path to r.bprelease>`

## Step 0. Run the toolchain (I run, you read)

Ask me to run these and paste the output:

```
python selftest.py
python migrate.py --process PROCESS --objects OBJECTS -o out_bpmn
python audit3.py out_bpmn
python tools/bpmn_lint.py out_bpmn
python port/bp_equiv.py PROCESS OBJECTS --objects --per-artifact
```

Then read `out_bpmn/REPORT.md` (what migrated, what is blocked and why, which
objects were kept). `out_bpmn/<Process>.bpmn` is the process,
`out_bpmn/objects/*.bpmn` the objects that convert, `out_bpmn/api_facts_ui.json`
the ledger of objects that need an API instead of UI automation.

How to read the measurements, so you do not chase ghosts:
- `bp_equiv` rows `orphan nodes: source stage HAD inflow` and
  `dead-end nodes: source stage HAD outflow` are the only reachability rows
  that are a conversion defect. `no inflow/outflow in Blue Prism either` is
  dead on the source page too: list them in the report, do not fix them.
  `synthetic` rows must be 0; if not, stop and report (that is an emitter bug,
  not yours to patch in the BPMN).
- `bp_equiv` runs on the whole object pack, so its `TOTAL` is noise; read the
  table for the process and for the objects `REPORT.md` kept.
- `bpmn_lint`: every `ERROR` is yours to resolve; `WARN` you judge;
  `CODE-SLOT-UNPORTED (INFO) xN` is the size of the work list.
- A page whose first documentation line starts `regions left flat (partial
  overlap, not nestable)` is a Block drawn across a loop in Blue Prism; the
  stages are emitted flat. Say so in the report; do not hand-build a scope.

## Step 1. Inventory, before any change

Produce one table of every open item, grouped by kind, with the BPMN file,
element id and name. Kinds, in this order of value:

1. **Script slots**: `scriptTask` named `[SLOT code ...]`; body throws
   `TODO port`; the original C# is in its `<documentation>`.
2. **Workers**: `serviceTask` with topic `code.<object>.<stage>` (code that
   reaches outside the engine) and topic `<object>.<action>` (an object not in
   the export: Work Queues, Credentials, un-exported VBOs).
3. **Manual conditions**: sequence flows with `${TODO_manual_condition}`; the
   gateway's `<documentation>` holds the Blue Prism expression.
4. **Manual parameters**: `<documentation>` lines `in <param> = ... (manual:
   ...)` on call activities and service tasks.
5. **Lint ERRORs**: `LOOP-BOUNDED` (a back-flow without a counter/collection
   gateway), `NAME-DEFAULT` (default names from the source), anything else.
6. **Unsupported functions**: the `functions in failed expressions:` line of
   `bp_equiv`, ranked by count. These decide what the slots and conditions
   will need most.

Ask me (reference/questions.md) before touching a kind whose answer changes
the work: which items are in scope for this hand-over, whether an engine is
reachable for the gate (`--url`), and which object actions already have an
API on the Camunda side.

## Step 2. Cover the holes, in this order

For each item, work in this order and stop at the first one that fails its
check; report, do not continue on a broken base.

**2a. Manual conditions and parameters.** Translate the Blue Prism expression
to JUEL using only what `reference/conventions.md` lists as known. Variable
names are the Blue Prism names verbatim: a name with spaces is
`execution.getVariable('Queue Name')`. `[Coll.Field]` is
`execution.getVariable('Coll#row')['Field']`. A nested JSON field
(`[Return Value.recordOrError.payload.x]`) is not reachable from JUEL: route
it through a script slot that reads the row and returns the field, and say so.
`IsStopRequested()` becomes a process variable set from outside (the pattern
in modelling-rules.md), documented on the gateway. If an expression needs a
function with no exact equivalent, leave `${TODO_manual_condition}` in place
and write why in the documentation. Never replace it with `${true}`.

**2b. Script slots.** Procedure in `reference/slot-port.md`. For every slot:
write `cases.json` (3 to 5 realistic inputs: the empty value, a null, a
negative number, a non-ASCII string, the characters the C# special-cases),
port the C# to JavaScript respecting the slot's input/output names exactly,
then ask me to run the gate:

```
python tools/slot_oracle.py OBJECTS --stage "<stage>" --object "<object>" --cases cases.json -o work/<stage>
python tools/slot_check.py OBJECTS --stage "<stage>" --object "<object>" --js port.js --cases cases.json --expected work/<stage>/expected.json [--url http://localhost:8080/engine-rest]
```

`SLOT PASS` or it is not done. On a failing case, fix the port, never the
case. Keep Blue Prism numbers exact (they are decimals): no float arithmetic
on money or counts. Look at `examples/build_task_ritm_url/`: the obvious port
failed case 4 (`Uri.EscapeDataString` escapes `!'()*`), the faithful one
passed.

**2c. Workers.** Procedure in `reference/worker.md`. One worker per topic,
same inputs/outputs as the task declares, errors thrown as BPMN errors with
code `BP_BUSINESS` or `BP_SYSTEM` and the detail as message, every resource it
opens released on every exit. Internal Blue Prism VBOs map to Camunda-native
features first (queues, credentials from the secret store, locks). A worker
that drives a UI is a re-host and must be marked as such in the report; it is
not a migration.

**2d. Lint ERRORs.** `LOOP-BOUNDED`: add the missing guard as a gateway that
reads the counter or collection (never a Camunda `retries` setting for a
business retry). `NAME-DEFAULT`: rename only elements you added; names that
come from the export stay, report them. Re-run `python tools/bpmn_lint.py
out_bpmn` after each batch.

**2e. Anything you think the emitter got wrong.** Do not edit the emitted
mappings (`camunda:in`/`out`, `inputParameter`/`outputParameter`, variable
names, process ids) in the BPMN. Write the finding with the element id and
the source stage; the fix belongs in the emitter, re-emitted afterwards.

## Step 3. Verify and hand over

After the last batch, ask me to run and paste:

```
python tools/bpmn_lint.py out_bpmn
python port/bp_equiv.py PROCESS OBJECTS --objects --per-artifact
python tools/c7_runtime_check.py --deploy out_bpmn --url <engine>
```

Expected: no lint `ERROR`; `CODE-SLOT-UNPORTED` count equals the slots you
deliberately left; no `HAD inflow`/`HAD outflow` rows; `0 failed` on deploy.

Hand over one report, in this shape and nothing longer:

- per item: kind, element, what you did, the evidence (`SLOT PASS` with case
  count, lint line, deploy line), or why it stays open;
- the list of items left open, each with the reason in one line;
- the list of things the emitter should do differently, each with element id
  and source stage.

State what you measured, not what you expect. "It should work" is not a
status.
