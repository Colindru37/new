# Writing a worker (external task) for what the engine cannot run

Three kinds of `serviceTask camunda:type="external"` come out of the emitter.
All three use the same mechanics; only what the worker does differs.

| topic | source | what the worker is |
|---|---|---|
| `code.<object>.<stage>` | a Code stage with outside reach (COM/Office, HTTP/browser, files, OS, UI) -- its own code or the object's shared code | the stage's C# re-hosted: a .NET worker that runs that code with the same inputs/outputs |
| `<object>.<action>` for an object **not in the export** | a Blue Prism internal VBO (`Blueprism.Automate.clsWorkQueuesActions`, `clsCredentialsActions`, Environment Locking, Calendars) or an estate VBO that was not exported | the Camunda-native feature (table below) or a thin worker over it |
| `<object>.<action>` for an exported UI object (Navigate/Read/Write stages) | the object's action, which drives an application | the whole object re-hosted: a worker that does what the UI automation did (API if one exists, else the same automation outside Blue Prism) |

## Mechanics (Camunda 7 external task, any language)

1. `POST /external-task/fetchAndLock` with `topics:[{topicName, lockDuration, variables:[...]}]`.
   Ask for the input variables by their BP names (`inputParameter name=` on the
   task tells you which; they are local to the task, which is what fetchAndLock
   returns).
2. Do the work.
3. `POST /external-task/{id}/complete` with `variables: {<output name>: {value,type}}`
   for every `outputParameter` the task declares -- the mapping moves them to the
   caller's Data items. Also set `<C>#row` for every collection C you changed the
   current row of (conventions.md).
4. On a business failure: `POST /external-task/{id}/bpmnError` with
   `errorCode: "BP_BUSINESS"` (or `BP_SYSTEM`) and `errorMessage: <detail>`.
   That is what the process's Recover/boundary events catch, and what
   `ExceptionType()`/`ExceptionDetail()` read. **Never `failure` with retries for
   a Blue Prism exception**: `failure` creates an incident, which Blue Prism's
   Recover would never have seen.
5. On a technical failure (the worker itself broke): `failure` with retries.

Reference client: `org.finos.fluxnova.bpm.client` (Java) / `camunda-external-task-client-js`.
A .NET worker is a plain loop over the REST calls above; `HttpClient` is enough.

## Internal Blue Prism VBOs -> Camunda-native

| BP action | Camunda 7 | note |
|---|---|---|
| Work Queues: Add To Queue / Get Next Item / Mark Completed / Mark Exception / Defer | the process instance IS the work item: one instance per item, `Mark Exception` = BPMN error, `Defer` = timer event | the queue itself: a message start event fed by the producer, or a worker over a table. Decide per process; do not fake a queue in variables |
| Work Queues: Get Item Data / Set Data / Update Status / Tag | process variables | |
| Credentials: Get | a secret store the worker reads (Vault, Key Vault, Camunda `camunda:properties` is NOT it) | never a process variable |
| Environment Locking: Acquire / Release | an exclusive-gateway + `camunda:asyncBefore` with `exclusive=true` only serialises within ONE process; a real cross-process lock is a DB row / Redis `SET NX` in a worker | |
| Calendars | a worker or a DMN table | |
| Utility - Strings / Collections / Dates | a slot (pure logic) once the action's page is exported, else a small worker | |
| Utility - File Management / Excel / Email (shipped VBOs) | a worker (they ARE outside reach) | the estate's `data/vbo_registry.yaml` tiers these |

## Re-hosting a UI object

This is the real migration work and no tool does it. What the tooling gives you:
- `bp_estate` / `bp_full.py` list every application an object drives (`<appdef>`),
  every element, and which actions touch which.
- The emitted object document shows every action as a process with its logic
  already converted; only the Navigate/Read/Write placeholders are missing. A
  worker for topic `<object>.<action>` has to do exactly those placeholders' work,
  in that order, with the Calculations/Decisions around them already done by the
  engine... **or** the whole action is re-hosted as one worker and the emitted
  page is not deployed. Pick one per object and write it down; mixing the two
  inside one object doubles the maintenance.
- Strangler fig: until the API exists, the worker may call Blue Prism itself
  (a published process as a SOAP/REST web service) with the same inputs/outputs.
  That is an honest first worker: same behaviour, new orchestration.

## Proving a worker

Same gate idea as a slot: run the original against the replacement.
- For `code.*` workers: `tools/slot_oracle.py` compiles and runs the original C#
  for pure parameters; with outside reach the oracle needs the outside (a mock
  site, a scratch folder) -- the `tools/mockpack` approach from the pythontoc
  project is the pattern: the worker and the original run against the same mock.
- For VBO re-hosts: the object's Blue Prism unit tests, if any; else the
  process-level run on UAT with the same inputs, comparing the Data items the
  process writes (the tracker rows, the files, the tickets).
