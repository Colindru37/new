# Before you start (ask, or find out; do not assume)

Answer each one in writing before the first edit. A question you cannot answer
is a question for the person, not a default to pick silently.

## About the job
1. Which export, which artifact, which slot/worker exactly? (object name + stage
   name; the BPMN element id.) Is it in `port/bp_equiv.py --per-artifact` output
   as a LOST or DESIGN row, or as a slot?
2. Has the emitter been run on the CURRENT export? (`bp_emit.py --objects`, the
   `.bpmn` timestamp vs the export's.) Never port against a stale frame.
3. Is the engine available for the gate (`tools/c7_runtime_check.py` answers)?
   If not, the deliverable is a draft and must be labelled one.

## About the code stage
4. Does it call into the object's shared code (Code Options)? Then the shared
   code is part of what you port -- or the reason it is a worker.
5. Which parameters are collections? (-> not a slot.) Which are passwords?
   (-> never in a case file, never logged.)
6. What does the stage do on bad input: throw (which type), return empty, return
   a flag? The cases must cover it; the port must match it.
7. Number parameters: counts or money? Money -> exact arithmetic, state the method.
8. Culture: does the code format or parse dates/numbers? With which culture?
   The bots ran on Windows with the estate's regional settings -- which?

## About the worker
9. What is outside: an application (which, UI or API?), a file share (path,
   credentials), Office (which app, licensed where the worker will run?),
   a browser (which, which driver)?
10. Where will the worker run, under which account, with which network reach?
11. Is there an API for what the UI automation did? If not, is the strangler-fig
    option (call the Blue Prism process as a web service) acceptable for now?
12. Does the action change a collection's current row? Then `C#row` is part of
    the output contract.

## About equivalence
13. What does "done" look like for this process: the same tracker rows, the same
    ticket state, the same email? Name the observable, then test against it --
    not against the BPMN diagram.
14. Which Blue Prism behaviours are deliberately NOT reproduced (Clean Up pages,
    `IsStopRequested`, kept-between-calls data items)? List them in the change
    note as divergences, each with a reason.
