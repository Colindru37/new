# Porting a script slot (pure-logic Code stage -> JavaScript)

## Procedure

1. **Read the slot.** In the BPMN, the `scriptTask` named `[SLOT code NL csharp] <stage>`
   holds, in `<documentation>`: the contract line (input names, output names) and
   the original C# verbatim. The object's shared code (Code Options) is in the
   export's ProcessInfo stage; if the stage calls into it, read that too.
2. **Write the cases first** (`cases.json`, a list of `{param: value}`). At least:
   a normal case; every branch of the code; empty string / null for every text
   input; 0, negative, decimal fraction for every number; the characters the code
   special-cases (`?`, `/`, `&`, spaces, quotes, non-ASCII). Five to ten cases.
3. **Oracle:** `python tools/slot_oracle.py <export> --stage "<name>" --cases cases.json -o work/<name>`
   -> `expected.json`. If the oracle REFUSES (collection or image parameter) the
   stage is not a slot candidate: port it as a worker (worker.md).
   If the original throws for a case, the oracle records `__exception` and the
   gate skips that case: decide explicitly what your port does there (usually:
   throw a BPMN error, see below).
4. **Port.** The script runs with the engine's JavaScript (GraalJS on 7.16+;
   `execution` is the DelegateExecution). Read inputs with
   `execution.getVariable('<BP name>')`, write every declared output with
   `execution.setVariable('<BP name>', value)`. Keep the C# structure line for
   line where you can -- it makes the review a diff, not a re-derivation.
5. **Gate:** `python tools/slot_check.py <export> --stage "<name>" --js port.js --cases cases.json --expected work/<name>/expected.json`
   must print `SLOT PASS`. On MISMATCH, fix the port (or the case, if the case
   was wrong -- then re-run the oracle).
6. **Install:** replace the slot's `<bpmn:script>` body, keep everything else of
   the element. Put the gate output (cases + PASS line) in the change note.

## Semantics that differ (the gate catches these; know them beforehand)

| C# / .NET in the stage | JavaScript | note |
|---|---|---|
| `decimal` arithmetic | doubles | `0.1 + 0.2`. For money: work in integer minor units (`Math.round(x * 100)`), or use Java from the script: `var BD = Java.type('java.math.BigDecimal'); new BD(String(x))`. State which you did. |
| `Uri.EscapeDataString` | `encodeURIComponent` + escape `! ' ( ) *` by hand | see examples/build_task_ritm_url |
| `string.Substring(i, n)` | `s.substr(i, n)` (NOT `substring(i, n)` -- that is start/end) | `Substring(i)` = `s.substring(i)` |
| `IndexOf`/`LastIndexOf` with no hit | `-1` both | `IndexOf` on a `char` vs `string`: same in JS |
| `string.Trim()` | `trim()` | .NET Trim also removes U+0085, U+00A0...; JS trim covers them too |
| `ToUpper()/ToLower()` | `toUpperCase()/toLowerCase()` | culture-insensitive in both unless the C# passes a culture |
| `string.Format("{0:N2}", x)` / `ToString("0.00")` | `x.toFixed(2)` (round-half-away-from-zero in .NET, half-up in JS: differs on exact halves) | add a case with `.005` |
| `int.Parse` / `Convert.ToInt32` on junk -> throws | `parseInt` -> `NaN` | throw explicitly: `throw new org.camunda.bpm.engine.delegate.BpmnError('BP_SYSTEM', msg)` |
| `null` string | `null` | C# `s ?? ""` -> `(s == null ? '' : String(s))`; `s.Length` on null throws in C# |
| `DateTime.Now`, `DateTime.Parse` | not portable as-is | a date input arrives as an ISO string; parse with `new Date(s)`; output ISO `toISOString()`; time zones: say what the original assumed |
| `string.Split(',')` | `split(',')` | .NET `Split` with `RemoveEmptyEntries` has no JS one-liner -- filter |
| `List<T>`, LINQ | arrays | `Select`->`map`, `Where`->`filter`, `First()` throws on empty vs `[0]` is `undefined` |
| `Regex` | `RegExp` | .NET-only constructs: lookbehind is fine in Graal, `(?n)`, balancing groups are not |
| `Environment.NewLine` | `'\r\n'` on the bots' Windows | keep `\r\n` if the output is written to Windows files |
| `StringBuilder` | string concatenation | fine |
| `Math.Round(x)` | `Math.round` | .NET rounds half to EVEN by default; JS half UP. `Math.Round(2.5)` = 2 vs 3. |

## Errors from a slot

The Blue Prism stage, on an unhandled exception, raised a System Exception that
the enclosing Recover caught. Keep that contract:

```javascript
try {
  // ... port ...
} catch (e) {
  throw new (Java.type('org.camunda.bpm.engine.delegate.BpmnError'))('BP_SYSTEM', 'Code stage <name>: ' + e);
}
```

The catching boundary event binds the code and message to `bpErrorCode` /
`bpErrorMessage`, exactly as for an emitted throw. Do not swallow.

## What the slot must NOT do

- Reach outside: no `Java.type('java.io...')`, no HTTP, no file. If the port
  needs that, the classifier missed it -- say so, the stage becomes a worker.
- Rename variables, drop an output, add a side channel (process-wide variable
  the stage did not declare).
- Depend on `C#row` without a loop or worker having set it.
