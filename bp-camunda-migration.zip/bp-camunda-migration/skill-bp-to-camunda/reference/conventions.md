# The emitted contract (what the BPMN already does, and what it expects of you)

Every row here is produced by `port/bp_emit.py` and runtime-verified by
`tools/c7_runtime_check.py` on Camunda 7.24 (2026-10-19). The vendor prefix is
`fluxnova:` by default, `camunda:` with `--ns camunda`; both are accepted by
Fluxnova. Expressions are Camunda 7 JUEL (`${...}`), never FEEL.

## Structure

| Blue Prism | BPMN |
|---|---|
| process / object | one `.bpmn` document; **each page = one `bpmn:process`** (id `p_<Artifact>__<Page>_<hash>`) |
| Main Page | the entry process; an object's Main Page is its Initialise |
| Start / End | `startEvent` / `endEvent` |
| page call (SubSheet stage) | `callActivity` into the page's process, parameters mapped (below) |
| Action on an object **in the export** | `callActivity` into that object's action page, same mapping |
| Action on an object **not in the export** (Work Queues, Credentials, un-exported VBOs) | external `serviceTask`, topic `<object>.<action>` (lower-case, spaces -> `-`), inputs/outputs mapped |
| Code stage, pure logic | `scriptTask scriptFormat="javascript"` **slot**, inputs/outputs mapped, C# in documentation, body throws |
| Code stage reaching outside (own code or the object's shared code) | external `serviceTask`, topic `code.<object>.<stage>` |
| Decision | `exclusiveGateway`, flows `${E}` / `${!(E)}`; untranslatable -> `${TODO_manual_condition}` on the true branch + default on the false branch |
| ChoiceStart..ChoiceEnd | `exclusiveGateway`, branch conditions chained in order (`!(c1) && (c2)`), the ChoiceEnd "otherwise" is the gateway's `default` |
| Calculation / MultipleCalculation | `task` with `outputParameter name=<target>` = `${expr}` (a real assignment) |
| LoopStart..LoopEnd over collection C | sequential multi-instance `subProcess`, `collection="C"`, `elementVariable="C#row"` |
| Block with a Recover+Resume | embedded `subProcess` + interrupting error `boundaryEvent`; the recovery path leaves the boundary and rejoins at the Resume |
| Recover without Resume | error event sub-process that re-raises |
| Exception stage | error `endEvent`; one `bpmn:error` per throw, `errorCode` BP_SYSTEM / BP_BUSINESS, `errorMessage="${detail}"` |
| Anchor, ChoiceEnd, LoopEnd, WaitEnd | dissolved / folded, never a node |
| Clean Up page | **not modelled** (open) |
| Navigate / Read / Write / Wait (UI stages) | labelled placeholder `task` (no engine equivalent; the object is re-hosted as a worker) |

## Variables

- **Names are the Blue Prism names, verbatim**, spaces included. In JUEL a name
  that is not an identifier is read with `execution.getVariable('Queue Name')`.
- **Scope = the page.** A page runs as its own process instance, so its
  private Data items are local by construction. The caller maps in what the page
  declares as inputs (`camunda:in target=<receiving Data item>`), maps back what
  its End declares as outputs (`camunda:out source=<Data item> target=<caller's item>`).
  Inputs the caller leaves blank are passed as the type's empty value.
- **Process-wide items** (Data items without "hide from other pages") are passed
  explicitly in and out of every page call that touches them (transitively).
- **Object state**: an object's process-wide items live in the *calling process*
  under the name `<Object>::<item>` and travel in/out of every action call. The
  process Main Page initialises them; the object's Initialise page (when it has
  logic) is called right after. Between two action calls the state is exactly
  where Blue Prism kept it: with the object instance.
- **Initial values**: the first node after Start is `Init: <page>` -- an
  `outputParameter` per Data item with its typed literal (`${false}`, `${0}`,
  `${'text'}`, `${null}` for an unset date). Passwords and collections are never
  initialised here. Items Blue Prism *kept* between calls (no always-init) are
  reset here anyway; the Init task's documentation lists them.
- **Collections** are `java.util.List` of `java.util.Map` (REST: type `Object`,
  `serializationDataFormat=application/json`, `objectTypeName=java.util.ArrayList`).
  A field read `[C.Field]` is `execution.getVariable('C#row')['Field']` -- the
  **current row** of C is the variable `C#row`. A loop sets it per iteration.
  **A worker that implements a collection action (Get Next Row, Add Row...) must
  maintain `C#row` itself**, or every field read after it is null.
- **Exceptions**: a thrown error carries `errorCode` (BP_SYSTEM/BP_BUSINESS) and
  `errorMessage` (the detail expression). Every catching event binds them to
  `bpErrorCode` and `bpErrorMessage`, so `ExceptionType()` = `(bpErrorCode ==
  'BP_BUSINESS' ? 'Business Exception' : 'System Exception')` and
  `ExceptionDetail()` = `bpErrorMessage`. `ExceptionStage()` has no equivalent
  (manual). A worker throws with the same contract: BPMN error, code
  BP_BUSINESS or BP_SYSTEM, message = the detail.
- **Numbers**: Blue Prism numbers are `decimal`. The emitter records
  `(decimal - never double)` in the process properties for every number item;
  the engine stores what you give it (Long/Double/Integer via REST, Java numbers
  from scripts). Keep money exact (slot-port.md).

## Expression functions the transpiler knows

`Trim Upper Lower Len Left Mid Right InStr StartsWith EndsWith Replace`, `&`
concatenation, `AND/OR/NOT` (keyword and function forms), comparisons,
arithmetic, `ExceptionType() ExceptionDetail()`, `[C.Field]`. Everything else is
refused and surfaces as `(manual: unsupported function 'X')` in the
documentation. `ToNumber`, `IsNumber`, `IsStopRequested`, `ExceptionStage`,
`GetClipboard`, date functions, `^`: manual.

## Measuring

`python port/bp_equiv.py --objects <export>` prints source-vs-emitted counts per
category with verdicts OK / PARTIAL / LOST / DESIGN / BUG. DESIGN is a known,
documented loss; everything LOST or BUG is work. `--per-artifact` for one
object/process; `--json` for machines.
