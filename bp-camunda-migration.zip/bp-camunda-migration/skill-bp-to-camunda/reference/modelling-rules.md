# Modelling rules (the estate's Blue Prism coding standard, translated to BPMN / Camunda 7)

The bank's Blue Prism standard (audited by `tools/audit_rules.py`, rules
`CODE-*`, `STAGE-*`, `NARRATIVE-*`, `DATA-*`, `NAME-*`, `EXC-*`, `LOG-*`) has an
equivalent for every rule on the Camunda side. The emitter already follows
these where it can; **anything you add or edit by hand must too.** The
mechanical half is checked by `python tools/bpmn_lint.py <dir or .bpmn>`
(rule ids below); run it before every hand-over. The non-mechanical half
(does the documentation say something true? is this really business logic?)
is yours.

## Naming

| rule | BPMN / Camunda | lint |
|---|---|---|
| process name `<PREFIX><nnn> - <Area> - <Business Task>` | `bpmn:process name="<Artifact> / <Page>"` keeps the registered BP name as the artifact part; **never rename**; the process `id` is the emitter's stable `p_<Artifact>__<Page>_<hash>` and is what call activities and the REST API reference -- do not hand-edit ids | NAME-PROCESS-ID |
| Decision names are questions ending in `?` | `exclusiveGateway name` ends with `?`; each outgoing flow is **named** with the answer (`Yes` / `No` / the choice label) so the diagram reads without opening conditions | NAME-GATEWAY-QUESTION, NAME-FLOW-FROM-GATEWAY |
| Calculation = `<Verb> <Target>`, Title Case | `task` that carries `outputParameter`s keeps the stage name; a new one you add follows the same form | NAME-DEFAULT |
| no default names (`Data1`, `Decision3`) | no element named like its tag (`Task_1`, `Gateway_2`, `Activity_0abc`, `Flow_…`) -- Modeler generates these; rename on creation | NAME-DEFAULT |
| action names start with a verb | external-task **topics** are `<object>.<action>` lower-case with `-` for spaces, and `code.<object>.<stage>`; a worker topic you invent follows the same shape, verb first in the action part | NAME-TOPIC |
| data items `scope_type_Meaning` (`g_txt_Item ID`, `i_col_Rows`) | variables keep the BP names verbatim (the contract); a NEW variable you introduce in a script or worker follows the same prefix scheme; never a bare `tmp`, `x`, `result` | (manual) |
| object parameters: Title Case, no prefixes, acronyms kept | `camunda:in/out target`/`source` names, external-task `inputParameter`/`outputParameter` names: as declared in the export; a new worker's parameters: Title Case | (manual) |
| Anchors get purpose names | n/a: anchors are dissolved. Do not add waypoint-only elements | -- |

## Structure

| rule | BPMN / Camunda | lint |
|---|---|---|
| object Main is declarations only; one page = one action | one `bpmn:process` per page; an object's action pages are **called**, never started directly; the Main Page (Initialise) runs before first use | STRUCT-ONE-START |
| process Main = control framework (declarations, config, loop, exception counter) | the Main Page process starts with the `Init:` task; the long-running loop stays a loop (multi-instance or explicit back-flow), never unrolled | STRUCT-INIT-FIRST |
| `Continue To Work` / consecutive-exception guard in queue processes | the guard's Decision survives as a gateway; `IsStopRequested()` is manual: a process variable `g_flg_Stop Requested` set from outside (REST `PUT /process-instance/{id}/variables`) is the accepted translation -- document it on the gateway | (manual) |
| declarations in named Blocks (`Global Variables`, `Environment Variables`) | process-level `camunda:properties` (`var:<name>`, `collection:<name>`) are the declaration block; keep them in sync when you add a variable | DATA-UNDECLARED |
| each recoverable unit of work in a named Block | embedded `subProcess` **named** after the work, with its error boundary event named `Recover <work>` | NAME-SUBPROCESS, EXC-BOUNDARY-NAMED |
| Clean Up page on every object | not modelled by the emitter; a worker that re-hosts an object must release what it opened on **every** exit (success, BPMN error, failure) -- the `CODE-COM-UNRELEASED` rule in worker form | (manual) |
| every element has a narrative | every flow node has a non-empty `bpmn:documentation`; the emitter writes one for every node it creates; Modeler-added nodes default to none | NARRATIVE-MISSING |

## Exceptions and retry

| rule | BPMN / Camunda | lint |
|---|---|---|
| exactly `System Exception` or `Business Exception` | error codes are exactly `BP_SYSTEM` or `BP_BUSINESS`; a new `bpmn:error` you declare uses one of the two, `name` = `<Kind>Exception: <what>` | EXC-CODE |
| capture type, detail, stage before routing or rethrowing | every error catch binds `camunda:errorCodeVariable="bpErrorCode"` and `camunda:errorMessageVariable="bpErrorMessage"`; the first node after the catch records them (the emitted MultipleCalculation does) | EXC-CATCH-BINDS |
| preserve type/detail when rethrowing | a re-raise end event references an error whose `errorMessage` is `${bpErrorMessage}` or is the same error object; never a fresh static message that loses the original | EXC-RERAISE-KEEPS-DETAIL |
| useful detail = fixed context + captured detail | `errorMessage="${('Stage X: ').concat(bpErrorMessage)}"` -- context first, original last | (manual) |
| screenshot before resuming a System Exception | no screen in the engine; the worker that drives a UI must attach the screenshot path to `bpErrorMessage` or a variable `g_txt_Screenshot Path` on failure; for pure-logic errors the rule is void -- say so | (manual) |
| explicit retry counter, maximum, increment, reset | a retry loop is a gateway on `[g_num_Attempt] < max` with the increment as an `outputParameter`; never a Camunda `retries` on the external task for a *business* retry (that is for worker crashes) | LOOP-BOUNDED |
| every loop bounded | every back-flow into an earlier node passes through a gateway with a condition that reads a counter or a collection | LOOP-BOUNDED |

## Logging and secrets

| rule | BPMN / Camunda | lint |
|---|---|---|
| logging Errors Only in production | `camunda:historyTimeToLive` present on every process (the emitter sets `P180D`); history level is an engine setting (`historyLevel=activity` in production, not `full`) -- state it in the deploy note | LOG-HTTL |
| secrets typed `password` | a variable whose name carries `pwd_`/`Password`/`Secret`/`Token` is never given a literal in an `Init:` task, never an `inputParameter` with a literal, never written into documentation; it comes from the worker's secret store at run time | DATA-SECRET-LITERAL |
| `{_IGNORE_VALUE}` honoured by writers | a worker that writes fields honours the same marker string and skips the field | (manual) |

## Code

| rule | BPMN / Camunda | lint |
|---|---|---|
| no blocking UI, no script interpreters, release COM | a `scriptTask` body contains no `Java.type('java.io`, `java.net`, `ProcessBuilder`, `Runtime.getRuntime` -- the slot is pure logic by definition; any of these means it should have been a worker | CODE-SLOT-REACHES-OUT |
| custom code in objects, not processes | a `scriptTask` lives in an **object's** page process, never in a process artifact's (the emitter never creates one there) | CODE-IN-PROCESS |
| slot bodies are real before hand-over | a `scriptTask` whose body is the emitter's `throw new Error("TODO port` placeholder is reported; a document with one is a draft | CODE-SLOT-UNPORTED |
| external tasks carry their contract | every `camunda:type="external"` task has a `camunda:topic` and at least its declared `inputParameter`/`outputParameter`s when the stage had any | CODE-TOPIC |

## Layout and spacing (the diagram is read by people)

The emitter keeps the Blue Prism coordinates for ORDER and ALIGNMENT, not for
distance: every stage is snapped to a grid cell (one cell per Blue Prism
column/row band), cells sit at a fixed pitch (200 px across, 150 px down),
shapes are centred in their cell (tasks 100x80, gateways 50x50, events 36x36),
a Block/loop subProcess is drawn around its children with 20 px padding per
nesting level, boundary events sit on the right border of their activity, and
edges are orthogonal (a loop's back-edge goes around the right). Keep that
rhythm when you add elements in the Modeler: new shapes on the same grid, no
diagonals.

| rule | lint |
|---|---|
| no two shapes overlap; minimum gap 20 px between any two shapes in the same process | LAYOUT-OVERLAP |
| flow direction is one direction per page (down, or right), as the BP page was; back-flows (loops) are the only edges going against it | LAYOUT-DIRECTION (warn) |
| elements on one lane of logic share an x (vertical pages) or y (horizontal pages) to +-5 px | LAYOUT-ALIGN (warn) |
| every flow node has a `BPMNShape`, every flow a `BPMNEdge` (an element without DI is invisible in Cockpit and Modeler and gets a random place on open) | LAYOUT-DI-MISSING |
| a sub-process shape contains all its children's shapes | LAYOUT-CONTAINS |
| the Init task and the Initialise calls sit directly after Start, before anything else | STRUCT-INIT-FIRST |

Modeler specifics: keep "snap to grid" on (10 px); the BP 15-unit grid maps to
37.5 px, so re-aligned elements will sit on 40 px multiples -- fine. Do not
auto-layout a whole page (`bpmn-auto-layout`): it destroys the correspondence
with the Blue Prism diagram the reviewers compare against.

## Precedence

Emitted output > these rules > Modeler defaults. If the emitter violates a
rule here, the fix is in `src/bp_estate` / `port/bp_emit.py` (then rebuilt and
re-baked), and the lint gets a test case -- never a hand edit of the `.bpmn`.
