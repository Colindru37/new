---
name: bp-to-camunda
description: Finish a Blue Prism -> Camunda 7 / Fluxnova migration that the deterministic emitter (port/bp_emit.py) has already framed. Use when filling a script SLOT (a pure-logic Code stage ported to JavaScript), writing an external-task WORKER (a Code stage or VBO that reaches outside the engine), translating a condition the transpiler refused, or judging whether a converted process is equivalent. Never for re-doing what the emitter does.
---

# Skill: finishing a Blue Prism -> Camunda migration

The frame of every process is already produced, deterministically, by
`port/bp_emit.py` (one command for a whole process: `python migrate.py
--process <export> --objects <object pack> -o out`): pages, flows, conditions,
calculations, page calls with mapped parameters, initial values, loops,
exception handling (Blocks with a Recover become scopes with an error boundary,
nested inside loops or around them as drawn), object state. It is verified on a
live engine by `tools/c7_runtime_check.py`, linted by `tools/bpmn_lint.py` and
measured against the export by `port/bp_equiv.py`. **Your job is only what the
emitter deliberately leaves open**, and each of those is a labelled slot in the
BPMN. The paste-ready version of this skill for Copilot is
[COPILOT-PROMPT.md](COPILOT-PROMPT.md).

| in the BPMN | what it is | your job |
|---|---|---|
| `scriptTask` named `[SLOT code ...]` | a pure-logic Code stage: inputs/outputs mapped, the original C# or Visual Basic in `<documentation>`, a body that throws | port it to JavaScript, prove it with the gate (below) |
| `serviceTask` named `[WORKER code ...]`, topic `code.<object>.<stage>` | a Code stage that reaches outside the engine (COM/Office, browser, files, OS) | write an external-task worker for that topic, same inputs/outputs |
| `serviceTask` topic `<object>.<action>` | an action on an object that is NOT in the export (internal BP VBOs: Work Queues, Credentials...) | map to the Camunda-native feature or a worker, see reference/worker.md |
| flow condition `${TODO_manual_condition}` | a Decision/Choice whose expression the transpiler refused (`ExceptionStage()`, `ToNumber()`, `IsStopRequested()`, nested JSON fields...) | translate by hand; the gateway's `<documentation>` holds the original |
| `<documentation>` lines starting `in <param> = ... (manual: ...)` | a parameter expression the transpiler refused | translate by hand in the mapping |
| page documentation starting `regions left flat (partial overlap, not nestable)` | a Block drawn across a loop in Blue Prism; BPMN cannot nest that | report it; do not hand-build a scope |

Read [reference/conventions.md](reference/conventions.md) first: it is the
contract every slot and worker must respect (variable names, `Object::item`
state, `Coll#row`, `bpErrorCode`/`bpErrorMessage`). Then
[reference/modelling-rules.md](reference/modelling-rules.md): the estate's
Blue Prism coding standard translated to BPMN (naming, structure, exceptions,
secrets, code, layout/spacing); its mechanical half is `tools/bpmn_lint.py`,
which must be clean (no ERROR) on anything you hand over. Then the page for
the job: [slot-port.md](reference/slot-port.md), [worker.md](reference/worker.md).
Before touching anything: [questions.md](reference/questions.md).

## Reading the measurements

- `python audit3.py out` counts orphans and dead ends in the BPMN alone. It
  cannot tell whose fault they are; `bp_equiv` can.
- `bp_equiv` splits reachability by cause. Only `orphan nodes: source stage HAD
  inflow` and `dead-end nodes: source stage HAD outflow` are conversion
  defects. `no inflow/outflow in Blue Prism either` means the stage was
  unwired on the source page (or fed only by a Note, or a Recover without a
  Block): dead there too, listed, never "fixed". `synthetic` must be 0.
- `bp_equiv` over a whole object pack measures every object in it; read the
  table of the process and of the objects `REPORT.md` kept, not the `TOTAL`.
- `functions in failed expressions:` at the end of `bp_equiv` ranks what the
  transpiler refused. `NewLine`, `ToNumber`, `IsNumber`, `Now`, `Today` and
  nested `[C.a.b]` fields translate (every form is executed on the engine by
  `python tools/juel_probe.py`); what remains is date formatting and the
  by-choice refusals. `orphans with no inflow in the source` lists, by name,
  the stages no flow stage links to in the export: on a process known to be
  complete, check one in Blue Prism before believing it.

## The gate (not optional)

You do not grade your own translation. The original code grades it:

1. `python tools/slot_oracle.py <export> --stage "<name>" [--object "<object>"] --cases cases.json -o work/<name>`
   compiles the stage's ORIGINAL code (C# or Visual Basic, plus the object's
   shared code) and runs your cases through it -> `expected.json`. On Windows the
   compilers are `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe` and
   `vbc.exe` beside it (pass `--csc <path>` if not found).
2. `python tools/slot_check.py <export> --stage "<name>" [--object "<object>"] --js port.js --cases cases.json --expected work/<name>/expected.json`
   runs your JavaScript on the engine, in exactly the slot's shape, once per
   case, and compares every output. `SLOT PASS` or it is not done.

A port without a passing gate is a draft. Cases are yours to choose and that is
where your judgement goes: empty strings, nulls, negative numbers, non-ASCII,
spaces, the characters the original code special-cases. See the worked example
in `examples/build_task_ritm_url/`: the "obvious" port (`naive_WRONG.js`) passed
4 of 5 cases and would have shipped a URL-encoding bug; the gate caught it.

## MUST rules

- **Never invent an equivalent.** If a .NET call has no exact JavaScript or
  engine counterpart, say so in the slot's documentation and leave the throw in
  place. A wrong port that runs is worse than a slot that fails loudly. The
  same for a condition: `${TODO_manual_condition}` stays until it is right;
  never `${true}`.
- **Never change the emitter's mappings** (the `camunda:in`/`out`,
  `inputParameter`/`outputParameter`, variable names, process ids). They are
  the contract the rest of the process relies on. Report what the emitter
  should do differently (element id + source stage); it gets fixed in the
  emitter and re-emitted, never in the BPMN by hand.
- **Keep the BP names.** Variables are called what the Data items were called,
  spaces included: `execution.getVariable('Queue Name')`. Do not "clean up" names.
- **Numbers are decimals in Blue Prism.** Money and counts must not drift through
  JavaScript doubles; see slot-port.md for how to keep exact arithmetic.
- **State the verdict with the evidence**: which cases, which tool output. "It
  should work" is not a status.
- **Re-run the whole-process checks after a batch of slots:**
  `python tools/bpmn_lint.py <out dir>` (no ERROR; the INFO count of
  `CODE-SLOT-UNPORTED` is the work left), `python port/bp_equiv.py <process>
  <objects> --objects --per-artifact` (no `HAD inflow`/`HAD outflow` rows,
  nothing new LOST) and a deploy (`python tools/c7_runtime_check.py
  --deploy <out dir>`; or the Fluxnova Modeler's engine, `--url`).

## When NOT to use this skill

- The export has not been through `migrate.py` / `bp_emit.py` yet -> run the
  emitter, not this.
- The question is "is this process equivalent?" with no engine available ->
  `bp_equiv.py` gives the structural answer; functional equivalence needs the
  gate per slot and a run per process. Do not estimate it.
