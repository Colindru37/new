#!/usr/bin/env python3
"""migrate.py -- one command, one answer, for ONE Blue Prism process.

Replaces the scatter of separate runs (bp_emit / api_facts / object_triage /
intersect / manual filtering / 725 loose files) with a single assembled result.

    python migrate.py --process "<process export>" --objects "<combined export>" -o out

Writes into <out>/:
    <Process>.bpmn          the migrated process (import THIS into Fluxnova)
    objects/*.bpmn          only the objects that actually convert
    api_facts_ui.json       the ledger for objects that need an API (feeds prompt 02)
    REPORT.md               what migrated, what is blocked, and why

--objects is optional: without it you get the BPMN and no object verdicts.
Needs bp_core.py, bp_emit.py, api_facts.py, object_triage.py beside it.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from collections import Counter
from pathlib import Path

# make the sibling bundles/tools importable from any working directory
import sys as _sys
from pathlib import Path as _Path
_ROOT = _Path(__file__).resolve().parent
for _d in (_ROOT, _ROOT.parent, _ROOT / "port", _ROOT / "tools", _ROOT.parent / "port", _ROOT.parent / "tools"):
    if _d.is_dir() and str(_d) not in _sys.path:
        _sys.path.insert(0, str(_d))
import bp_core
import bp_emit
import api_facts
import object_triage


def _norm(s: str) -> str:
    return " ".join(s.split()).strip().lower()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="migrate")
    ap.add_argument("--process", required=True, help="export containing the PROCESS")
    ap.add_argument("--objects", help="export containing the OBJECTS (for verdicts)")
    ap.add_argument("-o", "--out", default="migration", help="output folder")
    ap.add_argument("--ns", choices=sorted(bp_emit.EXT_NS), default="fluxnova")
    a = ap.parse_args(argv)

    out = Path(a.out)
    if out.exists():
        shutil.rmtree(out)
    (out / "objects").mkdir(parents=True)

    # ---- 1. the process -> BPMN ------------------------------------------ #
    est = bp_core.Estate()
    bp_core.parse_paths(bp_core._collect([a.process]), est)
    procs = [x for x in est.artifacts if x.type == "process"]
    docs = bp_emit.emit_all(est, a.ns)
    for name, xml in docs.items():
        (out / name).write_text(xml, encoding="utf-8")
    main_bpmn = sorted(docs)[0] if docs else None

    stages = [s for lst in est.stages_by_artifact.values() for s in lst]
    pages = len({s.subsheet for s in stages})

    # ---- 2. what the process calls --------------------------------------- #
    facts = api_facts.build_facts(a.process, "all")
    called = {o["object"]: o for o in facts["objects"]}

    # ---- 3. object verdicts ---------------------------------------------- #
    verdicts: dict[str, dict] = {}
    if a.objects:
        tri = object_triage.collect([a.objects])
        by_norm = {_norm(o["object"]): o for o in tri["objects"]}
        for name in called:
            got = by_norm.get(_norm(name))
            if got:
                verdicts[name] = got

    internal = [n for n in called if n not in verdicts
                and bp_emit._vbo_tier(n) == "native"]
    unknown = [n for n in called if n not in verdicts and n not in internal]
    counts = Counter(v["verdict"] for v in verdicts.values())

    # ---- 4. convert the objects that CAN convert ------------------------- #
    converted = []
    if a.objects:
        conv_names = {n for n, v in verdicts.items()
                      if v["verdict"] in ("logic-only", "code-bound")}
        if conv_names:
            oest = bp_core.Estate()
            bp_core.parse_paths(bp_core._collect([a.objects]), oest)
            keep = [x for x in oest.artifacts if x.name in conv_names]
            oest.artifacts = keep
            odocs = bp_emit.emit_all(oest, a.ns, include_objects=True)
            for name, xml in odocs.items():
                (out / "objects" / name).write_text(xml, encoding="utf-8")
            converted = sorted(odocs)

    # ---- 5. the API backlog ---------------------------------------------- #
    ui_names = {n for n, v in verdicts.items() if v["verdict"] == "ui-driving"}
    ui_facts = dict(facts)
    ui_facts["objects"] = [o for o in facts["objects"] if o["object"] in ui_names]
    ui_facts["object_count"] = len(ui_facts["objects"])
    (out / "api_facts_ui.json").write_text(
        json.dumps(ui_facts, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    # ---- 6. the report ---------------------------------------------------- #
    pname = procs[0].name if procs else "(unknown)"
    r = [f"# Migration report -- {pname}", ""]
    r += ["## Migrated", "",
          f"- **{main_bpmn}** -- import this into Fluxnova",
          f"- {len(stages)} stages across {pages} pages",
          f"- {len(converted)} object(s) also converted -> `objects/`", ""]
    r += ["## Objects this process needs", "",
          f"Calls **{len(called)}** distinct objects.", "",
          "| status | count | meaning |", "|---|---|---|"]
    label = {
        "ui-driving": "**needs an API** (blocks the migration)",
        "code-bound": "converts, but code stages need re-implementing",
        "logic-only": "converts as-is",
        "mixed": "declares an app but no UI stages -- inspect by hand",
    }
    for v, n in counts.most_common():
        r.append(f"| {v} | {n} | {label.get(v, '')} |")
    if internal:
        r.append(f"| internal | {len(internal)} | built into Blue Prism -> native Fluxnova feature, free |")
    if unknown:
        r.append(f"| not in export | {len(unknown)} | object file was not supplied |")
    r.append("")
    if ui_names:
        r += [f"## Blocked on {len(ui_names)} API(s)", "",
              "Each needs an application API before this process can run:", ""]
        r += [f"- {n}" for n in sorted(ui_names)]
        r += ["", "Draft a spec per object: paste one record from `api_facts_ui.json` "
                  "with prompt 02, then verify with `api_spec_check.py`.", ""]
    if unknown:
        r += ["## Not in the export", ""] + [f"- {n}" for n in sorted(unknown)] + [""]
    (out / "REPORT.md").write_text("\n".join(r), encoding="utf-8")

    print(f"{pname}: {len(stages)} stages, {pages} pages")
    print(f"  BPMN        -> {out / (main_bpmn or '?')}")
    print(f"  objects     -> {len(converted)} converted")
    print(f"  needs API   -> {len(ui_names)}")
    print(f"  report      -> {out / 'REPORT.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
