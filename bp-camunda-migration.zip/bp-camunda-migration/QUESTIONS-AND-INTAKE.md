# Questions & Intake — what we need to go further

> ⚠️ **Section A is stale — see `PROGRAMME.md` §7 for the live gates.** The
> target is uFlow, so "Camunda 7 or 8?" is no longer the question that blocks
> the emitter. The two that do: **does uFlow have any UI/RPA capability**, and
> **what does uFlow ingest**. Sections B–E below are still what we need.

Grouped by what each answer unblocks. Bring what you can; nothing here blocks
Phase 0 (the analyzer already runs on synthetic fixtures).

---

## ⚠️ Read this first — what we actually need to *test*

There are two very different "test on the laptop" goals, and they need different
things. Don't over-invest in the wrong one:

1. **Test the MIGRATION PIPELINE (our tooling).**
   Needs only **XML exports** (`.bprelease` / `.bpprocess` / `.bpobject`).
   Does **NOT** need a running Blue Prism. A full Blue Prism install requires a
   licensed BP server + SQL Server + runtime resources — heavy, and unnecessary
   just to test the converter. → **The single most useful thing you can bring is
   one sanitized real export.**

2. **Test a MIGRATED AUTOMATION end-to-end** (does the Camunda version actually
   drive the app). This is the part that needs the "recreate the bots/VM" work:
   the target application(s), a Windows session, and a Camunda runtime. Scope
   this per-automation, later — not up front.

So: recreating running bots is only for goal (2), and only for a couple of pilot
automations. For everything else, **exports are the fuel.**

---

## A. Decision blockers (unblock the converter)

- [ ] **Camunda 7 or 8?** And which version? *(Blocks the emitter design — 7 =
      Java delegates/external tasks; 8 = Zeebe job workers + connectors.)*
- [ ] **Target job-worker language/stack** (Java / .NET / Node / Python)?
- [ ] Camunda **RPA workers** in scope, or is UI automation being replaced by
      APIs / another tool?

## B. Estate facts (scope + calibrate Phase 0)

- [ ] One **sanitized real export** we can parse (reconciles the parser).
- [ ] Rough counts: # processes, # objects/VBOs, # work queues.
- [ ] **Blue Prism version** (drives internal-VBO names/param keys in the registry).
- [ ] Prevalence of **Code stages** and external **DLL references** (biggest blockers).
- [ ] Which internal VBOs are **renamed/localized** on your install (registry aliases).

## C. Automation-layer fate (per app)

- [ ] What do the bots drive? mainframe / web / thick-client desktop / Citrix / Java?
- [ ] Which of those have a **real API** available (replace-with-API candidates)?
- [ ] Per app: **re-host** on Camunda RPA vs **replace with API** vs **keep BP**
      behind Camunda during transition?

## D. VM / runtime details (to recreate a pilot bot locally)

- [ ] VM **OS + specs**, and how many runtime resources run in parallel.
- [ ] Which **applications** are installed on the runtime VMs (versions).
- [ ] Does automation need an **interactive logged-in session** (most UI automation does)?
- [ ] **Credentials/vault**: what secret store feeds the bots today.
- [ ] Network/segregation: can a pilot app (or a stand-in) run on this laptop at all?

## E. Bank / regulatory

- [ ] **Audit-log parity bar** — what granularity do internal audit / regulators require?
- [ ] Secrets **vault** in use (maps Blue Prism Credential Manager).
- [ ] **PII / data-residency** constraints on work-queue item data (→ Camunda variables & history).
- [ ] Change-control / four-eyes requirements for sign-off on migrated processes.

## F. Environment on this laptop

- [ ] Install **Docker Desktop** if we go Camunda 8 (Zeebe needs it). *(Not installed yet.)*
- [ ] Camunda 7 alternative: the **"Camunda Run" jar** runs on the installed Java —
      no Docker needed. Good for a quick local target if we go C7. See `docker/`.

---

### The one-line ask
If you bring **(1) one sanitized real `.bprelease`** and **(2) the Camunda
7-vs-8 answer**, we can reconcile the parser against reality *and* start the
converter — the two things everything else waits on.
