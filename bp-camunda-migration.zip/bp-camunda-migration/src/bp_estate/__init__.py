"""bp_estate — Phase 0 estate analyzer for Blue Prism -> Camunda migration.

Reads Blue Prism exports, builds a deterministic, tool-agnostic estate model,
and reports coupling, blockers, dead code, duplicates, and migration scores.

MVP note: this scaffold consolidates the sub-package layout documented in
PHASE0-IMPLEMENTATION.md (io/parse/detect/analyze/score/report) into flat
modules so it runs end-to-end today. Split back out as it grows.
"""

__version__ = "0.1.0"
