"""Loads the three shared, language-neutral contract files from data/.

    vbo_registry.yaml   -> Registry  (object tiers + resource detectors + param keys)
    weights.yaml        -> Weights   (complexity/risk/coupling scoring)
    pii_patterns.yaml   -> PiiMatcher (collection-field PII heuristic)

These are DATA, not code, precisely so a future C#/.NET port consumes the same
files and cannot silently diverge.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import yaml


def _load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


# --------------------------------------------------------------------------- #
# VBO registry
# --------------------------------------------------------------------------- #
@dataclass
class Registry:
    raw: dict

    def __post_init__(self) -> None:
        self._by_name: dict[str, dict] = {}
        for obj in self.raw.get("objects", []):
            names = [obj["name"], *obj.get("aliases", [])]
            for n in names:
                self._by_name[n.strip().lower()] = obj
        self._unknown_tier = self.raw.get("unknown_object_policy", "custom")
        self._tier_targets = {
            k: v.get("default_migration_target")
            for k, v in self.raw.get("tiers", {}).items()
        }

    def _entry(self, object_name: str) -> dict | None:
        if not object_name:
            return None
        return self._by_name.get(object_name.strip().lower())

    def classify(self, object_name: str) -> tuple[str, str | None]:
        """Return (tier, migration_target) for an object name."""
        entry = self._entry(object_name)
        if entry is None:
            return self._unknown_tier, self._tier_targets.get(self._unknown_tier)
        tier = entry["tier"]
        target = (entry.get("migration") or {}).get("maps_to") or self._tier_targets.get(tier)
        return tier, target

    def detector_for(self, object_name: str) -> str | None:
        entry = self._entry(object_name)
        return entry.get("detector") if entry else None

    def param_key(self, object_name: str, action_name: str, role: str) -> str | None:
        """Best-known input param key holding a resource name (queue/credential/lock).

        Returns None if not declared — the caller must then fall back to the first
        string input and, if non-literal, record unresolved(dynamic). Never guess.
        """
        entry = self._entry(object_name)
        if not entry:
            return None
        for act in entry.get("actions", []):
            if act["name"].strip().lower() == (action_name or "").strip().lower():
                return (act.get("param") or {}).get(role)
        return None

    def action_semantics(self, object_name: str, action_name: str) -> list[str]:
        entry = self._entry(object_name)
        if not entry:
            return []
        for act in entry.get("actions", []):
            if act["name"].strip().lower() == (action_name or "").strip().lower():
                return list(act.get("semantics", []))
        return []


# --------------------------------------------------------------------------- #
# PII matcher
# --------------------------------------------------------------------------- #
@dataclass
class PiiMatcher:
    raw: dict

    def __post_init__(self) -> None:
        norm = self.raw.get("meta", {}).get("match", {}).get("normalize", [])
        self._strip = set(norm)
        self._terms: list[tuple[str, str]] = []   # (category, term)
        self._regex: list[tuple[str, re.Pattern]] = []
        for cat, spec in self.raw.get("categories", {}).items():
            for t in spec.get("terms", []) or []:
                self._terms.append((cat, self._normalize(t)))
            for rx in spec.get("regex", []) or []:
                self._regex.append((cat, re.compile(rx, re.IGNORECASE)))
        self._allow = {self._normalize(a) for a in self.raw.get("allowlist", []) or []}

    def _normalize(self, name: str) -> str:
        s = name.lower()
        if "strip_spaces" in self._strip:
            s = s.replace(" ", "")
        if "strip_underscores" in self._strip:
            s = s.replace("_", "")
        if "strip_hyphens" in self._strip:
            s = s.replace("-", "")
        return s

    def match(self, field_name: str) -> list[str]:
        """Return sorted list of PII categories a field name hits ([] if none)."""
        norm = self._normalize(field_name)
        if norm in self._allow:
            return []
        hits: set[str] = set()
        for cat, term in self._terms:
            if term in norm:
                hits.add(cat)
        for cat, rx in self._regex:
            if rx.search(norm):
                hits.add(cat)
        return sorted(hits)


# --------------------------------------------------------------------------- #
# Weights
# --------------------------------------------------------------------------- #
@dataclass
class Weights:
    raw: dict

    def score(self, kind: str, features: dict[str, float]) -> float:
        spec = self.raw.get(kind, {}).get("features", {})
        total = 0.0
        for name, cfg in spec.items():
            val = float(features.get(name, 0) or 0)
            contrib = cfg["weight"] * min(val * cfg.get("scale", 1.0), cfg.get("cap", float("inf")))
            total += contrib
        return round(total, 3)

    def band(self, kind: str, score: float) -> str:
        bands = self.raw.get(kind, {}).get("bands", {})
        for label in ("low", "medium"):
            mx = bands.get(label, {}).get("max")
            if mx is not None and score <= mx:
                return label
        return "high"

    @property
    def rollup(self) -> dict:
        return self.raw.get("rollup", {})

    @property
    def waves(self) -> dict:
        return self.raw.get("waves", {})


@dataclass
class Config:
    registry: Registry
    pii: PiiMatcher
    weights: Weights


def load_config(data_dir: Path) -> Config:
    data_dir = Path(data_dir)
    return Config(
        registry=Registry(_load_yaml(data_dir / "vbo_registry.yaml")),
        pii=PiiMatcher(_load_yaml(data_dir / "pii_patterns.yaml")),
        weights=Weights(_load_yaml(data_dir / "weights.yaml")),
    )
