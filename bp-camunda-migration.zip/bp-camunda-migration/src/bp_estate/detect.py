"""Semantic recognition (PHASE0-ESTATE-ANALYZER.md §7).

Classifies every referenced object into a tier, extracts queue / credential /
lock names from internal-VBO calls, and flags PII-suspect collections. When a
resource name is not a literal, it is recorded as unresolved(dynamic) + a
dynamic-name blocker — never fabricated.
"""
from __future__ import annotations

from .bpexpr import unwrap_literal
from .config import Config
from .model import (
    Blocker, Credential, Edge, EnvLock, Estate, ObjectTier, Queue, Unresolved,
)

# detector -> (role for param lookup, edge kind, blocker kind or None)
_DETECTORS = {
    "work-queue":       ("queue_name", "queue", None),
    "credential":       ("credential_name", "credential", None),
    "environment-lock": ("lock_name", "lock", "environment-lock"),
}


def _resolve_name(raw: str | None) -> tuple[str, bool]:
    """(name, is_dynamic).

    Input values are BP expressions, so a literal queue name arrives quoted
    ('"Payments"'). Only a plain literal resolves; anything assembled at
    runtime is reported verbatim and flagged, never guessed.
    """
    value, literal = unwrap_literal(raw)
    if value is None:
        return "<unresolved>", True
    return value, not literal


def _upsert(items: list, name: str, artifact: str, dynamic: bool, using_attr: str):
    for it in items:
        if it.name == name:
            if artifact not in getattr(it, using_attr):
                getattr(it, using_attr).append(artifact)
            it.dynamic_name = it.dynamic_name or dynamic
            return it
    return None


def run(estate: Estate, config: Config) -> None:
    reg = config.registry
    tiers_seen: dict[str, ObjectTier] = {}

    def classify(object_name: str) -> None:
        if not object_name or object_name in tiers_seen:
            return
        tier, target = reg.classify(object_name)
        tiers_seen[object_name] = ObjectTier(object=object_name, tier=tier, migration_target=target)

    # every custom VBO artifact is itself a re-host candidate
    for art in estate.artifacts:
        if art.type == "object":
            classify(art.name)

    for art in estate.artifacts:
        for stage in estate.stages_by_artifact.get(art.name, []):
            if stage.type != "Action" or not stage.target_object:
                continue
            obj = stage.target_object
            classify(obj)

            detector = reg.detector_for(obj)
            if detector not in _DETECTORS:
                continue
            role, edge_kind, blk_kind = _DETECTORS[detector]

            key = reg.param_key(obj, stage.target_action or "", role)
            raw = None
            if key and key in stage.inputs:
                raw = stage.inputs[key]
            elif key is None:
                # action carries no resource-name param (e.g. Mark Completion) -> nothing to extract
                continue
            else:
                # declared key absent on stage -> fall back to first string input, then flag
                raw = next(iter(stage.inputs.values()), None)

            name, dynamic = _resolve_name(raw)

            if edge_kind == "queue":
                if not _upsert(estate.queues, name, art.name, dynamic, "used_by"):
                    estate.queues.append(Queue(name=name, used_by=[art.name], dynamic_name=dynamic))
            elif edge_kind == "credential":
                if not _upsert(estate.credentials, name, art.name, dynamic, "requested_by"):
                    estate.credentials.append(Credential(name=name, requested_by=[art.name], dynamic_name=dynamic))
            elif edge_kind == "lock":
                if not _upsert(estate.env_locks, name, art.name, dynamic, "locked_by"):
                    estate.env_locks.append(EnvLock(name=name, locked_by=[art.name], dynamic_name=dynamic))

            estate.edges.append(
                Edge(from_artifact=art.name, from_stage=stage.name,
                     kind=edge_kind, to=name, resolved=not dynamic)
            )

            if blk_kind == "environment-lock":
                estate.blockers.append(
                    Blocker(artifact=art.name, page=stage.subsheet, stage=stage.name,
                            kind="environment-lock", severity="warn",
                            detail=f"Environment lock '{name}' — estate-wide mutual exclusion; needs an explicit distributed-lock design in the target")
                )

            if dynamic:
                estate.blockers.append(
                    Blocker(artifact=art.name, page=stage.subsheet, stage=stage.name,
                            kind="dynamic-name", severity="warn",
                            detail=f"{edge_kind} name is computed at runtime ({raw!r}) — cannot statically resolve")
                )
                estate.unresolved.append(
                    Unresolved(from_artifact=art.name, from_stage=stage.name, ref=str(raw), reason="dynamic")
                )

    estate.object_tiers.extend(tiers_seen.values())

    # PII heuristic over collection fields
    for col in estate.collections:
        cats: set[str] = set()
        for f in col.fields:
            cats.update(config.pii.match(f))
        if cats:
            col.pii_suspect = True
            col.pii_categories = sorted(cats)
