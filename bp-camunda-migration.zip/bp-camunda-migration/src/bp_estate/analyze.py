"""Graph & structural analysis: call graph, resolution, dead code, back-links,
duplicate logic. Pure functions over the model; deterministic.
"""
from __future__ import annotations

import hashlib

import networkx as nx

from .config import Config
from .model import Blocker, DeadCode, Duplicate, Edge, Estate, Unresolved

# Declaration/annotation stages are not part of the flow graph — they have no
# inbound links by design, so they must never be reported as "unreachable".
#
# SubSheetInfo (one per page) and ProcessInfo (one per artifact) are the info
# blocks Blue Prism puts on every diagram. Recover is an EXCEPTION handler:
# reached when a stage throws, never by a normal link. All three were missing
# here, and together they were ~62% of a real export's "dead code".
_NON_FLOW = {
    "Data", "Collection", "Note", "Anchor", "Block",
    "SubSheetInfo", "ProcessInfo",      # diagram info blocks
    "Recover",                          # entered on exception, not by a link
}


def run(estate: Estate, config: Config) -> None:
    reg = config.registry
    object_names = {a.name for a in estate.artifacts if a.type == "object"}

    # --- object-action & page edges + resolution ------------------------- #
    for art in estate.artifacts:
        stages = estate.stages_by_artifact.get(art.name, [])
        # parse resolves both page refs and stage subsheets to page NAMES; the
        # <subsheet> declarations are authoritative, so a declared page with no
        # stages on it still counts as resolvable.
        known_pages = set(art.pages) | {s.subsheet for s in stages if s.subsheet}
        for s in stages:
            if s.type == "Action" and s.target_object:
                tier, _ = reg.classify(s.target_object)
                resolved = tier in ("internal", "shipped") or s.target_object in object_names
                estate.edges.append(Edge(
                    from_artifact=art.name, from_stage=s.name, kind="object-action",
                    to=f"{s.target_object}.{s.target_action or '?'}", resolved=resolved))
                if not resolved:
                    estate.unresolved.append(Unresolved(
                        from_artifact=art.name, from_stage=s.name, ref=s.target_object, reason="missing"))
                    estate.blockers.append(Blocker(
                        artifact=art.name, page=s.subsheet, stage=s.name, kind="missing-reference",
                        severity="block", detail=f"Referenced object '{s.target_object}' not in export set"))
            elif s.type in ("SubSheet", "Page") and s.page_ref:  # SubSheet is the real page-call type
                resolved = s.page_ref in known_pages
                estate.edges.append(Edge(
                    from_artifact=art.name, from_stage=s.name, kind="page",
                    to=s.page_ref, resolved=resolved))

    # --- reachability / dead code (per artifact) ------------------------- #
    for art in estate.artifacts:
        stages = estate.stages_by_artifact.get(art.name, [])
        by_id = {s.id: s for s in stages if s.id}
        starts = [s for s in stages if s.type == "Start"]
        if not starts:
            continue
        reachable: set[str] = set()
        frontier = [s.id for s in starts]
        while frontier:
            sid = frontier.pop()
            if sid in reachable or sid not in by_id:
                continue
            reachable.add(sid)
            frontier.extend(by_id[sid].links)
        for s in stages:
            if (s.id and s.id not in reachable
                    and s.type != "Start" and s.type not in _NON_FLOW):
                estate.dead_code.append(DeadCode(artifact=art.name, kind="stage", ref=s.name or s.id))

    # --- orphan objects -------------------------------------------------- #
    called = {e.to.split(".")[0] for e in estate.edges if e.kind == "object-action"}
    for a in estate.artifacts:
        if a.type == "object" and a.name not in called:
            estate.dead_code.append(DeadCode(artifact=a.name, kind="object", ref=a.name))

    # --- back-links (non-reducible cycle proxy) -------------------------- #
    # Scoped PER PAGE, not per artifact: flow links never cross a page, so
    # comparing document positions of stages on different pages is meaningless
    # and manufactured most of the back-links on a real export.
    #
    # The loop stage types are LoopStart/LoopEnd — one word. They were written
    # "Loop Start"/"Loop End" here, so `in_loop` was never true and every honest
    # For-Each was reported as a cycle risk.
    for art in estate.artifacts:
        by_page: dict[str, list] = {}
        for s in estate.stages_by_artifact.get(art.name, []):
            by_page.setdefault(s.subsheet or "Main Page", []).append(s)
        for page, stages in by_page.items():
            if any(s.type in ("LoopStart", "LoopEnd") for s in stages):
                continue                      # an explicit loop is not a finding
            ids = {s.id for s in stages if s.id}
            g = nx.DiGraph()
            g.add_nodes_from(ids)
            names = {}
            for s in stages:
                if not s.id:
                    continue
                names[s.id] = s.name or s.id
                g.add_edges_from((s.id, t) for t in s.links if t in ids)
            # A cycle exists iff a strongly-connected component has >1 node (or
            # a node links to itself). Linear, exact, and order-independent.
            for comp in nx.strongly_connected_components(g):
                if len(comp) == 1:
                    n = next(iter(comp))
                    if not g.has_edge(n, n):
                        continue
                loop = sorted(names.get(n, n) for n in comp)
                estate.blockers.append(Blocker(
                    artifact=art.name, page=page, stage=loop[0], kind="backlink-cycle",
                    severity="warn",
                    detail=("Cycle with no loop stage, "
                            f"{len(comp)} stages: {', '.join(loop[:6])}"
                            f"{' …' if len(loop) > 6 else ''} "
                            "(non-reducible cycle risk in BPMN)")))

    # --- duplicate logic (identical page stage-type signatures) ---------- #
    sig_map: dict[str, list[str]] = {}
    for art in estate.artifacts:
        stages = estate.stages_by_artifact.get(art.name, [])
        pages: dict[str, list[str]] = {}
        for s in stages:
            pages.setdefault(s.subsheet or "Main", []).append(s.type)
        for page, types in pages.items():
            if len(types) < 3:
                continue
            sig = hashlib.sha1(("|".join(types)).encode()).hexdigest()[:12]
            sig_map.setdefault(sig, []).append(f"{art.name}/{page}")
    ci = 0
    for sig, members in sorted(sig_map.items()):
        if len(members) > 1:
            ci += 1
            estate.duplicates.append(Duplicate(cluster_id=f"dup{ci:03d}", members=sorted(members), hash=sig))

    # --- call graph stats (for coupling scoring; not serialized) --------- #
    g = nx.DiGraph()
    for a in estate.artifacts:
        g.add_node(a.name)
    for e in estate.edges:
        if e.kind == "object-action":
            g.add_edge(e.from_artifact, e.to.split(".")[0])
    estate.callgraph_stats = {  # type: ignore[attr-defined]
        n: {"fan_in": g.in_degree(n), "fan_out": g.out_degree(n)} for n in g.nodes
    }
