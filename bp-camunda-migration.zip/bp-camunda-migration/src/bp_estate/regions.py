"""Structured control-flow regions: loops and exception handlers.

Blue Prism encodes two control structures the flat stage graph does not make
explicit, and any migration target (BPMN error boundary, uFlow, …) needs them
lifted out of the raw stage soup rather than re-derived downstream:

  * LOOPS — a LoopStart / LoopEnd pair, matched by <groupid>, iterating a
    collection (<loopdata>). CONFIDENT: the pairing is an id match and the body
    is the flow between the two brackets on one page.

  * EXCEPTION HANDLERS — a Recover stage catches throws in a scope. The TRY
    scope and the CATCH handler are two orthogonal things, and the split was
    ground-truthed on a real 1109-stage bank process (23 Recovers, 67 Blocks):

      TRY SCOPE — GEOMETRIC (Block containment). A Recover is a POINT: 23/23 had
      a <display> with x,y but NO w,h, so a Recover cannot define its own extent.
      It sits inside a `Block` stage's rectangle, and that Block is the protected
      scope — 22/23 Recovers fell inside a Block (smallest one when nested), the
      lone loose Recover being the top-level last-resort handler (page scope).
      This replaces the earlier (wrong) guesses: a documentation answer said
      catch was forward link-flow — DISPROVEN, Recover stages have no inbound
      links; and document order — DISPROVEN, the gap to the next Recover/Resume
      ranged 0..80 (avg ~8, some 0), not a scope. Block sizes were 1..38 (avg
      ~14) — a real region. `scope_block` / `scope_stage_count`.

      CATCH — LINK FLOW. A Recover's own outbound links lead to a Resume or not.
      A Resume ends recovery mode (`resumes`); Recovers are NOT 1:1 with Resumes.
      The Resume is placed OUTSIDE the Block (0/22 Blocks-with-a-Recover held
      their Resume): recovery exits the scope, then Resume re-enters normal flow.
      No Resume => the exception never clears and PROPAGATES up the call stack
      (`escapes`, then `exception_propagation`).

Pure, deterministic functions over the parsed model. Stdlib only.
"""
from __future__ import annotations

from collections import defaultdict

from .config import Config
from .model import Estate, ExceptionHandler, ExceptionPropagation, LoopRegion


def _by_page(stages):
    pages: dict[str, list] = {}
    for s in stages:
        pages.setdefault(s.subsheet or "Main Page", []).append(s)
    return pages


def _contains(block, s) -> bool:
    """True if stage `s`'s anchor point falls inside Block `block`'s rectangle.
    Requires the block to actually have a rectangle (w,h) and `s` a point (x,y);
    a Block missing geometry contains nothing (we never invent bounds)."""
    if None in (block.x, block.y, block.w, block.h, s.x, s.y):
        return False
    return (block.x <= s.x <= block.x + block.w
            and block.y <= s.y <= block.y + block.h)


def _enclosing_block(recover, blocks):
    """The SMALLEST Block containing the Recover (innermost, when nested), or
    None if the Recover sits in no Block (a top-level / last-resort handler)."""
    holding = [b for b in blocks if _contains(b, recover)]
    if not holding:
        return None
    return min(holding, key=lambda b: b.w * b.h)


def _reach(start_links, by_id, page_ids, stop_ids=(), stop_types=()):
    """Stage ids reachable from `start_links`, staying on this page, never
    crossing a stop id and never continuing PAST a stop type (the stop stage
    itself is included so it stays visible, but its links are not followed)."""
    region: set[str] = set()
    frontier = list(start_links)
    while frontier:
        sid = frontier.pop()
        if sid in region or sid not in by_id or sid not in page_ids or sid in stop_ids:
            continue
        region.add(sid)
        if by_id[sid].type in stop_types:
            continue                      # reached a boundary — do not go beyond it
        frontier.extend(by_id[sid].links)
    return region


def run(estate: Estate, config: Config | None = None) -> None:
    # phase 2 (propagation) needs the set of pages that can let an exception
    # escape; it is gathered while walking the handlers.
    escaping_pages: set[tuple[str, str]] = set()
    artifact_names = {a.name for a in estate.artifacts}

    for art in estate.artifacts:
        stages = estate.stages_by_artifact.get(art.name, [])
        by_id = {s.id: s for s in stages if s.id}

        for page, pstages in _by_page(stages).items():
            page_ids = {s.id for s in pstages if s.id}

            # --- loops: pair LoopStart/LoopEnd by <groupid> ---------------- #
            ends_by_group = {s.group_id: s for s in pstages
                             if s.type == "LoopEnd" and s.group_id}
            for ls in pstages:
                if ls.type != "LoopStart":
                    continue
                le = ends_by_group.get(ls.group_id) if ls.group_id else None
                body = (_reach(ls.links, by_id, page_ids, stop_ids={le.id})
                        if le and le.id else set())
                estate.loop_regions.append(LoopRegion(
                    artifact=art.name, page=page,
                    start_stage=ls.name or ls.id,
                    end_stage=(le.name or le.id) if le else None,
                    collection=ls.loop_data,
                    body_stage_count=len(body),
                    resolved=le is not None,
                ))

            # --- exception handlers: one per Recover ---------------------- #
            # TRY scope is GEOMETRIC: the smallest Block containing the Recover
            # (real data — 22/23 Recovers sat inside a Block, sizes 1..38). A
            # Recover in no Block is the top-level, last-resort handler → page
            # scope. CATCH is LINK FLOW: the Recover's own outbound path to a
            # Resume (which is placed OUTSIDE the Block).
            blocks = [s for s in pstages if s.type == "Block"]
            for rc in pstages:
                if rc.type != "Recover":
                    continue
                region = _reach(rc.links, by_id, page_ids, stop_types=("Resume",))
                resumes = any(by_id[i].type == "Resume" for i in region)
                if not resumes:
                    escaping_pages.add((art.name, page))     # a re-raising handler
                blk = _enclosing_block(rc, blocks)
                if blk is not None:
                    scope_kind, scope_block = "block", (blk.name or blk.id)
                    scope_count = sum(1 for s in pstages
                                      if s is not blk and _contains(blk, s))
                else:
                    scope_kind, scope_block = "page", None
                    scope_count = len(pstages)
                estate.exception_handlers.append(ExceptionHandler(
                    artifact=art.name, page=page,
                    recover_stage=rc.name or rc.id,
                    recovery_path=sorted(by_id[i].name or i for i in region),
                    resumes=resumes,
                    escapes=not resumes,
                    scope_kind=scope_kind,
                    scope_block=scope_block,
                    scope_stage_count=scope_count,
                ))

            # a throw with no Recover at all on the page escapes with certainty
            if (any(s.type == "Exception" for s in pstages)
                    and not any(s.type == "Recover" for s in pstages)):
                escaping_pages.add((art.name, page))

    _propagate(estate, escaping_pages, artifact_names)


def _propagate(estate, escaping_pages, artifact_names) -> None:
    """For each page that can let an exception escape, record where it surfaces:
    every stage that CALLS that page — a SubSheet call (same artifact) or an
    Action call to an object action (another artifact). CONFIRMED against BP's
    model: with no Resume the exception propagates up the call stack.

    We record the call SITE (one hop), not whether the caller ultimately catches
    it: that depends on the caller's positional recovery scope, which we cannot
    model yet (see the exception-handler note in run()). So the emitter knows
    where to attach an error boundary; whether BP caught it there is deferred."""
    # (callee_artifact, callee_page) -> [(caller_art, caller_page, via_name, kind)]
    call_sites: dict[tuple[str, str], list] = defaultdict(list)
    for art in estate.artifacts:
        for s in estate.stages_by_artifact.get(art.name, []):
            caller_page = s.subsheet or "Main Page"
            if s.type in ("SubSheet", "Page") and s.page_ref:
                call_sites[(art.name, s.page_ref)].append(
                    (art.name, caller_page, s.name or s.id, "page-call"))
            elif (s.type == "Action" and s.target_object in artifact_names
                  and s.target_action):
                call_sites[(s.target_object, s.target_action)].append(
                    (art.name, caller_page, s.name or s.id, "object-action"))

    for callee_art, callee_page in escaping_pages:
        for caller_art, caller_page, via_name, kind in \
                call_sites.get((callee_art, callee_page), []):
            estate.exception_propagation.append(ExceptionPropagation(
                from_artifact=callee_art, from_page=callee_page,
                to_artifact=caller_art, to_page=caller_page,
                via_stage=via_name, kind=kind,
            ))
