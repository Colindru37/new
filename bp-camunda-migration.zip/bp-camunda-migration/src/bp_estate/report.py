"""Emit estate.json (schema-validated) + a human report + CSV exports."""
from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path

from .model import Estate


def _validate(doc: dict, schema_path: Path) -> None:
    import jsonschema  # local import keeps core import light
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    jsonschema.validate(doc, schema)


def write_all(estate: Estate, out_dir: Path, schema_path: Path | None = None) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    doc = estate.to_dict()
    if schema_path:
        _validate(doc, schema_path)

    estate_json = out_dir / "estate.json"
    estate_json.write_text(estate.dumps(), encoding="utf-8")

    _write_report(estate, out_dir / "estate-report.md")
    _write_csv(out_dir / "blockers.csv",
               ["severity", "kind", "artifact", "page", "stage", "detail"],
               [(b.severity, b.kind, b.artifact, b.page, b.stage, b.detail) for b in estate.blockers])
    _write_csv(out_dir / "unresolved.csv",
               ["reason", "from_artifact", "from_stage", "ref"],
               [(u.reason, u.from_artifact, u.from_stage, u.ref) for u in estate.unresolved])
    _write_csv(out_dir / "shared-resources.csv",
               ["type", "name", "consumers", "used_by"],
               _shared_rows(estate))
    return estate_json


def _shared_rows(estate: Estate):
    rows = []
    for q in estate.queues:
        if len(q.used_by) > 1:
            rows.append(("queue", q.name, len(q.used_by), "; ".join(sorted(q.used_by))))
    for c in estate.credentials:
        if len(c.requested_by) > 1:
            rows.append(("credential", c.name, len(c.requested_by), "; ".join(sorted(c.requested_by))))
    for l in estate.env_locks:
        if len(l.locked_by) > 1:
            rows.append(("lock", l.name, len(l.locked_by), "; ".join(sorted(l.locked_by))))
    rows.sort()
    return rows


def _write_csv(path: Path, header, rows):
    with path.open("w", newline="", encoding="utf-8") as fh:
        wr = csv.writer(fh)
        wr.writerow(header)
        for r in sorted(rows, key=lambda x: tuple("" if v is None else str(v) for v in x)):
            wr.writerow(["" if v is None else v for v in r])


def _write_report(estate: Estate, path: Path) -> None:
    tiers = Counter(t.tier for t in estate.object_tiers)
    blk = Counter(b.kind for b in estate.blockers)
    lines = []
    add = lines.append
    add("# Blue Prism Estate Report\n")
    add(f"- Artifacts: **{len(estate.artifacts)}** "
        f"({sum(a.type=='process' for a in estate.artifacts)} processes, "
        f"{sum(a.type=='object' for a in estate.artifacts)} objects)")
    add(f"- Object tiers: internal={tiers['internal']}, shipped={tiers['shipped']}, custom={tiers['custom']}")
    add(f"- Work queues: {len(estate.queues)} | Credentials: {len(estate.credentials)} | Env locks: {len(estate.env_locks)}")
    add(f"- Blockers: **{len(estate.blockers)}** | Unresolved: {len(estate.unresolved)} "
        f"| Dead code: {len(estate.dead_code)} | Duplicate clusters: {len(estate.duplicates)}\n")

    add("## Blockers by kind")
    for kind, n in sorted(blk.items()):
        add(f"- `{kind}`: {n}")
    add("")

    # The application inventory. Deterministic, straight out of Application
    # Modeller — this is the "what does the estate actually touch" answer, and
    # it is the input to every API conversation the migration needs to have.
    if estate.applications:
        add("## Applications driven")
        add("| Application | Driven by | How | UI elements | Executable |")
        add("|---|---|---|---|---|")
        for a in sorted(estate.applications, key=lambda x: x.name):
            how = ", ".join(sorted(a.launch_types)) or "attach only"
            if not a.launches:
                how += " (never launched here)"
            exe = f"`{a.executable}`" if a.executable else "-"
            add(f"| {a.name} | {len(a.driven_by)} | {how} | {a.element_count} | {exe} |")
        add("")
        for a in sorted(estate.applications, key=lambda x: x.name):
            add(f"- **{a.name}** driven by: " + ", ".join(f"`{o}`" for o in sorted(a.driven_by)))
        add("")

    shared = _shared_rows(estate)
    if shared:
        add("## Shared resources (migration coupling points)")
        add("| Type | Name | Consumers |")
        add("|---|---|---|")
        for typ, name, n, _ in shared:
            add(f"| {typ} | {name} | {n} |")
        add("")

    if estate.dead_code:
        add("## Dead code")
        for d in sorted(estate.dead_code, key=lambda x: (x.artifact, x.kind, x.ref)):
            add(f"- {d.kind}: `{d.artifact}` :: {d.ref}")
        add("")

    add("## Migration waves")
    add("| Wave | Artifact | Type | complexity | risk | coupling |")
    add("|---|---|---|---|---|---|")
    tmap = {a.name: a.type for a in estate.artifacts}
    for s in sorted(estate.scores, key=lambda x: (x.wave or 0, x.artifact)):
        add(f"| {s.wave} | {s.artifact} | {tmap.get(s.artifact,'')} | "
            f"{s.complexity} ({s.complexity_band}) | {s.risk} ({s.risk_band}) | {s.coupling} ({s.coupling_band}) |")
    add("")
    path.write_text("\n".join(lines), encoding="utf-8")
