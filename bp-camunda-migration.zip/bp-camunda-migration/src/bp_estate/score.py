"""Complexity / risk / coupling scoring + call-graph roll-up + wave planning.
All weights come from data/weights.yaml — this module only computes features.
"""
from __future__ import annotations

import re

from .config import Config
from .model import Estate, Score

_ARITH = re.compile(r"[+\-*/]|[<>]=?")
_EXC = {"Exception", "Recover", "Resume"}


def _artifact_features(estate: Estate, config: Config, art) -> dict:
    reg = config.registry
    stages = estate.stages_by_artifact.get(art.name, [])
    data_items = [d for d in estate.data_items if d.artifact == art.name]
    collections = [c for c in estate.collections if c.artifact == art.name]

    called_objects = {s.target_object for s in stages if s.type == "Action" and s.target_object}
    sem_counts: dict[str, int] = {}
    for s in stages:
        if s.type == "Action" and s.target_object:
            for tag in reg.action_semantics(s.target_object, s.target_action or ""):
                sem_counts[tag] = sem_counts.get(tag, 0) + 1

    code_stages = [s for s in stages if s.type == "Code"]
    backlinks = sum(1 for b in estate.blockers if b.artifact == art.name and b.kind == "backlink-cycle")
    money = sum(1 for s in stages if s.type in ("Calculation", "Decision")
                and s.expression and _ARITH.search(s.expression))
    queue_edges = sum(1 for e in estate.edges if e.from_artifact == art.name and e.kind == "queue")
    lock_edges = sum(1 for e in estate.edges if e.from_artifact == art.name and e.kind == "lock")
    cred_edges = sum(1 for e in estate.edges if e.from_artifact == art.name and e.kind == "credential")

    complexity = {
        "stage_count": art.stage_count,
        "page_count": len(art.pages),
        "object_fan_out": len(called_objects),
        "data_item_count": len(data_items),
        "global_data_usage": sum(1 for d in data_items if d.scope == "session"),
        "exception_depth": sum(1 for s in stages if s.type in _EXC),
        "code_stage_count": len(code_stages),
        "code_stage_loc": sum(s.code_loc for s in code_stages),
        "backlink_count": backlinks,
        "appmodel_element_count": 0,   # populated once <appdef> parsing lands
        "appmodel_fragility": 0,
        "queue_involvement": queue_edges,
    }
    risk = {
        "money_decimal_calc": money,
        "date_calendar_logic": sem_counts.get("date-sensitive", 0),
        "timezone_sensitive": sem_counts.get("timezone-sensitive", 0),
        "idempotency_sensitive": sem_counts.get("idempotency-sensitive", 0),
        "credential_usage": cred_edges,
        "pii_collection": sum(1 for c in collections if c.pii_suspect),
        "environment_lock": lock_edges,
        "exception_construct": sum(1 for s in stages if s.type in _EXC),
        "code_stage_present": 1 if code_stages else 0,
    }
    stats = getattr(estate, "callgraph_stats", {}).get(art.name, {"fan_in": 0, "fan_out": 0})
    coupling = {
        "shared_object_fan_in": sum(
            getattr(estate, "callgraph_stats", {}).get(o, {}).get("fan_in", 0)
            for o in called_objects
            if getattr(estate, "callgraph_stats", {}).get(o, {}).get("fan_in", 0) > 1),
        "shared_queue_fan_in": sum(len(q.used_by) for q in estate.queues
                                   if art.name in q.used_by and len(q.used_by) > 1),
        "shared_credential": sum(1 for c in estate.credentials
                                 if art.name in c.requested_by and len(c.requested_by) > 1),
        "shared_env_var": sum(1 for v in estate.env_vars
                              if art.name in v.referenced_by and len(v.referenced_by) > 1),
        "consumed_by_count": stats["fan_in"],
    }
    return {"complexity": complexity, "risk": risk, "coupling": coupling,
            "called": called_objects}


def run(estate: Estate, config: Config) -> None:
    w = config.weights
    base: dict[str, dict] = {}
    for art in estate.artifacts:
        f = _artifact_features(estate, config, art)
        base[art.name] = {
            "called": f["called"],
            "complexity": w.score("complexity", f["complexity"]),
            "risk": w.score("risk", f["risk"]),
            "coupling": w.score("coupling", f["coupling"]),
        }

    # single-level roll-up: a caller inherits a fraction of each called object's score
    frac = float(w.rollup.get("child_contribution", 0) or 0)
    object_names = {a.name for a in estate.artifacts if a.type == "object"}
    rolled: dict[str, dict] = {}
    for name, b in base.items():
        cx, rk = b["complexity"], b["risk"]
        for child in b["called"]:
            if child in object_names and child in base:
                cx += frac * base[child]["complexity"]
                rk += frac * base[child]["risk"]
        rolled[name] = {"complexity": round(cx, 3), "risk": round(rk, 3), "coupling": b["coupling"]}

    for art in estate.artifacts:
        r = rolled[art.name]
        estate.scores.append(Score(
            artifact=art.name,
            complexity=r["complexity"], risk=r["risk"], coupling=r["coupling"],
            complexity_band=w.band("complexity", r["complexity"]),
            risk_band=w.band("risk", r["risk"]),
            coupling_band=w.band("coupling", r["coupling"]),
        ))

    _plan_waves(estate, config)


def _plan_waves(estate: Estate, config: Config) -> None:
    cfg = config.weights.waves
    keys = cfg.get("order_by", ["coupling", "risk", "complexity"])
    size = int(cfg.get("wave_size_hint", 15) or 15)
    ordered = sorted(estate.scores, key=lambda s: (
        tuple(getattr(s, k) for k in keys), s.artifact))
    for i, s in enumerate(ordered):
        s.wave = (i // size) + 1
