"""The estate fact base — plain dataclasses that mirror estate.schema.json 1:1.

Kept deliberately boring (stdlib dataclasses, no framework) so a future C#
`record` port is a mechanical translation. `Estate.to_dict()` emits the schema
shape with everything sorted, for byte-deterministic output.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict


# --------------------------------------------------------------------------- #
# In-memory only (NOT serialized) — used by analyze passes
# --------------------------------------------------------------------------- #
@dataclass
class Stage:
    id: str
    name: str
    type: str
    subsheet: str | None = None                             # resolved PAGE NAME, not the id
    narrative: str | None = None                            # the stage's description/comment
    links: list[str] = field(default_factory=list)          # outbound target stage ids
    target_object: str | None = None                        # Action: called object
    target_action: str | None = None                        # Action: called action
    page_ref: str | None = None                             # Page stage: referenced page NAME
    inputs: dict[str, str] = field(default_factory=dict)    # param name -> BP expression
    outputs: dict[str, str] = field(default_factory=dict)   # output name -> capturing Data stage
    input_stages: dict[str, str] = field(default_factory=dict)  # Start: page input name -> receiving Data stage
    expression: str | None = None
    calc_targets: list[str] = field(default_factory=list)   # Calculation: the Data stage(s) written
    choice_exprs: list[str] = field(default_factory=list)   # ChoiceStart: branch condition per link
    choice_names: list[str] = field(default_factory=list)   # ChoiceStart: branch label per link (same order)
    code_language: str | None = None
    code_loc: int = 0
    code_text: str | None = None                            # Code: the source, verbatim (the port's input)
    code_external: list[str] = field(default_factory=list)  # Code: outside-world touch points (empty = pure logic)
    group_id: str | None = None                             # pairs ChoiceStart/End, LoopStart/End
    loop_data: str | None = None                            # LoopStart: the iterated collection (BP expr)
    loop_type: str | None = None                            # LoopStart: BP loop kind
    exception_type: str | None = None                       # Exception: "System"/"Business" Exception
    exception_detail: str | None = None                     # Exception: the thrown message (BP expr)
    x: float | None = None                                  # <display> diagram geometry (top-left)
    y: float | None = None
    w: float | None = None                                  # width/height: only container types (Block) carry these
    h: float | None = None


# --------------------------------------------------------------------------- #
# Serialized entities
# --------------------------------------------------------------------------- #
@dataclass
class Artifact:
    id: str
    name: str
    type: str                       # "process" | "object"
    version: str | None = None
    bpversion: str | None = None
    narrative: str | None = None
    published: bool | None = None   # false => cannot run in production
    pages: list[str] = field(default_factory=list)
    stage_count: int = 0


@dataclass
class Application:
    """A real application some object drives through Application Modeller.

    This is the estate's answer to "what does this bot actually touch", and it
    is fully deterministic — it comes out of <appdef>, so it must never be
    asked of a model. One application is usually driven by SEVERAL objects
    (classically one that launches it and one that attaches to it), so the
    grouping key is the application name, not the object.
    """
    name: str
    driven_by: list[str] = field(default_factory=list)   # object names
    launch_types: list[str] = field(default_factory=list)  # Win32Launch, HTML, ...
    executable: str | None = None
    element_count: int = 0          # UI surface area: how much there is to re-host
    launches: bool = False          # some object starts it, vs attach-only


@dataclass
class Page:
    """A subsheet. `published` decides whether the page is visible when the
    artifact is embedded elsewhere — and how severely a diff on it is graded."""
    artifact: str
    name: str
    published: bool | None = None


@dataclass
class DataItem:
    artifact: str
    name: str
    datatype: str
    scope: str                      # "local" | "session"
    initial_value: str | None = None
    page: str | None = None         # the page that declares it (BP declares Data PER PAGE)
    always_init: bool = False       # <alwaysinit/>: reset to initial_value every time the page runs


@dataclass
class Collection:
    artifact: str
    name: str
    fields: list[str] = field(default_factory=list)
    scope: str = "session"          # "local" (<private/>) | "session", like DataItem
    page: str | None = None         # the page that declares it
    pii_suspect: bool = False
    pii_categories: list[str] = field(default_factory=list)


@dataclass
class EnvVar:
    name: str
    type: str | None = None
    value: str | None = None
    referenced_by: list[str] = field(default_factory=list)


@dataclass
class Queue:
    name: str
    used_by: list[str] = field(default_factory=list)
    key_field: str | None = None
    max_attempts: int | None = None
    encrypted: bool | None = None
    dynamic_name: bool = False


@dataclass
class Credential:
    name: str
    requested_by: list[str] = field(default_factory=list)
    dynamic_name: bool = False


@dataclass
class EnvLock:
    name: str
    locked_by: list[str] = field(default_factory=list)
    dynamic_name: bool = False


@dataclass
class Edge:
    from_artifact: str
    kind: str                       # object-action | page | queue | credential | lock | calendar
    to: str
    resolved: bool
    from_stage: str | None = None


@dataclass
class Blocker:
    artifact: str
    kind: str
    detail: str
    severity: str                   # info | warn | block
    page: str | None = None
    stage: str | None = None


@dataclass
class ObjectTier:
    object: str
    tier: str
    migration_target: str | None = None


@dataclass
class Duplicate:
    cluster_id: str
    members: list[str]
    hash: str = ""


@dataclass
class DeadCode:
    artifact: str
    kind: str
    ref: str


@dataclass
class Unresolved:
    from_artifact: str
    ref: str
    reason: str                     # external | dynamic | missing
    from_stage: str | None = None


@dataclass
class LoopRegion:
    """A structured for-each: a LoopStart/LoopEnd pair (matched by <groupid>)
    iterating a collection. The target's emitter turns this into a loop; the
    body is whatever runs between the two brackets on the same page."""
    artifact: str
    page: str
    start_stage: str                # LoopStart name
    end_stage: str | None = None    # LoopEnd name (None => unmatched bracket, a defect)
    collection: str | None = None   # the iterated collection (BP expr, verbatim)
    body_stage_count: int = 0
    resolved: bool = True           # False => start/end could not be paired


@dataclass
class ExceptionHandler:
    """A Blue Prism recovery section: a Recover stage (entered when a stage in
    scope throws) whose recovery path runs until a Resume (which clears the
    exception) or ends. Maps to an error boundary + handler in the target.

    Two orthogonal things, confirmed on the real 1109-stage process:
      * The TRY scope (what it protects) is GEOMETRIC — `scope_block` /
        `scope_stage_count`. A Recover is a point (no width/height) that sits
        inside a `Block` stage's rectangle; that Block is the protected scope.
        22 of the process's 23 Recovers sat inside a Block; the lone loose one
        is the top-level, last-resort handler (`scope_kind = "page"`).
      * The CATCH (what it DOES) is by LINK FLOW — `recovery_path` / `resumes` /
        `escapes` — a Recover's own outbound links to a Resume. The Resume is
        placed OUTSIDE the Block (0 of 22 Blocks-with-a-Recover contained their
        Resume): recovery exits the scope, then Resume re-enters normal flow.
    See the module docstring in regions.py for the evidence."""
    artifact: str
    page: str
    recover_stage: str              # the Recover (handler entry) name
    recovery_path: list[str] = field(default_factory=list)  # reachable recovery stages (sorted), Recover up to a Resume
    resumes: bool = False           # region reaches a Resume (exception cleared) vs falls through
    escapes: bool = False           # no Resume => exception propagates up the call stack
    scope_kind: str = "page"        # "block" (Recover inside a Block) | "page" (no enclosing Block)
    scope_block: str | None = None  # the enclosing Block's name (None => page-scoped)
    scope_stage_count: int = 0      # stages geometrically inside the scope (Block, or whole page)


@dataclass
class ExceptionPropagation:
    """Where an escaping exception SURFACES: a page that lets an exception escape
    (no Resume) surfaces it at every stage that CALLS that page — a SubSheet call
    (same artifact) or an Action call to an object action (another artifact).

    We record the call site, NOT whether the caller ultimately catches it: that
    depends on the caller's positional recovery scope, which is not modelled
    (real Recover stages have no inbound links). The emitter learns where to
    attach an error boundary; whether Blue Prism caught it there is deferred."""
    from_artifact: str
    from_page: str                  # the escaping callee page
    to_artifact: str
    to_page: str                    # caller page holding the call site
    via_stage: str                  # the SubSheet / Action call-site stage
    kind: str                       # "page-call" | "object-action"


@dataclass
class Score:
    artifact: str
    complexity: float
    risk: float
    coupling: float
    complexity_band: str = "low"
    risk_band: str = "low"
    coupling_band: str = "low"
    wave: int | None = None


class Estate:
    """Aggregate root. Enrichment passes append to these lists."""

    def __init__(self) -> None:
        self.artifacts: list[Artifact] = []
        self.applications: list[Application] = []
        self.pages: list[Page] = []
        self.data_items: list[DataItem] = []
        self.collections: list[Collection] = []
        self.env_vars: list[EnvVar] = []
        self.queues: list[Queue] = []
        self.credentials: list[Credential] = []
        self.env_locks: list[EnvLock] = []
        self.edges: list[Edge] = []
        self.blockers: list[Blocker] = []
        self.object_tiers: list[ObjectTier] = []
        self.duplicates: list[Duplicate] = []
        self.dead_code: list[DeadCode] = []
        self.unresolved: list[Unresolved] = []
        self.loop_regions: list[LoopRegion] = []
        self.exception_handlers: list[ExceptionHandler] = []
        self.exception_propagation: list[ExceptionPropagation] = []
        self.scores: list[Score] = []
        # in-memory only, not serialized:
        self.stages_by_artifact: dict[str, list[Stage]] = {}

    # -- deterministic serialization ------------------------------------- #
    def to_dict(self) -> dict:
        def rows(items, *sort_keys):
            out = [asdict(x) for x in items]
            out.sort(key=lambda d: tuple(str(d.get(k, "")) for k in sort_keys))
            return out

        return {
            "meta": {
                "schema_version": 1,
                "artifact_count": len(self.artifacts),
                "generated_by": "bp-estate",
            },
            "artifacts":    rows(self.artifacts, "type", "name", "id"),
            "applications": rows(self.applications, "name"),
            "pages":        rows(self.pages, "artifact", "name"),
            "data_items":   rows(self.data_items, "artifact", "name"),
            "collections":  rows(self.collections, "artifact", "name"),
            "env_vars":     rows(self.env_vars, "name"),
            "queues":       rows(self.queues, "name"),
            "credentials":  rows(self.credentials, "name"),
            "env_locks":    rows(self.env_locks, "name"),
            "edges":        rows(self.edges, "from_artifact", "kind", "to", "from_stage"),
            "blockers":     rows(self.blockers, "severity", "artifact", "kind", "stage"),
            "object_tiers": rows(self.object_tiers, "tier", "object"),
            "duplicates":   rows(self.duplicates, "cluster_id"),
            "dead_code":    rows(self.dead_code, "artifact", "kind", "ref"),
            "unresolved":   rows(self.unresolved, "from_artifact", "ref", "reason"),
            "loop_regions": rows(self.loop_regions, "artifact", "page", "start_stage"),
            "exception_handlers": rows(self.exception_handlers, "artifact", "page", "recover_stage"),
            "exception_propagation": rows(self.exception_propagation,
                                          "from_artifact", "from_page", "to_page", "via_stage"),
            "scores":       rows(self.scores, "artifact"),
        }

    def dumps(self) -> str:
        # sort_keys + fixed separators => byte-deterministic across runs/platforms.
        return json.dumps(self.to_dict(), indent=2, sort_keys=True, ensure_ascii=False) + "\n"
