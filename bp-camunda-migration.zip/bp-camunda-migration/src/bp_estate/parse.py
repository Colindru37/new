"""Blue Prism XML -> structural model.

Reconciled against the bank's "BP Description" reference (photographed; see the
gitignored rules/ folder). What that doc CONFIRMS, and this module now follows:

  * Three file types, all XML: .bpprocess (automation logic), .bpobject (UI
    automation — same <process> schema plus an <appdef>), .bprelease (a bundle
    that can contain both, used for import/export/deploy).
  * <process name preferredid published> is the root. published=false means the
    artifact cannot run in production.
  * <view> is ignored by design.
  * <subsheet subsheetid published> carries the page name in a CHILD <name>.
    subsheetid is an internal id (generated); the human-meaningful, stable key
    is the name. Every process has a "Main Page" that cannot be renamed.
  * <stage stageid name type> with children <narrative>, <display x y w h>, and
    for type=Data: <datatype>, <initialvalue>, <private/>.
      - <private/> is PRESENCE-based: the element merely existing means private.
      - a MISSING <subsheetid> means the stage lives on "Main Page".
  * Action stages carry <inputs><input type name narrative expr/></inputs> and
    <outputs><output type name narrative stage/></outputs>, where output@stage
    names the Data stage that captures the return value. Input values are BP
    EXPRESSIONS (a text literal is quoted: "Payments") — not bare strings.
  * Data types: Date, DateTime, Flag (boolean), Number, Password, Text, Time,
    TimeSpan, Image, Binary. Preserved verbatim — casing is not asserted.

CONFIRMED against real scrubbed stage XML from a bank process:
  * flow links are element TEXT of <onsuccess> (normal) / <ontrue> / <onfalse>
    (a Decision's branches sit on the STAGE, not inside <decision>);
  * a choice is a ChoiceStart/ChoiceEnd bracket pair (no "Choice" type), and a
    branch's target is <ontrue> inside <choice expression="..">;
  * Calculation and MultipleCalculation are distinct — one direct <calculation
    expression stage/> vs several nested under <steps>;
  * an Action's target is <resource object=".." action=".."/>;
  * a page call is type SubSheet with <processid>;
  * Decision holds <decision expression=".."/>; Exception holds <exception
    type=".." detail=".."/>; loops carry <groupid>/<looptype>/<loopdata>.

STILL UNCONFIRMED: <collectioninfo>/<field> internals (a real Collection stage
was seen carrying only <datatype>collection</datatype>, no field block — so the
field shape is still unconfirmed) and <code language> (the sample process had
zero Code stages; its C# lives inside Utility - Environment (C#) Action calls).
Not yet MODELLED (shapes now known, mapping deferred): the exception scope
(Exception / Recover / Resume) and loops (LoopStart / LoopEnd).

Namespace-agnostic: real exports are commonly namespaced, so every lookup
compares LOCAL element names rather than a hardcoded namespace URI.

Uses stdlib xml.etree (no C build). Swap to lxml (optional dep) later for
precise line/XPath error locations.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

from .model import (
    Application, Artifact, Blocker, Collection, DataItem, EnvVar, Estate, Page, Stage,
)

_LINK_TAGS = ("onsuccess", "ontrue", "onfalse")      # CONFIRMED (element text)
_MAIN_PAGE = "Main Page"                             # cannot be renamed (doc)
_EXT_TYPE = {".bpprocess": "process", ".bpobject": "object"}


# --------------------------------------------------------------------------- #
# namespace-agnostic element access
# --------------------------------------------------------------------------- #
def _local(tag: object) -> str:
    """Local name of an element tag, ignoring any {namespace} prefix."""
    return str(tag).rsplit("}", 1)[-1]


def _kid(el: ET.Element, name: str) -> ET.Element | None:
    for child in el:
        if _local(child.tag) == name:
            return child
    return None


def _kids(el: ET.Element, name: str) -> list[ET.Element]:
    return [child for child in el if _local(child.tag) == name]


def _text(el: ET.Element | None) -> str | None:
    if el is None or el.text is None:
        return None
    return el.text.strip() or None


def _kid_text(el: ET.Element, name: str) -> str | None:
    return _text(_kid(el, name))


def _flag(raw: str | None, default: bool | None = None) -> bool | None:
    if raw is None:
        return default
    return raw.strip().lower() in ("true", "1", "yes")


# What a Code stage reaches for outside the process. A stage that matches none of
# these is PURE LOGIC: data in, data out, portable to an engine script. One that
# matches stays a worker whatever else happens -- the engine has no COM, no
# browser, no file system. Deterministic, over-inclusive on purpose.
CODE_EXTERNAL = {
    "com-office": r"Interop|Marshal\.|CreateObject|\bWord\.|\bExcel\.|Outlook\.",
    "web-http": r"HttpWebRequest|HttpClient|WebRequest|WebClient|WebDriver|HttpListener|Uri\(|/session",
    "filesystem": r"System\.IO|\bFile\.|\bDirectory\.|StreamWriter|StreamReader|FileStream",
    "process-os": r"Process\.Start|ProcessStartInfo|\bRegistry|Environment\.(GetEnvironmentVariable|UserName|MachineName)",
    "network": r"SmtpClient|MailMessage|\bSocket\b|TcpClient|Dns\.",
    "ui": r"SendKeys|FindWindow|user32|System\.Windows\.Forms|Clipboard\.",
}


def code_external(text: str | None) -> list[str]:
    if not text:
        return []
    return [k for k, pat in CODE_EXTERNAL.items() if re.search(pat, text)]


def _loc(code: str | None) -> int:
    if not code:
        return 0
    return sum(1 for line in code.splitlines() if line.strip())


def _num(raw: str | None) -> float | None:
    """A <display> coordinate. Absent or non-numeric => None (never invented)."""
    if raw is None:
        return None
    try:
        return float(raw.strip())
    except ValueError:
        return None


# --------------------------------------------------------------------------- #
# artifact typing
# --------------------------------------------------------------------------- #
def _artifact_type(el: ET.Element, path: Path, wrapper_tag: str | None = None) -> str:
    """process | object.

    The file extension is authoritative per the doc (.bpobject *are* objects).
    Inside a .bprelease the extension tells us nothing, but the release wraps
    each body in a <process>/<object> element whose tag *is* the type — that is
    authoritative and is passed in as `wrapper_tag`.

    The <appdef> fallback is last resort only. It is not reliable: a code-only
    VBO has no Application Modeller definition and would be mistyped a process.
    """
    ext = path.suffix.lower()
    if ext in _EXT_TYPE:
        return _EXT_TYPE[ext]
    if wrapper_tag in ("process", "object"):
        return wrapper_tag
    declared = (el.get("type") or "").strip().lower()
    if declared in ("process", "object"):
        return declared
    return "object" if _kid(el, "appdef") is not None else "process"


# --------------------------------------------------------------------------- #
# application modeller
# --------------------------------------------------------------------------- #
# Every object carries an <appdef>, but most of them carry an EMPTY one: a
# single "Application Root" element and no <apptypeinfo><id>. That is a
# code-only VBO — it drives no application at all. Counting those as
# applications would inflate the estate's re-hosting surface with utilities
# that only shuffle collections around.
_STUB_ROOTS = {"application root", ""}


def _parse_appdef(body: ET.Element, art: Artifact, estate: Estate) -> None:
    ad = _kid(body, "appdef")
    if ad is None:
        return

    elements = [el for el in ad.iter() if _local(el.tag) == "element"]
    roots = [el for el in ad if _local(el.tag) == "element"]
    app_name = (roots[0].get("name") or "").strip() if roots else ""

    ti = next((el for el in ad.iter() if _local(el.tag) == "apptypeinfo"), None)
    launch_type = _kid_text(ti, "id") if ti is not None else None
    launch_type = (launch_type or "").strip()

    # A real application declares HOW it is driven, or models more than the bare
    # root. Anything else is the empty default Blue Prism gives every object.
    if not launch_type and (len(elements) <= 1 or app_name.lower() in _STUB_ROOTS):
        return
    if not app_name or app_name.lower() in _STUB_ROOTS:
        app_name = art.name

    executable = None
    for par in ad.iter():
        if _local(par.tag) != "parameter":
            continue
        vals = {_local(c.tag): (c.text or "").strip() for c in par}
        if vals.get("name") == "Path" and vals.get("value"):
            executable = vals["value"]

    app = next((a for a in estate.applications if a.name == app_name), None)
    if app is None:
        app = Application(name=app_name)
        estate.applications.append(app)

    if art.name not in app.driven_by:
        app.driven_by.append(art.name)
    if launch_type and launch_type not in app.launch_types:
        app.launch_types.append(launch_type)
    # "Launch" starts the application; "Attach" joins one already running. An
    # estate where nothing launches an app is depending on something external
    # to start it — worth seeing at a glance.
    if "launch" in launch_type.lower():
        app.launches = True
    app.executable = app.executable or executable
    # Elements are a tree; the total node count is the UI surface a re-host has
    # to reproduce. Take the largest object's view rather than summing, since
    # two objects modelling the same app overlap heavily.
    app.element_count = max(app.element_count, len(elements))


# --------------------------------------------------------------------------- #
# parsing
# --------------------------------------------------------------------------- #
def _parse_process(
    root: ET.Element,
    path: Path,
    estate: Estate,
    wrapper: ET.Element | None = None,
) -> None:
    """Parse one artifact body.

    In a .bprelease the body is nested inside a wrapper element that carries the
    real id, name and type; the body itself repeats the name but has no id.
    """
    wrapper_tag = _local(wrapper.tag) if wrapper is not None else None
    ids = (wrapper, root) if wrapper is not None else (root,)
    artifact_id = next(
        (e.get("preferredid") or e.get("id") for e in ids
         if e.get("preferredid") or e.get("id")),
        path.stem,
    )
    art = Artifact(
        id=artifact_id,
        name=root.get("name") or (wrapper.get("name") if wrapper is not None else None) or path.stem,
        type=_artifact_type(root, path, wrapper_tag),
        version=root.get("version"),
        bpversion=root.get("bpversion"),
        narrative=_kid_text(root, "narrative"),
        published=_flag(root.get("published")),
    )

    # --- pages: subsheetid -> name -------------------------------------- #
    # Stages reference pages by internal id, but every human-facing output
    # (blockers, dead code, duplicate clusters) must name the page, so resolve
    # ids to names here and keep the rest of the pipeline in name-space.
    id2name: dict[str, str] = {}
    pages: list[str] = []
    for ss in _kids(root, "subsheet"):
        ssid = ss.get("subsheetid") or ""
        name = _kid_text(ss, "name") or ss.get("name") or ssid
        if not name:
            continue
        if ssid:
            id2name[ssid] = name
        pages.append(name)
        estate.pages.append(
            Page(artifact=art.name, name=name, published=_flag(ss.get("published")))
        )
    art.pages = pages

    def page_of(raw: str | None) -> str:
        """Resolve a subsheet id to its page name. A missing id means Main Page
        (doc). An unknown id is returned as-is rather than invented."""
        if not raw:
            return _MAIN_PAGE
        return id2name.get(raw, raw)

    # --- stages ---------------------------------------------------------- #
    stages: list[Stage] = []
    for st in _kids(root, "stage"):
        stype = st.get("type", "")
        stage = Stage(
            id=st.get("stageid", ""),
            name=st.get("name", ""),
            type=stype,
            subsheet=page_of(_kid_text(st, "subsheetid")),
            narrative=_kid_text(st, "narrative"),
            # CONFIRMED: <groupid> pairs a bracket's start with its end
            # (ChoiceStart/End, LoopStart/End). Absent on non-bracket stages.
            group_id=_kid_text(st, "groupid"),
        )

        # <display x y w h> — diagram geometry. Every stage has x,y (top-left);
        # only container types (Block) carry w,h. Load-bearing: a real-data probe
        # showed exception recovery scope is Block CONTAINMENT (a Recover — a
        # point, no w,h — is guarded by the Block rectangle it sits inside), so
        # regions.py needs the coordinates to resolve each Recover to its Block.
        disp = _kid(st, "display")
        if disp is not None:
            stage.x = _num(disp.get("x"))
            stage.y = _num(disp.get("y"))
            stage.w = _num(disp.get("w"))
            stage.h = _num(disp.get("h"))
        # Real exports carry geometry as CHILD ELEMENTS
        # (<displayx>15</displayx><displayy>-135</displayy>...), not <display>
        # attributes. Fall back to that form so coordinates (hence Block-scope
        # detection AND diagram layout) survive on real data, not just fixtures.
        if stage.x is None:
            stage.x = _num(_kid_text(st, "displayx"))
            stage.y = _num(_kid_text(st, "displayy"))
            stage.w = _num(_kid_text(st, "displaywidth"))
            stage.h = _num(_kid_text(st, "displayheight"))

        # outbound flow links. CONFIRMED against real stage XML: the target
        # stage id is the ELEMENT TEXT of <onsuccess> (normal flow) or
        # <ontrue>/<onfalse> (a Decision's two branches, which sit directly on
        # the stage, NOT inside <decision>). A <loginhibit onsuccess=".."/> is a
        # logging flag, not a link — it is skipped because it is not an
        # <onsuccess> element with text.
        for tag in _LINK_TAGS:
            for el in _kids(st, tag):
                if el.text and el.text.strip():
                    stage.links.append(el.text.strip())

        if stype == "Decision":                                   # CONFIRMED
            # <decision expression=".."/> holds the condition; the ontrue/onfalse
            # targets are stage-level children captured by the link loop above.
            dec = _kid(st, "decision")
            if dec is not None:
                stage.expression = dec.get("expression")

        # A choice is a ChoiceStart / ChoiceEnd BRACKET pair, not a single
        # "Choice" stage — that type name never occurs in a real export.
        # CONFIRMED: ChoiceStart holds <choices><choice expression="..">, and
        # each branch's target is <ontrue> (NOT <onsuccess>). ChoiceEnd is only a
        # merge point, reached via the generic <onsuccess> link above.
        # CONFIRMED on real data: a WaitStart uses the SAME <choices><choice>
        # <ontrue> structure as a ChoiceStart (plus a <timeout>). Parsing it only
        # for ChoiceStart dropped every Wait stage's outgoing links and severed
        # the flow -- 47 orphan nodes in the emitted BPMN traced back to this.
        elif stype in ("ChoiceStart", "WaitStart"):               # CONFIRMED
            choices = _kid(st, "choices")
            if choices is not None:
                for ch in _kids(choices, "choice"):
                    v = _kid_text(ch, "ontrue")
                    if v:
                        stage.links.append(v)
                        # Keep the branch CONDITION alongside its link, in the
                        # same order: without it the emitter can only write
                        # ${true} placeholders and the routing is lost.
                        stage.choice_exprs.append(ch.get("expression") or "")
                        stage.choice_names.append(_kid_text(ch, "name") or "")

        # Calculation and MultipleCalculation are DISTINCT types; a real process
        # splits its calc logic roughly half-and-half between them, so matching
        # only "Calculation" dropped the expressions of ~half the calc stages
        # with no error. CONFIRMED: a single Calculation has one direct
        # <calculation expression=".." stage=".."/>; a MultipleCalculation nests
        # several under <steps>. Gather both places so none are lost.
        elif stype in ("Calculation", "MultipleCalculation"):     # CONFIRMED
            calcs = list(_kids(st, "calculation"))
            for wrap in ("steps", "calcsteps"):
                w = _kid(st, wrap)
                if w is not None:
                    calcs.extend(_kids(w, "calculation"))
            exprs = [c.get("expression") for c in calcs if c.get("expression")]
            # The TARGET (the Data stage each result is written to) is what makes
            # a calculation executable; dropping it left the emitter with nothing
            # to assign.
            stage.calc_targets = [c.get("stage") or "" for c in calcs
                                  if c.get("expression")]
            if exprs:
                stage.expression = " ; ".join(exprs)

        # CONFIRMED: an Action names its target via <resource object=".."
        # action=".."/>, a direct child of the stage.
        elif stype == "Action":                                   # CONFIRMED
            res = _kid(st, "resource")
            if res is not None:
                stage.target_object = res.get("object")
                stage.target_action = res.get("action")

        # A page call. The type is "SubSheet" and the target page id lives in a
        # <processid> child — NOT type "Page" with a <page ref=...>, which is
        # what this assumed and which does not occur in a real export. The
        # result was an empty page-call graph that looked merely uneventful.
        elif stype in ("SubSheet", "Page"):
            ref = _kid_text(st, "processid")
            if not ref:
                pg = _kid(st, "page")
                ref = pg.get("ref") if pg is not None else None
            if ref:
                stage.page_ref = page_of(ref)

        elif stype == "Data":
            # <private/> is presence-based: the element existing means private,
            # regardless of any text inside it.
            private = _kid(st, "private") is not None
            estate.data_items.append(
                DataItem(
                    artifact=art.name,
                    name=stage.name,
                    # verbatim: the doc names the types but not their casing
                    datatype=_kid_text(st, "datatype") or "unknown",
                    scope="local" if private else "session",
                    initial_value=_kid_text(st, "initialvalue"),
                    page=stage.subsheet,
                    always_init=_kid(st, "alwaysinit") is not None,
                )
            )

        elif stype == "Collection":                               # UNCONFIRMED
            info = _kid(st, "collectioninfo")
            fields = [f.get("name", "") for f in _kids(info, "field")] if info is not None else []
            estate.collections.append(
                Collection(artifact=art.name, name=stage.name,
                           scope="local" if _kid(st, "private") is not None else "session",
                           page=stage.subsheet,
                           fields=[f for f in fields if f])
            )

        elif stype == "Code":                                     # UNCONFIRMED
            code_el = _kid(st, "code")
            stage.code_language = (code_el.get("language") if code_el is not None else None) or "unknown"
            stage.code_loc = _loc(code_el.text if code_el is not None else None)
            stage.code_text = code_el.text if code_el is not None else None
            stage.code_external = code_external(stage.code_text)
            estate.blockers.append(
                Blocker(
                    artifact=art.name,
                    page=stage.subsheet,
                    stage=stage.name,
                    kind="code-stage",
                    detail=f"{stage.code_language} code stage, {stage.code_loc} LOC — re-implement manually",
                    severity="block",
                )
            )

        # CONFIRMED: a LoopStart carries <looptype> and <loopdata> (the iterated
        # collection, a BP expression); it pairs with its LoopEnd via <groupid>.
        elif stype == "LoopStart":                                # CONFIRMED
            stage.loop_type = _kid_text(st, "looptype")
            stage.loop_data = _kid_text(st, "loopdata")

        # CONFIRMED: an Exception THROWS via <exception type=".." detail=".."/>,
        # where type is "System Exception"/"Business Exception" and detail is the
        # message (a BP expression). It has no onward flow — it unwinds to a
        # Recover.
        elif stype == "Exception":                                # CONFIRMED
            exc = _kid(st, "exception")
            if exc is not None:
                stage.exception_type = exc.get("type")
                stage.exception_detail = exc.get("detail")

        # Action inputs: name -> BP expression, kept verbatim. Interpretation
        # (literal vs computed) belongs to detect, via bpexpr.unwrap_literal.
        inputs = _kid(st, "inputs")
        if inputs is not None:
            for inp in _kids(inputs, "input"):
                key = inp.get("name", "")
                if not key:
                    continue
                # `expr` is the documented attribute; `value` is tolerated so a
                # BP version that emits a bare literal is not silently dropped.
                raw = inp.get("expr")
                if raw is None:
                    raw = inp.get("value")
                stage.inputs[key] = raw if raw is not None else ""
                # A page's Start declares its inputs with `stage` (the Data item
                # that receives the value) and no expr; keep it so a page call
                # can be mapped parameter-by-parameter instead of "all variables".
                recv = inp.get("stage")
                if recv:
                    stage.input_stages[key] = recv

        # Action outputs bind a returned value to a Data stage BY NAME.
        outputs = _kid(st, "outputs")
        if outputs is not None:
            for out in _kids(outputs, "output"):
                key = out.get("name", "")
                target = out.get("stage")
                if key and target:
                    stage.outputs[key] = target

        stages.append(stage)

    # The code LANGUAGE is declared once per artifact on the ProcessInfo stage
    # (<language>csharp|visualbasic</language>), NOT as an attribute on each
    # <code> element -- so a per-stage read always came back unknown.
    # Shared <globalcode> on the ProcessInfo stage is reachable from EVERY Code
    # stage of the artifact: if it touches the outside world, so does each of
    # them (over-inclusive on purpose -- a missed worker is worse).
    _global_ext = []
    for st_ in stages:
        if st_.type == "ProcessInfo":
            pass
    _lang = None
    for st in _kids(root, "stage"):
        if st.get("type") == "ProcessInfo":
            _lang = _kid_text(st, "language")
            # shared code lives in <globalcode> AND/OR the ProcessInfo <code>
            # ("Code Options" in the UI); classify both
            _global_ext = sorted({"shared-code:" + k
                                  for tag in ("globalcode", "code")
                                  for k in code_external(_kid_text(st, tag))})
            break
    if _lang:
        for st in stages:
            if st.type == "Code" and (not st.code_language or st.code_language == "unknown"):
                st.code_language = _lang
    if _global_ext:
        for st in stages:
            if st.type == "Code":
                st.code_external = st.code_external + _global_ext

    # A WaitStart's TIMEOUT path is its paired WaitEnd (same <groupid>, like a
    # loop bracket); the WaitEnd then continues via its own <onsuccess>.
    _ends = {st.group_id: st for st in stages if st.type == "WaitEnd" and st.group_id}
    for st in stages:
        if st.type == "WaitStart" and st.group_id:
            end = _ends.get(st.group_id)
            if end is not None and end.id and end.id not in st.links:
                st.links.append(end.id)

    art.stage_count = len(stages)
    estate.artifacts.append(art)
    estate.stages_by_artifact[art.name] = stages
    _parse_appdef(root, art, estate)

    # environment variables (release-level block echoed into a process)
    ev = _kid(root, "environment-variables")                      # UNCONFIRMED
    if ev is not None:
        for var in _kids(ev, "variable"):
            estate.env_vars.append(
                EnvVar(
                    name=var.get("name", ""),
                    type=var.get("type"),
                    value=var.get("value"),
                    referenced_by=[art.name],
                )
            )


def _illegal_charref(n: int) -> bool:
    """True if a numeric character reference is illegal in XML 1.0. Blue Prism
    writes control characters into real exports (&#1;, &#11; ...); the parser
    then rejects the WHOLE file, so an object export can be unreadable."""
    return not (n in (0x9, 0xA, 0xD) or 0x20 <= n <= 0xD7FF
                or 0xE000 <= n <= 0xFFFD or 0x10000 <= n <= 0x10FFFF)


_BADREF = re.compile(r"&#(?:([0-9]+)|[xX]([0-9a-fA-F]+));")


def parse_file(path: Path, estate: Estate) -> None:
    path = Path(path)
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        # Retry ONCE, stripping only illegal character references, and say so on
        # stderr. Anything else still fails loud — never silently skip an artifact.
        removed: list[int] = []

        def _strip(m):
            n = int(m.group(1)) if m.group(1) else int(m.group(2), 16)
            if _illegal_charref(n):
                removed.append(n)
                return ""
            return m.group(0)

        raw = path.read_text(encoding="utf-8", errors="replace")
        cleaned = _BADREF.sub(_strip, raw)
        if not removed:
            raise ValueError(f"{path}: XML parse error: {exc}") from exc
        try:
            root = ET.fromstring(cleaned)
        except ET.ParseError as exc2:
            raise ValueError(f"{path}: XML parse error: {exc2}") from exc2
        print(f"NOTE: {path.name}: stripped {len(removed)} illegal character "
              f"reference(s) to parse", file=sys.stderr)

    if _local(root.tag) == "process" and _kid(root, "process") is None:
        # a standalone .bpprocess/.bpobject: the root *is* the body
        _parse_process(root, path, estate)
        return

    # A .bprelease. Each artifact is a <process>/<object> WRAPPER holding exactly
    # one <process> body; the wrapper's tag is the artifact type. The release
    # then repeats every artifact as an empty stub in its <contents> manifest.
    #
    # Both traps are real and both were hit by the first real export we ran:
    # iterating every <process> counts a process twice (wrapper + body), and
    # counts each manifest stub as a phantom artifact named after the file.
    found = 0
    for wrapper in root.iter():
        if _local(wrapper.tag) not in ("process", "object"):
            continue
        body = _kid(wrapper, "process")
        if body is None:
            continue        # manifest stub, or the body itself — not a wrapper
        _parse_process(body, path, estate, wrapper=wrapper)
        found += 1

    if not found:
        raise ValueError(
            f"{path}: no artifact found (root <{_local(root.tag)}>)"
        )


def parse_paths(paths: list[Path], estate: Estate) -> None:
    for p in sorted(paths, key=lambda x: str(x)):
        parse_file(p, estate)
