"""Blue Prism expression helpers.

BP expressions appear in Action `<input expr="...">`, decisions and
calculations. Full evaluation needs a real tokenizer (see DESIGN.md); this
module answers only the one question the estate analyzer asks today:

    is this a plain literal I can trust, or is it computed at runtime?

Anything computed is FLAGGED, never guessed — a queue name assembled at
runtime must surface as unresolved rather than be silently mis-attributed.
"""
from __future__ import annotations

# Markers that mean "this value is assembled at runtime, not a constant":
#   [X]  data-item reference      &  concatenation
#   (    function call            +  arithmetic
_COMPUTED_MARKERS = ("[", "&", "+", "(")


def unwrap_literal(expr: str | None) -> tuple[str | None, bool]:
    """Return (value, is_literal).

    A BP text literal is fully double-quoted::

        '"Payments"'      -> ("Payments", True)
        '"PMT-" & [Id]'   -> ('"PMT-" & [Id]', False)   # computed
        '[TargetQueue]'   -> ("[TargetQueue]", False)   # computed
        '5'               -> ("5", True)                # bare number/flag

    The raw text is returned unchanged when it is not a literal, so callers can
    report exactly what the XML said.
    """
    if expr is None:
        return None, False
    raw = expr.strip()
    if not raw:
        return None, False

    if len(raw) >= 2 and raw.startswith('"') and raw.endswith('"'):
        inner = raw[1:-1]
        # A quote inside a fully-quoted span means concatenation or an escape
        # ("A" & "B") -> not a single trustworthy literal.
        if '"' not in inner:
            return inner, True
        return raw, False

    if any(m in raw for m in _COMPUTED_MARKERS):
        return raw, False

    # Bare, unquoted and operator-free: a number, flag or date literal.
    return raw, True
