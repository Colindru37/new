"""Command-line entrypoint: `bp-estate analyze <inputs> -o out/`.

Pipeline: parse -> detect -> analyze -> score -> report. Each stage enriches a
single Estate aggregate (see PHASE0-IMPLEMENTATION.md §4).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import analyze, detect, regions, report, score
from .config import load_config
from .model import Estate
from .parse import parse_paths

_ROOT = Path(__file__).resolve().parents[2]        # repo root (…/blueprism-camunda-migration)
_DATA = _ROOT / "data"
_SCHEMA = _ROOT / "schemas" / "estate.schema.json"

_EXPORT_GLOBS = ("*.bpprocess", "*.bpobject", "*.bprelease", "*.xml")


def _collect(inputs: list[str]) -> list[Path]:
    files: list[Path] = []
    for item in inputs:
        p = Path(item)
        if p.is_dir():
            for g in _EXPORT_GLOBS:
                files.extend(p.rglob(g))
        elif p.is_file():
            files.append(p)
        else:
            raise SystemExit(f"input not found: {item}")
    return sorted(set(files), key=lambda x: str(x))


def run_analysis(inputs: list[str], out_dir: str | Path,
                 data_dir: Path = _DATA, schema_path: Path | None = _SCHEMA) -> Estate:
    """Programmatic entrypoint (used by tests)."""
    config = load_config(data_dir)
    estate = Estate()
    parse_paths(_collect(inputs), estate)
    detect.run(estate, config)
    analyze.run(estate, config)
    regions.run(estate, config)
    score.run(estate, config)
    report.write_all(estate, out_dir, schema_path=schema_path)
    return estate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="bp-estate", description="Blue Prism estate analyzer (Phase 0)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    pa = sub.add_parser("analyze", help="parse exports and emit estate.json + reports")
    pa.add_argument("inputs", nargs="+", help="export files or directories")
    pa.add_argument("-o", "--out", default="out", help="output directory (default: out/)")
    pa.add_argument("--data", default=str(_DATA), help="config data dir")
    pa.add_argument("--no-validate", action="store_true", help="skip estate.json schema validation")

    args = parser.parse_args(argv)
    if args.cmd == "analyze":
        est = run_analysis(
            args.inputs, args.out,
            data_dir=Path(args.data),
            schema_path=None if args.no_validate else _SCHEMA,
        )
        print(f"Analyzed {len(est.artifacts)} artifacts -> {Path(args.out) / 'estate.json'}")
        print(f"  blockers={len(est.blockers)} unresolved={len(est.unresolved)} "
              f"queues={len(est.queues)} creds={len(est.credentials)} locks={len(est.env_locks)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
