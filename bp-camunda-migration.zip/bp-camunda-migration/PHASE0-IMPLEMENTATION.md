# Phase 0 — Estate Analyzer — Implementation Plan

**Status:** Draft v0.1
**Companion to:** `PHASE0-ESTATE-ANALYZER.md`
**Stack decision:** Python for now (team not final; C#/.NET is a live possibility).
**Governing constraint:** make the *contracts* data, not code, so a future
.NET/C# reimplementation is cheap and provably equivalent (§5).

---

## 1. Language & runtime

- **Python 3.12+.** Fastest path to a static analyzer; strong graph/XML libraries; low ceremony for the team to contribute.
- Portability to C#/.NET is handled architecturally (§5), not by avoiding Python idioms. Write clean, boring Python — no metaprogramming that a .NET port can't mirror.

## 2. Dependencies (minimal, deliberate)

| Library | Use | Why not stdlib |
|---|---|---|
| **lxml** | Streaming XML parse (`iterparse`) | Bounded memory on large `.bprelease`; precise error locations (line/XPath) |
| **networkx** | Call graph: fan-in/out, depth, topo sort, cycle detection | Don't hand-roll graph algorithms |
| **click** | CLI | Ergonomic subcommands; stdlib `argparse` acceptable if we want zero-dep |
| **Jinja2** | Markdown/HTML report templating | Optional; can hand-write strings instead |
| **pytest** | Tests, golden snapshots | — |

**Model layer uses stdlib `dataclasses`, not pydantic** — keeps the fact base a
plain data structure that mirrors the language-neutral schema 1:1 and ports
directly to C# `record` types. Validation is explicit, not framework-magic.

## 3. Package / module layout

```
bp_estate/
  cli.py                 # entrypoint: `bp-estate analyze <exports/> -o out/`
  io/
    loader.py            # discover & open .bprelease/.bpprocess/.bpobject
    xml_stream.py        # lxml iterparse wrappers; errors carry file + XPath
  parse/
    release.py           # split .bprelease into constituent artifacts
    artifact.py          # process/object → raw structures (pages, stages)
    stage.py             # stage-type dispatch; links, inputs/outputs
    appdef.py            # Application Modeler elements (objects)
    expression.py        # TOKENIZE BP expressions (for dedup + function census)
  model/                 # the fact base — plain dataclasses, port 1:1 to C# records
    entities.py          # Artifact, Stage, DataItem, Collection, Edge, Blocker, ...
    estate.py            # Estate aggregate root
    enums.py             # StageType, VboTier, BlockerKind, Scope, RefKind
    serialize.py         # DETERMINISTIC JSON encoder (sorted keys, stable order)
  detect/                # semantic recognition (§7 of the spec)
    vbo_registry.py      # loads the data-file registry (§5); classifies tiers
    queues.py            # queue names + retry semantics from Work Queues calls
    credentials.py       # credential names from Credentials calls
    locks.py             # lock names from Environment - Locking calls
    calendars.py         # business-calendar usage
    pii.py               # collection field-name heuristics (data-driven patterns)
  analyze/
    resolve.py           # resolve action refs; mark unresolved(external|dynamic|missing)
    callgraph.py         # networkx build; fan-in/out, depth, cycles
    reachability.py      # dead code: unreachable stages/pages, unused items, orphans
    backlinks.py         # non-reducible cycles per artifact
    duplicates.py        # normalize → hash → cluster near-duplicate logic
  score/
    weights.py           # loads tunable weights (data file, §5)
    complexity.py
    risk.py
    coupling.py
    rollup.py            # roll artifact scores UP the call graph
  waves/
    planner.py           # topo order + score → migration waves
  report/
    estate_report.py     # estate-report.md / .html
    csv_exports.py       # blockers, shared-resources, unresolved, waves
    graph_export.py      # callgraph.graphml / .dot (via networkx)
  config.py              # locates data files; runtime options

data/                    # THE SHARED CONTRACTS — language-neutral (§5)
  vbo_registry.yaml      # canonical internal/shipped VBO names + action signatures + tier
  pii_patterns.yaml      # PII-suspect field-name patterns
  weights.yaml           # complexity/risk/coupling weights

tests/
  fixtures/              # tiny hand-authored BP XML (one construct each)
  golden/                # expected estate.json snapshots (cross-language conformance)
  test_parse.py test_detect.py test_analyze.py test_score.py test_determinism.py

pyproject.toml
```

## 4. Data flow (single aggregate, enrichment passes)

```
loader → parse ──► Estate (populated: artifacts, stages, data, raw edges)
                     │
        detect ──────┤  enrich: classify VBO tiers, extract queues/creds/locks,
                     │          flag PII, mark dynamic names
        analyze ─────┤  enrich: resolve refs, build call graph, dead code,
                     │          backlinks, duplicate clusters
        score  ──────┤  enrich: complexity/risk/coupling, roll up call graph
        waves  ──────┤  derive: migration order
                     ▼
        report → estate.json + csvs + graphml + estate-report.md
```

`Estate` is the single object threaded through the passes. Each pass is a pure
function `(Estate) → findings` that appends to the aggregate — easy to test in
isolation, easy to reorder, easy to port.

## 5. Portability strategy (the C#/.NET hedge)

The team may go .NET later. Contain that risk by making three things **data
files, not code** — shared verbatim across any implementation:

1. **`vbo_registry.yaml`** — the canonical Blue Prism internal/shipped VBO names,
   their action signatures, and their tier (internal | shipped | custom). This is
   the load-bearing knowledge in §7.1 of the spec. As a data file it's tunable
   for localized/renamed installs *without code changes* and identical in Python
   and C#.
2. **`pii_patterns.yaml`** and **`weights.yaml`** — heuristics and scoring
   weights, tuned by analysts, not developers.
3. **`estate.json` schema + golden fixtures** — the output contract. The
   `tests/golden/` snapshots become a **cross-language conformance suite**: a C#
   port is "correct" iff it produces byte-identical `estate.json` for the same
   fixtures.

Result: a .NET rewrite reimplements `parse/analyze/score` but consumes the same
registry/patterns/weights and is validated against the same golden files. The
contracts can't silently diverge between two teams' implementations.

## 6. Determinism (hard requirement)

- Sort every collection before serialization; never rely on dict/set iteration order for output.
- No timestamps or host paths in `estate.json` (or pin them behind a `--stamp` flag kept out of golden comparisons).
- Stable IDs sourced from Blue Prism GUIDs, never generated.
- `test_determinism.py`: run twice, assert byte-identical output.

## 7. CLI surface (v1)

```
bp-estate analyze  <exports_dir|files...> -o <out_dir> [--config data/]
bp-estate graph    <estate.json> -o callgraph.graphml
bp-estate report   <estate.json> -o estate-report.md
bp-estate validate <estate.json>          # schema self-check
```

Single `analyze` runs the whole pipeline; the others operate on a produced
`estate.json` for re-reporting without re-parsing.

## 8. Testing strategy

- **Fixture-per-construct:** hand-author minimal BP XML exercising each tricky
  case — Choice ordering, back-link cycle, code stage, env-lock call, dynamic
  queue name, orphan object, duplicate pages. One construct per fixture.
- **Golden snapshots:** each fixture has an expected `estate.json`; diff on change.
- **Property test (determinism):** double-run equality.
- **Real-export smoke test:** once a sanitized real release is available, assert
  zero silent drops (every stage accounted for) and no crashes.

## 9. Build order (suggested)

1. `io` + `parse` + `model` + deterministic `serialize` → produce a faithful `estate.json` with raw edges. (Milestone: round-trips the fixtures.)
2. `detect` (VBO registry + queues/creds/locks/pii). (Milestone: shared-resource map.)
3. `analyze` (resolve, callgraph, reachability, backlinks, duplicates). (Milestone: dependency graph + dead code + duplicates.)
4. `score` + `waves`. (Milestone: prioritized backlog.)
5. `report` polish (html, graphml). (Milestone: shareable estate report.)

Each milestone is independently useful — the estate map (steps 1–3) already
delivers value before scoring exists.
```
