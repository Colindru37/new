# The programme, restructured around the 3 tasks

**Status:** reframe note, 2026-07-14. Supersedes the framing (not the analysis)
of `DESIGN.md` and `QUESTIONS-AND-INTAKE.md`.

## What changed

Three things, from `ideas.txt` and the photographed reference docs:

| Was | Is |
|---|---|
| Target = Camunda (BPMN engine) | Target = **uFlow** |
| One converter | **3 tasks**, plus a 4th tool nobody had scoped |
| LLM = Claude-class | **Gemini / Copilot (GPT-5 via Copilot Studio)** |
| "Camunda 7 or 8?" was the top gate | **Wrong question.** What does uFlow ingest? |

The repo folder is still named `blueprism-camunda-migration`. Leave it; renaming
a git root is churn for no gain, and the misnomer is documented here.

---

## 1. The one structural consequence: task 1 gates task 3

This is the whole point of the note, so it goes first.

Per the research in `ideas.txt`, uFlow is a **decisioning/workflow platform**:
it edits policies without code, runs ML models, and *"can call any JSON or XML
API, with uFlow handling authentication and result parsing"*.

Read that list again for what is **absent**: uFlow has no hands. Nothing
suggests it can drive a Windows thick client, a mainframe green screen, or a
Citrix session. Camunda had the same gap, but we planned around it with
strangler-fig — Camunda orchestrates *while still calling Blue Prism objects*.
That escape hatch is narrower here: if uFlow's only outbound verb is "call an
API", then coexistence requires **Blue Prism itself to be fronted by an API**.

So the three tasks are not three parallel workstreams. For any process that
touches a UI, they are a **dependency chain**:

```
task 1 (app inventory + API specs)
        │  product teams build the APIs        ← the long pole, measured in quarters
        ▼
task 3 (spec extraction + migration to uFlow)
```

Which reframes task 1 completely. It is not analysis-and-reporting. **It is the
critical path**, and its output — API specs a product team will actually build
against — is the thing the whole migration waits on. An estate of 153 processes
and 134 robots is mostly hands. uFlow has none.

> **CONFIRMED 2026-07-14** by `deep-research-report2.md`. Across a full product
> research pass: **zero** mentions of RPA, UI automation, on-prem, mainframe,
> Citrix, or a Windows agent. The only hit for "desktop" is *"there is no desktop
> software — everything runs on uFlow's AWS cloud."* uFlow has no hands, and no
> on-prem anything. The chain in §1 holds.

### 1a. Three problems the research surfaced that outrank the import format

The research answers the gates — and the answers are worse than the questions.
**Read these before doing any more work on task 3.**

**(i) uFlow is a credit-decisioning engine. The estate is not credit.**
Every source describes one domain: *"NoCode decision engine specializing in
credit underwriting and loan origination"*, bureau connectors (TransUnion,
Experian, DataCrédito), applicant scoring, approve/reject. The reviews list the
con explicitly: *"Limited to loan origination functionalities"* and *"may not
cover general business rules outside lending."* The word "credit" appears 26
times; "RPA" appears zero.

Now look at the estate: BizBanking, Münzgeld, Stammdaten — coin handling, master
data, back-office banking ops. **That is not loan origination.** Most of those
153 processes have no home in uFlow at any level of effort, because the platform
has no concept they map onto. This is not a migration difficulty; it is a domain
mismatch.

**(ii) There may be no import format — and therefore nothing for task 3b to
generate.** *"uFlow's rule definitions live in its own format, so moving policies
in/out requires using the provided UI/API; no open standard is mentioned."*
*"Data migration from another rule engine would require manual reconstruction of
policies."* No SDK, no CLI, no Postman collection, no public repo, no schema.

Gate B does not resolve to "BPMN or JSON". It resolves to **"a human drags nodes
in a browser."** If that stands, task 3b — *automated* migration via generated
code — has no artefact to emit. You cannot generate into a drag-drop UI. That
does not kill task 3a: the spec extraction still feeds the humans doing the
dragging, and stays the deliverable. But *"migrarea care e tacticul lor"* may be
tactically appealing precisely because nobody has checked whether it is possible.

**(iii) It is LatAm fintech SaaS on AWS, and this is a German bank.** RappiCard,
RappiPay, Juancho te presta. Spanish-only docs. Endpoint `api.co.uflow.biz`
(`.co` = Colombia). Serverless AWS multi-tenant, no on-prem option, no sandbox,
no trial. Against `DESIGN.md` §13 (PII, data residency, audit-log parity,
regulator reconstruction) that is a live compliance question, not a footnote.
And pricing is usage-based from ~\$300/mo — at **30,000 transactions/day** the
cost model needs an answer before anyone commits.

### 1b. So the real gate is: is this even the right uFlow?

Hold the three findings above next to each other — a Colombian credit-underwriting
SaaS, and a German bank's back-office RPA estate — and the obvious question is
whether they are the same subject at all. Three possibilities:

1. **Different product, same name.** "uFlow" is generic; this could be an
   unrelated vendor.
2. **An internal platform** the bank calls uFlow, which no public research would
   ever find.
3. **The research is right, and the scope is narrower than the framing** — uFlow
   was chosen for a *credit-decisioning slice*, and "migrate Blue Prism to uFlow"
   got over-generalised on its way to you.

**(3) is the most likely, and (2) is very plausible.** Note that your own
research in `ideas.txt` quotes this same source, so both passes could be about
the same wrong product — agreement between them is not evidence.

This now outranks everything else in this note. **One question to whoever named
uFlow — "which uFlow, and for which processes?"** — decides whether §1's chain,
task 3, and a good part of `PROGRAMME.md` are about the right system. Do not
build task 3b until it is answered.

## 2. What we can compute today, while blocked

If §1 holds, the estate splits into three populations, and **the analyzer
already has the facts to do the split** — no uFlow knowledge required:

| Population | Test (from `estate.json`) | Path |
|---|---|---|
| **uFlow-ready** | every object edge is tier `internal` or `shipped`; no Code stages | migrate now — this is the pilot pool |
| **API-blocked** | touches ≥1 `custom` object | task 1 first, then task 3. The bulk. |
| **Hard** | Code stages, surface automation, env locks | design decision per process |

`object_tiers` and `edges` are already emitted, so this is a report, not a
research project. **Build it next.** It converts "153 processes, someday" into
"these N can start Monday, these M are waiting on an API, here is the queue" —
and it is the strongest possible artefact to hold while waiting on uFlow,
because it is true regardless of what uFlow ingests.

It also sizes the prize. If the uFlow-ready population is ~zero, that is not a
disappointment — it is the finding that says the programme's real name is *"build
APIs for the bank's applications"*, and the uFlow migration is the easy tail.

## 3. The programme

| # | Task | Backbone | Status |
|---|---|---|---|
| 1 | Code analysis → app inventory + API specs | analyzer + `prompts/01`, `prompts/02` | **unblocked** |
| 2 | AI code re-engineering to the coding rules | deterministic rules + `prompts/03` | unblocked, but see §5 |
| 3a | Spec extraction | `prompts/04` (stage ledger) | **unblocked** |
| 3b | Automated migration to uFlow | — | **may not be possible** — see §1a(ii); no import format is known to exist |
| 4 | Comparison / diff-audit tool | same IR, two `Estate`s | **unblocked, unscoped, cheap** |
| — | Auto-documentation (cross-cutting) | `prompts/05` | unblocked |

**Task 4 is the sleeper.** The BP Comparison Rules doc describes a version-diff
engine — base vs target, findings graded critical/impactful/minor, output
pasteable into JIRA — and it runs on the **same parsed `Estate`** the analyzer
already builds. Two estates, one diff. It needs no uFlow answer, no LLM, and no
API. It is the cheapest real deliverable on the board, and it earns trust in the
parser with the people whose exports it will read. Given that departments run
different Blue Prism versions, it also has a standing customer from day one.

## 4. Task distribution — you were right to split it

You asked whether task 3 should be migration-only, with generation coming from
task 2. **Yes.** Draw the line at *generate vs translate*:

- **Task 2 owns all code generation**, and the guardrails and verification that
  make generated code trustworthy. That is one competence, not two.
- **Task 3 owns extraction and landing in uFlow**: read the estate, produce the
  spec, translate, confirm it arrived.

The reason is that verification is the expensive part, and if both tasks
generate, both build verification — and both build it badly, differently, and
twice. One generator, one verification stack, many consumers.

The order follows: **2 before 3**, not because of hygiene but because canonical
code is *legible* code. Spec extraction against an estate that follows one naming
convention and one error-handling pattern is dramatically more reliable than
against 153 dialects — for a deterministic parser and for a weak model alike.
Task 2 is a **normalisation pass that makes task 3 cheap.**

That framing also survives §5, which the hygiene framing does not.

## 5. The tension in task 2 nobody has named

**Why re-engineer code you are decommissioning?**

Task 2 makes Blue Prism code comply with Blue Prism coding rules. Task 3 deletes
Blue Prism. Left as-is, task 2 is polishing a corpse, and the first person who
asks that in a steering meeting is right.

There are three coherent answers. Pick one *before* building task 2, because
they imply different tools:

1. **Normalisation for migration** (§4) — target only what tasks 1/3 must read.
   Scope: whatever makes extraction reliable. Value: dies with Blue Prism.
2. **The estate outlives the plan** — 153 processes will not migrate in a year;
   the survivors need maintaining, and rule-compliant code is cheaper to keep.
   Scope: the API-blocked and Hard populations from §2 — the ones that *stay*.
3. **Hygiene as a standalone product** — the audit is valuable to the RPA team
   whatever happens to uFlow. Scope: everything. Value: independent of migration.

My read: **(2) is the strongest**, and §2's segmentation tells you exactly which
processes it means. Note it is the *opposite* population from the pilot pool —
you re-engineer the bots that are stuck, and migrate the ones that are not. That
is a coherent programme; "re-engineer everything then migrate everything" is not.

## 6. Verification — where it lives, and what it costs

Your questions: *"Unde vine verificarea? Și cât accent se pune verificare?"* and
*"Câtă siguranță ai în cod generat de AI pentru alg care lucrează cu date
sensibile?"*

Four tiers. Push every check down as far as it will go:

| Tier | What | Cost | Catches |
|---|---|---|---|
| **T0 deterministic** | parser facts, stage ledgers, citations, regex rules, schema | **free** | invention, omission, naming, structure |
| **T1 differential** | re-run at temp 0 and diff; golden sets | ~1 extra call | instability, prompt drift |
| **T2 human** | review what survives T0/T1 | expensive, finite | judgement, business meaning |
| **T3 behavioural** | run the uFlow flow on recorded BP inputs, diff outputs | needs a pilot env | **whether it is actually correct** |

Three rules:

- **Anything T0 can check must never cost a token.** That is the entire design of
  `prompts/` + `tools/verify_llm_output.py`. It is also the answer to *"la
  verificare posibil să intervină token-urile"* — the token bill only explodes if
  you verify with the model.
- **Never verify with a second LLM pass over the same evidence.** The errors are
  correlated: a model that hallucinated a stage will confirm it, fluently, for
  full price. A second pass buys the *feeling* of verification. That is worse
  than no verification, because it converts "nobody checked" into "it was
  checked". (I built exactly this bug into the verifier this week and caught it
  only by feeding it a known-bad input — see `fuckups.md`, 2026-07-14.)
- **T3 is the only tier that proves a migration.** T0–T2 prove nobody lied about
  the source. Only a behavioural diff proves the target *does the same thing*.
  Budget for it, and pick the pilot from §2's uFlow-ready pool.

And the honest answer to "how much do you trust AI-generated code handling
sensitive data": **not enough to skip T3, ever.** But that is not really an AI
question — you would not ship a *hand*-migrated payment process without a
behavioural diff either. The bar does not move because the author changed. What
moves is the failure *mode*: a human writes bugs that look like bugs, a weak
model writes bugs that look like working code. So T0's job is to make lying
expensive, and T3's job is to be the thing that actually decides.

## 7. Gates

Updated 2026-07-14 after `deep-research-report2.md`. A and B came back answered;
the answers spawned **A′**, which now leads.

| | Gate | Status | Blocks |
|---|---|---|---|
| **A′** | **Which uFlow, and for which processes?** (§1b) | **OPEN — now the top gate** | whether this note is about the right system |
| **A** | Does uFlow have any UI/RPA capability? | **ANSWERED: no.** Zero RPA/on-prem/UI mentions in a full research pass | — §1's chain holds |
| **B** | What does uFlow ingest? | **ANSWERED, badly:** no open format, no SDK/CLI, "manual reconstruction of policies" | task 3b may have no artefact to emit |
| **B′** | Is there an undocumented policy/admin API behind the Swagger? | OPEN — only a vendor can say | whether task 3b exists at all |
| **C** | One sanitized real export | OPEN | the `# UNCONFIRMED` parser items |
| **D** | Which answer in §5 is task 2's scope? | OPEN | task 2's shape |
| **E** | Which model, which access | OPEN | prompt tuning, cost model |
| **F** | Domain fit: what do the 153 processes *do*? (§1a(i)) | OPEN | whether uFlow is a target for 5 processes or 150 |
| **G** | Data residency + cost at 30k txn/day on multi-tenant AWS SaaS (§1a(iii)) | OPEN | whether uFlow is viable here at all |

A′, B′ and F are one conversation with whoever chose uFlow. G is a conversation
with compliance, and it is better had now than after the tooling is built.

**None of them block §2, §3's task 4, prompt tuning, or task 1** — task 1 gets
*more* certain from this research, not less: whatever the target turns out to be,
the estate's applications need APIs, and nothing about that conclusion depended
on uFlow.

## 8. Disposition of the existing docs

| Doc | Verdict |
|---|---|
| `PHASE0-ESTATE-ANALYZER.md` | **Survives.** 5 stale Camunda lines (§7 tier targets, env-lock). The detection rules are target-agnostic. |
| `PHASE0-IMPLEMENTATION.md` | **Survives.** Pure engineering. Data-file contracts + golden fixtures are *more* valuable now, not less. |
| `DESIGN.md` §2, §6, §10, §11, §13, §15 | **Survive.** The dual-nature insight, the VM corollary, the money/date/type table, the 14-item risk register, bank governance, LLM boundaries — none of that was ever about Camunda. R6 (money rounding) and R8 (idempotency) still lead. |
| `DESIGN.md` §1, §3, §5, §7–9, §12, §14, §16–17 | **Superseded.** The BPMN emitter, the FEEL transpiler, the BP→Camunda mapping table, the Camunda-shaped phasing and metrics. Keep for the *shape* of the thinking; the target is wrong. |
| `QUESTIONS-AND-INTAKE.md` | **Mostly stale.** Section A asks the wrong headline question. Sections B–E survive; the one-line ask becomes gates A+B+C. |
| `docker/camunda8/` | **Dead** until uFlow says otherwise. Harmless; leave it. |
| `data/vbo_registry.yaml` | **Survives**, but `default_migration_target: camunda-feature` etc. are now placeholders. The *tiering* is the asset; the targets are one edit once B lands. |

Nothing gets deleted. The Camunda work was not wasted — the IR, the tiers, the
risk register and the deterministic-core discipline are exactly what a weaker
model and an unknown target make **more** necessary, not less.

## 9. What to do next, in order

1. **Ask gate A′: which uFlow, and for which processes?** (§1b) One question. It
   decides whether §1's chain and task 3 are about the right system. Everything
   about task 3 waits on it — including any estimate anyone asks you for.
2. **Build the §2 segmentation report.** Unblocked, ~a day, target-agnostic, and
   it is the artefact that makes the programme legible to everyone above you. It
   also feeds gate F: it tells you what the estate actually *does*.
3. **Build task 4 (the diff tool).** Cheap, standalone, has a customer today, and
   is the only deliverable here that no uFlow answer can invalidate.
4. **Move the mechanical coding rules into the analyzer** (§3 of `prompts/03`).
   Free, exact, and it shrinks task 2's token bill before task 2 exists.
5. **Tune `prompts/` on fixtures** while waiting on C.

Do **not** start task 3b, and do not write the uFlow prompt — gate B says there
may be nothing to emit into, and gate A′ says we may be aimed at the wrong
product entirely. Anything built now encodes both guesses into every layer above.

**Do not treat this research as ground truth either.** It is a model's pass over
vendor marketing and software directories, and it is a poor source on exactly the
thing that matters most — an undocumented internal API would be invisible to it,
by definition (gate B′). Its value is that it makes the *questions* sharp and
cheap to ask, not that it answers them. Ask a human at uFlow before believing any
of it, including the parts that support the conclusions above.
