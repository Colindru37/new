# Deploy & validate emitted BPMN on a local Camunda 7

The first end-to-end confidence check for the emitter: prove that
`bp_emit.py` output actually **deploys to a Camunda 7 engine**, not just that it is
well-formed and structurally sane. Because Fluxnova is a Camunda 7 fork that retains
the `camunda:` namespace, a file we emit with `--ns camunda` deploys to a **free,
local Camunda 7 "Run"** distribution unchanged — so this validation needs no
Fluxnova access and no bank environment.

> **RESULT (2026-08-13):** the training-release output deployed to a live
> **Camunda 7.24 Run** — HTTP 200, **all 7 process definitions registered.** The
> six defects the deploy exposed (XSD child order, `historyTimeToLive`, empty
> scriptTask, unconditioned XOR flows, error-end `errorRef`, executable sub-pages)
> are now fixed in the emitter, so a fresh `--ns camunda` emit deploys clean.

## What is (and is not) being validated here

We validate the **emitter**, on **non-bank inputs**, on an internet-connected /
build machine:

- the embedded synthetic fixtures, and
- the **Blue Prism training release** (`exports/Blue Prism Foundation Training …`),
  which is Blue Prism's own courseware — safe to work on.

We do **not** deploy real bank BPMN here. Real `estate`/BPMN carries bank IP and
lives only on the locked laptop, which takes no files in — so a Camunda jar can't be
placed there either. The emitter is deterministic and applies the same transform to
every release, so engine-validity on the training release (7 processes, 77 flows, 6
conditions, **0 structural problems**) generalises structurally; the `--selftest`
structural gate guards the rest per-run.

## Prerequisites

- **Java 17 or 21** (this machine already has Java 23, which runs Camunda Run in
  practice; if anything misbehaves, install **JDK 21** — the version Fluxnova itself
  targets, and a supported Camunda 7 runtime). No Docker needed.
- **Camunda Platform 7 Run** — the standalone distribution (a Spring Boot app, not a
  server install). Download `camunda-bpm-run-7.<latest>.zip` from Camunda's
  distributions (Maven Central: `org.camunda.bpm.run:camunda-bpm-run`) and unzip to
  e.g. `C:\camunda-run\`. It contains `start.bat` / `start.sh`, an
  `internal/` runner jar, and a `configuration/resources/` auto-deploy folder.

## Step 1 — produce validation inputs (camunda namespace)

```bash
cd blueprism-camunda-migration/port
# the safe training release -> one BPMN doc per process artifact
python bp_emit.py "../exports/Blue Prism Foundation Training - Consolidation Exercise Sample Solution v1.00.bprelease" \
    -o ../out_bpmn --ns camunda
```

`--ns camunda` is required: it emits the `camunda:` extension namespace stock
Camunda 7 understands (the default `fluxnova:` namespace is for the real target).

## Step 2 — deploy

**Path A — auto-deploy on startup (simplest pass/fail):**

```bash
cp ../out_bpmn/*.bpmn  /c/camunda-run/configuration/resources/
/c/camunda-run/start.bat          # (start.sh on unix)
```

The engine deploys everything in `configuration/resources/` at boot. Watch the
console:

- **PASS** — a deployment log line per process definition, no parse errors.
- **FAIL** — `ENGINE-09005 Could not parse BPMN process definition …` (a hard XSD /
  schema error) names the file and element. That is the signal to fix the emitter.

**Path B — REST deploy against a running instance (scriptable):**

```bash
curl -s -w '\n%{http_code}\n' \
     -F "deployment-name=bp-emit-test" \
     -F "file=@../out_bpmn/Centrix_Data_Solutions___Create_Orders___fa78adfc.bpmn" \
     http://localhost:8080/engine-rest/deployment/create
```

`200` + a deployment JSON = deployed. `400` + an `ENGINE-09005` body = a parse error.

## Step 3 — confirm

- **Cockpit**: <http://localhost:8080/camunda> (default user `demo` / `demo`) →
  *Processes* lists the deployed definitions; the count should match the number of
  `<process>` elements emitted.
- **REST**: `curl http://localhost:8080/engine-rest/process-definition/count`.

**Green =** every emitted document deploys with no `ENGINE-09005`, and every process
definition appears in Cockpit / the REST count.

## Deploy errors the first real run exposed — now fixed in the emitter

The offline `--selftest` (well-formed + structural) passed while the engine still
rejected the file six ways. All six are handled now; documented so the reasoning
survives:

1. **XSD child order** — `documentation` must precede `eventDefinition` /
   `extensionElements`. Fixed.
2. **`ENGINE-12018` History TTL** — every process needs `historyTimeToLive`; the
   emitter sets `camunda:historyTimeToLive="P180D"`.
3. **Empty `scriptTask`** — Camunda rejects a scriptTask with no script; Calculation
   is now an abstract `task` (the JUEL is documentation; a functional assignment
   needs the calc target, which the parser drops).
4. **Unconditioned XOR flows are a *deploy* error** (not just runtime). A Decision
   gets `${E}`/`${!(E)}`; a Choice or failed-JUEL Decision gets `${true}`
   placeholders — applied **inside loops/recover regions too**, not only top level.
5. **`errorRef` mandatory on an error *end* event** — the re-raise refs `Err_System`
   (a catch-all `errorEventDefinition` is legal only on the error *start* event).
6. **Only executable processes register** — sub-pages are `isExecutable="true"` so
   their `callActivity` callers resolve; otherwise 6 of 7 pages silently vanish.

## Behaviours that are expected, not failures

1. **External service tasks have no workers.** Starting an instance parks at the
   first `camunda:type="external"` task on its topic — validate *deployment*, don't
   require execution.
2. **No diagram (BPMNDI omitted).** Cockpit lists the definitions but can't draw the
   flow — the deferred layout pass, not a deploy error.
3. **Placeholder gateway routing.** `${true}` branches deploy but route the first
   branch at runtime; real routing waits on Choice-condition retention / JUEL.
4. **`calledElement` resolves in-file** — all pages of an artifact live in one
   `<definitions>`, so page-call activities resolve within the deployment.

## One-shot loop

```bash
cd blueprism-camunda-migration/port
python bp_emit.py "<a safe .bprelease>" -o ../out_bpmn --ns camunda
rm -f /c/camunda-run/configuration/resources/*.bpmn
cp ../out_bpmn/*.bpmn /c/camunda-run/configuration/resources/
/c/camunda-run/start.bat   # read the console: any ENGINE-09005 => a real defect to fix in bp_emit
```

A clean startup here is the first proof that Blue Prism → runnable Camunda 7 BPMN
works end to end. Any `ENGINE-09005` is gold — it's a real schema defect on real
input that the offline structural check couldn't reach, exactly like the
"flow out of endEvent" the training release surfaced.
