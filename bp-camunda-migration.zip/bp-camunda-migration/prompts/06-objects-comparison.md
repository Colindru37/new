# Task — objects comparison (their live task 1)

**Goal:** given a base object and a departmental copy of it, produce a Jira-ready
list of what changed and why it matters.

## The diff is not a model's job

The model must never be asked *what changed*. Two XML files have an exact
answer, and a model asked for it will paraphrase, merge, and miss things — and
on a large `.bpobject` it will sample and extrapolate, which is the failure
their own audit reference admits to.

So the parser computes the diff and the model only explains it:

```
base.bpobject   ─┐                    ADDED / REMOVED / CHANGED stageids ─┐
                 ├─► diff_objects ─►  page findings, severity per rule    ├─► model ─► "what it means"
target.bpobject ─┘                                                        │
                                      the two objects' XML ───────────────┘
                                              │
                                              └─► render_compare ─► Jira text
```

The model receives the change set as ground truth and must account for every id
in it exactly once. Same ledger trick as `04`, applied to a diff instead of a
page. Verification is the same script.

**Severity is not the model's either.** The BP Comparison Rules grade findings
themselves — rule 7 says a renamed stage is not critical, rules 8 and 9 grade a
missing page against an extra one, rule 27 demotes anything unpublished — and
`diff_objects.py` applies those rules in code. A model asked to re-grade would
produce a second, contradictory severity on the same finding. It is given the
grade and explains it; it does not set it.

**Direction is fixed and matters.** Base is the good version; target is the one
being overwritten (rules 21, 24). Every severity is the answer to "if we
overwrite, what breaks?", so swapping the two arguments inverts the report.

**Prerequisite:** `00-CONTRACT.md` as the system instruction.

---

## Prompt

```
You are given a CHANGES list: the complete, authoritative set of differences
between a base Blue Prism object and the target copy it will overwrite. It was
computed by a parser and graded against the BP Comparison Rules. It is ground
truth. You did not compute it and must not add to it.

Each line is prefixed + (added), - (removed), ~ (changed) or P (page-level), and
carries a severity in brackets: critical, impactful or minor.

Explain what each change does in business terms, and what it risks.

Do NOT change a severity. It was set by a numbered rule in the standard, not by
judgement. If you believe one is wrong, say so in "disputed_severity" with your
reason and leave the grade alone.

Every stageid in CHANGES must appear exactly once across "changes[].stageids"
and "behaviour_unchanged". This is checked by a script. An output that drops one
is rejected whole. Never write "and similar changes" - group them and list every
id. Put a change in "behaviour_unchanged" only when it cannot alter what the
object does (a renamed stage, an edited comment).

Do not judge whether a change is good. Report what it does and what could break.
If you cannot tell what a change is for, say so - "clarity": "UNKNOWN" is a
correct answer and routes it to a human.

The goal of the exercise is to overwrite the target with the base version. Write
"summary" for a reader deciding whether that is safe to do.

Output exactly this JSON and nothing else:

{
  "base": "<@name>",
  "target": "<@name>",
  "summary": "<2-4 sentences: what changed overall, and whether overwriting the
               target with the base version is safe>",
  "changes": [
    {
      "id": "C1",
      "kind": "added|removed|changed|page",
      "stageids": ["<id>", "..."],
      "what": "<what the two versions now do differently, in business terms>",
      "risk": "<what could break, or 'none identified'>",
      "clarity": "clear|UNKNOWN"
    }
  ],
  "behaviour_unchanged": ["<stageid>", "..."],
  "disputed_severity": [
    {"stageid": "<id>", "graded": "<as given>", "argument": "<why you disagree>"}
  ],
  "open_questions": ["<what a human must confirm>"]
}

<<<CHANGES
{{PASTE out/changes.txt - one finding per line, already graded}}
CHANGES

<<<BASE
{{PASTE THE BASE OBJECT XML}}
BASE

<<<TARGET
{{PASTE THE TARGET OBJECT XML}}
TARGET
```

---

## Jira formatting

Format the Jira ticket **from the JSON, with a template**, not by asking the
model for Jira markup. Their tracker already logs the pain of hand-fixing
generated HTML — same failure, one layer up. One JSON → one renderer → identical
tickets every time.

```powershell
.\.venv\Scripts\python.exe tools\render_compare.py out\changes.json -o report.jira
```

Emits the title block (rule 18), `(/)`/`(x)` icons (rule 19), findings grouped
under their page and severity heading (rule 15), and the remediation actions
that follow mechanically from a finding's kind (rule 25). It exits non-zero on a
critical finding, so a pipeline cannot wave one through.

The report is **not** stamped "AI Assisted" by default, which rule 18 asks for,
because by default no model has touched it — it is a parser diff graded by code,
and inviting a reviewer to discount exact findings is the worse error. Pass
`--ai-assisted` once a model has written the explanations.

## Producing the diff

```powershell
.\.venv\Scripts\python.exe tools\diff_objects.py base.bpobject target.bpobject -o out
```
Writes `out/changes.txt` - paste that as the CHANGES block - and `changes.json`.

Layout is not change: a stage dragged across the canvas produces no finding, and
neither does renaming a page produce one per stage sitting on it. Anything the
diff cannot classify is reported as `unclassified` rather than dropped, because
an unknown change is a finding, not an absence.

## Checking the answer

```powershell
.\.venv\Scripts\python.exe tools\verify_llm_output.py answer.json target.bpobject --changes out\changes.json
```

Every stageid in `CHANGES` accounted for exactly once, no invented ids, no
`Password` value echoed. Pass/fail. **Without `--changes` it cannot detect a
dropped change**, which is the failure that matters.
