# Task 3a — process specification extraction

**Goal:** a complete, human-readable specification of what an existing process
does. Today that feeds the documentation generator; if a migration target is
ever chosen it is also the thing you build *against*. Both uses want the same
artifact, which is why this prompt is worth having regardless of uFlow.

## The completeness problem, and the trick that solves it

You named it: *"extragere specificații unde problema ar fi COMPLETE"*. It is the
right worry. A model summarising a 400-stage process will produce something
fluent that silently omits the retry branch, and **fluency is exactly why you
will not notice**. You cannot review your way out of it: to spot the omission
you would have to already know the answer.

So don't ask for completeness. **Measure it.**

Every stage in a Blue Prism export has a `stageid`. The parser knows all of
them, for free and exactly. So:

1. `bp_estate` emits the full stageid list for the artifact — ground truth.
2. That list goes **into the prompt** as a ledger the model must fill in.
3. Every stageid comes back marked either *covered by spec section X* or
   *deliberately not covered, because R*.
4. A script asserts `set(returned) == set(ground_truth)`.

Completeness stops being a judgement call and becomes **set equality**. An
omission is now a failing assertion, not something you hope a reviewer notices.

It also fixes the token problem sideways: verifying coverage costs no tokens at
all, so the budget goes to the spec prose instead of a second model reading the
first model's homework.

The ledger is not optional. Without it this prompt is a summariser, and a
summariser is what you are trying not to build.

**Run it on:** one page at a time, then merge. `Main Page` first — it holds the
orchestration and tells you what the other pages are for.

**Prerequisite:** `00-CONTRACT.md` loaded as the system instruction.

---

## Prompt

```
Write a specification of what this Blue Prism page does, and account for every
stage.

You are given the page's XML and a STAGE LEDGER: the complete, authoritative
list of stageids on this page. The ledger is ground truth, produced by a
parser, not by you.

Your output MUST contain every stageid from the ledger EXACTLY ONCE, across
"sections[].stageids" and "excluded". Not once more, not once less. This is
checked by a script and is the acceptance criterion for this task. An output
that misses a stageid is rejected whole - the prose quality does not matter if
the ledger does not balance.

Do not shorten the ledger. Do not write "and so on". Do not collapse a run of
similar stages into one entry. If the page is large, write fewer sections with
more stageids in each - never drop a stageid to save space.

Put a stage in "excluded" ONLY for these reasons:
  "cosmetic"     - Note/Anchor: no behaviour
  "declaration"  - a Data or Collection stage, covered by the data model rather
                   than by a step
  "unreachable"  - nothing links to it (the analyzer flags these as dead code)
Any other reason is not a reason. If you do not understand a stage, it does NOT
go in "excluded" - it goes in a section with "clarity": "UNKNOWN". Excluding a
stage you did not understand is the exact failure this ledger exists to catch.

Write the spec for a business analyst who has never seen Blue Prism. Describe
behaviour, not stages: "retries the payment up to 3 times" beats "loops back to
stage g14". Never name a stage type in the prose.

Where the process makes a decision, state the CONDITION verbatim from the
input. Where it touches money, a queue, or an external system, say so
explicitly - those are the parts that get scrutinised.

Output exactly this JSON and nothing else:

{
  "input_scope": "<what you were given>",
  "artifact": "<@name>",
  "page": "<page name>",
  "purpose": "<what this page is for, one paragraph>",
  "trigger": "<what starts it, or UNKNOWN>",
  "sections": [
    {
      "id": "S1",
      "title": "<short>",
      "behaviour": "<prose. what happens, in business terms.>",
      "conditions": ["<decision condition verbatim from the input>"],
      "touches": ["queue:<name>", "app:<object name>", "credential:<name>", "..."],
      "clarity": "clear|UNKNOWN",
      "stageids": ["<every stageid this section covers>"]
    }
  ],
  "excluded": [
    {"stageid": "<id>", "reason": "cosmetic|declaration|unreachable"}
  ],
  "error_handling": "<what happens when it fails, or 'none found'>",
  "open_questions": ["<what a human must confirm before this spec is trusted>"]
}

"clarity": "UNKNOWN" is a section you wrote but are not confident about. It is
expected on real code and is not a failure - it routes that section to a human.
Marking a section clear when it is not is the failure.

<<<LEDGER
{{PASTE THE STAGEID LIST FOR THIS PAGE - one per line}}
LEDGER

<<<PAGE
{{PASTE THE PAGE XML HERE}}
PAGE
```

---

## Getting the ledger

```powershell
.\.venv\Scripts\python.exe tools\stage_ledger.py <export-dir>                        # artifacts
.\.venv\Scripts\python.exe tools\stage_ledger.py <export-dir> "Payments Process"     # its pages
.\.venv\Scripts\python.exe tools\stage_ledger.py <export-dir> "Payments Process" "Main Page"
```
The last one prints the stageids, one per line — paste that block as the ledger.

## Checking the answer

`tools/verify_llm_output.py` is the whole acceptance test:

- **ledger balances** — every ground-truth stageid appears exactly once. This
  is pass/fail. Everything else is advisory.
- no invented stageids;
- `conditions` appear verbatim in the export;
- `touches` agree with the analyzer's `edges` for those stages — the analyzer
  already knows every queue/credential/object each stage touches, so a `touches`
  entry the analyzer never saw is a hallucination, and one the analyzer saw but
  the model missed is an omission. **This is a second, independent completeness
  check on a different axis, and it is free.**

When the ledger does not balance, do not patch the output — **re-run with a
smaller slice**. An unbalanced ledger means the page exceeded what the model
could hold, and a model that dropped stages will also have dropped meaning from
the ones it kept.

## Known failure modes

- **Fluent omission.** The whole reason the ledger exists.
- **"...and the remaining stages handle cleanup"** — the model will try to
  summarise the tail of a long ledger. The script catches it every time.
- **Excluding what it did not understand.** Watch the `excluded` array: if it
  is much longer than the analyzer's dead-code + declaration count, the model
  is hiding confusion in it. Compare the two numbers — that comparison is free
  and catches the most dishonest failure this prompt has.
- **Prose that is just the diagram in words** ("goes to stage 5, then stage 6").
  Useless to an analyst and to uFlow. Reject and re-run.
