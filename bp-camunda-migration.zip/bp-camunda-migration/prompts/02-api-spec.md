# Task 1b — draft API specification (per custom object)

**Status: LIVE (un-parked 2026-08-20).** It was parked while no migration target
was chosen. The target is now known — **uFlow = Fluxnova = a Camunda 7 fork**,
whose only outbound verb is *"call a JSON/XML API"* (it has no hands). So every
**custom** VBO the estate calls needs an API before its work can move. This
prompt drafts that API, one object at a time, from evidence.

**Goal:** a first-draft API contract per custom object, to open the conversation
with the product team that must build it.

**Read this first.** The hard part is *the data that never leaves the
application*. An LLM cannot know whether a system can expose a field. So this
prompt is scoped to what it **can** do honestly:

> Turn "the bot calls these object actions with these fields" into "here is the
> shape of the API that would let the bot stop" — and mark loudly where a human
> has to decide.

The draft is a **conversation starter for the product team**, never a spec to
build from. Treat any endpoint it emits as a question.

**Run it on:** one object's record from `tools/api_facts.py` — the action
ledger with per-action `request_fields`, `response_fields` and `stageids`,
extracted deterministically from the real call sites. Produce that ledger first:

```
python tools/api_facts.py "<release>" --tier rehost -o api_facts.json
```

`--tier rehost` gives you only the custom objects that actually need an API
(native → Fluxnova features, connector → existing libraries; neither needs a
spec). Paste **one** object's record per run. Not raw XML — this step reasons
over facts already extracted and checked.

**Prerequisite:** `00-CONTRACT.md` loaded as the system instruction.

---

## Prompt

```
You are drafting a REST API specification to replace UI automation.

INPUT: the verified action ledger for ONE custom Blue Prism object, produced by
api_facts.py from the real call sites and already checked against the source.
Treat every field as fact. Do not re-derive it and do not add actions or fields
that are not in the input.

Derive endpoints ONLY from actions present in the input. One endpoint per
distinct BUSINESS operation the bot performs - not one per Blue Prism action
(several actions are often one operation split for reuse).

Blue Prism PLUMBING is not a business operation - it maps to API concerns, not
endpoints. Do NOT emit endpoints for: "Launch", "Attach", "Terminate", "Exit",
"Initialise", "Close", "Create Instance". Session/auth actions ("Login",
"Logon", "Connect", "Authenticate") map to the API's OWN AUTH, not an endpoint -
list them under "auth_candidates", never as an operation.

request_fields come ONLY from the input's request_fields; response_fields ONLY
from its response_fields. Never invent a field. If an action has empty field
lists, say so - an operation whose I/O the bot never made explicit is a real
"blocked_on" item, not a reason to guess.

For every endpoint, populate "blocked_on" with anything a human must settle
before it can be built. An endpoint with an empty "blocked_on" is a claim the
product team can build it as written - only make that claim when the input fully
determines the operation.

Never invent: auth schemes, pagination, rate limits, error codes, versioning,
field types not evidenced by the input. If the input does not say, the answer is
UNKNOWN and it goes in "open_questions".

Output exactly this JSON and nothing else:

{
  "object": "<object name, verbatim from the input>",
  "auth_candidates": ["<login/connect action that becomes API auth>", "..."],
  "endpoints": [
    {
      "operation": "<business operation in plain language>",
      "replaces": [{"action": "...", "stageids": ["..."]}],
      "method": "GET|POST|PUT|PATCH|DELETE",
      "path": "/<proposed>",
      "purpose": "<one sentence>",
      "request_fields": [
        {"name": "<verbatim from input>", "type": "string|number|boolean|date|binary|UNKNOWN",
         "required": true|false}
      ],
      "response_fields": [
        {"name": "<verbatim from input>", "type": "..."}
      ],
      "idempotent": true|false|"UNKNOWN",
      "idempotency_note": "<if the bot writes/posts, what a retry does today>",
      "blocked_on": ["<what a human must decide>", "..."],
      "open_questions": ["<question for the product team>", "..."]
    }
  ],
  "data_needing_workaround": [
    {"field": "<name>", "why": "<why an API cannot supply it>",
     "options": ["<workaround, only if the input supports it>"],
     "decision_owner": "product team|RPA team|UNKNOWN"}
  ],
  "not_covered": ["<every input action NOT mapped above (incl. plumbing), and why>"]
}

"idempotent": for anything that writes, this is the question that decides
whether a retry double-posts. If the input does not settle it, say UNKNOWN and
put it in blocked_on. Never guess it as true.

<<<LEDGER
{{PASTE ONE OBJECT'S RECORD FROM api_facts.json}}
LEDGER
```

---

## Checking the answer

Mostly judgement, so human review. What a script can check against the ledger:

- every `replaces[].action` exists in the input object's actions;
- every `replaces[].stageids` appears in that action's `stageids`;
- every `request_fields[].name` / `response_fields[].name` appears verbatim in
  the ledger for that action (nothing invented);
- **coverage ledger:** the actions named across all `replaces[]`, plus
  `auth_candidates`, plus `not_covered`, equal the full set of actions in the
  input. No action silently vanishes. (Same trick as `04-process-spec.md`.)

What only you can check: whether the endpoints are the right *shape*. Expect to
rewrite most paths — the value is the field lists, `blocked_on`,
`auth_candidates` and `data_needing_workaround`, not the URL design.

## Known failure modes

- **Confident REST slop.** The model has read a million OpenAPI docs and will
  add `?page=1&limit=20`, `Bearer` auth and RFC7807 errors nothing asked for.
  This prompt is the most slop-prone of the set — the model's prior is strongest
  and the input thinnest. The "never invent" clause fights it; check anyway.
- **Drops the hard fields.** The whole point is the unreachable data. A tidy
  spec is the failure mode, not the goal.
- **One endpoint per BP action.** Produces an "API" that is the UI with extra
  steps — re-hosting the bot, not replacing it.
- **Turns Login into an endpoint.** Auth is a cross-cutting concern; it belongs
  in `auth_candidates`, not as a business operation.
- **Guesses idempotency.** In a payments estate this is the field that becomes a
  double-posted transaction. `UNKNOWN` is always the safe answer.
