# Task 2 — coding-rules audit (before any generation)

**Goal:** find where an artifact violates the coding standard, as a citable
list. Not to fix it. Fixing comes after, and only for findings a human kept.

## Why audit before generate

Your note: *"baza tare pe guardrails … verificare dar la verificare posibil să
intervină token-urile"*. Auditing is how you dodge that. Generating code needs
verification of an artifact that **does not exist yet** — expensive and hard.
Auditing produces a **finding that points at a stageid that already exists** —
so verification is `grep`, not a second model pass.

So: audit → human keeps/drops findings → generate a fix for the kept ones →
re-audit. The re-audit is the acceptance test, and it costs the same as the
first one. Verification stops being an open-ended token sink and becomes a
fixed, known cost per artifact.

## Do NOT send mechanical rules to the model

Most of the standard is a regex, and paying a model to run a regex buys you
false negatives at a price. These belong in `bp_estate` as deterministic checks
— free, exact, no review:

- naming conventions (scope/datatype prefixes) — pure pattern match on names
  the parser already has;
- one action per type per object — a `GROUP BY` over `edges`;
- logging settings, Global Ignore Value, queue-name-equals-process-name —
  attribute equality;
- `published` state, Main Page presence — the parser already emits both.

Send the model **only** what needs reading comprehension:

- does the page actually do what its narrative claims?
- is this genuinely a Business Core page, or orchestration wearing the name?
- does the error handling recover, or just swallow?
- is this stage's narrative meaningful, or `"Data1"`?

That split is the whole game. If a rule can be a regex, it must be a regex.

### The VB.NET rules are all regex

Every code-pattern rule in the audit reference is a literal string search over
`<code>` blocks. None of them needs a model:

| grep for | means |
|---|---|
| `ExecWithTimeout` | timeout wrapper present |
| `InvokeReflection` | reflection call |
| `Marshal.ReleaseComObject` | COM released |
| `GetObject(` / `GetInstance(handle)` | attaches to a running instance |
| `Workbooks.Open(` | opens a workbook |
| `MessageBox.Show` | **blocking UI in an unattended bot** |
| `powershell` / `cmd.exe` / `python` | script execution in a process |

Presence/absence is the finding. Run these in `bp_estate`, not in a prompt:
free, exact, no review, and no false negatives from a page the model only
sampled.

### The mechanical half is BUILT — run it before you prompt anything

```
.\.venv\Scripts\python.exe tools\audit_rules.py <export> -o findings.json
.\.venv\Scripts\python.exe tools\render_audit.py findings.json -o audit.html
```

12 checks, exact over every in-scope stage, no sampling, no tokens. It also
prints a **coverage table** over the standard's 12 sections, so what it does
NOT check is on the page next to what it does. Send the model only the sections
that table marks uncovered-because-judgement.

Two behaviours worth knowing before you trust a run:

* **Vendor code is out of scope by default.** Objects marked `shipped` or
  `internal` in `data/vbo_registry.yaml` are skipped — Blue Prism wrote them,
  the standard does not govern them, and auditing them produced four
  block-severity false positives on the first real file. `--include-shipped`
  overrides.
* **A check that scanned nothing is not a check that passed.** Every row
  reports what it examined, and `scanned 0` is printed in the failure colour.

Findings tagged `fix_is_mechanical` and whose value is *computable* can be
applied with `tools\fix_mechanical.py`; everything else lands in `handoff.json`,
which is what the prompt below is for.

**Prerequisite:** `00-CONTRACT.md` loaded as the system instruction.

**Run it on:** one page at a time, plus the artifact's data items.

---

## Prompt

```
Audit one page of a Blue Prism artifact against the coding standard below.
Report violations. Do NOT fix anything, do not rewrite, do not suggest code.

The standard between <<<STANDARD markers is the ONLY standard. It overrides
anything you believe about Blue Prism best practice, any other version of this
document, and any convention you have seen elsewhere. If the standard does not
say it, it is not a rule, and you must not report it. Blue Prism version and
standard version differ between departments - never carry a rule across.

Report ONLY violations you can point at. Every finding names the exact rule
from the standard and the exact stageid. A finding you cannot pin to a stageid
does not exist - drop it.

Do not report a rule as satisfied. Do not report style opinions. Do not report
the same violation twice because it appears on many stages - group it, list the
stageids.

If the page is compliant, return an empty findings array. An empty array is a
correct answer and is expected often. Do not manufacture a finding to look
useful.

severity:
  "block"   - the standard states it as mandatory AND breaking it can cause a
              production incident (error handling, credentials, logging of
              sensitive data, queue integrity)
  "warn"    - the standard states it as mandatory, lower blast radius
  "info"    - the standard states it as a recommendation

confidence:
  "certain" - the standard is explicit and the input plainly breaks it
  "likely"  - requires reading the intent of the stage
Anything below "likely", do not report.

Output exactly this JSON and nothing else:

{
  "input_scope": "<what you were given>",
  "artifact": "<@name>",
  "page": "<page name>",
  "findings": [
    {
      "rule": "<the rule, quoted or closely paraphrased from the standard>",
      "rule_section": "<section number/heading from the standard, or UNKNOWN>",
      "severity": "block|warn|info",
      "confidence": "certain|likely",
      "stageids": ["<stageid>", "..."],
      "observed": "<what the input actually shows - quote it>",
      "required": "<what the standard requires instead>",
      "fix_is_mechanical": true|false
    }
  ],
  "not_auditable": [
    {"rule_section": "...", "why": "<what you were not given that this rule needs>"}
  ]
}

"fix_is_mechanical": true only if the fix is a rename or an attribute change
with no behaviour change. Those get batched and applied by script, not by you.

"not_auditable" matters as much as findings: it tells us which rules this
single page cannot answer (e.g. an estate-wide rule). Be exhaustive there.

<<<STANDARD
{{PASTE THE RELEVANT SECTIONS OF THE BP CODING STANDARD HERE}}
STANDARD

<<<PAGE
{{PASTE THE PAGE'S STAGES + THE ARTIFACT'S DATA ITEMS HERE}}
PAGE
```

---

## Why the standard is a slot and not baked in

It is bank-internal, and this repo must stay clean of it. But it would be a
slot anyway: the standard is versioned (and departments are not on the same
version). Pasting it live means an audit is always against the standard you
actually hold, and a `rule_section` in the output can be traced back to a real
document rather than to a transcription that drifted.

Paste **only the sections in scope** for the page. The whole standard in every
call is most of your token bill for zero accuracy gain.

## Checking the answer

- every `stageids` entry exists on that page → `tools/verify_llm_output.py`;
- every `observed` quote appears verbatim in the input → same script;
- `rule_section` resolves to a real section of what you pasted → eyeball;
- spot-check the empty results: **a page that returns `[]` when you know it is
  bad is the failure that matters**, and no script catches it. Keep two or
  three known-bad pages as a permanent canary and re-run them whenever the
  model or the prompt changes.

## Known failure modes

- **Recites Blue Prism best practice from training data** instead of your
  standard. The override clause fights this; the `rule_section` field is how
  you catch it — a finding with `"UNKNOWN"` section is usually invented.
- **Reports everything as a violation** to seem thorough. The "empty is
  correct" clause fights this.
- **Sycophantic compliance.** Ask it "are you sure?" and a weaker model folds
  and retracts a correct finding. Never re-ask that way — re-run the page
  clean, and diff the two runs instead.
- **Rules that need the whole estate** (queue name = process name) cannot be
  answered from one page. That is what `not_auditable` is for, and it is why
  those rules belong in the analyzer anyway.
