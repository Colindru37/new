# Task 1a — application inventory — RETIRED, this is not a prompt any more

This used to be a prompt that asked a model which applications an object drives.
It should never have been one, and it broke the rule the whole folder is built
on: **if a regex can answer it, a regex answers it.**

Every Blue Prism object carries an `<appdef>` — the Application Modeller
definition. It states the application's name, how it is driven, the executable
path, and the whole modelled UI tree. It is exact, it is free, and asking a
model to infer it from action names was always going to be worse.

## Do this instead

```powershell
.\.venv\Scripts\python.exe -m bp_estate.cli analyze <export-dir> --out out
```

`out/estate-report.md` gains an **Applications driven** table, and
`out/estate.json` gains an `applications[]` array:

```json
{
  "name": "Centrix Data Solutions",
  "driven_by": ["Centrix - Basic Actions", "Centrix - Order Processing"],
  "launch_types": ["Win32Attach", "Win32Launch"],
  "executable": "C:\\BluePrism\\...\\CentrixDataSolutions.exe",
  "element_count": 17,
  "launches": true
}
```

What each field is for:

- **`driven_by`** — one application is normally driven by several objects, one
  that launches it and one that attaches to it. The application is the unit an
  API conversation happens about; the object is not.
- **`launch_types`** — `Win32Launch`/`Win32Attach` is a thick client,
  `HTML` a browser, `Mainframe` a terminal. This decides what replacing it even
  looks like, and it is the first thing anyone asks.
- **`element_count`** — how much UI was modelled. The honest proxy for how much
  work a re-host is.
- **`launches: false`** — nothing in the export starts this application. Some
  other process, a person, or a scheduled task does. That is a dependency the
  export does not show you and somebody has to go and find.

## The one trap

Blue Prism gives **every** object an `<appdef>`, including code-only VBOs that
drive nothing at all. Four of the six objects in the Foundation Training release
carry an empty one — a single `Application Root` element and no launch type.
"Has an appdef" does not mean "drives an application", and counting those would
inflate the estate's re-hosting surface with utilities that only shuffle
collections around. The parser drops them; see
`tests/test_parse.py::test_appdef_stub_is_not_an_application`.

## What still needs a model

Nothing here. The next step — turning "the bot does these things to this app"
into a draft API contract — is `02-api-spec.md`, and it takes this inventory as
its input.
