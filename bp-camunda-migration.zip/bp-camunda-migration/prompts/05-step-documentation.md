# Cross-cutting — automated step documentation

**Goal:** the step-by-step record the programme owes for every automation:
the steps, the applications and processes used, and where a screenshot belongs.

Your note: *"pașii contează da nu foarte"* — so this prompt spends its effort on
the **application/process inventory** and on **which steps need a screenshot**,
and keeps the step list coarse. Steps are the deliverable's skeleton; the
inventory is its value.

## What this can and cannot do

**Can:** produce the document's structure, the app/process inventory, and a
list of the exact points where a screenshot is required, each pinned to a
stageid.

**Cannot:** take the screenshots. Those come from a run — either Blue Prism's
own *Save Screenshot* on exception (your standard already mandates it) or a
capture during a piloted run. This prompt tells you **where** to point the
camera; it cannot hold it. Don't let the doc's completeness be judged on
something static analysis structurally cannot supply.

**Run it on:** the merged, verified `04-process-spec.md` output for a whole
artifact — not on XML. Documentation is written from the spec, so the two can
never drift apart. If you generate it from XML separately, you now have two
descriptions of one process and no idea which is right.

**Prerequisite:** `00-CONTRACT.md` loaded as the system instruction.

---

## Prompt

```
Produce step-by-step documentation for one automated process, from its
verified specification.

INPUT: specification records for every page of one artifact, already checked
against the source. Treat them as fact. Do not add behaviour that is not in
them. Do not re-derive anything - if the spec says a section is UNKNOWN, the
documentation says so too, in those words. Never smooth over an UNKNOWN: this
document is read as a description of what actually runs.

Steps are COARSE: a step is a unit a human would recognise as one thing done
("log in to the payment system", "post the batch"), not one stage. 8-20 steps
for a typical process. If you are writing 60 steps, you are transcribing the
diagram, which is not what this is for.

Applications and processes: list EVERY distinct application, system, work
queue, and called process the spec mentions. This list is the primary output -
be exhaustive here even where you are coarse elsewhere. It is what the estate
inventory is built from and what the API conversations are scoped by.

Screenshots: mark a step "screenshot_required": true when a human reader could
not verify the step happened without seeing the screen. That is: any step that
changes state in an external application, any decision made on what the screen
shows, and any failure path. Navigation between screens does not need one.
For each, say exactly what must be visible - "the payment confirmation number",
not "the screen".

User stories: group the steps into 3-6 coarse arcs a reader would recognise as
the phases of the automation ("Process Initialization & Queue Population", "Case
Data Reading & Business Rule Verification"). Each is one "As a robot, I must ..."
narrative plus the data that phase fetches. This is only a grouping of the steps
you already wrote - every step carries the id of the story it belongs to, and a
step whose story is missing is shown under "Other steps", never dropped. Do NOT
invent phases the steps do not support.

Do NOT produce environment configuration or session/input variables. Those are
read off the export by the parser and rendered as fact; a datatype or a variable
name you write here would be prose over something already known, which is exactly
what this pipeline distrusts. Say nothing about them.

Output exactly this JSON and nothing else:

{
  "artifact": "<@name>",
  "purpose": "<one paragraph: what this automation is for>",
  "trigger": "<what starts it, verbatim from the spec, or UNKNOWN>",
  "applications_used": [
    {
      "name": "<application/system>",
      "how": "<UI automation|API|file|UNKNOWN>",
      "used_for": "<one sentence>",
      "steps": ["<step id>", "..."]
    }
  ],
  "processes_used": [
    {"name": "<called process or object>", "used_for": "<one sentence>"}
  ],
  "queues_used": [
    {"name": "<queue>", "role": "<reads|writes|both>"}
  ],
  "credentials_used": ["<credential name - NEVER a value>"],
  "user_stories": [
    {
      "id": "US1",
      "title": "<the phase, e.g. Process Initialization & Queue Population>",
      "narrative": "<one 'As a robot, I must ...' sentence>",
      "data_fetched": ["<what this phase reads>", "..."]
    }
  ],
  "steps": [
    {
      "id": "1",
      "title": "<what a human would call this>",
      "detail": "<what happens>",
      "application": "<from applications_used, or 'none'>",
      "user_story": "<the id of the story this step belongs to, e.g. US1>",
      "screenshot_required": true|false,
      "screenshot_shows": "<exactly what must be visible, or null>",
      "spec_sections": ["S1", "..."],
      "on_failure": "<what happens if this step fails, or UNKNOWN>"
    }
  ],
  "not_documented": [
    {"spec_section": "S9", "why": "<why no step covers it>"}
  ]
}

Refer to every section as "<page name>/<section id>" - for example
"Main Page/S1". Section ids are only unique within a page: every page has an
S1, so a bare id is ambiguous and will be rejected.

Every section of every page you were given MUST appear exactly once across
"steps[].spec_sections" and "not_documented". This is checked by a script. The
same rule as the spec's stage ledger, one level up: a section you cannot place
is reported, never dropped.

"credentials_used": names only. If a credential value or a Password data item
appears anywhere in the input, do not reproduce it - report the name and move on.

<<<SPEC
{{PASTE THE VERIFIED 04-process-spec JSON FOR EVERY PAGE OF ONE ARTIFACT}}
SPEC
```

---

## Checking the answer

- **section ledger balances** — every `<page>/S*` from the input specs appears
  exactly once across `steps[].spec_sections` and `not_documented`. Same trick
  as the stage ledger, and the same script — but you must pass the specs:

  ```powershell
  .\.venv\Scripts\python.exe tools\verify_llm_output.py doc.json <export> --specs <spec-dir>
  ```

  Without `--specs` it can only catch a section claimed twice, never one
  dropped, and a drop is the failure that matters. The first real run of this
  prompt dropped a section (the Excel cleanup path) whose behaviour was
  described in prose but never accounted for — which is exactly how a failure
  path goes missing from a document that reads as complete;
- `applications_used`, `queues_used`, `credentials_used` are **subsets** of what
  the analyzer already extracted. A name the analyzer never saw is invented; a
  name the analyzer saw and the doc missed is an omission. Both are script-
  checkable, both for free — this is the check that makes the inventory
  trustworthy, which is the point of the whole prompt;
- no credential values, no `Password` initial values — grep for them.

## Known failure modes

- **Writes the happy path only.** Failure paths are where documentation earns
  its keep in an audit. `on_failure` on every step fights this; if most come
  back `UNKNOWN`, that is a true finding about the process, not a bad answer.
- **Invents a plausible business purpose.** "This process handles customer
  onboarding" when nothing said so. Constrain to the spec's `purpose`.
- **Screenshot inflation.** Everything marked true is the same as nothing
  marked true, and someone has to take each one.
- **Rewrites UNKNOWN into confident prose.** The most damaging failure here,
  because this document is the one non-engineers read and believe.
