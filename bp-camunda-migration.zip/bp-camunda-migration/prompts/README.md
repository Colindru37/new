# Prompts (Gemini / Copilot)

Prompts for the model that will actually do this work, in the order it runs.
They are written for a model that is **not** the one drafting them: assume it
will confabulate confidently, so every prompt is built so that a script can
catch it.

| | Prompt | Input | Checkable? | Live? |
|---|---|---|---|---|
| 00 | `00-CONTRACT.md` | — | system instruction, paste first | yes |
| 06 | `06-objects-comparison.md` | two objects + a parser diff | **fully** | yes |
| 03 | `03-coding-rules-audit.md` | one page + the standard | mostly | yes |
| 04 | `04-process-spec.md` | one page + a stage ledger | **fully** | yes |
| 05 | `05-step-documentation.md` | verified 04 output | mostly | yes |
| 01 | `01-app-inventory.md` | — | n/a | **retired — the analyzer does it** |
| 02 | `02-api-spec.md` | `api_facts.py` per-object ledger | coverage-checkable | **live (un-parked 2026-08-20)** |

**Typing them by hand:** use `HANDWRITE.md`. Same guarantees, a quarter the
length — only the sentences meant for you were cut.

01 is **retired**: `<appdef>` answers it exactly, so `bp_estate` now emits an
application inventory and the prompt is a pointer to it. That deletion is the
rule below working — a prompt that survives contact with the real file format
is one nobody checked against the real file format.

02 is now LIVE (un-parked 2026-08-20): the target is known (uFlow = Fluxnova =
a Camunda 7 fork, API-only), so the custom objects genuinely need API specs. It
is re-aimed from applications to OBJECTS and driven by `tools/api_facts.py`,
which extracts a per-object action ledger (actions + request/response fields +
stageids) from the real call sites -- so the spec is coverage-checkable, not
vibes.

Nothing here covers **migration to uFlow**, deliberately. We do not know what
uFlow ingests (BPMN? proprietary JSON? an API?), so any prompt written now
encodes a guess at the target format and every downstream fix inherits it.

## How they are meant to run

```
export ──► bp_estate (deterministic) ──► facts + stage ledger
                                              │
                                              ▼
                        00-CONTRACT + task prompt ──► model ──► JSON
                                              │
                                              ▼
                        tools/verify_llm_output.py ──► ok / FAIL
                                              │
                                              ▼
                                       human review
```

The model never sees a question the parser could have answered. That is not
frugality — it is that the parser is *right*, and on those questions the model
is merely usually right, which is worse than useless when nobody re-checks it.

## The four rules every prompt follows

1. **Deterministic first.** If a regex can answer it, a regex answers it. The
   model gets only reading comprehension.
2. **Cite or say UNKNOWN.** Every claim carries a stageid or a verbatim quote.
   This is what makes verification a `grep` instead of a second model pass —
   the answer to *"unde vine verificarea, și cât costă?"*.
3. **Ledgers, not vibes.** Completeness is a set-equality assertion against
   ids the parser produced, never a reviewer's impression. See
   `04-process-spec.md` — that idea is the one worth keeping if the rest is
   thrown away.
4. **UNKNOWN is a success.** Every prompt says so explicitly. A model that
   guesses to please you is the specific failure mode that makes AI output
   untrustworthy around money.

## Verifying an answer

```powershell
.\.venv\Scripts\python.exe tools\verify_llm_output.py answer.json <export-dir-or-file>
```
Exit 0 = nothing invented, nothing dropped. It checks: no invented stageids,
stages cited belong to the page named, the stage ledger balances exactly,
exclusions are corroborated by the parser, quotes are verbatim, `touches`
agrees with the analyzer's edges both ways, and no `Password` value is echoed.

It does **not** check whether the prose is any good. Nothing can. Budget for
reading it.

## Costs, and where they actually go

Cheap and fixed: 01, 03, 04. One artifact or page per call, no second pass,
verification is free because it is a script.

Expensive and open-ended: 02, and any future generation step. There the model
produces something that does not exist yet, so nothing can be diffed against a
source. Push work **out** of that column — the audit-then-fix split in `03` is
exactly that move, and it is why 02 is scoped to a draft for humans rather than
to a spec to build from.

## Slots

`{{LIKE_THIS}}` is a paste slot. The coding standard is a slot on purpose:
it stays out of this repo, it is versioned, and departments are not all on the
same version — so an audit should always run against the copy you actually
hold, not a transcription that drifted.

## Before you paste a real export

These prompts take real Blue Prism exports: credentials, PII references, and
the bank's process logic. Use the **sanctioned enterprise tenant** (Copilot
Studio / Vertex under the bank's agreement), never a consumer chat window, and
follow whatever data classification the estate carries. Fixtures in
`tests/fixtures/` are synthetic and safe to experiment with — start there while
tuning a prompt, because tuning takes many runs and none of them need real data.

## Tuning

Change one thing, re-run the same input, diff the JSON. At temperature 0 a
prompt change is the only variable, so a diff is signal.

Keep two or three known-bad pages as permanent canaries: the failure that hurts
is a clean-looking pass on a page you know is broken, and only a canary catches
that. Re-run them whenever the prompt, the standard, or the model changes —
especially the model. These are written against Gemini/Copilot behaviour; a
version bump is a silent prompt change.
