# Blue Prism → Fluxnova (Camunda 7) BPMN emission map

> **Aligned 2026-10-21 to what `port/bp_emit.py` emits** (runtime-verified on
> Camunda 7.24 by `tools/c7_runtime_check.py`, linted by `tools/bpmn_lint.py`,
> measured by `port/bp_equiv.py`). The short operational contract lives in
> `skill-bp-to-camunda/reference/conventions.md`; this document keeps the
> reasoning and the per-construct binding. Where the two disagree, the
> conventions file wins and this one has a bug.

The concrete emitter contract. It binds every construct the estate analyzer lifts
out of a Blue Prism export to a specific BPMN 2.0 element and vendor-extension
attribute, targeting **Fluxnova** — the FINOS fork of **Camunda 7** Community
Edition that Deutsche Bank co-maintains.

This **supersedes DESIGN.md §8–9 and §10**, which were written against Camunda 8 /
Zeebe / FEEL before the target was known. Two corrections propagate through
everything below:

- **It is Camunda 7, not 8.** Process-level expressions are **JUEL** (`${...}`),
  not FEEL. FEEL appears *only* inside DMN decision tables.
- **Service work binds as an external task**, not a Zeebe job worker — the
  `camunda:type="external"` + `camunda:topic` pattern.

It builds on, and does not repeat, `EXCEPTION-LOOP-MAPPING.md`, which already
grounds loops / exception handlers / cross-page propagation in the analyzer's
`loop_regions`, `exception_handlers`, and `exception_propagation` sections. Where
that note said "when the target format is known, each row binds to a concrete
element" — this doc *is* that binding.

---

## 1. Locked target conventions (from the fork's source, not the brochure)

Read directly from `finos/fluxnova-bpm-platform` (`BpmnModelConstants.java`, module
layout, external-task client) on 2026-08-13:

| Concern | Value |
|---|---|
| Standard BPMN 2.0 namespace | `http://www.omg.org/spec/BPMN/20100524/MODEL` — unchanged |
| DI namespaces | OMG `BPMNDI` / `DC` / `DI` — unchanged |
| Vendor extension namespace | **both** retained: `camunda:` = `http://camunda.org/schema/1.0/bpmn`, `fluxnova:` = `http://fluxnova.finos.org/schema/1.0/bpmn` (identical local names) |
| Engine | Spring Boot, Java 21; module layout = stock Camunda 7 (`engine`, `engine-rest`, `engine-dmn`, `model-api/bpmn-model`, `webapps`, `spring-boot-starter`, `quarkus-extension`) |
| Java packages | renamed `org.camunda` → `org.finos.fluxnova` (engine-side only — does **not** touch our XML) |
| Service binding | external-task client shipped (`clients/java/client`) → external tasks are first-class |
| Expression language | Camunda 7 JUEL `${...}` at process level; FEEL in DMN only |

### The namespace decision

The vendor-extension attribute **local names are identical** across `camunda:` and
`fluxnova:` — only the URI differs. So the emitter carries the extension namespace
in **one config constant**:

- **Default: `fluxnova:`** — target-native, forward-proof against a future
  deprecation of the compat `camunda:` namespace.
- **`--ns camunda` flag** — for tooling interop (Camunda Modeler, bpmn.io, a local
  Camunda 7 "Run" jar). Because Fluxnova *retains* `CAMUNDA_NS`, a `camunda:`
  file we emit **deploys to Fluxnova unmodified today** — which is what lets us
  validate against a free local Camunda 7 before Fluxnova is even reachable.

Everything downstream references `EXT_NS`; nothing hard-codes `camunda:`.

---

## 2. Stage-by-stage mapping

Confidence: **High** = mechanical, deterministic, runtime-verified; **Medium** =
deterministic but with a semantic hazard flagged in §5; **Manual** = emitted as
a labelled placeholder or refused on purpose, surfaced for a human.

| Blue Prism | BPMN element (as emitted) | Conf. | Binding notes |
|---|---|---|---|
| Process / object | one `.bpmn` document per export; **each page = one `bpmn:process`**, id `p_<Artifact>__<Page>_<hash>`, name `<Artifact> / <Page>`, `ext:historyTimeToLive="P180D"` (required at deploy since 7.20) | High | the process id is the stable handle call activities and the REST API use; never hand-edit it |
| Main Page | the entry process; an object's Main Page is its Initialise | High | the process Main Page calls each used object's Initialise right after its own `Init:` task |
| Start / End | `startEvent` / `endEvent` | High | the End's declared outputs become the page's `out` mappings |
| Data item / Collection declarations | process-level `ext:properties`: `var:<name>` (type, scope, `(decimal - never double)` for numbers) and `collection:<name>` (field list) | High | the declaration block; lint `DATA-UNDECLARED` |
| Initial values | first node after Start = `task name="Init: <page>"`, one `outputParameter` per Data item with its typed literal (`${false}`, `${0}`, `${'text'}`, `${null}` unset date) | High | passwords and collections are never initialised here; items BP kept between calls are reset anyway and listed in the task's documentation |
| Page call (SubSheet stage) | `callActivity calledElement=<page process>` with explicit `ext:in` / `ext:out` per parameter | High | §3; process-wide items the page touches (transitively) are threaded in and out too |
| Action on an object **in the export** | `callActivity` into that object's action page, same mapping; the object's process-wide items travel as `<Object>::<item>` in the caller's scope | High | object state lives where BP kept it: with the instance, i.e. across the calls |
| Action on an object **not in the export** (Work Queues, Credentials, un-exported VBOs) | external `serviceTask` `ext:type="external" ext:topic="<object>.<action>"` (lower-case, spaces → `-`), inputs/outputs mapped | Medium | the re-host seam; internal VBOs are **still** external tasks today (the §2a native mapping is design, not emitted) |
| Decision | `exclusiveGateway name="…?"`, flows `${E}` (named `Yes`) / `${!(E)}` (named `No`) | High | untranslatable `E` → `${TODO_manual_condition}` on the Yes branch + `default` on No, so the model deploys and raises an incident instead of guessing |
| Choice (`ChoiceStart`…`ChoiceEnd`) | `exclusiveGateway`, conditions chained in BP's top-down order (`!(c1) && (c2)` …), flows named after the choices, the ChoiceEnd "otherwise" is the gateway `default` | High | R1 priority preserved by construction |
| Wait (`WaitStart`…`WaitEnd`) | `exclusiveGateway` over the wait's `<choices>` (parsed like a Choice), last flow named `Time Out` | Medium | a task with two outflows would FORK; condition-met vs timeout is exclusive. No real timer: the UI it waits on is re-hosted in a worker |
| Calculation / MultipleCalculation | `task` carrying an `outputParameter name=<target>` = `${expr}` per assignment, in order | High | a real assignment (proved: Amount=21 → Doubled=42); unknown function → manual (§4) |
| Loop (`LoopStart`…`LoopEnd`) over collection `C` | sequential multi-instance `subProcess`, `ext:collection="C"` `ext:elementVariable="C#row"` | High | `C#row` **is** the current row; `[C.Field]` reads `execution.getVariable('C#row')['Field']`; a worker implementing a collection action must maintain `C#row` |
| Block with Recover **and** Resume | embedded `subProcess` + interrupting error `boundaryEvent` binding `bpErrorCode`/`bpErrorMessage`; the recovery path leaves the boundary and rejoins at the Resume | High | SESE restructuring is mechanical, **nested** (a Block inside a loop body, a loop inside a Block, Blocks in Blocks): regions nest by set containment; a Recover lives where its try scope is, so a handler inside a loop iteration resumes into that iteration. Runtime-verified (`Nested` fixture: row 2 throws, is caught in-iteration, rows 1 and 3 still count) |
| Recover **without** Resume | event sub-process `triggeredByEvent="true"` named `Recover: <block>` that re-raises | High | re-raise keeps `${bpErrorMessage}` (lint `EXC-RERAISE-KEEPS-DETAIL`) |
| Exception stage | error `endEvent`; **one `bpmn:error` per throw**, `errorCode` `BP_SYSTEM` / `BP_BUSINESS`, `errorMessage="${detail}"` | High | `ExceptionType()` = `(bpErrorCode == 'BP_BUSINESS' ? 'Business Exception' : 'System Exception')`, `ExceptionDetail()` = `bpErrorMessage`; `ExceptionStage()` has no equivalent |
| Code stage, pure logic | `scriptTask scriptFormat="javascript"` **slot**: inputs/outputs mapped, the C#/VB source in `documentation`, body `throw new Error("TODO port: …")` until ported | Medium | only in **object** pages (lint `CODE-IN-PROCESS`); the port is gated by `tools/slot_oracle.py` + `tools/slot_check.py` (original I/O replayed) |
| Code stage reaching outside (I/O, COM, the object's shared code) | external `serviceTask`, topic `code.<object>.<stage>` | Medium | a worker, never a slot (lint `CODE-SLOT-REACHES-OUT`) |
| Navigate / Read / Write / Alert / Skill (UI stages) | labelled placeholder `task` | Manual | no engine equivalent; the whole object is re-hosted as a worker behind its action topic |
| Anchor, ChoiceEnd, LoopEnd, WaitEnd | dissolved (pass-through), never a node | High | the training release lost 137 meaningless boxes |
| Note / Block (non-recovery) | documentation / grouping only | High | |
| Clean Up page | **not modelled** | Manual | the re-hosting worker releases what it opened on every exit |
| Environment lock, Credentials, Work Queues | external task today; native pattern (vault ref / distributed lock / queue-item status) is the design target of §2a | Medium | R8 idempotency and R14 lock semantics live in the worker until then |
| Human / approval step | `userTask` (design, not auto-detected yet) | Manual | R9: never silently a service task |

### 2a. Internal-VBO calls do NOT become service tasks

The three object tiers (from `vbo_registry.yaml`) route differently — this is the
single most important classification, because misfiling an internal call as a
service task both invents a nonexistent integration and hides a native feature:

- **internal** (`clsWorkQueuesActions`, `clsCredentialsActions`,
  `clsEnvLockingActions`, `clsCollectionActions`) → a **native construct**: queue
  pattern, vault lookup, external lock, or an in-model data operation.
- **shipped** (Excel/Outlook/PDF/Web Services) → an **external `serviceTask`**
  bound to a connector/worker (a real integration exists to re-point).
- **custom** → an **external `serviceTask` stub** — the UI automation that must be
  re-hosted or replaced by an API. This is where the VMs actually die.

---

## 3. Emission patterns (the load-bearing XML)

Namespace prefix shown as `ext:` = the configured `EXT_NS` (`fluxnova:` default).

**Custom/shipped VBO call → external service task** (the RPA re-host seam):

```xml
<bpmn:serviceTask id="Task_ValidateIban" name="Validate IBAN"
                  ext:type="external" ext:topic="orinoco.validate-iban">
  <bpmn:extensionElements>
    <ext:inputOutput>
      <ext:inputParameter name="iban">${customerIban}</ext:inputParameter>
      <ext:outputParameter name="ibanValid">${result.valid}</ext:outputParameter>
    </ext:inputOutput>
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

**Choice (n-way) → priority-preserving exclusive gateway:**

```xml
<bpmn:exclusiveGateway id="Gw_Route" default="Flow_else"/>
<bpmn:sequenceFlow id="Flow_high" sourceRef="Gw_Route" targetRef="...">
  <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression"
    >${amount &gt; 100000}</bpmn:conditionExpression>
</bpmn:sequenceFlow>
<bpmn:sequenceFlow id="Flow_mid" sourceRef="Gw_Route" targetRef="...">
  <bpmn:conditionExpression xsi:type="bpmn:tFormalExpression"
    >${amount &gt; 1000}</bpmn:conditionExpression>
</bpmn:sequenceFlow>
<bpmn:sequenceFlow id="Flow_else" sourceRef="Gw_Route" targetRef="..."/>
```

Branches are emitted in BP's top-down order; `default` is the terminal else so the
gateway is total (never a stuck token). R1's mutual-exclusion check runs at emit.

**Loop → sequential multi-instance subprocess:**

```xml
<bpmn:subProcess id="Sub_ForEachRow">
  <bpmn:multiInstanceLoopCharacteristics isSequential="true"
      ext:collection="${invoiceRows}" ext:elementVariable="row"/>
  <!-- body stages the analyzer counted between the brackets -->
</bpmn:subProcess>
```

Sequential, never parallel — BP processes one row at a time and later rows may
depend on earlier side effects (R7).

**Recover → interrupting error boundary on the scope subprocess:**

```xml
<bpmn:subProcess id="Sub_Block17"><!-- the Block's stages --></bpmn:subProcess>
<bpmn:boundaryEvent id="Bnd_Recover" attachedToRef="Sub_Block17" cancelActivity="true">
  <bpmn:errorEventDefinition errorRef="Err_Business"/>
</bpmn:boundaryEvent>
<bpmn:error id="Err_Business" name="BusinessException" errorCode="BP_BUSINESS"/>
<bpmn:error id="Err_System"   name="SystemException"   errorCode="BP_SYSTEM"/>
```

`resumes=true` → the boundary's outgoing flow rejoins normal flow after the scope;
`escapes=true` → it ends in an `error endEvent` re-raising to the parent.

**Page reference → call activity, threading all vars:**

```xml
<bpmn:callActivity id="Call_PostPayment" calledElement="PostPayment">
  <bpmn:extensionElements>
    <ext:in  source="paymentId"     target="paymentId"/>
    <ext:in  source="ledgerContext" target="ledgerContext"/>
    <ext:out source="postingRef"    target="postingRef"/>
  </bpmn:extensionElements>
</bpmn:callActivity>
```

Explicit per-variable `in`/`out` (not `variables="all"`) so R5 — implicitly-read
globals silently dropped — is caught by the analyzer's data-flow set, not left to
the engine's ambient scope.


**Init task + declarations (the first node after Start, and the process header):**

```xml
<bpmn:process id="p_PRC042__Main_Page_3f2a" name="PRC042 / Main Page" isExecutable="true"
              ext:historyTimeToLive="P180D">
  <bpmn:extensionElements>
    <ext:properties>
      <ext:property name="var:Attempt"      value="number, page (decimal - never double)"/>
      <ext:property name="var:Queue Name"   value="text, process-wide"/>
      <ext:property name="collection:Rows"  value="Name, Amount"/>
    </ext:properties>
  </bpmn:extensionElements>
  <bpmn:task id="Init_Main" name="Init: Main Page">
    <bpmn:extensionElements><ext:inputOutput>
      <ext:outputParameter name="Attempt">${0}</ext:outputParameter>
      <ext:outputParameter name="Queue Name">${'PRC042 - Create Orders'}</ext:outputParameter>
    </ext:inputOutput></bpmn:extensionElements>
  </bpmn:task>
```

Variable names are the Blue Prism names verbatim, spaces included; JUEL reads a
non-identifier name with `execution.getVariable('Queue Name')`.

**Object state across action calls (`Object::item`):**

```xml
<bpmn:callActivity id="Call_GetSetting" name="Get Setting" calledElement="p_GKRevokeBrowser__Get_Setting_9c1e">
  <bpmn:extensionElements>
    <ext:in  source="Section"                         target="Section"/>
    <ext:in  source="GK Revoke Browser::Config Path"  target="Config Path"/>
    <ext:out source="Value"                           target="Value"/>
    <ext:out source="Config Path"                     target="GK Revoke Browser::Config Path"/>
  </bpmn:extensionElements>
</bpmn:callActivity>
```

The object's process-wide items live in the *calling* process under the
`<Object>::<item>` name and travel in and out of every action call, so between two
calls the state is exactly where Blue Prism kept it.

**Error contract (every throw, every catch):**

```xml
<bpmn:error id="Err_17" name="BusinessException: Orders file not found" errorCode="BP_BUSINESS"
            ext:errorMessage="${'Orders file not found.'}"/>
<bpmn:boundaryEvent id="Bnd_Recover_Login" name="Recover Login" attachedToRef="Sub_Login" cancelActivity="true">
  <bpmn:errorEventDefinition ext:errorCodeVariable="bpErrorCode" ext:errorMessageVariable="bpErrorMessage"/>
</bpmn:boundaryEvent>
```

A worker throws with the same contract (BPMN error, code `BP_BUSINESS` or
`BP_SYSTEM`, message = the detail), so `ExceptionType()` / `ExceptionDetail()`
translate uniformly whether the thrower is modelled or re-hosted.

**Code stage → script slot (until ported):**

```xml
<bpmn:scriptTask id="Task_BuildUrl" name="Build Task RITM URL" scriptFormat="javascript">
  <bpmn:documentation>// original C#
return "https://.../nav_to.do?uri=" + Uri.EscapeDataString(number);</bpmn:documentation>
  <bpmn:extensionElements><ext:inputOutput>
    <ext:inputParameter name="number">${execution.getVariable('RITM Number')}</ext:inputParameter>
    <ext:outputParameter name="Url">${Url}</ext:outputParameter>
  </ext:inputOutput></bpmn:extensionElements>
  <bpmn:script>throw new Error("TODO port: Code stage 'Build Task RITM URL' (3L C#)");</bpmn:script>
</bpmn:scriptTask>
```

A document with an unported slot is a draft (lint `CODE-SLOT-UNPORTED`). The port
is accepted only when `tools/slot_check.py` replays the cases `tools/slot_oracle.py`
produced from the **original** C# — the naive `encodeURIComponent` port of this
very stage failed case 4 (`Uri.EscapeDataString` escapes `!'()*`), the faithful
one passed 5/5.
---

## 4. Expression translation — JUEL, not FEEL

- BP expression language is VBA/VBScript-flavored. Target at process level is
  **Camunda 7 JUEL** (`${...}`), the language of `conditionExpression`,
  `inputParameter`/`outputParameter` and `errorMessage`.
- **Curated mapping table, never LLM guessing.** Implemented and executed on the
  engine (12 templates incl. BP's 1-based `Mid`/`InStr` and `InStr`-miss = 0):
  `Trim Upper Lower Len Left Mid Right InStr StartsWith EndsWith Replace`,
  `&` concatenation, `AND/OR/NOT` (keyword and function forms), comparisons,
  arithmetic, `ExceptionType()` / `ExceptionDetail()`, `[C.Field]` → `C#row`
  lookup. 96.9% of the training estate's expressions translate.
- **Refused on purpose** (surfaces as `(manual: unsupported function 'X')` in the
  node's documentation, `${TODO_manual_condition}` on a Decision): `ToNumber`,
  `IsNumber`, `IsStopRequested`, `ExceptionStage`, `GetClipboard`, the date
  functions, `^`. Unverifiable semantics are not worth a wrong deploy.
  `IsStopRequested()` has an accepted manual translation: a process variable set
  from outside via REST, documented on the gateway (modelling-rules.md).
- JUEL that is not XML-safe (`&&`, `<`) is escaped at emit; one real artifact was the only
  training artifact that hit it.
- **DMN stays the escape hatch** for decision-heavy Choices (FEEL belongs there,
  and only there). Not emitted automatically.

## 5. Semantic hazards carried forward (unchanged, still critical)

These are the DESIGN §11 risks that the mapping must actively defend, not the
"schema-valid ⇒ done" illusion (R11):

- **R6 Money math — Camunda 7 has no decimal variable type.** BP `Number` = .NET
  `decimal`; the engine's numeric vars are `integer`/`long`/`double`. **Never
  carry money as `double`.** Money variables are typed objects (serialized
  `BigDecimal`) or explicit decimal-string with parse/format at every boundary.
  Financial test cases gate this.
- **R1 Choice ordering** — priority-preserving gateway + mutual-exclusion check.
- **R2 Exception mis-scope** — manual review gate on every Recover/Resume; the
  Block-geometry scope (EXCEPTION-LOOP §4) makes the TRY precise, but the CATCH
  rejoin still needs eyes.
- **R8 Idempotency** — reconstruct queue-status guards; item status is the
  double-post guard, not decoration.
- **R9 Human step** — approval/manual queue items → `userTask`, never a service
  task; SoD / four-eyes preserved.
- **Typed errors** — System vs Business must be distinct `bpmn:error` codes so a
  handler can discriminate.
- **Dates/timezones** — `Today()`/`Now()` were resource-VM local time; make TZ and
  business-calendar explicit.

---

## 6. Data & type mapping (BP datatype → engine variable)

| BP datatype | Engine variable | Note |
|---|---|---|
| Text | `String` | |
| Number | **serialized `BigDecimal` / decimal-string** | **never `double`** — R6 |
| Flag | `Boolean` | |
| Date / DateTime / Time | `Date` (+ explicit TZ) | preserve Date vs DateTime vs Time distinction |
| TimeSpan | ISO-8601 `Duration` | |
| Password | **vault reference, not a variable** | PII path; withheld from any emitted value |
| Binary / Image | `bytes` / file ref | |
| Collection | JSON object / `List<Map>` | model the current-row pointer for loops |

---

## 7. Validation (the four gates, in the order they run)

1. **Structural / lint** — `python tools/bpmn_lint.py <dir or .bpmn>`: naming
   (`NAME-*`), structure (`STRUCT-*`), exceptions (`EXC-*`), logging (`LOG-HTTL`),
   data (`DATA-*`), code (`CODE-*`), layout (`LAYOUT-*`), bounded loops
   (`LOOP-BOUNDED`, SCC-based). Every rule is a line of the bank's Blue Prism
   coding standard translated (modelling-rules.md). Training release: 0 ERROR.
2. **Equivalence** — `python port/bp_equiv.py --objects <export>`: source vs
   emitted counts per category, verdict OK / PARTIAL / LOST / DESIGN / BUG.
   DESIGN is a documented loss; LOST or BUG is work. GK pack: 0 LOST.
3. **Runtime** — `python tools/c7_runtime_check.py`: deploys to a stock Camunda 7
   (7.24 in docker here, the Fluxnova Modeler app on the laptop via `--url`) and
   runs the round trip. Because Fluxnova retains `CAMUNDA_NS`, a `--ns camunda`
   file deploys unmodified; delivery is re-emitted `fluxnova:`. This is the gate
   that caught what offline checks could not: a conditioned flow on a
   single-outflow gateway, a loop collection in BP syntax (`ENGINE-02025` at run
   time, deploys fine), multi-instance without a collection, XSD element order.
4. **Slot ports** — `tools/slot_oracle.py` (compiles the ORIGINAL C# with
   `csc.exe`/`mcs`, runs the cases → `expected.json`) + `tools/slot_check.py`
   (runs the candidate JS in the slot's shape on the engine, compares). A slot is
   ported when the original's I/O replays, not when it looks right.

Plus the standing ones: XSD validity, every stage classified
converted / stubbed / blocked with a reason (the stage-ledger discipline).

---

## 8. Open items (as of 2026-10-21, after nesting)

- **Partial overlaps.** Regions nest by set containment; a Block whose rectangle
  cuts a loop in half (neither contains the other) is not a structure BPMN can
  express. Such a region is left flat, and the page's first documentation line
  names it (`regions left flat (partial overlap, not nestable): …`). Nested
  regions themselves are modelled since 2026-10-21.
- **Native patterns for internal VBOs** (§2a: vault reference, distributed lock,
  queue-item status as idempotency guard) are design; today they are external
  tasks whose worker carries R8/R14.
- **Clean Up pages** are not modelled; the re-hosting worker owns release-on-exit.
- **Human steps** are not auto-detected (`userTask` by hand, R9).
- **DMN** for decision-heavy Choices: not emitted.
- **Refused functions** (§4) stay manual by choice.
