#!/usr/bin/env python3
"""Blue Prism -> Fluxnova (Camunda 7) BPMN emitter -- SKELETON (Layer 3).

Third layer of the port pipeline. Like bp_full, it `import bp_core` and consumes
the FULL-fidelity parse model (`estate.stages_by_artifact`), NOT estate.json --
estate.json is an estate-level analysis summary and carries no per-stage flow, so
it cannot feed a per-stage emitter. The stage graph (type, links, page_ref,
target_object/action, expression, group_id, exception_type) lives only in the
parse model, which is what this reads.

SCOPE = the "mechanical" (High-confidence) rows of FLUXNOVA-BPMN-MAPPING.md, wired
into a structurally valid, deployable BPMN 2.0 document:

  Start                -> startEvent
  End                  -> endEvent
  Decision             -> exclusiveGateway + JUEL conditions on the true/false flows
  Choice               -> exclusiveGateway          (branch exprs not retained by parser)
  Page reference       -> callActivity              (calledElement -> the page's process)
  Action (VBO call)    -> external serviceTask      (ext:type=external, ext:topic=object.action)
  Calculation          -> scriptTask                (expression translated to JUEL in documentation)
  Data items           -> ext:property metadata on the process
  every intra-page link -> sequenceFlow

BP expressions are translated to Camunda 7 JUEL by a deterministic, curated
transpiler (_juel): [Name] -> variable, comparisons/logic/arithmetic map, and any
function / string-concat / power / collection-field ref HARD-FAILS (kept verbatim
for manual work -- never an invented equivalent). A Decision's condition is emitted
as ${E} / ${!(E)} on its two flows.

MEDIUM pass (control flow) also done:
  Loop (LoopStart/End)        -> sequential multi-instance subProcess (ext:collection)
  Exception throw             -> typed error end event + declared bpmn:error (System/Business)
  Recover with NO Resume      -> error event subProcess (catch-all start -> handler -> re-raise)

Resuming Recovers: the Block becomes an embedded subProcess with an interrupting
error boundary (the Recover); the recovery path leaves the boundary and rejoins at
the Resume. Regions NEST (loop in Block, Block in loop, Block in Block) by set
containment of their stages -- one recursive body emitter renders the page, a loop
body, a Block scope or a handler the same way; a partial overlap is left flat and
named in the page's documentation. Still deferred: DMN; UI stages stay placeholders.
Nothing is silently dropped: a stage is either a typed node, a region composite, a
labelled placeholder, or a declared non-flow type (Data/Collection/Block/Note/...).

Namespace: the vendor-extension namespace is behind ONE constant (EXT). Default is
`fluxnova:` (target-native); `--ns camunda` emits the compat namespace Fluxnova
also accepts, which is what lets the output deploy to a plain local Camunda 7 "Run"
jar for validation before Fluxnova is reachable.

Cross-the-gap contract (same as bp_core / bp_full): `python bp_emit.py --selftest`
reproduces baked-in golden hashes over an embedded synthetic fixture AND asserts
every emitted document is well-formed XML. SELFTEST PASS == this copy is
faithful. The embedded fixtures are synthetic test data, never bank IP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

# make the sibling bundles/tools importable from any working directory
import sys as _sys
from pathlib import Path as _Path
_ROOT = _Path(__file__).resolve().parent
for _d in (_ROOT, _ROOT.parent, _ROOT / "port", _ROOT / "tools", _ROOT.parent / "port", _ROOT.parent / "tools"):
    if _d.is_dir() and str(_d) not in _sys.path:
        _sys.path.insert(0, str(_d))
import bp_core
from bp_core import Estate, parse_paths

# --------------------------------------------------------------------------- #
# Target conventions (locked from finos/fluxnova-bpm-platform, 2026-08-13)
# --------------------------------------------------------------------------- #
BPMN_NS = "http://www.omg.org/spec/BPMN/20100524/MODEL"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
EXT_NS = {
    "fluxnova": "http://fluxnova.finos.org/schema/1.0/bpmn",
    "camunda": "http://camunda.org/schema/1.0/bpmn",
}
TARGET_NS = "http://bank.example/bp-migration"
# Diagram interchange (so Cockpit / bpmn-js can render the flow).
BPMNDI_NS = "http://www.omg.org/spec/BPMN/20100524/DI"
DC_NS = "http://www.omg.org/spec/DD/20100524/DC"
DI_NS = "http://www.omg.org/spec/DD/20100524/DI"
LAYOUT_SCALE = 2.5  # (legacy, unused since the grid layout) BP grid is 15 units; LINKED stages sit 45-75 apart. At 2.5 a
                    # 45-unit gap is 112px against an 80px node -- clear. (1.6 overlapped.)

# Stage types that are NOT control flow -- never become a node, never a flow
# endpoint. Data/Collection are data; Block is a geometric scope (handled by the
# exception pass); Note/SubSheet/SubSheetInfo/ProcessInfo are structure/metadata.
# NB: type "SubSheet" is a page CALL (carries <processid> -> callActivity), NOT a
# non-flow marker; "SubSheetInfo" is the non-flow page marker.
NON_FLOW = {
    "Data", "Collection", "Note", "Block",
    "SubSheetInfo", "ProcessInfo",
    "Anchor",          # a diagram waypoint, dissolved by _dissolve_pass_through
    "ChoiceEnd",       # the Choice bracket's "otherwise" exit, dissolved likewise
}
START_TYPES = {"Start"}
END_TYPES = {"End"}
GATEWAY_TYPES = {"Decision", "Choice", "ChoiceStart",
                 "WaitStart"}   # condition-met vs timeout: exclusive, not a fork
CALC_TYPES = {"Calculation", "MultipleCalculation", "Calc", "MultiCalc"}
MAIN_PAGE = "Main Page"


# --------------------------------------------------------------------------- #
# id / name helpers
# --------------------------------------------------------------------------- #
def _nc(prefix: str, raw: str) -> str:
    """A stable XML NCName. BP ids are GUIDs and names contain spaces/punctuation;
    both must become valid, collision-free BPMN ids. The prefix guarantees a
    letter start; the hash tail guarantees uniqueness even if two raw values
    sanitize to the same slug."""
    slug = re.sub(r"[^A-Za-z0-9_]", "_", raw)[:40]
    tail = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:8]
    return f"{prefix}_{slug}_{tail}"


def _topic(obj: str | None, action: str | None) -> str:
    o = re.sub(r"\s+", "-", (obj or "unknown").strip()).lower()
    a = re.sub(r"\s+", "-", (action or "call").strip()).lower()
    return f"{o}.{a}"


def _attrs(d: dict[str, str]) -> str:
    return "".join(f" {k}={quoteattr(v)}" for k, v in d.items() if v is not None)


# VBO tier heuristic -- self-contained mirror of data/vbo_registry.yaml (the
# target machine has no config file). Internal engine VBOs map to NATIVE
# Fluxnova/Camunda features; shipped VBOs map to CONNECTORs; everything else is
# a CUSTOM re-host (a real API or UI-automation replacement -- the actual work).
def _vbo_tier(obj: str | None) -> str:
    o = (obj or "").strip().lower()
    if (o.startswith("blueprism.") or o.startswith("internal - ")
            or "environment locking" in o or "clsworkqueues" in o
            or "clscredentials" in o or "clscalendars" in o
            or "clsenvironmentlocking" in o or "clscollection" in o):
        return "native"
    if (o.startswith("utility - ") or o.startswith("ms ") or o.startswith("data - ")
            or "excel" in o or "outlook" in o or "email" in o):
        return "connector"
    return "rehost"


_TIER_NOTE = {
    "native": "internal engine VBO -> a Fluxnova/Camunda feature (queue/credential/lock/calendar); no external worker needed",
    "connector": "shipped VBO -> an existing connector/library (Excel, email, DB, string/collection utils)",
    "rehost": "custom VBO -> needs a real API or UI-automation replacement (the actual migration cost)",
}


def _is_terminal(stage) -> bool:
    """A stage that renders as a BPMN endEvent (a normal End, or an Exception
    throw -> error end). Such a node must NEVER get an outgoing sequence flow --
    real BP exports do carry stray links out of these, which is illegal BPMN."""
    t = stage.type or ""
    return t in END_TYPES or stage.exception_type is not None or t.startswith("Exception")


# --------------------------------------------------------------------------- #
# BP expression -> Camunda 7 JUEL transpiler (deterministic, curated, hard-fail)
# --------------------------------------------------------------------------- #
# NEVER invent an equivalent: an unknown function / operator / identifier fails
# translation and the expression is kept verbatim for manual work (mapping doc §4).
_JUEL_CMP = {"<>": "!=", "=": "==", "<=": "<=", ">=": ">=", "<": "<", ">": ">"}
_JUEL_KW = {"and": "&&", "or": "||", "not": "!", "true": "true", "false": "false", "mod": "%"}
_JUEL_TOKEN = re.compile(r"""
      (?P<ws>\s+)
    | (?P<var>\[[^\]]*\])
    | (?P<str>"(?:[^"]|"")*")
    | (?P<num>\d+\.?\d*)
    | (?P<cmp><>|<=|>=|=|<|>)
    | (?P<op>[-+*/()])
    | (?P<amp>&)
    | (?P<pow>\^)
    | (?P<word>[A-Za-z_][A-Za-z0-9_]*)
    | (?P<other>.)
""", re.VERBOSE)


def _juel_str(s: str) -> str:
    return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"


# Blue Prism function -> JUEL. Curated and RUNTIME-VERIFIED against Camunda 7:
# every template below was executed on a real engine, including the index cases.
# BP is 1-BASED and returns 0 for "not found"; Java is 0-based and returns -1, so
# Mid/Left/InStr carry explicit offsets. A function NOT in this map still
# hard-fails -- an unverified guess is worse than an honest TODO.
_JUEL_FUNCS = {
    # The catching side binds the BPMN error's code/message to these two
    # variables (errorCodeVariable / errorMessageVariable on every Recover).
    ("exceptiontype", 0): "(bpErrorCode == 'BP_BUSINESS' ? 'Business Exception' : 'System Exception')",
    ("exceptiondetail", 0): "bpErrorMessage",
    ("trim", 1): "{0}.trim()",
    ("upper", 1): "{0}.toUpperCase()",
    ("lower", 1): "{0}.toLowerCase()",
    ("len", 1): "{0}.length()",
    ("length", 1): "{0}.length()",
    ("startswith", 2): "{0}.startsWith({1})",
    ("endswith", 2): "{0}.endsWith({1})",
    ("left", 2): "{0}.substring(0, {1})",
    ("right", 2): "{0}.substring({0}.length() - ({1}))",
    ("mid", 3): "{0}.substring({1} - 1, {1} - 1 + {2})",
    ("instr", 2): "({0}.indexOf({1}) + 1)",
    ("and", 2): "({0} && {1})",
    ("or", 2): "({0} || {1})",
    ("not", 1): "(!({0}))",
    ("replace", 3): "{0}.replace({1}, {2})",
}


def _split_args(text: str) -> list[str]:
    """Split a function argument list on TOP-LEVEL commas only (a nested call or
    a quoted comma must not split)."""
    args, depth, cur, in_str = [], 0, [], False
    for ch in text:
        if ch == '"':
            in_str = not in_str
        if not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "," and depth == 0:
                args.append("".join(cur))
                cur = []
                continue
        cur.append(ch)
    if "".join(cur).strip():
        args.append("".join(cur))
    return args


def _match_paren(expr: str, open_at: int) -> int:
    """Index of the ')' matching the '(' at open_at, or -1."""
    depth, in_str = 0, False
    for i in range(open_at, len(expr)):
        ch = expr[i]
        if ch == '"':
            in_str = not in_str
        elif not in_str:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return i
    return -1


def _juel(expr: str | None) -> tuple[bool, str]:
    """Translate a Blue Prism expression to a JUEL body (no ${} wrapper), or
    (False, reason). Bracketed [Name] -> a variable (bare when identifier-safe,
    else execution.getVariable('Name')); comparisons/logic/arithmetic map; string
    concat (&), power (^), collection-field refs, and ANY function are hard-fails."""
    if not expr or not expr.strip():
        return False, "empty expression"
    toks = list(_JUEL_TOKEN.finditer(expr))
    out: list[str] = []
    skip_to = -1
    amp_depth = 0          # open parens owed by ").concat(" rewrites
    for i, m in enumerate(toks):
        if m.start() < skip_to:
            continue
        kind, val = m.lastgroup, m.group()
        if kind == "ws":
            out.append(" ")
        elif kind == "var":
            name = val[1:-1].strip()
            if not name:
                return False, "empty variable ref []"
            if "." in name:
                # [Coll.Field] reads a field of the collection's CURRENT ROW.
                # Convention: the current row of collection C is the variable
                # "C#row" -- a loop over C sets it (elementVariable), and a
                # worker implementing a BP collection action must maintain it.
                coll, fld = (x.strip() for x in name.split(".", 1))
                if not coll or not fld or "." in fld:
                    return False, f"collection/field ref [{name}]"
                out.append(f"execution.getVariable({_juel_str(coll + '#row')})[{_juel_str(fld)}]")
                continue
            out.append(name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name)
                       else f"execution.getVariable({_juel_str(name)})")
        elif kind == "str":
            out.append(_juel_str(val[1:-1].replace('""', '"')))
        elif kind == "num":
            out.append(val)
        elif kind == "cmp":
            out.append(_JUEL_CMP[val])
        elif kind == "op":
            out.append(val)
        elif kind == "amp":
            # Blue Prism concatenates with &. JUEL has no string + operator, but
            # String.concat() is exact and was verified on the engine.
            out.append(").concat(")
            amp_depth += 1
        elif kind == "pow":
            return False, "power operator (^)"
        elif kind == "word":
            nxt = next((t for t in toks[i + 1:] if t.lastgroup != "ws"), None)
            if nxt is not None and nxt.group() == "(":
                close = _match_paren(expr, nxt.start())
                if close < 0:
                    return False, f"unbalanced parentheses after '{val}'"
                raw_args = _split_args(expr[nxt.start() + 1:close])
                tmpl = _JUEL_FUNCS.get((val.lower(), len(raw_args)))
                if tmpl is None:
                    return False, f"unsupported function '{val}'"
                done = []
                for a in raw_args:
                    ok_a, res_a = _juel(a)
                    if not ok_a:
                        return False, f"in {val}(): {res_a}"
                    done.append("(" + res_a + ")" if any(
                        c in res_a for c in "+-*/&|<>=") else res_a)
                out.append(tmpl.format(*done))
                skip_to = close + 1
                continue
            low = val.lower()
            if low in _JUEL_KW:
                out.append(_JUEL_KW[low])
            else:
                return False, f"unknown identifier '{val}'"
        else:  # "other"
            return False, f"unexpected token '{val}'"
    result = "".join(out).strip()
    if amp_depth:
        # a & b  ->  (a).concat(b) : one wrapping paren per rewrite
        result = "(" * amp_depth + result + ")" * amp_depth
    return (True, result) if result else (False, "empty after translation")


def _varref(name: str) -> str:
    """A JUEL reference to a variable. A Blue Prism name often contains spaces,
    which cannot appear bare in an expression -- those go through
    execution.getVariable(). Never invent a sanitized name: the variable really
    is called "Queue Name"."""
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name or ""):
        return "${" + name + "}"
    return "${execution.getVariable(" + _juel_str(name) + ")}"


# --------------------------------------------------------------------------- #
# per-stage classification -> (bpmn tag, attributes, inner xml)
# --------------------------------------------------------------------------- #
# Typed BP errors -> declared bpmn:error definitions (System vs Business must map
# to distinct error codes so a handler can discriminate).
_ERRORS = {
    "business": ("Err_Business", "BusinessException", "BP_BUSINESS"),
    "system": ("Err_System", "SystemException", "BP_SYSTEM"),
}


def _CATCH_VARS(extpfx: str) -> dict:
    """Every Recover binds the caught error's code and message to the variables
    ExceptionType() / ExceptionDetail() translate to (see _JUEL_FUNCS)."""
    return {f"{extpfx}:errorCodeVariable": "bpErrorCode",
            f"{extpfx}:errorMessageVariable": "bpErrorMessage"}


def _err_kind(exc_type: str | None) -> str:
    return "business" if exc_type and "business" in exc_type.lower() else "system"


def _io_params(stage, extpfx: str) -> tuple[list[str], list[str]]:
    """inputParameter / outputParameter elements for a stage's inputs (BP
    expressions -> JUEL) and outputs (bind the returned value to the Data stage
    that captured it). Untranslatable inputs come back as notes, never guessed."""
    params, notes = [], []
    for pname, expr in sorted(stage.inputs.items()):
        ok, res = _juel(expr) if expr else (False, "empty")
        if ok:
            params.append(f"<{extpfx}:inputParameter{_attrs({'name': pname})}>"
                          f"{escape('${' + res + '}')}</{extpfx}:inputParameter>")
        else:
            notes.append(f"in {pname} = {expr} (manual: {res})")
    for oname, target in sorted(stage.outputs.items()):
        if target:
            params.append(f"<{extpfx}:outputParameter{_attrs({'name': target})}>"
                          f"{escape(_varref(oname))}</{extpfx}:outputParameter>")
    return params, notes


def _io_block(params: list[str], extpfx: str) -> str:
    if not params:
        return ""
    return (f"<bpmn:extensionElements><{extpfx}:inputOutput>" + "".join(params)
            + f"</{extpfx}:inputOutput></bpmn:extensionElements>")


def _node(stage, extpfx: str, page_pid: dict[tuple, str], artifact: str,
          used_errors: set, default_fid: str | None = None) -> dict | None:
    """Return the BPMN node spec for a flow stage, or None if it is not a node.
    Attribute-driven dispatch (robust to BP type-string variance): the presence
    of page_ref / target_object / expression is more reliable than the label."""
    t = stage.type or ""
    if t in NON_FLOW:
        return None

    name = stage.name or t
    doc = None

    if t in START_TYPES:
        return {"tag": "startEvent", "attrs": {}, "inner": ""}
    if t in END_TYPES:
        return {"tag": "endEvent", "attrs": {}, "inner": ""}

    # Throw (Exception stage) -> typed error end event + a declared bpmn:error.
    if stage.exception_type is not None or t.startswith("Exception"):
        kind = _err_kind(stage.exception_type)
        _ref, ename, code = _ERRORS[kind]
        # One bpmn:error PER THROW so the BP detail expression travels with it
        # (ext:errorMessage) and the catching Recover sees it as bpErrorMessage.
        # The error CODE stays the shared System/Business code, so a handler
        # still discriminates the two kinds.
        ok, res = _juel(stage.exception_detail) if stage.exception_detail else (False, "no detail")
        msg = "${" + res + "}" if ok else None
        eid = _nc("Err", stage.id)
        used_errors.add(("throw", eid, f"{ename}: {name}", code, msg))
        doc = f"BP throw: {stage.exception_type or 'Exception'} - {stage.exception_detail or ''}".strip()
        if not ok and stage.exception_detail:
            doc += f" (detail not translated: {res})"
        # documentation MUST precede eventDefinition (BPMN XSD child order).
        inner = _doc(doc) + f"<bpmn:errorEventDefinition{_attrs({'errorRef': eid})}/>"
        return {"tag": "endEvent", "attrs": {}, "inner": inner, "name": f"Throw: {ename}"}


    # Page reference -> call activity into that page's process.
    if stage.page_ref is not None:
        return _call_node(stage, extpfx, page_pid, artifact, artifact, stage.page_ref, None)

    # Action on an object that is IN the export -> call activity into that
    # object's action page: it is a page like any other, so it converts like one.
    if stage.target_object is not None and stage.target_object in _CTX.get("objects", set()) \
            and (stage.target_object, stage.target_action) in _CTX["iface"]:
        return _call_node(stage, extpfx, page_pid, artifact, stage.target_object, stage.target_action,
                          f"BP action {stage.target_object}.{stage.target_action} -> the object's page")


    # VBO call -> external service task (the re-host seam). Topic = object.action.
    # The VBO tier is stamped into the doc (grep tier=rehost for the real API work),
    # so the 264 Actions split into cheap (native/connector) vs costly (custom
    # re-host) instead of one flat stub pile.
    if stage.target_object is not None:
        tier = _vbo_tier(stage.target_object)
        attrs = {f"{extpfx}:type": "external",
                 f"{extpfx}:topic": _topic(stage.target_object, stage.target_action)}
        # Carry the DATA, not just the topic. Without these the worker knows what
        # to do but not with what. Inputs are BP expressions -> JUEL; outputs bind
        # the action's return value to the Data stage that captured it.
        params, notes = _io_params(stage, extpfx)
        doc = (f"tier={tier}: BP action {stage.target_object}."
               f"{stage.target_action or ''} -- {_TIER_NOTE[tier]}")
        if notes:
            doc += " | " + "; ".join(notes)
        return {"tag": "serviceTask", "attrs": attrs, "inner": _doc(doc) + _io_block(params, extpfx)}

    # Decision / Choice -> exclusive gateway. For a Decision the branch conditions
    # are emitted on the outgoing flows (see _emit_process); here the doc records
    # the translated JUEL or why it needs manual work. Choice branch expressions
    # are not retained by the parser, so they stay a TODO.
    if t in GATEWAY_TYPES:
        if stage.type == "Decision" and stage.expression:
            ok, res = _juel(stage.expression)
            doc = (f"condition: ${{{res}}}" if ok
                   else f"BP condition (manual - {res}): {stage.expression}")
        elif stage.expression:
            doc = f"BP condition (TODO -> JUEL): {stage.expression}"
        # `default` names the flow taken when no condition matches -- the
        # Blue Prism "otherwise". Without it the engine dead-ends instead.
        gw = {"default": default_fid} if default_fid else {}
        if not doc:
            branches = "; ".join(f"{n or f'Choice {i + 1}'}: {e}" for i, (n, e) in
                                 enumerate(zip(stage.choice_names or [""] * len(stage.choice_exprs), stage.choice_exprs)))
            doc = f"BP {t}: " + (branches or name)
        return {"tag": "exclusiveGateway", "attrs": gw, "inner": _doc(doc)}

    # Calculation -> abstract task (NOT scriptTask: Camunda rejects a scriptTask
    # with no script body, and we have no functional assignment to emit -- the
    # parser joins calc exprs and drops the target). Translate for visibility.
    if t in CALC_TYPES or stage.expression is not None:
        # A calculation writes its result to a Data stage. Camunda 7 can do that
        # with an outputParameter -- a REAL assignment, no script body needed
        # (an empty scriptTask is rejected at deploy). Untranslatable steps stay
        # documentation: never invent an equivalent expression.
        parts = (stage.expression or "").split(" ; ")
        params, notes = [], []
        for expr, target in zip(parts, stage.calc_targets):
            ok, res = _juel(expr)
            if ok and target:
                # JUEL uses &&, < and > -- element text MUST be escaped or the
                # document is not well-formed (invalid token at deploy/parse).
                params.append(f"<{extpfx}:outputParameter"
                              f"{_attrs({'name': target})}>{escape('${' + res + '}')}"
                              f"</{extpfx}:outputParameter>")
            else:
                notes.append(f"{target or '?'} = {expr}"
                             + ("" if ok else f"  (manual: {res})"))
        doc = ("BP calc assigns: " + "; ".join(notes)) if notes else "BP calc"
        inner = _doc(doc)
        if params:
            inner += (f"<bpmn:extensionElements><{extpfx}:inputOutput>"
                      + "".join(params)
                      + f"</{extpfx}:inputOutput></bpmn:extensionElements>")
        return {"tag": "task", "attrs": {}, "inner": inner}

    # Code stage = a hard blocker in the mapping -- surface it loudly, never a
    # silent conversion.
    if t == "Code":
        # Say WHAT has to be ported and HOW BIG it is, and point at the extracted
        # source. "Not convertible" on its own is a dead end for whoever picks
        # this up; the code itself is in the export and extract_code.py writes it
        # out as files.
        lang = stage.code_language or "unknown"
        doc = (f"BLOCKER: Blue Prism Code stage -- {stage.code_loc} line(s) of {lang}. "
               f"BPMN cannot express this. The source is in the export: run "
               f"extract_code.py, then see the file for page/stage \"{name}\". "
               f"Port it to a worker on this topic, or replace the whole object if it "
               f"is a shipped VBO.")
        # The code itself is the port's job, but its CONTRACT is known now: the
        # stage's inputs and outputs, mapped either way.
        params, notes = _io_params(stage, extpfx)
        if notes:
            doc += " | " + "; ".join(notes)
        if stage.code_external:
            # Reaches outside the engine (COM, browser, files, OS...) -> stays a
            # worker on this topic, whatever is done with the rest.
            doc += " | outside reach: " + ", ".join(stage.code_external)
            attrs = {f"{extpfx}:type": "external",
                     f"{extpfx}:topic": "code." + _topic(artifact, name)}
            return {"tag": "serviceTask", "attrs": attrs, "inner": _doc(doc) + _io_block(params, extpfx),
                    "name": f"[WORKER code {stage.code_loc}L {lang}] {name}"}
        # Pure logic (data in, data out) -> a script task SLOT: the contract is
        # mapped, the original source rides along, the body throws until a
        # port replaces it. Nothing runs silently wrong; the slot is the unit
        # of work for whoever (or whatever) writes the JavaScript.
        contract = ("PORT SLOT: rewrite the Blue Prism code below as JavaScript. Inputs arrive as "
                    "variables named like the parameters (" + ", ".join(sorted(stage.inputs)) + "); "
                    "set each output with execution.setVariable('<name>', value) for: "
                    + ", ".join(sorted(stage.outputs)) + ". Names with spaces: execution.getVariable('..').")
        src_txt = (stage.code_text or "").strip()
        body = "throw new Error(" + _juel_str(f"TODO port: Code stage '{name}' ({stage.code_loc}L {lang})") + ");"
        inner = (_doc(contract + f"\n--- original {lang} ---\n" + src_txt)
                 + _io_block(params, extpfx)
                 + f"<bpmn:script>{escape(body)}</bpmn:script>")
        return {"tag": "scriptTask", "attrs": {"scriptFormat": "javascript"}, "inner": inner,
                "name": f"[SLOT code {stage.code_loc}L {lang}] {name}"}

    # Everything else with flow (LoopStart/End, Recover, Resume, Wait, Anchor,
    # Navigate, Read, Write, Alert, Skill, ...) -> labelled placeholder task.
    return {"tag": "task", "attrs": {}, "inner": _doc(f"BP stage type: {t} (Medium/Low pass)")}



def _call_node(stage, extpfx, page_pid, artifact, callee_art, callee_page, note) -> dict:
    """callActivity into (callee_art, callee_page) with parameter-by-parameter
    mappings. Used for page calls and for actions on exported objects."""
    if True:
        called = page_pid.get((callee_art, callee_page))
        attrs = {"calledElement": called or _nc("p", callee_page)}
        iface = _CTX["iface"].get((callee_art, callee_page))
        maps, notes = [], [note or f"BP page call -> {callee_page}"]
        own = callee_art == artifact
        if called is None or iface is None:
            # Unresolved page: nothing to map against. Say so; pass everything
            # so the call at least runs, and flag it.
            notes.append(f"TODO calledElement unresolved: page '{callee_page}' -- passing ALL variables")
            maps = [f"<{extpfx}:in variables=\"all\"/>", f"<{extpfx}:out variables=\"all\"/>"]
        else:
            # A page call is a Camunda call activity with ITS OWN variable scope,
            # which is exactly Blue Prism's page-private data. Map the call's
            # inputs onto the Data items the page's Start declares as receivers,
            # and the page's End outputs back onto the caller's capturing items.
            # Process-wide (non-private) items the page touches travel the same
            # way, explicitly, so nothing else of the caller's leaks or is
            # clobbered on the way back (variables="all" did both).
            supplied = set()
            for pname, expr in sorted(stage.inputs.items()):
                tgt = iface["in"].get(pname)
                if tgt is None:
                    notes.append(f"in {pname}: the page declares no such input")
                    continue
                ok, res = _juel(expr) if expr else (False, "empty")
                if ok:
                    maps.append(f"<{extpfx}:in{_attrs({'sourceExpression': '${' + res + '}', 'target': tgt})}/>")
                    supplied.add(pname)
                else:
                    notes.append(f"in {pname} = {expr} (manual: {res})")
            # An input the caller leaves blank arrives in Blue Prism as the
            # type's empty value, not as "no variable" -- pass that default, so
            # the page never trips over an unknown property.
            for pname, tgt in sorted(iface["in"].items()):
                if pname in supplied:
                    continue
                lit = _typed_literal(_CTX.get("dtype", {}).get((callee_art, callee_page, tgt)), None)
                if lit is not None:
                    maps.append(f"<{extpfx}:in{_attrs({'sourceExpression': '${' + lit + '}', 'target': tgt})}/>")
            for g in sorted(iface["reads"] | iface["writes"]):
                maps.append(f"<{extpfx}:in{_attrs({'source': g if own else f'{callee_art}::{g}', 'target': g})}/>")
            for q in sorted(iface["xreads"] | iface["xwrites"]):
                maps.append(f"<{extpfx}:in{_attrs({'source': q, 'target': q})}/>")
            for oname, caller_tgt in sorted(stage.outputs.items()):
                src = iface["out"].get(oname)
                if src is None:
                    notes.append(f"out {oname}: the page declares no such output")
                    continue
                maps.append(f"<{extpfx}:out{_attrs({'source': src, 'target': caller_tgt})}/>")
            for g in sorted(iface["writes"]):
                maps.append(f"<{extpfx}:out{_attrs({'source': g, 'target': g if own else f'{callee_art}::{g}'})}/>")
            for q in sorted(iface["xwrites"]):
                maps.append(f"<{extpfx}:out{_attrs({'source': q, 'target': q})}/>")
        # documentation MUST precede extensionElements (BPMN XSD child order).
        inner = (_doc(" | ".join(notes)) if notes else "") \
            + ("<bpmn:extensionElements>" + "".join(maps) + "</bpmn:extensionElements>" if maps else "")
        return {"tag": "callActivity", "attrs": attrs, "inner": inner}


def _doc(text: str | None) -> str:
    if not text:
        return ""
    return f"<bpmn:documentation>{escape(text)}</bpmn:documentation>"


def _leaf(stage, nid: str, extpfx: str, page_pid: dict[tuple, str],
          artifact: str, used_errors: set,
          default_fid: str | None = None) -> tuple[str, str] | None:
    """Render one leaf stage as a BPMN element string, or None if it is not a node."""
    spec = _node(stage, extpfx, page_pid, artifact, used_errors, default_fid)
    if spec is None:
        return None
    nm = spec.get("name", stage.name or stage.type or "")
    attrs = {"id": nid, "name": nm, **spec["attrs"]}
    return f"<bpmn:{spec['tag']}{_attrs(attrs)}>{spec['inner']}</bpmn:{spec['tag']}>", spec["tag"]


def _flowline(src: str, tgt: str, cond=None) -> str:
    """cond: a JUEL condition string, or (condition, name) -- the name is the
    branch label (Yes / No / the choice's name / Otherwise) the diagram shows."""
    fid = _nc("f", src + "__" + tgt)
    name = None
    if isinstance(cond, tuple):
        cond, name = cond
    inner = ""
    if cond:
        inner = f'<bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">{escape(cond)}</bpmn:conditionExpression>'
    return f'<bpmn:sequenceFlow{_attrs({"id": fid, "name": name, "sourceRef": src, "targetRef": tgt})}>{inner}</bpmn:sequenceFlow>'


# --------------------------------------------------------------------------- #
# region detection (reuses bp_core's exact membership primitives)
# --------------------------------------------------------------------------- #
def _emit_flows(triples) -> list[str]:
    """Render sequence flows, dropping a condition from any source that ends up
    with only ONE outgoing flow. Camunda rejects a conditioned flow on a gateway
    that does not actually branch -- which happens when two branches collapse
    onto the same outer node (a region composite, or a shared target)."""
    out_count: dict[str, int] = {}
    for src, _tgt, _cond in triples:
        out_count[src] = out_count.get(src, 0) + 1
    def keep(src, cond):
        if out_count[src] > 1:
            return cond
        # single outflow: drop the condition, keep the label
        return (None, cond[1]) if isinstance(cond, tuple) else None
    return [_flowline(src, tgt, keep(src, cond)) for src, tgt, cond in triples]


def _page_regions(stages, by_id, page_ids):
    """Loops (LoopStart/End brackets) and Recovers, with member ids, mirroring
    bp_core.run(). Loop body = forward-reach from LoopStart stopping at LoopEnd;
    recover region = forward-reach from Recover stopping at a Resume."""
    ends_by_group = {s.group_id: s for s in stages if s.type == "LoopEnd" and s.group_id}
    loops = []
    for ls in stages:
        if ls.type != "LoopStart":
            continue
        le = ends_by_group.get(ls.group_id) if ls.group_id else None
        if le is None or not le.id:
            continue  # unresolved bracket -> falls through to a flat placeholder
        body = set(bp_core._reach(ls.links, by_id, page_ids, stop_ids={le.id}))
        # A page End is a PAGE terminator, never part of the loop body. Absorbing
        # it made LoopEnd -> End a self-flow on the composite, so the loop ended
        # up with no exit at all and the End node was left orphaned.
        body -= {sid for sid in body
                 if sid in by_id and by_id[sid].type in END_TYPES}
        loops.append({"ls": ls, "le": le, "body": body, "collection": ls.loop_data})
    recovers = []
    for rc in stages:
        if rc.type != "Recover":
            continue
        region = set(bp_core._reach(rc.links, by_id, page_ids, stop_types=("Resume",)))
        resumes = any(by_id[i].type == "Resume" for i in region if i in by_id)
        recovers.append({"rc": rc, "region": region, "resumes": resumes})
    return loops, recovers


# A condition the transpiler could not translate. It deploys, and the engine
# raises "Unknown property" the first time it is evaluated -- loud, never a
# silent misroute. The gateway's documentation carries the original expression.
MANUAL_CONDITION = "${TODO_manual_condition}"


def _gateway_conditions(stages) -> dict[tuple, str]:
    """Per-page map (src_id, tgt_id) -> JUEL condition for exclusive-gateway splits.
    A translatable Decision gets ${E}/${!(E)} on its true/false flows; any other
    split (Choice, or a Decision whose JUEL failed) gets ${true} PLACEHOLDERS so it
    deploys (Camunda rejects unconditioned XOR flows) -- routing is a TODO."""
    fc: dict[tuple, str] = {}
    defaults: dict[str, str] = {}      # gateway stage id -> its "otherwise" target
    for s in stages:
        if s.type not in GATEWAY_TYPES or len(s.links) < 2:
            continue
        # A Blue Prism Choice is an ordered if / else-if / else: branches are
        # evaluated top-to-bottom and the FIRST match wins. A BPMN exclusive
        # gateway has no ordering, so a raw copy of each condition routes
        # differently whenever two are true. Preserve the semantics by chaining
        # the negations, and make the LAST branch the gateway's default so the
        # engine can never dead-end (ENGINE-02001) where Blue Prism fell through.
        if s.type in ("ChoiceStart", "WaitStart") and s.choice_exprs:
            prior: list[str] = []
            last = s.links[-1] if s.links else None
            for i, t in enumerate(s.links):
                if t == last:
                    defaults[s.id] = t          # the else branch: no condition
                    continue
                expr = s.choice_exprs[i] if i < len(s.choice_exprs) else ""
                ok, res = _juel(expr) if expr else (False, "no condition")
                label = (s.choice_names[i] if i < len(s.choice_names) and s.choice_names[i]
                         else f"Choice {i + 1}")
                if ok:
                    guard = "".join(f"!({p}) && " for p in prior) + f"({res})"
                    fc[(s.id, t)] = ("${" + guard + "}", label)
                    prior.append(res)
                else:
                    fc[(s.id, t)] = (MANUAL_CONDITION, label)
            if last is not None:
                fc[(s.id, last)] = (None, "Time Out" if s.type == "WaitStart" else "Otherwise")
            continue
        ok, res = (_juel(s.expression) if s.type == "Decision" and s.expression else (False, ""))
        if ok:
            fc[(s.id, s.links[0])] = ("${" + res + "}", "Yes")
            fc[(s.id, s.links[1])] = ("${!(" + res + ")}", "No")
        elif len(s.links) >= 2:
            # Two ${true} branches would route SILENTLY down the first one. The
            # true-branch gets an unresolvable placeholder (an incident at
            # runtime, which is the honest outcome) and the false-branch is the
            # default so the model still deploys.
            fc[(s.id, s.links[0])] = (MANUAL_CONDITION, "Yes")
            fc[(s.id, s.links[1])] = (None, "No")
            defaults[s.id] = s.links[1]
        else:
            for t in s.links:
                fc[(s.id, t)] = "${true}"
    return fc, defaults


def _tag_of(node_xmls: list[str], nid: str) -> str:
    """the BPMN tag of an already-rendered node element (for its DI size)"""
    for x in node_xmls:
        if f'id="{nid}"' in x:
            m = re.match(r"\s*<bpmn:(\w+)", x)
            if m:
                return m.group(1)
    return "task"


# --------------------------------------------------------------------------- #
# structured regions, NESTED: loops, Block+Recover scopes, escaping Recovers
# --------------------------------------------------------------------------- #
# Every region is a dict: kind ("loop" | "sese" | "evsub"), the anchor stages,
# `claim` = every stage id it owns (children included), `children` = regions
# nested inside it. Regions nest by set containment of their claims; a partial
# overlap (neither contains the other) is not a structure BPMN can express, so
# the lower-priority region is dropped and its stages stay flat -- an honest
# placeholder beats a wrong nesting. One recursive body emitter renders the
# page, a loop body, a Block scope or a handler the same way.
_REGION_RANK = {"sese": 0, "loop": 1, "evsub": 2}   # outer-most first on equal claims


def _region_tree(stages, by_id, page_ids):
    loops, recovers = _page_regions(stages, by_id, page_ids)
    blocks = [s for s in stages if s.type == "Block"]
    regs: list[dict] = []
    for lp in loops:
        regs.append({"kind": "loop", "key": lp["ls"].id, "ls": lp["ls"], "le": lp["le"],
                     "collection": lp["collection"],
                     "claim": set(lp["body"]) | {lp["ls"].id, lp["le"].id}, "children": []})
    hosted: list[dict] = []     # recovers whose try scope decides where they live
    for r in recovers:
        rc = r["rc"]
        blk = bp_core._enclosing_block(rc, blocks)
        scope = set()
        if blk is not None:
            # The handler path is never part of the TRY scope, whatever the
            # rectangle says: a boundary that flows back into its own subProcess
            # is a cycle, not a catch.
            scope = {s.id for s in stages
                     if s.id and s is not blk and s.id != rc.id
                     and s.type not in END_TYPES and bp_core._contains(blk, s)} - r["region"]
        if r["resumes"]:
            if blk is None or not scope:
                continue        # page-scope resuming Recover: stays a placeholder leaf
            reg = {"kind": "sese", "key": blk.id, "blk": blk, "rc": rc, "members": scope,
                   "claim": scope | {rc.id}, "children": []}
        else:
            reg = {"kind": "evsub", "key": rc.id, "rc": rc, "region": set(r["region"]),
                   "claim": set(r["region"]) | {rc.id}, "children": []}
        reg["scope"] = scope
        reg["handler"] = set(r["region"])
        regs.append(reg)
        hosted.append(reg)
    # A Recover belongs where its try scope is: a loop whose body holds the
    # scope also holds the Recover, its handler path and the Resume (which links
    # back to the LoopEnd). Without this the handler would sit outside the loop
    # and the scope inside -- a partial overlap, i.e. the old orphan.
    # The scope must sit STRICTLY inside the body: a Block drawn around the
    # brackets themselves is the outer try { for-each } and nests the other way.
    changed = True
    while changed:
        changed = False
        for lp in (x for x in regs if x["kind"] == "loop"):
            brackets = {lp["ls"].id, lp["le"].id}
            for h in hosted:
                if (h["scope"] and h["scope"] <= lp["claim"] and not (h["scope"] & brackets)
                        and not (h["claim"] | h["handler"]) <= lp["claim"]):
                    lp["claim"] |= h["claim"] | h["handler"]
                    changed = True

    def contains(outer, inner) -> bool:
        if outer is inner:
            return False
        if inner["claim"] < outer["claim"]:
            return True
        if inner["claim"] == outer["claim"]:
            ro, ri = _REGION_RANK[outer["kind"]], _REGION_RANK[inner["kind"]]
            return (ro, outer["key"]) < (ri, inner["key"])
        return False

    accepted: list[dict] = []
    dropped: list[dict] = []
    for r in sorted(regs, key=lambda x: (-len(x["claim"]), _REGION_RANK[x["kind"]], x["key"])):
        if any((r["claim"] & a["claim"]) and not contains(a, r) and not contains(r, a) for a in accepted):
            dropped.append(r)
            continue
        accepted.append(r)
    roots: list[dict] = []
    for r in accepted:
        parents = [a for a in accepted if contains(a, r)]
        if parents:
            min(parents, key=lambda x: len(x["claim"]))["children"].append(r)
        else:
            roots.append(r)
    return roots, dropped


def _loop_lead(collection, extpfx):
    """multiInstance characteristics (or an honest TODO) for a loop composite."""
    var = None
    if collection:
        # Real exports write <loopdata> as the bare name ("Files"), the training
        # release as "[Files]" -- accept both; a field ref or a function is left
        # unresolved rather than guessed (ENGINE-02025 at runtime otherwise).
        m = re.fullmatch(r"\s*\[?([^\]\[.()]+)\]?\s*", collection)
        if m:
            var = m.group(1).strip()
    if var:
        return "", (f'<bpmn:multiInstanceLoopCharacteristics'
                    f'{_attrs({"isSequential": "true", f"{extpfx}:collection": var, f"{extpfx}:elementVariable": var + "#row"})}/>')
    # Camunda rejects loopCharacteristics without a collection or cardinality;
    # a plain subProcess plus a TODO deploys and keeps the body. documentation
    # MUST be the first child (XSD order).
    return _doc(f"TODO loop runs ONCE: collection unresolved: {collection}" if collection
                else "TODO loop runs ONCE: collection unresolved"), ""


def _emit_body(container, ids, children, ctx, synthetic=None, special=None,
               insert_after=None, dangling_to_end=False):
    """Render the stages `ids` (children's claims included) as the content of
    `container` (None = the page). Child regions become composite nodes; every
    stage id maps to the OUTER node it belongs to, so flows between a region's
    inside and outside land on the composite for free.

    synthetic: (start_id, end_id) of a region's own events; links leaving `ids`
    (or reaching a page End, which is dropped inside a region) exit to end_id,
    and stages entered from outside are fed from start_id.
    special: stage id -> node id preassigned by the wrapper (LoopStart -> the
    loop's start event, a Recover -> None: its flows are the parent's business).
    insert_after: stage id -> [node ids] spliced after that stage's outflow
    (the page's Init chain).  dangling_to_end: a node with no outgoing flow is
    wired to end_id (an escaping handler re-raises).
    Returns dict(nodes=[xml], nodeid={sid: nid|None}, triples, di_nodes, di_edges)."""
    by_id, extpfx, page_pid, artifact = ctx["by_id"], ctx["extpfx"], ctx["page_pid"], ctx["artifact"]
    used_errors, flow_cond, gw_defaults = ctx["used_errors"], ctx["flow_cond"], ctx["gw_defaults"]
    special = special or {}
    insert_after = insert_after or {}
    start_id, end_id = synthetic if synthetic else (None, None)

    nodes: list[str] = []
    di_nodes: list[tuple] = []
    di_edges: list[tuple] = []
    nodeid: dict[str, str | None] = {}
    claimed: set[str] = set()
    # 1) child regions first: their composite ids are what sibling flows target
    for ch in children:
        xml, cid, bnd, dn, de, anchor = _emit_region(ch, container, ctx)
        nodes.append(xml)
        for sid in ch["claim"]:
            nodeid[sid] = cid
        if ch["kind"] == "sese":
            nodeid[ch["rc"].id] = bnd
        claimed |= ch["claim"]
        di_nodes.append((cid, anchor.x, anchor.y, "subProcess", True, container))
        if bnd:
            di_nodes.append((bnd, ch["rc"].x, ch["rc"].y, "boundaryEvent", False, container, cid))
        di_nodes += dn
        di_edges += de
    # 2) leaves: decide node-ness first (gateway defaults need every target's id)
    specs: dict[str, dict] = {}
    dropped_end: set[str] = set()
    for sid in sorted(ids - claimed):
        if sid in special:
            nodeid[sid] = special[sid]
            continue
        st = by_id.get(sid)
        if st is None:
            continue
        if synthetic and st.type in END_TYPES:
            nodeid[sid] = None          # a page End inside a region: exit to the region's end
            dropped_end.add(sid)
            continue
        spec = _node(st, extpfx, page_pid, artifact, used_errors, None)
        if spec is None:
            nodeid[sid] = None
            continue
        specs[sid] = spec
        nodeid[sid] = _nc("s", sid)

    def target(t):
        """outer node a link to stage `t` lands on, inside this body"""
        if t in nodeid:
            n = nodeid[t]
            if n is None and t in dropped_end:
                return end_id
            return n
        return end_id if synthetic and t in by_id else None

    gw_fid: dict[str, str] = {}
    for src, tgt in gw_defaults.items():
        if src in specs:
            a, b = nodeid[src], target(tgt)
            if a and b and a != b:
                gw_fid[src] = _nc("f", a + "__" + b)
    for sid, spec in specs.items():
        st = by_id[sid]
        if sid in gw_fid:
            spec = _node(st, extpfx, page_pid, artifact, used_errors, gw_fid[sid]) or spec
        nm = spec.get("name", st.name or st.type or "")
        nid = nodeid[sid]
        nodes.append(f"<bpmn:{spec['tag']}{_attrs({'id': nid, 'name': nm, **spec['attrs']})}>{spec['inner']}</bpmn:{spec['tag']}>")
        di_nodes.append((nid, st.x, st.y, spec["tag"], False, container))
    # 3) flows
    triples: list[tuple] = []
    seen: set[tuple] = set()

    no_target = {nodeid[ch["rc"].id] for ch in children if ch["kind"] == "sese"}   # boundary events
    if start_id:
        no_target.add(start_id)

    def add(a, b, cond=None):
        # a boundary or start event can have no incoming flow; a stray Blue
        # Prism link into a Recover is dropped rather than emitted illegally
        if not a or not b or a == b or (a, b) in seen or a == end_id or b in no_target:
            return
        seen.add((a, b))
        triples.append((a, b, cond))

    if synthetic:
        for o in by_id.values():
            if not o.id or o.id in ids:
                continue
            for t in o.links:
                if t in ids:
                    add(start_id, target(t))
    for sid in sorted(ids):
        a = nodeid.get(sid)
        st = by_id.get(sid)
        if not a or st is None or _is_terminal(st):
            continue
        for nid in insert_after.get(sid, []):
            add(a, nid)
            a = nid
        for t in st.links:
            add(a, target(t), flow_cond.get((sid, t)))
    if synthetic:
        has_out = {x for x, _, _ in triples}
        # inner node ids in a stable order: leaves by stage id, composites too
        inner: dict[str, str | None] = {}
        for sid in sorted(ids):
            n = nodeid.get(sid)
            if n and n not in (start_id, end_id) and n not in inner:
                inner[n] = None if sid in claimed else sid
        if start_id not in has_out and inner:
            add(start_id, next(iter(inner)))        # nothing enters from outside: first node is the entry
        # A node with no onward path ends the region (a token may never get
        # stuck inside a scope): a dropped link, a bracket wired into a Recover,
        # an escaping handler's last stage (which then re-raises).
        for n, sid in inner.items():
            if n in has_out or n in no_target:
                continue
            if sid is not None and _is_terminal(by_id[sid]):
                continue                            # an error end / page End already terminates
            if sid is None or dangling_to_end or True:
                add(n, end_id)
    di_edges += [(_nc("f", a + "__" + b), a, b) for a, b, _ in triples]
    return {"nodes": nodes, "nodeid": nodeid, "triples": triples, "di_nodes": di_nodes, "di_edges": di_edges}


def _emit_region(reg, container, ctx):
    """One region -> (xml, composite id, boundary id or None, di_nodes, di_edges, anchor stage)."""
    extpfx = ctx["extpfx"]
    kind = reg["kind"]
    if kind == "loop":
        ls, le = reg["ls"], reg["le"]
        cid = _nc("loop", ls.id)
        sstart, send = cid + "_start", cid + "_end"
        body = _emit_body(cid, reg["claim"], reg["children"], ctx, (sstart, send),
                          special={ls.id: sstart, le.id: send})
        lead, mi = _loop_lead(reg["collection"], extpfx)
        # the region's own end event exists only if something flows into it (a
        # body that always ends in a throw has no normal exit; an unfed end is
        # an orphan the audit rightly flags)
        fed = any(b == send for _, b, _ in body["triples"])
        inner = (lead + mi + f'<bpmn:startEvent id="{sstart}"/>' + "".join(body["nodes"])
                 + (f'<bpmn:endEvent id="{send}"/>' if fed else "") + "".join(_emit_flows(body["triples"])))
        dn = [(sstart, ls.x, ls.y, "startEvent", False, cid)] + ([(send, le.x, le.y, "endEvent", False, cid)] if fed else []) + body["di_nodes"]
        return (f'    <bpmn:subProcess{_attrs({"id": cid, "name": ls.name or "Loop"})}>{inner}</bpmn:subProcess>',
                cid, None, dn, body["di_edges"], ls)
    if kind == "sese":
        blk, rc = reg["blk"], reg["rc"]
        cid = _nc("blk", blk.id)
        bstart, bend = cid + "_start", cid + "_end"
        body = _emit_body(cid, reg["claim"], reg["children"], ctx, (bstart, bend), special={rc.id: None})
        fed = any(b == bend for _, b, _ in body["triples"])
        inner = (f'<bpmn:startEvent id="{bstart}"/>' + "".join(body["nodes"])
                 + (f'<bpmn:endEvent id="{bend}"/>' if fed else "") + "".join(_emit_flows(body["triples"])))
        sub = f'    <bpmn:subProcess{_attrs({"id": cid, "name": blk.name or "Block"})}>{inner}</bpmn:subProcess>'
        bnd = _nc("bnd", rc.id)
        # The Recover itself: an interrupting, catch-all error boundary event.
        boundary = (f'    <bpmn:boundaryEvent{_attrs({"id": bnd, "name": rc.name or "Recover", "attachedToRef": cid, "cancelActivity": "true"})}>'
                    f'<bpmn:errorEventDefinition{_attrs(_CATCH_VARS(extpfx))}/></bpmn:boundaryEvent>')
        xs = [n[1] for n in body["di_nodes"] if n[1] is not None]
        ys = [n[2] for n in body["di_nodes"] if n[2] is not None]
        dn = [(bstart, (min(xs) - 30) if xs else blk.x, min(ys) if ys else blk.y, "startEvent", False, cid)] \
             + ([(bend, (max(xs) + 60) if xs else blk.x, max(ys) if ys else blk.y, "endEvent", False, cid)] if fed else []) \
             + body["di_nodes"]
        return sub + chr(10) + boundary, cid, bnd, dn, body["di_edges"], blk
    # evsub: an ESCAPING recover (no Resume) -> error event subProcess:
    # catch-all error start -> the handler flow -> re-raise (error end).
    rc = reg["rc"]
    cid = _nc("evsub", rc.id)
    esid, reraise = _nc("es", rc.id), cid + "_reraise"
    body = _emit_body(cid, reg["claim"], reg["children"], ctx, (esid, reraise),
                      special={rc.id: esid}, dangling_to_end=True)
    nodes = list(body["nodes"])
    reachable = any(b == reraise for _, b, _ in body["triples"])
    if reachable:
        ctx["used_errors"].add("system")
        nodes.append(f'<bpmn:endEvent id="{reraise}" name="Re-raise">'
                     f'<bpmn:errorEventDefinition{_attrs({"errorRef": _ERRORS["system"][0]})}/></bpmn:endEvent>')
    start = (f'<bpmn:startEvent id="{esid}" name="On Exception">'
             f'<bpmn:errorEventDefinition{_attrs(_CATCH_VARS(extpfx))}/></bpmn:startEvent>')
    dn = [(esid, rc.x, rc.y, "startEvent", False, cid)] + body["di_nodes"]
    if reachable:
        ys = [n[2] for n in dn if n[2] is not None]
        dn.append((reraise, rc.x, (max(ys) + 45) if ys else None, "endEvent", False, cid))
    doc = _doc(f"BP Recover without Resume ({rc.name}): catches any exception raised in this scope, "
               f"runs the handler, re-raises as a System Exception")
    xml = (f'    <bpmn:subProcess{_attrs({"id": cid, "name": f"Recover: {rc.name or rc.id}", "triggeredByEvent": "true"})}>'
           f"{doc}{start}{''.join(nodes)}{''.join(_emit_flows(body['triples']))}</bpmn:subProcess>")
    return xml, cid, None, dn, body["di_edges"], rc


# A Blue Prism Anchor carries NO behaviour -- it is a corner point used to route
# a line on the diagram. Emitting it as a task invents work that does not exist
# and clutters the flow, so anchors are DISSOLVED: A -> Anchor -> B becomes A -> B.
PASS_THROUGH = {"Anchor", "ChoiceEnd"}


def _wire_choice_otherwise(stages) -> None:
    """A ChoiceStart's branches link to their targets; its OTHERWISE path is not a
    link at all -- it is the paired ChoiceEnd (same <groupid>), which continues
    via its own <onsuccess>. Without this edge the last real branch was taken as
    the default (its condition dropped) and every ChoiceEnd became an orphan
    gateway. Append the ChoiceEnd as the LAST link, where _gateway_conditions
    expects the default; dissolving ChoiceEnd then lands it on the real target."""
    ends = {st.group_id: st for st in stages if st.type == "ChoiceEnd" and st.group_id}
    for st in stages:
        if st.type == "ChoiceStart" and st.group_id:
            end = ends.get(st.group_id)
            if end is not None and end.id and end.id not in st.links:
                st.links.append(end.id)


def _dissolve_pass_through(stages) -> None:
    """Rewrite links so they skip pass-through stages, following chains. Done in
    place and idempotent -- once anchors are gone from links, a second run is a
    no-op. A cycle of anchors terminates via the `seen` guard."""
    by_id = {s.id: s for s in stages if s.id}

    def follow(sid, seen):
        st = by_id.get(sid)
        if st is None or st.type not in PASS_THROUGH:
            return [sid]
        out = []
        for nxt in st.links:
            if nxt in seen:
                continue
            seen.add(nxt)
            out.extend(follow(nxt, seen))
        return out

    for st in stages:
        if not st.links:
            continue
        resolved = []
        for t in st.links:
            for r in follow(t, {t}):
                if r not in resolved:
                    resolved.append(r)
        st.links = resolved


def _emit_process(est: Estate, artifact: str, page: str, stages: list,
                  page_pid: dict[tuple, str], extpfx: str, used_errors: set) -> str:
    pid = page_pid[(artifact, page)]
    # All page-processes are executable: sub-pages are callActivity targets, and
    # Camunda can only start (hence call) an executable process. The Main Page is
    # the human entry point by convention, not by this flag.
    executable = "true"
    by_id = {s.id: s for s in stages if s.id}
    page_ids = {s.id for s in stages if s.id}
    roots, dropped = _region_tree(stages, by_id, page_ids)
    flow_cond, gw_defaults = _gateway_conditions(stages)  # top level AND inside regions
    ctx = {"by_id": by_id, "extpfx": extpfx, "page_pid": page_pid, "artifact": artifact,
           "used_errors": used_errors, "flow_cond": flow_cond, "gw_defaults": gw_defaults}

    # initial values: Start -> Init -> [Initialise of each used object] -> (what Start linked to)
    init_of: dict[str, list[str]] = {}
    init_xml: list[str] = []
    init_di: list[tuple] = []
    art_type = next((a.type for a in est.artifacts if a.name == artifact), "process")
    for s in stages:
        if s.type not in START_TYPES:
            continue
        chain: list[str] = []
        res = _init_task(est, artifact, page, s, extpfx)
        if res:
            chain.append(res[0])
            init_xml.append("    " + res[1])
        if page == MAIN_PAGE and art_type == "process":
            # Blue Prism runs an object's Initialise page when the object is
            # first loaded; call it up front for every object this process
            # uses (transitively), when that page does anything at all.
            iface = _CTX["iface"].get((artifact, page), {})
            for obj in sorted(iface.get("objs", set())):
                opg = _CTX["iface"].get((obj, MAIN_PAGE))
                if not opg or not opg["logic"]:
                    continue
                fake = bp_core.Stage(id=s.id + "::init::" + obj, name=f"Initialise {obj}", type="SubSheet")
                spec = _call_node(fake, extpfx, page_pid, artifact, obj, MAIN_PAGE,
                                  f"object Initialise page, run once before first use")
                nid = _nc("initobj", artifact + "::" + obj)
                init_xml.append("    " + f"<bpmn:callActivity{_attrs({'id': nid, 'name': fake.name, **spec['attrs']})}>{spec['inner']}</bpmn:callActivity>")
                chain.append(nid)
        if chain:
            init_of[s.id] = chain
            for i, nid in enumerate(chain):
                init_di.append((nid, (s.x or 0) + 45 * (i + 1), s.y, "task", False))

    body = _emit_body(None, page_ids, roots, ctx, None, {}, insert_after=init_of)
    node_xml = ["    " + x if not x.startswith("    ") else x for x in body["nodes"]] + init_xml
    di_nodes = body["di_nodes"] + init_di
    di_edges = body["di_edges"]
    flow_xml = ["    " + f for f in _emit_flows(body["triples"])]
    if dropped:
        # a region BPMN cannot nest (partial overlap): say so on the page
        node_xml.insert(0, "    " + _doc("regions left flat (partial overlap, not nestable): "
                                        + "; ".join(f"{r['kind']} at {r['key']}" for r in dropped)))

    # 4) data items -> ext:property metadata (Number -> decimal note; secrets withheld)
    props = ""
    if page == MAIN_PAGE:
        rows = [d for d in est.data_items if d.artifact == artifact]
        if rows:
            # Blue Prism declares a Data stage PER PAGE, so the same variable name
            # recurs many times across an artifact (var:handle x50 on a real
            # object). Camunda has ONE variable per name, so declare each once and
            # record how many pages declared it; flag a real type conflict.
            seen: dict[str, str] = {}
            counts: dict[str, int] = {}
            for d in rows:
                if d.datatype == "Password":
                    continue
                note = f"{d.datatype}/{d.scope}"
                if d.datatype == "Number":
                    note += " (decimal - never double)"
                counts[d.name] = counts.get(d.name, 0) + 1
                if d.name in seen and seen[d.name] != note:
                    seen[d.name] = seen[d.name] + " | CONFLICT: " + note
                else:
                    seen.setdefault(d.name, note)
            items = []
            for name in sorted(seen):
                note = seen[name]
                if counts[name] > 1:
                    note += f" (declared on {counts[name]} pages)"
                items.append(f'<{extpfx}:property{_attrs({"name": "var:" + name, "value": note})}/>')
            # A Blue Prism Collection is a TABLE with a declared field schema.
            # Camunda has no typed collection, but dropping the schema loses the
            # shape entirely -- record it so a port knows what the rows contain.
            seen_c: set = set()
            for c in est.collections:
                if c.artifact != artifact or c.name in seen_c:
                    continue
                seen_c.add(c.name)
                items.append(f'<{extpfx}:property'
                             f'{_attrs({"name": "collection:" + c.name, "value": ", ".join(c.fields) or "(no declared fields)"})}/>')
            if items:
                props = (f"<bpmn:extensionElements><{extpfx}:properties>"
                         + "".join(items) + f"</{extpfx}:properties></bpmn:extensionElements>")

    body = props + "\n" + "\n".join(node_xml + flow_xml)
    # historyTimeToLive is required at deploy by Camunda 7.20+ (ENGINE-12018).
    proc = (f'  <bpmn:process{_attrs({"id": pid, "name": f"{artifact} / {page}", "isExecutable": executable, f"{extpfx}:historyTimeToLive": "P180D"})}>\n'
            f"{body}\n  </bpmn:process>")
    return proc, _diagram(pid, di_nodes, di_edges)


def _shape_size(tag: str) -> tuple[int, int]:
    if tag in ("startEvent", "endEvent", "boundaryEvent"):
        return (36, 36)
    if tag == "exclusiveGateway":
        return (50, 50)
    return (100, 80)  # task / serviceTask / callActivity / subProcess


def _route(a, b):
    """Orthogonal waypoints between two shape rectangles (x, y, w, h): leave the
    source on the side that faces the target, one bend (or two) in between, enter
    the target on the facing side. A back-edge (target above the source, i.e. a
    loop) is routed around the right of both shapes so it never crosses the flow
    it returns to. Long diagonals are what made real diagrams unreadable."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    acx, acy = ax + aw / 2, ay + ah / 2
    bcx, bcy = bx + bw / 2, by + bh / 2
    pts: list[tuple[float, float]]
    if by >= ay + ah:                                   # target below: exit bottom, enter top
        if abs(bcx - acx) < 1:
            pts = [(acx, ay + ah), (bcx, by)]
        else:
            my = (ay + ah + by) / 2
            pts = [(acx, ay + ah), (acx, my), (bcx, my), (bcx, by)]
    elif by + bh <= ay:                                 # target above: a back-edge, go around the right
        rx = max(ax + aw, bx + bw) + 40
        pts = [(ax + aw, acy), (rx, acy), (rx, bcy), (bx + bw, bcy)]
    elif bx >= ax + aw:                                 # same band, target right
        if abs(bcy - acy) < 1:
            pts = [(ax + aw, acy), (bx, bcy)]
        else:
            mx = (ax + aw + bx) / 2
            pts = [(ax + aw, acy), (mx, acy), (mx, bcy), (bx, bcy)]
    elif bx + bw <= ax:                                 # same band, target left
        if abs(bcy - acy) < 1:
            pts = [(ax, acy), (bx + bw, bcy)]
        else:
            mx = (ax + bx + bw) / 2
            pts = [(ax, acy), (mx, acy), (mx, bcy), (bx + bw, bcy)]
    else:                                               # overlapping bands: straight
        pts = [(acx, acy), (bcx, bcy)]
    return [(round(x), round(y)) for x, y in pts]


# Layout grid. Blue Prism coordinates are kept for ORDER and ALIGNMENT, not for
# distance: stages are snapped to grid cells (one cell = one BP column/row band)
# and the cells are laid out at a fixed pitch, so a page is as compact as its
# number of distinct columns/rows, every lane shares an x (or y) exactly, and
# two shapes can never be closer than the cell gap.
COL_PITCH, ROW_PITCH = 200, 150     # cell size: 100x80 shape + gap (room for nested container padding)
CELL_W, CELL_H = 120, 90            # the band a shape is centred in
BP_CELL = 30                        # BP units merged into one grid band (grid is 15)
MARGIN = 20


def _diagram(pid: str, di_nodes: list, di_edges: list) -> str:
    """A BPMNDI plane for one process: leaves snapped to the grid, composites
    expanded around their children (nested, bottom-up), boundary events on the
    right border of the activity they are attached to, orthogonal edges."""
    leaves = [e for e in di_nodes if not e[4] and e[3] != "boundaryEvent"]
    xs = sorted({round(e[1] / BP_CELL) for e in leaves if e[1] is not None})
    ys = sorted({round(e[2] / BP_CELL) for e in leaves if e[2] is not None})
    col = {k: i for i, k in enumerate(xs)}
    row = {k: i for i, k in enumerate(ys)}
    bounds: dict[str, tuple[int, int, int, int]] = {}
    children: dict[str, list[str]] = {}
    attached: dict[str, str] = {}
    occupied: set[tuple[int, int]] = set()
    fb_r = 0
    for entry in di_nodes:
        nid, x, y, tag, is_sub = entry[:5]
        parent = entry[5] if len(entry) > 5 else None
        if parent:
            children.setdefault(parent, []).append(nid)
        if tag == "boundaryEvent":
            attached[nid] = entry[6] if len(entry) > 6 else None
            continue
        if is_sub:
            continue                      # placed after its children (below)
        w, h = _shape_size(tag)
        if x is None or y is None:        # no BP coordinates: a column past the last one
            c, r = len(xs) + 1, fb_r
            fb_r += 1
        else:
            c, r = col[round(x / BP_CELL)], row[round(y / BP_CELL)]
        while (c, r) in occupied:         # two stages in one band: bump right
            c += 1
        occupied.add((c, r))
        cx = MARGIN + c * COL_PITCH + CELL_W / 2
        cy = MARGIN + r * ROW_PITCH + CELL_H / 2
        bounds[nid] = (round(cx - w / 2), round(cy - h / 2), w, h)
    # composites: expanded around their children's shapes, children before
    # parents so nesting works; a composite with no placed child is collapsed
    PAD = 20                              # per nesting level; 2 levels still clear the lint's 20 px rule
    pending = {e[0]: e for e in di_nodes if e[4]}
    while pending:
        progressed = False
        for nid, entry in list(pending.items()):
            kids_ids = children.get(nid, [])
            if any(k in pending for k in kids_ids):
                continue
            kids = [bounds[k] for k in kids_ids if k in bounds]
            if kids:
                x0 = min(k[0] for k in kids) - PAD
                y0 = min(k[1] for k in kids) - PAD
                x1 = max(k[0] + k[2] for k in kids) + PAD
                y1 = max(k[1] + k[3] for k in kids) + PAD
                bounds[nid] = (x0, y0, x1 - x0, y1 - y0)
            else:
                w, h = _shape_size(entry[3])
                bounds[nid] = (MARGIN + (len(xs) + 1) * COL_PITCH, MARGIN + fb_r * ROW_PITCH, w, h)
                fb_r += 1
            del pending[nid]
            progressed = True
        if not progressed:                # cannot happen (no cycles); never loop forever
            for nid, entry in pending.items():
                w, h = _shape_size(entry[3])
                bounds[nid] = (MARGIN, MARGIN + fb_r * ROW_PITCH, w, h)
                fb_r += 1
            break
    # boundary events: on the right border of their activity, stacked if several
    per_host: dict[str, int] = {}
    for nid, host in attached.items():
        hb = bounds.get(host)
        n = per_host.get(host, 0)
        per_host[host] = n + 1
        if hb is None:
            bounds[nid] = (MARGIN, MARGIN + fb_r * ROW_PITCH, 36, 36)
            fb_r += 1
            continue
        hx, hy, hw, hh = hb
        bounds[nid] = (hx + hw - 18, round(hy + hh / 2 - 18 + n * 40), 36, 36)

    shapes: list[str] = []
    for nid, (bx, by, w, h) in bounds.items():
        is_sub = any(e[0] == nid and e[4] for e in di_nodes)
        exp = (' isExpanded="true"' if children.get(nid) else ' isExpanded="false"') if is_sub else ''
        shapes.append(f'<bpmndi:BPMNShape id="di_{nid}" bpmnElement="{nid}"{exp}>'
                      f'<dc:Bounds x="{bx}" y="{by}" width="{w}" height="{h}"/></bpmndi:BPMNShape>')
    edges: list[str] = []
    for fid, a, b in di_edges:
        if a not in bounds or b not in bounds:
            continue
        pts = _route(bounds[a], bounds[b])
        edges.append(f'<bpmndi:BPMNEdge id="di_{fid}" bpmnElement="{fid}">'
                     + "".join(f'<di:waypoint x="{x}" y="{y}"/>' for x, y in pts)
                     + '</bpmndi:BPMNEdge>')
    return (f'  <bpmndi:BPMNDiagram id="diag_{pid}">'
            f'<bpmndi:BPMNPlane id="plane_{pid}" bpmnElement="{pid}">'
            + "".join(shapes) + "".join(edges)
            + '</bpmndi:BPMNPlane></bpmndi:BPMNDiagram>')


def _emit_definitions(processes: list[str], diagrams: list[str], defid: str,
                      extpfx: str, used_errors: set) -> str:
    extns = EXT_NS[extpfx]
    errors = ""
    for k in sorted(used_errors, key=lambda e: (0, e) if isinstance(e, str) else (1, e[1])):
        if isinstance(e := k, str):
            errors += f'  <bpmn:error{_attrs(dict(zip(("id", "name", "errorCode"), _ERRORS[e])))}/>\n'
        else:
            _tag, eid, ename, code, msg = e
            errors += f'  <bpmn:error{_attrs({"id": eid, "name": ename, "errorCode": code, f"{extpfx}:errorMessage": msg})}/>\n'
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<bpmn:definitions xmlns:bpmn="{BPMN_NS}" xmlns:xsi="{XSI_NS}" '
        f'xmlns:{extpfx}="{extns}" '
        f'xmlns:bpmndi="{BPMNDI_NS}" xmlns:dc="{DC_NS}" xmlns:di="{DI_NS}" '
        f'{_attrs({"id": defid, "targetNamespace": TARGET_NS})}>\n'
        + errors
        + "\n".join(processes) + "\n"
        + "\n".join(diagrams)
        + "\n</bpmn:definitions>\n"
    )


_CTX: dict = {"iface": {}}
_NAME_REF = re.compile(r"\[([^\]]+)\]")


def _names_in(expr: str | None, known: set) -> set:
    """Data item names an expression references ([Name] / [Coll.Field])."""
    out = set()
    for raw in _NAME_REF.findall(expr or ""):
        raw = raw.strip()
        if raw in known:
            out.add(raw)
        elif "." in raw and raw.split(".", 1)[0].strip() in known:
            out.add(raw.split(".", 1)[0].strip())
    return out


def _build_context(est: Estate) -> None:
    """Per (artifact, page): the page's declared inputs (name -> receiving Data
    item), outputs (name -> source Data item), and the process-wide (non-private)
    items it reads / writes -- transitively through the pages it calls."""
    iface: dict = {}
    exported = {a.name for a in est.artifacts if a.type == "object"}
    all_pages: dict = {}
    gitems: dict = {}
    for art in est.artifacts:
        stages = est.stages_by_artifact.get(art.name, [])
        for d in est.data_items:
            if d.artifact == art.name and d.scope == "session":
                gitems.setdefault((art.name, d.name), d)
        known = {d.name for d in est.data_items if d.artifact == art.name} | \
                {c.name for c in est.collections if c.artifact == art.name}
        globs = {d.name for d in est.data_items if d.artifact == art.name and d.scope == "session"} | \
                {c.name for c in est.collections if c.artifact == art.name and c.scope == "session"}
        pages: dict = {}
        for s in stages:
            pg = pages.setdefault(s.subsheet or MAIN_PAGE,
                                  {"in": {}, "out": {}, "reads": set(), "writes": set(), "calls": set(),
                                   "xreads": set(), "xwrites": set(), "acalls": set(), "objs": set(),
                                   "logic": False})
            if s.type in START_TYPES:
                pg["in"].update(s.input_stages)
            elif s.type in END_TYPES:
                pg["out"].update(s.outputs)
            elif s.type not in NON_FLOW:
                pg["logic"] = True
            if s.page_ref:
                pg["calls"].add(s.page_ref)
            if s.target_object is not None and s.target_object in exported:
                pg["acalls"].add((s.target_object, s.target_action))
            refs = set()
            for e in [s.expression, s.exception_detail, s.loop_data, *s.choice_exprs, *s.inputs.values()]:
                refs |= _names_in(e, known)
            if s.loop_data and s.loop_data.strip("[] ") in known:
                refs.add(s.loop_data.strip("[] "))
            pg["reads"] |= refs & globs
            pg["writes"] |= ({t for t in s.calc_targets if t} | set(s.outputs.values())) & globs
        all_pages[art.name] = pages
    # A page needs every process-wide item its callees need, to pass it on.
    # Through a PAGE call the names stay as they are; through a call into
    # another OBJECT's action, that object's own items are seen qualified as
    # "Object::item" (they are the object's state, kept in the caller's scope
    # between actions, exactly as a Blue Prism object instance keeps them).
    changed = True
    while changed:
        changed = False
        for art_name, pages in all_pages.items():
            for pg in pages.values():
                for callee in pg["calls"]:
                    c = pages.get(callee)
                    if c is None:
                        continue
                    for k in ("reads", "writes", "xreads", "xwrites", "objs"):
                        if not c[k] <= pg[k]:
                            pg[k] |= c[k]
                            changed = True
                for obj, act in pg["acalls"]:
                    c = all_pages.get(obj, {}).get(act)
                    if c is None:
                        continue
                    add = {"objs": {obj} | c["objs"], "xreads": set(c["xreads"]), "xwrites": set(c["xwrites"])}
                    if obj == art_name:          # an object calling its own action
                        add["reads"], add["writes"] = set(c["reads"]), set(c["writes"])
                    else:
                        add["xreads"] |= {f"{obj}::{n}" for n in c["reads"]}
                        add["xwrites"] |= {f"{obj}::{n}" for n in c["writes"]}
                    for k, v in add.items():
                        if not v <= pg[k]:
                            pg[k] |= v
                            changed = True
    for art_name, pages in all_pages.items():
        for name, pg in pages.items():
            iface[(art_name, name)] = pg
    _CTX["iface"] = iface
    _CTX["objects"] = exported
    _CTX["gitems"] = gitems
    # datatype of every Data item, so a caller can default an input it omits
    _CTX["dtype"] = {(d.artifact, d.page or MAIN_PAGE, d.name): d.datatype for d in est.data_items}


def _typed_literal(datatype: str | None, value: str | None) -> str | None:
    """A JUEL literal for a Data item's initial value, by BP type. None = no
    honest literal (a collection, a secret)."""
    t = (datatype or "").lower()
    v = (value or "").strip()
    if t == "flag":
        return "true" if v.lower() == "true" else "false"
    if t == "number":
        if v == "":
            return "0"
        return v if re.fullmatch(r"-?\d+(\.\d+)?", v) else None
    if t == "text":
        return _juel_str(value or "")
    if t in ("collection", "password"):
        return None
    # date / datetime / time / timespan / binary / image: a string of the BP
    # literal, or null when unset -- the type is recorded in the process properties
    return _juel_str(v) if v else "null"


def _init_task(est: Estate, artifact: str, page: str, start, extpfx: str) -> tuple[str, str] | None:
    """The page's Data items set to their Blue Prism initial values, as the first
    step after Start. A called page runs in its own scope, so without this a
    [flag] never written is an unknown property, where Blue Prism had False.
    The Main Page also initialises every process-wide item (BP does so at
    session start). Items a page call maps IN are not touched."""
    iface = _CTX["iface"].get((artifact, page), {})
    receivers = set(iface.get("in", {}).values())
    items = [d for d in est.data_items if d.artifact == artifact and d.page == page]
    if page == MAIN_PAGE:
        items += [d for d in est.data_items if d.artifact == artifact and d.page != page and d.scope == "session"]
    else:
        items = [d for d in items if d.scope != "session"]
    seen: set = set()
    params, retained, skipped = [], [], []
    # object state this page (transitively) touches: "Object::item", kept here
    if page == MAIN_PAGE:
        for q in sorted(iface.get("xreads", set()) | iface.get("xwrites", set())):
            obj, _, g = q.partition("::")
            d = _CTX.get("gitems", {}).get((obj, g))
            lit = _typed_literal(d.datatype, d.initial_value) if d else None
            if lit is None:
                skipped.append(q)
                continue
            seen.add(q)
            params.append(f"<{extpfx}:outputParameter{_attrs({'name': q})}>"
                          f"{escape('${' + lit + '}')}</{extpfx}:outputParameter>")
    for d in items:
        if d.name in seen or d.name in receivers:
            continue
        seen.add(d.name)
        lit = _typed_literal(d.datatype, d.initial_value)
        if lit is None:
            skipped.append(f"{d.name} ({d.datatype})")
            continue
        params.append(f"<{extpfx}:outputParameter{_attrs({'name': d.name})}>"
                      f"{escape('${' + lit + '}')}</{extpfx}:outputParameter>")
        if d.scope == "local" and not d.always_init:
            retained.append(d.name)
    if not params:
        return None
    doc = "Blue Prism initial values of this page's Data items"
    if retained:
        doc += " | BP KEPT these between calls of the page (no always-init); here they reset: " + ", ".join(retained)
    if skipped:
        doc += " | not initialised (no literal): " + ", ".join(skipped)
    nid = _nc("init", start.id)
    xml = (f'<bpmn:task{_attrs({"id": nid, "name": f"Init: {page}"})}>'
           f"{_doc(doc)}{_io_block(params, extpfx)}</bpmn:task>")
    return nid, xml


def emit_all(est: Estate, ns: str = "fluxnova", include_objects: bool = False) -> dict[str, str]:
    """Emit one BPMN 2.0 document per PROCESS artifact. Objects (the VBO library)
    are not top-level processes -- their actions surface as service topics on the
    callers. Returns {filename: xml}, filename-sorted-stable."""
    extpfx = ns
    # stable process id for every (artifact, page) so callActivity can resolve.
    page_pid: dict[tuple, str] = {}
    for art in est.artifacts:
        for s in est.stages_by_artifact.get(art.name, []):
            page = s.subsheet or MAIN_PAGE
            page_pid.setdefault((art.name, page), _nc("p", art.name + "::" + page))

    _build_context(est)
    out: dict[str, str] = {}
    for art in est.artifacts:
        # Objects are emitted only on request: an object's pages are its ACTIONS,
        # so each becomes a callable process. UI-automation stages still have no
        # BPMN equivalent (they stay labelled placeholders) -- but a logic-only or
        # code-bound object's flow converts exactly like a process's.
        if art.type != "process" and not include_objects:
            continue
        stages = est.stages_by_artifact.get(art.name, [])
        _wire_choice_otherwise(stages)
        _dissolve_pass_through(stages)
        by_page = bp_core._by_page(stages)
        used_errors: set = set()
        procs, diagrams = [], []
        # Main Page first, then the rest alphabetically -- deterministic order.
        for page in sorted(by_page, key=lambda p: (p != MAIN_PAGE, p)):
            proc, diagram = _emit_process(est, art.name, page, by_page[page], page_pid, extpfx, used_errors)
            procs.append(proc)
            diagrams.append(diagram)
        if not procs:
            continue
        fname = _nc("", art.name).strip("_") or "process"
        out[f"{fname}.bpmn"] = _emit_definitions(procs, diagrams, _nc("Definitions", art.name), extpfx, used_errors)
    return dict(sorted(out.items()))


# --------------------------------------------------------------------------- #
# self-test (cross-the-gap faithfulness check)
# --------------------------------------------------------------------------- #
# bp_core's two fixtures are loop/recovery-only. Add one synthetic process that
# exercises the mechanical rows this layer targets: Start, Action (-> service
# task), Decision (-> gateway), page call (-> call activity), Data (-> variable
# metadata, Number -> decimal note), End. Synthetic test data, never bank IP.
_MECHANICAL_FIXTURE = """\
<process name="Mechanical Rows" version="1.0" bpversion="7.2.0" preferredid="proc-mech" published="true">
  <narrative>Synthetic non-bank fixture: Start, Action, Decision, page call, Data, End.</narrative>
  <subsheet subsheetid="mech-sub-0001" published="true"><name>Main Page</name></subsheet>
  <subsheet subsheetid="mech-sub-0002" published="true"><name>Worker</name></subsheet>

  <stage stageid="mr_amount" name="Amount" type="Data">
    <display x="200" y="0" w="60" h="30"/>
    <datatype>Number</datatype>
    <initialvalue>0</initialvalue>
  </stage>
  <stage stageid="mr_start" name="Start" type="Start">
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>mr_fetch</onsuccess>
  </stage>
  <stage stageid="mr_fetch" name="Fetch Balance" type="Action">
    <display x="0" y="45" w="60" h="30"/>
    <resource object="Centrix" action="Get Balance"/>
    <onsuccess>mr_dec</onsuccess>
  </stage>
  <stage stageid="mr_dec" name="Over Limit?" type="Decision">
    <display x="0" y="90" w="60" h="30"/>
    <decision expression="[Amount] &gt; 1000"/>
    <ontrue>mr_call</ontrue>
    <onfalse>mr_end</onfalse>
  </stage>
  <stage stageid="mr_call" name="Escalate" type="SubSheet">
    <display x="0" y="135" w="60" h="30"/>
    <processid>mech-sub-0002</processid>
    <onsuccess>mr_end</onsuccess>
  </stage>
  <stage stageid="mr_end" name="End" type="End">
    <display x="0" y="180" w="60" h="30"/>
  </stage>

  <stage stageid="w_start" name="W Start" type="Start">
    <subsheetid>mech-sub-0002</subsheetid>
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>w_end</onsuccess>
  </stage>
  <stage stageid="w_end" name="W End" type="End">
    <subsheetid>mech-sub-0002</subsheetid>
    <display x="0" y="45" w="60" h="30"/>
  </stage>
</process>
"""

# Exercises the Medium pass: typed Exception throws (System + Business) -> two
# declared bpmn:error definitions + typed error end events.
_THROWS_FIXTURE = """\
<process name="Throws Medium" version="1.0" bpversion="7.2.0" preferredid="proc-throws" published="true">
  <narrative>Synthetic non-bank fixture: a System and a Business exception throw.</narrative>
  <subsheet subsheetid="throw-sub-0001" published="true"><name>Main Page</name></subsheet>
  <stage stageid="th_start" name="Start" type="Start">
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>th_dec</onsuccess>
  </stage>
  <stage stageid="th_dec" name="Valid?" type="Decision">
    <display x="0" y="45" w="60" h="30"/>
    <decision expression="[ok]"/>
    <ontrue>th_sys</ontrue>
    <onfalse>th_bus</onfalse>
  </stage>
  <stage stageid="th_sys" name="Abort" type="Exception">
    <display x="0" y="90" w="60" h="30"/>
    <exception type="System" detail="Unexpected"/>
  </stage>
  <stage stageid="th_bus" name="Reject" type="Exception">
    <display x="120" y="90" w="60" h="30"/>
    <exception type="Business" detail="Validation failed"/>
  </stage>
</process>
"""

_ROUNDTRIP_FIXTURE = """\
<process name="Roundtrip" version="1.0" bpversion="7.2.0" preferredid="proc-roundtrip" published="true">
  <narrative>Synthetic non-bank fixture: page call with mapped parameters, initial values, a Block
  with Recover/Resume reading ExceptionType()/ExceptionDetail(), a loop with a current-row field read.</narrative>
  <subsheet subsheetid="rt-main" published="true"><name>Main Page</name></subsheet>
  <subsheet subsheetid="rt-double" published="true"><name>Double It</name></subsheet>
  <stage stageid="rt_start" name="Start" type="Start">
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>rt_call</onsuccess>
  </stage>
  <stage stageid="rt_call" name="Double It" type="SubSheet">
    <display x="0" y="45" w="60" h="30"/>
    <inputs><input type="number" name="Value" expr="[Amount]"/></inputs>
    <outputs><output type="number" name="Result" stage="Doubled"/></outputs>
    <onsuccess>rt_dec</onsuccess>
    <processid>rt-double</processid>
  </stage>
  <stage stageid="rt_blk" name="Guard" type="Block">
    <display x="-30" y="80" w="200" h="130"/>
  </stage>
  <stage stageid="rt_dec" name="Too big?" type="Decision">
    <display x="0" y="90" w="60" h="30"/>
    <decision expression="[Doubled] &gt; 10"/>
    <ontrue>rt_throw</ontrue>
    <onfalse>rt_loop</onfalse>
  </stage>
  <stage stageid="rt_throw" name="Reject" type="Exception">
    <display x="0" y="135" w="60" h="30"/>
    <exception type="Business Exception" detail="&quot;Too big: &quot; &amp; [Doubled]"/>
  </stage>
  <stage stageid="rt_rc" name="Recover Guard" type="Recover">
    <display x="90" y="135" w="60" h="30"/>
    <onsuccess>rt_mc</onsuccess>
  </stage>
  <stage stageid="rt_mc" name="Exception Details" type="MultipleCalculation">
    <display x="90" y="225" w="60" h="30"/>
    <onsuccess>rt_res</onsuccess>
    <steps>
      <calculation expression="ExceptionType()" stage="ExType"/>
      <calculation expression="ExceptionDetail()" stage="ExDetail"/>
    </steps>
  </stage>
  <stage stageid="rt_res" name="Resume Guard" type="Resume">
    <display x="90" y="270" w="60" h="30"/>
    <onsuccess>rt_loop</onsuccess>
  </stage>
  <stage stageid="rt_loop" name="Each Row" type="LoopStart">
    <display x="0" y="315" w="60" h="30"/>
    <groupid>rt-g1</groupid>
    <looptype>ForEach</looptype>
    <loopdata>Rows</loopdata>
    <onsuccess>rt_last</onsuccess>
  </stage>
  <stage stageid="rt_last" name="Remember Name" type="Calculation">
    <display x="0" y="360" w="60" h="30"/>
    <onsuccess>rt_le</onsuccess>
    <calculation expression="[Rows.Name]" stage="Last"/>
  </stage>
  <stage stageid="rt_le" name="Each Row End" type="LoopEnd">
    <display x="0" y="405" w="60" h="30"/>
    <groupid>rt-g1</groupid>
    <onsuccess>rt_act1</onsuccess>
  </stage>
  <stage stageid="rt_act1" name="Triple Once" type="Action">
    <display x="0" y="450" w="60" h="30"/>
    <inputs><input type="number" name="X" expr="[Doubled]"/></inputs>
    <outputs><output type="number" name="Y" stage="Tripled"/></outputs>
    <onsuccess>rt_act2</onsuccess>
    <resource object="Calc" action="Triple"/>
  </stage>
  <stage stageid="rt_act2" name="Triple Again" type="Action">
    <display x="0" y="495" w="60" h="30"/>
    <inputs><input type="number" name="X" expr="[Tripled]"/></inputs>
    <outputs><output type="number" name="Y" stage="Tripled"/></outputs>
    <onsuccess>rt_end</onsuccess>
    <resource object="Calc" action="Triple"/>
  </stage>
  <stage stageid="rt_end" name="End" type="End">
    <display x="0" y="540" w="60" h="30"/>
  </stage>
  <stage stageid="rt_d_tripled" name="Tripled" type="Data">
    <display x="300" y="315" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="rt_d_amount" name="Amount" type="Data">
    <display x="300" y="0" w="60" h="30"/>
    <datatype>number</datatype><initialvalue>21</initialvalue>
  </stage>
  <stage stageid="rt_d_greet" name="Greeting" type="Data">
    <display x="300" y="45" w="60" h="30"/>
    <datatype>text</datatype><initialvalue>hello</initialvalue>
  </stage>
  <stage stageid="rt_d_doubled" name="Doubled" type="Data">
    <display x="300" y="90" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="rt_d_extype" name="ExType" type="Data">
    <display x="300" y="135" w="60" h="30"/>
    <datatype>text</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="rt_d_exdetail" name="ExDetail" type="Data">
    <display x="300" y="180" w="60" h="30"/>
    <datatype>text</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="rt_d_last" name="Last" type="Data">
    <display x="300" y="225" w="60" h="30"/>
    <datatype>text</datatype><initialvalue>none</initialvalue><private/><alwaysinit/>
  </stage>
  <stage stageid="rt_c_rows" name="Rows" type="Collection">
    <display x="300" y="270" w="60" h="30"/>
    <datatype>collection</datatype>
    <collectioninfo><field name="Name" type="text"/></collectioninfo>
  </stage>
  <stage stageid="rd_start" name="Start" type="Start">
    <subsheetid>rt-double</subsheetid>
    <display x="0" y="0" w="60" h="30"/>
    <inputs><input type="number" name="Value" stage="Value"/></inputs>
    <onsuccess>rd_calc</onsuccess>
  </stage>
  <stage stageid="rd_calc" name="Double" type="Calculation">
    <subsheetid>rt-double</subsheetid>
    <display x="0" y="45" w="60" h="30"/>
    <onsuccess>rd_end</onsuccess>
    <calculation expression="[Value] * 2" stage="Result"/>
  </stage>
  <stage stageid="rd_end" name="End" type="End">
    <subsheetid>rt-double</subsheetid>
    <display x="0" y="90" w="60" h="30"/>
    <outputs><output type="number" name="Result" stage="Result"/></outputs>
  </stage>
  <stage stageid="rd_d_value" name="Value" type="Data">
    <subsheetid>rt-double</subsheetid>
    <display x="300" y="0" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="rd_d_result" name="Result" type="Data">
    <subsheetid>rt-double</subsheetid>
    <display x="300" y="45" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
</process>
"""

EMBEDDED_FIXTURES = dict(bp_core.EMBEDDED_FIXTURES)
_CALC_OBJECT_FIXTURE = """\
<process name="Calc" type="object" version="1.0" bpversion="7.2.0" preferredid="obj-calc" published="true">
  <narrative>Synthetic non-bank object: an Initialise page with logic, an action with mapped I/O that
  keeps state in an object-wide Data item, and a pure-logic Code stage (a script slot).</narrative>
  <subsheet subsheetid="calc-init" published="true"><name>Initialise</name></subsheet>
  <subsheet subsheetid="calc-triple" published="true"><name>Triple</name></subsheet>
  <subsheet subsheetid="calc-pure" published="true"><name>Pure</name></subsheet>
  <stage stageid="ci_start" name="Start" type="Start">
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>ci_calc</onsuccess>
  </stage>
  <stage stageid="ci_calc" name="Reset Counter" type="Calculation">
    <display x="0" y="45" w="60" h="30"/>
    <onsuccess>ci_end</onsuccess>
    <calculation expression="100" stage="Calls"/>
  </stage>
  <stage stageid="ci_end" name="End" type="End">
    <display x="0" y="90" w="60" h="30"/>
  </stage>
  <stage stageid="ct_start" name="Start" type="Start">
    <subsheetid>calc-triple</subsheetid>
    <display x="0" y="0" w="60" h="30"/>
    <inputs><input type="number" name="X" stage="X"/></inputs>
    <onsuccess>ct_calc</onsuccess>
  </stage>
  <stage stageid="ct_calc" name="Triple" type="MultipleCalculation">
    <subsheetid>calc-triple</subsheetid>
    <display x="0" y="45" w="60" h="30"/>
    <onsuccess>ct_end</onsuccess>
    <steps>
      <calculation expression="[X] * 3" stage="Y"/>
      <calculation expression="[Calls] + 1" stage="Calls"/>
    </steps>
  </stage>
  <stage stageid="ct_end" name="End" type="End">
    <subsheetid>calc-triple</subsheetid>
    <display x="0" y="90" w="60" h="30"/>
    <outputs><output type="number" name="Y" stage="Y"/></outputs>
  </stage>
  <stage stageid="cp_start" name="Start" type="Start">
    <subsheetid>calc-pure</subsheetid>
    <display x="0" y="0" w="60" h="30"/>
    <inputs><input type="number" name="X" stage="X"/></inputs>
    <onsuccess>cp_code</onsuccess>
  </stage>
  <stage stageid="cp_code" name="Square" type="Code">
    <subsheetid>calc-pure</subsheetid>
    <display x="0" y="45" w="60" h="30"/>
    <inputs><input type="number" name="X" expr="[X]"/></inputs>
    <outputs><output type="number" name="Y" stage="Y"/></outputs>
    <onsuccess>cp_end</onsuccess>
    <code>Y = X * X;</code>
  </stage>
  <stage stageid="cp_end" name="End" type="End">
    <subsheetid>calc-pure</subsheetid>
    <display x="0" y="90" w="60" h="30"/>
    <outputs><output type="number" name="Y" stage="Y"/></outputs>
  </stage>
  <stage stageid="c_pi" name="Code Options" type="ProcessInfo">
    <display x="300" y="200" w="60" h="30"/>
    <language>csharp</language><globalcode/><code/>
  </stage>
  <stage stageid="c_d_calls" name="Calls" type="Data">
    <display x="300" y="0" w="60" h="30"/>
    <datatype>number</datatype><initialvalue>0</initialvalue>
  </stage>
  <stage stageid="c_d_x" name="X" type="Data">
    <subsheetid>calc-triple</subsheetid>
    <display x="300" y="45" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="c_d_y" name="Y" type="Data">
    <subsheetid>calc-triple</subsheetid>
    <display x="300" y="90" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="c_d_px" name="X" type="Data">
    <subsheetid>calc-pure</subsheetid>
    <display x="300" y="135" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
  <stage stageid="c_d_py" name="Y" type="Data">
    <subsheetid>calc-pure</subsheetid>
    <display x="300" y="180" w="60" h="30"/>
    <datatype>number</datatype><private/><alwaysinit/>
  </stage>
</process>
"""

# A loop whose BODY is a protected Block: the throw on one row is caught by the
# Recover inside the loop, the handler notes it, the Resume rejoins the loop and
# the next rows still run. This is the nesting the old emitter left flat.
_NESTED_FIXTURE = """\
<process name="Nested" version="1.0" bpversion="7.2.0" preferredid="proc-nested" published="true">
  <narrative>Synthetic non-bank fixture: for each item, a Block guards a Decision that throws on big
  values; the Recover (inside the Block, inside the loop) notes the failure and Resumes into the loop end.</narrative>
  <subsheet subsheetid="ne-main" published="true"><name>Main Page</name></subsheet>
  <stage stageid="ne_start" name="Start" type="Start">
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>ne_loop</onsuccess>
  </stage>
  <stage stageid="ne_loop" name="Each Item" type="LoopStart">
    <display x="0" y="45" w="60" h="30"/>
    <groupid>ne-g1</groupid>
    <looptype>ForEach</looptype>
    <loopdata>Items</loopdata>
    <onsuccess>ne_dec</onsuccess>
  </stage>
  <stage stageid="ne_blk" name="Try Item" type="Block">
    <display x="-30" y="90" w="200" h="110"/>
  </stage>
  <stage stageid="ne_dec" name="Big?" type="Decision">
    <display x="0" y="105" w="60" h="30"/>
    <decision expression="[Items.V] &gt; 10"/>
    <ontrue>ne_throw</ontrue>
    <onfalse>ne_count</onfalse>
  </stage>
  <stage stageid="ne_throw" name="Too big" type="Exception">
    <display x="0" y="150" w="60" h="30"/>
    <exception type="Business Exception" detail="&quot;Too big: &quot; &amp; [Items.V]"/>
  </stage>
  <stage stageid="ne_count" name="Count It" type="Calculation">
    <display x="90" y="150" w="60" h="30"/>
    <onsuccess>ne_le</onsuccess>
    <calculation expression="[Count] + 1" stage="Count"/>
  </stage>
  <stage stageid="ne_rc" name="Catch" type="Recover">
    <display x="120" y="110"/>
    <onsuccess>ne_note</onsuccess>
  </stage>
  <stage stageid="ne_note" name="Record Failure" type="MultipleCalculation">
    <display x="120" y="240" w="60" h="30"/>
    <onsuccess>ne_res</onsuccess>
    <steps>
      <calculation expression="ExceptionDetail()" stage="Caught"/>
      <calculation expression="[Fails] + 1" stage="Fails"/>
    </steps>
  </stage>
  <stage stageid="ne_res" name="Carry On" type="Resume">
    <display x="120" y="285" w="60" h="30"/>
    <onsuccess>ne_le</onsuccess>
  </stage>
  <stage stageid="ne_le" name="Each Item End" type="LoopEnd">
    <display x="0" y="330" w="60" h="30"/>
    <groupid>ne-g1</groupid>
    <onsuccess>ne_end</onsuccess>
  </stage>
  <stage stageid="ne_end" name="End" type="End">
    <display x="0" y="375" w="60" h="30"/>
  </stage>
  <stage stageid="ne_d_count" name="Count" type="Data">
    <display x="300" y="0" w="60" h="30"/>
    <datatype>number</datatype><initialvalue>0</initialvalue>
  </stage>
  <stage stageid="ne_d_fails" name="Fails" type="Data">
    <display x="300" y="45" w="60" h="30"/>
    <datatype>number</datatype><initialvalue>0</initialvalue>
  </stage>
  <stage stageid="ne_d_caught" name="Caught" type="Data">
    <display x="300" y="90" w="60" h="30"/>
    <datatype>text</datatype><initialvalue>none</initialvalue><private/><alwaysinit/>
  </stage>
  <stage stageid="ne_c_items" name="Items" type="Collection">
    <display x="300" y="135" w="60" h="30"/>
    <datatype>collection</datatype>
    <collectioninfo><field name="V" type="number"/></collectioninfo>
  </stage>
</process>
"""

EMBEDDED_FIXTURES["roundtrip.bpprocess"] = _ROUNDTRIP_FIXTURE
EMBEDDED_FIXTURES["nested.bpprocess"] = _NESTED_FIXTURE
EMBEDDED_FIXTURES["calc.bpobject"] = _CALC_OBJECT_FIXTURE
EMBEDDED_FIXTURES["mechanical_rows.bpprocess"] = _MECHANICAL_FIXTURE
EMBEDDED_FIXTURES["throws_medium.bpprocess"] = _THROWS_FIXTURE


def _fixture_estate() -> Estate:
    with tempfile.TemporaryDirectory() as d:
        for name, xml in EMBEDDED_FIXTURES.items():
            (Path(d) / name).write_text(xml, encoding="utf-8")
        est = Estate()
        parse_paths(bp_core._collect([d]), est)
        return est


def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _emit_hashes(ns: str = "fluxnova") -> dict[str, str]:
    return {name: _h(xml) for name, xml in emit_all(_fixture_estate(), ns).items()}


# Baked goldens over the embedded synthetic fixtures (fluxnova namespace).
EXPECTED_EMIT_HASHES: dict[str, str] = {
    "Cross_Page_Recovery_aa06acd9.bpmn": "10c29a6b74b15831",
    "Loops_And_Recovery_dcd3e33f.bpmn": "bc13db2a36795c55",
    "Mechanical_Rows_a9ae4e8b.bpmn": "156429ad059cf092",
    "Nested_2344677d.bpmn": "327387af9ca7e287",
    "Roundtrip_4c223bc8.bpmn": "9cdfc6499b19d7a3",
    "Throws_Medium_c83be3e9.bpmn": "70df0ac5381ced27",
}


def _structural_problems(xml: str) -> list[str]:
    """BPMN sanity beyond well-formedness: every sequenceFlow endpoint must exist,
    a flow may not leave an endEvent, and none may enter a startEvent."""
    def local(t: str) -> str:
        return t.split("}")[-1]
    root = ET.fromstring(xml)
    tag_of = {el.get("id"): local(el.tag) for el in root.iter() if el.get("id")}
    problems = []
    for f in (el for el in root.iter() if local(el.tag) == "sequenceFlow"):
        s, t = f.get("sourceRef"), f.get("targetRef")
        if s not in tag_of:
            problems.append(f"dangling source {s}")
        if t not in tag_of:
            problems.append(f"dangling target {t}")
        if tag_of.get(s) == "endEvent":
            problems.append(f"flow out of endEvent {s}")
        if tag_of.get(t) == "startEvent":
            problems.append(f"flow into startEvent {t}")
        if tag_of.get(t) == "boundaryEvent":
            problems.append(f"flow into boundaryEvent {t}")
    # DI: every shape/edge must reference an existing model element
    for d in (el for el in root.iter() if local(el.tag) in ("BPMNShape", "BPMNEdge")):
        ref = d.get("bpmnElement")
        if ref not in tag_of:
            problems.append(f"DI {local(d.tag)} -> missing {ref}")
    return problems


# Transpiler control set: exact translations (positive) + must-fail inputs
# (negative). Guards the JUEL grammar independently of the fixtures.
_JUEL_OK = [
    ("[Amount] > 1000", "Amount > 1000"),
    ("[ok] = True", "ok == true"),
    ('[a] <> "x"', "a != 'x'"),
    ("[x] > 1 And [y] < 2", "x > 1 && y < 2"),
    ("Not [flag]", "! flag"),
    ("[Work Items] >= 5", "execution.getVariable('Work Items') >= 5"),
    # curated functions -- each template runtime-verified against Camunda 7
    ("Trim([Name])", "Name.trim()"),
    ("Mid([s],2,3)", "s.substring(2 - 1, 2 - 1 + 3)"),
    ("Upper(Trim([s]))", "s.trim().toUpperCase()"),
    # concatenation and the AND/OR/NOT function forms -- verified on the engine
    ("[a] & [b]", "(a ).concat( b)"),
    ("AND([p],[q])", "(p && q)"),
    ("NOT([p])", "(!(p))"),
    # current-row field reads and the exception accessors (see _JUEL_FUNCS)
    ("[Rows.Name]", "execution.getVariable('Rows#row')['Name']"),
    ("ExceptionDetail()", "bpErrorMessage"),
]
# An UNMAPPED function must still hard-fail: a guessed equivalent is worse than
# an honest TODO.
_JUEL_FAIL = ["GetClipboard()", "IsNumber([s])", "ToNumber([s])", "[Coll.A.B] = 1",
              "[x] ^ 2", "[a] ; [b]"]


def selftest() -> int:
    fails: list[str] = []

    # (0) transpiler control set
    for src, want in _JUEL_OK:
        ok, res = _juel(src)
        if not ok or res != want:
            fails.append(f"juel '{src}' -> {res!r} (want {want!r})")
    for src in _JUEL_FAIL:
        ok, _ = _juel(src)
        if ok:
            fails.append(f"juel '{src}' should have failed")

    docs = emit_all(_fixture_estate(), "fluxnova")

    # (a) every emitted document must be well-formed AND structurally sane
    for name, xml in docs.items():
        try:
            ET.fromstring(xml)
        except Exception as e:  # noqa: BLE001
            fails.append(f"not well-formed: {name}: {e}")
            continue
        for p in _structural_problems(xml):
            fails.append(f"structural: {name}: {p}")

    # (b) byte-faithfulness against the baked goldens
    got = {name: _h(xml) for name, xml in docs.items()}
    if EXPECTED_EMIT_HASHES:
        for key in sorted(EXPECTED_EMIT_HASHES):
            if got.get(key) != EXPECTED_EMIT_HASHES[key]:
                fails.append(f"emit '{key}' hash mismatch")
        for key in sorted(got):
            if key not in EXPECTED_EMIT_HASHES:
                fails.append(f"emit '{key}' (unexpected extra file)")
    else:
        fails.append("no goldens baked yet - run --emit-hashes and paste them in")

    if not fails:
        print("SELFTEST PASS")
        return 0
    print("SELFTEST FAIL - this copy does NOT match the tested original")
    for f in fails:
        print("  " + f)
    return 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="bp_emit",
        description="Blue Prism -> Fluxnova (Camunda 7) BPMN emitter (skeleton).",
    )
    ap.add_argument("inputs", nargs="*", help="export files or directories")
    ap.add_argument("--selftest", action="store_true",
                    help="verify this copy reproduces the baked hashes + emits well-formed XML")
    ap.add_argument("--emit-hashes", action="store_true",
                    help="(build only) print golden emit hashes as JSON")
    ap.add_argument("--objects", action="store_true",
                    help="also emit BPMN for OBJECTS (each object action page -> a process)")
    ap.add_argument("--ns", choices=sorted(EXT_NS), default="fluxnova",
                    help="vendor-extension namespace (default fluxnova; camunda for tooling/local-C7 interop)")
    ap.add_argument("-o", "--out", help="output directory (default: stdout, first doc only)")
    a = ap.parse_args(argv)

    if a.emit_hashes:
        sys.stdout.write(json.dumps(_emit_hashes(a.ns), indent=2, sort_keys=True))
        return 0
    if a.selftest:
        return selftest()
    if not a.inputs:
        ap.error("give an input path, or --selftest")

    est = Estate()
    parse_paths(bp_core._collect(a.inputs), est)
    docs = emit_all(est, a.ns, include_objects=a.objects)
    if not docs:
        print("no process artifacts to emit", file=sys.stderr)
        return 0
    if a.out:
        d = Path(a.out)
        d.mkdir(parents=True, exist_ok=True)
        for name, xml in docs.items():
            (d / name).write_text(xml, encoding="utf-8")
        print(f"{len(docs)} BPMN document(s) -> {a.out}  (ns={a.ns})", file=sys.stderr)
    else:
        # stdout: just the first document (real runs use -o)
        sys.stdout.write(next(iter(docs.values())))
    return 0


if __name__ == "__main__":
    sys.exit(main())
