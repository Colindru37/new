#!/usr/bin/env python3
"""Blue Prism -> BPMN equivalence audit (Layer 4).

Answers ONE question with numbers: how much of the Blue Prism export is actually
represented in the BPMN that bp_emit produces for it?  It counts every construct
on the SOURCE side (read straight from the export XML, independently of
bp_core's parse model, so a parser drop is visible too) and looks for its
counterpart on the OUTPUT side (the BPMN bp_emit emits), then prints the gap per
category.  A reachability pass (orphans / dead ends) is included, but it is one
row among many -- "0 orphans" alone proved to be a far weaker statement than it
looked.

    python bp_equiv.py <exports...> [--objects] [--per-artifact] [--json out.json]

Rows: stage types (emitted / absorbed / absent), links, reachability,
expressions by category (translated / failed, with the failing functions),
Action and Code parameters, page interfaces and page-call mappings, data items
(scope, initial values, collection schemas), gateway conditions, loops and
exception handling.  Verdicts: OK (nothing lost), PARTIAL, LOST (nothing of the
category survives), DESIGN (the loss is an accepted mapping decision, documented
in the note).  A DESIGN row is still a loss -- it is just a known one.

Cross-the-gap contract (same as bp_core / bp_full / bp_emit): `--selftest`
reproduces a baked summary over the embedded synthetic fixtures. SELFTEST PASS
== this copy was retyped faithfully.  Stdlib only, Python 3.11+.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

import bp_core
import bp_emit
from bp_core import Estate, parse_paths

FLOW_LINK_TAGS = ("onsuccess", "ontrue", "onfalse")
NODE_TAGS = {"startEvent", "endEvent", "task", "serviceTask", "scriptTask",
             "callActivity", "exclusiveGateway", "subProcess", "boundaryEvent",
             "intermediateCatchEvent", "intermediateThrowEvent", "userTask"}
# Stage types that are not flow nodes in Blue Prism either.
DECL_TYPES = {"ProcessInfo", "SubSheetInfo", "Data", "Collection", "Note"}
# Stage types whose absence as a BPMN node is a documented mapping decision.
DESIGN_ABSENT = {
    "Anchor": "dissolved: A -> Anchor -> B becomes A -> B",
    "Block": "a Block is a scope, not a step; emitted as a subProcess only when it owns a Recover",
    "LoopEnd": "folded into the loop subProcess",
    "ChoiceEnd": "the Choice bracket's otherwise exit; dissolved into the gateway's default flow",
    "WaitEnd": "folded into the Wait gateway",
    "Resume": "folded into the boundary-event rejoin when the Recover is block-scoped",
}


def _loc(tag: str) -> str:
    return tag.split("}")[-1]


# --------------------------------------------------------------------------- #
# SOURCE side: read the export XML directly
# --------------------------------------------------------------------------- #
class SrcStage:
    __slots__ = ("id", "name", "type", "links", "inputs", "outputs", "exprs",
                 "calc", "choices", "page", "loopdata", "private", "initial",
                 "collfields", "datatype", "groupid", "code", "res_obj", "res_act", "globalcode")

    def __init__(self, el):
        self.id = el.get("stageid", "")
        self.name = el.get("name", "")
        self.type = el.get("type", "")
        self.links: list[str] = []
        self.inputs: list[tuple[str, str | None, str | None]] = []   # name, expr, stage
        self.outputs: list[tuple[str, str | None]] = []              # name, stage
        self.exprs: list[tuple[str, str]] = []                       # category, expression
        self.calc: list[tuple[str, str | None]] = []                 # expr, target stage
        self.choices: list[tuple[str, str]] = []                     # expr, ontrue target
        self.page = None
        self.loopdata = None
        self.private = False
        self.initial = None
        self.collfields = 0
        self.datatype = None
        self.groupid = None
        self.code = None
        self.res_obj = self.res_act = None
        self.globalcode = None
        for ch in el:
            n = _loc(ch.tag)
            if n in FLOW_LINK_TAGS and (ch.text or "").strip():
                self.links.append(ch.text.strip())
            elif n == "code":
                self.code = ch.text
            elif n == "globalcode":
                self.globalcode = ch.text
            elif n == "resource":
                self.res_obj, self.res_act = ch.get("object"), ch.get("action")
            elif n == "groupid":
                self.groupid = (ch.text or "").strip()
            elif n == "subsheetid":
                self.page = (ch.text or "").strip()
            elif n == "choices":
                for c in ch:
                    if _loc(c.tag) != "choice":
                        continue
                    tgt = next(((x.text or "").strip() for x in c if _loc(x.tag) == "ontrue"), "")
                    expr = c.get("expression", "")
                    self.choices.append((expr, tgt))
                    if tgt:
                        self.links.append(tgt)
                    if expr:
                        self.exprs.append(("choice", expr))
            elif n == "decision":
                e = ch.get("expression")
                if e:
                    self.exprs.append(("decision", e))
            elif n == "calculation":
                self.calc.append((ch.get("expression", ""), ch.get("stage")))
                self.exprs.append(("calculation", ch.get("expression", "")))
            elif n == "steps":
                for c in ch:
                    if _loc(c.tag) == "calculation":
                        self.calc.append((c.get("expression", ""), c.get("stage")))
                        self.exprs.append(("calculation", c.get("expression", "")))
            elif n == "exception":
                d = ch.get("detail")
                if d:
                    self.exprs.append(("exception-detail", d))
            elif n == "loopdata":
                self.loopdata = (ch.text or "").strip() or None   # a collection NAME, not an expression
            elif n == "inputs":
                for i in ch:
                    if _loc(i.tag) == "input" and i.get("name"):
                        e = i.get("expr")
                        if e is None:
                            e = i.get("value")
                        self.inputs.append((i.get("name"), e, i.get("stage")))
                        if e:
                            self.exprs.append(("action-input", e))
            elif n == "outputs":
                for o in ch:
                    if _loc(o.tag) == "output" and o.get("name"):
                        self.outputs.append((o.get("name"), o.get("stage")))
            elif n == "private":
                self.private = True
            elif n == "initialvalue":
                self.initial = (ch.text or "")
            elif n == "datatype":
                self.datatype = (ch.text or "").strip()
            elif n == "collectioninfo":
                self.collfields = sum(1 for f in ch if _loc(f.tag) == "field")


class SrcArtifact:
    def __init__(self, el):
        self.name = el.get("name", "")
        self.type = el.get("type") or _loc(el.tag)   # an object exports as <process type="object">
        self.stages: list[SrcStage] = [SrcStage(s) for s in el if _loc(s.tag) == "stage"]
        self.by_id = {s.id: s for s in self.stages}
        self.page_name = {s.page: s.name for s in self.stages if s.type == "SubSheetInfo" and s.page}
        # shared code (ProcessInfo <code>/<globalcode>) reaches every Code stage
        pi = next((s for s in self.stages if s.type == "ProcessInfo"), None)
        self.shared_ext = sorted({k for t in (pi.code, pi.globalcode) for k in bp_core.code_external(t)}) if pi else []

    def page_of(self, s: SrcStage) -> str:
        return self.page_name.get(s.page, bp_emit.MAIN_PAGE) if s.page else bp_emit.MAIN_PAGE


def read_source(paths: list[Path]) -> list[SrcArtifact]:
    arts: list[SrcArtifact] = []
    for p in paths:
        root = ET.parse(p).getroot()
        for el in root.iter():
            if _loc(el.tag) in ("process", "object") and el.get("name") \
                    and any(_loc(c.tag) == "stage" for c in el):
                arts.append(SrcArtifact(el))
    return arts


def dissolved_links(art: SrcArtifact) -> list[tuple[str, str]]:
    """Every source link with Anchors skipped: (from stage id, to stage id)."""
    out = []
    # the otherwise path of a Choice is an implicit edge: ChoiceStart -> its
    # ChoiceEnd (same groupid), which then continues via its own onsuccess
    ends = {}
    for s in art.stages:
        if s.type == "ChoiceEnd":
            ends[s.groupid] = s.id
    pass_through = {"Anchor", "ChoiceEnd"}
    for s in art.stages:
        if s.type in pass_through:
            continue
        links = list(s.links)
        if s.type == "ChoiceStart" and ends.get(s.groupid):
            links.append(ends[s.groupid])
        for t in links:
            seen = set()
            while t in art.by_id and art.by_id[t].type in pass_through and t not in seen:
                seen.add(t)
                nxt = art.by_id[t].links
                t = nxt[0] if nxt else ""
            if t:
                out.append((s.id, t))
    return out


# --------------------------------------------------------------------------- #
# OUTPUT side: read the emitted BPMN
# --------------------------------------------------------------------------- #
class Bpmn:
    def __init__(self, xml: str):
        self.root = ET.fromstring(xml)
        self.tag_of: dict[str, str] = {}
        self.el_of: dict[str, ET.Element] = {}
        self.flows: list[tuple[str, str, str | None]] = []
        self.container: dict[str, str] = {}
        for el in self.root.iter():
            n = _loc(el.tag)
            i = el.get("id")
            if i and n in NODE_TAGS:
                self.tag_of[i] = n
                self.el_of[i] = el
            if n == "sequenceFlow":
                cond = next(((c.text or "").strip() for c in el if _loc(c.tag) == "conditionExpression"), None)
                self.flows.append((el.get("sourceRef"), el.get("targetRef"), cond))
        self.event_sub: set[str] = set()
        for parent in self.root.iter():
            pn = _loc(parent.tag)
            if pn == "subProcess" and parent.get("triggeredByEvent") == "true":
                self.event_sub.add(parent.get("id"))
                for ch in parent.iter():
                    if ch.get("id"):
                        self.event_sub.add(ch.get("id"))
            if pn in ("process", "subProcess"):
                for ch in parent:
                    if ch.get("id") and _loc(ch.tag) in NODE_TAGS:
                        self.container[ch.get("id")] = parent.get("id")
        # per process: names an Init task sets; call-activity mapping endpoints
        self.init_names: dict[str, set] = defaultdict(set)
        self.in_targets: set = set()
        self.out_sources: set = set()
        self.all_vars_calls = 0
        for nid, el in self.el_of.items():
            if self.tag_of[nid] == "task" and nid.startswith("init_"):
                for e in el.iter():
                    if _loc(e.tag) == "outputParameter":
                        self.init_names[self.container.get(nid, "")].add(e.get("name"))
            if self.tag_of[nid] == "callActivity":
                for e in el.iter():
                    if _loc(e.tag) == "in":
                        if e.get("variables") == "all":
                            self.all_vars_calls += 1
                        elif e.get("target"):
                            self.in_targets.add(e.get("target"))
                    elif _loc(e.tag) == "out" and e.get("source"):
                        self.out_sources.add(e.get("source"))
        self.out_of = defaultdict(list)
        self.in_of = defaultdict(list)
        for s, t, c in self.flows:
            self.out_of[s].append((t, c))
            self.in_of[t].append((s, c))
        self.flowset = {(s, t) for s, t, _ in self.flows}

    def node_id_for(self, stage_id: str) -> str | None:
        for pfx in ("s", "loop", "blk", "bnd", "evsub"):
            i = bp_emit._nc(pfx, stage_id)
            if i in self.tag_of:
                return i
        return None

    def params(self, nid: str, kind: str) -> int:
        el = self.el_of.get(nid)
        return 0 if el is None else sum(1 for e in el.iter() if _loc(e.tag) == kind)

    def reachability(self) -> tuple[int, int]:
        orphans = dead = 0
        for i, tag in self.tag_of.items():
            # an event subProcess is entered by its start event, never by a flow
            if tag == "boundaryEvent" or i in self.event_sub:
                continue
            if tag != "startEvent" and not self.in_of.get(i):
                orphans += 1
            if tag != "endEvent" and not self.out_of.get(i):
                dead += 1
        return orphans, dead


# --------------------------------------------------------------------------- #
# the audit
# --------------------------------------------------------------------------- #
class Row:
    def __init__(self, section, item, source, emitted, verdict=None, note=""):
        self.section, self.item = section, item
        self.source, self.emitted = source, emitted
        self.note = note
        if verdict is None:
            if source == 0:
                verdict = "-"
            elif emitted >= source:
                verdict = "OK"
            elif emitted == 0:
                verdict = "LOST"
            else:
                verdict = "PARTIAL"
        self.verdict = verdict

    def key(self):
        return (self.section, self.item)


def _fn_names(expr: str) -> list[str]:
    return re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", expr)


def audit_artifact(src: SrcArtifact, doc: Bpmn | None, all_artifact_names: set = frozenset(),
                   all_in_targets: set | None = None, all_out_sources: set | None = None) -> tuple[list[Row], dict]:
    rows: list[Row] = []
    detail: dict = {"failed_functions": Counter(), "failed_reasons": Counter(),
                    "unmatched_links": Counter()}

    def nid(sid):
        return doc.node_id_for(sid) if doc else None

    # 1) stage types
    by_type: dict[str, list[SrcStage]] = defaultdict(list)
    for s in src.stages:
        by_type[s.type].append(s)
    for t in sorted(by_type):
        if t in DECL_TYPES:
            continue
        lst = by_type[t]
        emitted = sum(1 for s in lst if nid(s.id))
        if t in DESIGN_ABSENT:
            rows.append(Row("stages", t, len(lst), emitted,
                            "DESIGN" if emitted < len(lst) else "OK", DESIGN_ABSENT[t]))
        else:
            rows.append(Row("stages", t, len(lst), emitted))

    # 2) links + reachability
    links = dissolved_links(src)
    matched = 0
    for a, b in links:
        na, nb = nid(a), nid(b)
        if na and doc.tag_of.get(na) == "startEvent":
            # Start -> Init -> target: the init task is a pass-through
            nxt = [t for t, _ in doc.out_of.get(na, []) if t.startswith("init_")]
            if nxt:
                na = nxt[0]
        if na and nb and (na, nb) in doc.flowset:
            matched += 1
        else:
            ta = src.by_id[a].type if a in src.by_id else "?"
            tb = src.by_id[b].type if b in src.by_id else "?"
            detail["unmatched_links"][f"{ta} -> {tb}"] += 1
    rows.append(Row("flow", "links (anchors dissolved)", len(links), matched, None,
                    "a link into/out of a loop or Block subProcess is rewired, so some unmatched are structural"))
    if doc:
        orphans, dead = doc.reachability()
        rows.append(Row("flow", "orphan nodes (no inflow)", orphans, 0, "OK" if orphans == 0 else "BUG",
                        "nodes the engine can never reach"))
        rows.append(Row("flow", "dead-end nodes (no outflow)", dead, 0, "OK" if dead == 0 else "BUG", ""))

    # 3) expressions
    by_cat: dict[str, list[str]] = defaultdict(list)
    for s in src.stages:
        for cat, e in s.exprs:
            by_cat[cat].append(e)
    for cat in sorted(by_cat):
        ok = 0
        for e in by_cat[cat]:
            good, res = bp_emit._juel(e)
            if good:
                ok += 1
            else:
                detail["failed_reasons"][res.split("'")[0].strip()] += 1
                for fn in _fn_names(e):
                    detail["failed_functions"][fn] += 1
        rows.append(Row("expressions", cat, len(by_cat[cat]), ok))

    # 4) Action / Code parameters
    def param_rows(stype, label):
        ins = outs = ins_e = outs_e = 0
        for s in by_type.get(stype, []):
            n = nid(s.id)
            has_in = [i for i in s.inputs if (i[1] or "").strip()]
            ins += len(has_in)
            outs += sum(1 for o in s.outputs if o[1])
            if n:
                ins_e += min(doc.params(n, "inputParameter"), len(has_in))
                outs_e += min(doc.params(n, "outputParameter"), len(s.outputs))
        rows.append(Row("parameters", f"{label} inputs", ins, ins_e))
        rows.append(Row("parameters", f"{label} outputs", outs, outs_e))
    param_rows("Action", "Action")
    param_rows("Code", "Code stage")

    # 4b) what each Code stage became, and what each Action became
    pure = ext = pure_e = ext_e = 0
    for s in by_type.get("Code", []):
        is_ext = bool(bp_core.code_external(s.code) or src.shared_ext)
        n = nid(s.id)
        tag = doc.tag_of.get(n) if n else None
        if is_ext:
            ext += 1
            ext_e += tag == "serviceTask"
        else:
            pure += 1
            pure_e += tag == "scriptTask"
    rows.append(Row("code", "Code stages, pure logic -> script slot", pure, pure_e, None,
                    "a scriptTask carrying the C# and the I/O contract; body throws until ported"))
    rows.append(Row("code", "Code stages, outside reach -> worker", ext, ext_e, "DESIGN" if ext else "-",
                    "COM/browser/files/OS (own or shared code): an external task, whatever else is done"))
    exported = {a for a in all_artifact_names}
    a_in = a_in_e = a_out = a_out_e = 0
    for s in by_type.get("Action", []):
        n = nid(s.id)
        tag = doc.tag_of.get(n) if n else None
        if s.res_obj in exported:
            a_in += 1
            a_in_e += tag == "callActivity"
        else:
            a_out += 1
            a_out_e += tag == "serviceTask"
    rows.append(Row("code", "Actions on exported objects -> page calls", a_in, a_in_e))
    rows.append(Row("code", "Actions on other objects -> external tasks", a_out, a_out_e, "DESIGN" if a_out else "-",
                    "internal BP VBOs and objects not in the export: workers"))

    # 5) page interfaces and page calls
    page_in = sum(len(s.inputs) for s in by_type.get("Start", []))
    page_out = sum(len(s.outputs) for s in by_type.get("End", []))
    # an object's pages are its actions, called from OTHER artifacts' documents:
    # look at every caller's mappings, not just this document's
    in_t = all_in_targets if all_in_targets is not None else doc.in_targets
    out_s = all_out_sources if all_out_sources is not None else doc.out_sources
    page_in_e = sum(1 for s in by_type.get("Start", []) for i in s.inputs if i[2] in in_t)
    page_out_e = sum(1 for s in by_type.get("End", []) for o in s.outputs if o[1] in out_s)
    rows.append(Row("pages", "page input parameters (Start)", page_in, page_in_e, None,
                    "a declared page/action input that some call maps a value into (unused pages count as lost)"))
    rows.append(Row("pages", "page output parameters (End)", page_out, page_out_e, None,
                    "a declared page/action output that some call maps back out"))
    call_in = call_out = call_in_e = call_out_e = all_vars = 0
    for s in by_type.get("SubSheet", []):
        call_in += len(s.inputs)
        call_out += len(s.outputs)
        n = nid(s.id)
        el = doc.el_of.get(n) if n else None
        if el is None:
            continue
        ins = [e for e in el.iter() if _loc(e.tag) == "in"]
        outs = [e for e in el.iter() if _loc(e.tag) == "out"]
        if any(e.get("variables") == "all" for e in ins + outs):
            all_vars += 1
        call_in_e += min(len(s.inputs), sum(1 for e in ins if e.get("source") or e.get("sourceExpression")))
        call_out_e += min(len(s.outputs), sum(1 for e in outs if e.get("source") or e.get("sourceExpression")))
    rows.append(Row("pages", "page-call input mappings", call_in, call_in_e))
    rows.append(Row("pages", "page-call output mappings", call_out, call_out_e))
    rows.append(Row("pages", "page calls passing ALL variables", all_vars, 0,
                    "OK" if all_vars == 0 else "UNSAFE", "variables=\"all\": callee sees and may clobber every caller variable"))

    # 6) data
    datas = by_type.get("Data", [])
    colls = by_type.get("Collection", [])
    props = {}
    if doc:
        for e in doc.root.iter():
            if _loc(e.tag) == "property" and e.get("name"):
                props[e.get("name")] = e.get("value", "")
    names = {s.name for s in datas}
    rows.append(Row("data", "data items (distinct names)", len(names),
                    sum(1 for n in names if "var:" + n in props), None,
                    "declared (type + scope) in the process properties"))

    def inited(s: SrcStage) -> bool:
        """set by the Init task of its own page process, or mapped in by a caller;
        a process-wide item is initialised by the Main Page"""
        pg = bp_emit.MAIN_PAGE if not s.private else src.page_of(s)
        pid = bp_emit._nc("p", src.name + "::" + pg)
        return s.name in doc.init_names.get(pid, set()) or s.name in in_t
    priv = [s for s in datas if s.private]
    # an object action's input receivers are set by the external-task worker
    # that implements the action, never by a page call (see the pages rows)
    rows.append(Row("data", "page-private data items", len(priv),
                    sum(1 for s in priv if inited(s)) if doc.all_vars_calls == 0 else 0, None,
                    "own scope: initialised by the page's Init task or mapped in by the caller"))
    collide = sum(1 for n, c in Counter(s.name for s in datas).items() if c > 1)
    rows.append(Row("data", "names declared on >1 page", collide,
                    collide if doc.all_vars_calls == 0 else 0,
                    None if collide else "-", "isolated: each page runs in its own call-activity scope"))
    init = [s for s in datas if (s.initial or "").strip()]
    rows.append(Row("data", "initial values", len(init), sum(1 for s in init if inited(s)), None,
                    "set by an Init task (typed literal); passwords/collections never"))
    schema = sum(1 for s in colls if s.collfields)
    rows.append(Row("data", "collection schemas", schema,
                    sum(1 for s in colls if s.collfields and "collection:" + s.name in props)))

    # 7) gateways
    multi_true = no_default = 0
    if doc:
        for i, tag in doc.tag_of.items():
            if tag != "exclusiveGateway":
                continue
            outs = doc.out_of.get(i, [])
            if len(outs) < 2:
                continue
            trues = sum(1 for _, c in outs if c == "${true}")
            if trues > 1:
                multi_true += 1
            # a Decision's two flows are complementary (${E} / ${!(E)}); only a
            # Choice with 3+ conditioned branches and no default can fall through
            if len(outs) >= 3 and not doc.el_of[i].get("default") and all(c for _, c in outs):
                no_default += 1
    rows.append(Row("gateways", "gateways with >1 unconditional branch", multi_true, 0,
                    "OK" if multi_true == 0 else "BUG", "the engine takes the first; BP evaluated a condition"))
    rows.append(Row("gateways", "gateways with no default branch", no_default, 0,
                    "OK" if no_default == 0 else "RISK", "dead-ends at runtime when no condition matches"))

    # 8) loops
    loops = by_type.get("LoopStart", [])
    mi = 0
    for s in loops:
        n = nid(s.id)
        el = doc.el_of.get(n) if n else None
        if el is not None and any(_loc(e.tag) == "multiInstanceLoopCharacteristics" and
                                  any(k.endswith("collection") for k in e.attrib) for e in el.iter()):
            mi += 1
    rows.append(Row("loops", "loops iterating a resolved collection", len(loops), mi))

    # 9) exceptions
    throws = by_type.get("Exception", [])
    te = 0
    for s in throws:
        n = nid(s.id)
        el = doc.el_of.get(n) if n else None
        if el is not None and any(_loc(e.tag) == "errorEventDefinition" for e in el.iter()):
            te += 1
    rows.append(Row("exceptions", "throws as typed error events", len(throws), te))
    recs = by_type.get("Recover", [])
    bnd = sum(1 for s in recs if bp_emit._nc("bnd", s.id) in doc.tag_of) if doc else 0
    evs = sum(1 for s in recs if bp_emit._nc("evsub", s.id) in doc.tag_of) if doc else 0
    rows.append(Row("exceptions", "Recover as boundary event / event subprocess", len(recs), bnd + evs, None,
                    "the rest are placeholder tasks (page-scoped Recover)"))
    return rows, detail


def merge(all_rows: list[list[Row]]) -> list[Row]:
    acc: dict[tuple, Row] = {}
    order: list[tuple] = []
    for rows in all_rows:
        for r in rows:
            k = r.key()
            if k not in acc:
                acc[k] = Row(r.section, r.item, 0, 0, "-", r.note)
                order.append(k)
            a = acc[k]
            a.source += r.source
            a.emitted += r.emitted
    # recompute verdicts from totals, keeping the fixed-verdict rows' labels
    sections = ["stages", "flow", "expressions", "parameters", "code", "pages", "data",
                "gateways", "loops", "exceptions"]
    pos = {k: i for i, k in enumerate(order)}
    order.sort(key=lambda k: (sections.index(k[0]) if k[0] in sections else 99, pos[k]))
    out = []
    for k in order:
        a = acc[k]
        fixed = {r.key(): r for rows in all_rows for r in rows if r.verdict in
                 ("DESIGN", "BUG", "RISK", "UNSAFE", "COLLISION")}
        if k in fixed and a.source > 0:
            a.verdict = fixed[k].verdict
        elif a.source == 0:
            a.verdict = "-"
        elif a.emitted >= a.source:
            a.verdict = "OK"
        elif a.emitted == 0:
            a.verdict = "LOST"
        else:
            a.verdict = "PARTIAL"
        out.append(a)
    return out


def render(rows: list[Row], title: str) -> str:
    lines = [f"## {title}", "", "| section | item | source | emitted | lost | verdict | note |",
             "|---|---|---:|---:|---:|---|---|"]
    for r in rows:
        if r.source == 0 and r.emitted == 0:
            continue
        lines.append(f"| {r.section} | {r.item} | {r.source} | {r.emitted} | {r.source - r.emitted} | {r.verdict} | {r.note} |")
    return "\n".join(lines)


def summary(rows: list[Row]) -> dict:
    return {f"{r.section}/{r.item}": [r.source, r.emitted, r.verdict] for r in rows if r.source or r.emitted}


def run(paths: list[Path], ns: str, include_objects: bool):
    est = Estate()
    parse_paths(bp_core._collect([str(p) for p in paths]), est)
    docs = bp_emit.emit_all(est, ns, include_objects)
    bpmn = {name: Bpmn(xml) for name, xml in docs.items()}
    results = []
    srcs = read_source(bp_core._collect([str(p) for p in paths]))
    names = {a.name for a in srcs if a.type == "object"}
    all_in = set().union(*(b.in_targets for b in bpmn.values())) if bpmn else set()
    all_out = set().union(*(b.out_sources for b in bpmn.values())) if bpmn else set()
    for src in srcs:
        fname = (bp_emit._nc("", src.name).strip("_") or "process") + ".bpmn"
        doc = bpmn.get(fname)
        if doc is None:
            continue       # objects are audited only with --objects, like the emitter
        rows, detail = audit_artifact(src, doc, names, all_in, all_out)
        results.append((src, rows, detail))
    return results


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="bp_equiv",
                                 description="Blue Prism -> BPMN equivalence audit")
    ap.add_argument("inputs", nargs="*", help="export files or directories")
    ap.add_argument("--objects", action="store_true", help="audit objects too (as bp_emit --objects)")
    ap.add_argument("--ns", choices=sorted(bp_emit.EXT_NS), default="fluxnova")
    ap.add_argument("--per-artifact", action="store_true", help="one table per artifact before the total")
    ap.add_argument("--json", help="write the totals + failure histograms here")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--bake", action="store_true", help="(build only) print the selftest summary")
    a = ap.parse_args(argv)

    if a.selftest or a.bake:
        with tempfile.TemporaryDirectory() as d:
            for name, xml in bp_emit.EMBEDDED_FIXTURES.items():
                (Path(d) / name).write_text(xml, encoding="utf-8")
            res = run([Path(d)], "fluxnova", False)
        total = merge([r for _, r, _ in res])
        got = summary(total)
        if a.bake:
            print(json.dumps(got, indent=1, sort_keys=True))
            return 0
        if got == EXPECTED_SUMMARY:
            print("SELFTEST PASS")
            return 0
        print("SELFTEST FAIL - this copy does NOT match the tested original")
        for k in sorted(set(got) | set(EXPECTED_SUMMARY)):
            if got.get(k) != EXPECTED_SUMMARY.get(k):
                print(f"  {k}: got {got.get(k)} want {EXPECTED_SUMMARY.get(k)}")
        return 1

    if not a.inputs:
        ap.error("give export files/directories, or --selftest")
    res = run([Path(p) for p in a.inputs], a.ns, a.objects)
    if not res:
        print("no artifacts audited (objects need --objects)", file=sys.stderr)
        return 2
    if a.per_artifact:
        for src, rows, _ in res:
            print(render(rows, f"{src.name} ({src.type})"))
            print()
    total = merge([r for _, r, _ in res])
    print(render(total, f"TOTAL over {len(res)} artifact(s)"))
    fns = Counter()
    reasons = Counter()
    links = Counter()
    for _, _, d in res:
        fns.update(d["failed_functions"])
        reasons.update(d["failed_reasons"])
        links.update(d["unmatched_links"])
    if fns:
        print("\nfunctions in failed expressions: " +
              ", ".join(f"{k} x{v}" for k, v in fns.most_common()))
    if reasons:
        print("failure reasons: " + ", ".join(f"{k} x{v}" for k, v in reasons.most_common()))
    if links:
        print("unmatched links by type: " + ", ".join(f"{k} x{v}" for k, v in links.most_common(12)))
    if a.json:
        Path(a.json).write_text(json.dumps({
            "total": summary(total),
            "per_artifact": {s.name: summary(r) for s, r, _ in res},
            "failed_functions": dict(fns), "failure_reasons": dict(reasons),
            "unmatched_links": dict(links)}, indent=1), encoding="utf-8")
    return 0


# Baked selftest summary over bp_emit's embedded synthetic fixtures.
EXPECTED_SUMMARY: dict = {
    "code/Actions on exported objects -> page calls": [
        2,
        2,
        "OK"
    ],
    "code/Actions on other objects -> external tasks": [
        1,
        1,
        "DESIGN"
    ],
    "data/collection schemas": [
        2,
        2,
        "OK"
    ],
    "data/data items (distinct names)": [
        13,
        13,
        "OK"
    ],
    "data/initial values": [
        7,
        7,
        "OK"
    ],
    "data/page-private data items": [
        8,
        7,
        "PARTIAL"
    ],
    "exceptions/Recover as boundary event / event subprocess": [
        5,
        4,
        "PARTIAL"
    ],
    "exceptions/throws as typed error events": [
        4,
        4,
        "OK"
    ],
    "expressions/action-input": [
        3,
        3,
        "OK"
    ],
    "expressions/calculation": [
        11,
        11,
        "OK"
    ],
    "expressions/decision": [
        4,
        4,
        "OK"
    ],
    "expressions/exception-detail": [
        4,
        2,
        "PARTIAL"
    ],
    "flow/dead-end nodes (no outflow)": [
        1,
        0,
        "BUG"
    ],
    "flow/links (anchors dissolved)": [
        47,
        31,
        "PARTIAL"
    ],
    "loops/loops iterating a resolved collection": [
        3,
        3,
        "OK"
    ],
    "pages/page input parameters (Start)": [
        1,
        1,
        "OK"
    ],
    "pages/page output parameters (End)": [
        1,
        1,
        "OK"
    ],
    "pages/page-call input mappings": [
        1,
        1,
        "OK"
    ],
    "pages/page-call output mappings": [
        1,
        1,
        "OK"
    ],
    "parameters/Action inputs": [
        2,
        0,
        "LOST"
    ],
    "parameters/Action outputs": [
        2,
        0,
        "LOST"
    ],
    "stages/Action": [
        3,
        3,
        "OK"
    ],
    "stages/Block": [
        3,
        3,
        "OK"
    ],
    "stages/Calculation": [
        7,
        7,
        "OK"
    ],
    "stages/Decision": [
        4,
        4,
        "OK"
    ],
    "stages/End": [
        8,
        7,
        "PARTIAL"
    ],
    "stages/Exception": [
        4,
        4,
        "OK"
    ],
    "stages/LoopEnd": [
        3,
        0,
        "DESIGN"
    ],
    "stages/LoopStart": [
        3,
        3,
        "OK"
    ],
    "stages/MultipleCalculation": [
        2,
        2,
        "OK"
    ],
    "stages/Recover": [
        5,
        5,
        "OK"
    ],
    "stages/Resume": [
        4,
        4,
        "OK"
    ],
    "stages/Start": [
        9,
        9,
        "OK"
    ],
    "stages/SubSheet": [
        3,
        3,
        "OK"
    ]
}


if __name__ == "__main__":
    sys.exit(main())
