# `port/` — getting the pipeline onto the air-gapped laptop

The real Blue Prism releases live only on a locked laptop that takes **nothing in
or out** — no files, ever. Code gets there by being **typed / Copilot-generated on
that machine**, and results come back as **screen photos**. This directory is how
we cross that gap safely.

## What's here

| file | what it is |
|---|---|
| `build.py` | Generator for Layer 1. Amalgamates `src/bp_estate/{model,parse,regions}.py`. **Run here**, never on the locked laptop. |
| `bp_core.py` | **Generated** Layer 1 — structural analyzer (parse + regions). Stdlib only, Python 3.11+, no pip, no config. Reproduce this on the locked laptop first. |
| `build_full.py` | Generator for Layer 2. Adds detect + analyze + score + the inlined configs. **Run here.** |
| `bp_full.py` | **Generated** Layer 2 — the full pipeline. Imports `bp_core.py`, adds enrichment (tiers, queues/creds/locks, PII, edges, dead code, duplicates, scores, waves). Stdlib only (a graph shim replaces `networkx`; the YAML configs are inlined). Reproduce this *after* `bp_core.py`. |

Both `bp_core.py` and `bp_full.py` are generated — **never hand-edit them.** Change
`src/bp_estate/*.py` (or `data/*.yaml`), then rerun `python port/build.py` and
`python port/build_full.py`.

## What `bp_core.py` does (and doesn't)

It runs the **structural** pipeline: `parse` → `regions`. That covers everything
we've ground-truthed on real data — stages, links, geometry, loops, exception
handlers with **Block-containment scope**, cross-page propagation, applications,
data items, collections, code-stage blockers.

It does **not** run the config-driven enrichment (`detect`/`analyze`/`score`):
edges, scores, PII flags, object tiers, dead code. Those need PyYAML + three YAML
config files, neither of which exists on a no-pip, no-file-transfer laptop. They
are **Layer 2** — folded in later once the configs are converted to inline Python.
The `estate.json` `bp_core.py` produces is schema-shaped: the Layer-2 sections are
present but empty, ready to be filled.

## The self-test is the whole point

`bp_core.py` carries baked-in fixtures **and the exact `estate.json` they must
produce**. `--selftest` reproduces that golden and prints `PASS` / `FAIL`.

A wrong retype **cannot** reproduce the baked-in golden, so:

> **`SELFTEST PASS` on the locked laptop proves the copy there is byte-faithful to
> what is tested here.** No file needs to cross the gap to verify it.

On `FAIL` it prints the first differing line — that tells you which chunk of the
retype drifted, so you fix just that spot and re-run.

## Procedure

**Here (this laptop):**
1. `python port/build.py` — regenerates `bp_core.py` and confirms it self-tests
   green. Do this after any change to the source modules.

**On the locked laptop:**
2. Reproduce `bp_core.py` there — type it, or drive Copilot to write it out
   **verbatim** (verbatim, not "reimplement from a description": the parser is
   exact, and a paraphrase will fail the self-test). One file, so there's exactly
   one thing to get right.
3. `python bp_core.py --selftest` → must print **`SELFTEST PASS`**. If it fails,
   fix the line it points at and repeat. Do not proceed until it passes.
4. `python bp_core.py <release.bprelease> -o estate.json` — runs the full
   structural pipeline on the real release, locally. `estate.json` stays on the
   laptop.
5. To see results here, run `python bp_core.py <release.bprelease> --summary` and
   photograph that. It prints **counts and generic Blue Prism type names only**
   (stage-type histogram, loop/handler/scope counts) — no process/stage/field
   names, no expressions. **Never** photograph raw `estate.json`; it contains
   bank IP. The self-test certifies the summary too, so a `PASS` in step 3 means
   the numbers you photograph are faithful.

## Layer 2 (`bp_full.py`) — the full pipeline

Reproduce `bp_full.py` on the laptop the same way, **after** `bp_core.py` passes
(it does `import bp_core`, so both files live in the same directory). Then:

```
python bp_full.py --selftest                       # must print SELFTEST PASS
python bp_full.py <release.bprelease> -o estate.json
python bp_full.py <release.bprelease> --summary     # numbers-only, photograph this
```

`bp_full.py` produces the **complete** `estate.json` (edges, scores, blockers,
tiers, PII flags, waves) — the input the migration emitter will consume.

Its self-test works differently from Layer 1's. Instead of one big text golden it
checks **hashes**: a per-object hash of each config literal, and a per-section hash
of the output. So a `FAIL` names *what* drifted, not an exact line:
- `mismatch: config registry:object:Work Queues` → a typo in that object in the
  `CONFIG_REGISTRY` literal. Re-check that one object.
- `mismatch: config weights` / `config pii` → a typo in that config literal.
- `mismatch: estate section 'scores'` → a typo in the **code** that fills that
  section (here, `score_run`). Ask for the correct code of that piece to compare.

This is why there's no 460-line JSON answer key to type — the hashes catch every
config-data and code typo with section/object locality instead.

## Rebuilding / keeping it honest

`tests/test_port.py` asserts, on every test run:
- `bp_core.py --selftest` and `bp_full.py --selftest` both pass;
- `bp_full.py` on the fixtures reproduces the canonical golden **byte-for-byte**
  (proves the `networkx` shim + inlined config still match the real pipeline);
- regenerating both bundles from source is **byte-identical** (not stale / not
  hand-edited).

If a staleness test fails, run `python port/build.py` and `python port/build_full.py`
and commit the result.
