# RESTORE

Internal names were replaced before this zip was built. Put them back
with the key you have on your side (RESTORE-KEY.md was NOT shipped):

- `__H1__` occurs in: tests/test_render_doc.py
- `__H2__` occurs in: tests/test_render_doc.py
- `__H5__` occurs in: tests/test_render_doc.py, tools/render_doc.py
- `__H6__` occurs in: tests/test_render_doc.py

Then: `python selftest.py` must still print MANIFEST OK (the manifest was taken
BEFORE restoring, so re-run it before you restore, not after) and the five
SELFTEST PASS lines.
