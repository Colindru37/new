import glob
import xml.etree.ElementTree as ET
from collections import defaultdict, Counter


def loc(t):
    return t.split('}')[-1]


NODE = {'startEvent', 'endEvent', 'task', 'serviceTask', 'callActivity',
        'exclusiveGateway', 'subProcess', 'boundaryEvent'}

orph_total = dead_total = 0
by_container = Counter()
by_type = Counter()
examples = []

for f in glob.glob('out_bpmn/*.bpmn'):
    root = ET.fromstring(open(f, encoding='utf-8').read())
    for proc in [e for e in root.iter() if loc(e.tag) == 'process']:
        container, ev, nodes, names = {}, set(), {}, {}
        for parent in proc.iter():
            pn = loc(parent.tag)
            if pn not in ('process', 'subProcess'):
                continue
            if pn == 'subProcess' and parent.get('triggeredByEvent') == 'true':
                ev.add(parent.get('id'))
                tag = 'event-subprocess'
            elif pn == 'subProcess':
                tag = 'subprocess'
            else:
                tag = 'top-level'
            # DIRECT children only: parent.iter() walks every descendant, and
            # since the process is visited first it would claim the whole tree
            # as 'top-level' and hide which region a node really sits in.
            for ch in parent:
                if loc(ch.tag) in NODE and ch.get('id'):
                    container[ch.get('id')] = tag
        inc = defaultdict(int)
        out = defaultdict(int)
        for el in proc.iter():
            n = loc(el.tag)
            if n in NODE and el.get('id'):
                nodes[el.get('id')] = n
                names[el.get('id')] = el.get('name') or ''
            if n == 'sequenceFlow':
                out[el.get('sourceRef')] += 1
                inc[el.get('targetRef')] += 1
        for i, t in nodes.items():
            if t in ('startEvent', 'boundaryEvent') or i in ev:
                continue
            if inc[i] == 0:
                orph_total += 1
                by_container[container.get(i, 'UNKNOWN')] += 1
                by_type[t] += 1
                if len(examples) < 15:
                    examples.append((t, container.get(i, '?'), names[i][:34]))
            if out[i] == 0 and t != 'endEvent':
                dead_total += 1

print("ORPHANS:", orph_total, "  DEAD ENDS:", dead_total)
print("  by container:", dict(by_container))
print("  by type     :", dict(by_type))
print("  examples:")
for e in examples:
    print("     ", e)
