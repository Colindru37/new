# Handoff — running this on the working laptop

A cold-start runbook for moving this toolchain to the laptop that can actually
see the exports, and picking it up with GitHub Copilot. `README.md` is the design
root; this is the "what do I type" companion. Nothing here calls a model — the
tools are plain Python. Where a model *is* needed it is called out explicitly.

---

## 1. What moves

No git on the new laptop — nothing is cloned. Two things travel by hand (USB, the
Z: drive, or a zip you copy across):

1. **The project folder** — copy the whole `blueprism-camunda-migration` folder as
   it is. It is just Python source + data files; it holds no bank data (exports,
   coding-rule photos, and dropped photos are git-ignored, so they aren't in the
   folder unless you added them). You can copy the `.git` subfolder or delete it —
   nothing here needs git to run. Skip `.venv/` if it came along; you rebuild it
   fresh on the new laptop (step 2).
2. **The real `.bprelease` / `.bpobject` files** — copy these across separately
   into a local folder (e.g. `exports/`). The tools read the export XML directly;
   you do **not** need Blue Prism, a licence, or a database on this laptop.

If you cannot get the export off the source laptop yet, the toolchain still runs
on `tests/fixtures/` — enough to prove the setup works before real data lands.

## 2. Setup (Windows, Python 3.11+)

Open PowerShell in the copied folder (`cd` into wherever you put it), then:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -q          # expect: all pass -> setup is good
```

**No Python and can't install it?** Grab the **Windows embeddable package** zip
from python.org (a folder you unzip, not an installer — usually allowed where MSIs
are blocked) and run `.\python.exe` from it. `diff_objects.py`, `render_compare.py`,
`render_doc.py` and `render_audit.py` are stdlib-only and run on it as-is.
`audit_rules.py` needs **pyyaml**, and `bp-estate analyze` needs **pyyaml +
jsonschema + networkx** — all pure-Python, so on a locked-down box you can unzip
each package's folder next to `python.exe` (no compiler, no MSI). Only the test
suite and the optional `lxml` ever need `pip`. If even that is blocked, ask me for
a single standalone `.exe`.

## 3. The split (what Python does vs what the model does)

- **Python (this repo)** does everything mechanical and everything that must be
  exact: parsing, the coding-rules audit, the version diff, the completeness
  ledgers, and rendering every HTML page. It never guesses and never calls a model.
- **The model (Gemini Code Assist / Copilot)** is only needed for the two things a
  parser genuinely can't do: the *prose* halves — a process's business
  description (05) and the "why each change was made" explanation (06). It emits
  **JSON**, which `verify_llm_output.py` gates against the parsed facts, and which
  the renderers turn into pages. In the bank environment the model **cannot write
  files** — it generates the JSON in chat, you save it, the Python renders it.
- **Screenshots are manual.** No tool captures them (a screenshot is a picture of
  the live app, not in the XML). The doc renderer emits a labelled **slot** naming
  the exact Z: file to drop in — `<Application> - <what it shows>.png` — and a
  running count of how many are still owed.

## 4. The three workflows

Replace `<export>` with a real file or `tests\fixtures\customer_object.bpobject`.
Every render tool exits non-zero if its verdict fails, so it is CI-safe.

### A. Coding-rules audit (one object) — deterministic, no model

```powershell
.\.venv\Scripts\python.exe tools\audit_rules.py <export> -o out\findings.json
.\.venv\Scripts\python.exe tools\render_audit.py out\findings.json -o out\audit.html
```
`out\audit.html` = findings by rule over every in-scope stage. `fix_mechanical.py`
can apply the findings whose corrected value is computable.

### B. Object comparison (two versions) — deterministic; model only for prose

Direction is fixed: **base overwrites target.** Put the good version first.

`diff_objects.py` compares **one artifact against one artifact** — it refuses a
whole `.bprelease` (which holds many). If all you have is the release, split it
first; each file it writes is a normal single export:

```powershell
.\.venv\Scripts\python.exe tools\extract_release.py <release>.bprelease -o out\objects
#   -> out\objects\<Artifact Name>.bpobject / .bpprocess, one per artifact
#   (--list to preview without writing). audit + analyze take the release whole,
#   so this splitting step is only needed for diff and per-object docs.
```

Then compare two versions of the same object:

```powershell
.\.venv\Scripts\python.exe tools\diff_objects.py <base> <target> -o out\compare
.\.venv\Scripts\python.exe tools\render_compare.py out\compare\changes.json `
    -o out\compare\report.jira --html out\compare\report.html
```
`report.jira` = paste into JIRA; `report.html` = read in a browser. To add the
business "why" per change, feed `out\compare\changes.txt` through
`prompts\06-objects-comparison.md`, then re-render with `--ai-assisted`.

### C. Process documentation — analyze, then two model passes, then render

```powershell
# 1. deterministic facts (dependencies, config tables, the stage ledger)
.\.venv\Scripts\python.exe -m bp_estate analyze <export> -o out

# 2. MODEL pass, prompt 04, ONCE PER PAGE -> save each as specs\<page>.json
#    verify each before trusting it:
.\.venv\Scripts\python.exe tools\verify_llm_output.py specs\<page>.json <export>

# 3. MODEL pass, prompt 05, over all verified specs -> save doc.json
#    verify with --specs so a DROPPED section is caught, not just a duplicate:
.\.venv\Scripts\python.exe tools\verify_llm_output.py doc.json <export> --specs specs

# 4. render the page (verdict + house layout + screenshot slots)
.\.venv\Scripts\python.exe tools\render_doc.py doc.json <export> --specs specs -o out\doc.html
```
`render_pack.py doc.json <export> --specs specs -o out\pack.html` bundles the
spec, screens and doc into one document instead of a page each.

## 5. Handing it to Copilot

Point Copilot at `PROGRAMME.md` (the plan) and `prompts\README.md` (how the model
prompts are built to be script-checkable). The useful jobs for it here are:

- **When a real export breaks the parser** — big bank objects use stage types and
  constructs `tests/fixtures/` never had. The failure mode to hunt is a **silent
  skip**, not a crash: a diff that looks clean because the parser didn't
  understand half the page. Fix at source in `src/bp_estate/parse.py` (the
  `_facts()` extraction) or `data/vbo_registry.yaml`, and add a fixture that
  reproduces it. Never loosen a check to make output look clean.
- **Running the model prompts** (04, 05, 06) and saving the JSON they emit.
- **Do not** start the uFlow migration emitter — it's blocked until we know what
  uFlow ingests (see `README.md` "Blocked").

The deterministic core is done and tested (run `pytest`); Copilot's job is the
model-side JSON and teaching the parser new real-world shapes, not rewriting the
tools.

## 6. Security (non-negotiable)

Real exports, the coding-rule photos (`rules/`, `rule/`), and dropped photos
(`convo/`) are bank IP and are **git-ignored**. Never commit them, never force-add
them, never paste their contents into a cloud tool. Credential and `Password`
values are never printed by any tool — keep it that way.
