---
name: copilot-discipline
description: Working method for a coding assistant (GitHub Copilot, Gemini Code Assist, any model) on this estate's engineering tasks. Use at the start of EVERY task that touches code, exports, configs or documents: it dictates the order of work (map, ask, plan, do, verify, report) and the rules that stop the usual failures (guessing, partial measurement, flagged-but-shipped hazards, self-grading). Project skills (rpa-bp, bp-to-camunda) sit on top of this one.
---

# Skill: how to work

You are not asked for an answer. You are asked for a result that survives
contact with the real system, and a report that says exactly how far it got.
Everything below exists because the opposite happened and cost days.

## 1. Order of work -- always this order

1. **Map** before you touch. Inventory what exists: files, stage types, objects,
   configs, who calls whom. Write the map down (a table or a list), even for a
   "one-liner". Most wrong fixes come from editing the second copy of something,
   or the generated file instead of its source.
2. **Ask** what you cannot derive. One message, numbered questions, your
   proposed default next to each. Never pick a silent default for anything that
   touches data, money, accounts, external systems or someone else's time.
3. **Plan** in writing: the steps, the files each step changes, the check that
   proves each step. If a step has no check, it is not a step yet.
4. **Do** the smallest change that satisfies the plan. Match the surrounding
   code's style; do not refactor what you were not asked to touch.
5. **Verify** with an instrument that is not you (section 3).
6. **Report** (section 4).

Skipping 1-3 because the task "looks small" is the single most frequent cause of
rework on this estate.

## 2. Maps

- A map is an artefact: a markdown table in the chat or a file, not a sentence.
- Minimum maps: *what calls what* (processes -> pages -> objects -> actions),
  *what is generated from what* (never edit the generated side), *what runs where*
  (laptop, VM, engine, bank network), *what is configuration* (INI keys, env
  vars, element names) vs code.
- Before changing any loop over "all rows/items/files", put the real count in
  the map. 10 rows and 1078 rows are different programs.
- Before building a mock or fixture, map it from the REAL thing (a page dump, an
  export, a screenshot), not from your reading of the code that uses it. A mock
  built from the code can only confirm the code.

## 3. Verification rules

- **The judge must be older than the code it judges.** If the test, fixture or
  comparison script is as new as the change, suspect the judge first when it
  fails -- and when it passes.
- **Never grade your own translation.** Run the original against the
  replacement on the same inputs (the oracle pattern: original code compiled
  and run; the real page; the previous version's output). A diff is evidence;
  "it should be equivalent" is not.
- **Measure the gap, not the success.** "0 orphan nodes" says nothing about what
  was dropped. Count what went in against what came out, per category, and
  report the LOST rows, not the OK rows.
- **Execute the real path before saying ready.** Deploy it, run it, open the
  file, start the process. Checking inputs is not testing.
- **A hazard you named is a bug you own.** If your own analysis flags "this may
  break when X" and X is cheap to pre-empt, pre-empt it in the same change. A
  caption in a report that ships the hazard anyway has caused every UAT failure
  of the last month.
- **Fail loud, never guess.** When a mapping, function or value has no exact
  equivalent, leave an explicit TODO that cannot run silently (a throw, an
  unresolvable placeholder), say so in the report, and move on. A plausible
  invention that runs is the worst outcome.
- **Positive control first.** Before trusting a measurement, feed it a case
  whose answer you know. If the instrument cannot see a planted defect it cannot
  see the real ones.
- **Size it.** Rows, files, calls per row, minutes per run. Ask for the real
  number when you do not have it.

## 4. Reporting

- Lead with the verdict and its evidence: `PASS 5/5 cases (tool X output)`,
  `FAIL case 4: got ... want ...`, `NOT RUN: no engine available`.
- Then the map of what changed: file, what, why -- one line each.
- Then divergences and open items, each with the reason it is open and what
  resolves it. Never bury a skipped step; name it.
- Numbers over adjectives. "Most", "should", "probably" are flags that a
  measurement is missing -- replace them with the number or with "not measured".
- Anything a person must do before running (config edits, INI keys, a
  personalised view, a credential) goes FIRST in the report as a checklist, not
  last as a note.

## 5. Things that are never acceptable

- Editing a generated file instead of its generator (look for "GENERATED" in the
  header; `port/*.py` here, `bp_core.py` especially).
- Loosening a check to make an output look clean.
- Removing a feature to stop it from failing. Solve it or leave it failing with
  a TODO; do not amputate.
- Pasting bank data, exports, credentials or internal names into any tool
  outside the bank network. Replace with placeholders before anything leaves.
- Declaring something done that you did not run.

## 6. Estate-specific pointers

- Blue Prism authoring / Python->BP: skill `rpa-bp` (`skill-rpa-bp/SKILL.md`).
- Blue Prism->Camunda/Fluxnova finishing work: skill `bp-to-camunda`
  (`skill-bp-to-camunda/SKILL.md`): the emitter is deterministic, you fill slots
  and workers, the gate (`tools/slot_oracle.py` + `tools/slot_check.py`) grades you.
- Measurement of a converted process: `port/bp_equiv.py`. Engine check:
  `tools/c7_runtime_check.py`.
- The air-gapped laptop: files cross only as retyped/regenerated text verified
  by `--selftest`; `SELFTEST PASS` is the only proof a copy is faithful.

## 7. GitHub Copilot on this estate -- known failure modes (observed, with the fix that worked)

These were all seen on the bank laptop (Copilot Chat in VS Code / Copilot Studio,
Claude and GPT models behind it). Each one has a counter-move; apply it before
the failure, not after.

| what Copilot did | when it bites | counter-move |
|---|---|---|
| **Answered from documentation, as fact.** "Blue Prism exception catch is link-flow" -- plausible, cited, wrong. Real exports showed every Recover has NO inbound link (catch is Block containment). A model built on that answer had to be thrown away. | any question about how a system *really* behaves | ask it to **show the evidence in the export/code** ("quote the element"), then run a counts-only probe on the real data before building on the answer. A doc paraphrase is a hypothesis. |
| **Paraphrased when asked for verbatim.** Retyping a file "from the description" produced a near copy that failed `--selftest`. | any transfer of code into the laptop by Copilot | demand verbatim, in chunks of <=150 lines, then `python <file> --selftest` -- `PASS` is the only acceptance. On `FAIL` fix the line it names, do not regenerate the file. |
| **Optimistic evaluations.** A long "is the migrated object equivalent?" answer read well and missed 14 categories of loss; the same question as *"one short answer, no formatting, with all the missing details, flaws and other mistakes"* produced the honest list. | any "is this correct / complete / equivalent?" | never ask open-ended; ask for the flaw list, bounded ("one short answer"), and run the deterministic measurement (`bp_equiv.py`, `audit_rules.py`, `bpmn_lint.py`) first -- then ask Copilot only about what the tools cannot see. |
| **Cannot write files in the bank environment.** It generates in chat; the person saves. Long outputs get cut or "..."-elided. | JSON/XML/code generation | ask for one file per answer, state the exact filename and the first and last line expected, and verify with the verifier (`verify_llm_output.py`, `--selftest`, `bpmn_lint.py`) before using. |
| **Context decay around ~70% of the window** (seen at ~735k tokens): earlier instructions silently drop, it re-answers with defaults. | long sessions | restart the chat with the map (section 2) and the skill file pasted first; never carry a day's work in one thread. |
| **Invents helper names** (VBO action names, element names, API endpoints) that look right. | anything that must match an existing contract | give it the list (`reference/estate-objects.md`, the export) and say "only these"; grep the output against the list. |
| **Edits the generated artefact** (`bp_core.py`, an emitted `.bpmn`) instead of the source, because that is the file open in the editor. | any fix in a generated file | state which file is the source in the prompt; after the edit, regenerate and diff. |
| **Rewrites surrounding code "while here".** | any edit | "change only lines X-Y; do not touch anything else"; review the diff, not the file. |
| **Windows/PowerShell quoting and CRLF**: here-strings break on embedded `"`, generated files come back CRLF and change hashes. | commits, hashes, selftests | commit messages via `-F file`; normalise line endings before hashing (`.gitattributes` pins LF). |
| **"Think deeper" is the only mode that reasons structurally**; the default answers fast and shallow. | parsing/mapping/design questions | switch it on for anything that is not a lookup. |
| **Slow or stalled turns on preview models** look like a hang. | long generations | wait it out or re-ask with a smaller unit; do not fire the same prompt twice (duplicate half-answers). |
| **It grades its own translation as correct.** | code ports, mappings | the oracle pattern: run the original and the replacement on the same cases (`tools/slot_oracle.py` + `tools/slot_check.py`). Copilot proposes cases; the tools decide. |

Rule behind all of them: Copilot is a generator, not an authority. Everything it
says about *how things are* gets checked against the real artefact; everything
it *produces* gets checked by a tool that did not come from the same prompt.
