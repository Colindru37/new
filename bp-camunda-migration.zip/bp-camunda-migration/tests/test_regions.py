"""Structured control-flow regions (loops + exception handlers).

Pins the two things a migration emitter needs lifted out of the flat stage
graph: a LoopStart/LoopEnd pair recognised as one for-each over a collection,
and a Recover stage recognised as an exception handler with its recovery path.
Stage shapes here match the real scrubbed XML (<groupid>/<loopdata>, stage-level
<onsuccess>, <exception type detail>).
"""
from pathlib import Path

from bp_estate import regions
from bp_estate.model import Estate
from bp_estate.parse import parse_file

FIX = Path(__file__).parent / "fixtures" / "loops_and_recovery.bpprocess"


def _analyzed() -> Estate:
    est = Estate()
    parse_file(FIX, est)
    regions.run(est)
    return est


# --- parser captured the new structural attributes ------------------------- #

def test_loopstart_attributes_parsed():
    est = Estate()
    parse_file(FIX, est)
    ls = {s.name: s for s in est.stages_by_artifact["Loops And Recovery"]}["For Each Item"]
    assert ls.group_id == "grp-loop-1"
    assert ls.loop_data == "[Work Items]"
    assert ls.loop_type == "collection"


def test_exception_throw_attributes_parsed(tmp_path):
    """An Exception stage carries <exception type=".." detail=".."/>."""
    xml = ('<process name="E" preferredid="e1" published="true">'
           '<stage stageid="t" name="Throw" type="Exception">'
           '<exception type="Business Exception" detail="[msg]"/>'
           '</stage></process>')
    p = tmp_path / "e.bpprocess"
    p.write_text(xml, encoding="utf-8")
    est = Estate()
    parse_file(p, est)
    thr = est.stages_by_artifact["E"][0]
    assert thr.exception_type == "Business Exception"
    assert thr.exception_detail == "[msg]"


# --- loop regions ---------------------------------------------------------- #

def test_loop_region_pairs_by_groupid():
    est = _analyzed()
    assert len(est.loop_regions) == 1
    lr = est.loop_regions[0]
    assert lr.start_stage == "For Each Item"
    assert lr.end_stage == "Next Item"          # paired via <groupid>, not guessed
    assert lr.resolved is True


def test_loop_region_captures_collection_and_body():
    est = _analyzed()
    lr = est.loop_regions[0]
    assert lr.collection == "[Work Items]"
    assert lr.body_stage_count == 1             # just "Compute Row" between the brackets


def test_unmatched_loopstart_is_flagged_not_dropped(tmp_path):
    """A LoopStart whose LoopEnd is missing is a defect to surface, not silence."""
    xml = ('<process name="U" preferredid="u1" published="true">'
           '<stage stageid="a" name="Lonely Loop" type="LoopStart">'
           '<groupid>g9</groupid><loopdata>[X]</loopdata><onsuccess>b</onsuccess></stage>'
           '<stage stageid="b" name="Body" type="Calculation"><onsuccess>a</onsuccess>'
           '<calculation expression="1" stage="Y"/></stage></process>')
    p = tmp_path / "u.bpprocess"
    p.write_text(xml, encoding="utf-8")
    est = Estate()
    parse_file(p, est)
    regions.run(est)
    assert len(est.loop_regions) == 1
    assert est.loop_regions[0].resolved is False
    assert est.loop_regions[0].end_stage is None


# --- exception handlers ---------------------------------------------------- #

def test_recover_becomes_a_handler_with_its_recovery_path():
    est = _analyzed()
    assert len(est.exception_handlers) == 1
    h = est.exception_handlers[0]
    assert h.recover_stage == "On Error"
    assert h.resumes is True                    # the path reaches a Resume
    assert h.escapes is False                   # ...so nothing propagates
    assert h.recovery_path == ["Log Error", "Resume Flow"]


def test_recover_scope_is_the_enclosing_block():
    """TRY scope is geometric: the Recover sits inside the Guarded Block, which
    becomes the protected scope. The Block holds the loop bracket + body + the
    Recover itself (4 stages, the container excluded); the Resume is placed
    OUTSIDE the Block and is not counted."""
    est = _analyzed()
    h = est.exception_handlers[0]
    assert h.scope_kind == "block"
    assert h.scope_block == "Guarded"
    assert h.scope_stage_count == 4             # loop start/body/end + Recover; Block & Resume excluded


def test_recover_display_is_a_point_not_a_container():
    """Real Recover stages carry x,y but no w,h — they cannot self-scope."""
    est = Estate()
    parse_file(FIX, est)
    rc = {s.name: s for s in est.stages_by_artifact["Loops And Recovery"]}["On Error"]
    assert (rc.x, rc.y) == (0.0, 180.0)
    assert rc.w is None and rc.h is None


def test_recover_outside_any_block_is_page_scoped(tmp_path):
    """The lone top-level / last-resort Recover (in no Block) protects the whole
    page — scope_kind 'page', no block, count = every stage on the page."""
    xml = ('<process name="P" preferredid="p1" published="true">'
           '<stage stageid="s" name="Start" type="Start">'
           '<display x="0" y="0"/><onsuccess>r</onsuccess></stage>'
           '<stage stageid="r" name="Last Resort" type="Recover">'
           '<display x="0" y="45"/><onsuccess>e</onsuccess></stage>'
           '<stage stageid="e" name="End" type="End"><display x="0" y="90"/></stage>'
           '</process>')
    p = tmp_path / "p.bpprocess"
    p.write_text(xml, encoding="utf-8")
    est = Estate()
    parse_file(p, est)
    regions.run(est)
    h = est.exception_handlers[0]
    assert h.scope_kind == "page"
    assert h.scope_block is None
    assert h.scope_stage_count == 3             # Start, Recover, End — the whole page


def test_recovery_path_stops_at_resume():
    """The handler region must not bleed past Resume into normal flow (the End
    stage after Resume is not part of the recovery path)."""
    est = _analyzed()
    h = est.exception_handlers[0]
    assert "End" not in h.recovery_path


XPAGE = Path(__file__).parent / "fixtures" / "cross_page_recovery.bpprocess"


def _xpage() -> Estate:
    est = Estate()
    parse_file(XPAGE, est)
    regions.run(est)
    return est


# --- cross-page propagation ------------------------------------------------ #

def test_escape_surfaces_at_the_calling_page():
    """The Do Work subpage escapes (its Recover never Resumes); the exception
    surfaces at the SubSheet call site on Main Page. We record the call site, not
    whether the caller catches it (positional scope is not modelled)."""
    est = _xpage()
    props = est.exception_propagation
    assert len(props) == 1
    p = props[0]
    assert (p.from_page, p.to_page, p.via_stage) == ("Do Work", "Main Page", "Call Do Work")
    assert p.kind == "page-call"


def test_recover_without_resume_escapes(tmp_path):
    """No Resume on the recovery path => the exception propagates up the call
    stack (answer #4), flagged as escapes."""
    xml = ('<process name="X" preferredid="x1" published="true">'
           '<stage stageid="s" name="Start" type="Start"><onsuccess>r</onsuccess></stage>'
           '<stage stageid="r" name="Catch" type="Recover"><onsuccess>h</onsuccess></stage>'
           '<stage stageid="h" name="Handle" type="Calculation"><onsuccess>e</onsuccess>'
           '<calculation expression="1" stage="Y"/></stage>'
           '<stage stageid="e" name="End" type="End"/></process>')
    p = tmp_path / "x.bpprocess"
    p.write_text(xml, encoding="utf-8")
    est = Estate()
    parse_file(p, est)
    regions.run(est)
    h = est.exception_handlers[0]
    assert h.resumes is False
    assert h.escapes is True
