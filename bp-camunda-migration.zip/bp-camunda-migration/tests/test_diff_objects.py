"""Controls for the object comparison (task 4, BP Comparison Rules).

The severities here are not this tool's opinion. Each one is a numbered rule in
the bank's own comparison document, and the direction they all hang off is fixed
by rules 21 and 24: BASE overwrites TARGET. Get that backwards and every
severity inverts — a page missing from the target becomes a catastrophe instead
of a no-op — so the direction is asserted directly, twice, rather than left to
be inferred from the pass/fail of some other test.
"""
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

from diff_objects import (CRITICAL, IMPACTFUL, MINOR, Art,  # noqa: E402
                          compare, instance_of, ledger)
import render_compare as R   # noqa: E402

NS = 'xmlns="http://www.blueprism.co.uk/product/process"'


def obj(sheets: str = "", stages: str = "", name: str = "Bank - Thing") -> str:
    return f'<process name="{name}" {NS}>{sheets}{stages}</process>'


def sheet(sid: str, name: str, published: bool = True) -> str:
    return (f'<subsheet subsheetid="{sid}" type="Normal" '
            f'published="{"True" if published else "False"}">'
            f"<name>{name}</name></subsheet>")


def stage(sid: str, name: str, page: str, stype: str = "Action",
          extra: str = "") -> str:
    return (f'<stage stageid="{sid}" name="{name}" type="{stype}">'
            f"<subsheetid>{page}</subsheetid>{extra}</stage>")


def art(tmp_path: Path, xml: str, fname: str = "a.bpobject") -> Art:
    p = tmp_path / fname
    p.write_text(xml, encoding="utf-8")
    return Art(p)


def diff(tmp_path, base_xml, target_xml):
    return compare(art(tmp_path, base_xml, "base.bpobject"),
                   art(tmp_path, target_xml, "target.bpobject"))


P1, P2 = "sheet-1", "sheet-2"


# --------------------------------------------------------------------------- #
# the direction — rules 21 and 24
# --------------------------------------------------------------------------- #
def test_page_only_in_target_is_impactful(tmp_path):
    """Rule 9. Overwriting destroys it and every caller of it."""
    d = diff(tmp_path, obj(sheet(P1, "Kept")),
             obj(sheet(P1, "Kept") + sheet(P2, "Extra")))
    f = [r for r in d["sheets"] if r["kind"] == "page_only_in_target"]
    assert len(f) == 1 and f[0]["severity"] == IMPACTFUL
    assert f[0]["page"] == "Extra"


def test_page_only_in_base_is_minor(tmp_path):
    """Rule 8. The overwrite restores it, so nothing that exists today breaks.
    This is the pair to the test above and the two must not agree."""
    d = diff(tmp_path, obj(sheet(P1, "Kept") + sheet(P2, "Extra")),
             obj(sheet(P1, "Kept")))
    f = [r for r in d["sheets"] if r["kind"] == "page_only_in_base"]
    assert len(f) == 1 and f[0]["severity"] == MINOR


def test_the_two_directions_are_not_symmetric(tmp_path):
    """If someone 'simplifies' the grader into a symmetric diff, this fails."""
    a, b = obj(sheet(P1, "Kept")), obj(sheet(P1, "Kept") + sheet(P2, "Extra"))
    assert (diff(tmp_path, a, b)["totals"][IMPACTFUL]
            != diff(tmp_path, b, a)["totals"][IMPACTFUL])


# --------------------------------------------------------------------------- #
# page-level rules — 2, 12, 20, 27
# --------------------------------------------------------------------------- #
def test_renamed_page_is_impactful_when_published(tmp_path):
    d = diff(tmp_path, obj(sheet(P1, "Old")), obj(sheet(P1, "New")))
    f = [r for r in d["sheets"] if r["kind"] == "page_renamed"]
    assert f and f[0]["severity"] == IMPACTFUL
    assert "rule_conflict" not in f[0]


def test_renamed_page_is_minor_when_both_unpublished(tmp_path):
    """Rule 12 downgrades it; rule 20 does not. The more specific rule wins and
    the disagreement is carried on the finding, not resolved in silence."""
    d = diff(tmp_path, obj(sheet(P1, "Old", published=False)),
             obj(sheet(P1, "New", published=False)))
    f = [r for r in d["sheets"] if r["kind"] == "page_renamed"]
    assert f and f[0]["severity"] == MINOR
    assert "rule 20" in f[0]["rule_conflict"]


def test_unpublishing_a_page_is_impactful(tmp_path):
    d = diff(tmp_path, obj(sheet(P1, "A")), obj(sheet(P1, "A", published=False)))
    assert [r["severity"] for r in d["sheets"]
            if r["kind"] == "page_publish_changed"] == [IMPACTFUL]


def test_changes_on_an_unpublished_page_are_minor(tmp_path):
    """Rule 27. Nothing outside can call it, so nothing outside can break."""
    base = obj(sheet(P1, "Hidden", published=False),
               stage("s1", "Do", P1, extra="<code>OLD</code>"))
    tgt = obj(sheet(P1, "Hidden", published=False),
              stage("s1", "Do", P1, extra="<code>NEW</code>"))
    d = diff(tmp_path, base, tgt)
    assert [r["severity"] for r in d["changed"]] == [MINOR]


def test_the_same_change_on_a_published_page_is_not_minor(tmp_path):
    """The control for the test above: rule 27 must be doing the work, not some
    accident of how a code change is graded."""
    base = obj(sheet(P1, "Shown"), stage("s1", "Do", P1, extra="<code>OLD</code>"))
    tgt = obj(sheet(P1, "Shown"), stage("s1", "Do", P1, extra="<code>NEW</code>"))
    assert [r["severity"] for r in diff(tmp_path, base, tgt)["changed"]] \
        == [IMPACTFUL]


def test_unpublished_pages_are_still_compared(tmp_path):
    """Rule 26: published or not, the stages are compared. Minor is not silent."""
    base = obj(sheet(P1, "Hidden", published=False), stage("s1", "A", P1))
    tgt = obj(sheet(P1, "Hidden", published=False), stage("s1", "B", P1))
    assert diff(tmp_path, base, tgt)["changed"]


# --------------------------------------------------------------------------- #
# stage-level severity — rules 3, 4, 5, 6, 7, 17
# --------------------------------------------------------------------------- #
def test_renamed_stage_is_minor(tmp_path):
    """Rule 7 says this in as many words: a difference, but not a critical one."""
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "Old", P1)),
             obj(sheet(P1, "P"), stage("s1", "New", P1)))
    assert [r["severity"] for r in d["changed"]] == [MINOR]


def test_changed_argument_type_is_critical(tmp_path):
    """Rules 3 and 17: the argument list is the contract with every caller."""
    ins = '<inputs><input type="{t}" name="Qty" expr="1"/></inputs>'
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="number"))),
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="text"))))
    assert [r["severity"] for r in d["changed"]] == [CRITICAL]
    assert "signature" in d["changed"][0]["fields"]


def test_changed_argument_value_is_only_impactful(tmp_path):
    """The control: re-pointing an input is a behaviour change, not a contract
    change. If the signature check is matching on the value too, this fails."""
    ins = '<inputs><input type="number" name="Qty" expr="{e}"/></inputs>'
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(e="1"))),
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(e="2"))))
    assert [r["severity"] for r in d["changed"]] == [IMPACTFUL]
    assert "signature" not in d["changed"][0]["fields"]


@pytest.mark.parametrize("tag,inner", [
    ("references", "<reference>System.Xml.dll</reference>"),
    ("imports", "<import>System.Xml</import>"),
])
def test_lost_reference_or_import_is_impactful(tag, inner, tmp_path):
    """Rules 5 and 6. A Code stage that loses a .dll stops compiling, and
    nothing in the stage body shows it."""
    d = diff(tmp_path,
             obj(sheet(P1, "P"), stage("s1", "C", P1, "Code", f"<{tag}>{inner}</{tag}>")),
             obj(sheet(P1, "P"), stage("s1", "C", P1, "Code", f"<{tag}></{tag}>")))
    assert [r["severity"] for r in d["changed"]] == [IMPACTFUL]
    assert tag in d["changed"][0]["fields"]


def test_worst_field_sets_the_severity(tmp_path):
    """A stage that changed a name AND an argument type is critical, not minor."""
    ins = '<inputs><input type="{t}" name="Qty" expr="1"/></inputs>'
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "Old", P1, extra=ins.format(t="number"))),
             obj(sheet(P1, "P"), stage("s1", "New", P1, extra=ins.format(t="text"))))
    assert d["changed"][0]["severity"] == CRITICAL


# --------------------------------------------------------------------------- #
# nothing may be silently equal
# --------------------------------------------------------------------------- #
def test_layout_only_change_is_not_a_difference(tmp_path):
    """A stage dragged across the canvas must not surface as a change, or the
    real ones drown."""
    d = diff(tmp_path,
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra="<displayx>10</displayx>")),
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra="<displayx>900</displayx>")))
    assert d["identical"] and not d["changed"]


def test_renaming_a_page_does_not_move_the_stages_on_it(tmp_path):
    """Regression. The first real run of this tool renamed one page and reported
    "moved to a different page" against all 27 stages sitting on it, because
    pages were compared by display name. A rename is one finding, not 27."""
    stages = "".join(stage(f"s{i}", f"St{i}", P1) for i in range(27))
    d = diff(tmp_path, obj(sheet(P1, "Login"), stages),
             obj(sheet(P1, "Log In"), stages))
    assert not d["changed"], [r["fields"] for r in d["changed"]]
    assert [r["kind"] for r in d["sheets"]] == ["page_renamed"]


def test_a_stage_that_really_moves_is_still_caught(tmp_path):
    """The control for the regression above: fixing the phantom must not blind
    the tool to a genuine move."""
    d = diff(tmp_path, obj(sheet(P1, "A") + sheet(P2, "B"), stage("s1", "X", P1)),
             obj(sheet(P1, "A") + sheet(P2, "B"), stage("s1", "X", P2)))
    assert [r["fields"] for r in d["changed"]] == [["sheet_id"]]
    assert d["changed"][0]["severity"] == MINOR


def test_identical_objects_produce_nothing(tmp_path):
    x = obj(sheet(P1, "P"), stage("s1", "A", P1))
    d = diff(tmp_path, x, x)
    assert d["identical"] and d["totals"] == {CRITICAL: 0, IMPACTFUL: 0, MINOR: 0}


def test_an_unmodelled_change_is_reported_not_dropped(tmp_path):
    """The subtree hash differs but no field this tool understands does. That is
    a finding, not an absence — and it is graded as if it were behaviour."""
    d = diff(tmp_path,
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra="<mystery>a</mystery>")),
             obj(sheet(P1, "P"), stage("s1", "A", P1, extra="<mystery>b</mystery>")))
    assert len(d["unclassified"]) == 1
    assert d["unclassified"][0]["severity"] == IMPACTFUL


def test_totals_count_every_finding(tmp_path):
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "A", P1)),
             obj(sheet(P1, "P") + sheet(P2, "Extra"),
                 stage("s1", "B", P1) + stage("s2", "New", P2)))
    n = sum(len(d[k]) for k in ("added", "removed", "changed", "unclassified"))
    assert sum(d["totals"].values()) == n + len(d["sheets"])


# --------------------------------------------------------------------------- #
# rule 23 — the instance short code
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("fname,want", [
    ("PRD - Centrix Basic Actions.bpobject", "PRD"),
    ("UAT - Some Process.bpprocess", "UAT"),
    ("no_separator.bpobject", None),
    ("Trailing - .bpobject", "Trailing"),
])
def test_instance_short_code(fname, want):
    assert instance_of(fname) == want


def test_instance_is_never_guessed():
    """A filename with no separator yields None, not the whole stem. A reader
    cannot tell a guessed instance from a real one."""
    assert instance_of("Centrix Basic Actions.bpobject") is None


# --------------------------------------------------------------------------- #
# the JIRA report — rules 18, 19, 25
# --------------------------------------------------------------------------- #
def report(tmp_path, base_xml, target_xml, **kw) -> str:
    d = diff(tmp_path, base_xml, target_xml)
    d.update(base_file="PRD - Thing.bpobject", target_file="UAT - Thing.bpobject",
             base_instance="PRD", target_instance="UAT")
    return R.render(d, **kw)


def test_clean_comparison_uses_the_tick(tmp_path):
    x = obj(sheet(P1, "P"), stage("s1", "A", P1))
    out = report(tmp_path, x, x)
    assert "(/)" in out and "(x)" not in out
    assert "No differences found" in out


def test_differences_use_the_error_icon(tmp_path):
    out = report(tmp_path, obj(sheet(P1, "P")), obj(sheet(P1, "P") + sheet(P2, "X")))
    assert out.startswith("h1. Object comparison (x)")


def test_title_block_carries_date_user_and_provenance(tmp_path):
    """Rule 18 — but see the module docstring: this report is not AI-assisted
    and must not claim to be."""
    x = obj(sheet(P1, "P"))
    out = report(tmp_path, x, x)
    assert "|Date|" in out and "|Run by|" in out
    assert "No model was consulted" in out
    assert "AI Assisted" not in out


def test_ai_assisted_is_opt_in(tmp_path):
    x = obj(sheet(P1, "P"))
    assert "AI Assisted" in report(tmp_path, x, x, ai_assisted=True)


def test_instance_names_reach_the_report(tmp_path):
    x = obj(sheet(P1, "P"))
    out = report(tmp_path, x, x)
    assert "*PRD*" in out and "*UAT*" in out


def test_findings_land_under_their_severity_heading(tmp_path):
    out = report(tmp_path, obj(sheet(P1, "P")), obj(sheet(P1, "P") + sheet(P2, "X")))
    impactful = out.index("Impactful Issues (1)")
    assert out.index("h2. (/) Critical Issues") < impactful
    assert "'X'" in out[impactful:]


def test_remediation_is_offered_only_where_it_is_entailed(tmp_path):
    out = report(tmp_path, obj(sheet(P1, "P")), obj(sheet(P1, "P") + sheet(P2, "X")))
    assert "copy this page from the target into the base" in out
    assert "need a judgement call this tool does not make" in out


# --------------------------------------------------------------------------- #
# rule 1 — the coding-rules section
# --------------------------------------------------------------------------- #
def _cr(tmp_path, base_xml, target_xml):
    from diff_objects import coding_rules
    b = tmp_path / "b.bpobject"; b.write_text(base_xml, encoding="utf-8")
    t = tmp_path / "t.bpobject"; t.write_text(target_xml, encoding="utf-8")
    return coding_rules(b, t)


def _named(sid, name):
    return stage(sid, name, P1, "Data", "<datatype>text</datatype>")


def test_a_violation_only_in_the_base_is_introduced(tmp_path):
    """A default stage name in the base and not the target is a problem the
    overwrite ADDS. That is the only part of compliance a reader can still act
    on, so it is the part the report highlights."""
    good = obj(sheet(P1, "P"), _named("s1", "i_txt_Order"))
    bad = obj(sheet(P1, "P"), _named("s1", "Data1"))
    cr = _cr(tmp_path, bad, good)
    assert cr["introduced_by_overwrite"]
    assert any(f["rule_id"] == "STAGE-DEFAULT-NAME"
               for f in cr["introduced_by_overwrite"])


def test_a_violation_only_in_the_target_is_fixed(tmp_path):
    """The mirror. If these two agreed, the direction would not be doing any
    work and the section would be a coin flip."""
    good = obj(sheet(P1, "P"), _named("s1", "i_txt_Order"))
    bad = obj(sheet(P1, "P"), _named("s1", "Data1"))
    cr = _cr(tmp_path, good, bad)
    assert not cr["introduced_by_overwrite"]
    assert cr["fixed_by_overwrite_count"] > 0


def test_a_shared_violation_is_neither_introduced_nor_fixed(tmp_path):
    """Both versions non-compliant is not a reason to hold the overwrite."""
    bad = obj(sheet(P1, "P"), _named("s1", "Data1"))
    cr = _cr(tmp_path, bad, bad)
    assert not cr["introduced_by_overwrite"]
    assert cr["fixed_by_overwrite_count"] == 0
    assert cr["base_issue_count"] == cr["target_issue_count"] > 0


def test_a_delta_row_counts_only_the_stages_that_differ(tmp_path):
    """Regression. Findings aggregate per artifact ("3 stages keep a default
    name") but a delta is per stage, so printing the finding's own wording
    claimed 3 new problems where there was 1."""
    both = _named("s1", "Data1") + _named("s2", "Data2")
    cr = _cr(tmp_path, obj(sheet(P1, "P"), both + _named("s3", "Data3")),
             obj(sheet(P1, "P"), both))
    row = next(f for f in cr["introduced_by_overwrite"]
               if f["rule_id"] == "STAGE-DEFAULT-NAME")
    assert row["stageids"] == ["s3"]
    assert row["observed"].startswith("1 of the 3 stage(s)")


# --------------------------------------------------------------------------- #
# rules 1 and 16 in the rendered report
# --------------------------------------------------------------------------- #
def test_coding_rules_section_is_clean_when_nothing_is_introduced(tmp_path):
    x = obj(sheet(P1, "P"), _named("s1", "i_txt_Order"))
    d = diff(tmp_path, x, x)
    d["coding_rules"] = _cr(tmp_path, x, x)
    out = R.render(d)
    assert "h2. (/) Coding rules" in out
    assert "introduces no new coding-rules issue" in out


def test_coding_rules_section_flags_what_the_overwrite_adds(tmp_path):
    good = obj(sheet(P1, "P"), _named("s1", "i_txt_Order"))
    bad = obj(sheet(P1, "P"), _named("s1", "Data1"))
    d = diff(tmp_path, bad, good)
    d["coding_rules"] = _cr(tmp_path, bad, good)
    out = R.render(d)
    assert "h2. (x) Coding rules" in out
    assert "STAGE-DEFAULT-NAME" in out and "*Required:*" in out


def test_closing_description_is_present_even_on_a_clean_report(tmp_path):
    """Rule 16. Without it, "no differences" reads the same as "not checked"."""
    x = obj(sheet(P1, "P"), stage("s1", "A", P1))
    out = report(tmp_path, x, x)
    assert "h2. About this report" in out
    assert "stage(s) identical" in out
    assert "Nothing critical or impactful" in out


def test_closing_description_leads_with_the_critical_count(tmp_path):
    ins = '<inputs><input type="{t}" name="Qty" expr="1"/></inputs>'
    out = report(tmp_path,
                 obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="number"))),
                 obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="text"))))
    tail = out[out.index("h2. About this report"):]
    assert "1 critical finding(s)" in tail
    assert "contract every calling process depends on" in tail


def test_closing_description_never_claims_intent(tmp_path):
    x = obj(sheet(P1, "P"), stage("s1", "A", P1))
    tail = report(tmp_path, x, x)
    assert "is not in the files and is not claimed here" in tail


# --------------------------------------------------------------------------- #
# the HTML view — same JSON, second format
# --------------------------------------------------------------------------- #
def html(tmp_path, base_xml, target_xml) -> str:
    d = diff(tmp_path, base_xml, target_xml)
    d.update(base_file="PRD - Thing.bpobject", target_file="UAT - Thing.bpobject",
             base_instance="PRD", target_instance="UAT")
    return R.render_html(d, "changes.json")


@pytest.mark.parametrize("markup", ["h1. ", "h2. ", "||", "{{", "(/)", "(x)", "(!)"])
def test_jira_markup_never_leaks_into_the_html(markup, tmp_path):
    """Both formats come off one JSON through shared helpers, so the easiest
    way to break this page is to let JIRA syntax through verbatim -- it renders
    as literal '(x)' and '||' and looks like a broken template."""
    ins = '<inputs><input type="{t}" name="Qty" expr="1"/></inputs>'
    out = html(tmp_path,
               obj(sheet(P1, "P") + sheet(P2, "Gone"),
                   stage("s1", "A", P1, extra=ins.format(t="number"))),
               obj(sheet(P1, "P"), stage("s1", "B", P1, extra=ins.format(t="text"))))
    assert markup not in out


def test_html_says_do_not_overwrite_when_something_is_critical(tmp_path):
    ins = '<inputs><input type="{t}" name="Qty" expr="1"/></inputs>'
    out = html(tmp_path,
               obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="number"))),
               obj(sheet(P1, "P"), stage("s1", "A", P1, extra=ins.format(t="text"))))
    assert "Do not overwrite without review" in out
    assert "is-fail" in out


def test_html_says_safe_when_only_minor(tmp_path):
    out = html(tmp_path, obj(sheet(P1, "P"), stage("s1", "Old", P1)),
               obj(sheet(P1, "P"), stage("s1", "New", P1)))
    assert "Safe to overwrite" in out and "is-pass" in out


def test_html_seal_counts_identical_stages_not_findings(tmp_path):
    """A findings count answers "how different", which is unreadable until you
    know the diff parsed anything. The fraction is identical/compared."""
    stages = "".join(stage(f"s{i}", f"St{i}", P1) for i in range(4))
    out = html(tmp_path, obj(sheet(P1, "P"), stages),
               obj(sheet(P1, "P"), stages + stage("s9", "New", P1)))
    assert re.search(r'class="frac">4<small>/5', out)


def test_html_refuses_to_look_clean_when_nothing_was_compared(tmp_path):
    """The silent-zero guard: an empty object must not render as a pass."""
    out = html(tmp_path, obj(), obj())
    assert "No stages were compared" in out
    assert "is not a clean result" in out


def test_html_carries_the_coding_rules_and_closing_sections(tmp_path):
    good = obj(sheet(P1, "P"), _named("s1", "i_txt_Order"))
    bad = obj(sheet(P1, "P"), _named("s1", "Data1"))
    d = diff(tmp_path, bad, good)
    d["coding_rules"] = _cr(tmp_path, bad, good)
    out = R.render_html(d, "changes.json")
    assert "<h2>Coding rules</h2>" in out
    assert "STAGE-DEFAULT-NAME" in out
    assert "About this report" in out


def test_html_page_passes_the_shared_page_audit(tmp_path):
    """_page.write refuses to emit a file that is not a page. Two renderers
    have already shipped a Python repr as a body; this runs that guard."""
    from _page import SEAL, write
    x = obj(sheet(P1, "P"), stage("s1", "A", P1))
    d = diff(tmp_path, x, x)
    out = tmp_path / "r.html"
    write(out, "Object comparison", SEAL + R._CSS, R.render_html(d, "c.json"))
    assert "<!doctype html>" in out.read_text(encoding="utf-8")


# --------------------------------------------------------------------------- #
def test_ledger_lines_carry_the_severity(tmp_path):
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "Old", P1)),
             obj(sheet(P1, "P"), stage("s1", "New", P1)))
    assert MINOR in ledger(d)


def test_changes_json_round_trips(tmp_path):
    d = diff(tmp_path, obj(sheet(P1, "P"), stage("s1", "A", P1)),
             obj(sheet(P1, "P") + sheet(P2, "X"), stage("s1", "B", P1)))
    assert json.loads(json.dumps(d)) == d
