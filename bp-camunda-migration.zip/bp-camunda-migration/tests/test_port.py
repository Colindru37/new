"""The single-file port (`port/bp_core.py`) must stay faithful and current.

Two guarantees, both cheap:
  * the committed bundle self-tests green (its baked-in golden still holds), and
  * regenerating it from source yields byte-identical output — so the bundle can
    never silently go stale or be hand-edited without this test catching it.

This is what lets `SELFTEST PASS` on the air-gapped laptop mean "faithful to the
tested original": the original is pinned here.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "port" / "build.py"
BUNDLE = ROOT / "port" / "bp_core.py"
BUILD_FULL = ROOT / "port" / "build_full.py"
BUNDLE_FULL = ROOT / "port" / "bp_full.py"
FIXTURES = ROOT / "tests" / "fixtures"
GOLDEN = ROOT / "tests" / "golden" / "fixtures.estate.json"


def test_bundle_selftest_passes():
    res = subprocess.run([sys.executable, str(BUNDLE), "--selftest"],
                         capture_output=True, text=True)
    assert res.returncode == 0, res.stdout + res.stderr
    assert "SELFTEST PASS" in res.stdout


def test_bundle_is_not_stale(tmp_path):
    """Regenerating from source must reproduce the committed bundle byte-for-byte.
    (Rebuild into a temp copy so the working tree is untouched.)"""
    before = BUNDLE.read_bytes()
    res = subprocess.run([sys.executable, str(BUILD)],
                         capture_output=True, text=True)
    assert res.returncode == 0, res.stdout + res.stderr
    after = BUNDLE.read_bytes()
    # restore whatever was there before, regardless of outcome
    BUNDLE.write_bytes(before)
    assert before == after, (
        "port/bp_core.py is stale or hand-edited — run `python port/build.py`"
    )


# --- Layer 2 bundle (bp_full.py) ------------------------------------------- #

def test_full_bundle_selftest_passes():
    res = subprocess.run([sys.executable, str(BUNDLE_FULL), "--selftest"],
                         capture_output=True, text=True)
    assert res.returncode == 0, res.stdout + res.stderr
    assert "SELFTEST PASS" in res.stdout


def test_full_bundle_matches_the_real_pipeline(tmp_path):
    """The stdlib graph shim + inlined config must reproduce the canonical golden
    (which the real pipeline builds with networkx + PyYAML) byte-for-byte."""
    out = tmp_path / "estate.json"
    res = subprocess.run(
        [sys.executable, str(BUNDLE_FULL), str(FIXTURES), "-o", str(out)],
        capture_output=True, text=True)
    assert res.returncode == 0, res.stdout + res.stderr
    assert out.read_text(encoding="utf-8") == GOLDEN.read_text(encoding="utf-8"), (
        "bp_full.py diverged from the canonical golden — the networkx shim or "
        "inlined config no longer matches the real pipeline"
    )


def test_full_bundle_is_not_stale():
    before = BUNDLE_FULL.read_bytes()
    res = subprocess.run([sys.executable, str(BUILD_FULL)],
                         capture_output=True, text=True)
    assert res.returncode == 0, res.stdout + res.stderr
    after = BUNDLE_FULL.read_bytes()
    BUNDLE_FULL.write_bytes(before)
    assert before == after, (
        "port/bp_full.py is stale or hand-edited — run `python port/build_full.py`"
    )
