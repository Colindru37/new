"""The stage-skeleton dumper.

This tool exists to move STRUCTURE off a bank laptop without moving CONTENT, so
its one non-negotiable property is that no value ever survives - not an
expression, not an id, not a name, not code. The tests pin that (a scrub that
leaks is worse than useless), plus the structural facts it must preserve: tag
names, attribute names, the stage `type`, and whether a link target lives in
element text vs an attribute.
"""
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

import stage_skeleton as S  # noqa: E402

NS = "http://www.blueprism.co.uk/product/process"

# A namespaced process holding one stage of each kind we still guess at, with
# distinctive, obviously-sensitive VALUES that must not appear in the output.
SECRET = "SECRET_VALUE_THAT_MUST_NOT_LEAK"
_XML = f"""<process xmlns="{NS}" name="{SECRET}">
  <stage stageid="{SECRET}" name="{SECRET}" type="Decision">
    <decision expression="[Amount] &gt; {SECRET}"/>
    <ontrue>{SECRET}</ontrue>
    <onfalse>{SECRET}</onfalse>
  </stage>
  <stage stageid="s2" name="{SECRET}" type="MultipleCalculation">
    <steps>
      <calculation expression="{SECRET}" stage="{SECRET}"/>
    </steps>
    <onsuccess>{SECRET}</onsuccess>
  </stage>
  <stage stageid="s3" name="{SECRET}" type="Decision">
    <decision expression="second {SECRET}"/>
  </stage>
</process>
"""


def _root():
    return ET.fromstring(_XML)


def test_no_value_ever_leaks():
    """The whole reason the tool exists: not one sensitive value in the output."""
    out = S.render(_root())
    assert SECRET not in out


def test_type_is_preserved():
    out = S.render(_root())
    assert "type = Decision" in out
    assert "type = MultipleCalculation" in out
    assert 'type="Decision"' in out          # kept on the element too


def test_structure_is_preserved():
    """Tag and attribute NAMES survive - that is the ground truth we are after."""
    out = S.render(_root())
    for token in ("<decision", "expression=", "<ontrue>", "<onfalse>",
                  "<steps>", "<calculation", "stage=", "<onsuccess>"):
        assert token in out, token


def test_link_target_presence_stays_visible():
    """A link carried as element TEXT must read as non-empty (sentinel), so we
    can tell text-borne targets from attribute-borne ones."""
    out = S.render(_root())
    assert f"<ontrue>{S.SENTINEL}</ontrue>" in out


def test_one_per_type_by_default():
    """Two Decision stages, one representative - dedupe by type."""
    pairs = list(S.skeletons(_root()))
    types = [t for t, _ in pairs]
    assert types.count("Decision") == 1
    assert set(types) == {"Decision", "MultipleCalculation"}


def test_type_filter_returns_every_instance():
    pairs = list(S.skeletons(_root(), only="Decision"))
    assert len(pairs) == 2                    # both Decision stages, not deduped


def test_missing_file_exits_two(tmp_path, capsys):
    assert S.main([str(tmp_path / "nope.bprelease")]) == 2


def test_no_stages_exits_one(tmp_path, capsys):
    p = tmp_path / "empty.bpprocess"
    p.write_text(f'<process xmlns="{NS}" name="X"/>', encoding="utf-8")
    assert S.main([str(p)]) == 1
