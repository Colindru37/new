"""The writer must refuse to write something that is not a page.

Two documents have already been handed to a reader and described in detail
without being looked at: one whose stylesheet was clobbered by a variable
reassignment, one whose body was a `(head, body)` tuple interpolated into an
f-string. Both had a plausible byte count and a <style> tag, which is why
neither was caught by looking at byte counts and <style> tags.

These tests are that lesson, made permanent. They are cheap and they are the
only thing standing between a renderer refactor and another confident lie.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

from _page import SHELL, audit, write  # noqa: E402

BODY = '<div class="wrap"><header><h1>Title</h1></header><p>Prose.</p></div>'


def test_writes_a_real_page(tmp_path):
    out = tmp_path / "p.html"
    write(out, "A title", "", BODY)
    s = out.read_text(encoding="utf-8")
    assert "<title>A title</title>" in s
    assert len(s.split("<style>")[1].split("</style>")[0]) > 2000
    assert BODY in s


def test_fragment_still_carries_head(tmp_path):
    out = tmp_path / "f.html"
    write(out, "A title", "", BODY, fragment=True)
    s = out.read_text(encoding="utf-8")
    assert "<title>" in s and "<style>" in s and "<!doctype" not in s.lower()


def test_rejects_tuple_body(tmp_path):
    """The exact shape of the second bug: render() returned (head, body)."""
    with pytest.raises(TypeError):
        write(tmp_path / "x.html", "T", "", ("<title>T</title>", BODY))
    assert not (tmp_path / "x.html").exists(), "must not leave a partial file"


def test_rejects_clobbered_stylesheet():
    """The exact shape of the first bug: the head was reassigned to a verdict
    string, so the page shipped with no CSS at all. Routing every renderer
    through write() means SHELL is always present - audit() is the check that
    that stayed true."""
    page = ('<!doctype html><title>T</title><style>body{margin:0}</style>'
            f"{BODY}")
    with pytest.raises(AssertionError, match="stylesheet is"):
        audit(page)


def test_rejects_body_that_is_not_markup(tmp_path):
    with pytest.raises(AssertionError, match="content shell"):
        write(tmp_path / "x.html", "T", "", "Verified complete")
    assert not (tmp_path / "x.html").exists()


def test_rejects_literal_escape_sequences(tmp_path):
    with pytest.raises(AssertionError, match="backslash-n"):
        write(tmp_path / "x.html", "T", "", BODY + r"<p>a\nb</p>")


def test_shell_defines_both_themes():
    for probe in ("prefers-color-scheme:dark", '[data-theme="dark"]',
                  '[data-theme="light"]'):
        assert probe in SHELL, f"{probe} missing - theme toggle will not work"
