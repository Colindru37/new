# Blue Prism fixtures

Hand-authored XML — **not real exports**. They exercise the analyzer end-to-end
before a real export is available.

**Reconciled** against the bank's "BP Description" reference (photographed; see
the gitignored `rules/`). The *spine* below is what that doc states explicitly,
so these fixtures now mirror real exports rather than a convenient invention:

```xml
<process name="..." preferredid="ID" published="true" version="1.0" bpversion="7.x">
  <narrative>...</narrative>
  <view>...</view>                        <!-- ignored by design -->

  <!-- page name lives in a CHILD node; subsheetid is an internal GUID -->
  <subsheet subsheetid="8f1d3a52-..." published="true"><name>Main Page</name></subsheet>

  <!-- a stage with NO <subsheetid> is on "Main Page" -->
  <stage stageid="g1" name="Start" type="Start">
    <narrative>...</narrative>
    <display x="0" y="0" w="60" h="30"/>
    <onsuccess>g2</onsuccess>                              <!-- UNCONFIRMED -->
  </stage>

  <stage type="Data">
    <datatype>Number</datatype>          <!-- Date|DateTime|Flag|Number|Password
                                              |Text|Time|TimeSpan|Image|Binary -->
    <initialvalue>0</initialvalue>
    <private/>                           <!-- PRESENCE means private -->
  </stage>

  <stage type="Action">
    <resource object="Work Queues" action="Add To Queue"/>  <!-- UNCONFIRMED -->
    <inputs>
      <!-- values are BP EXPRESSIONS: a text literal is quoted -->
      <input type="text" name="Queue Name" narrative="..." expr="&quot;Payments&quot;"/>
    </inputs>
    <outputs>
      <!-- @stage names the Data stage that captures the return value -->
      <output type="text" name="Item ID" narrative="..." stage="ItemId"/>
    </outputs>
  </stage>
</process>
```

Objects (`.bpobject`) use the same `<process>` schema plus an `<appdef>`
(Application Modeller). Artifact type comes from the **file extension**; inside
a `.bprelease` it falls back to `@type`, then to the presence of `<appdef>`.

**Still unconfirmed** (tagged `# UNCONFIRMED` in `parse.py`): `<resource>`,
Decision/Choice/Calculation internals, `<page ref>`, `<collectioninfo>`,
`<code language>`, flow-link tags. Fix those against the first real export.

## What each fixture is for
- **payments_process.bpprocess** — the kitchen sink: money decision, ordered
  choice, work-queue add/get/complete (idempotency), credential, env-lock, a
  code stage, a page ref, a missing-object reference, a back-link, a dead stage,
  a PII-suspect collection, an unpublished page, and Main Page stages that omit
  `<subsheetid>`.
- **customer_object.bpobject** — a custom VBO (re-host tier) with an `<appdef>`
  and a code stage; also adds to the shared "Payments" queue.
- **orphan_object.bpobject** — an object nothing references (dead code).
- **dynamic_queue.bpprocess** — an unpublished process adding to a queue whose
  name is computed at runtime (unresolved/dynamic).

Namespaced exports, `.bprelease` bundles and the expression grammar are covered
by inline XML in `tests/test_parse.py` (kept out of this folder so the golden
snapshot stays stable).
