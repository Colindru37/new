"""End-to-end smoke tests over the synthetic fixtures.

Proves the pipeline runs, the output validates against the schema, is
deterministic, and that each tricky construct is detected.
"""
from pathlib import Path

import pytest

from bp_estate.cli import run_analysis

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def estate(tmp_path_factory):
    out = tmp_path_factory.mktemp("out")
    return run_analysis([str(FIXTURES)], out)


def test_artifacts_parsed(estate):
    names = {a.name for a in estate.artifacts}
    assert {"Payments Process", "Customer Object", "Orphan Helper", "Dynamic Queue Process"} <= names


def test_object_tiers(estate):
    tiers = {t.object: t.tier for t in estate.object_tiers}
    assert tiers["Work Queues"] == "internal"
    assert tiers["Credentials"] == "internal"
    assert tiers["Environment - Locking"] == "internal"
    assert tiers["Utility - Strings"] == "shipped"
    assert tiers["Customer Object"] == "custom"
    assert tiers["Ghost Object"] == "custom"        # unknown -> custom


def test_resource_extraction(estate):
    q = {x.name: x for x in estate.queues}
    assert "Payments" in q
    assert set(q["Payments"].used_by) == {"Payments Process", "Customer Object"}   # shared
    assert {c.name for c in estate.credentials} == {"CoreBankingSvc"}
    assert {l.name for l in estate.env_locks} == {"PaymentsRun"}


def test_dynamic_queue_flagged(estate):
    dyn = [q for q in estate.queues if q.dynamic_name]
    assert any(q.name == "[TargetQueue]" for q in dyn)
    assert any(u.reason == "dynamic" for u in estate.unresolved)


def test_blockers(estate):
    kinds = {b.kind for b in estate.blockers}
    assert "code-stage" in kinds
    assert "environment-lock" in kinds
    assert "missing-reference" in kinds       # Ghost Object
    assert "dynamic-name" in kinds
    assert "backlink-cycle" in kinds


def test_dead_code(estate):
    dead = {(d.kind, d.ref) for d in estate.dead_code}
    assert ("object", "Orphan Helper") in dead
    assert ("stage", "Unused Trim") in dead


def test_pii_detected(estate):
    wi = next(c for c in estate.collections if c.name == "WorkItem")
    assert wi.pii_suspect
    assert "identity" in wi.pii_categories or "financial" in wi.pii_categories


def test_risk_reflects_idempotency_and_money(estate):
    s = {x.artifact: x for x in estate.scores}["Payments Process"]
    assert s.risk > 0
    assert s.complexity > 0
    assert s.wave is not None


def test_deterministic(tmp_path):
    a = run_analysis([str(FIXTURES)], tmp_path / "a").dumps()
    b = run_analysis([str(FIXTURES)], tmp_path / "b").dumps()
    assert a == b


def test_schema_validation_runs(estate):
    # run_analysis validates against estate.schema.json; reaching here means it passed
    assert estate.to_dict()["meta"]["schema_version"] == 1
