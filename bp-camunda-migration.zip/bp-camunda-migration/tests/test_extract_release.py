"""The .bprelease splitter.

A .bprelease is one XML document, not an archive. This tool pulls each artifact
out in the exact shape a single Blue Prism export has, so the single-artifact
tools (diff_objects, per-object docs) - which refuse a whole release - can consume
it. The tests pin the four things that make it *correct* rather than merely
producing files: the body (not the wrapper) becomes the root, the wrapper tag
picks the extension, manifest stubs are not mistaken for artifacts, and every
written file round-trips back through the real parser as exactly one artifact.
"""
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import extract_release as X  # noqa: E402
from bp_estate.model import Estate  # noqa: E402
from bp_estate.parse import parse_file  # noqa: E402

NS = "http://www.blueprism.co.uk/product/process"


def _body(name, ns=True):
    tag = f"{{{NS}}}process" if ns else "process"
    b = ET.Element(tag, {"name": name})
    ET.SubElement(b, f"{{{NS}}}stage" if ns else "stage", {"name": "S1"})
    return b


def _release(specs, with_stub=True, ns=True):
    """specs: list of (wrapper_tag, artifact_name). Returns a release root that
    mirrors a real export: full wrappers under <contents>, plus an optional
    empty manifest stub that must NOT be extracted."""
    rtag = f"{{http://www.blueprism.co.uk/product/release}}release" if ns else "release"
    root = ET.Element(rtag)
    contents = ET.SubElement(root, "contents")
    for tag, name in specs:
        wtag = f"{{{NS}}}{tag}" if ns else tag
        w = ET.SubElement(contents, wtag, {"id": f"id-{name}", "name": name})
        w.append(_body(name, ns=ns))
    if with_stub:
        # a manifest stub: a wrapper with NO <process> body
        ET.SubElement(contents, f"{{{NS}}}process" if ns else "process",
                      {"name": "phantom-stub"})
    return root


def _write(tmp_path, root, fname="rel.bprelease"):
    p = tmp_path / fname
    ET.ElementTree(root).write(p, encoding="utf-8", xml_declaration=True)
    return p


# --- what makes it correct ---------------------------------------------------

def test_body_becomes_the_root_not_the_wrapper(tmp_path):
    """Extracted root must be the <process> body (carrying stages), never the
    id+name wrapper - that is the only shape the single-artifact tools accept."""
    p = _write(tmp_path, _release([("object", "Alpha")], with_stub=False))
    items = X.extract(p)
    assert len(items) == 1
    _, tag, body = items[0]
    assert X._local(body.tag) == "process"
    assert any(X._local(k.tag) == "stage" for k in body)      # real body, has stages
    assert "id" not in body.attrib                            # wrapper attrs dropped


def test_extension_follows_wrapper_tag(tmp_path):
    p = _write(tmp_path, _release(
        [("process", "AProc"), ("object", "AnObj")], with_stub=False))
    names = {fn for fn, _, _ in X.extract(p)}
    assert "AProc.bpprocess" in names
    assert "AnObj.bpobject" in names


def test_manifest_stub_is_not_an_artifact(tmp_path):
    """A wrapper with no body is a <contents> stub; extracting it would invent a
    phantom object named after the file - the exact trap the parser documents."""
    p = _write(tmp_path, _release([("object", "Real")], with_stub=True))
    names = [fn for fn, _, _ in X.extract(p)]
    assert names == ["Real.bpobject"]
    assert not any("phantom" in n for n in names)


def test_every_written_file_roundtrips_to_one_artifact(tmp_path):
    """The whole point: what we write must parse back as a standalone export."""
    p = _write(tmp_path, _release(
        [("process", "Main"), ("object", "Lib One"), ("object", "Lib Two")]))
    out = tmp_path / "objects"
    for fname, _, body in X.extract(p):
        X.write_one(body, out / fname) if out.mkdir(exist_ok=True) or True else None
    written = sorted(out.glob("*.bp*"))
    assert len(written) == 3
    for f in written:
        est = Estate()
        parse_file(f, est)
        assert len(est.artifacts) == 1, f"{f.name}: {len(est.artifacts)} artifacts"


def test_namespace_is_preserved_on_output(tmp_path):
    """Output must stay valid Blue Prism XML - prefix-free default namespace,
    re-parseable - not ET's ns0: mangling."""
    p = _write(tmp_path, _release([("object", "NsCheck")], with_stub=False))
    _, _, body = X.extract(p)[0]
    dest = tmp_path / "one.bpobject"
    X.write_one(body, dest)
    text = dest.read_text(encoding="utf-8")
    assert "ns0:" not in text
    reparsed = ET.parse(dest).getroot()            # still valid XML
    assert X._local(reparsed.tag) == "process"


# --- degrade + safety --------------------------------------------------------

def test_standalone_export_extracts_to_itself(tmp_path):
    """Given a single .bpobject (root IS the body), it is one artifact - the tool
    is safe to run on anything, not just releases."""
    b = _body("Solo", ns=False)
    p = tmp_path / "solo.bpobject"
    ET.ElementTree(b).write(p, encoding="utf-8", xml_declaration=True)
    items = X.extract(p)
    assert len(items) == 1
    assert items[0][0] == "Solo.bpobject"          # object ext from the .bpobject suffix


def test_duplicate_names_do_not_collide(tmp_path):
    p = _write(tmp_path, _release(
        [("object", "Dup"), ("object", "Dup")], with_stub=False))
    names = [fn for fn, _, _ in X.extract(p)]
    assert names == ["Dup.bpobject", "Dup (2).bpobject"]


@pytest.mark.parametrize("raw,expect", [
    ("Utility - File Management", "Utility - File Management"),
    ('bad:name*with?illegal"chars', "badnamewithillegalchars"),
    ("   ", "artifact"),                            # never empty
    ("trailing.", "trailing"),
])
def test_safe_name(raw, expect):
    assert X._safe_name(raw) == expect
