"""Controls for the mechanical fixer.

The dangerous operation here is the rename: a data item whose name moves but
whose references do not produces a file that parses cleanly, imports cleanly,
and fails in production. So most of these tests are about refusing, not fixing.
A fixer that never declines is a fixer nobody should run on a bank's estate.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

from fix_mechanical import (apply_rename, apply_retype, artifact_spans,  # noqa: E402
                            plan_rename, plan_retype, stage_span)

# A minimal artifact with the two reference shapes a rename must follow:
# [Name] inside an expression, and stage="Name" on an output.
ART = '''<object id="1" name="Bank - Thing"><process name="Bank - Thing">
<stage stageid="s1" name="i_nr_Order" type="Data"><datatype>text</datatype></stage>
<stage stageid="s2" name="Calc" type="Calculation">
<calculation expression="[i_nr_Order] &amp; &quot;x&quot;" stage="i_nr_Order"/></stage>
<stage stageid="s3" name="Act" type="Action">
<inputs><input name="p" expr="[i_nr_Order]"/></inputs></stage>
</process></object>'''

RELEASE = ('<bpr:release xmlns:bpr="http://x">' + ART +
           '<bpr:contents><object id="1" name="Bank - Thing" /></bpr:contents>'
           "</bpr:release>")

STAGES = {"s1": {"name": "i_nr_Order", "type": "Data", "datatype": "text"}}


def span_of(raw):
    spans = artifact_spans(raw)
    assert len(spans) == 1, f"expected 1 artifact span, got {len(spans)}"
    return spans[0]


# --------------------------------------------------------------------------- #
# locating
# --------------------------------------------------------------------------- #
def test_manifest_stubs_are_not_artifacts():
    """A .bprelease repeats every artifact as an empty stub. Treating a stub as
    an artifact is how the parser once invented phantom processes."""
    s = span_of(RELEASE)
    assert s.name == "Bank - Thing"
    assert "<stage" in RELEASE[s.start:s.end]


def test_stage_span_is_bounded_by_its_own_element():
    s = span_of(ART)
    a, b = stage_span(ART, s, "s1")
    body = ART[a:b]
    assert body.startswith("<stage") and body.endswith("</stage>")
    assert "s2" not in body


# --------------------------------------------------------------------------- #
# retype
# --------------------------------------------------------------------------- #
def test_retype_changes_exactly_one_datatype():
    edit = plan_retype(STAGES, {"rule_id": "X", "stageids": ["s1"]})[0]
    edit["to"] = "password"
    out, err = apply_retype(ART, span_of(ART), edit)
    assert err is None
    assert "<datatype>password</datatype>" in out
    assert out.count("<datatype>") == ART.count("<datatype>")


# --------------------------------------------------------------------------- #
# rename — the decidable value, and every way it can go wrong
# --------------------------------------------------------------------------- #
def test_rename_target_is_computed_from_the_datatype():
    """text => txt_. The standard's token table gives exactly one answer, which
    is what makes this fix automatic rather than a suggestion."""
    edits = plan_rename(STAGES, {"rule_id": "X", "stageids": ["s1"]})
    assert len(edits) == 1 and edits[0]["to"] == "i_txt_Order"


def test_rename_moves_every_reference():
    edit = plan_rename(STAGES, {"rule_id": "X", "stageids": ["s1"]})[0]
    out, err = apply_rename(ART, span_of(ART), edit)
    assert err is None, err
    assert "i_nr_Order" not in out, "a reference to the old name survived"
    assert out.count("[i_txt_Order]") == 2      # calculation + input expr
    assert out.count('stage="i_txt_Order"') == 1
    assert out.count('name="i_txt_Order"') == 1


def test_rename_preserves_everything_else_byte_for_byte():
    edit = plan_rename(STAGES, {"rule_id": "X", "stageids": ["s1"]})[0]
    out, _ = apply_rename(ART, span_of(ART), edit)
    # i_nr_ -> i_txt_ is one character longer, four occurrences.
    assert len(out) == len(ART) + 4
    assert out.replace("i_txt_Order", "i_nr_Order") == ART


def test_rename_refuses_on_name_collision():
    clash = ART.replace('name="Calc"', 'name="i_txt_Order"')
    edit = plan_rename(STAGES, {"rule_id": "X", "stageids": ["s1"]})[0]
    out, err = apply_rename(clash, span_of(clash), edit)
    assert err and "already exists" in err
    assert out == clash, "a refused fix must not modify the file"


def test_rename_refuses_when_the_stage_is_not_in_this_artifact():
    edit = dict(plan_rename(STAGES, {"rule_id": "X", "stageids": ["s1"]})[0],
                stageid="nope")
    out, err = apply_rename(ART, span_of(ART), edit)
    assert err and out == ART


def test_plan_skips_a_stage_whose_datatype_has_no_token():
    """No token, no computable target. Better to hand it off than to guess."""
    assert not plan_rename({"s1": {"name": "i_nr_Order", "type": "Data",
                                   "datatype": "sometypewedontknow"}},
                           {"rule_id": "X", "stageids": ["s1"]})


def test_plan_skips_an_unprefixed_name():
    assert not plan_rename({"s1": {"name": "Order ID", "type": "Data",
                                   "datatype": "text"}},
                           {"rule_id": "X", "stageids": ["s1"]})
