"""Controls for the deterministic coding-rules audit.

The training export exercises three of the eight checks. The code checks scan
zero in-scope stages there, so on that evidence alone a clean report and a
broken check are the same picture — which is the failure this project has
already paid for once (`queues=0` read as "no queues").

So every check gets a planted positive and, where it can misfire, a negative.
The negatives matter more: the first run of this auditor reported `block` for a
`MessageBox.Show` that was commented out, and every one of its four block-level
findings sat in vendor code the bank cannot change.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

from audit_rules import (NOT_IN_STANDARD, SECTIONS, El, St, _collect,  # noqa: E402
                         audit, live_code, load_elements, load_shipped)

REG = Path(__file__).resolve().parent.parent / "data" / "vbo_registry.yaml"
EXPORT = Path(__file__).resolve().parent.parent / "exports"


def st(**kw) -> St:
    base = dict(artifact="Bank - Thing", art_type="object", page="Main Page",
                id="s1", name="Stage", type="Code", narrative="does a thing",
                code="", datatype="", expression="")
    base.update(kw)
    return St(**base)


def fired(stages, rule_id):
    for c in audit(stages):
        if c.id == rule_id:
            return c.findings
    raise AssertionError(f"no check named {rule_id}")


# --------------------------------------------------------------------------- #
# live_code — the comment/string stripper
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("src", [
    "'MessageBox.Show(\"hi\")",                    # VB line comment
    "// MessageBox.Show()",                        # C# line comment
    "REM MessageBox.Show()",                       # VB REM
    'Log("never call MessageBox.Show here")',      # inside a string literal
    'x = "a" & "MessageBox.Show" & "b"',           # concatenated literal
])
def test_dead_text_is_not_code(src):
    assert "MessageBox.Show" not in live_code(src), src


def test_live_call_survives():
    assert "MessageBox.Show" in live_code('MessageBox.Show("real")')


def test_code_after_a_string_still_counts():
    """The stripper must not eat the rest of the line with the literal."""
    assert "Process.Start" in live_code('Log("done") : Process.Start(app)')


# --------------------------------------------------------------------------- #
# per-check positives and negatives
# --------------------------------------------------------------------------- #
def test_blocking_ui_positive():
    f = fired([st(code=live_code('MessageBox.Show("x")'))], "CODE-BLOCKING-UI")
    assert len(f) == 1 and f[0].severity == "block"


def test_blocking_ui_negative_when_commented():
    assert not fired([st(code=live_code("'MessageBox.Show(\"x\")"))],
                     "CODE-BLOCKING-UI")


def test_script_exec_positive():
    f = fired([st(code=live_code("System.Diagnostics.Process.Start(app)"))],
              "CODE-SCRIPT-EXEC")
    assert len(f) == 1 and f[0].severity == "block"


def test_com_unreleased_positive():
    f = fired([st(id="a", code="x = GetObject(path)")], "CODE-COM-UNRELEASED")
    assert len(f) == 1 and f[0].stageids == ["a"]


def test_com_released_elsewhere_in_same_artifact_is_clean():
    """Acquire and release in different stages is correct, and is the normal
    shape. A per-stage check here would be all false positives."""
    assert not fired([st(id="a", code="x = GetObject(path)"),
                      st(id="b", code="Marshal.ReleaseComObject(x)")],
                     "CODE-COM-UNRELEASED")


def test_code_in_process_positive():
    f = fired([st(art_type="process", code="x = 1")], "CODE-IN-PROCESS")
    assert len(f) == 1


def test_code_in_object_is_clean():
    assert not fired([st(art_type="object", code="x = 1")], "CODE-IN-PROCESS")


@pytest.mark.parametrize("name", ["Data1", "Decision12", "Action3"])
def test_default_name_positive(name):
    assert fired([st(type="Data", name=name)], "STAGE-DEFAULT-NAME")


@pytest.mark.parametrize("name", ["Data for order", "Order ID", "Decision maker"])
def test_real_name_is_clean(name):
    assert not fired([st(type="Data", name=name)], "STAGE-DEFAULT-NAME")


def test_secret_not_password_positive():
    f = fired([st(type="Data", name="SAP Password", datatype="Text")],
              "DATA-SECRET-NOT-PASSWORD")
    assert len(f) == 1 and f[0].severity == "block" and f[0].fix_is_mechanical


def test_secret_typed_password_is_clean():
    assert not fired([st(type="Data", name="SAP Password", datatype="Password")],
                     "DATA-SECRET-NOT-PASSWORD")


def test_exception_without_detail_positive():
    assert fired([st(type="Exception", narrative="", expression="")],
                 "EXC-EMPTY-DETAIL")


def test_exception_with_detail_is_clean():
    assert not fired([st(type="Exception", expression='"Order not found"')],
                     "EXC-EMPTY-DETAIL")


def test_narrative_present_is_clean():
    assert not fired([st(type="Action", narrative="Reads the order")],
                     "NARRATIVE-MISSING")


# --------------------------------------------------------------------------- #
# naming — BP Coding Rules v5.0, scope_datatype_name
# --------------------------------------------------------------------------- #
def test_prefix_contradicting_datatype_fires():
    f = fired([st(type="Data", name="i_txt_Order", datatype="number")],
              "NAME-PREFIX-CONTRADICTS-TYPE")
    assert len(f) == 1 and f[0].fix_is_mechanical


def test_prefix_agreeing_with_datatype_is_clean():
    assert not fired([st(type="Data", name="i_txt_Order", datatype="text")],
                     "NAME-PREFIX-CONTRADICTS-TYPE")


@pytest.mark.parametrize("name,dt", [
    ("g_datetime_Stamp", "datetime"),   # must not parse as date_ + "time_Stamp"
    ("o_timespan_Wait", "timespan"),    # must not parse as time_ + "span_Wait"
    ("io_col_Orders", "collection"),
    ("e_pwd_SAP", "password"),
    ("nr_Attempts", "number"),          # scope prefix is optional
])
def test_token_table_parses_the_standards_own_prefixes(name, dt):
    assert not fired([st(type="Data", name=name, datatype=dt)],
                     "NAME-PREFIX-CONTRADICTS-TYPE"), name
    assert not fired([st(type="Data", name=name, datatype=dt)],
                     "NAME-NO-PREFIX"), name


def test_unprefixed_name_fires_but_only_as_likely():
    f = fired([st(type="Data", name="Order ID", datatype="text")],
              "NAME-NO-PREFIX")
    assert len(f) == 1 and f[0].confidence == "likely"


def test_contradiction_check_counts_only_what_it_can_judge():
    """An item with no prefix is invisible to this rule. Counting it as
    scanned would report a confident zero from a check that judged nothing."""
    checks = {c.id: c for c in audit([st(type="Data", name="Order ID",
                                         datatype="text")])}
    assert checks["NAME-PREFIX-CONTRADICTS-TYPE"].scanned == 0
    assert checks["NAME-NO-PREFIX"].scanned == 1


# --------------------------------------------------------------------------- #
# error handling — Save Screenshot on System Exception
# --------------------------------------------------------------------------- #
def test_recover_without_screenshot_fires():
    f = fired([st(type="Recover", name="Recover"),
               st(type="Resume", name="Resume")], "EXC-NO-SCREENSHOT")
    assert len(f) == 1


def test_recover_with_screenshot_is_clean():
    assert not fired([st(type="Recover", name="Recover"),
                      st(type="Action", name="Grab",
                         calls="Utility - Image.Save Screenshot"),
                      st(type="Resume", name="Resume")], "EXC-NO-SCREENSHOT")


def test_page_without_recover_is_not_scanned():
    checks = {c.id: c for c in audit([st(type="Action", name="Do it")])}
    assert checks["EXC-NO-SCREENSHOT"].scanned == 0


# --------------------------------------------------------------------------- #
# the whole-report control: clean input must produce an empty report
# --------------------------------------------------------------------------- #
def test_a_clean_artifact_produces_no_findings():
    """Prompt 03: "An empty array is a correct answer and is expected often."
    A checker that cannot return empty is a checker that always fires."""
    # log_inhibit on the two executing stages: a deployment-ready artifact is
    # silent on success, and the Exception stage rightly still logs.
    clean = [
        st(type="Action", name="Read the order", narrative="Reads the order",
           log_inhibit=True),
        st(type="Data", name="i_txt_OrderId", datatype="Text"),
        st(type="Exception", name="Order missing", expression='"not found"'),
        st(type="Code", name="Trim", narrative="trims", code="x = y.Trim()",
           log_inhibit=True),
    ]
    assert not [f for c in audit(clean) for f in c.findings]


def test_every_check_reports_what_it_scanned():
    """A check that examined nothing must not look like a check that passed."""
    for c in audit([st(type="Data", name="Order ID")]):
        assert isinstance(c.scanned, int), c.id


# --------------------------------------------------------------------------- #
# Application Modeller — robust attributes
# --------------------------------------------------------------------------- #
def el(*matched, name="Textbox"):
    return El(artifact="Bank - Thing", name=name, matched_on=list(matched))


def brittle(elements):
    for c in audit([], elements):
        if c.id == "ELEMENT-BRITTLE-MATCH":
            return c
    raise AssertionError("check missing")


def test_position_only_match_is_a_warning():
    f = brittle([el("X", "Y", "Ordinal")]).findings
    assert len(f) == 1 and f[0].severity == "warn"


def test_stable_plus_positional_is_info_but_certain():
    """The v5.0 text (held 2026-07-26) explicitly flags positional attributes,
    so this is no longer a hedge: severity stays info because a stable anchor is
    present, but the finding is asserted (certain), not merely surfaced."""
    f = brittle([el("WindowText", "Ordinal")]).findings
    assert len(f) == 1 and f[0].severity == "info" and f[0].confidence == "certain"
    assert "Application Modeller" in f[0].rule_section


def test_stable_only_match_is_clean():
    assert not brittle([el("WindowText", "ClassName", "TypeName")]).findings


def test_attributes_not_in_use_are_not_judged():
    """Blue Prism records X/Y on every element. Only `inuse="True"` takes part
    in the match, and load_elements is what enforces that."""
    assert not brittle([el("TypeName")]).findings


def test_real_export_elements_carry_their_match_attributes():
    """Guards the loader, not the rule: if `inuse` parsing broke, every element
    would look clean and this check would silently pass on everything."""
    els = load_elements(_collect([str(EXPORT)]))
    assert len(els) > 20, f"only {len(els)} element(s) loaded"
    assert all(e.matched_on for e in els)
    assert any("Ordinal" in e.matched_on for e in els), \
        "expected at least one ordinal-matched element in this export"


# --------------------------------------------------------------------------- #
# LOG-STAGE-ON-SUCCESS — deployment logging
#
# The trap here is the exclusion list, not the match. "Errors Only" means the
# exception path MUST keep logging, so a check that flagged every uninhibited
# stage would demand the bank silence exactly the stages support depends on.
# --------------------------------------------------------------------------- #
def test_stage_logging_on_success_is_flagged():
    f = fired([st(type="Action", name="Click Save")], "LOG-STAGE-ON-SUCCESS")
    assert f and "1 of 1" in f[0].observed


def test_inhibited_stage_is_not_flagged():
    assert not fired([st(type="Action", name="Click Save", log_inhibit=True)],
                     "LOG-STAGE-ON-SUCCESS")


@pytest.mark.parametrize("stype", ["Exception", "Recover", "Resume"])
def test_error_path_must_keep_logging(stype):
    """Under Errors Only these are the stages that SHOULD log. Flagging them
    would invert the rule."""
    assert not fired([st(type=stype, name="Handle it")], "LOG-STAGE-ON-SUCCESS")


@pytest.mark.parametrize("stype", ["Start", "End", "Note", "Anchor", "Block",
                                   "SubSheetInfo", "ProcessInfo", "Data"])
def test_structure_stages_are_not_scanned_for_logging(stype):
    c = next(c for c in audit([st(type=stype, name="x")], [])
             if c.id == "LOG-STAGE-ON-SUCCESS")
    assert c.scanned == 0 and not c.findings


def test_logging_scanned_counts_only_judgeable_stages():
    stages = [st(type="Action", name="a"), st(type="Note", name="n"),
              st(type="Exception", name="e"), st(type="Decision", name="d")]
    c = next(c for c in audit(stages, []) if c.id == "LOG-STAGE-ON-SUCCESS")
    assert c.scanned == 2, "only Action and Decision can be judged here"


# --------------------------------------------------------------------------- #
# IGNORE-VALUE-ABSENT — the global '###IGNORE SCREEN ELEMENT###' marker
# --------------------------------------------------------------------------- #
IGNORE = "###IGNORE SCREEN ELEMENT###"


def test_writer_without_the_ignore_marker_is_flagged():
    f = fired([st(type="Write", name="Write Name", steps="[Name]")],
              "IGNORE-VALUE-ABSENT")
    assert f and IGNORE in f[0].observed


def test_literal_anywhere_in_the_artifact_clears_it():
    stages = [st(type="Write", name="Write Name", steps="[Name]"),
              st(type="Data", name="Ignore", datatype="Text", initial=IGNORE)]
    assert not fired(stages, "IGNORE-VALUE-ABSENT")


def test_an_item_named_for_the_marker_clears_it():
    """The value usually lives in an environment variable, whose VALUE does not
    survive export — only its name does. A name that plainly means it counts."""
    stages = [st(type="Write", name="Write Name", steps="[Name]"),
              st(type="Data", name="g_txt_Ignore Screen Element", datatype="Text")]
    assert not fired(stages, "IGNORE-VALUE-ABSENT")


def test_artifact_with_no_write_stage_is_not_judged():
    c = next(c for c in audit([st(type="Action", name="a")], [])
             if c.id == "IGNORE-VALUE-ABSENT")
    assert c.scanned == 0 and not c.findings


def test_ignore_marker_is_scoped_per_artifact():
    """A marker defined in one object does not excuse another."""
    stages = [st(artifact="Bank - A", type="Write", name="W", steps="[x]"),
              st(artifact="Bank - A", type="Data", name="Ign", initial=IGNORE,
                 datatype="Text"),
              st(artifact="Bank - B", type="Write", name="W", steps="[x]")]
    f = fired(stages, "IGNORE-VALUE-ABSENT")
    assert [x.artifact for x in f] == ["Bank - B"]


# --------------------------------------------------------------------------- #
# provenance — prompt 03: a rule the standard does not state is not a rule
# --------------------------------------------------------------------------- #
def test_every_check_declares_where_its_rule_comes_from():
    for c in audit([st(type="Data", name="i_txt_X", datatype="text")], []):
        assert c.source, c.id


def test_untraceable_checks_say_so_rather_than_borrowing_authority():
    untraced = [c.id for c in audit([], []) if c.source == NOT_IN_STANDARD]
    # Once the full v5.0 text was held (2026-07-26), NARRATIVE-MISSING mapped to
    # "Descriptions" and EXC-EMPTY-DETAIL to "Error Handling". Only CODE-IN-
    # PROCESS has no line in the standard behind it: the standard separates
    # logic from application interaction but never bans a code stage in a
    # process. It may be kept, but never presented as a standard violation.
    assert set(untraced) == {"CODE-IN-PROCESS"}, untraced


def test_traced_findings_cite_a_real_section_not_unmapped():
    """The full text is held now, so a finding from a traceable check must name
    its section. UNMAPPED survives only on CODE-IN-PROCESS, which the standard
    does not state."""
    stages = [
        st(type="Data", name="SAP Password", datatype="Text"),      # secret
        st(type="Action", name="Do it", narrative=""),               # narrative
        st(type="Data", name="i_txt_Order", datatype="number"),      # prefix clash
    ]
    for c in audit(stages, []):
        for f in c.findings:
            if c.id == "CODE-IN-PROCESS":
                continue
            assert f.rule_section != "UNMAPPED", c.id
            assert f.rule_section, c.id


def test_now_traceable_checks_name_their_section():
    f = fired([st(type="Action", name="Do it", narrative="")], "NARRATIVE-MISSING")
    assert f and "Descriptions" in f[0].rule_section


def test_coverage_table_lists_every_section_of_the_standard():
    assert len(SECTIONS) == 12
    for section, covered, ids, gap in SECTIONS:
        assert covered in ("full", "partial", "none"), section
        # A section claimed as covered must name the checks that cover it, and
        # one that is not must say what it needs. Neither may be silent.
        assert (ids if covered != "none" else gap), section


def test_covered_sections_name_checks_that_actually_exist():
    real = {c.id for c in audit([], [])}
    for section, _covered, ids, _gap in SECTIONS:
        for cid in ids:
            assert cid in real, f"{section} claims {cid}, which does not exist"


# --------------------------------------------------------------------------- #
# scoping
# --------------------------------------------------------------------------- #
def test_registry_marks_vendor_objects_out_of_scope():
    shipped = load_shipped(REG)
    assert "ms excel vbo" in shipped
    assert "utility - environment" in shipped
    assert not any("centrix" in n for n in shipped), \
        "project-authored objects must stay in scope"
