"""Controls for the answer verifier — the gate every model output passes.

This module had no tests, which is the wrong thing to leave untested: it is the
only thing standing between a plausible-sounding model answer and a document
someone acts on. A verifier that silently stops verifying looks exactly like a
verifier that keeps passing everything, and the first symptom is a hallucinated
stageid reaching a reviewer.

So the tests here are mostly negatives. `check_change_ledger` passing on a good
answer proves very little; what matters is that it FAILS on a dropped change, on
an invented id, and on the same id claimed twice.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))

import verify_llm_output as V   # noqa: E402


@pytest.fixture(autouse=True)
def clean_slate():
    """The module accumulates results in globals, so every test starts empty or
    inherits another test's verdict."""
    V._fails.clear()
    V._warns.clear()
    V._oks.clear()
    yield


def fails() -> str:
    return " | ".join(V._fails)


# --------------------------------------------------------------------------- #
# the change ledger — the failure that actually matters
# --------------------------------------------------------------------------- #
TRUTH = {"s1", "s2", "s3"}


def test_a_balanced_answer_passes():
    V.check_change_ledger(
        {"changes": [{"stageids": ["s1", "s2"]}], "behaviour_unchanged": ["s3"]},
        TRUTH)
    assert not V._fails
    assert any("balances" in m for m in V._oks)


def test_a_dropped_change_fails():
    """The model summarised instead of listing. This is the whole point."""
    V.check_change_ledger({"changes": [{"stageids": ["s1"]}],
                           "behaviour_unchanged": ["s2"]}, TRUTH)
    assert "dropped" in fails() and "s3" in fails()


def test_an_invented_stageid_fails():
    V.check_change_ledger({"changes": [{"stageids": ["s1", "s2", "s3", "s9"]}]},
                          TRUTH)
    assert "not in the diff" in fails() and "s9" in fails()


def test_the_same_change_claimed_twice_fails():
    """Once in changes[] and again in behaviour_unchanged. Both cannot be true,
    and the count would otherwise balance."""
    V.check_change_ledger({"changes": [{"stageids": ["s1", "s2", "s3"]}],
                           "behaviour_unchanged": ["s1"]}, TRUTH)
    assert "claimed twice" in fails() and "s1" in fails()


def test_without_the_diff_it_warns_that_it_cannot_check_drops():
    """Passing no --changes must not look like a pass. It downgrades to a
    duplicate check and has to say so."""
    V.check_change_ledger({"changes": [{"stageids": ["s1"]}]}, None)
    assert not V._fails
    assert any("NOT" in m and "drops" in m for m in V._warns)


def test_an_answer_with_no_changes_key_is_not_judged():
    """A 04 or 05 answer is not a comparison; the ledger must stay silent
    rather than fail it for missing a field it never had."""
    V.check_change_ledger({"artifact": "X"}, TRUTH)
    assert not V._fails and not V._oks


# --------------------------------------------------------------------------- #
# load_change_set — every kind of finding is ground truth, not just the easy two
# --------------------------------------------------------------------------- #
def test_change_set_includes_unclassified(tmp_path):
    """An unclassified change is the one most likely to be quietly dropped, by
    the tool as much as by the model."""
    p = tmp_path / "changes.json"
    p.write_text('{"added":[{"stageid":"a"}],"removed":[{"stageid":"r"}],'
                 '"changed":[{"stageid":"c"}],"unclassified":[{"stageid":"u"}]}',
                 encoding="utf-8")
    assert V.load_change_set(p) == {"a", "r", "c", "u"}


def test_change_set_ignores_page_findings(tmp_path):
    """Page-level findings carry no stageid, so they are not part of the ledger
    the model must balance. If they leaked in, every answer would fail."""
    p = tmp_path / "changes.json"
    p.write_text('{"added":[{"stageid":"a"}],'
                 '"sheets":[{"kind":"page_renamed","page":"P"}]}', encoding="utf-8")
    assert V.load_change_set(p) == {"a"}


# --------------------------------------------------------------------------- #
# vocabulary — `target` is the current name, `modified` the old one
# --------------------------------------------------------------------------- #
class _Estate:
    """Minimal stand-in: check_stageids only reaches for stages_by_artifact."""
    def __init__(self, artifact, ids):
        class S:
            def __init__(self, i):
                self.id, self.subsheet = i, "Main Page"
        self.stages_by_artifact = {artifact: [S(i) for i in ids]}


@pytest.mark.parametrize("key", ["target", "modified", "artifact", "object_name"])
def test_every_accepted_name_for_the_artifact_resolves(key):
    """`modified` was renamed to `target` when the diff adopted the standard's
    own vocabulary. The old name stays accepted, or every answer written against
    the previous prompt fails on wording rather than on substance."""
    V.check_stageids({key: "Bank - Thing", "changes": [{"stageids": ["s1"]}]},
                     _Estate("Bank - Thing", ["s1"]))
    assert not V._fails, fails()


def test_an_answer_naming_no_artifact_fails():
    """The control: the keys above must be doing real work. If this passed, the
    check would be resolving against nothing."""
    V.check_stageids({"changes": [{"stageids": ["s1"]}]},
                     _Estate("Bank - Thing", ["s1"]))
    assert "is not in the export" in fails()


def test_a_stageid_absent_from_the_export_is_flagged():
    V.check_stageids({"target": "Bank - Thing",
                      "changes": [{"stageids": ["ghost"]}]},
                     _Estate("Bank - Thing", ["s1"]))
    assert "invented" in fails() and "ghost" in fails()


def test_a_removed_stage_is_not_a_hallucination():
    """A deletion is legitimately cited and legitimately absent from the target.
    Without the diff's ids as extra_known, every correct deletion scores as
    invented -- which would punish the model for being right."""
    V.check_stageids({"target": "Bank - Thing", "changes": [{"stageids": ["gone"]}]},
                     _Estate("Bank - Thing", ["s1"]), extra_known={"gone"})
    assert not V._fails, fails()


# --------------------------------------------------------------------------- #
# the 04 stage ledger and the 05 section ledger
#
# Both were found untested by mutation: disabling either one's drop detection
# left the whole suite green. A ledger that has stopped checking is invisible
# from the outside -- it prints the same "balances" line it always did.
# --------------------------------------------------------------------------- #
class _St:
    def __init__(self, i, stype="Action", name="", subsheet="Main Page"):
        self.id, self.type, self.name, self.subsheet = i, stype, name, subsheet


class _Full:
    """check_stage_ledger reads dead_code as well as the stages it is handed."""
    dead_code: list = []


def _spec(sections, excluded=(), page="Main Page"):
    return {"artifact": "Bank - Thing", "page": page,
            "sections": [{"stageids": list(s)} for s in sections],
            "excluded": list(excluded)}


def test_stage_ledger_balances_on_a_complete_answer():
    V.check_stage_ledger(_spec([["s1", "s2"]]), _Full(), [_St("s1"), _St("s2")])
    assert not V._fails
    assert any("LEDGER balances" in m for m in V._oks)


def test_stage_ledger_catches_a_dropped_stage():
    V.check_stage_ledger(_spec([["s1"]]), _Full(), [_St("s1"), _St("s2")])
    assert "dropped" in fails() and "s2" in fails()


def test_stage_ledger_catches_a_stage_claimed_twice():
    V.check_stage_ledger(_spec([["s1", "s2"], ["s2"]]), _Full(),
                         [_St("s1"), _St("s2")])
    assert "twice" in fails() and "s2" in fails()


def test_an_exclusion_the_analyzer_contradicts_fails():
    """"Excluded as cosmetic" over a live Action stage is where dropped logic
    hides, so the reason is checked against the parser, not taken on trust."""
    ans = _spec([["s1"]], excluded=[{"stageid": "s2", "reason": "cosmetic"}])
    V.check_stage_ledger(ans, _Full(), [_St("s1"), _St("s2", "Action")])
    assert "contradicts" in fails()


def test_a_genuinely_cosmetic_exclusion_is_accepted():
    """The control: Note stages really are cosmetic, and rejecting them would
    fail every honest answer."""
    ans = _spec([["s1"]], excluded=[{"stageid": "s2", "reason": "cosmetic"}])
    V.check_stage_ledger(ans, _Full(), [_St("s1"), _St("s2", "Note")])
    assert not V._fails, fails()


SECTIONS = {"S1", "S2", "S3"}


def test_section_ledger_catches_a_dropped_section():
    V.check_section_ledger({"steps": [{"spec_sections": ["S1"]}],
                            "not_documented": [{"spec_section": "S2"}]}, SECTIONS)
    assert "dropped" in fails() and "S3" in fails()


def test_section_ledger_catches_an_invented_section():
    V.check_section_ledger({"steps": [{"spec_sections": ["S1", "S2", "S3", "S9"]}],
                            "not_documented": []}, SECTIONS)
    assert "not in any" in fails() and "S9" in fails()


def test_section_ledger_balances():
    V.check_section_ledger({"steps": [{"spec_sections": ["S1", "S2"]}],
                            "not_documented": [{"spec_section": "S3"}]}, SECTIONS)
    assert not V._fails
    assert any("SECTION LEDGER balances" in m for m in V._oks)


def test_section_ledger_warns_when_it_cannot_check_drops():
    V.check_section_ledger({"steps": [{"spec_sections": ["S1"]}],
                            "not_documented": []}, None)
    assert not V._fails
    assert any("NOT checked for drops" in m for m in V._warns)


# --------------------------------------------------------------------------- #
# secrets
# --------------------------------------------------------------------------- #
class _Secretive:
    def __init__(self, value):
        class D:
            name, datatype, initial_value = "pwd_SAP", "Password", value
        self.data_items = [D()]


def test_a_reproduced_password_value_fails():
    V.check_secrets({"what": "the password is hunter2"}, _Secretive("hunter2"))
    assert "Password data item" in fails()


def test_an_unrelated_answer_does_not_trip_the_secret_check():
    V.check_secrets({"what": "reads the customer name"}, _Secretive("hunter2"))
    assert not V._fails
