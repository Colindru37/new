"""Parser conformance against the documented real Blue Prism schema.

Each test pins a semantic the "BP Description" reference states explicitly —
the ones the synthetic fixtures used to hide, and the ones most likely to bite
on the first real export: namespaced XML, GUID subsheet ids, presence-based
<private/>, an omitted <subsheetid>, and .bprelease bundles.

XML is built inline (not added to tests/fixtures/) so the golden snapshot stays
stable.
"""
from pathlib import Path

import pytest

from bp_estate.bpexpr import unwrap_literal
from bp_estate.model import Estate
from bp_estate.parse import parse_file

MAIN_ID = "8f1d3a52-0b7e-4c19-9a2f-6d5e4c3b2a10"
SUB_ID = "c4e7b9a1-2d38-4f6b-8e05-1a9c7d2f3b44"


def _write(tmp_path: Path, name: str, xml: str) -> Path:
    p = tmp_path / name
    p.write_text(xml, encoding="utf-8")
    return p


def _parse(tmp_path: Path, name: str, xml: str) -> Estate:
    estate = Estate()
    parse_file(_write(tmp_path, name, xml), estate)
    return estate


PROC = f"""<process name="P" preferredid="p1" published="true">
  <view><camera x="0" y="0"/></view>
  <subsheet subsheetid="{MAIN_ID}" published="true"><name>Main Page</name></subsheet>
  <subsheet subsheetid="{SUB_ID}" published="false"><name>Do Post</name></subsheet>
  <stage stageid="s1" name="OnMain" type="Data">
    <datatype>Number</datatype>
    <private/>
  </stage>
  <stage stageid="s2" name="OnSub" type="Data">
    <subsheetid>{SUB_ID}</subsheetid>
    <datatype>Text</datatype>
  </stage>
  <stage stageid="s3" name="Go" type="Page">
    <page ref="{SUB_ID}"/>
  </stage>
</process>
"""


def test_absent_subsheetid_means_main_page(tmp_path):
    est = _parse(tmp_path, "a.bpprocess", PROC)
    stages = {s.name: s for s in est.stages_by_artifact["P"]}
    # doc: "if the child node subsheetid does not exist, the stage is in Main Page"
    assert stages["OnMain"].subsheet == "Main Page"


def test_subsheet_guid_resolves_to_page_name(tmp_path):
    est = _parse(tmp_path, "a.bpprocess", PROC)
    stages = {s.name: s for s in est.stages_by_artifact["P"]}
    # a raw GUID here would leak into every human-facing report
    assert stages["OnSub"].subsheet == "Do Post"
    assert stages["Go"].page_ref == "Do Post"


def test_private_is_presence_based(tmp_path):
    est = _parse(tmp_path, "a.bpprocess", PROC)
    scopes = {d.name: d.scope for d in est.data_items}
    # <private/> is empty: its mere existence means private
    assert scopes["OnMain"] == "local"
    assert scopes["OnSub"] == "session"


def test_published_captured_on_artifact_and_pages(tmp_path):
    est = _parse(tmp_path, "a.bpprocess", PROC)
    assert est.artifacts[0].published is True
    pub = {p.name: p.published for p in est.pages}
    assert pub == {"Main Page": True, "Do Post": False}


def test_unpublished_artifact_flagged(tmp_path):
    est = _parse(tmp_path, "b.bpprocess",
                 '<process name="U" preferredid="u1" published="false"/>')
    assert est.artifacts[0].published is False


def test_namespaced_export_parses(tmp_path):
    """Real exports are commonly namespaced; tag matching must be local-name."""
    xml = PROC.replace(
        "<process ",
        '<process xmlns="http://www.blueprism.co.uk/product/process" ',
        1,
    )
    est = _parse(tmp_path, "ns.bpprocess", xml)
    assert est.artifacts[0].name == "P"
    assert {s.name for s in est.stages_by_artifact["P"]} == {"OnMain", "OnSub", "Go"}
    assert {p.name for p in est.pages} == {"Main Page", "Do Post"}


def test_type_comes_from_extension(tmp_path):
    # no type attribute at all -> the .bpobject extension decides
    est = _parse(tmp_path, "o.bpobject", '<process name="O" preferredid="o1"/>')
    assert est.artifacts[0].type == "object"


# The shape below is taken from a real Blue Prism export (the Foundation
# Training consolidation exercise), not from the reference doc. Two things in it
# are load-bearing and neither was guessable:
#
#   1. every artifact is a <process>/<object> WRAPPER holding one <process>
#      body. The wrapper's tag is the type; the body repeats the name and has
#      no id. Iterating every <process> therefore counts a process twice.
#   2. <bpr:contents> repeats every artifact as an EMPTY stub. Those are
#      references, not artifacts, and have no name.
_RELEASE = """<bpr:release xmlns:bpr="http://www.blueprism.co.uk/product/release">
  <process id="a1" name="Proc A" published="true">
    <process name="Proc A" published="true">
      <stage stageid="s1" name="Start" type="Start"/>
    </process>
  </process>
  <object id="b1" name="Obj B" published="true">
    <process name="Obj B" published="true">
      <appdef><element name="W" type="Window"/></appdef>
      <stage stageid="s2" name="Start" type="Start"/>
    </process>
  </object>
  <object id="c1" name="Code Only VBO" published="true">
    <process name="Code Only VBO" published="true">
      <stage stageid="s3" name="Start" type="Start"/>
    </process>
  </object>
  <bpr:contents>
    <process id="a1"/>
    <object id="b1"/>
    <object id="c1"/>
  </bpr:contents>
</bpr:release>
"""


def test_release_yields_every_artifact_exactly_once(tmp_path):
    est = _parse(tmp_path, "r.bprelease", _RELEASE)
    names = [a.name for a in est.artifacts]
    assert names == sorted(names, key=names.index)          # no duplicates
    assert len(names) == 3, names                            # no phantom stubs
    assert {a.name: a.type for a in est.artifacts} == {
        "Proc A": "process",
        "Obj B": "object",
        "Code Only VBO": "object",   # typed by the wrapper, NOT by <appdef>
    }


def test_release_artifact_id_comes_from_the_wrapper(tmp_path):
    est = _parse(tmp_path, "r.bprelease", _RELEASE)
    assert {a.name: a.id for a in est.artifacts} == {
        "Proc A": "a1", "Obj B": "b1", "Code Only VBO": "c1",
    }


def test_release_without_artifacts_fails_loud(tmp_path):
    with pytest.raises(ValueError, match="no artifact found"):
        _parse(tmp_path, "empty.bprelease", "<bpr:release xmlns:bpr='urn:x'/>")


def test_broken_xml_fails_loud(tmp_path):
    with pytest.raises(ValueError, match="XML parse error"):
        _parse(tmp_path, "bad.bpprocess", "<process name='X'>")


@pytest.mark.parametrize("expr,value,literal", [
    ('"Payments"', "Payments", True),          # quoted text literal
    ('  "Payments"  ', "Payments", True),      # surrounding whitespace
    ('""', "", True),                          # empty literal
    ('5', "5", True),                          # bare number
    ('True', "True", True),                    # bare flag
    ('[TargetQueue]', "[TargetQueue]", False),  # data-item reference
    ('"PMT-" & [Id]', '"PMT-" & [Id]', False),  # concatenation
    ('"A" & "B"', '"A" & "B"', False),          # quoted at both ends, still computed
    ('Left([X], 3)', "Left([X], 3)", False),    # function call
    (None, None, False),
    ('', None, False),
])
def test_unwrap_literal(expr, value, literal):
    assert unwrap_literal(expr) == (value, literal)


# --------------------------------------------------------------------------- #
# Stage-type dispatch — pinned against a real bank process's type inventory,
# where the synthetic names we had guessed did not occur. Two branches were
# firing on names Blue Prism never emits ("Choice", and "Calculation" only),
# so the stages fell through to generic handling and their logic vanished with
# no error — the exact silent-skip these tests exist to prevent regressing.
# --------------------------------------------------------------------------- #
_CALC = f"""<process name="C" preferredid="c1" published="true">
  <subsheet subsheetid="{MAIN_ID}"><name>Main Page</name></subsheet>
  <stage stageid="s1" name="OneCalc" type="Calculation">
    <calculation expression="[a] + [b]" stage="Sum"/>
  </stage>
  <stage stageid="s2" name="ManyCalc" type="MultipleCalculation">
    <steps>
      <calculation expression="[a] * 2" stage="Double"/>
      <calculation expression="[b] - 1" stage="Less"/>
    </steps>
  </stage>
  <stage stageid="s3" name="Switch" type="ChoiceStart">
    <choices>
      <choice expression="[a] &gt; 1"><ontrue>t1</ontrue></choice>
      <choice expression="[a] &gt; 2"><ontrue>t2</ontrue></choice>
    </choices>
  </stage>
  <stage stageid="s4" name="SwitchEnd" type="ChoiceEnd">
    <onsuccess>after</onsuccess>
  </stage>
  <stage stageid="s5" name="Gate" type="Decision">
    <decision expression="[a] &gt; 0"/>
    <ontrue>t1</ontrue>
    <onfalse>t2</onfalse>
  </stage>
</process>
"""


def test_single_calculation_expression_captured(tmp_path):
    est = _parse(tmp_path, "c.bpprocess", _CALC)
    stages = {s.name: s for s in est.stages_by_artifact["C"]}
    assert stages["OneCalc"].expression == "[a] + [b]"


def test_multiple_calculation_keeps_every_step(tmp_path):
    """A MultipleCalculation is a distinct type; none of its steps may be lost."""
    est = _parse(tmp_path, "c.bpprocess", _CALC)
    stages = {s.name: s for s in est.stages_by_artifact["C"]}
    expr = stages["ManyCalc"].expression
    assert expr is not None
    assert "[a] * 2" in expr and "[b] - 1" in expr


def test_choicestart_branches_become_links(tmp_path):
    """The real type is ChoiceStart, not 'Choice'; its branches must be linked."""
    est = _parse(tmp_path, "c.bpprocess", _CALC)
    stages = {s.name: s for s in est.stages_by_artifact["C"]}
    assert set(stages["Switch"].links) >= {"t1", "t2"}


def test_choiceend_is_a_plain_merge(tmp_path):
    """ChoiceEnd carries no branches; it links onward via the generic handling."""
    est = _parse(tmp_path, "c.bpprocess", _CALC)
    stages = {s.name: s for s in est.stages_by_artifact["C"]}
    assert stages["SwitchEnd"].links == ["after"]


def test_decision_expression_and_stage_level_branches(tmp_path):
    """<decision expression=..> holds the condition; ontrue/onfalse are children
    of the STAGE (not <decision>), so both branch targets become links."""
    est = _parse(tmp_path, "c.bpprocess", _CALC)
    gate = {s.name: s for s in est.stages_by_artifact["C"]}["Gate"]
    assert gate.expression == "[a] > 0"
    assert set(gate.links) == {"t1", "t2"}


# --------------------------------------------------------------------------- #
# Application Modeller
# --------------------------------------------------------------------------- #
# Shapes below are copied from a real export. The stub case is the important
# one: Blue Prism gives EVERY object an <appdef>, so "has an appdef" does not
# mean "drives an application" - four of the six objects in the training
# release carry an empty one.
_APP_XML = """<bpr:release xmlns:bpr="http://www.blueprism.co.uk/product/release">
  <object id="o1" name="Centrix - Basic Actions">
    <process name="Centrix - Basic Actions">
      <appdef>
        <element name="Centrix Data Solutions">
          <element name="Login Window"><element name="Staff Number"/></element>
        </element>
        <apptypeinfo>
          <id>Win32Launch</id>
          <parameters>
            <parameter><name>Path</name><value>C:\Apps\Centrix.exe</value></parameter>
            <parameter><name>CommandLineParams</name><value></value></parameter>
          </parameters>
        </apptypeinfo>
      </appdef>
      <stage stageid="s1" name="Start" type="Start"/>
    </process>
  </object>
  <object id="o2" name="Centrix - Order Processing">
    <process name="Centrix - Order Processing">
      <appdef>
        <element name="Centrix Data Solutions">
          <element name="Orders Grid"/>
        </element>
        <apptypeinfo><id>Win32Attach</id></apptypeinfo>
      </appdef>
      <stage stageid="s2" name="Start" type="Start"/>
    </process>
  </object>
  <object id="o3" name="Utility - Collections">
    <process name="Utility - Collections">
      <appdef>
        <element name="Application Root"/>
        <apptypeinfo/>
      </appdef>
      <stage stageid="s3" name="Start" type="Start"/>
    </process>
  </object>
</bpr:release>
"""


def test_appdef_groups_objects_by_application(tmp_path):
    est = _parse(tmp_path, "apps.bprelease", _APP_XML)
    assert [a.name for a in est.applications] == ["Centrix Data Solutions"]
    app = est.applications[0]
    assert sorted(app.driven_by) == ["Centrix - Basic Actions", "Centrix - Order Processing"]
    assert sorted(app.launch_types) == ["Win32Attach", "Win32Launch"]
    assert app.launches is True
    assert app.executable == r"C:\Apps\Centrix.exe"


def test_appdef_stub_is_not_an_application(tmp_path):
    """A code-only VBO still carries an <appdef>. It drives nothing."""
    est = _parse(tmp_path, "apps.bprelease", _APP_XML)
    assert "Utility - Collections" not in {o for a in est.applications for o in a.driven_by}


def test_attach_only_application_is_flagged(tmp_path):
    xml = _APP_XML.replace("<id>Win32Launch</id>", "<id>Win32Attach</id>")
    est = _parse(tmp_path, "apps.bprelease", xml)
    assert est.applications[0].launches is False
