"""Golden-snapshot conformance test.

The fixtures must always produce byte-identical estate.json. This is the
cross-language conformance anchor: a future C#/.NET port is correct iff it
reproduces this same file.

To regenerate after an INTENTIONAL change:
    python -m bp_estate analyze tests/fixtures -o out
    copy out/estate.json tests/golden/fixtures.estate.json
"""
from pathlib import Path

from bp_estate.cli import run_analysis

GOLDEN = Path(__file__).parent / "golden" / "fixtures.estate.json"
FIXTURES = Path(__file__).parent / "fixtures"


def test_matches_golden(tmp_path):
    actual = run_analysis([str(FIXTURES)], tmp_path).dumps()
    expected = GOLDEN.read_text(encoding="utf-8")
    assert actual == expected, (
        "estate.json drifted from golden snapshot. If intentional, regenerate "
        "(see this file's docstring)."
    )
