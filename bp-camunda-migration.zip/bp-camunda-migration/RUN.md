# Blue Prism -> Fluxnova: run it, and what it is

One file. Three parts:

1. **COMMANDS** — copy/paste to migrate a new process
2. **WHAT THIS IS** — paste into an AI (Copilot/Gemini) so it has context
3. **THE AI PART** — the prompt that drives the whole run

---

# PART 1 — COMMANDS FOR A NEW PROCESS

You need two exports from Blue Prism:

- **PROCESS** = a release with just the process
- **COMBINED** = the same process PLUS the Objects group (bulk drag them in)

All scripts sit in one folder. Python 3.11+, no installs, no internet.

## 0. Prove the tools are intact (after copying or editing them)

    python bp_core.py --selftest
    python bp_full.py --selftest
    python bp_emit.py --selftest

All three must print `SELFTEST PASS`. If one fails, fix it before trusting any
output.

## 1. What is in the process?

    python bp_full.py "<PROCESS>" --summary
    python bp_full.py "<PROCESS>" -o est.json

`--summary` is numbers only (safe to photograph). Read the `blockers:` line.

## 2. Migrate it

    python bp_emit.py "<PROCESS>" -o out_bpmn --ns fluxnova

One `.bpmn` per process artifact. Import it into Fluxnova.

## 3. Check the migration

    python check.py out_bpmn\<file>.bpmn
    python audit3.py

- `check.py` -> element counts + `dangling flow endpoints: 0`
- `audit3.py` -> `ORPHANS: 0   DEAD ENDS: 0`

**Dead ends must be 0.** Any orphans should match dead code in `est.json` —
stages Blue Prism itself never reaches. That is a finding about the process,
not a bug. Cross-check the names against `est.json` -> `dead_code`.

Sanity-check the counts against step 1:

    serviceTask      = Action stages
    callActivity     = SubSheet (page call) stages
    exclusiveGateway = Decision + ChoiceStart/End + WaitStart
    process          = pages

## 4. Which objects can migrate, which need an API?

    python object_triage.py "<COMBINED>" -o object_triage.json
    python object_triage.py "<COMBINED>" --summary

Verdicts:

    ui-driving   drives a screen; NEEDS AN API (task 1). No tool can replace it.
    code-bound   no UI, logic sits in embedded C#. What to do depends on WHOSE
                 code it is: a SHIPPED VBO (Excel, file, collection, string
                 utils) gets replaced by a connector and the C# is thrown away;
                 a CUSTOM object must actually be ported (step 7 extracts it).
    logic-only   converts to BPMN today
    mixed        declares an app but no UI stages; inspect by hand

Objects named `Blueprism.Automate.*` are built into Blue Prism. They map to
native Fluxnova features and need nothing. They show as "not in export".

## 5. Migrate the objects that can be migrated

    python bp_emit.py "<COMBINED>" -o out_objects --ns fluxnova --objects

**WARNING:** on a bulk export this emits one file per object (hundreds). To
convert a single object, point it at that one `.bpobject` instead.

## 6. The binding sheet — the hand-off for every blocked object

    python api_facts.py "<PROCESS>" --tier all --triage object_triage.json --verdict ui-driving,code-bound --sheet -o bindings.txt

One block per blocked object. Each says **what blocks it and what to do**:

    ui-driving              -> needs an API for that application. Nothing else works.
    code-bound + shipped    -> REPLACE with a connector. Do NOT port the C#.
    code-bound + custom     -> port the code (extract it, step 7).

Plus a `BINDING:` line for whoever owns it to fill in (an API url, a Blue Prism
object, a script name). Plain text — edit it in Notepad.

## 7. Extract the embedded code (the logic BPMN cannot carry)

    python extract_code.py "<COMBINED>" -o code_out

Blue Prism hides real logic in Code stages (OAuth, token refresh, JWT, HTTP).
BPMN can only mark those `[BLOCKER code]`, so this writes the SOURCE out as
files plus `code_out\MANIFEST.txt` (what, where, how many lines).

By default it skips SHIPPED VBOs — their C# does what a connector already does,
so porting it is waste. Use `--tier all` to include them anyway.

If a process needs 0 lines extracted, nothing needs porting. That is a result.

## 8. API specs (optional, needs an AI)

    python api_facts.py "<PROCESS>" --tier all --triage object_triage.json -o api_facts_ui.json

Then per object: paste `00-CONTRACT` + the short `02` prompt + **one** object's
record into Copilot. Save the answer as `spec.json`. Verify it:

    python api_spec_check.py api_facts_ui.json spec.json

`CHECK PASS` = the model invented no field and dropped no action.

## What you end up with

    out_bpmn\      the process, structurally verified
    out_objects\   the objects that convert
    bindings.txt   every blocked object: what blocks it and what to do
    code_out\      the embedded code that must be ported, + MANIFEST.txt
    est.json       full inventory: dependencies, blockers, dead code

## If something breaks

    XML parse error   illegal control characters in the export. The tools strip
                      them and print "NOTE: stripped N illegal character
                      reference(s)". If it still fails, the error names the spot.
    objects: 0        the export has no objects. Re-export with the Objects group.
    SELFTEST FAIL     that copy of the script is mistyped. Fix it first.
    not well-formed   a bug in the emitter. Print the failing line with repr().

---

# PART 2 — WHAT THIS IS (paste into an AI for context)

## The goal

Migrate Blue Prism RPA automations to uFlow. **uFlow = Fluxnova = a FINOS fork
of Camunda 7 Community Edition.** It keeps the `camunda:` namespace, so stock
Camunda 7 BPMN deploys to it unchanged. This is **Camunda 7, not 8**:
expressions are JUEL `${...}`, not FEEL.

## Why this is not one big AI prompt

Blue Prism is two things at once:

    PROCESS layer (flow, decisions, loops, error handling)  ->  maps to BPMN
    OBJECT layer  (UI automation via Application Modeller)  ->  NO equivalent

Fluxnova has no hands — its only outbound verb is "call a JSON/XML API". So
UI-driving objects must be replaced by real APIs built by product teams. That is
the long pole of the programme and no tool shortcuts it.

A real process is ~1100 stages, and objects are **~91% of all stages**. Feeding
that to a model repeatedly, for extraction *and* verification, is the token
problem. So: a parser answers everything a parser can answer, deterministically
and free; the model only gets reading comprehension; and every model claim cites
a `stageid`, so verification is a grep rather than a second model.

## The tools

    bp_core.py   parse + regions (loops, exception scopes). GENERATED from
                 src/bp_estate/*.py by port/build.py - never hand-edit.
    bp_full.py   detect/analyze/score -> est.json, blockers, tiers, dead code
    bp_emit.py   emit Camunda 7 BPMN (+ diagram layout)

    check.py, audit3.py   quality gates on emitted BPMN
    object_triage.py      classify objects by CONTENT, not by name
    api_facts.py          per-object action ledger + binding sheet
    api_spec_check.py     verify an AI's API spec against that ledger
    extract_code.py       pull embedded C#/VB out as files (needs object_triage)
    diff_objects.py       base-vs-target object diff -> JIRA report

Each of `bp_core`/`bp_full`/`bp_emit` is ONE self-contained file, stdlib only,
with `--selftest` reproducing baked-in golden hashes. `SELFTEST PASS` proves a
copy is faithful. They travel as single files, so keep changes minimal.

## What is proven (do not re-litigate)

Verified by **deploying and running on a live Camunda 7.24**, not by assertion:

- emitted BPMN deploys (HTTP 200) and renders its diagram
- Calculation -> a real `camunda:outputParameter` assignment that executes
- service tasks carry input/output mappings; a worker really receives them
- a resuming Recover inside a Block -> subProcess + interrupting error boundary;
  error -> boundary -> handler -> resume -> end all execute
- multi-instance loops iterate once per collection element
- 12 BP->JUEL function templates, each executed on the engine, including the
  1-based `Mid`/`InStr` and `InStr`-miss = 0
- on a real 1109-stage process: **0 orphan nodes, 0 dead ends**

## Mapping

    Start / End                      ->  startEvent / endEvent
    Decision, Choice, WaitStart      ->  exclusiveGateway (+ JUEL conditions)
    Action (VBO call)                ->  external serviceTask, topic object.action
    SubSheet (page call)             ->  callActivity
    Calculation                      ->  task + camunda:outputParameter assignment
    LoopStart/LoopEnd                ->  sequential multi-instance subProcess
    Exception (throw)                ->  typed error endEvent + declared bpmn:error
    Recover WITHOUT Resume           ->  error event subProcess (catch, re-raise)
    Recover WITH Resume, in a Block  ->  subProcess + error boundary event
    Anchor                           ->  dissolved (a waypoint, not work)
    Data/Collection/Note/Block       ->  not flow nodes

VBO tiers, stamped into each service task as `tier=`:

    native     internal engine VBO -> a Fluxnova feature. No worker needed.
    connector  shipped VBO (Excel, Outlook, DB, Utility - *) -> existing library
    rehost     custom VBO -> needs a real API. THIS is the migration cost.

## Deploy rules learned the hard way (do not reintroduce)

1. `documentation` MUST precede `eventDefinition` and `extensionElements`.
2. Every process needs `camunda:historyTimeToLive`.
3. An empty `scriptTask` is rejected — use an abstract `task`.
4. An unconditioned XOR gateway flow is a **deploy** error.
5. `errorRef` is mandatory on an error END event.
6. Only executable processes register, so `callActivity` can resolve them.
7. A gateway with ONE outgoing flow may not carry a condition.
8. A multi-instance loop needs a collection or a cardinality.
9. JUEL contains `&&` and `<` — element text MUST be XML-escaped.

## Known limits (deliberate, not bugs)

- External service tasks have no workers; an instance parks at the first one.
- ~3% of expressions do not translate (`AND`/`IsNumber`/`ToNumber`/
  `ExceptionType`/`IsStopRequested`). They **hard-fail by design** — an
  unverified guess is worse than an honest TODO.
- UI stages (`Navigate`/`Read`/`Write`) stay labelled stubs — no BPMN equivalent.
- A page-scoped resuming Recover stays a placeholder (an event subprocess cannot
  rejoin the main flow).
- No DMN.

## Rules for changing any of this

1. **Fail loud, never guess.** Not in the export -> UNKNOWN, surfaced.
2. **Deterministic first.** If a parser can answer it, a parser answers it.
3. `bp_core.py` is GENERATED — edit `src/bp_estate/*.py` and rerun `build.py`.
4. **ASCII only** in emitted strings.
5. Same input -> byte-identical output. Golden hashes depend on it.
6. **Money:** Camunda 7 has no decimal type. Never map a BP Number to a double.
7. Never weaken a check to make a test pass.

## Data handling

Real exports, `est.json`, emitted BPMN and ledgers are **confidential**. They
never leave the machine that produced them and are never pasted into an external
service. Only numbers-only `--summary` output is safe to share. The Blue Prism
training release ("Consolidation Exercise Sample Solution") is vendor courseware
and is safe to work on.

---

# PART 3 — THE AI PART (the prompt that runs it)

Paste PART 2 first, then this. Give the AI a terminal in the folder that holds
the scripts and the two exports.

```
You are migrating ONE Blue Prism process to Fluxnova (Camunda 7 BPMN).
The tools are deterministic Python scripts in this folder. You do not
rewrite them and you do not write BPMN yourself: you RUN the tools, READ
the numbers, and REPORT what they mean.

Inputs I will give you:
  PROCESS  = an export containing the process
  COMBINED = the same process plus its objects

Run these in order and paste the real output of each:

  1. python bp_full.py "<PROCESS>" --summary
  2. python bp_full.py "<PROCESS>" -o est.json
  3. python bp_emit.py "<PROCESS>" -o out_bpmn --ns fluxnova
  4. python check.py out_bpmn\<file>.bpmn
  5. python audit3.py
  6. python object_triage.py "<COMBINED>" -o object_triage.json
  7. python object_triage.py "<COMBINED>" --summary
  8. python api_facts.py "<PROCESS>" --tier all --triage object_triage.json --verdict ui-driving,code-bound --sheet -o bindings.txt
  9. python extract_code.py "<COMBINED>" -o code_out

Then report, in plain language:
  - how big the process is (stages, pages) and how it converted
  - whether audit3 says DEAD ENDS: 0. If not, STOP and show the output.
  - whether check.py counts reconcile with step 1: serviceTask = Action
    stages, callActivity = SubSheet stages, exclusiveGateway = Decision +
    Choice + WaitStart, process = pages. Say so explicitly.
  - how many objects are ui-driving / code-bound / logic-only / mixed
  - how many objects therefore need an API, and name them
  - how many objects are shipped VBOs to REPLACE with a connector (do not port)
  - how many lines of custom code were extracted, and from which objects
  - any orphan nodes, cross-checked against est.json "dead_code": say for
    each whether it is genuine unreachable Blue Prism code, or unexplained

RULES:
  - Never edit a script to make a check pass. A failing check IS the
    finding. Report it with the exact error text.
  - Never invent a number. Every figure comes from real output you pasted.
  - If a command errors, stop and show the full error. Do not work around it.
  - If a count does NOT reconcile, say so loudly. That cross-check is the
    whole point.
  - Anything you cannot determine is UNKNOWN. Do not guess.
```
