# Blue Prism → Camunda Migration Pipeline — Design Document

> ⚠️ **Partly superseded — read `PROGRAMME.md` first.** The target is **uFlow**,
> not Camunda, and this is a 3-task programme, not one converter. §2, §6, §10,
> §11, §13 and §15 (dual nature, VM corollary, money/date/type rules, risk
> register, bank governance, LLM boundaries) are still current and still lead.
> The BPMN emitter, the FEEL transpiler, the mapping table (§8–9), the phasing
> and the open questions (§16) are Camunda-shaped and no longer the plan.
> `PROGRAMME.md` §8 has the section-by-section disposition.

**Status:** Draft v0.1
**Context:** Bank (regulated), bank-technology area
**Target:** Full decommission of Blue Prism (gradual acceptable; end state = no Blue Prism)
**Scale:** Large estate (clearly >20 processes; treat as "unknown many")

---

## 1. Purpose

Build a pipeline that ingests Blue Prism artifacts (XML exports) and produces a
**migration accelerator** for Camunda: a validated BPMN skeleton, an automation
inventory, service-task stubs, and a per-process risk/coverage report.

It is explicitly **not** a one-click converter. See §3.

## 2. The core insight that shapes everything

Blue Prism is **two tools in one**:

| Layer | What it is | Camunda equivalent |
|---|---|---|
| **Process layer** | Orchestration: flowchart of decisions, loops, queue handling, sub-pages | **BPMN** — mostly mechanical mapping |
| **Object / VBO layer** | Execution engine: spied UI elements, surface automation, screen/mainframe interaction, embedded code | **None.** Must be re-hosted or replaced with APIs |

Camunda orchestrates; it has no "hands." Therefore the pipeline can *convert*
the orchestration and can only *inventory + stub* the automation. The automation
layer is a re-implementation decision, not a conversion.

**Corollary — the VM problem:** the Windows VMs don't disappear by moving
orchestration. Any surviving UI automation still needs a logged-in Windows
session with the target app installed. VMs only retire when the underlying
automations are replaced by real API integrations — often the biggest prize
hiding in the estate (bots papering over missing APIs).

## 3. Goals & Non-Goals

### Goals
- Deterministically convert the **orchestration layer** to human-ownable, executable Camunda BPMN.
- Produce a complete **automation inventory** (every UI action, with its original spec) so re-implementation can be planned and estimated.
- Emit **service-task/job-worker stubs** wired into the BPMN, ready for implementation.
- Produce a **per-process migration report**: coverage %, blockers, risk flags, complexity score.
- Build a **whole-estate dependency map** before touching any single process.
- Support **re-import/diff** (source stays live during gradual migration).

### Non-Goals
- Converting UI automation logic (impossible; see §2).
- Fully automated, unreviewed migration. Every process is human-validated and re-tested.
- Replacing missing APIs (that's a separate, downstream refactoring stream — the pipeline only *flags candidates*).

## 4. Guiding principles

1. **Deterministic core, LLM at the edges.** A rule-based transpiler does the
   authoritative translation. The LLM is used only for naming, documentation,
   summarization, and *suggestions* — never for authoritative logic translation.
   At this scale, LLM inconsistency compounds and destroys auditability.
2. **Fail loud, never guess.** Unknown stages, functions, or code stages are
   **hard blockers surfaced in the report**, never silently "converted."
3. **Valid XML ≠ correct.** Success is measured by semantic/behavioral tests,
   not by "it emitted schema-valid BPMN."
4. **Human-ownable output.** Full decommission means humans own these BPMNs
   forever. Readability/layout is a hard requirement, not cosmetic.
5. **Honest coverage.** The pipeline's most important feature is accurately
   reporting what it could *not* safely convert.

## 5. Architecture

```
Blue Prism XML (.bprelease / .bpprocess / .bpobject)
        │
        ▼
[ Phase 0: Whole-estate static analysis ]  ← run ONCE across all artifacts
        │   call graph · shared objects/queues/creds · dead code · duplicate logic
        ▼
[ Parse ] ──► Blue Prism object model (faithful, lossless)
        │
        ▼
[ Normalize ] ──► tool-agnostic Intermediate Representation (IR)
        │
        ▼
[ Classify ] each node:
        │   • pure logic/decision/calc  → auto-map
        │   • orchestration (page ref, loop, queue) → BPMN structure
        │   • UI automation            → stub + attach original spec
        │   • code stage / DLL         → BLOCKER
        │   • integration              → API-candidate flag
        ▼
[ Emit ]  ──► Camunda BPMN 2.0 XML + job-worker stubs + mapping report
        │
        ▼
[ Validate ] ──► schema check · semantic diff · golden-set regression · test harness
        │
        ▼
[ Report ] ──► coverage %, blockers, risks, complexity, effort estimate
```

The **IR is the key architectural decision**: it decouples parsing from emission,
lets us classify complexity and coverage tool-agnostically, and keeps a future
retarget (different engine/version) cheap.

## 6. Phase 0 — Whole-estate static analysis (do this first)

At >20 processes this is the step that fails silently if skipped. Handed one XML
at a time, no tool (or LLM) can see the estate. Before per-process conversion,
build:

- **Call graph** — which processes call which objects/pages; shared sub-pages.
- **Shared-resource map** — shared VBOs, work queues, credentials, environment/session variables, environment locks.
- **Dead-code / unreachable-stage detection.**
- **Duplicate-logic detection** — the same idiom implemented N ways; consolidate before migrating.
- **Complexity scoring** per process (stage count, code stages, object fan-out, queue usage, exception depth) → migration wave planning.

Output: an estate dependency graph + a prioritized migration backlog.

## 7. Intermediate Representation (sketch)

```
Process
  ├─ id, name, version, startupParams[]
  ├─ dataItems[]   { name, type, scope(local|session), initialValue }
  ├─ pages[]       { name, stages[], links[] }
  └─ queues[]      { name, keyField, maxAttempts, tags[] }

Stage (discriminated union)
  ├─ Decision      { expr }                 → exclusive gateway (2-way)
  ├─ Choice        { branches[] ORDERED }   → exclusive gateway (priority-preserved)
  ├─ Calculation   { expr, target }         → FEEL expression / script
  ├─ Loop          { collection, body }     → multi-instance subprocess
  ├─ PageRef       { page, in[], out[] }    → call activity (thread ALL vars)
  ├─ Action        { object, action, params, kind } → service task | stub | BLOCKER
  ├─ Exception     { type, detail }         → error event
  ├─ Recover/Resume                          → boundary/error handling
  ├─ Code          { language, source }     → BLOCKER (surface, never translate)
  ├─ Wait          { condition, timeout }   → timer/message event
  └─ HumanStep     { queue, approval }      → USER task (not service!)

ActionSpec (for UI automation, carried as documentation)
  └─ { app, elementMatchCriteria, actionType, params }  // for re-implementation
```

## 8. Blue Prism → Camunda mapping table

> **SUPERSEDED (2026-08-13) by `FLUXNOVA-BPMN-MAPPING.md`.** Target is now known:
> Fluxnova = a Camunda **7** fork. §8–9 below were written against Camunda 8 /
> Zeebe / FEEL; the corrected, source-grounded map (JUEL not FEEL, external tasks,
> the `fluxnova:`/`camunda:` namespace decision) lives in that doc. Kept here for
> history.

| Blue Prism | Maps to | Confidence | Notes |
|---|---|---|---|
| Process page | BPMN process / subprocess | High | |
| Page reference | Call activity | High | **Must thread all in/out data items, incl. implicitly-read** |
| Decision (2-way) | Exclusive gateway | High | |
| Choice (n-way) | Exclusive gateway | **Medium** | Preserve top-down priority; force mutual exclusion |
| Calculation | FEEL expression / script task | Medium | Function translation (§9) |
| Loop over collection | Multi-instance subprocess | Medium | Current-row pointer, break/continue, mutation of source |
| Data item | Process variable | High | Type mapping (§10) |
| Work queue | Instances + queue pattern | Medium | Retry ≠ Zeebe job retry; item status = idempotency guard |
| Exception/Recover/Resume | Error events + boundary | **Low** | Semantics differ; heavy review |
| Environment lock | External distributed lock | — | **No native equivalent** |
| Credentials VBO | Vault lookup | High | Never plaintext variables |
| Action (UI automation) | Service task **stub** | — | Re-host / replace-with-API decision |
| Code stage / DLL | **BLOCKER** | — | Surface, never convert |
| Manual/approval queue item | **User task** | Medium | Do not auto-classify as service task |

## 9. Expression / FEEL translation

- Blue Prism expression language is VBA/VBScript-flavored (`&` concat, `Left`,
  `Mid`, `Trim`, `Today`, `Now`, `IsNull`, …). Target is Camunda **FEEL**.
- Strategy: **curated mapping table**, not LLM guessing. Unknown function →
  **hard fail**, flagged for manual translation. No invented equivalents.
- Maintain a golden set of expression → FEEL pairs as regression tests.

## 10. Data & type handling (bank-critical)

| Concern | Risk | Rule |
|---|---|---|
| **Money math** | BP `Number` = .NET **decimal**; FEEL number = double → rounding drift | Force decimal semantics; never float for money |
| **Dates/timezones** | `Today()`/`Now()` = resource VM local time; value dates, settlement cut-offs, holiday calendars | Explicit TZ + business-calendar handling |
| **Locale** | `1.000,00`, `dd/mm/yyyy`, decimal comma | Explicit locale in parse/format; no implicit conversion |
| **Type zoo** | `Flag`, `Password` (secure), `Binary`, `Image`, `Collection` (row pointer), nested collections, Date vs DateTime vs Time | Preserve semantics; `Password` → PII path; collection row-state modeled |
| **Null/empty** | `IsNull` / empty vs unset differ from FEEL null | Explicit null semantics in translated conditions |

## 11. Risk register

| # | Risk | Impact | Likelihood | Mitigation |
|---|---|---|---|---|
| R1 | Choice ordering lost → nondeterministic routing | High | High | Priority-preserving gateway generation; mutual-exclusion check |
| R2 | Exception/Recover mis-scoped → swallowed errors | High | High | Manual review gate on all exception constructs |
| R3 | Unstructured back-links → deadlock/token leak BPMN | High | Medium | Graph structuredness analysis; reject/flag non-reducible cycles |
| R4 | Code stages / DLLs silently dropped | High | High | Hard blocker; report; never emit |
| R5 | Implicit global data flow not threaded → silent data loss | High | High | Full data-dependency analysis per page ref |
| R6 | Money rounding drift | **Critical** | Medium | Decimal enforcement; financial test cases |
| R7 | Accidental parallelism changes side-effect order | High | Medium | Preserve sequential unless independence proven |
| R8 | Idempotency lost → double transaction posting | **Critical** | Medium | Reconstruct queue-status guards; idempotency keys |
| R9 | Approval/manual step auto-classified as automation | High | Medium | User-task detection; SoD/four-eyes preserved |
| R10 | Inconsistent translation across estate | Medium | High | Deterministic rules + golden-set regression |
| R11 | Coverage illusion ("converted" but semantically broken) | High | High | Semantic diff + behavioral tests, not schema validation |
| R12 | Audit-log parity lost | High | Medium | Map BP session-log granularity to Camunda history + custom audit |
| R13 | Source changes during gradual migration | Medium | High | Re-import/diff workflow, not one-shot |
| R14 | Environment locks missed → resource contention | Medium | Medium | Detect in Phase 0; external distributed lock |

## 12. Validation & test strategy

- **Structural:** BPMN 2.0 schema + executability (no dangling tokens, joins matched).
- **Semantic:** golden-set regression — known BP fragments → expected BPMN/FEEL.
- **Behavioral:** where feasible, run migrated process against recorded input/output fixtures and diff outcomes.
- **Coverage report:** every node classified as converted / stubbed / blocked, with reasons. No node is unaccounted for.

## 13. Governance, audit & security (bank)

- **Auditability:** preserve trace granularity equivalent to BP session logs; regulators must reconstruct any run.
- **Credentials:** map BP credential manager → bank secrets vault; no secrets in process variables or history.
- **PII:** collections carry PII into Camunda variables *and history tables* → data-residency & retention rules apply.
- **Controls:** control totals, checksums, dual-run reconciliation are semantic invariants — inventory and preserve them explicitly.
- **Change control:** map BP release versioning → Camunda deployment versioning; four-eyes on migrated-process sign-off.

## 14. Migration phasing (strangler-fig → full decommission)

1. **Wave 0:** Phase-0 estate analysis; tooling + golden sets; pick low-complexity, low-risk pilot processes.
2. **Coexistence:** Camunda orchestrates; **still calls existing Blue Prism objects** (via API/queue) so automations aren't rewritten day one. De-risks rewrite *and* VM migration.
3. **Re-host / replace:** wave by wave, replace called BP objects with Camunda RPA workers or (preferably) API integrations. Retire VMs as automations become API-based.
4. **Decommission:** once a process's automations are all re-hosted/replaced and validated, cut the BP dependency. Full decommission when the estate is empty.

## 15. The LLM's role & hard boundaries

**Uses:** documentation generation, human-readable summaries of migrated
processes, naming suggestions, duplicate-logic clustering hints, effort-estimate
narration, drafting stub comments.

**Never:** authoritative expression translation, deciding control flow,
"filling in" unknown functions/stages, converting code stages, judging whether a
step is a control/approval. Those are deterministic rules or human decisions.

## 16. Open questions

- **Camunda 7 vs 8?** (Zeebe/job-workers vs legacy — different emit target; blocks the emitter design.)
- **UI-automation fate per process:** re-host on Camunda RPA vs replace with API vs keep BP during transition — likely case-by-case.
- **Target job-worker stack/language.**
- **Estate size + composition** (exact process/object counts, code-stage prevalence) — output of Phase 0.
- **Audit-log parity bar** — what granularity do the regulators/internal audit actually require?

## 17. Success metrics

- % of orchestration nodes auto-converted (target: high).
- % of automation actions inventoried with complete specs (target: 100%).
- Zero silent drops (every unconverted node reported).
- Golden-set regression pass rate.
- Human review time per process vs. hand-migration baseline (the accelerator's ROI).
```
