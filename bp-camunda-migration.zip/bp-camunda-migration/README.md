# Blue Prism migration

Tooling for migrating a bank's Blue Prism RPA estate off Blue Prism, with **full
decommission** as the end state. The target is **uFlow**. *(The folder name says
Camunda — that was the original target. Renaming a git root is churn; see
`PROGRAMME.md`.)*

## What this is
Blue Prism is two tools in one: an **orchestrator** (the process flow) and an
**execution engine** for UI automation (the object/VBO layer). No workflow
engine has the second one. So this tooling **converts orchestration** and
**inventories** automation — and the automation layer is a re-implementation
decision, not a conversion.

It is a **3-task programme**, not one converter: analysis → API specs (1), code
re-engineering (2), spec extraction → migration (3). **Read `PROGRAMME.md`
first** — it has the task breakdown, the verification strategy, and the open
gates. `DESIGN.md` holds the deeper analysis, with a Camunda-shaped framing that
`PROGRAMME.md` §8 dispositions section by section.

## Layout
```
PROGRAMME.md                  START HERE — the 3-task programme (supersedes DESIGN's framing)
DESIGN.md                     Master design + 14-item risk register (partly superseded)
EXCEPTION-LOOP-MAPPING.md     Design: BP loops/exceptions/propagation -> target error boundaries (target-neutral)
PHASE0-ESTATE-ANALYZER.md     Spec: the whole-estate static-analysis pass
PHASE0-IMPLEMENTATION.md      Spec: how the analyzer is built (this code)
QUESTIONS-AND-INTAKE.md       What we need from you to go further
data/                         Shared, language-neutral CONTRACTS (tune freely):
  vbo_registry.yaml             Blue Prism object tiers + resource detectors
  weights.yaml                  complexity/risk/coupling scoring
  pii_patterns.yaml             PII field-name heuristic
schemas/estate.schema.json    Output contract (validated on every run)
src/bp_estate/                Phase 0 analyzer (Python)
prompts/                      Prompts for the delivery model (Gemini/Copilot)
tools/                        Everything deterministic. No tool here calls a model.
  extract_release.py            .bprelease bundle -> one standalone file per artifact
  stage_skeleton.py             one scrubbed <stage> per type (structure, no values) to confirm parser shapes
  audit_rules.py                Coding-rules audit (the mechanical half of 03)
  fix_mechanical.py             Applies the findings whose value is computable
  diff_objects.py               Two versions of an artifact -> a change ledger
  render_compare.py             change ledger -> JIRA report + HTML page
  verify_llm_output.py          Acceptance tests over a model's answer
  stage_ledger.py               Every stageid, for the completeness assertion
  render_audit.py               audit    -> one HTML page
  render_spec.py                04 spec  -> one HTML page
  render_doc.py                 05 doc   -> one HTML page
  render_screens.py             Application Modeller -> to-scale wireframes
  render_pack.py                All of the above -> ONE document per process
  _page.py                      Shared design system (not a CLI)
tests/                        Fixtures + golden snapshot + smoke tests
docker/                       Local Camunda run options (for later)
```

## Status
**Phase 0 analyzer: runnable.** It parses Blue Prism exports, classifies object
tiers, extracts queues/credentials/locks, flags blockers (code stages, env
locks, dynamic names, missing refs, back-links), finds dead code, scores each
artifact, plans migration waves, and emits a schema-validated `estate.json` +
reports.

**Parser status:** `src/bp_estate/parse.py` is reconciled against the bank's
"BP Description" reference — the documented *spine* is now implemented for real:
`<process name preferredid published>`, `<view>` ignored, `<subsheet>` with its
name in a child node and an internal id resolved to that name, an omitted
`<subsheetid>` meaning "Main Page", presence-based `<private/>`, Action
`<input expr>` values parsed as BP **expressions** (a text literal is quoted),
`<output stage>` data-flow binding, artifact type from the file extension,
`.bprelease` bundles split structurally, and namespace-tolerant tag matching.

What remains unconfirmed until a real export lands is tagged `# UNCONFIRMED` in
that module: the element carrying an Action's target (`<resource>`),
Decision/Choice/Calculation internals, `<page ref>`, `<collectioninfo>`,
`<code language>` and the flow-link tags. Everything downstream consumes the
model, not the XML, so the blast radius stays in this one file.

**LLM prompts: drafted.** `prompts/` holds one prompt per programme task, for
the model that will do the work (Gemini / Copilot, not Claude). They are built
so a script — not a second model pass — catches invention and omission:
`tools/verify_llm_output.py` checks stageid citations, verbatim quotes, and a
**stage ledger** that turns spec completeness into a set-equality assertion.
`prompts/README.md` explains the design.

**Blocked:** the per-process converter/emitter, and the uFlow migration prompt —
the target is **uFlow**, and we do not yet know what it ingests (BPMN?
proprietary JSON/DSL? an API?). That question gates both, and anything written
before it is answered just encodes a guess at the target format.

## Quickstart (Windows, Python 3.11+)
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m bp_estate analyze tests\fixtures -o out
.\.venv\Scripts\python.exe -m pytest -q
```
Outputs land in `out/`: `estate.json`, `estate-report.md`, and CSVs.

## Security
Real exports are bank IP and contain credentials/PII references. They are
git-ignored (`exports/`, `*.bprelease`, …). Never commit a real export.
