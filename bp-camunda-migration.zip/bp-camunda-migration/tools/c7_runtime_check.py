#!/usr/bin/env python3
"""Run the emitter's round-trip fixture on a LIVE Camunda 7 and check the result.

The positive control for bp_emit: the embedded "Roundtrip" fixture exercises
every construct the emitter claims to translate (mapped page call, typed initial
values, Block + Recover/Resume with ExceptionType()/ExceptionDetail(), a loop
with a current-row field read) and this script deploys it, starts it, and
asserts the variables the engine ends up with. A deploy-only mode checks that
any emitted directory is accepted by the engine.

    python tools/c7_runtime_check.py                       # round-trip on localhost:8080
    python tools/c7_runtime_check.py --deploy out_bpmn     # deploy every .bpmn there, report
    python tools/c7_runtime_check.py --url http://host:8080/engine-rest

Needs a running engine, e.g.:  docker run -d -p 8080:8080 camunda/camunda-bpm-platform:7.24.0
Stdlib only.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "port"))
import bp_emit  # noqa: E402

EXPECTED = {
    "Amount": 21,            # Init: Main Page, from <initialvalue>
    "Greeting": "hello",     # Init: text literal
    "Doubled": 42,           # page call: in-mapping Value<-Amount, calc, out-mapping Result->Doubled
    "ExType": "Business Exception",   # ExceptionType() via errorCodeVariable
    "ExDetail": "Too big: 42",        # ExceptionDetail() via ext:errorMessage expression
    "Last": "B",             # loop over Rows, [Rows.Name] = current-row field read
    "Tripled": 378,          # object action called twice as a call activity (42*3*3)
    "Calc::Calls": 102,      # object state: Initialise page set 100, each action +1, kept in the caller
}
# A script task must actually run on this engine for the "script slot" story to hold.
PROBE = """<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:camunda="http://camunda.org/schema/1.0/bpmn" id="probe" targetNamespace="http://bank.example/bp-migration">
  <bpmn:process id="bp_script_probe" isExecutable="true" camunda:historyTimeToLive="P1D">
    <bpmn:startEvent id="s"/><bpmn:sequenceFlow id="f1" sourceRef="s" targetRef="t"/>
    <bpmn:scriptTask id="t" scriptFormat="javascript"><bpmn:script>execution.setVariable('probe', execution.getVariable('X') * 7);</bpmn:script></bpmn:scriptTask>
    <bpmn:sequenceFlow id="f2" sourceRef="t" targetRef="e"/><bpmn:endEvent id="e"/>
  </bpmn:process>
</bpmn:definitions>
"""
ROWS = [{"Name": "A"}, {"Name": "B"}]
# Nested: a Block with a resuming Recover INSIDE a loop body. Row 2 throws, is
# caught inside the iteration, and the loop goes on to row 3.
ITEMS = [{"V": 5}, {"V": 50}, {"V": 7}]
EXPECTED_NESTED = {
    "Count": 2,                 # rows 1 and 3 counted
    "Fails": 1,                 # row 2 caught once
    "Caught": "Too big: 50\n",  # ExceptionDetail() & NewLine(): the Init-set BP#NewLine variable
}


def _req(url: str, data: bytes | None = None, ctype: str | None = None, method: str | None = None):
    req = urllib.request.Request(url, data=data, method=method or ("POST" if data is not None else "GET"))
    if ctype:
        req.add_header("Content-Type", ctype)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = r.read().decode("utf-8")
            return r.status, (json.loads(body) if body else None)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        try:
            return e.code, json.loads(body)
        except ValueError:
            return e.code, {"message": body}


def deploy(base: str, name: str, xml: str) -> tuple[bool, str]:
    boundary = "----bp" + uuid.uuid4().hex
    parts = []
    for field, value in (("deployment-name", name), ("enable-duplicate-filtering", "false")):
        parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"\r\n\r\n{value}\r\n")
    parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"data\"; filename=\"{name}\"\r\n"
                 f"Content-Type: application/octet-stream\r\n\r\n")
    body = "".join(parts).encode("utf-8") + xml.encode("utf-8") + f"\r\n--{boundary}--\r\n".encode("utf-8")
    code, res = _req(f"{base}/deployment/create", body, f"multipart/form-data; boundary={boundary}")
    if code == 200 and res and "id" in res:
        defs = res.get("deployedProcessDefinitions") or {}
        return True, f"{len(defs)} definition(s)"
    return False, (res or {}).get("message", f"HTTP {code}")[:600]


def start(base: str, key: str, variables: dict) -> tuple[bool, str]:
    code, res = _req(f"{base}/process-definition/key/{key}/start",
                     json.dumps({"variables": variables}).encode("utf-8"), "application/json")
    if code == 200 and res:
        return True, res["id"]
    return False, (res or {}).get("message", f"HTTP {code}")[:600]


def wait_done(base: str, pid: str, timeout: float = 60.0) -> dict | None:
    t0 = time.time()
    while time.time() - t0 < timeout:
        code, res = _req(f"{base}/history/process-instance/{pid}")
        if code == 200 and res and res.get("endTime"):
            return res
        code, inc = _req(f"{base}/incident?processInstanceId={pid}")
        if code == 200 and inc:
            return {"incident": inc[0].get("incidentMessage")}
        time.sleep(0.5)
    return None


def variables(base: str, pid: str) -> dict:
    code, res = _req(f"{base}/history/variable-instance?processInstanceId={pid}")
    return {v["name"]: v.get("value") for v in (res or [])} if code == 200 else {}


def probe_script(base: str) -> bool:
    ok, msg = deploy(base, "probe.bpmn", PROBE)
    if not ok:
        print(f"script probe deploy FAIL: {msg}")
        return False
    ok, pid = start(base, "bp_script_probe", {"X": {"value": 6, "type": "Integer"}})
    done = wait_done(base, pid) if ok else None
    got = variables(base, pid).get("probe") if done and "incident" not in done else None
    print(f"script probe (javascript scriptTask): {'OK' if got == 42 else 'FAIL ' + str(done)}")
    return got == 42


def roundtrip(base: str) -> int:
    if not probe_script(base):
        return 1
    docs = bp_emit.emit_all(bp_emit._fixture_estate(), "camunda", include_objects=True)
    for name in sorted(docs):
        if not (name.startswith("Roundtrip") or name.startswith("Calc")):
            continue
        ok, msg = deploy(base, name, docs[name])
        print(f"deploy {name}: {'OK' if ok else 'FAIL'} {msg}")
        if not ok:
            return 1
    key = bp_emit._nc("p", "Roundtrip::" + bp_emit.MAIN_PAGE)
    rows = {"value": json.dumps(ROWS), "type": "Object",
            "valueInfo": {"serializationDataFormat": "application/json",
                          "objectTypeName": "java.util.ArrayList"}}
    ok, pid = start(base, key, {"Rows": rows})
    print(f"start {key}: {'OK' if ok else 'FAIL'} {pid}")
    if not ok:
        return 1
    done = wait_done(base, pid)
    if not done:
        print("FAIL: instance did not finish in time")
        return 1
    if "incident" in done:
        print(f"FAIL: incident: {done['incident']}")
        return 1
    got = variables(base, pid)
    fails = []
    for k, want in EXPECTED.items():
        have = got.get(k)
        if isinstance(want, (int, float)) and isinstance(have, (int, float)):
            same = float(have) == float(want)
        else:
            same = have == want
        print(f"  {k:10s} = {have!r:30s} want {want!r} {'OK' if same else 'MISMATCH'}")
        if not same:
            fails.append(k)
    print("RUNTIME PASS" if not fails else f"RUNTIME FAIL: {', '.join(fails)}")
    if fails:
        return 1
    return nested(base, docs)


def _collection(rows):
    return {"value": json.dumps(rows), "type": "Object",
            "valueInfo": {"serializationDataFormat": "application/json",
                          "objectTypeName": "java.util.ArrayList"}}


def nested(base: str, docs: dict) -> int:
    """Second round trip: the Nested fixture (loop > Block > Recover/Resume)."""
    for name in sorted(docs):
        if name.startswith("Nested"):
            ok, msg = deploy(base, name, docs[name])
            print(f"deploy {name}: {'OK' if ok else 'FAIL'} {msg}")
            if not ok:
                return 1
    key = bp_emit._nc("p", "Nested::" + bp_emit.MAIN_PAGE)
    ok, pid = start(base, key, {"Items": _collection(ITEMS)})
    print(f"start {key}: {'OK' if ok else 'FAIL'} {pid}")
    if not ok:
        return 1
    done = wait_done(base, pid)
    if not done:
        print("FAIL: nested instance did not finish in time")
        return 1
    if "incident" in done:
        print(f"FAIL: nested incident: {done['incident']}")
        return 1
    got = variables(base, pid)
    fails = []
    for k, want in EXPECTED_NESTED.items():
        have = got.get(k)
        same = float(have) == float(want) if isinstance(want, (int, float)) and isinstance(have, (int, float)) else have == want
        print(f"  {k:10s} = {have!r:30s} want {want!r} {'OK' if same else 'MISMATCH'}")
        if not same:
            fails.append(k)
    print("NESTED RUNTIME PASS" if not fails else f"NESTED RUNTIME FAIL: {', '.join(fails)}")
    return 0 if not fails else 1


def deploy_dir(base: str, d: Path) -> int:
    bad = 0
    for f in sorted(d.glob("*.bpmn")):
        ok, msg = deploy(base, f.name, f.read_text(encoding="utf-8"))
        print(f"{f.name}: {'OK' if ok else 'FAIL'} {msg}")
        bad += not ok
    print(f"{bad} failed")
    return 1 if bad else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--url", default="http://localhost:8080/engine-rest")
    ap.add_argument("--deploy", help="deploy every .bpmn in this directory instead of the round-trip")
    a = ap.parse_args(argv)
    code, _ = _req(f"{a.url}/engine")
    if code != 200:
        print(f"no engine at {a.url} (HTTP {code})")
        return 2
    if a.deploy:
        return deploy_dir(a.url, Path(a.deploy))
    return roundtrip(a.url)


if __name__ == "__main__":
    sys.exit(main())
