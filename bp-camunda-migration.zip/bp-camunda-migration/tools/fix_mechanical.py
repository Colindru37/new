"""Apply the audit findings whose correct value is computable. Task 2, part one.

    python tools/fix_mechanical.py <export> <findings.json> -o <outdir>

## Why this is not the AI part, and why it comes first

Prompt 03 splits findings by `fix_is_mechanical`. That flag conflates two
different questions, and task 2 lives in the gap between them:

* **mechanically APPLICABLE** — the edit is a rename or an attribute change
  with no behaviour change, so applying it is safe once the value is known;
* **mechanically DECIDABLE** — the correct value can be *computed* from the
  export, with no judgement.

`Data1 -> ?` is applicable but not decidable: nothing in the XML says what that
stage should be called. `i_txt_Order` on a Number item is both — the standard's
token table gives exactly one right answer, `i_nr_Order`.

This tool does only the decidable ones. Everything else is written to
`handoff.json`, which is precisely the input the model half of task 2 needs:
each item already carries its stage, its context and the constraint the new
value must satisfy. The model chooses values; this layer applies and verifies
them. That division is the whole reason generation here is affordable — the
expensive part of AI codegen is proving the result is safe, and for this class
of change the proof is a diff.

## Why it edits text and not a parse tree

Round-tripping a real `.bprelease` through ElementTree grows it by 13% and
rewrites the `bpr:` namespace prefix to `ns0:` — a file Blue Prism may refuse to
import. So every edit here is a bounded string replacement inside a located
span, and every byte outside the edit is preserved exactly. The parse tree is
used only to find things, never to write them.

## A rename is the dangerous one

Renaming a data item silently breaks the process unless *every* reference moves
with it: `[Old Name]` inside expressions, and `stage="Old Name"` on outputs and
calculations. This counts references before and after and refuses the whole fix
if the numbers do not reconcile. A partial rename is worse than no rename.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from audit_rules import _DT_TOKEN, _NAME_RE   # noqa: E402
from bp_estate.cli import _collect            # noqa: E402

# Every attribute that can hold a data item's name. Miss one and a rename
# produces a process that parses cleanly and fails at run time.
_STAGE_REF_ATTRS = ("stage",)
_EXPR_ATTRS = ("expr", "expression")

# Which rules this tool is allowed to touch, and how.
_RETYPE = "DATA-SECRET-NOT-PASSWORD"
_RENAME = "NAME-PREFIX-CONTRADICTS-TYPE"


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


@dataclass
class Span:
    """A byte range in the raw file, plus what lives in it."""
    start: int
    end: int
    name: str


def artifact_spans(raw: str) -> list[Span]:
    """Locate each artifact's text span in a release or single-artifact file.

    A `.bprelease` repeats every artifact as an empty stub inside
    `<bpr:contents>`; a stub holds no `<stage`, which is how they are told
    apart without trusting the manifest's ordering.
    """
    spans: list[Span] = []
    for m in re.finditer(r"<(process|object)\b[^>]*\bname=\"([^\"]*)\"[^>]*?(/?)>", raw):
        tag, name, selfclose = m.group(1), m.group(2), m.group(3)
        if selfclose:
            continue
        depth, pos = 1, m.end()
        pat = re.compile(rf"</?{tag}\b[^>]*?(/?)>")
        while depth and (n := pat.search(raw, pos)):
            if raw[n.start():n.start() + 2] == f"</":
                depth -= 1
            elif not n.group(1):
                depth += 1
            pos = n.end()
        if depth:
            continue
        body = raw[m.start():pos]
        if "<stage" in body:
            spans.append(Span(m.start(), pos, name))
    # Wrappers nest (a <process> wrapper holds a <process> body), so keep only
    # the outermost span for each region.
    spans.sort(key=lambda s: (s.start, -s.end))
    kept: list[Span] = []
    for s in spans:
        if not kept or s.start >= kept[-1].end:
            kept.append(s)
    return kept


def stage_span(raw: str, span: Span, stageid: str) -> tuple[int, int] | None:
    """The <stage>...</stage> range containing this stageid, within an artifact."""
    i = raw.find(f'stageid="{stageid}"', span.start, span.end)
    if i < 0:
        return None
    start = raw.rfind("<stage", span.start, i)
    end = raw.find("</stage>", i, span.end)
    if start < 0 or end < 0:
        return None
    return start, end + len("</stage>")


# --------------------------------------------------------------------------- #
# the two decidable fixes
# --------------------------------------------------------------------------- #
def plan_retype(stages: dict, f: dict) -> list[dict]:
    """A data item whose name says secret but whose datatype does not."""
    return [{"kind": "retype", "stageid": sid, "rule_id": f["rule_id"],
             "from": stages[sid]["datatype"], "to": "password",
             "name": stages[sid]["name"]}
            for sid in f["stageids"] if sid in stages]


def plan_rename(stages: dict, f: dict) -> list[dict]:
    """A prefix that contradicts the datatype. The token table gives exactly
    one correct answer, so this needs no judgement."""
    out = []
    for sid in f["stageids"]:
        s = stages.get(sid)
        if not s:
            continue
        m = _NAME_RE.match(s["name"].strip())
        if not m:
            continue
        want = {v: k for k, v in _DT_TOKEN.items()}.get(s["datatype"].lower())
        if not want:
            continue
        new = s["name"].strip().replace(f"{m.group('dt')}_", f"{want}_", 1)
        if new != s["name"].strip():
            out.append({"kind": "rename", "stageid": sid, "rule_id": f["rule_id"],
                        "from": s["name"], "to": new, "name": s["name"]})
    return out


def apply_retype(raw: str, span: Span, edit: dict) -> tuple[str, str | None]:
    r = stage_span(raw, span, edit["stageid"])
    if not r:
        return raw, "stage not found in this artifact"
    a, b = r
    body = raw[a:b]
    new_body, n = re.subn(r"(<datatype>)[^<]*(</datatype>)",
                          rf"\g<1>{edit['to']}\g<2>", body, count=1)
    if n != 1:
        return raw, f"expected exactly 1 <datatype> in the stage, found {n}"
    return raw[:a] + new_body + raw[b:], None


def apply_rename(raw: str, span: Span, edit: dict) -> tuple[str, str | None]:
    """Rename the stage AND every reference to it inside the same artifact."""
    old, new = edit["from"], edit["to"]
    body = raw[span.start:span.end]

    if f'name="{new}"' in body:
        return raw, f"target name {new!r} already exists in this artifact"

    want_brackets = body.count(f"[{old}]")
    want_stageref = sum(body.count(f'{a}="{old}"') for a in _STAGE_REF_ATTRS)

    new_body = body.replace(f"[{old}]", f"[{new}]")
    for a in _STAGE_REF_ATTRS:
        new_body = new_body.replace(f'{a}="{old}"', f'{a}="{new}"')
    # The stage's own name attribute, scoped to its own element.
    r = stage_span(raw, span, edit["stageid"])
    if not r:
        return raw, "stage not found in this artifact"
    rel_a, rel_b = r[0] - span.start, r[1] - span.start
    stage_txt = new_body[rel_a:rel_b]
    fixed, n = re.subn(rf'(<stage\b[^>]*?\bname=")({re.escape(old)})(")',
                       rf"\g<1>{new}\g<3>", stage_txt, count=1)
    if n != 1:
        return raw, f"expected 1 name attribute on the stage, found {n}"
    new_body = new_body[:rel_a] + fixed + new_body[rel_b:]

    # Reconcile: nothing referencing the old name may survive, and the number
    # of new references must equal the number of old ones. A rename that only
    # half-lands is a process that fails in production, not in review.
    if new_body.count(f"[{old}]") or any(
            f'{a}="{old}"' in new_body for a in _STAGE_REF_ATTRS):
        return raw, "a reference to the old name survived the rewrite"
    got_b = new_body.count(f"[{new}]") - body.count(f"[{new}]")
    got_s = sum(new_body.count(f'{a}="{new}"') for a in _STAGE_REF_ATTRS) \
        - sum(body.count(f'{a}="{new}"') for a in _STAGE_REF_ATTRS)
    # The stage's own `name="..."` is NOT one of these - it is rewritten by the
    # regex above and verified by its own count. Adding it here double-counted
    # and refused a correct rename.
    if got_b != want_brackets or got_s != want_stageref:
        return raw, (f"reference count did not reconcile: expected "
                     f"{want_brackets} expression + {want_stageref} attribute "
                     f"reference(s), rewrote {got_b} + {got_s}")
    return raw[:span.start] + new_body + raw[span.end:], None


_PLANNERS = {_RETYPE: plan_retype, _RENAME: plan_rename}
_APPLIERS = {"retype": apply_retype, "rename": apply_rename}


# --------------------------------------------------------------------------- #
def index_stages(path: Path) -> dict[str, dict]:
    """stageid -> facts, read with a parser (locating only; never writing)."""
    out: dict[str, dict] = {}
    root = ET.parse(path).getroot()
    for st in root.iter():
        if _local(st.tag) != "stage" or not st.get("stageid"):
            continue
        dt = ""
        for k in st:
            if _local(k.tag) == "datatype":
                dt = (k.text or "").strip()
        out[st.get("stageid")] = {"name": st.get("name") or "",
                                  "type": st.get("type") or "",
                                  "datatype": dt}
    return out


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("export")
    p.add_argument("findings")
    p.add_argument("-o", "--out", default="fixed")
    args = p.parse_args()

    paths = _collect([args.export])
    doc = json.loads(Path(args.findings).read_text(encoding="utf-8"))
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)

    applied, refused, handoff = [], [], []
    for f in doc.get("findings") or []:
        if f["rule_id"] not in _PLANNERS:
            handoff.append({
                "rule_id": f["rule_id"], "artifact": f.get("artifact"),
                "page": f.get("page"), "stageids": f.get("stageids"),
                "observed": f.get("observed"), "required": f.get("required"),
                "why_not_automatic":
                    "the correct value is not computable from the export - a "
                    "human or a model must choose it"
                    if f.get("fix_is_mechanical") else
                    "this is a behaviour change, not a rename or retype",
            })

    for path in paths:
        raw = path.read_text(encoding="utf-8")
        original = raw
        stages = index_stages(path)
        spans = artifact_spans(raw)

        for f in doc.get("findings") or []:
            planner = _PLANNERS.get(f["rule_id"])
            if not planner:
                continue
            span = next((s for s in spans if s.name == f.get("artifact")), None)
            if span is None:
                continue
            for edit in planner(stages, f):
                # Spans shift after every edit, so re-locate each time.
                spans = artifact_spans(raw)
                span = next((s for s in spans if s.name == f.get("artifact")), None)
                if span is None:
                    refused.append({**edit, "why": "artifact span not found"})
                    continue
                raw, err = _APPLIERS[edit["kind"]](raw, span, edit)
                (refused if err else applied).append(
                    {**edit, **({"why": err} if err else {})})

        dest = outdir / path.name
        if raw != original:
            # Re-parse before writing: an edit that produces invalid XML must
            # never reach disk.
            try:
                ET.fromstring(raw)
            except ET.ParseError as e:
                sys.exit(f"{path.name}: edits produced invalid XML ({e}) - "
                         "nothing written")
            dest.write_text(raw, encoding="utf-8")
        else:
            shutil.copy2(path, dest)

    (outdir / "applied.json").write_text(
        json.dumps({"applied": applied, "refused": refused}, indent=2,
                   sort_keys=True) + "\n", encoding="utf-8")
    (outdir / "handoff.json").write_text(
        json.dumps({"needs_a_decision": handoff}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8")

    print(f"applied {len(applied)}, refused {len(refused)}, "
          f"handed off {len(handoff)} -> {outdir}")
    for e in applied:
        print(f"  FIXED    {e['kind']:<7} {e['from']!r} -> {e['to']!r}")
    for e in refused:
        print(f"  REFUSED  {e['kind']:<7} {e['from']!r}: {e['why']}")
    sys.exit(1 if refused else 0)


if __name__ == "__main__":
    main()
