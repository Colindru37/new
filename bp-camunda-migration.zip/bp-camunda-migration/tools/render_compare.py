"""Render a comparison as JIRA markup, ready to paste into a ticket.

    python tools/render_compare.py <changes.json> [-o report.jira]

BP Comparison Rules 18 and 19 fix the shape: a title block carrying the date,
the user and how the report was produced, then findings graded critical /
impactful / minor, with (/) when a section is clean and (x) when it is not.

Two deliberate departures from a naive reading of the rules.

Rule 18 asks every report to be stamped "AI Assisted". This one is not: the
change set below is a parser diff, and every severity on it comes from a rule
in the standard applied by code. Stamping it AI-Assisted would invite a reviewer
to discount findings that are exact. The provenance line therefore says what
actually produced the report, and `--ai-assisted` is available for the day a
model writes the explanation half.

Rule 25 asks for a "what to do about it" subsection. The remediation lines here
are only the ones that follow mechanically from the finding's own kind - a page
that exists only in the target has exactly one safe answer. Anything needing
judgement is left for the model or the human, and marked as such, because a
confident wrong instruction is worse than an obvious gap.
"""
from __future__ import annotations

import argparse
import getpass
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _page import SEAL, e, seal, stamp, write                 # noqa: E402
from diff_objects import CRITICAL, IMPACTFUL, MINOR, _LABEL   # noqa: E402

_HEAD = {CRITICAL: "Critical Issues", IMPACTFUL: "Impactful Issues",
         MINOR: "Minor Issues"}
_ORDER = (CRITICAL, IMPACTFUL, MINOR)

# Rule 25, but only where one action is entailed by the finding itself.
_FIX = {
    "page_only_in_target":
        "copy this page from the target into the base before overwriting, or "
        "the overwrite deletes it",
    "page_only_in_base":
        "no action - overwriting the target restores this page",
    "page_renamed":
        "confirm which name callers use; the id is shared, so only one name "
        "survives the overwrite",
    "page_publish_changed":
        "re-publish the page in the base version if any process calls it",
    "removed":
        "confirm no process calls this stage's page before overwriting",
    "unclassified":
        "inspect by hand - this diff detected a change it cannot describe",
}


def _rows(d: dict) -> list[dict]:
    """Every finding, flattened, each carrying enough to print one line."""
    out = []
    for r in d.get("sheets") or []:
        out.append({**r, "what": f"page {r['page']!r} - {r['detail']}",
                    "where": r["page"], "fix": _FIX.get(r["kind"])})
    for r in d.get("added") or []:
        out.append({**r, "kind": "added",
                    "what": f"stage added: [{r['type']}] {r['name']!r}",
                    "where": r["page"], "fix": None})
    for r in d.get("removed") or []:
        out.append({**r, "kind": "removed",
                    "what": f"stage removed: [{r['type']}] {r['name']!r}",
                    "where": r["page"], "fix": _FIX["removed"]})
    for r in d.get("changed") or []:
        fields = ", ".join(_LABEL.get(f, f) for f in r["fields"])
        out.append({**r, "kind": "changed",
                    "what": f"[{r['type']}] {r['name']!r} changed: {fields}",
                    "where": r["page"], "fix": None})
    for r in d.get("unclassified") or []:
        out.append({**r, "kind": "unclassified",
                    "what": f"[{r['type']}] {r['name']!r} changed in a way this "
                            "diff does not model",
                    "where": r["page"], "fix": _FIX["unclassified"]})
    return out


def render(d: dict, ai_assisted: bool = False) -> str:
    rows = _rows(d)
    totals = d.get("totals") or {}
    clean = not rows

    name = d.get("base") or "?"
    o = [f"h1. Object comparison {'(/)' if clean else '(x)'} {name}", ""]

    # Rule 23: name the instance when the filename actually carries one.
    bi, ti = d.get("base_instance"), d.get("target_instance")
    o.append("||Field||Value||")
    o.append(f"|Base (overwrites)|{{{{{d.get('base_file', '?')}}}}}"
             + (f" - instance *{bi}*|" if bi else "|"))
    o.append(f"|Target (overwritten)|{{{{{d.get('target_file', '?')}}}}}"
             + (f" - instance *{ti}*|" if ti else "|"))
    o.append(f"|Date|{datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC|")
    o.append(f"|Run by|{getpass.getuser()}|")
    o.append("|Produced by|" + ("AI Assisted - a model wrote the explanations; "
                                "the change set below is a parser diff|"
                                if ai_assisted else
                                "{{tools/diff_objects.py}} - a parser diff, "
                                "graded by the BP Comparison Rules in code. "
                                "No model was consulted|"))
    o.append(f"|Unchanged stages|{d.get('unchanged_count', 0)}|")
    o.append("")

    if clean:
        o += ["(/) *No differences found.* Every stage, page and argument "
              "matches between the two versions.",
              "", "Overwriting the target with the base version is safe.", ""]
        # Rule 16 asks for the closing description on every report, not only on
        # the ones with findings - a clean result still has to say what was
        # compared, or "no differences" is indistinguishable from "not checked".
        o += _coding_rules(d) + _closing(d, rows)
        return "\n".join(o)

    o.append("h2. Summary")
    o.append("||Severity||Count||")
    for s in _ORDER:
        n = totals.get(s, 0)
        o.append(f"|{'(x)' if n else '(/)'} {_HEAD[s]}|{n}|")
    o.append("")

    for s in _ORDER:
        mine = [r for r in rows if r["severity"] == s]
        if not mine:
            o += [f"h2. (/) {_HEAD[s]}", "", "None.", ""]
            continue
        o += [f"h2. (x) {_HEAD[s]} ({len(mine)})", ""]
        # Rule 15: grouped under the page they belong to.
        for page in sorted({r["where"] for r in mine}):
            o.append(f"h3. {page}")
            for r in sorted(mine, key=lambda x: x["what"]):
                if r["where"] != page:
                    continue
                o.append(f"* {r['what']}")
                if r.get("stageid"):
                    o.append(f"** {{{{{r['stageid']}}}}}")
                if r.get("rule"):
                    o.append(f"** _BP Comparison Rules, rule {r['rule']}_")
                if r.get("rule_conflict"):
                    o.append(f"** (!) _{r['rule_conflict']}_")
                if r.get("fix"):
                    o.append(f"** *Action:* {r['fix']}")
            o.append("")

    o += ["h2. Remediation", "",
          "Goal (rules 21 and 24): overwrite the target with the base version.",
          ""]
    acts = sorted({r["fix"] for r in rows if r.get("fix")})
    for a in acts:
        o.append(f"* {a}")
    o += ["",
          "(!) Findings without an action above need a judgement call this tool "
          "does not make - what the change was *for*. That is the half a "
          "reviewer or a model has to write.", ""]

    o += _coding_rules(d) + _closing(d, rows)
    return "\n".join(o)


def _coding_rules(d: dict) -> list[str]:
    """Rule 1: the coding-rules section, highlighting issues.

    What is highlighted is not the base's whole issue list but the subset the
    overwrite would ADD, because that is the only part the reader can still
    decide about. An issue both versions share is real, and listed, but it is
    not a reason to hold the overwrite - it was there before and will be there
    after either way.
    """
    cr = d.get("coding_rules")
    if not cr:
        return []
    new = cr.get("introduced_by_overwrite") or []
    fixed = cr.get("fixed_by_overwrite_count", 0)
    o = [f"h2. {'(x)' if new else '(/)'} Coding rules", ""]
    o += ["||Measure||Count||",
          f"|Issues in the base version (what you keep)|{cr.get('base_issue_count', 0)}|",
          f"|Issues in the target version (what you lose)|{cr.get('target_issue_count', 0)}|",
          f"|(x) Introduced by overwriting|{len(new)}|",
          f"|(/) Fixed by overwriting|{fixed}|", ""]
    if not new:
        o += ["(/) Overwriting introduces no new coding-rules issue.", ""]
        return o
    o += ["These exist in the base version and not in the target, so the "
          "overwrite adds them:", ""]
    for f in new:
        where = f["page"] or f["artifact"] or "?"
        o.append(f"* *{f['severity']}* {{{{{f['rule_id']}}}}} - {where}")
        o.append(f"** {f['observed']}")
        o.append(f"** *Required:* {f['required']}")
        o.append(f"** _{f['section']}_")
    o.append("")
    return o


def _closing(d: dict, rows: list[dict]) -> list[str]:
    """Rule 16: a brief description of the report, at the end of it.

    Stated as fact and nothing more. Whether the overwrite should go ahead is
    left to the reader, because that depends on why the target diverged - which
    is the one thing no parser can see.
    """
    t = d.get("totals") or {}
    cr = d.get("coding_rules") or {}
    crit, imp, minor = t.get(CRITICAL, 0), t.get(IMPACTFUL, 0), t.get(MINOR, 0)
    pages = len({r["where"] for r in rows})

    o = ["h2. About this report", ""]
    o.append(f"Compared {{{{{d.get('base_file', 'base')}}}}} against "
             f"{{{{{d.get('target_file', 'target')}}}}} stage by stage: "
             f"{len(rows)} difference(s) across {pages} page(s), "
             f"{d.get('unchanged_count', 0)} stage(s) identical. "
             f"Graded {crit} critical, {imp} impactful, {minor} minor against "
             "the BP Comparison Rules.")
    if cr:
        o.append(f"The coding-rules pass adds {len(cr.get('introduced_by_overwrite') or [])} "
                 f"issue(s) and removes {cr.get('fixed_by_overwrite_count', 0)}.")
    o.append("")

    if crit:
        o += [f"(x) *{crit} critical finding(s).* A critical grade means an "
              "action's argument list differs, so overwriting changes the "
              "contract every calling process depends on. Confirm the callers "
              "before proceeding.", ""]
    elif imp:
        o += [f"(!) *No critical findings, {imp} impactful.* Nothing changes an "
              "action's signature, but pages or behaviour differ; the listed "
              "actions are worth working through first.", ""]
    else:
        o += ["(/) *Nothing critical or impactful.* The differences are "
              "cosmetic or confined to unpublished pages.", ""]

    o += ["_The change set and every severity above are computed, not judged: a "
          "parser diff graded by the numbered rules. What each change was "
          "intended to achieve is not in the files and is not claimed here._", ""]
    return o


_CSS = """
.sev{font-family:var(--mono);font-size:.66rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--mark)}
ul.finds{list-style:none;margin:0;padding:0;display:flex;
  flex-direction:column;gap:.55rem}
ul.finds>li{background:var(--card);border:1px solid var(--rule);
  border-left:4px solid var(--mark);padding:.95rem 1.1rem}
li.sev-critical{--mark:var(--fail)} li.sev-impactful{--mark:var(--flag)}
li.sev-minor{--mark:var(--rule-firm)}
.fhead{display:flex;align-items:baseline;gap:.6rem;flex-wrap:wrap;
  margin-bottom:.35rem}
.pg{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft)}
.finds p{margin:0 0 .4rem}
.finds dl{display:grid;grid-template-columns:max-content 1fr;gap:.2rem .9rem;
  margin:.5rem 0 0;font-size:.88rem}
.finds dt{font-family:var(--mono);font-size:.66rem;letter-spacing:.12em;
  text-transform:uppercase;color:var(--ink-soft)}
.finds dd{margin:0}
.sid{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft);
  word-break:break-all}
.act{border-left:3px solid var(--seal);padding-left:.7rem;margin:.5rem 0 0;
  font-size:.9rem}
.conflict{color:var(--flag);font-size:.86rem;margin:.4rem 0 0}
td.n-crit{color:var(--fail)} td.n-imp{color:var(--flag)}
td.n-ok{color:var(--pass)}
.closing{background:var(--card);border:1px solid var(--rule);
  padding:1.05rem 1.2rem;margin:1.2rem 0 0}
.closing p:last-child{margin-bottom:0}
.caveat{font-size:.9rem;color:var(--ink-soft);font-style:italic}
@media (max-width:34rem){.finds dl{grid-template-columns:1fr}}
"""

_BAND = {CRITICAL: "Critical", IMPACTFUL: "Impactful", MINOR: "Minor"}


def render_html(d: dict, source: str) -> str:
    rows = _rows(d)
    t = d.get("totals") or {}
    crit, imp = t.get(CRITICAL, 0), t.get(IMPACTFUL, 0)
    unchanged = d.get("unchanged_count", 0)
    compared = unchanged + len(rows)

    o = ['<div class="wrap">', "<header>",
         '<p class="lbl">Object comparison &middot; deterministic diff</p>',
         "<h1>What overwriting would change</h1>",
         f'<p class="artifact">{e(d.get("base"))}</p>', "</header>"]

    # The seal is stages IDENTICAL over stages compared, not a findings count.
    # A findings count answers "how different", which is meaningless until you
    # know the diff read anything - and a comparison that parsed nothing would
    # otherwise print a confident, clean zero.
    safe = not crit and not imp
    o.append(seal(
        safe, unchanged, compared,
        "Safe to overwrite" if safe else "Do not overwrite without review",
        "Nothing critical or impactful: the differences are cosmetic or on "
        "unpublished pages." if safe else
        f"{crit} critical and {imp} impactful finding(s). Overwriting the "
        "target with the base version would change behaviour a caller "
        "depends on.",
        [] if safe else [f"{r['what']} ({r['where']})"
                         for r in rows if r["severity"] == CRITICAL]))

    if not compared:
        o.append("<p>No stages were compared. This is not a clean result; it "
                 "is a failed one.</p></div>")
        return "\n".join(o)

    o.append("<h2>The two versions</h2>")
    o.append('<dl class="meta">')
    for lbl, key, inst in (("Base (overwrites)", "base_file", "base_instance"),
                           ("Target (overwritten)", "target_file", "target_instance")):
        v = e(d.get(key) or "?")
        if d.get(inst):
            v += f' &middot; instance <code>{e(d[inst])}</code>'
        o.append(f"<dt>{lbl}</dt><dd>{v}</dd>")
    o.append(f"<dt>Identical</dt><dd>{unchanged} of {compared} stage(s)</dd>")
    o.append("</dl>")

    o.append("<h2>Findings by severity</h2>")
    o.append('<div class="scroll"><table><thead><tr><th>Severity</th>'
             '<th class="num">Count</th><th>Means</th></tr></thead><tbody>')
    for s, why in ((CRITICAL, "an action's argument list differs, so every "
                              "calling process is affected"),
                   (IMPACTFUL, "behaviour or a published page differs"),
                   (MINOR, "names, comments, or unpublished pages")):
        n = t.get(s, 0)
        cls = "n-ok" if not n else ("n-crit" if s == CRITICAL else
                                    "n-imp" if s == IMPACTFUL else "")
        o.append(f"<tr><td>{_BAND[s]}</td>"
                 f'<td class="num {cls}">{n}</td><td>{e(why)}</td></tr>')
    o.append("</tbody></table></div>")

    for s in _ORDER:
        mine = [r for r in rows if r["severity"] == s]
        if not mine:
            continue
        o.append(f"<h2>{_BAND[s]} &middot; {len(mine)}</h2>")
        o.append('<ul class="finds">')
        for r in sorted(mine, key=lambda x: (x["where"], x["what"])):
            o.append(f'<li class="sev-{e(s)}">')
            o.append(f'<div class="fhead"><span class="sev">{e(s)}</span>'
                     f'<span class="pg">{e(r["where"])}</span></div>')
            o.append(f"<p>{e(r['what'])}</p>")
            if r.get("rule"):
                o.append('<dl><dt>Rule</dt><dd>BP Comparison Rules, rule '
                         f"{e(r['rule'])}</dd></dl>")
            if r.get("stageid"):
                o.append(f'<p class="sid">{e(r["stageid"])}</p>')
            if r.get("rule_conflict"):
                o.append(f'<p class="conflict">{e(r["rule_conflict"])}</p>')
            if r.get("fix"):
                o.append(f'<p class="act"><strong>Action.</strong> '
                         f'{e(r["fix"])}</p>')
            o.append("</li>")
        o.append("</ul>")

    o += _coding_rules_html(d) + _closing_html(d, rows)
    o.append(f"<footer>Generated from <code>{e(Path(source).name)}</code>, "
             f"{stamp()}.<br>Every severity here is a numbered rule in the BP "
             "Comparison Rules applied by a parser. No model was asked anything "
             "on this page.</footer></div>")
    return "\n".join(o)


def _coding_rules_html(d: dict) -> list[str]:
    cr = d.get("coding_rules")
    if not cr:
        return []
    new = cr.get("introduced_by_overwrite") or []
    o = ["<h2>Coding rules</h2>",
         "<p>Both versions were audited, because the question is not whether "
         "this object complies but whether overwriting makes compliance better "
         "or worse.</p>",
         '<div class="scroll"><table><tbody>',
         f"<tr><td>Issues in the base version (what you keep)</td>"
         f'<td class="num">{cr.get("base_issue_count", 0)}</td></tr>',
         f"<tr><td>Issues in the target version (what you lose)</td>"
         f'<td class="num">{cr.get("target_issue_count", 0)}</td></tr>',
         f"<tr><td>Introduced by overwriting</td>"
         f'<td class="num {"n-imp" if new else "n-ok"}">{len(new)}</td></tr>',
         f"<tr><td>Fixed by overwriting</td>"
         f'<td class="num n-ok">{cr.get("fixed_by_overwrite_count", 0)}</td></tr>',
         "</tbody></table></div>"]
    if not new:
        o.append("<p>Overwriting introduces no new coding-rules issue. Issues "
                 "shared by both versions are real, but they are not a reason "
                 "to hold the overwrite.</p>")
        return o
    o.append('<ul class="finds">')
    for f in new:
        o.append('<li class="sev-impactful">')
        o.append(f'<div class="fhead"><span class="sev">{e(f["rule_id"])}</span>'
                 f'<span class="pg">{e(f["page"] or f["artifact"])}</span></div>')
        o.append(f"<p>{e(f['rule'])}</p>")
        o.append(f"<dl><dt>Observed</dt><dd>{e(f['observed'])}</dd>"
                 f"<dt>Required</dt><dd>{e(f['required'])}</dd>"
                 f"<dt>Section</dt><dd>{e(f['section'])}</dd></dl>")
        o.append("</li>")
    o.append("</ul>")
    return o


def _closing_html(d: dict, rows: list[dict]) -> list[str]:
    """Rule 16, as prose rather than markup. Same sentences as the JIRA text."""
    body = [ln for ln in _closing(d, rows) if ln and not ln.startswith("h2.")]
    o = ["<h2>About this report</h2>", '<div class="closing">']
    for ln in body:
        txt = ln.replace("(x) ", "").replace("(!) ", "").replace("(/) ", "")
        txt = txt.replace("*", "").replace("{{", "").replace("}}", "")
        cls = ' class="caveat"' if txt.startswith("_") else ""
        o.append(f"<p{cls}>{e(txt.strip('_'))}</p>")
    o.append("</div>")
    return o


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("changes")
    p.add_argument("-o", "--out", default=None)
    p.add_argument("--html", default=None,
                   help="also write an HTML page, for reading without JIRA")
    p.add_argument("--ai-assisted", action="store_true",
                   help="stamp the report as AI Assisted (rule 18). Only true "
                        "once a model has actually written the explanations")
    args = p.parse_args()

    d = json.loads(Path(args.changes).read_text(encoding="utf-8"))
    text = render(d, args.ai_assisted)
    out = Path(args.out or Path(args.changes).with_suffix(".jira"))
    out.write_text(text + "\n", encoding="utf-8")
    wrote = [str(out)]

    if args.html:
        write(Path(args.html), "Object comparison", SEAL + _CSS,
              render_html(d, args.changes))
        wrote.append(args.html)

    t = d.get("totals") or {}
    print(f"{t.get(CRITICAL, 0)} critical, {t.get(IMPACTFUL, 0)} impactful, "
          f"{t.get(MINOR, 0)} minor -> {', '.join(wrote)}")
    sys.exit(1 if t.get(CRITICAL) else 0)


if __name__ == "__main__":
    main()
