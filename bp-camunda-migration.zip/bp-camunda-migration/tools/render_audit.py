"""Render a coding-rules audit as a single HTML page.

    python tools/render_audit.py <findings.json> [-o audit.html]

The seal on this page is deliberately NOT a count of findings. A findings count
answers "how bad is the code", which nobody can act on until they know the
audit looked at anything — and on the training export three of the eight checks
scan zero stages, because every Code stage in it belongs to a vendor VBO. So
the headline is **checks that examined something**, and a check that scanned
nothing is printed in the failure colour next to a check that scanned 320 and
found nothing. Those two must never look alike.

The page cites the section each finding rests on, by title, now that the bank
standard is held as reference (gitignored, never committed). It still refuses to
imply authority it lacks: checks sourced from the team's own methodology rather
than v5.0 say so, and a rule the standard does not state stays UNMAPPED.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _page import SEAL, e, seal, stamp, write   # noqa: E402


_CSS = """
.warnbar{border:1px solid var(--flag);border-left:4px solid var(--flag);
  background:var(--card);padding:.9rem 1.1rem;margin:0 0 2rem;
  font-size:.92rem;line-height:1.5}
.warnbar b{font-family:var(--mono);font-size:.68rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--flag);display:block;margin-bottom:.3rem}

td.chk{font-family:var(--mono);font-size:.78rem;white-space:nowrap}
td.cov{font-family:var(--mono);font-size:.7rem;letter-spacing:.1em;
  text-transform:uppercase;white-space:nowrap}
tr.cov-full td.cov{color:var(--pass)}
tr.cov-partial td.cov{color:var(--flag)}
tr.cov-none td.cov{color:var(--fail)}
td.src{font-size:.8rem;color:var(--ink-soft)}
tr.untraced td.src{color:var(--fail)}
tr.dead td{color:var(--fail)}
tr.dead td.num::after{content:" never ran";font-family:var(--serif);
  font-size:.78rem;opacity:.85}

ul.finds{list-style:none;margin:0;padding:0;display:flex;
  flex-direction:column;gap:.55rem}
ul.finds>li{background:var(--card);border:1px solid var(--rule);
  border-left:4px solid var(--mark);padding:.95rem 1.1rem}
li.sev-block{--mark:var(--fail)} li.sev-warn{--mark:var(--flag)}
li.sev-info{--mark:var(--rule-firm)}
.fhead{display:flex;align-items:baseline;gap:.6rem;flex-wrap:wrap;
  margin-bottom:.35rem}
.sev{font-family:var(--mono);font-size:.66rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--mark)}
.rid{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft)}
.finds p{margin:0 0 .45rem}
.finds dl{display:grid;grid-template-columns:max-content 1fr;gap:.2rem .9rem;
  margin:.5rem 0 0;font-size:.88rem}
.finds dt{font-family:var(--mono);font-size:.66rem;letter-spacing:.12em;
  text-transform:uppercase;color:var(--ink-soft)}
.finds dd{margin:0}
.sids{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft);
  margin:.5rem 0 0;word-break:break-all;line-height:1.5}
.mech{font-family:var(--mono);font-size:.66rem;letter-spacing:.12em;
  text-transform:uppercase;color:var(--seal);border:1px solid var(--seal);
  padding:.05rem .4rem}
@media (max-width:34rem){.finds dl{grid-template-columns:1fr}}
"""

_ORDER = {"block": 0, "warn": 1, "info": 2}


def render(d: dict, source: str) -> str:
    checks = d.get("checks_run") or []
    live = [c for c in checks if c.get("scanned")]
    findings = sorted(d.get("findings") or [],
                      key=lambda f: (_ORDER.get(f.get("severity"), 9),
                                     f.get("rule_id", "")))

    o = ['<div class="wrap">', "<header>",
         '<p class="lbl">Coding-rules audit &middot; deterministic checks</p>',
         "<h1>What the export can be held to</h1>",
         f'<p class="artifact">{e(d.get("input_scope"))}</p>', "</header>"]

    passed = len(live) == len(checks)
    o.append(seal(passed, len(live), len(checks),
                  "Every check examined something" if passed
                  else "Some checks examined nothing",
                  "Each check below ran against every stage in scope — no "
                  "sampling, no extrapolation."
                  if passed else
                  "A check that scanned nothing has not passed; it has not "
                  "run. Its rule is unproven on this export, and a clean "
                  "result here would be a false comfort.",
                  [f"{c['rule_id']} scanned 0 {c['applies_to']}"
                   for c in checks if not c.get("scanned")]))

    std = d.get("standard") or {}
    if not std.get("mapped"):
        o.append('<div class="warnbar"><b>Not yet the bank standard</b>'
                 f"{e(std.get('note'))}</div>")

    oos = d.get("out_of_scope")
    if oos:
        o.append("<h2>Excluded from the audit</h2>")
        o.append(f"<p>{e(oos.get('why'))}</p>")
        o.append('<div class="scroll"><table><tbody>')
        for a in oos.get("artifacts") or []:
            o.append(f"<tr><td><code>{e(a)}</code></td>"
                     "<td>vendor-shipped</td></tr>")
        o.append("</tbody></table></div>")

    # --- coverage against the standard's own sections --------------------- #
    cov = d.get("coverage") or []
    if cov:
        done = sum(1 for c in cov if c["covered"] == "full")
        part = sum(1 for c in cov if c["covered"] == "partial")
        o.append("<h2>Coverage of the standard</h2>")
        o.append(f"<p>{done} of {len(cov)} sections are checked in full and "
                 f"{part} in part. The rest are listed with what each one needs "
                 "— an uncovered section is a known gap, not a silent one.</p>")
        o.append('<div class="scroll"><table><thead><tr><th>Section</th>'
                 "<th>Covered</th><th>By / what it needs</th></tr></thead><tbody>")
        for c in cov:
            o.append(f'<tr class="cov-{e(c["covered"])}">'
                     f"<td>{e(c['section'])}</td>"
                     f'<td class="cov">{e(c["covered"])}</td>'
                     "<td>" + (", ".join(f"<code>{e(x)}</code>"
                                         for x in c.get("checks") or [])
                               or e(c.get("gap"))) + "</td></tr>")
        o.append("</tbody></table></div>")

    # --- the checks table. The zero-scan rows are the point. -------------- #
    o.append("<h2>Checks run</h2>")
    o.append('<div class="scroll"><table><thead><tr><th>Check</th>'
             "<th>Applied to</th><th>Rule source</th><th class=\"num\">Scanned</th>"
             "<th class=\"num\">Findings</th></tr></thead><tbody>")
    for c in checks:
        klass = []
        if not c.get("scanned"):
            klass.append("dead")
        if "NOT TRACEABLE" in (c.get("source") or ""):
            klass.append("untraced")
        dead = f' class="{" ".join(klass)}"' if klass else ""
        o.append(f"<tr{dead}><td class=\"chk\">{e(c['rule_id'])}</td>"
                 f"<td>{e(c['applies_to'])}</td>"
                 f"<td class=\"src\">{e(c.get('source'))}</td>"
                 f"<td class=\"num\">{c.get('scanned', 0)}</td>"
                 f"<td class=\"num\">{c.get('findings', 0)}</td></tr>")
    o.append("</tbody></table></div>")

    # --- findings ---------------------------------------------------------- #
    o.append("<h2>Findings</h2>")
    if not findings:
        o.append("<p>No check that ran produced a finding. That is a valid "
                 "result — but read the table above first: it is only as "
                 "strong as the number of checks that scanned anything.</p>")
    else:
        o.append('<ul class="finds">')
        for f in findings:
            sev = f.get("severity", "info")
            o.append(f'<li class="sev-{e(sev)}">')
            o.append(f'<div class="fhead"><span class="sev">{e(sev)}</span>'
                     f'<span class="rid">{e(f.get("rule_id"))}</span>'
                     + ('<span class="mech">mechanical fix</span>'
                        if f.get("fix_is_mechanical") else "") + "</div>")
            o.append(f"<p>{e(f.get('rule'))}</p>")
            o.append("<dl>")
            o.append(f"<dt>Where</dt><dd>{e(f.get('artifact'))}"
                     + (f" &middot; {e(f.get('page'))}" if f.get("page") else "")
                     + "</dd>")
            o.append(f"<dt>Observed</dt><dd>{e(f.get('observed'))}</dd>")
            o.append(f"<dt>Required</dt><dd>{e(f.get('required'))}</dd>")
            o.append(f"<dt>Section</dt><dd>{e(f.get('rule_section'))}</dd>")
            o.append("</dl>")
            sids = f.get("stageids") or []
            o.append(f'<p class="sids">{len(sids)} stage(s): '
                     + " ".join(e(s) for s in sids[:12])
                     + (f" … and {len(sids) - 12} more" if len(sids) > 12 else "")
                     + "</p>")
            o.append("</li>")
        o.append("</ul>")

    na = d.get("not_auditable") or []
    if na:
        o.append("<h2>Not auditable from an export</h2>")
        o.append('<div class="scroll"><table><thead><tr><th>Rule area</th>'
                 "<th>Why not</th></tr></thead><tbody>")
        for x in na:
            o.append(f"<tr><td>{e(x.get('rule_section'))}</td>"
                     f"<td>{e(x.get('why'))}</td></tr>")
        o.append("</tbody></table></div>")

    o.append(f"<footer>Generated from <code>{e(Path(source).name)}</code>, "
             f"{stamp()}.<br>Deterministic: every check is an exact match over "
             "every stage in scope. No model was asked anything on this page."
             "</footer></div>")
    return "\n".join(o)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("findings")
    p.add_argument("-o", "--out", default=None)
    p.add_argument("--fragment", action="store_true")
    args = p.parse_args()

    d = json.loads(Path(args.findings).read_text(encoding="utf-8"))
    out = Path(args.out or Path(args.findings).with_suffix(".html"))
    write(out, "Coding-rules audit", SEAL + _CSS, render(d, args.findings),
          fragment=args.fragment)

    checks = d.get("checks_run") or []
    live = sum(1 for c in checks if c.get("scanned"))
    print(f"{live}/{len(checks)} checks scanned something, "
          f"{len(d.get('findings') or [])} finding(s) -> {out}")
    sys.exit(0 if live == len(checks) else 1)


if __name__ == "__main__":
    main()
