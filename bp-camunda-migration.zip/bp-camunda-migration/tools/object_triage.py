#!/usr/bin/env python3
"""object_triage.py -- can this OBJECT become meaningful BPMN, or does it need an API?

The tier heuristic guesses from the object NAME. This decides from the object's
CONTENT, which is the only honest test:

  * UI-DRIVING  -- a real Application Modeller definition (an <appdef> with more
                   than the stub root, and/or a launch type) and/or stages bound
                   to screen elements. Its work IS the UI. BPMN has no shape for
                   "click this button": needs a real API (task 1).
  * LOGIC-ONLY  -- no application driven, no element-bound stages: calculations,
                   decisions, loops, calls to other objects. This is ordinary
                   flow logic and CONVERTS to BPMN today, like a process does.
  * MIXED       -- drives an app but a large share of its stages are pure logic;
                   worth splitting: the logic half can migrate now.

Run it on an export that CONTAINS OBJECTS (a release with the Objects group, or
.bpobject files). Process-only exports have nothing to triage -- objects are not
in them.

  python object_triage.py <export> [-o object_triage.json]

Stdlib + bp_core only.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

import bp_core
from bp_core import _kid, _kids, _kid_text, _local
# The VBO tier decides whether a content signal is meaningful. A SHIPPED utility
# VBO can contain one HTTP download among twenty file actions -- that does not
# make it an API client, and its answer ("replace with a connector") is already
# known. Signals therefore only choose the verdict for CUSTOM objects.
from bp_emit import _vbo_tier

# Stages whose work is inherently screen-bound: they carry an <element> reference
# into Application Modeller. Presence of these = the object drives a UI.
_UI_STAGE_TYPES = {"Navigate", "Read", "Write", "WaitStart", "WaitEnd", "Wait"}
# Stages that are ordinary logic -- these convert to BPMN cleanly.
# Declarations / cosmetics -- never "work" when judging how UI-heavy an object is.
_NONWORK_STAGE_TYPES = {
    "Data", "Collection", "Note", "Anchor", "Block", "SubSheetInfo", "ProcessInfo",
}
# Content signals. A VBO's WORK is what matters, never its name. Each of these
# changes the migration answer completely, so they are separated:
#   api-driven -> the API ALREADY EXISTS; call it directly, delete the client
#   database   -> point the platform at the database, do not port the driver
#   shell      -> needs OS access on a machine; cannot become an API call
_API_SIGNALS = ("system.net", "httpclient", "webrequest", "webclient",
                "restsharp", "newtonsoft.json", "system.net.http")
_DB_SIGNALS = ("system.data.sqlclient", "sqlconnection", "oledbconnection",
               "system.data.oledb", "system.data.odbc", "connectionstring")
_SHELL_SIGNALS = ("process.start", "system.diagnostics.process", "cmd.exe",
                  "powershell", "shellexecute")

# A launch type says WHICH re-host path a UI object needs. Lumping them into one
# "ui-driving" number hides that browser work and mainframe work are nothing
# like Win32 work -- mainframes usually expose transactions/MQ instead.
_UI_KIND = (
    ("browser", ("browser", "html")),
    ("mainframe", ("mainframe",)),
    ("java", ("java",)),
    ("win32", ("win32",)),
)


def _ui_kind(launch: str) -> str:
    l = (launch or "").lower()
    for kind, needles in _UI_KIND:
        if any(n in l for n in needles):
            return kind
    return "other"


_LOGIC_STAGE_TYPES = {
    "Calculation", "MultipleCalculation", "Decision", "ChoiceStart", "ChoiceEnd",
    "LoopStart", "LoopEnd", "Action", "SubSheet", "Page", "Start", "End",
}


def _appdef_facts(body: ET.Element) -> tuple[int, str]:
    """(modelled element count, launch type) from <appdef>. A stub appdef -- the
    empty default every object carries -- yields (<=1, "")."""
    ad = _kid(body, "appdef")
    if ad is None:
        return 0, ""
    elements = [e for e in ad.iter() if _local(e.tag) == "element"]
    ti = next((e for e in ad.iter() if _local(e.tag) == "apptypeinfo"), None)
    launch = (_kid_text(ti, "id") if ti is not None else None) or ""
    return len(elements), launch.strip()


def _element_bound(st: ET.Element) -> bool:
    """True if a stage references an Application Modeller element (screen-bound).
    CONFIRMED against a real export: the reference is nested -- <stage><step>
    <element id=".."/> -- NOT a direct child, so a direct-children scan reports
    zero on every real UI stage."""
    return any(_local(e.tag) in ("element", "elementid") for e in st.iter())


def triage_body(body: ET.Element, name: str) -> dict:
    n_elements, launch = _appdef_facts(body)
    stages = _kids(body, "stage")
    kinds = Counter(st.get("type", "") for st in stages)
    bound = sum(1 for st in stages if _element_bound(st))
    ui_typed = sum(1 for st in stages if st.get("type", "") in _UI_STAGE_TYPES)
    logic = sum(1 for st in stages if st.get("type", "") in _LOGIC_STAGE_TYPES)
    code = kinds.get("Code", 0)
    # Lines of embedded C#/VB. A "code-bound" object is only cheap if this is
    # small: a real one can hide an entire integration framework (OAuth, token
    # refresh, JWT, HTTP) that no BPMN conversion can carry across.
    code_loc = 0
    blob = []          # every code body + the declared references/imports
    for st in stages:
        for c in st.iter():
            n = _local(c.tag)
            if n in ("code", "globalcode") and c.text:
                code_loc += sum(1 for ln in c.text.splitlines() if ln.strip())
                blob.append(c.text)
            elif n in ("reference", "import") and c.text:
                blob.append(c.text)
    text = " ".join(blob).lower()
    has_api = any(k in text for k in _API_SIGNALS)
    has_db = any(k in text for k in _DB_SIGNALS)
    has_shell = any(k in text for k in _SHELL_SIGNALS)

    drives_app = n_elements > 1 or bool(launch)
    # A Wait/Navigate stage only means UI work if there is an application to
    # drive. With a stub appdef (a code-only VBO) a Wait is just a sleep, so
    # counting it as screen automation misfiles a pure-logic object.
    ui_work = bound + (ui_typed if drives_app else 0)
    # Work stages only. Data/Collection/Note/Anchor/Block/SubSheetInfo/ProcessInfo
    # are declarations or cosmetics, NOT work: counting them in the denominator
    # made real UI objects (100 Navigate + 400 Data) look "mostly logic".
    work = sum(v for k, v in kinds.items() if k not in _NONWORK_STAGE_TYPES) or 1

    kind = _ui_kind(launch)
    custom = _vbo_tier(name) == "rehost"
    if drives_app and ui_work:
        verdict = "ui-driving"
        note = (f"drives a {kind} application with screen-bound stages: "
                "needs an API, or a re-host on that specific path")
    elif drives_app:
        verdict = "mixed"
        note = "declares an application but no UI stages found: inspect manually"
    elif has_api and custom:
        # The work IS an HTTP client. The API already exists -- this is the
        # CHEAPEST bucket, not an expensive one.
        verdict = "api-driven"
        note = "calls an HTTP/REST API: call that API directly, do not port the client"
    elif has_db and custom:
        verdict = "database"
        note = "talks to a database: point the platform at the database directly"
    elif has_shell and custom:
        verdict = "shell"
        note = "runs OS processes: needs a worker with OS access; cannot become an API call"
    elif code:
        # No app, but .NET/VB code stages: the parser cannot convert a code body.
        verdict = "code-bound"
        note = f"no UI, but {code} Code stage(s): re-implement the code, flow itself is convertible"
    else:
        verdict = "logic-only"
        note = "no application modelled and no screen-bound stages: converts to BPMN today"

    return {
        "object": name,
        "verdict": verdict,
        "note": note,
        "drives_application": drives_app,
        "appdef_elements": n_elements,
        "launch_type": launch,
        "stages": len(stages),
        "element_bound_stages": bound,
        "ui_typed_stages": ui_typed,
        "logic_stages": logic,
        "work_stages": work,
        "code_stages": code,
        "code_loc": code_loc,
        "ui_kind": kind if verdict in ("ui-driving", "mixed") else "",
        "signals": ",".join(k for k, v in (("api", has_api), ("db", has_db),
                                           ("shell", has_shell)) if v),
        "stage_types": dict(sorted(kinds.items())),
    }


# Blue Prism can write ILLEGAL numeric character references (control chars) into
# an export; XML 1.0 forbids them and the parser rejects the whole file. Strip
# only those, and REPORT the count -- never silently swallow a parse error.
_BADREF = re.compile(r"&#(?:([0-9]+)|[xX]([0-9a-fA-F]+));")


def _illegal(n: int) -> bool:
    return not (n in (0x9, 0xA, 0xD) or 0x20 <= n <= 0xD7FF
                or 0xE000 <= n <= 0xFFFD or 0x10000 <= n <= 0x10FFFF)


def _parse_forgiving(path):
    """Return (root_element, n_stripped). BOTH returns are tuples -- returning a
    bare Element makes `root, scrubbed = ...` unpack the element's CHILDREN."""
    raw = Path(path).read_text(encoding="utf-8", errors="replace")
    try:
        return ET.fromstring(raw), 0
    except ET.ParseError:
        removed = []

        def rep(m):
            n = int(m.group(1)) if m.group(1) else int(m.group(2), 16)
            if _illegal(n):
                removed.append(n)
                return ""
            return m.group(0)

        cleaned = _BADREF.sub(rep, raw)
        return ET.fromstring(cleaned), len(removed)


def collect(paths: list[str]) -> dict:
    rows: list[dict] = []
    for p in bp_core._collect(paths):
        root, scrubbed = _parse_forgiving(p)
        if scrubbed:
            print(f"NOTE: {p.name}: stripped {scrubbed} illegal character reference(s)",
                  file=sys.stderr)
        if _local(root.tag) == "process" and _kid(root, "process") is None:
            # standalone .bpobject / .bpprocess -- only triage true objects
            if _kid(root, "appdef") is not None:
                rows.append(triage_body(root, root.get("name") or p.stem))
            continue
        for wrapper in root.iter():
            if _local(wrapper.tag) != "object":     # objects only, skip processes
                continue
            body = _kid(wrapper, "process")
            if body is None:
                continue
            rows.append(triage_body(
                body, body.get("name") or wrapper.get("name") or "(unnamed)"))

    rows.sort(key=lambda r: (r["verdict"], r["object"].lower()))
    counts = Counter(r["verdict"] for r in rows)
    return {"object_count": len(rows), "verdicts": dict(counts), "objects": rows}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="object_triage")
    ap.add_argument("inputs", nargs="+", help="export file(s) or directory CONTAINING OBJECTS")
    ap.add_argument("-o", "--out", help="write JSON here instead of stdout")
    ap.add_argument("--summary", action="store_true",
                    help="print counts only (safe to photograph)")
    a = ap.parse_args(argv)

    data = collect(a.inputs)
    if a.summary:
        print("=== OBJECT TRIAGE (counts only) ===")
        print(f"objects: {data['object_count']}")
        for v in sorted(data["verdicts"]):
            print(f"    {v}: {data['verdicts'][v]}")
        kinds = Counter(o["ui_kind"] for o in data["objects"]
                        if o["verdict"] == "ui-driving" and o.get("ui_kind"))
        for k in sorted(kinds):
            print(f"        ui-driving / {k}: {kinds[k]}")
        if not data["object_count"]:
            print("  (no objects found -- export the Objects group, not just the process)")
        return 0

    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    if a.out:
        Path(a.out).write_text(text, encoding="utf-8")
        print(f"{data['object_count']} object(s) -> {a.out}  {data['verdicts']}", file=sys.stderr)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
