#!/usr/bin/env python3
"""api_facts.py -- per-object API ledger for the 02-api-spec deliverable.

Reads a Blue Prism export and, for every VBO the processes CALL, aggregates the
actions used and -- from the call sites -- the input fields sent and output
fields captured. That is the evidence-based API surface: object = service,
action = candidate endpoint, inputs = request fields, outputs = response fields.
Every fact carries stageids so the downstream spec can be grep-checked.

Runs where the exports are (imports bp_core + bp_emit, both already present).
Stdlib only otherwise.

  python api_facts.py <release> [-o api_facts.json] [--tier rehost|all]

Default --tier rehost = only the CUSTOM objects that actually need an API built
(native/connector already have a path). --tier all keeps every object.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import bp_core
from bp_emit import _vbo_tier  # single source of truth for the tier heuristic


def build_facts(release: str, tier_filter: str) -> dict:
    est = bp_core.Estate()
    bp_core.parse_paths(bp_core._collect([release]), est)

    # (object, action) -> {inputs, outputs, stageids, calls}
    acts: dict[tuple, dict] = defaultdict(
        lambda: {"inputs": set(), "outputs": set(), "stageids": [], "calls": 0})
    for stages in est.stages_by_artifact.values():
        for s in stages:
            if s.type != "Action" or not s.target_object:
                continue
            key = (s.target_object, s.target_action or "?")
            rec = acts[key]
            rec["inputs"].update(s.inputs.keys())
            rec["outputs"].update(s.outputs.keys())
            rec["calls"] += 1
            if s.id:
                rec["stageids"].append(s.id)

    # regroup by object; attach tier; filter
    by_obj: dict[str, dict] = {}
    for (obj, action), rec in acts.items():
        tier = _vbo_tier(obj)
        if tier_filter == "rehost" and tier != "rehost":
            continue
        o = by_obj.setdefault(obj, {"object": obj, "tier": tier, "actions": []})
        o["actions"].append({
            "action": action,
            "calls": rec["calls"],
            "request_fields": sorted(rec["inputs"]),
            "response_fields": sorted(rec["outputs"]),
            "stageids": sorted(rec["stageids"]),
        })

    objects = sorted(by_obj.values(), key=lambda o: o["object"].lower())
    for o in objects:
        o["actions"].sort(key=lambda a: a["action"].lower())
    return {
        "release": Path(release).name,
        "tier_filter": tier_filter,
        "object_count": len(objects),
        "objects": objects,
    }


def _why(name: str, v: dict) -> list[str]:
    """What is actually blocking this object, and what to DO about it.

    The verdict alone is not advice. A code-bound object that is a SHIPPED Blue
    Prism VBO (Excel, file, collection, string utilities) must NOT be
    re-implemented -- its C# does what a connector or the standard library
    already does, so the code is throwaway. Only a code-bound CUSTOM object is
    real porting work, and there the source exists and can be extracted."""
    tier = _vbo_tier(name)
    verdict = v["verdict"]
    loc = v.get("code_loc") or 0
    stages = v.get("code_stages") or 0
    if verdict == "ui-driving":
        # The launch type decides the re-host path, and the paths differ hugely
        # in cost. Reporting one "ui-driving" number hid that.
        kind = v.get("ui_kind") or "other"
        if kind == "browser":
            return ["BLOCKED BY: drives a WEB application on screen.",
                    "WHAT TO DO : ask for the API first -- a web app almost always has one",
                    "             behind it. Failing that, a browser re-host is the",
                    "             cheapest UI path."]
        if kind == "mainframe":
            return ["BLOCKED BY: drives a MAINFRAME terminal (not a GUI).",
                    "WHAT TO DO : do NOT plan a screen re-host first. Mainframes normally",
                    "             expose transactions/MQ/a service interface -- ask for",
                    "             that. Screen-scraping is the fallback, not the plan."]
        if kind == "win32":
            return ["BLOCKED BY: drives a WIN32 desktop application on screen.",
                    "WHAT TO DO : an API for this application. A re-host means owning a",
                    "             desktop-automation stack -- this is the expensive path."]
        return ["BLOCKED BY: drives an application on screen (" + kind + ").",
                "WHAT TO DO : an API for this application, or a re-host on that path."]
    if verdict == "api-driven":
        return ["BLOCKED BY: nothing structural -- this object IS an HTTP/REST client.",
                "WHAT TO DO : call that API directly from the target platform. Harvest the",
                "             endpoints and auth; DELETE the client. Cheapest bucket."]
    if verdict == "database":
        return ["BLOCKED BY: nothing structural -- this object talks to a database.",
                "WHAT TO DO : point the platform at the database directly.",
                "             Do not port the driver code."]
    if verdict == "shell":
        return ["BLOCKED BY: runs OS processes (command line / executables).",
                "WHAT TO DO : needs a worker with OS access on a machine. This one cannot",
                "             become an API call."]
    if verdict == "code-bound" and tier == "connector":
        return [f"BLOCKED BY: a shipped Blue Prism VBO with {stages} code stage(s), {loc} lines of C#.",
                "WHAT TO DO : REPLACE it with a connector or standard library.",
                "             Do NOT port the C# -- it does what the platform already does."]
    if verdict == "code-bound":
        out = [f"BLOCKED BY: custom embedded code -- {stages} code stage(s), {loc} lines.",
               "WHAT TO DO : port the code (the source is in the export; run",
               "             extract_code.py to get it as files)."]
        if v.get("signals"):
            out.append("             NOTE: contains " + v["signals"] + " calls -- check whether"
                       " part of this is a direct API/DB call you can keep instead of porting.")
        return out
    if verdict == "logic-only":
        return ["BLOCKED BY: nothing -- this object converts to BPMN as-is."]
    return [f"BLOCKED BY: {verdict} -- inspect by hand."]


def render_sheet(facts: dict) -> str:
    """The binding sheet: one short block per object saying what it NEEDS, and a
    blank BINDING line for whoever decides how it gets satisfied (an API URL, an
    existing Blue Prism object, a script name). Plain text -- edit it in any
    editor, no tool required."""
    out = [
        "BINDING SHEET -- " + facts["release"],
        "",
        "One block per object this process needs. Fill in the BINDING line:",
        "    an API url  |  a Blue Prism object  |  a script name  |  none",
        "Leave it as TODO if it is not decided yet.",
        "",
        "=" * 70,
        "",
    ]
    verdicts = facts.get("_verdicts", {})
    for o in facts["objects"]:
        out.append(o["object"])
        out.append("-" * len(o["object"]))
        v = verdicts.get(o["object"])
        if v:
            for ln in _why(o["object"], v):
                out.append(ln)
        out.append("Needs a way to do %d thing(s):" % len(o["actions"]))
        for a in o["actions"]:
            takes = ", ".join(a["request_fields"]) or "nothing"
            gives = ", ".join(a["response_fields"]) or "nothing"
            out.append("  - %s: takes %s; gives back %s  (used %dx)"
                       % (a["action"], takes, gives, a["calls"]))
        out.append("")
        out.append("BINDING: TODO")
        out.append("")
        out.append("=" * 70)
        out.append("")
    return chr(10).join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="api_facts")
    ap.add_argument("release", help="a .bprelease / .bpprocess export")
    ap.add_argument("--tier", choices=("rehost", "all"), default="rehost",
                    help="rehost = only custom objects needing an API (default); all = every object")
    ap.add_argument("--sheet", action="store_true",
                    help="write a plain-text BINDING SHEET instead of JSON")
    ap.add_argument("--triage", metavar="object_triage.json",
                    help="keep only objects with these verdicts (content-based, "
                         "beats the name heuristic); use with --verdict")
    ap.add_argument("--verdict", default="ui-driving",
                    help="comma-separated verdicts to keep from --triage "
                         "(default: ui-driving)")
    ap.add_argument("-o", "--out", help="write JSON here instead of stdout")
    a = ap.parse_args(argv)

    facts = build_facts(a.release, a.tier)
    if a.triage:
        # Content-based verdicts from object_triage.py: an object that really
        # drives a screen needs binding; a name heuristic only guesses.
        want = {v.strip() for v in a.verdict.split(",") if v.strip()}
        tri = json.loads(Path(a.triage).read_text(encoding="utf-8"))

        def _norm(s):
            return " ".join(s.split()).strip().lower()

        keep = {_norm(o["object"]) for o in tri["objects"] if o["verdict"] in want}
        facts["objects"] = [o for o in facts["objects"] if _norm(o["object"]) in keep]
        facts["object_count"] = len(facts["objects"])
        # carry the verdict + code volume through so the sheet says WHY each
        # object is blocked, not just what it does
        facts["_verdicts"] = {o["object"]: t for o in facts["objects"]
                              for t in tri["objects"] if _norm(t["object"]) == _norm(o["object"])}
    text = (render_sheet(facts) if a.sheet
            else json.dumps(facts, indent=2, ensure_ascii=False) + "\n")
    if a.out:
        Path(a.out).write_text(text, encoding="utf-8")
        print(f"{facts['object_count']} object(s), tier={a.tier} -> {a.out}", file=sys.stderr)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
