"""Assemble one migration pack: the document, every page specification, and
the screens the automation drives — as a single self-contained HTML file.

    python tools/render_pack.py <doc.json> <export> --specs <spec-dir> [-o pack.html]

Until now each renderer emitted its own page, which is three files a reader has
to be given in the right order and told how to hold. The format their team has
already signed off on is one document per process, so this is that: one file,
one stylesheet, one contents list, and one verdict at the top that is true only
if every part underneath it is true.

The parts keep their own seals. A pack that says "verified" while a page
specification inside it says "do not trust this" would be worse than either
document alone, so the pack's headline is the count of parts that passed and it
cannot be green unless all of them are.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import render_doc as D          # noqa: E402
import render_screens as S      # noqa: E402
import render_spec as P         # noqa: E402
import verify_llm_output as V   # noqa: E402
from _page import SEAL, e, seal, stamp, write   # noqa: E402
from bp_estate.cli import _collect              # noqa: E402


# Parts are stacked, so each one's own shell must stop being a page: no second
# centred column, no second top margin. Everything else they bring is theirs.
_CSS = """
.wrap{max-width:44rem}
nav.toc{margin:0 0 1rem;padding:0;list-style:none}
nav.toc ol{margin:0;padding:0;list-style:none;display:flex;
  flex-direction:column;gap:.15rem}
nav.toc li{display:grid;grid-template-columns:1.6rem 1fr auto;gap:.6rem;
  align-items:baseline;font-size:.95rem;padding:.3rem 0;
  border-bottom:1px solid var(--rule)}
nav.toc .n{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft);
  font-variant-numeric:tabular-nums}
nav.toc a{color:inherit;text-decoration:none;border-bottom:1px solid var(--rule-firm)}
nav.toc a:hover{border-bottom-color:var(--ink)}
nav.toc .v{font-family:var(--mono);font-size:.68rem;letter-spacing:.1em;
  text-transform:uppercase;white-space:nowrap}
nav.toc .v.ok{color:var(--pass)} nav.toc .v.no{color:var(--fail)}

.part{margin:3.5rem 0 0;padding-top:2rem;border-top:2px solid var(--ink)}
.part>.wrap{max-width:none;margin:0;padding:0}
.part header{border-bottom-width:1px;border-bottom-color:var(--rule-firm)}
/* Demoted from h1 (see demote()), so it must be told to stop looking like the
   mono eyebrow every other h2 on the page is. */
.part h2.pt{font-family:var(--serif);font-size:1.3rem;font-weight:600;
  letter-spacing:-.01em;text-transform:none;color:var(--ink);
  border:0;padding:0;margin:0;line-height:1.15;text-wrap:balance}
.part .seal{margin:1.1rem 0 1.5rem}
.part .frac{font-size:1.4rem}
.part .lede{font-size:1rem}
.part footer{margin-top:2rem;font-size:.68rem;border-top-style:dashed}
.kind{font-family:var(--mono);font-size:.66rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--seal);margin:0 0 .8rem}
"""


def demote(body: str) -> str:
    """Each part renders as a standalone page, so each brings an <h1>. Stacked,
    that is ten level-one headings in one document and a reader on a screen
    reader is told the file restarts nine times. The pack owns the only h1."""
    if "<h1>" not in body:
        raise AssertionError("part body has no <h1> to demote — the renderer "
                             "changed shape and this would silently do nothing")
    return body.replace("<h1>", '<h2 class="pt">', 1).replace("</h1>", "</h2>", 1)


class Part:
    def __init__(self, kind: str, title: str, body: str, passed: bool,
                 got: int, total: int):
        self.kind, self.title, self.body = kind, title, demote(body)
        self.passed, self.got, self.total = passed, got, total


def build(doc_path: Path, export: str, specs: list[Path]) -> list[Part]:
    parts: list[Part] = []

    doc = V.load_answer(doc_path)
    v = D.verdict(doc, export, specs)
    parts.append(Part("Process documentation", doc.get("artifact") or "Untitled",
                      D.render(doc, v, str(doc_path)), v["passed"],
                      v["got"], v["total"]))

    for sp in specs:
        spec = V.load_answer(sp)
        sv = P.verdict(spec, export)
        parts.append(Part("Page specification", spec.get("page") or sp.stem,
                          P.render(spec, sv, str(sp)), sv["passed"],
                          sv["accounted"], sv["total"]))

    screens = S.collect_screens(_collect([export]))
    if screens:
        # Nothing to verify here: these are parser output with no prose in them,
        # so they cannot be wrong about the export in the way a document can.
        parts.append(Part("Application Modeller", "Screens driven by the automation",
                          S.render(screens, Path(export).name), True,
                          len(screens), len(screens)))
    return parts


def render(parts: list[Part], name: str, source: str) -> str:
    ok = sum(1 for p in parts if p.passed)
    passed = ok == len(parts)

    o = ['<div class="wrap">', "<header>",
         '<p class="lbl">Migration pack</p>',
         f"<h1>{e(name)}</h1>",
         f'<p class="lbl">{len(parts)} part(s) &middot; generated, not written</p>',
         "</header>"]

    if passed:
        head, why = "Every part verified", (
            "Each part below was checked against the export it came from. "
            "Nothing was dropped and nothing was invented.")
    else:
        head, why = "One or more parts failed", (
            "At least one part does not account for what it describes. "
            "Regenerate that part — do not patch this file by hand.")
    o.append(seal(passed, ok, len(parts), head, why,
                  [f"{p.title}: {p.got}/{p.total} accounted for"
                   for p in parts if not p.passed]))

    o.append('<h2>Contents</h2><nav class="toc"><ol>')
    for i, p in enumerate(parts, 1):
        o.append(f'<li><span class="n">{i:02d}</span>'
                 f'<span><a href="#part-{i}">{e(p.title)}</a> — {e(p.kind.lower())}</span>'
                 f'<span class="v {"ok" if p.passed else "no"}">'
                 f'{p.got}/{p.total}</span></li>')
    o.append("</ol></nav>")
    o.append("</div>")

    for i, p in enumerate(parts, 1):
        o.append(f'<section class="part" id="part-{i}"><div class="wrap">'
                 f'<p class="kind">{i:02d} &nbsp;/&nbsp; {e(p.kind)}</p></div>')
        o.append(p.body)
        o.append("</section>")

    o.append('<div class="wrap">')
    o.append(f"<footer>Assembled from <code>{e(source)}</code>, {stamp()}."
             "<br>Every part of this file is generated. Regenerate it; never "
             "edit it — a hand edit cannot be verified and the seals above "
             "would then be lying.</footer>")
    o.append("</div>")
    return "\n".join(o)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("doc")
    p.add_argument("export")
    p.add_argument("--specs", nargs="*", default=[])
    p.add_argument("-o", "--out", default="pack.html")
    p.add_argument("--fragment", action="store_true",
                   help="emit only <style> + content, for embedding elsewhere")
    args = p.parse_args()

    specs: list[Path] = []
    for raw in args.specs:
        q = Path(raw)
        specs.extend(sorted(q.glob("*.json")) if q.is_dir() else [q])

    doc_path = Path(args.doc)
    parts = build(doc_path, args.export, specs)
    name = V.load_answer(doc_path).get("artifact") or doc_path.stem

    css = SEAL + D._CSS + P._CSS + S._CSS + _CSS
    write(Path(args.out), f"{name} - migration pack", css,
          render(parts, name, doc_path.name), fragment=args.fragment)

    bad = [p for p in parts if not p.passed]
    for q in parts:
        print(f"  {'PASS' if q.passed else 'FAIL'} {q.got:>3}/{q.total:<3} {q.title}")
    print(f"{len(parts) - len(bad)}/{len(parts)} parts verified -> {args.out}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
