#!/usr/bin/env python3
"""Split a .bprelease bundle into one standalone artifact file each.

A .bprelease is not an archive - it is a single XML document that wraps every
process and object in the release. `bp-estate analyze` and `audit_rules.py`
already read the bundle whole, but the *single-artifact* tools do not:
`diff_objects.py` refuses a multi-artifact file outright, and per-object
documentation wants one artifact at a time. This tool is the adapter between
them - it writes each artifact back out in the exact shape Blue Prism produces
for a single export, so the extracted files round-trip through the rest of the
toolchain identically to a real one-object export.

What "the exact shape" means, verified against a real release and a real single
export: a single .bpobject/.bpprocess has the artifact's *body* <process> as its
root (appdef, stages and subsheets hang off it) - the release's <object>/<process>
wrapper carries only id+name and is dropped. The wrapper's tag decides the file
extension, which is how downstream infers object-vs-process. Manifest stubs (a
wrapper with no body) are skipped, the same trap the parser documents.

Stdlib only - it runs on the embeddable-zip Python with no pip, because every
single-artifact workflow is downstream of it.

    python tools/extract_release.py RELEASE.bprelease -o out/objects
    python tools/extract_release.py RELEASE.bprelease --list      # dry run
"""
import argparse
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

PROC_NS = "http://www.blueprism.co.uk/product/process"
_ILLEGAL = '\\/:*?"<>|'          # Windows-illegal filename characters


def _local(tag: str) -> str:
    """Tag without its XML namespace, e.g. '{..}process' -> 'process'."""
    return tag.rsplit("}", 1)[-1]


def _safe_name(name: str) -> str:
    """Artifact name -> a filename stem: keep it readable, drop only what the
    filesystem forbids. Never collapse to empty."""
    cleaned = "".join(c for c in name if c not in _ILLEGAL).strip().rstrip(".")
    cleaned = " ".join(cleaned.split())           # collapse whitespace runs
    return cleaned or "artifact"


def artifacts(release_root: ET.Element):
    """Yield (wrapper_tag, body_element) for every real artifact in a release.

    Mirrors the parser's wrapper-walk exactly (parse.py): an artifact is a
    <process>/<object> wrapper holding exactly one <process> body. A wrapper with
    no body is a <contents> manifest stub and is skipped; a body's own <process>
    child does not exist, so iterating never double-counts it."""
    for w in release_root.iter():
        if _local(w.tag) not in ("process", "object"):
            continue
        body = next((k for k in w if _local(k.tag) == "process"), None)
        if body is None:
            continue                              # manifest stub or a body itself
        yield _local(w.tag), body


def extract(path: Path):
    """Return a list of (filename, wrapper_tag, body_element) for `path`.

    Handles a standalone export too (root IS the body): it is one artifact that
    round-trips to itself, which makes the tool safe to run on anything."""
    root = ET.parse(path).getroot()

    if _local(root.tag) == "process" and \
            not any(_local(k.tag) == "process" for k in root):
        # a standalone .bpobject/.bpprocess - the root is already the body.
        found = [(path.suffix.lstrip(".") == "bpobject" and "object" or "process",
                  root)]
    else:
        found = list(artifacts(root))

    out = []
    used: dict[str, int] = {}
    for tag, body in found:
        ext = "bpobject" if tag == "object" else "bpprocess"
        stem = _safe_name(body.get("name") or f"{tag}")
        n = used.get(stem.lower(), 0) + 1
        used[stem.lower()] = n
        fname = f"{stem}.{ext}" if n == 1 else f"{stem} ({n}).{ext}"
        out.append((fname, tag, body))
    return out


def write_one(body: ET.Element, dest: Path) -> None:
    """Write a body element as a standalone file, keeping Blue Prism's default
    (prefix-free) namespace so the output matches a real single export."""
    ET.register_namespace("", PROC_NS)            # emit xmlns=, not ns0:
    ET.ElementTree(body).write(dest, encoding="utf-8", xml_declaration=True)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("release", help="the .bprelease (or a standalone export)")
    p.add_argument("-o", "--out", default="objects",
                   help="directory to write the artifact files into")
    p.add_argument("--list", action="store_true",
                   help="show what would be written, write nothing")
    args = p.parse_args()

    src = Path(args.release)
    if not src.exists():
        sys.exit(f"{src}: no such file")

    try:
        items = extract(src)
    except ET.ParseError as exc:
        sys.exit(f"{src}: XML parse error: {exc}")   # fail loud, never silent

    if not items:
        # a release with zero artifacts is a broken input, not an empty success.
        sys.exit(f"{src}: no artifacts found - not a Blue Prism release?")

    procs = sum(1 for _, t, _ in items if t == "process")
    objs = len(items) - procs
    print(f"{src.name}: {len(items)} artifact(s) - {procs} process, {objs} object")

    out_dir = Path(args.out)
    if not args.list:
        out_dir.mkdir(parents=True, exist_ok=True)

    for fname, tag, body in items:
        if args.list:
            print(f"  [{tag:7}] {fname}")
        else:
            write_one(body, out_dir / fname)
            print(f"  wrote {out_dir / fname}")

    if not args.list:
        print(f"-> {len(items)} file(s) in {out_dir}/")


if __name__ == "__main__":
    main()
