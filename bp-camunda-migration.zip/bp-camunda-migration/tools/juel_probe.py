#!/usr/bin/env python3
"""Execute every form the BP -> JUEL transpiler produces on a LIVE Camunda 7.

Each case is a Blue Prism expression, the variables it needs, and the value the
engine must end up with. The expression goes through bp_emit._juel (so this
tests the transpiler, not a hand-written JUEL), into one task's outputParameter,
in one process that is deployed and started once. A case that the engine
evaluates differently from Blue Prism is a wrong template, and a template that
is not in this file is not verified.

    python tools/juel_probe.py [--url http://host:8080/engine-rest]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from xml.sax.saxutils import escape

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "port"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bp_emit  # noqa: E402
import c7_runtime_check as c7  # noqa: E402

# (name, BP expression, expected) -- expected None = "any non-null value"
CASES = [
    ("c01", 'Trim([s]) & "!"', "ab!"),
    ("c02", "Len([s])", 4),
    ("c03", "Upper(Left([s], 2))", " A"),
    ("c04", "Mid([t], 2, 3)", "ell"),
    ("c05", "InStr([t], \"l\")", 3),
    ("c06", "InStr([t], \"z\")", 0),
    ("c07", "[n] > 10 AND [t] <> \"x\"", True),
    ("c08", "ToNumber([num]) + 1", 42),
    ("c09", "ToNumber(\"12.5\") * 2", 25.0),
    ("c10", "IsNumber([num])", True),
    ("c11", "IsNumber([t])", False),
    ("c12", "IsNumber(\" 7 \")", True),
    ("c13", "[t] & NewLine() & [t]", "hello\nhello"),
    ("c14", "Len(NewLine())", 1),
    ("c15", "Now()", None),
    ("c16", "Today()", None),
    ("c17", "[Rows.Name]", "B"),
    ("c18", "[Rows.deep.x]", "found"),
    ("c19", "Replace([t], \"l\", \"L\")", "heLLo"),
    ("c20", "Right([t], 2)", "lo"),
]
VARS = {
    "s": {"value": " ab ", "type": "String"},
    "t": {"value": "hello", "type": "String"},
    "n": {"value": 11, "type": "Integer"},
    "num": {"value": "41", "type": "String"},
    "BP#NewLine": {"value": "\n", "type": "String"},   # set by every page's Init task in emitted processes
    "Rows#row": {"value": json.dumps({"Name": "B", "deep": {"x": "found"}}), "type": "Object",
                 "valueInfo": {"serializationDataFormat": "application/json", "objectTypeName": "java.util.HashMap"}},
}


def build() -> tuple[str, list[str]]:
    params, bad = [], []
    for name, expr, _ in CASES:
        ok, res = bp_emit._juel(expr)
        if not ok:
            bad.append(f"{name}: transpiler refused {expr!r}: {res}")
            continue
        params.append(f'<camunda:outputParameter name="{name}">{escape("${" + res + "}")}</camunda:outputParameter>')
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
  xmlns:camunda="http://camunda.org/schema/1.0/bpmn" id="juelprobe" targetNamespace="http://bank.example/bp-migration">
  <bpmn:process id="bp_juel_probe" isExecutable="true" camunda:historyTimeToLive="P1D">
    <bpmn:startEvent id="s"/><bpmn:sequenceFlow id="f1" sourceRef="s" targetRef="t"/>
    <bpmn:task id="t" name="probe"><bpmn:extensionElements><camunda:inputOutput>{"".join(params)}</camunda:inputOutput></bpmn:extensionElements></bpmn:task>
    <bpmn:sequenceFlow id="f2" sourceRef="t" targetRef="e"/><bpmn:endEvent id="e"/>
  </bpmn:process>
</bpmn:definitions>
"""
    return xml, bad


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--url", default="http://localhost:8080/engine-rest")
    a = ap.parse_args(argv)
    code, _ = c7._req(f"{a.url}/engine")
    if code != 200:
        print(f"no engine at {a.url} (HTTP {code})")
        return 2
    xml, bad = build()
    for b in bad:
        print("  REFUSED " + b)
    ok, msg = c7.deploy(a.url, "juel_probe.bpmn", xml)
    print(f"deploy: {'OK' if ok else 'FAIL'} {msg}")
    if not ok:
        return 1
    ok, pid = c7.start(a.url, "bp_juel_probe", VARS)
    if not ok:
        print(f"start FAIL: {pid}")
        return 1
    done = c7.wait_done(a.url, pid)
    if not done or "incident" in (done or {}):
        print(f"FAIL: {done}")
        return 1
    got = c7.variables(a.url, pid)
    fails = list(bad)
    for name, expr, want in CASES:
        if any(b.startswith(name) for b in bad):
            continue
        have = got.get(name)
        if want is None:
            same = have is not None
        elif isinstance(want, (int, float)) and isinstance(have, (int, float)) and not isinstance(want, bool):
            same = float(have) == float(want)
        else:
            same = have == want
        print(f"  {name} {expr:34s} = {have!r:22s} want {want!r:14s} {'OK' if same else 'MISMATCH'}")
        if not same:
            fails.append(name)
    print("JUEL PROBE PASS" if not fails else f"JUEL PROBE FAIL: {', '.join(fails)}")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
