"""Render a verified process specification as a single HTML page.

    python tools/render_spec.py <spec.json> <export-dir-or-file> [-o out.html]

The point of this script is that nobody edits its output. The team's own tracker
records the cost of the alternative - "I had to manually copy the generated text
into the html file. It also require additional prompts to fix the html
structure" - which is what happens when a model is asked for a document instead
of for data. One JSON in, one page out, byte-identical every time.

The page leads with the verification verdict, because a specification that is
merely fluent is the thing this whole pipeline exists to distrust. The verdict
comes from verify_llm_output.py - the same checks, not a re-implementation.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import verify_llm_output as V  # noqa: E402
from _page import SEAL, checks, e, seal, stamp, write  # noqa: E402


def verdict(spec: dict, export: str) -> dict:
    """Run the real checks — the same ones, not a re-implementation."""
    V._oks.clear(); V._warns.clear(); V._fails.clear()
    estate, haystack = V.load_export(export)
    stages = V.check_stageids(spec, estate)
    V.check_stage_ledger(spec, estate, stages)
    V.check_section_ledger(spec)
    V.check_verbatim(spec, haystack)
    V.check_touches(spec, estate)
    V.check_secrets(spec, estate)

    # The ledger fraction is the headline fact, so derive it from the parser's
    # own stage list rather than scraping it out of a message string.
    page = (spec.get("page") or "").strip().lower()
    art = (spec.get("artifact") or "").strip().lower()
    total = sum(
        1 for a, ss in estate.stages_by_artifact.items()
        if a.strip().lower() == art
        for s in ss
        if (s.subsheet or "Main Page").strip().lower() == page and s.id
    )
    accounted = {i for sec in spec.get("sections") or [] for i in sec.get("stageids") or []}
    accounted |= {x.get("stageid") for x in spec.get("excluded") or [] if x.get("stageid")}
    return {
        "passed": not V._fails,
        "oks": list(V._oks), "warns": list(V._warns), "fails": list(V._fails),
        "accounted": len(accounted), "total": total,
    }


# Only what this page owns; palette and shell live in _page.py.
_CSS = """
ol.steps{list-style:none;counter-reset:s;margin:0;padding:0;
  display:flex;flex-direction:column;gap:.55rem}
ol.steps>li{counter-increment:s;display:grid;grid-template-columns:2.15rem 1fr;
  gap:0 .85rem;background:var(--card);border:1px solid var(--rule);
  padding:1rem 1.15rem}
ol.steps>li::before{content:counter(s,decimal-leading-zero);
  font-family:var(--mono);font-variant-numeric:tabular-nums;font-size:.8rem;
  color:var(--seal);padding-top:.15rem}
.steps h3{grid-column:2;margin:0 0 .3rem;font-size:1.06rem;font-weight:600;
  line-height:1.3;text-wrap:balance}
.steps p{grid-column:2;margin:0}
.tags{grid-column:2;margin:.7rem 0 0;display:flex;flex-wrap:wrap;gap:.3rem}
.tag{font-family:var(--mono);font-size:.7rem;border:1px solid var(--rule-firm);
  padding:.1rem .45rem;color:var(--ink-soft);white-space:nowrap}
.tag.cond{border-color:var(--seal);color:var(--seal)}
.tag.unknown{border-color:var(--flag);color:var(--flag)}
@media (max-width:34rem){
  ol.steps>li{grid-template-columns:1fr}
  ol.steps>li::before{grid-column:1;margin-bottom:.3rem}
  .steps h3,.steps p,.tags{grid-column:1}
}
"""


def render(spec: dict, v: dict, source: str) -> str:
    """Body only. The head belongs to _page.write(); a renderer that builds its
    own has twice shipped a page with no stylesheet."""
    o = []
    a = o.append
    passed = v["passed"]
    a('<div class="wrap">')

    a("<header>")
    a('<p class="lbl">Process specification</p>')
    a(f"<h1>{e(spec.get('page') or 'Untitled page')}</h1>")
    a(f'<p class="artifact">{e(spec.get("artifact"))}</p>')
    a("</header>")

    # --- the seal. The ledger fraction is the reason this page exists. ---- #
    if passed:
        verdict_head, why = "Verified complete", (
            "Every stage the parser found on this page is accounted for below. "
            "Nothing was dropped and no stage was invented.")
    else:
        verdict_head, why = "Do not trust this document", (
            "The description does not account for the whole page. Re-run the "
            "extraction on a smaller slice — do not patch it by hand.")
    a(seal(passed, v["accounted"], v["total"], verdict_head, why, v["fails"]))

    if spec.get("purpose"):
        a(f'<p class="lede">{e(spec["purpose"])}</p>')

    a('<dl class="meta">')
    if spec.get("trigger"):
        a(f"<dt>Starts when</dt><dd>{e(spec['trigger'])}</dd>")
    if spec.get("input_scope"):
        a(f"<dt>Scope</dt><dd>{e(spec['input_scope'])}</dd>")
    a("</dl>")

    # --- steps: numbered because the flow genuinely is a sequence -------- #
    sections = spec.get("sections") or []
    if sections:
        a('<h2>What it does</h2><ol class="steps">')
        for s in sections:
            a("<li>")
            a(f"<h3>{e(s.get('title'))}</h3>")
            a(f"<p>{e(s.get('behaviour'))}</p>")
            tags = []
            for c in s.get("conditions") or []:
                tags.append(f'<span class="tag cond">if {e(c)}</span>')
            for t in s.get("touches") or []:
                tags.append(f'<span class="tag">{e(t)}</span>')
            if (s.get("clarity") or "").upper() == "UNKNOWN":
                tags.append('<span class="tag unknown">needs a human</span>')
            n = len(s.get("stageids") or [])
            tags.append(f'<span class="tag">{n} stage{"s" if n != 1 else ""}</span>')
            a(f'<div class="tags">{"".join(tags)}</div>')
            a("</li>")
        a("</ol>")

    if spec.get("error_handling"):
        a(f"<h2>When it fails</h2><p>{e(spec['error_handling'])}</p>")

    oq = spec.get("open_questions") or []
    if oq:
        a('<h2>Confirm before trusting this</h2><ul class="plain">')
        for q in oq:
            a(f"<li>{e(q)}</li>")
        a("</ul>")

    # --- excluded --------------------------------------------------------- #
    ex = spec.get("excluded") or []
    if ex:
        by: dict[str, int] = {}
        for x in ex:
            by[x.get("reason", "?")] = by.get(x.get("reason", "?"), 0) + 1
        labels = {"cosmetic": "Notes, anchors and diagram labels — no behaviour",
                  "declaration": "Data and collection definitions — not a step",
                  "unreachable": "Dead code — nothing reaches these"}
        a("<h2>Accounted for, not described</h2>")
        a('<div class="scroll"><table><thead><tr><th>Reason</th>'
          '<th class="num">Stages</th></tr></thead><tbody>')
        for r, n in sorted(by.items()):
            a(f'<tr><td>{e(labels.get(r, r))}</td><td class="num">{n}</td></tr>')
        a("</tbody></table></div>")

    a('<h2>Checks run</h2><ul class="checks">')
    for m in v["oks"]:
        a(f"<li>{e(m)}</li>")
    for m in v["warns"]:
        a(f'<li class="wa">{e(m)}</li>')
    for m in v["fails"]:
        a(f'<li class="no">{e(m)}</li>')
    a("</ul>")

    a(f"<footer>Generated from <code>{e(Path(source).name)}</code>, {stamp()}."
      "<br>No part of this page was written by hand. Regenerate it; never edit it."
      "</footer>")
    a("</div>")
    return "\n".join(o)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("spec")
    p.add_argument("export")
    p.add_argument("-o", "--out", default=None)
    p.add_argument("--fragment", action="store_true",
                   help="emit only <style> + content, for embedding in another page")
    args = p.parse_args()

    spec = V.load_answer(Path(args.spec))
    v = verdict(spec, args.export)
    out = Path(args.out or Path(args.spec).with_suffix(".html"))
    write(out, f"{spec.get('page')} - process specification",
          SEAL + _CSS, render(spec, v, args.spec), fragment=args.fragment)
    print(f"{'PASS' if v['passed'] else 'FAIL'} {v['accounted']}/{v['total']} -> {out}")
    sys.exit(0 if v["passed"] else 1)


if __name__ == "__main__":
    main()
