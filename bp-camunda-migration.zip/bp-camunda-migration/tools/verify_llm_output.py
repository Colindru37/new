"""Check a model's answer against the export it claims to describe.

This is the cheap half of verification. Every prompt in `prompts/` is written so
that its claims carry a stageid or a verbatim quote, which makes checking them a
string operation rather than a second model pass. The token cost of verification
is what sinks pipelines like this one, so anything checkable here must never be
paid for in tokens.

It answers "did the model invent this, and did it drop anything" - most of the
risk. It cannot answer "is the prose any good"; that stays a human's job.

    python tools/verify_llm_output.py <llm-output.json> <export-dir-or-file>
    python tools/verify_llm_output.py <doc.json> <export> --specs <spec-dir>
    python tools/verify_llm_output.py <cmp.json> <export> --changes changes.json

Exit code 0 = no failures. 1 = at least one FAIL.

`--specs` supplies the verified 04 records a 05 document was written from, and
`--changes` the parser diff a 06 comparison was written from. Both turn a
duplicate check into a real acceptance test, the same way the stage ledger does.

Output is deliberately ASCII: this runs in a Windows console under cp1252,
where a stray em-dash prints as a replacement char and makes a real failure
look like a tool bug.
"""
from __future__ import annotations

import html
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from bp_estate import analyze, detect        # noqa: E402
from bp_estate.cli import _DATA, _collect    # noqa: E402
from bp_estate.config import load_config     # noqa: E402
from bp_estate.model import Estate           # noqa: E402
from bp_estate.parse import parse_paths      # noqa: E402

_fails: list[str] = []
_warns: list[str] = []
_oks: list[str] = []


def fail(msg: str) -> None:
    _fails.append(msg)


def warn(msg: str) -> None:
    _warns.append(msg)


def ok(msg: str) -> None:
    _oks.append(msg)


def _some(items: list[str], n: int = 8) -> str:
    shown = ", ".join(items[:n])
    return shown + (f" ... (+{len(items) - n} more)" if len(items) > n else "")


# --------------------------------------------------------------------------- #
# input
# --------------------------------------------------------------------------- #
def load_answer(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    fence = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    if fence:                      # tolerate the fenced block the prompts ask for
        text = fence.group(1)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        sys.exit(f"FAIL  output is not valid JSON: {exc}")


def load_export(target: str) -> tuple[Estate, str]:
    """Run the real pipeline (parse -> detect -> analyze), not just the parser:
    the edge and dead-code facts the checks below compare against are produced
    by those passes, and an empty Estate would make every check vacuously pass.
    """
    files = _collect([target])
    if not files:
        sys.exit(f"no Blue Prism exports found under {target}")
    estate = Estate()
    parse_paths(files, estate)
    config = load_config(_DATA)
    detect.run(estate, config)
    analyze.run(estate, config)

    source = "\n".join(f.read_text(encoding="utf-8", errors="replace") for f in files)
    return estate, source + "\n" + html.unescape(source)


def walk(node, key: str):
    """Every value stored under `key`, anywhere in the answer."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k == key:
                yield v
            yield from walk(v, key)
    elif isinstance(node, list):
        for item in node:
            yield from walk(item, key)


def flatten(values) -> list[str]:
    out: list[str] = []
    for v in values:
        if isinstance(v, str):
            out.append(v)
        elif isinstance(v, list):
            out.extend(x for x in v if isinstance(x, str))
    return out


# --------------------------------------------------------------------------- #
# checks
# --------------------------------------------------------------------------- #
def check_stageids(answer: dict, estate: Estate,
                   extra_known: set[str] | None = None) -> list:
    # "target" is the 06 comparison's name for the artifact under test - its
    # stageids are the target object's, so that is what they resolve against.
    # "modified" is the older name for the same field, still accepted so that
    # answers written against the previous prompt do not fail on vocabulary.
    artifact = (answer.get("artifact") or answer.get("object_name")
                or answer.get("target") or answer.get("modified"))
    stages = estate.stages_by_artifact.get(artifact or "")
    if stages is None:
        fail(f"artifact {artifact!r} is not in the export "
             f"(known: {', '.join(sorted(estate.stages_by_artifact)) or 'none'})")
        return []

    # A REMOVED stage is legitimately cited by a comparison and legitimately
    # absent from the modified object. Without the diff's own ids here, every
    # deletion a model correctly reported would be scored as a hallucination.
    known = {s.id for s in stages if s.id} | (extra_known or set())
    cited = set(flatten(walk(answer, "stageids"))) | set(flatten(walk(answer, "evidence_stageids")))
    cited |= {v for v in walk(answer, "stageid") if isinstance(v, str)}

    invented = sorted(cited - known)
    if invented:
        fail(f"{len(invented)} invented stageid(s): {_some(invented)}")
    elif cited:
        ok(f"all {len(cited)} cited stageid(s) exist")

    page = answer.get("page")
    if page and cited:
        on_page = {s.id for s in stages if s.subsheet == page}
        if not on_page:
            fail(f"page {page!r} has no stages in the export")
        else:
            strays = sorted((cited & known) - on_page)
            if strays:
                fail(f"{len(strays)} stageid(s) cited but not on page {page!r}: {_some(strays)}")
    return stages


def check_stage_ledger(answer: dict, estate: Estate, stages: list) -> None:
    """The acceptance test for 04-process-spec: every stage accounted for once."""
    if "sections" not in answer or "excluded" not in answer or not stages:
        return
    artifact, page = answer.get("artifact"), answer.get("page")
    truth = [s.id for s in stages if s.subsheet == page and s.id]
    if not truth:
        return

    claimed: list[str] = []
    for sec in answer.get("sections") or []:
        claimed.extend(x for x in (sec.get("stageids") or []) if isinstance(x, str))
    for ex in answer.get("excluded") or []:
        if isinstance(ex.get("stageid"), str):
            claimed.append(ex["stageid"])

    missing = sorted(set(truth) - set(claimed))
    dupes = sorted({x for x in claimed if claimed.count(x) > 1})
    if missing:
        fail(f"LEDGER: {len(missing)}/{len(truth)} stage(s) dropped: {_some(missing)}")
    if dupes:
        fail(f"LEDGER: stage(s) accounted for twice: {_some(dupes)}")
    if not missing and not dupes:
        ok(f"LEDGER balances: all {len(truth)} stage(s) accounted for exactly once")

    # An `excluded` entry the analyzer cannot corroborate is where a model hides
    # what it did not understand, so each exclusion is checked against the
    # parser's own view rather than taken on trust.
    on_page = {s.id: s for s in stages if s.subsheet == page and s.id}
    declarations = {i for i, s in on_page.items() if s.type in ("Data", "Collection")}
    # SubSheetInfo/ProcessInfo are the page and artifact info blocks Blue Prism
    # puts on every diagram - genuinely cosmetic, and present on EVERY page, so
    # omitting them failed every real answer on the first page ever checked.
    cosmetic = {i for i, s in on_page.items()
                if s.type in ("Note", "Anchor", "Block", "SubSheetInfo", "ProcessInfo")}
    dead_names = {d.ref for d in estate.dead_code if d.artifact == artifact and d.kind == "stage"}
    dead = {i for i, s in on_page.items() if s.name in dead_names}

    allowed = {"declaration": declarations, "cosmetic": cosmetic, "unreachable": dead}
    wrong: list[str] = []
    for ex in answer.get("excluded") or []:
        sid, reason = ex.get("stageid"), ex.get("reason")
        if sid not in on_page:
            continue                      # already reported as invented / off-page
        if sid not in allowed.get(reason, set()):
            wrong.append(f"{sid} (claimed {reason!r}, is a {on_page[sid].type} stage)")
    if wrong:
        fail(f"{len(wrong)} stage(s) excluded on a reason the analyzer contradicts - "
             f"this is where dropped logic hides: {_some(wrong, 6)}")
    elif answer.get("excluded"):
        ok(f"all {len(answer['excluded'])} exclusion(s) corroborated by the analyzer")


def load_spec_sections(paths: list[Path]) -> set[str]:
    """Ground truth for 05: every section of every page, as "<page>/<id>".

    Section ids are only unique WITHIN a page - all seven pages of a real
    process open with an "S1" - so an unqualified id cannot be a ledger key.
    """
    truth: set[str] = set()
    for p in paths:
        spec = load_answer(p)
        page = spec.get("page") or "?"
        for sec in spec.get("sections") or []:
            if sec.get("id"):
                truth.add(f"{page}/{sec['id']}")
    return truth


def check_section_ledger(answer: dict, truth: set[str] | None = None) -> None:
    """The acceptance test for 05-step-documentation, one level up.

    Without `truth` this can only catch double-claims. Dropping a section - the
    failure that matters, and the exact one the stage ledger exists to catch a
    level down - is invisible unless the source specs are supplied.
    """
    if "steps" not in answer or "not_documented" not in answer:
        return
    claimed: list[str] = []
    for st in answer.get("steps") or []:
        claimed.extend(x for x in (st.get("spec_sections") or []) if isinstance(x, str))
    claimed.extend(
        nd["spec_section"] for nd in (answer.get("not_documented") or [])
        if isinstance(nd.get("spec_section"), str)
    )
    dupes = sorted({x for x in claimed if claimed.count(x) > 1})
    if dupes:
        fail(f"SECTION LEDGER: section(s) claimed twice: {_some(dupes)}")

    if truth is None:
        if claimed and not dupes:
            warn(f"section ledger: {len(claimed)} section(s), no duplicates, but "
                 "NOT checked for drops - pass the 04 specs with --specs to make "
                 "this an acceptance test")
        return

    got = set(claimed)
    dropped = sorted(truth - got)
    invented = sorted(got - truth)
    if invented:
        fail(f"SECTION LEDGER: {len(invented)} section(s) that are not in any "
             f"spec: {_some(invented)}")
    if dropped:
        fail(f"SECTION LEDGER: {len(dropped)}/{len(truth)} section(s) dropped: "
             f"{_some(dropped)}")
    elif not invented and not dupes:
        ok(f"SECTION LEDGER balances: all {len(truth)} spec section(s) "
           "accounted for exactly once")


def check_verbatim(answer: dict, haystack: str) -> None:
    quoted: list[tuple[str, str]] = []
    for key in ("evidence", "observed", "conditions"):
        quoted.extend((key, v) for v in flatten(walk(answer, key)))
    quoted = [(k, v) for k, v in quoted if v and v.strip()]
    if not quoted:
        return
    bad = [(k, v) for k, v in quoted if v.strip() not in haystack]
    for k, v in bad[:6]:
        fail(f"{k} is not verbatim in the export: {v[:70]!r}")
    if len(bad) > 6:
        fail(f"... and {len(bad) - 6} more non-verbatim quote(s)")
    if not bad:
        ok(f"all {len(quoted)} quoted string(s) appear verbatim in the export")


def check_touches(answer: dict, estate: Estate) -> None:
    """`touches` vs the analyzer's edges - a free second completeness axis, on a
    different dimension from the stage ledger."""
    claimed = {t for t in flatten(walk(answer, "touches")) if ":" in t}
    if not claimed:
        return
    artifact = answer.get("artifact")
    edges = [e for e in estate.edges if e.from_artifact == artifact]
    real = {f"{e.kind}:{e.to}" for e in edges}
    # an object-action edge is "Object.Action"; the prompt asks for "app:Object"
    real |= {f"app:{e.to.split('.')[0]}" for e in edges if e.kind == "object-action"}

    unseen = sorted(claimed - real)
    if unseen:
        warn(f"{len(unseen)} touches entr(y/ies) the analyzer never saw - verify or "
             f"treat as invented: {_some(unseen, 6)}")
    else:
        ok(f"all {len(claimed)} touches entr(y/ies) match the analyzer's edges")

    interesting = {r for r in real if r.split(":")[0] in ("queue", "credential", "lock")}
    missed = sorted(interesting - claimed)
    if missed:
        warn(f"{len(missed)} resource(s) the analyzer found but the answer never "
             f"mentions - possible omission: {_some(missed, 6)}")


def load_change_set(path: Path) -> set[str]:
    """Ground truth for 06: every stageid the parser's diff produced."""
    d = json.loads(path.read_text(encoding="utf-8"))
    ids = {r["stageid"] for k in ("added", "removed", "unclassified")
           for r in d.get(k, [])}
    ids |= {r["stageid"] for r in d.get("changed", [])}
    return ids


def check_change_ledger(answer: dict, truth: set[str] | None) -> None:
    """The acceptance test for 06-objects-comparison.

    Same shape as the stage ledger: the diff is ground truth, and every change
    in it must be accounted for exactly once. A model summarising "and several
    similar changes" is the failure this exists to catch.
    """
    if "changes" not in answer:
        return
    claimed: list[str] = []
    for c in answer.get("changes") or []:
        claimed.extend(x for x in (c.get("stageids") or []) if isinstance(x, str))
    claimed.extend(x for x in (answer.get("behaviour_unchanged") or [])
                   if isinstance(x, str))

    dupes = sorted({x for x in claimed if claimed.count(x) > 1})
    if dupes:
        fail(f"CHANGE LEDGER: stage(s) claimed twice: {_some(dupes)}")

    if truth is None:
        if claimed and not dupes:
            warn(f"change ledger: {len(claimed)} stage(s), no duplicates, but NOT "
                 "checked for drops - pass the diff with --changes to make this "
                 "an acceptance test")
        return

    got = set(claimed)
    invented = sorted(got - truth)
    dropped = sorted(truth - got)
    if invented:
        fail(f"CHANGE LEDGER: {len(invented)} stage(s) not in the diff at all: "
             f"{_some(invented)}")
    if dropped:
        fail(f"CHANGE LEDGER: {len(dropped)}/{len(truth)} change(s) dropped: "
             f"{_some(dropped)}")
    elif not invented and not dupes:
        ok(f"CHANGE LEDGER balances: all {len(truth)} change(s) accounted for "
           "exactly once")


def check_secrets(answer: dict, estate: Estate) -> None:
    blob = json.dumps(answer, ensure_ascii=False)
    leaked = [
        d.name for d in estate.data_items
        if (d.datatype or "").lower() == "password"
        and d.initial_value and d.initial_value in blob
    ]
    if leaked:
        fail(f"a Password data item's value is reproduced in the output: {', '.join(leaked)}")
    else:
        ok("no Password values reproduced")


# --------------------------------------------------------------------------- #
def main() -> None:
    argv = sys.argv[1:]
    specs: list[Path] = []
    changes: Path | None = None
    if "--changes" in argv:
        i = argv.index("--changes")
        changes = Path(argv[i + 1])
        argv = argv[:i] + argv[i + 2:]
    if "--specs" in argv:
        i = argv.index("--specs")
        for raw in argv[i + 1:]:
            p = Path(raw)
            specs.extend(sorted(p.glob("*.json")) if p.is_dir() else [p])
        argv = argv[:i]
    if len(argv) != 2:
        sys.exit(__doc__)

    answer = load_answer(Path(argv[0]))
    estate, haystack = load_export(argv[1])

    change_set = load_change_set(changes) if changes else None
    stages = check_stageids(answer, estate, change_set)
    check_stage_ledger(answer, estate, stages)
    check_section_ledger(answer, load_spec_sections(specs) if specs else None)
    check_change_ledger(answer, change_set)
    check_verbatim(answer, haystack)
    check_touches(answer, estate)
    check_secrets(answer, estate)

    for m in _oks:
        print(f"ok    {m}")
    for m in _warns:
        print(f"WARN  {m}")
    for m in _fails:
        print(f"FAIL  {m}")

    print(f"\n{len(_oks)} passed, {len(_warns)} warning(s), {len(_fails)} failure(s)")
    sys.exit(1 if _fails else 0)


if __name__ == "__main__":
    main()
