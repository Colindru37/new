"""Draw the screens a Blue Prism estate drives, from Application Modeller.

    python tools/render_screens.py <export-dir-or-file> [-o screens.html]

There are no screenshots in a Blue Prism export - no pixels, no images, nothing
to extract. But every spied element carries its real position, size, control
type and window, so the SHAPE of each screen is recoverable exactly. This draws
that: a to-scale wireframe of every window the estate automates.

It is not a photograph and does not pretend to be. For documentation it is
arguably better than one: no live data, no environment-specific noise, nothing
to redact, regenerable, and it diffs when the application changes. Use it where
a document needs to show "this is the screen"; use a real capture only where a
reader must see actual values.

Never renders a value. Password-typed elements are drawn masked, by type.
"""
from __future__ import annotations

import argparse
import html
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from bp_estate.cli import _collect        # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _page import SHELL, e, stamp, write  # noqa: E402


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _attrs(el: ET.Element) -> dict[str, str]:
    out = {}
    for bag in el:
        if _local(bag.tag) != "attributes":
            continue
        for a in bag:
            v = next((c.get("value") for c in a), None)
            if v is not None:
                out[a.get("name", "")] = v
    return out


def _kid_text(el: ET.Element, name: str) -> str:
    for c in el:
        if _local(c.tag) == name:
            return (c.text or "").strip()
    return ""


def _num(v: str | None) -> int | None:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


class Screen:
    def __init__(self, name: str, w: int, h: int, app: str):
        self.name, self.w, self.h, self.app = name, w, h, app
        self.controls: list[tuple[str, str, int, int, int, int]] = []


def collect_screens(paths: list[Path]) -> list[Screen]:
    """One Screen per Window element; its controls are the non-Window
    descendants beneath it, positioned in the window's own coordinates."""
    screens: dict[tuple[str, str], Screen] = {}

    for path in paths:
        root = ET.parse(path).getroot()
        for wrapper in root.iter():
            if _local(wrapper.tag) not in ("process", "object"):
                continue
            body = next((k for k in wrapper if _local(k.tag) == "process"), None)
            if body is None:
                continue
            ad = next((k for k in body if _local(k.tag) == "appdef"), None)
            if ad is None:
                continue
            app = next((c.get("name", "") for c in ad if _local(c.tag) == "element"), "")

            def walk(el: ET.Element, screen: Screen | None) -> None:
                for c in el:
                    if _local(c.tag) != "element":
                        continue
                    ctype = _kid_text(c, "type") or "?"
                    a = _attrs(c)
                    x, y = _num(a.get("X")), _num(a.get("Y"))
                    w, h = _num(a.get("Width")), _num(a.get("Height"))
                    name = c.get("name", "")
                    if ctype == "Window" and w and h:
                        key = (app, name)
                        s = screens.get(key)
                        if s is None:
                            s = Screen(name, w, h, app)
                            screens[key] = s
                        walk(c, s)
                    else:
                        if screen is not None and None not in (x, y, w, h):
                            row = (name, ctype, x, y, w, h)
                            if row not in screen.controls:
                                screen.controls.append(row)
                        walk(c, screen)

            walk(ad, None)

    # A window nobody modelled a control on tells a reader nothing.
    out = [s for s in screens.values() if s.controls]
    out.sort(key=lambda s: (s.app, -len(s.controls), s.name))
    return out


# --------------------------------------------------------------------------- #
# drawing
# --------------------------------------------------------------------------- #
# Control roles, not control classes: a reader cares whether the bot TYPES into
# a thing, PRESSES it, or only READS it.
_ROLE = {
    "Edit": "input", "ComboBox": "input", "Combobox": "input", "ListBox": "input",
    "CheckBox": "input", "RadioButton": "input", "Table": "input", "TabControl": "input",
    "Button": "press", "MenuItem": "press",
    "Password": "secret",
    "Label": "read", "Static": "read", "Text": "read",
}


def _role(ctype: str) -> str:
    return _ROLE.get(ctype, "other")


def _short(name: str) -> str:
    """"Textbox: Staff Number" -> "Staff Number". The prefix is the type, and
    the type is already shown."""
    return name.split(": ", 1)[1] if ": " in name else name


def outside(s: Screen) -> list[str]:
    """Controls whose rectangle does not fit inside the reported window.

    Not a rendering detail — it means those coordinates are not in the window's
    own frame, so their position relative to the window is NOT known. Drawing
    them as if it were would invent a layout.
    """
    return [n for n, _t, x, y, w, h in s.controls
            if x < 0 or y < 0 or x + w > s.w or y + h > s.h]


def svg(s: Screen) -> str:
    pad = 26
    # Canvas is the union of the window and everything drawn, so an overflowing
    # control is visible rather than clipped away.
    span_w = max([s.w] + [x + w for _n, _t, x, _y, w, _h in s.controls])
    span_h = max([s.h] + [y + h for _n, _t, _x, y, _w, h in s.controls])
    W, H = span_w + pad * 2, span_h + pad * 2 + 22
    o = [f'<svg viewBox="0 0 {W} {H}" role="img" '
         f'aria-label="Wireframe of the {e(s.name)} window" '
         f'preserveAspectRatio="xMidYMin meet">']
    o.append(f'<rect class="frame" x="{pad}" y="{pad + 22}" width="{s.w}" '
             f'height="{s.h}" rx="3"/>')
    o.append(f'<rect class="chrome" x="{pad}" y="{pad}" width="{s.w}" height="22"/>')
    o.append(f'<text class="chrome-t" x="{pad + 9}" y="{pad + 15}">{e(s.name)}</text>')
    o.append(f'<text class="dim" x="{pad}" y="{pad - 8}">{s.w} x {s.h} px</text>')

    for name, ctype, x, y, w, h in sorted(s.controls, key=lambda c: (c[3], c[2])):
        gx, gy = pad + x, pad + 22 + y
        r = _role(ctype)
        o.append(f'<rect class="c c-{r}" x="{gx}" y="{gy}" width="{w}" '
                 f'height="{h}" rx="2"/>')
        label = _short(name)
        if r == "secret":
            label += "  (masked)"
        # Only label inside the control when it plausibly fits; otherwise the
        # text spills over neighbouring controls and the drawing becomes a lie.
        if w >= 8 * len(label) * 0.62 and h >= 15:
            o.append(f'<text class="c-t c-t-{r}" x="{gx + 7}" y="{gy + h / 2 + 4}">'
                     f'{e(label)}</text>')
        else:
            o.append(f'<text class="c-t c-t-{r}" x="{gx}" y="{gy - 4}">{e(label)}</text>')
    o.append("</svg>")
    return "\n".join(o)


# Only what this page owns; palette and shell live in _page.py.
_CSS = """
.wrap{max-width:46rem}
figure{margin:0 0 2rem;background:var(--card);border:1px solid var(--rule);
  padding:1rem 1.1rem 1.15rem}
figcaption{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft);
  margin-bottom:.7rem;display:flex;justify-content:space-between;gap:1rem;
  flex-wrap:wrap}
figcaption b{color:var(--ink);font-weight:600;letter-spacing:.02em}
svg{width:100%;height:auto;display:block;overflow:visible}
.frame{fill:none;stroke:var(--rule-firm);stroke-width:1.5}
.chrome{fill:var(--rule);stroke:var(--rule-firm);stroke-width:1.5}
.chrome-t{fill:var(--ink);font:600 12px var(--mono)}
.dim{fill:var(--ink-soft);font:11px var(--mono)}
.c{fill:none;stroke-width:1.5}
.c-input{stroke:var(--input)}
.c-press{stroke:var(--press);fill:var(--press);fill-opacity:.09}
.c-read{stroke:var(--read);stroke-dasharray:4 3}
.c-secret{stroke:var(--secret);stroke-dasharray:2 3}
.c-other{stroke:var(--rule-firm)}
.c-t{font:11px var(--mono)}
.c-t-input{fill:var(--input)} .c-t-press{fill:var(--press)}
.c-t-read{fill:var(--read)} .c-t-secret{fill:var(--secret)}
.c-t-other{fill:var(--ink-soft)}
.key{display:flex;flex-wrap:wrap;gap:.35rem 1.1rem;margin:1.25rem 0 0;
  font-family:var(--mono);font-size:.74rem;color:var(--ink-soft)}
.key i{font-style:normal;display:inline-flex;align-items:center;gap:.4rem}
.key i::before{content:"";width:14px;height:10px;border:1.5px solid currentColor}
.key .k-input{color:var(--input)} .key .k-press{color:var(--press)}
.key .k-read{color:var(--read)} .key .k-secret{color:var(--secret)}
.caveat{font-family:var(--mono);font-size:.72rem;line-height:1.55;
  color:var(--secret);margin:.9rem 0 0;padding-left:.7rem;
  border-left:2px solid var(--secret)}
.caveat b{font-weight:600}
"""


def render(screens: list[Screen], source: str) -> str:
    o = ['<div class="wrap">', "<header>",
         '<p class="lbl">Application Modeller</p>',
         "<h1>Screens driven by the automation</h1>",
         f'<p class="lbl">{len(screens)} window(s) &middot; '
         f'{sum(len(s.controls) for s in screens)} modelled control(s)</p>',
         "</header>"]
    o.append('<p class="lede">Reconstructed from the spied element positions in '
             "the export. These are drawn to scale from real coordinates, but "
             "they are wireframes, not screenshots: the export contains no "
             "images and no live values.</p>")
    o.append('<div class="key">'
             '<i class="k-input">typed into</i>'
             '<i class="k-press">pressed</i>'
             '<i class="k-read">read only</i>'
             '<i class="k-secret">secret, masked</i></div>')

    app = None
    for s in screens:
        if s.app != app:
            app = s.app
            o.append(f"<h2>{e(app)}</h2>")
        off = outside(s)
        o.append("<figure>")
        o.append(f'<figcaption><b>{e(s.name)}</b>'
                 f"<span>{len(s.controls)} control(s)</span></figcaption>")
        o.append(svg(s))
        if off:
            o.append('<p class="caveat">'
                     f"{len(off)} control(s) sit outside this window's reported "
                     f"{s.w}&times;{s.h} bounds, so their coordinates are not in "
                     "the window's own frame. They are drawn at their recorded "
                     "position and the window outline is shown for reference, "
                     "but their placement relative to it is <b>not</b> known: "
                     + ", ".join(e(_short(n)) for n in off) + ".</p>")
        o.append("</figure>")

    o.append(f"<footer>Generated from <code>{e(source)}</code>, {stamp()}."
             "<br>Positions and sizes are the values the developer spied; a "
             "control the developer never spied cannot appear here."
             "</footer></div>")
    return "\n".join(o)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("export")
    p.add_argument("-o", "--out", default="screens.html")
    p.add_argument("--fragment", action="store_true")
    args = p.parse_args()

    paths = _collect([args.export])
    screens = collect_screens(paths)
    if not screens:
        sys.exit("no modelled screens found - no object in this export carries "
                 "spied element geometry")

    out = Path(args.out)
    write(out, "Screens driven by the automation", _CSS,
          render(screens, Path(args.export).name), fragment=args.fragment)
    print(f"{len(screens)} screen(s), "
          f"{sum(len(s.controls) for s in screens)} control(s) -> {out}")


if __name__ == "__main__":
    main()
