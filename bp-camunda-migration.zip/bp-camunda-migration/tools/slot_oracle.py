#!/usr/bin/env python3
"""Run a Blue Prism Code stage's ORIGINAL C# on given inputs -> expected outputs.

The oracle for a script-slot port. The person (or model) porting a Code stage to
JavaScript must not grade their own translation; the original code can, if it
runs. This wraps the stage's C# (plus the object's shared code) in a console
program, compiles it with whatever C# compiler the machine has (csc.exe from
the .NET Framework on any Windows box, mcs on Linux) and runs every case in
cases.json, writing expected.json. slot_check.py then runs the JavaScript
candidate on Camunda with the same cases and compares.

    python tools/slot_oracle.py <export(s)> --stage "Square" [--object Calc]
           --cases cases.json -o work/square

cases.json: [{"X": 6}, {"X": -2}, ...]        (BP parameter names, JSON values)
expected.json: [{"Y": 36}, {"Y": 4}, ...]     (the stage's outputs per case)

Types follow the stage's declared parameter types: text->string, number->decimal,
flag->bool, date/datetime/time->DateTime, timespan->TimeSpan, password->string.
A collection parameter is not supported by this harness (v1): the tool refuses
the stage and says so -- port those with a worker, not a slot.
Stdlib only. The compiler is the only thing outside Python.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

CS_TYPE = {"text": "string", "number": "decimal", "flag": "bool", "date": "DateTime",
           "datetime": "DateTime", "time": "DateTime", "timespan": "TimeSpan",
           "password": "string", "binary": "byte[]"}


def _loc(t):
    return t.split("}")[-1]


def find_stage(paths, stage_name, object_name=None):
    """-> (artifact name, language, shared code, references, imports, stage element)"""
    hits = []
    for p in paths:
        for f in ([p] if p.is_file() else sorted(p.rglob("*"))):
            if f.suffix.lower() not in (".xml", ".bpobject", ".bpprocess", ".bprelease"):
                continue
            try:
                root = ET.parse(f).getroot()
            except ET.ParseError:
                continue
            for art in root.iter():
                if _loc(art.tag) not in ("process", "object") or not art.get("name"):
                    continue
                if object_name and art.get("name") != object_name:
                    continue
                pi = next((s for s in art if _loc(s.tag) == "stage" and s.get("type") == "ProcessInfo"), None)
                for st in art:
                    if _loc(st.tag) == "stage" and st.get("type") == "Code" and st.get("name") == stage_name:
                        hits.append((art.get("name"), pi, st))
    if not hits:
        sys.exit(f"no Code stage named {stage_name!r}" + (f" in object {object_name!r}" if object_name else ""))
    if len(hits) > 1:
        sys.exit("ambiguous: " + ", ".join(f"{a}/{s.get('name')}" for a, _, s in hits) + " -- pass --object")
    return hits[0]


def params(st, tag):
    out = []
    holder = st.find(tag)
    if holder is not None:
        for p in holder:
            if _loc(p.tag) in ("input", "output") and p.get("name"):
                out.append((p.get("name"), (p.get("type") or "text").lower()))
    return out


def cs_ident(name: str) -> str:
    """Blue Prism exposes a parameter to Code as its name with non-identifier
    characters replaced by '_' -- the same rule the stage's code was written against."""
    s = "".join(c if c.isalnum() or c == "_" else "_" for c in name)
    return ("_" + s) if s[:1].isdigit() else s


def harness(lang, shared, refs_imports, code, ins, outs) -> str:
    imports = {"System", "System.Collections.Generic", "System.Globalization", "System.IO",
               "System.Linq", "System.Text", "System.Web.Script.Serialization"} | set(refs_imports)
    decl = []
    for n, t in ins + outs:
        decl.append(f"        {CS_TYPE[t]} {cs_ident(n)} = default({CS_TYPE[t]});")
    read = []
    for n, t in ins:
        v = f"c[{json.dumps(n)}]"
        conv = {"string": f"Convert.ToString({v}, CultureInfo.InvariantCulture)",
                "decimal": f"Convert.ToDecimal({v}, CultureInfo.InvariantCulture)",
                "bool": f"Convert.ToBoolean({v}, CultureInfo.InvariantCulture)",
                "DateTime": f"DateTime.Parse(Convert.ToString({v}), CultureInfo.InvariantCulture)",
                "TimeSpan": f"TimeSpan.Parse(Convert.ToString({v}), CultureInfo.InvariantCulture)",
                "byte[]": f"Convert.FromBase64String(Convert.ToString({v}))"}[CS_TYPE[t]]
        read.append(f"            if (c.ContainsKey({json.dumps(n)}) && c[{json.dumps(n)}] != null) {cs_ident(n)} = {conv};")
    write = []
    for n, t in outs:
        val = cs_ident(n)
        if CS_TYPE[t] == "DateTime":
            val = f'{val}.ToString("o", CultureInfo.InvariantCulture)'
        elif CS_TYPE[t] == "TimeSpan":
            val = f"{val}.ToString()"
        elif CS_TYPE[t] == "byte[]":
            val = f"Convert.ToBase64String({val})"
        write.append(f"            r[{json.dumps(n)}] = {val};")
    body = "\n".join("        " + line for line in code.splitlines())
    return "\n".join([
        *[f"using {i};" for i in sorted(imports)],
        "",
        "// ---- shared code of the object (Code Options) ----",
        shared or "",
        "",
        "public static class BpStage",
        "{",
        "    public static Dictionary<string, object> Run(Dictionary<string, object> c)",
        "    {",
        *decl,
        *read,
        "        // ---- the Code stage, verbatim ----",
        body,
        "        // ---- end of stage ----",
        "        var r = new Dictionary<string, object>();",
        *write,
        "        return r;",
        "    }",
        "}",
        "",
        "public static class Program",
        "{",
        "    public static int Main(string[] args)",
        "    {",
        "        var ser = new JavaScriptSerializer();",
        "        var cases = ser.Deserialize<List<Dictionary<string, object>>>(File.ReadAllText(args[0]));",
        "        var results = new List<Dictionary<string, object>>();",
        "        foreach (var c in cases)",
        "        {",
        "            try { results.Add(BpStage.Run(c)); }",
        "            catch (Exception ex) { results.Add(new Dictionary<string, object> { { \"__exception\", ex.GetType().Name + \": \" + ex.Message } }); }",
        "        }",
        "        File.WriteAllText(args[1], ser.Serialize(results));",
        "        return 0;",
        "    }",
        "}",
        "",
    ])


def find_compiler(explicit=None):
    if explicit:
        return explicit
    windir = os.environ.get("WINDIR", r"C:\Windows")
    for fw in ("Framework64", "Framework"):
        p = Path(windir) / "Microsoft.NET" / fw / "v4.0.30319" / "csc.exe"
        if p.exists():
            return str(p)
    return shutil.which("csc") or shutil.which("mcs")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("inputs", nargs="+", help="export files or directories")
    ap.add_argument("--stage", required=True, help="the Code stage's name")
    ap.add_argument("--object", help="the object/process that holds it (when the name is not unique)")
    ap.add_argument("--cases", required=True, help="cases.json: a list of {param: value}")
    ap.add_argument("-o", "--out", required=True, help="work directory (Program.cs, the exe, expected.json)")
    ap.add_argument("--csc", help="compiler path (default: Framework csc.exe, else csc/mcs on PATH)")
    ap.add_argument("--no-run", action="store_true", help="only write Program.cs")
    a = ap.parse_args(argv)

    art, pi, st = find_stage([Path(p) for p in a.inputs], a.stage, a.object)
    ins, outs = params(st, "inputs"), params(st, "outputs")
    bad = [n for n, t in ins + outs if t not in CS_TYPE]
    if bad:
        print(f"REFUSED: parameter(s) of a type this harness cannot carry: {', '.join(bad)} "
              f"(collection/image). Port this stage as a worker, not a slot.")
        return 2
    code = st.findtext("code") or ""
    shared = ((pi.findtext("globalcode") or "") + "\n" + (pi.findtext("code") or "")) if pi is not None else ""
    lang = (pi.findtext("language") if pi is not None else None) or "csharp"
    if lang.lower() not in ("csharp", "c#"):
        print(f"REFUSED: stage language is {lang}; this harness compiles C# only.")
        return 2
    imports = [x.text for x in pi.iter("import") if x.text] if pi is not None else []
    refs = [x.text for x in pi.iter("reference") if x.text] if pi is not None else []

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    src = out / "Program.cs"
    src.write_text(harness(lang, shared, imports, code, ins, outs), encoding="utf-8")
    print(f"wrote {src}  (stage {art}/{a.stage}: {len(ins)} in, {len(outs)} out)")
    if a.no_run:
        return 0
    cc = find_compiler(a.csc)
    if not cc:
        print("no C# compiler found: pass --csc <path to csc.exe>, e.g. "
              r"C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe")
        return 3
    exe = out / "oracle.exe"
    refargs = [f"-r:{r}" for r in refs if r.lower() not in ("system.dll", "mscorlib.dll")]
    if not any("System.Web.Extensions" in r for r in refs):
        refargs.append("-r:System.Web.Extensions.dll")
    cmd = [cc, "-nologo", "-optimize-", f"-out:{exe}", *refargs, str(src)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("COMPILE FAILED (the ORIGINAL code + harness):")
        print(r.stdout + r.stderr)
        return 4
    expected = out / "expected.json"
    run = [str(exe)] if os.name == "nt" else ["mono", str(exe)]
    r = subprocess.run(run + [str(Path(a.cases).resolve()), str(expected)], capture_output=True, text=True)
    if r.returncode != 0:
        print("RUN FAILED:", r.stdout + r.stderr)
        return 5
    res = json.loads(expected.read_text(encoding="utf-8"))
    for i, row in enumerate(res):
        print(f"  case {i}: {json.dumps(row)}")
    print(f"wrote {expected}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
