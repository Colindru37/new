#!/usr/bin/env python3
"""extract_code.py -- pull every embedded code stage out of an export, as files.

Blue Prism hides real logic inside Code stages (C#/VB): OAuth, token refresh,
JWT parsing, HTTP calls. The BPMN emitter can only mark those "[BLOCKER code]",
and until now the SOURCE was simply discarded -- yet it is sitting in the export
and it is exactly what a port needs to read.

This writes one file per code stage plus a manifest, so nothing is lost and the
size of the real work is visible.

    python extract_code.py <export> [-o code_out] [--tier rehost|all]

--tier rehost (default) skips SHIPPED Blue Prism VBOs (Excel, file, collection,
string utilities). Their C# does what a connector or the standard library
already does, so porting it is waste -- only CUSTOM code is real work.

Output:
    <out>/<object>/<page>__<stage>.cs        the source, verbatim
    <out>/MANIFEST.txt                       what is where, and how big

Stdlib + bp_core (+ bp_emit for the tier heuristic).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

import bp_core
from bp_core import _kid, _kids, _kid_text, _local
from bp_emit import _vbo_tier
# object_triage owns the forgiving parse (Blue Prism writes ILLEGAL character
# references into real exports; a plain ET.parse dies on them). bp_core handles
# them inside parse_file, so there is no reusable helper there -- reuse this one
# rather than duplicating the rule in a third place.
from object_triage import _parse_forgiving


def _safe(name: str) -> str:
    """A filesystem-safe fragment. Never invent: just neutralise separators."""
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", (name or "unnamed")).strip() or "unnamed"


def _ext(lang: str) -> str:
    l = (lang or "").lower()
    if "vb" in l:
        return ".vb"
    if "j" in l and "script" in l:
        return ".js"
    return ".cs"


def extract(export: str, out_dir: str, tier_filter: str) -> dict:
    root, scrubbed = _parse_forgiving(Path(export))
    if scrubbed:
        print(f"NOTE: {Path(export).name}: stripped {scrubbed} illegal character "
              f"reference(s) to parse", file=sys.stderr)

    bodies = []
    if _local(root.tag) == "process" and _kid(root, "process") is None:
        bodies.append((root.get("name") or Path(export).stem, root))
    else:
        for wrapper in root.iter():
            if _local(wrapper.tag) not in ("process", "object"):
                continue
            body = _kid(wrapper, "process")
            if body is None:
                continue
            bodies.append((body.get("name") or wrapper.get("name") or "unnamed", body))

    out = Path(out_dir)
    rows, total_loc, skipped, envs = [], 0, 0, []
    for art_name, body in bodies:
        if tier_filter == "rehost" and _vbo_tier(art_name) != "rehost":
            skipped += 1
            continue
        # The CODE ENVIRONMENT lives on the ProcessInfo stage: which .NET
        # language, which assemblies are referenced, which namespaces imported,
        # and <globalcode> -- the class-level code SHARED by every code stage.
        # A big integration class (an HTTP/OAuth client) lives there, not in a
        # Code stage, so extracting only <code> would miss the important half.
        for st in _kids(body, "stage"):
            if st.get("type") != "ProcessInfo":
                continue
            lang_o = _kid_text(st, "language") or "unknown"
            refs = [t.text for t in _kids(_kid(st, "references") or ET.Element("x"), "reference") if t.text]
            imps = [t.text for t in _kids(_kid(st, "imports") or ET.Element("x"), "import") if t.text]
            gc_el = _kid(st, "globalcode")
            gc = (gc_el.text or "") if gc_el is not None else ""
            gloc = sum(1 for ln in gc.splitlines() if ln.strip())
            if gloc:
                d = out / _safe(art_name)
                d.mkdir(parents=True, exist_ok=True)
                fn = f"_GLOBALCODE{_ext(lang_o)}"
                (d / fn).write_text(gc, encoding="utf-8")
                rows.append((art_name, "(shared)", "GLOBAL CODE", lang_o, gloc,
                             f"{_safe(art_name)}/{fn}"))
                total_loc += gloc
            envs.append((art_name, lang_o, refs, imps, gloc))
            break
        # page id -> name, so a file lands under a human-readable page
        pages = {}
        for ss in _kids(body, "subsheet"):
            pages[ss.get("subsheetid") or ""] = _kid_text(ss, "name") or "page"
        for st in _kids(body, "stage"):
            if st.get("type") != "Code":
                continue
            code_el = _kid(st, "code")
            src = (code_el.text or "") if code_el is not None else ""
            if not src.strip():
                continue
            lang = (code_el.get("language") if code_el is not None else "") or "unknown"
            page = pages.get(_kid_text(st, "subsheetid") or "", "Main Page")
            stage = st.get("name") or st.get("stageid") or "stage"
            loc = sum(1 for ln in src.splitlines() if ln.strip())
            total_loc += loc
            d = out / _safe(art_name)
            d.mkdir(parents=True, exist_ok=True)
            fn = f"{_safe(page)}__{_safe(stage)}{_ext(lang)}"
            (d / fn).write_text(src, encoding="utf-8")
            rows.append((art_name, page, stage, lang, loc, f"{_safe(art_name)}/{fn}"))

    rows.sort(key=lambda r: (-r[4], r[0].lower()))
    man = [
        "EMBEDDED CODE EXTRACTED FROM " + Path(export).name,
        f"tier filter: {tier_filter}   (shipped VBOs skipped: {skipped})",
        "",
        "This is the logic BPMN cannot carry across. Each file is verbatim source.",
        f"TOTAL: {len(rows)} code stage(s), {total_loc} lines",
        "",
        f"{'lines':>6}  {'object':38} {'page':22} {'stage':26} file",
        "-" * 120,
    ]
    for art, page, stage, lang, loc, rel in rows:
        man.append(f"{loc:>6}  {art[:36]:38} {page[:20]:22} {stage[:24]:26} {rel}")
    if envs:
        man += ["", "", "CODE ENVIRONMENT (what a port must target)",
                "=" * 60, ""]
        for art, lang, refs, imps, gloc in sorted(envs):
            man.append(art)
            man.append("  language   : " + lang)
            man.append("  global code: %d lines" % gloc)
            man.append("  references : " + (", ".join(refs) or "-"))
            man.append("  imports    : " + (", ".join(imps) or "-"))
            man.append("")
        man += ["NOTE: the export does NOT record a .NET runtime version -- that is a",
                "property of the Blue Prism install, not the file. The language,",
                "references and imports above are what a port actually has to match."]
    out.mkdir(parents=True, exist_ok=True)
    (out / "MANIFEST.txt").write_text("\n".join(man) + "\n", encoding="utf-8")
    return {"files": len(rows), "loc": total_loc, "skipped_objects": skipped}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="extract_code")
    ap.add_argument("export", help="a .bprelease / .bpobject / .bpprocess")
    ap.add_argument("-o", "--out", default="code_out", help="output folder")
    ap.add_argument("--tier", choices=("rehost", "all"), default="rehost",
                    help="rehost = custom objects only (default); all = include shipped VBOs")
    a = ap.parse_args(argv)
    r = extract(a.export, a.out, a.tier)
    print(f"{r['files']} code stage(s), {r['loc']} lines -> {a.out}"
          f"   (skipped {r['skipped_objects']} shipped VBO object(s))", file=sys.stderr)
    print(f"manifest: {Path(a.out) / 'MANIFEST.txt'}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
