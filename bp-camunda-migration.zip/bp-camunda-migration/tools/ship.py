#!/usr/bin/env python3
"""Build the public-GitHub zip that carries this repo to the air-gapped laptop.

    python tools/ship.py                # -> release/bp-camunda-migration.zip

What goes in: every git-TRACKED file (so never exports, scratch, photos, venvs),
minus EXCLUDE_DIRS. Text files are scrubbed with release/scrub.json (an untracked
local file: {"house name": "__Hn__"}), so no internal name leaves the building;
RESTORE.md inside the zip lists only the placeholders and where they occur, and
the key (placeholder -> real name) is written to release/RESTORE-KEY.md, which
stays HERE. On the laptop: unzip, `python selftest.py` (hash manifest of every
shipped file + the five --selftests), then put the names back per RESTORE.md.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / "release"
STAGE = RELEASE / "bp-camunda-migration"
EXCLUDE_DIRS = ("docker/", "gallery/", "convo/", "exports/", "rules/", "rule/")
TEXT_EXT = {".py", ".md", ".txt", ".json", ".yaml", ".yml", ".html", ".css", ".js", ".bpmn", ".bpprocess",
            ".bpobject", ".xml", ".toml", ".cfg", ".ini", ".gitignore", ".gitattributes", ".csv", ".sql", ".ps1", ".bat"}
SELFTESTS = [("port", "bp_core.py"), ("port", "bp_full.py"), ("port", "bp_emit.py"), ("port", "bp_equiv.py"),
             ("tools", "bpmn_lint.py")]


def tracked() -> list[str]:
    out = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode("utf-8")
    return [p for p in out.split("\0") if p and not p.startswith(EXCLUDE_DIRS)]


def main() -> int:
    key_path = RELEASE / "scrub.json"
    scrub: dict[str, str] = json.loads(key_path.read_text(encoding="utf-8")) if key_path.exists() else {}
    # longest names first, so a longer name that contains a shorter one is replaced first
    terms = sorted(scrub.items(), key=lambda kv: -len(kv[0]))
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)
    hits: dict[str, set[str]] = {}
    manifest: dict[str, str] = {}
    for rel in tracked():
        src = ROOT / rel
        dst = STAGE / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        data = src.read_bytes()
        if src.suffix.lower() in TEXT_EXT or src.name in (".gitignore", ".gitattributes"):
            text = data.decode("utf-8", "surrogateescape")
            for name, ph in terms:
                if name in text:
                    hits.setdefault(ph, set()).add(rel)
                    text = text.replace(name, ph)
            data = text.encode("utf-8", "surrogateescape")
        dst.write_bytes(data)
        manifest[rel] = hashlib.sha256(data).hexdigest()
    # leak check: no scrub term may survive anywhere in the staged tree
    leaks = []
    for rel in manifest:
        if (STAGE / rel).suffix.lower() in TEXT_EXT:
            t = (STAGE / rel).read_text(encoding="utf-8", errors="replace")
            leaks += [f"{rel}: {name}" for name, _ in terms if name in t]
    if leaks:
        print("LEAK, not shipping:\n  " + "\n  ".join(leaks))
        return 1

    restore = ["# RESTORE", "", "Internal names were replaced before this zip was built. Put them back",
               "with the key you have on your side (RESTORE-KEY.md was NOT shipped):", ""]
    for ph in sorted(hits):
        restore.append(f"- `{ph}` occurs in: " + ", ".join(sorted(hits[ph])))
    restore += ["", "Then: `python selftest.py` must still print MANIFEST OK (the manifest was taken",
                "BEFORE restoring, so re-run it before you restore, not after) and the five",
                "SELFTEST PASS lines."]
    (STAGE / "RESTORE.md").write_text("\n".join(restore) + "\n", encoding="utf-8")
    (RELEASE / "RESTORE-KEY.md").write_text(
        "# RESTORE-KEY (local only, never shipped)\n\n" + "\n".join(f"- `{ph}` = {name}" for name, ph in terms) + "\n",
        encoding="utf-8")

    selftest = f'''#!/usr/bin/env python3
"""Prove this extracted copy is the one that was tested: every shipped file's hash,
then the five self-tests. Run from the folder this file is in."""
import hashlib, json, subprocess, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
MANIFEST = json.loads({json.dumps(json.dumps(manifest, sort_keys=True))})
SELFTESTS = {SELFTESTS!r}
bad = [rel for rel, h in MANIFEST.items()
       if not (HERE / rel).exists() or hashlib.sha256((HERE / rel).read_bytes()).hexdigest() != h]
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad[:10]))
rc = 1 if bad else 0
for d, f in SELFTESTS:
    r = subprocess.run([sys.executable, f, "--selftest"], cwd=HERE / d, capture_output=True, text=True)
    last = (r.stdout.strip().splitlines() or ["(no output)"])[-1]
    print("%-14s %s" % (f, last))
    rc |= 0 if "SELFTEST PASS" in r.stdout else 1
sys.exit(rc)
'''
    (STAGE / "selftest.py").write_text(selftest, encoding="utf-8")
    zip_base = RELEASE / "bp-camunda-migration"
    if zip_base.with_suffix(".zip").exists():
        zip_base.with_suffix(".zip").unlink()
    shutil.make_archive(str(zip_base), "zip", RELEASE, STAGE.name)
    z = zip_base.with_suffix(".zip")
    print(f"{z} ({z.stat().st_size // 1024} KB, {len(manifest)} files, {len(hits)} placeholders) "
          f"sha256 {hashlib.sha256(z.read_bytes()).hexdigest()[:16]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
