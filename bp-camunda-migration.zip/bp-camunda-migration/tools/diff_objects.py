"""Diff two versions of a Blue Prism artifact. Deterministic, no model.

    python tools/diff_objects.py <base.bpobject> <target.bpobject> [-o outdir]

Base is the good version, target is the one it will overwrite (BP Comparison
Rules 21 and 24). Every severity depends on that direction, so it is the one
thing to get right at the command line.

This is the half of `prompts/06-objects-comparison.md` that must never be asked
of a language model. "What changed between these two files" has an exact answer,
and a model asked for it will paraphrase, merge, miss things, and — on a large
object — sample a few pages and extrapolate the rest. The model's job is to
explain the change set; producing it is a diff's job.

Emits `changes.txt` (the ledger you paste into the prompt) and `changes.json`.

## Two things this is careful about

**Layout is not change.** `<displayx>`, fonts and `<view>` are cosmetic; a stage
dragged across the canvas must not show up as a modified stage, or a real change
drowns in noise.

**Nothing is allowed to be silently equal.** Every stage is also hashed over its
whole normalised subtree. If the hash differs but no field this tool understands
differs, that is reported as `unclassified` rather than dropped — an unknown
change is a finding, not an absence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

# Cosmetic: never a behaviour change. Kept out of both the field comparison and
# the subtree hash.
_COSMETIC = {"displayx", "displayy", "displaywidth", "displayheight", "font",
             "view", "display", "camera", "zoom"}

_LINK_TAGS = ("onsuccess", "ontrue", "onfalse")


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _kids(el: ET.Element, name: str) -> list[ET.Element]:
    return [k for k in el if _local(k.tag) == name]


def _text(el: ET.Element | None, name: str) -> str | None:
    if el is None:
        return None
    for k in el:
        if _local(k.tag) == name:
            return (k.text or "").strip()
    return None


def _canon(el: ET.Element) -> str:
    """Order-independent, layout-free rendering of a subtree, for hashing."""
    if _local(el.tag) in _COSMETIC:
        return ""
    attrs = "".join(f"{k}={v}" for k, v in sorted(el.attrib.items())
                    if k not in ("x", "y", "w", "h"))
    body = "".join(sorted(_canon(c) for c in el))
    return f"<{_local(el.tag)} {attrs}>{(el.text or '').strip()}{body}</>"


def _hash(el: ET.Element) -> str:
    return hashlib.sha256(_canon(el).encode("utf-8")).hexdigest()[:16]


class Art:
    """One artifact's stages, keyed by stageid, with page names resolved."""

    def __init__(self, path: Path):
        root = ET.parse(path).getroot()
        bodies = []
        if _local(root.tag) == "process" and not _kids(root, "process"):
            bodies = [(root.get("name") or path.stem, root)]
        else:
            for w in root.iter():
                if _local(w.tag) not in ("process", "object"):
                    continue
                b = _kids(w, "process")
                if b:
                    bodies.append((w.get("name") or b[0].get("name") or path.stem, b[0]))
        if not bodies:
            sys.exit(f"{path}: no artifact found")
        if len(bodies) > 1:
            sys.exit(f"{path}: contains {len(bodies)} artifacts; diff one at a "
                     "time (split the release first)")

        self.name, body = bodies[0]
        self.pages = {s.get("subsheetid"): (_text(s, "name") or "?")
                      for s in _kids(body, "subsheet")}
        # Rules 12, 26 and 27 all turn on whether a page is published: an
        # unpublished page is internal, so a change to it cannot break a caller.
        self.sheets: dict[str, dict] = {
            s.get("subsheetid"): {
                "name": _text(s, "name") or "?",
                "type": s.get("type") or "Normal",
                "published": (s.get("published") or "").lower() == "true",
            } for s in _kids(body, "subsheet")
        }
        self.stages: dict[str, dict] = {}
        for st in _kids(body, "stage"):
            sid = st.get("stageid")
            if not sid:
                continue
            self.stages[sid] = self._facts(st)

    def _facts(self, st: ET.Element) -> dict:
        stype = st.get("type") or "?"
        res = _kids(st, "resource")
        dec = _kids(st, "decision") or _kids(st, "calculation")
        code = _text(st, "code")
        f = {
            "name": st.get("name") or "",
            "type": stype,
            "page": self.pages.get(_text(st, "subsheetid") or "", "Main Page"),
            # A page's NAME is a label, not an identity. Comparing on it turns
            # one page rename into "moved to a different page" against every
            # stage sitting on it - 27 phantom findings in the first real run of
            # this tool. The id is what says a stage actually moved.
            "sheet_id": _text(st, "subsheetid") or "",
            "narrative": _text(st, "narrative") or "",
            "calls": (f"{res[0].get('object')}.{res[0].get('action')}"
                      if res else None),
            "expression": (dec[0].get("expression") if dec else None)
                          or _text(st, "expression"),
            "datatype": _text(st, "datatype"),
            "inputs": {i.get("name"): i.get("expr")
                       for e in _kids(st, "inputs") for i in e},
            "outputs": {o.get("name"): o.get("stage")
                        for e in _kids(st, "outputs") for o in e},
            # Rule 3 wants the argument TYPE compared, not just its value, and
            # rule 17 makes a changed output signature critical. Value and
            # signature are therefore separate facts: re-pointing an input is a
            # behaviour change, but renaming or retyping one breaks every caller.
            "signature": [f"{_local(e.tag)}:{a.get('type')}:{a.get('name')}"
                          for e in st for a in e
                          if _local(e.tag) in ("inputs", "outputs")],
            # Rules 5 and 6: a Code stage that loses a .dll or an Imports line
            # stops compiling, and nothing in the stage body shows it.
            "references": sorted((r.text or "").strip()
                                 for e in _kids(st, "references") for r in e),
            "imports": sorted((i.text or "").strip()
                              for e in _kids(st, "imports") for i in e),
            "links": sorted(
                (k.text or "").strip()
                for tag in _LINK_TAGS for k in _kids(st, tag) if (k.text or "").strip()
            ),
            "code": None if code is None else hashlib.sha256(
                code.encode("utf-8")).hexdigest()[:16],
            "hash": _hash(st),
        }
        # A Password stage's initial value is never read, only its presence.
        iv = _text(st, "initialvalue")
        if (f["datatype"] or "").lower() == "password":
            f["initial_value"] = "<secret present>" if iv else None
        else:
            f["initial_value"] = iv
        return f


# `page` is deliberately absent: it is a display name, and comparing it reports
# a page rename once per stage on the page. `sheet_id` is the real test.
_FIELDS = ("name", "type", "sheet_id", "narrative", "calls", "expression",
           "datatype", "initial_value", "inputs", "outputs", "links", "code",
           "signature", "references", "imports")

_LABEL = {
    "calls": "calls a different object/action",
    "expression": "decision or calculation expression",
    "inputs": "input values passed in",
    "outputs": "where results are stored",
    "links": "flow — what it goes to next",
    "code": "the code inside it",
    "sheet_id": "moved to a different page",
    "narrative": "developer's comment",
    "initial_value": "starting value",
    "signature": "the action's own arguments (name or type)",
    "references": "assembly references (.dll)",
    "imports": "namespace imports",
}

# --------------------------------------------------------------------------- #
# Severity, per BP Comparison Rules.
#
# The direction matters and is fixed by rules 21 and 24: BASE is the good
# version, TARGET is the file that will be overwritten by it. Every severity
# below is the answer to one question - "if we overwrite target with base, what
# breaks?" - which is why an extra page in TARGET is worse than a missing one
# (rules 8 and 9): the missing one is about to be restored, the extra one is
# about to be destroyed along with every caller that used it.
# --------------------------------------------------------------------------- #
CRITICAL, IMPACTFUL, MINOR = "critical", "impactful", "minor"
_RANK = {CRITICAL: 0, IMPACTFUL: 1, MINOR: 2}

# Rule 3 + rule 17: an argument's name or type is the action's contract with
# every process that calls it. Changing it is the one thing that breaks callers
# silently, so it outranks changing what the stage actually does.
_CRITICAL_FIELDS = {"signature"}
# Behaviour, and the two ways a Code stage stops compiling (rules 4, 5, 6).
_IMPACTFUL_FIELDS = {"code", "expression", "calls", "links", "inputs",
                     "outputs", "datatype", "initial_value", "references",
                     "imports"}
# Rule 7 names the renamed-stage case explicitly as "not a critical one".
_MINOR_FIELDS = {"name", "narrative", "sheet_id", "type"}


def _worst(sevs: list[str]) -> str:
    return min(sevs, key=lambda s: _RANK[s]) if sevs else MINOR


def _field_severity(fields: list[str]) -> str:
    out = []
    for f in fields:
        if f in _CRITICAL_FIELDS:
            out.append(CRITICAL)
        elif f in _IMPACTFUL_FIELDS:
            out.append(IMPACTFUL)
        else:
            out.append(MINOR)
    return _worst(out)


def compare_sheets(base: Art, target: Art) -> list[dict]:
    """Page-level findings: rules 2, 8, 9, 12, 20 and 27.

    Rules 12 and 20 contradict each other on one case. Rule 20 says two
    subsheets sharing an id with different names are impactful, full stop; rule
    12 says the same thing but downgrades it to minor when BOTH versions are
    unpublished. The more specific rule wins here, and the disagreement is
    reported on the finding rather than resolved silently - a rule conflict is
    the author's to settle, not this tool's.
    """
    out: list[dict] = []

    for sid in sorted(set(base.sheets) - set(target.sheets)):
        s = base.sheets[sid]
        # Rule 8: present in base, absent from target. Overwriting target with
        # base restores it, so nothing that exists today breaks.
        out.append({"kind": "page_only_in_base", "page": s["name"],
                    "severity": MINOR, "rule": "8",
                    "detail": "in the base version but not the target; "
                              "overwriting restores it, so nothing breaks"})

    for sid in sorted(set(target.sheets) - set(base.sheets)):
        s = target.sheets[sid]
        # Rule 9: only in target. Overwriting destroys it and every caller.
        out.append({"kind": "page_only_in_target", "page": s["name"],
                    "severity": IMPACTFUL, "rule": "9",
                    "detail": "exists only in the target; overwriting with the "
                              "base version deletes it and breaks every process "
                              "or object that calls it"})

    for sid in sorted(set(base.sheets) & set(target.sheets)):
        b, t = base.sheets[sid], target.sheets[sid]
        if b["name"] != t["name"]:
            # Rule 12 over rule 20 - see the docstring.
            both_unpublished = not b["published"] and not t["published"]
            f = {"kind": "page_renamed", "page": t["name"],
                 "severity": MINOR if both_unpublished else IMPACTFUL,
                 "rule": "12", "before": b["name"], "after": t["name"],
                 "detail": f"same subsheet id, renamed {b['name']!r} -> "
                           f"{t['name']!r}"}
            if both_unpublished:
                f["rule_conflict"] = ("rule 20 calls this impactful "
                                      "unconditionally; rule 12 downgrades it "
                                      "because neither version is published. "
                                      "Rule 12 applied as the more specific.")
            out.append(f)
        if b["published"] != t["published"]:
            out.append({"kind": "page_publish_changed", "page": t["name"],
                        "severity": IMPACTFUL, "rule": "2",
                        "detail": "published" if t["published"] else
                                  "unpublished - any process calling this "
                                  "action stops being able to see it"})
    return out


def compare(base: Art, mod: Art) -> dict:
    added = sorted(set(mod.stages) - set(base.stages))
    removed = sorted(set(base.stages) - set(mod.stages))
    changed, unclassified, same = [], [], []

    # Rule 27: a change inside an unpublished page cannot break a caller,
    # because there is no caller - it goes to Minor Issues whatever it is.
    # Rule 26 is why it is still reported at all: published or not, the stages
    # are compared. Unknown pages are treated as published, which is the
    # cautious direction: it over-reports rather than hiding a real break.
    pub = {s["name"]: s["published"] for s in list(base.sheets.values())
           + list(mod.sheets.values())}

    def sev(page: str, base_sev: str) -> str:
        return MINOR if not pub.get(page, True) else base_sev

    for sid in sorted(set(base.stages) & set(mod.stages)):
        b, m = base.stages[sid], mod.stages[sid]
        diffs = [f for f in _FIELDS if b.get(f) != m.get(f)]
        if diffs:
            changed.append({
                "stageid": sid, "name": m["name"], "type": m["type"],
                "page": m["page"], "fields": diffs,
                "severity": sev(m["page"], _field_severity(diffs)),
                "detail": {f: {"before": b.get(f), "after": m.get(f)} for f in diffs},
            })
        elif b["hash"] != m["hash"]:
            # The subtree differs somewhere this tool does not model. Never drop
            # it, and never soften it: an unread change is graded as if it were
            # a behaviour change, because it might be one.
            unclassified.append({"stageid": sid, "name": m["name"],
                                 "type": m["type"], "page": m["page"],
                                 "severity": sev(m["page"], IMPACTFUL)})
        else:
            same.append(sid)

    def rows(ids, src, base_sev):
        return [{"stageid": i, "name": src[i]["name"], "type": src[i]["type"],
                 "page": src[i]["page"],
                 "severity": sev(src[i]["page"], base_sev)} for i in ids]

    # Rule 15: added and removed stages are graded under their page. A stage
    # removed from a published page is the one that breaks a running process.
    sheets = compare_sheets(base, mod)
    d = {
        "base": base.name, "target": mod.name,
        "added": rows(added, mod.stages, IMPACTFUL),
        "removed": rows(removed, base.stages, IMPACTFUL),
        "changed": changed,
        "unclassified": unclassified,
        "sheets": sheets,
        "unchanged_count": len(same),
        "pages_added": sorted(set(mod.pages.values()) - set(base.pages.values())),
        "pages_removed": sorted(set(base.pages.values()) - set(mod.pages.values())),
    }
    everything = (d["added"] + d["removed"] + d["changed"]
                  + d["unclassified"] + sheets)
    d["totals"] = {s: sum(1 for r in everything if r["severity"] == s)
                   for s in (CRITICAL, IMPACTFUL, MINOR)}
    d["identical"] = not everything
    return d


def ledger(d: dict) -> str:
    """The CHANGES block for prompt 06. One stageid per line, +/-/~ prefixed."""
    out = []
    for r in d["sheets"]:
        out.append(f"P [{r['severity']:<9}] page {r['page']!r}: {r['detail']} "
                   f"(rule {r['rule']})")
    for r in d["added"]:
        out.append(f"+ [{r['severity']:<9}] {r['stageid']}  [{r['type']}] "
                   f"{r['page']} / {r['name']}")
    for r in d["removed"]:
        out.append(f"- [{r['severity']:<9}] {r['stageid']}  [{r['type']}] "
                   f"{r['page']} / {r['name']}")
    for r in d["changed"]:
        out.append(f"~ [{r['severity']:<9}] {r['stageid']}  [{r['type']}] "
                   f"{r['page']} / {r['name']}"
                   f"   changed: {', '.join(_LABEL.get(f, f) for f in r['fields'])}")
    for r in d["unclassified"]:
        out.append(f"~ [{r['severity']:<9}] {r['stageid']}  [{r['type']}] "
                   f"{r['page']} / {r['name']}"
                   "   changed: something this diff does not model - inspect by hand")
    return "\n".join(out)


def coding_rules(base_path: Path, target_path: Path) -> dict:
    """Rule 1: the comparison carries a coding-rules section of its own.

    Both versions are audited, not just one, because the question a reviewer is
    actually asking is not "does this object comply" but "does overwriting make
    compliance better or worse". A base that fixes nine issues and introduces
    one is a different decision from a base that fixes none.

    A finding is identified by (rule, stage) so the two sides can be subtracted.
    Findings that name no stage - the Application Modeller ones are about spied
    elements, not stages - fall back to their observation text, which is stable
    between versions unless the thing it describes actually changed.
    """
    import audit_rules as A

    def pairs(p: Path) -> tuple[set, dict]:
        stages = A.load([p])
        checks = A.audit(stages, A.load_elements([p]))
        found, by_key = set(), {}
        for c in checks:
            for f in c.findings:
                keys = ([(f.rule_id, sid) for sid in f.stageids]
                        or [(f.rule_id, f.observed)])
                for k in keys:
                    found.add(k)
                    by_key[k] = f
        return found, by_key

    b, b_by = pairs(base_path)
    t, _ = pairs(target_path)

    def rows(keys, delta: bool = False):
        """A coding-rules finding is aggregated per artifact ("13 stages keep a
        default name"), but a delta is per stage. Printing the finding's own
        wording against a one-stage difference claimed 13 new problems where
        there was one, so a delta row carries the stages that actually differ
        and says how many of the finding's total they are."""
        grouped: dict[int, tuple] = {}
        for k in sorted(keys):
            f = b_by.get(k)
            if f is None:
                continue
            grouped.setdefault(id(f), (f, []))[1].append(k[1])
        out = []
        for f, hits in grouped.values():
            row = {"rule_id": f.rule_id, "severity": f.severity,
                   "artifact": f.artifact, "page": f.page, "rule": f.rule,
                   "observed": f.observed, "required": f.required,
                   "section": f.rule_section}
            if delta:
                total = len(f.stageids) or 1
                row["stageids"] = sorted(hits)
                row["observed"] = (
                    f"{len(hits)} of the {total} stage(s) in this finding are "
                    f"absent from the target version - {f.observed}")
            out.append(row)
        return out

    return {
        "base_issue_count": len(b),
        "target_issue_count": len(t),
        # What the bank is left holding after the overwrite.
        "in_base": rows(b),
        # Present in base but not target: the overwrite ADDS these.
        "introduced_by_overwrite": rows(b - t, delta=True),
        # Present in target but not base: the overwrite REMOVES these.
        "fixed_by_overwrite_count": len(t - b),
    }


def instance_of(path: str) -> str | None:
    """Rule 23: files are named `<instance short code> - <artifact>.<ext>`, and
    the report has to name the instance. Only a filename that actually carries
    the separator is claimed; guessing an instance would be worse than omitting
    one, because the reader cannot tell a guess from a fact."""
    stem = Path(path).stem
    return stem.split(" - ", 1)[0].strip() if " - " in stem else None


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("base", help="the good version; the one that will overwrite")
    p.add_argument("target", help="the version being compared to and replaced")
    p.add_argument("-o", "--out", default=".")
    args = p.parse_args()

    base, mod = Art(Path(args.base)), Art(Path(args.target))
    if base.name != mod.name:
        print(f"note: artifact names differ ({base.name!r} vs {mod.name!r}) - "
              "diffing anyway, but check these are two versions of one object")

    d = compare(base, mod)
    d["coding_rules"] = coding_rules(Path(args.base), Path(args.target))
    d["base_instance"] = instance_of(args.base)
    d["target_instance"] = instance_of(args.target)
    d["base_file"] = Path(args.base).name
    d["target_file"] = Path(args.target).name
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "changes.json").write_text(
        json.dumps(d, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8")
    text = ledger(d)
    (outdir / "changes.txt").write_text(text + "\n", encoding="utf-8")

    n = len(d["added"]) + len(d["removed"]) + len(d["changed"]) + len(d["unclassified"])
    print(f"{d['base']}: {len(d['added'])} added, {len(d['removed'])} removed, "
          f"{len(d['changed'])} changed, {len(d['unclassified'])} unclassified, "
          f"{d['unchanged_count']} unchanged")
    for r in d["sheets"]:
        print(f"  page {r['severity']:<9} {r['page']}: {r['detail']}")
    t = d["totals"]
    print(f"{t[CRITICAL]} critical, {t[IMPACTFUL]} impactful, {t[MINOR]} minor")
    print(f"-> {outdir/'changes.txt'} ({n} stage(s) for the model to explain)")
    # A critical finding means overwriting the target breaks a caller's
    # contract. Exit non-zero so a pipeline cannot wave it through.
    sys.exit(1 if t[CRITICAL] else 0)


if __name__ == "__main__":
    main()
