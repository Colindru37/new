#!/usr/bin/env python3
"""api_spec_check.py -- verify a 02-api-spec model output against its ledger.

Turns the model's judgement into a grep: everything it claims must trace back to
api_facts.py facts. Nothing here needs a second model or leaves the laptop.

  python api_spec_check.py api_facts.json spec.json

spec.json is ONE object's 02-api-spec JSON (the model's answer). It is matched to
its object record in the ledger by the "object" field. Checks:
  * every replaces[].action exists in that object's ledger actions
  * every replaces[].stageids id exists in that action's ledger stageids
  * every request_fields/response_fields name is a real field of a replaced
    action (nothing invented)
  * coverage: every ledger action is accounted for -- in some replaces[].action,
    in auth_candidates, or named in a not_covered entry. None silently dropped.

Exit 0 = CHECK PASS. Exit 1 = problems listed.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


def check(ledger: dict, spec: dict) -> list[str]:
    obj = spec.get("object", "")
    rec = next((o for o in ledger.get("objects", []) if o["object"] == obj), None)
    if rec is None:
        return [f"spec object {obj!r} is not in the ledger (check the name is verbatim)"]

    # ledger facts for this object
    ledger_actions = {a["action"] for a in rec["actions"]}
    req_of = {a["action"]: set(a["request_fields"]) for a in rec["actions"]}
    resp_of = {a["action"]: set(a["response_fields"]) for a in rec["actions"]}
    ids_of = {a["action"]: set(a["stageids"]) for a in rec["actions"]}

    problems: list[str] = []
    replaced: set[str] = set()

    for i, ep in enumerate(spec.get("endpoints", [])):
        tag = ep.get("operation") or ep.get("path") or f"endpoint[{i}]"
        actions = [r.get("action") for r in ep.get("replaces", [])]
        allow_req: set[str] = set()
        allow_resp: set[str] = set()
        for r in ep.get("replaces", []):
            act = r.get("action")
            if act not in ledger_actions:
                problems.append(f"{tag}: replaces unknown action {act!r}")
                continue
            replaced.add(act)
            allow_req |= req_of[act]
            allow_resp |= resp_of[act]
            for sid in r.get("stageids", []):
                if sid not in ids_of[act]:
                    problems.append(f"{tag}: stageid {sid} not a call site of {act!r}")
        for f in ep.get("request_fields", []):
            if f.get("name") not in allow_req:
                problems.append(f"{tag}: invented request_field {f.get('name')!r}")
        for f in ep.get("response_fields", []):
            if f.get("name") not in allow_resp:
                problems.append(f"{tag}: invented response_field {f.get('name')!r}")

    # coverage ledger: replaces U auth_candidates U (named in not_covered)
    auth = set(spec.get("auth_candidates", []))
    for a in auth:
        if a not in ledger_actions:
            problems.append(f"auth_candidates: unknown action {a!r}")
    not_covered = spec.get("not_covered", [])
    accounted = replaced | auth
    for a in sorted(ledger_actions):
        if a in accounted:
            continue
        if any(a in str(nc) for nc in not_covered):
            continue
        problems.append(f"coverage: action {a!r} is not mapped, not auth, and not in not_covered")
    return problems


def main(argv=None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if len(args) != 2:
        print("usage: api_spec_check.py api_facts.json spec.json", file=sys.stderr)
        return 2
    ledger = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    spec = json.loads(Path(args[1]).read_text(encoding="utf-8"))
    problems = check(ledger, spec)
    if not problems:
        print("CHECK PASS")
        return 0
    print(f"CHECK FAIL - {len(problems)} problem(s):")
    for p in problems:
        print("  " + p)
    return 1


if __name__ == "__main__":
    sys.exit(main())
