#!/usr/bin/env python3
"""Deterministic modelling-rules lint for emitted / hand-edited BPMN (Camunda 7 / Fluxnova).

The mechanical half of skill-bp-to-camunda/reference/modelling-rules.md: the
estate's Blue Prism coding standard translated to BPMN, checked by pattern,
never by a model. Exit code 1 on any ERROR finding, so it is CI-safe.

    python tools/bpmn_lint.py <dir or .bpmn ...> [--warn-as-error] [--json out.json]
    python tools/bpmn_lint.py --selftest

Each finding: RULE | severity | file | element id | name | detail.
INFO rules (CODE-SLOT-UNPORTED) count work left, they do not fail the run.
Stdlib only.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

ACTIVITY = {"task", "serviceTask", "scriptTask", "callActivity", "subProcess", "userTask",
            "sendTask", "receiveTask", "businessRuleTask", "manualTask"}
FLOW_NODE = ACTIVITY | {"startEvent", "endEvent", "exclusiveGateway", "parallelGateway",
                        "inclusiveGateway", "eventBasedGateway", "boundaryEvent",
                        "intermediateCatchEvent", "intermediateThrowEvent"}
DEFAULT_NAME = re.compile(r"^(Task|Activity|Gateway|Flow|Event|StartEvent|EndEvent|SubProcess|"
                          r"ScriptTask|ServiceTask|CallActivity|Decision|Data|Calc|Calculation|"
                          r"Action|Page|Note)[_ ]?\d*[a-z0-9]{0,8}$", re.I)
SECRET = re.compile(r"(^|_)(pwd|password|secret|token|apikey|api_key)($|_|\s)", re.I)
REACH_OUT = re.compile(r"Java\.type\(\s*['\"](java\.io|java\.net|java\.nio\.file|java\.lang\.ProcessBuilder|"
                       r"java\.lang\.Runtime|javax\.net|com\.sun\.net)|Runtime\.getRuntime|ProcessBuilder")
PLACEHOLDER = re.compile(r"throw new Error\(['\"]TODO port")
TOPIC = re.compile(r"^(code\.)?[a-z0-9][a-z0-9.\-]*\.[a-z0-9][a-z0-9\-]*$")
ERROR_CODES = {"BP_SYSTEM", "BP_BUSINESS"}
SIZE = {"startEvent": (36, 36), "endEvent": (36, 36), "boundaryEvent": (36, 36),
        "exclusiveGateway": (50, 50), "parallelGateway": (50, 50)}


def _loc(t: str) -> str:
    return t.split("}")[-1]


def _attr(el, name):
    """vendor-prefixed attribute by local name"""
    for k, v in el.attrib.items():
        if _loc(k) == name:
            return v
    return None


class Finding:
    def __init__(self, rule, sev, file, eid, name, detail):
        self.rule, self.sev, self.file, self.eid, self.name, self.detail = rule, sev, file, eid, name, detail

    def row(self):
        return f"{self.rule:26s} {self.sev:5s} {self.file}: {self.eid or '-'} ({self.name or ''}) {self.detail}"


def lint_doc(xml: str, fname: str) -> list[Finding]:
    f: list[Finding] = []
    root = ET.fromstring(xml)
    errors = {e.get("id"): e for e in root.iter() if _loc(e.tag) == "error"}
    shapes = {}
    edges = set()
    for d in root.iter():
        if _loc(d.tag) == "BPMNShape":
            b = next((c for c in d if _loc(c.tag) == "Bounds"), None)
            if b is not None:
                shapes[d.get("bpmnElement")] = tuple(float(b.get(k)) for k in ("x", "y", "width", "height"))
        elif _loc(d.tag) == "BPMNEdge":
            edges.add(d.get("bpmnElement"))

    for e in errors.values():
        if e.get("errorCode") not in ERROR_CODES:
            f.append(Finding("EXC-CODE", "ERROR", fname, e.get("id"), e.get("name"),
                             f"errorCode {e.get('errorCode')!r} is not BP_SYSTEM/BP_BUSINESS"))

    for proc in (p for p in root.iter() if _loc(p.tag) == "process"):
        pid, pname = proc.get("id", ""), proc.get("name", "")
        is_object_doc = None
        if not _attr(proc, "historyTimeToLive"):
            f.append(Finding("LOG-HTTL", "ERROR", fname, pid, pname, "no historyTimeToLive (deploy rejects on 7.20+)"))
        if not re.match(r"^p_[A-Za-z0-9_]+_[0-9a-f]{8}$", pid):
            f.append(Finding("NAME-PROCESS-ID", "WARN", fname, pid, pname, "process id is not the emitter's stable form; call activities may dangle"))
        declared = {_attr(p, "name").split(":", 1)[1] for p in proc.iter() if _loc(p.tag) == "property"
                    and (_attr(p, "name") or "").startswith(("var:", "collection:"))}

        # per container (process + each subProcess): nodes, flows
        containers = [proc] + [s for s in proc.iter() if _loc(s.tag) == "subProcess"]
        for cont in containers:
            cid = cont.get("id")
            nodes = {ch.get("id"): ch for ch in cont if _loc(ch.tag) in FLOW_NODE and ch.get("id")}
            flows = [ch for ch in cont if _loc(ch.tag) == "sequenceFlow"]
            out_of: dict[str, list] = {}
            in_of: dict[str, list] = {}
            for fl in flows:
                out_of.setdefault(fl.get("sourceRef"), []).append(fl)
                in_of.setdefault(fl.get("targetRef"), []).append(fl)
            starts = [n for n in nodes.values() if _loc(n.tag) == "startEvent"]
            if cont is proc and len(starts) != 1:
                f.append(Finding("STRUCT-ONE-START", "ERROR", fname, pid, pname, f"{len(starts)} start events"))
            if cont is proc and starts:
                nxt = [fl.get("targetRef") for fl in out_of.get(starts[0].get("id"), [])]
                first = nodes.get(nxt[0]) if nxt else None
                if first is not None and _loc(first.tag) in ACTIVITY and not (first.get("id", "").startswith("init_")):
                    # only a rule when an Init exists somewhere in this process
                    if any(i.startswith("init_") for i in nodes):
                        f.append(Finding("STRUCT-INIT-FIRST", "ERROR", fname, first.get("id"), first.get("name"),
                                         "an Init task exists but is not the first node after Start"))
            for nid, n in nodes.items():
                tag, name = _loc(n.tag), n.get("name") or ""
                doc = next(((c.text or "").strip() for c in n if _loc(c.tag) == "documentation"), "")
                if tag in ACTIVITY | {"exclusiveGateway"}:
                    if not name:
                        f.append(Finding("NAME-DEFAULT", "ERROR", fname, nid, name, "unnamed element"))
                    elif DEFAULT_NAME.match(name):
                        f.append(Finding("NAME-DEFAULT", "ERROR", fname, nid, name, "default-style name"))
                    if not doc and not nid.startswith(("loop_", "blk_")):
                        f.append(Finding("NARRATIVE-MISSING", "WARN", fname, nid, name, "no documentation"))
                if tag == "exclusiveGateway" and len(out_of.get(nid, [])) > 1:
                    if not name.rstrip().endswith("?"):
                        f.append(Finding("NAME-GATEWAY-QUESTION", "WARN", fname, nid, name, "branching gateway not named as a question"))
                    for fl in out_of.get(nid, []):
                        if not fl.get("name"):
                            f.append(Finding("NAME-FLOW-FROM-GATEWAY", "WARN", fname, fl.get("id"), name, "unnamed branch"))
                if tag == "subProcess" and not name:
                    f.append(Finding("NAME-SUBPROCESS", "ERROR", fname, nid, name, "unnamed sub-process"))
                if tag == "serviceTask" and _attr(n, "type") == "external":
                    topic = _attr(n, "topic") or ""
                    if not topic:
                        f.append(Finding("CODE-TOPIC", "ERROR", fname, nid, name, "external task without topic"))
                    elif not TOPIC.match(topic):
                        f.append(Finding("NAME-TOPIC", "WARN", fname, nid, name, f"topic {topic!r} not <object>.<action> lower-case"))
                if tag == "scriptTask":
                    body = next(((c.text or "") for c in n if _loc(c.tag) == "script"), "")
                    if PLACEHOLDER.search(body):
                        f.append(Finding("CODE-SLOT-UNPORTED", "INFO", fname, nid, name, "slot body still the placeholder"))
                    if REACH_OUT.search(body):
                        f.append(Finding("CODE-SLOT-REACHES-OUT", "ERROR", fname, nid, name, "script reaches outside the engine; should be a worker"))
                    if is_object_doc is False:
                        f.append(Finding("CODE-IN-PROCESS", "ERROR", fname, nid, name, "script task in a process artifact"))
                if tag == "boundaryEvent":
                    ed = next((c for c in n if _loc(c.tag) == "errorEventDefinition"), None)
                    if ed is not None:
                        if not name:
                            f.append(Finding("EXC-BOUNDARY-NAMED", "WARN", fname, nid, name, "error boundary without a name"))
                        if _attr(ed, "errorCodeVariable") != "bpErrorCode" or _attr(ed, "errorMessageVariable") != "bpErrorMessage":
                            f.append(Finding("EXC-CATCH-BINDS", "ERROR", fname, nid, name, "catch does not bind bpErrorCode/bpErrorMessage"))
                if tag == "startEvent":
                    ed = next((c for c in n if _loc(c.tag) == "errorEventDefinition"), None)
                    if ed is not None and (_attr(ed, "errorCodeVariable") != "bpErrorCode" or _attr(ed, "errorMessageVariable") != "bpErrorMessage"):
                        f.append(Finding("EXC-CATCH-BINDS", "ERROR", fname, nid, name, "error start does not bind bpErrorCode/bpErrorMessage"))
                if tag == "endEvent":
                    ed = next((c for c in n if _loc(c.tag) == "errorEventDefinition"), None)
                    if ed is not None and name and name.lower().startswith("re-raise"):
                        err = errors.get(ed.get("errorRef"))
                        msg = _attr(err, "errorMessage") if err is not None else None
                        if msg is not None and "bpErrorMessage" not in msg:
                            f.append(Finding("EXC-RERAISE-KEEPS-DETAIL", "ERROR", fname, nid, name, "re-raise replaces the original detail"))
                # secrets
                for p in n.iter():
                    if _loc(p.tag) in ("inputParameter", "outputParameter") and SECRET.search(_attr(p, "name") or ""):
                        val = (p.text or "").strip()
                        empty = val in ("${''}", "${null}", "")
                        if not empty and (not val.startswith("${") or re.fullmatch(r"\$\{'.*'\}", val)):
                            f.append(Finding("DATA-SECRET-LITERAL", "ERROR", fname, nid, name, f"literal for secret-named parameter {_attr(p, 'name')!r}"))
                    if _loc(p.tag) == "outputParameter" and declared:
                        vn = _attr(p, "name") or ""
                        if vn and "::" not in vn and vn not in declared and not vn.startswith("out:"):
                            f.append(Finding("DATA-UNDECLARED", "WARN", fname, nid, name, f"writes undeclared variable {vn!r}"))
                # DI
                if nid not in shapes:
                    f.append(Finding("LAYOUT-DI-MISSING", "ERROR", fname, nid, name, "no BPMNShape"))
            for fl in flows:
                if fl.get("id") not in edges:
                    f.append(Finding("LAYOUT-DI-MISSING", "ERROR", fname, fl.get("id"), "", "no BPMNEdge"))
            # bounded loops: every cycle must contain an exclusive gateway (the
            # counter / collection decision); a cycle without one never ends
            adj = {n: [fl.get("targetRef") for fl in out_of.get(n, []) if fl.get("targetRef") in nodes] for n in nodes}
            index: dict[str, int] = {}
            low: dict[str, int] = {}
            stack: list[str] = []
            on: set[str] = set()
            sccs: list[list[str]] = []

            def strong(v, counter=[0]):
                index[v] = low[v] = counter[0]
                counter[0] += 1
                stack.append(v)
                on.add(v)
                for w in adj.get(v, []):
                    if w not in index:
                        strong(w)
                        low[v] = min(low[v], low[w])
                    elif w in on:
                        low[v] = min(low[v], index[w])
                if low[v] == index[v]:
                    comp = []
                    while True:
                        w = stack.pop()
                        on.discard(w)
                        comp.append(w)
                        if w == v:
                            break
                    sccs.append(comp)
            sys.setrecursionlimit(max(10000, sys.getrecursionlimit()))
            for v in list(nodes):
                if v not in index:
                    strong(v)
            for comp in sccs:
                cyclic = len(comp) > 1 or any(v in adj.get(v, []) for v in comp)
                if cyclic and not any(_loc(nodes[v].tag) == "exclusiveGateway" for v in comp):
                    v = sorted(comp)[0]
                    f.append(Finding("LOOP-BOUNDED", "ERROR", fname, v, nodes[v].get("name"),
                                     f"cycle of {len(comp)} node(s) with no gateway deciding it"))
            # overlaps / containment
            ids = [i for i in nodes if i in shapes]
            for i, a in enumerate(ids):
                ax, ay, aw, ah = shapes[a]
                for b in ids[i + 1:]:
                    bx, by, bw, bh = shapes[b]
                    if ax < bx + bw + 20 and bx < ax + aw + 20 and ay < by + bh + 20 and by < ay + ah + 20:
                        if _loc(nodes[a].tag) == "boundaryEvent" or _loc(nodes[b].tag) == "boundaryEvent":
                            continue   # a boundary event sits on its activity by definition
                        f.append(Finding("LAYOUT-OVERLAP", "WARN", fname, a, nodes[a].get("name"),
                                         f"within 20px of {b} ({nodes[b].get('name')})"))
            if cont is not proc and cid in shapes and shapes[cid][2] > 0 and not cont.get("triggeredByEvent"):
                cx, cy, cw, ch = shapes[cid]
                if cw > 120 or ch > 100:    # expanded: children must be inside
                    for nid in nodes:
                        if nid in shapes:
                            x, y, w, h = shapes[nid]
                            if x < cx or y < cy or x + w > cx + cw or y + h > cy + ch:
                                f.append(Finding("LAYOUT-CONTAINS", "WARN", fname, nid, nodes[nid].get("name"),
                                                 f"outside its sub-process {cid}"))
    return f


_SELFTEST_BAD = """<?xml version="1.0"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:camunda="http://camunda.org/schema/1.0/bpmn"
 xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" id="d" targetNamespace="t">
  <bpmn:error id="e1" name="x" errorCode="OOPS"/>
  <bpmn:process id="Process_1" name="p">
    <bpmn:startEvent id="s"/>
    <bpmn:task id="Task_1" name="Task_1"/>
    <bpmn:exclusiveGateway id="g" name="Check"/>
    <bpmn:scriptTask id="sc" name="Do" scriptFormat="javascript"><bpmn:script>var F = Java.type('java.io.File');</bpmn:script></bpmn:scriptTask>
    <bpmn:serviceTask id="sv" name="Call" camunda:type="external"/>
    <bpmn:endEvent id="e"/>
    <bpmn:sequenceFlow id="f1" sourceRef="s" targetRef="Task_1"/>
    <bpmn:sequenceFlow id="f2" sourceRef="Task_1" targetRef="g"/>
    <bpmn:sequenceFlow id="f3" sourceRef="g" targetRef="sc"/>
    <bpmn:sequenceFlow id="f4" sourceRef="g" targetRef="sv"/>
    <bpmn:task id="Spin" name="Spin"/>
    <bpmn:sequenceFlow id="f5" sourceRef="sv" targetRef="Spin"/>
    <bpmn:sequenceFlow id="f6" sourceRef="Spin" targetRef="Spin"/>
  </bpmn:process>
</bpmn:definitions>
"""
_SELFTEST_EXPECT = {"EXC-CODE", "LOG-HTTL", "NAME-PROCESS-ID", "NAME-DEFAULT", "NARRATIVE-MISSING",
                    "NAME-GATEWAY-QUESTION", "NAME-FLOW-FROM-GATEWAY", "CODE-SLOT-REACHES-OUT",
                    "CODE-TOPIC", "LAYOUT-DI-MISSING", "LOOP-BOUNDED"}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("inputs", nargs="*")
    ap.add_argument("--warn-as-error", action="store_true")
    ap.add_argument("--json")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:
        got = {x.rule for x in lint_doc(_SELFTEST_BAD, "bad.bpmn")}
        missing = _SELFTEST_EXPECT - got
        print("SELFTEST PASS" if not missing else f"SELFTEST FAIL: not raised: {sorted(missing)}")
        return 0 if not missing else 1
    files: list[Path] = []
    for p in map(Path, a.inputs):
        files += sorted(p.rglob("*.bpmn")) if p.is_dir() else [p]
    if not files:
        ap.error("give .bpmn files or directories, or --selftest")
    allf: list[Finding] = []
    for fp in files:
        allf += lint_doc(fp.read_text(encoding="utf-8"), fp.name)
    by_rule: dict[str, int] = {}
    for x in allf:
        by_rule[f"{x.rule} ({x.sev})"] = by_rule.get(f"{x.rule} ({x.sev})", 0) + 1
    for x in sorted(allf, key=lambda x: ({"ERROR": 0, "WARN": 1, "INFO": 2}[x.sev], x.rule, x.file)):
        print(x.row())
    print("\nsummary: " + (", ".join(f"{k} x{v}" for k, v in sorted(by_rule.items())) or "clean"))
    if a.json:
        Path(a.json).write_text(json.dumps([x.__dict__ for x in allf], indent=1), encoding="utf-8")
    bad = any(x.sev == "ERROR" or (a.warn_as_error and x.sev == "WARN") for x in allf)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
