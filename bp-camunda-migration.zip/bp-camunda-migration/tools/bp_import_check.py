#!/usr/bin/env python3
"""bp_import_check.py -- will Blue Prism actually IMPORT this file?

Well-formed XML is not the bar. A generated artifact can parse perfectly, pass
every structural check, and still be rejected by Blue Prism's importer -- or
worse, import cleanly and fail at RUNTIME. Every rule below comes from an
observed import failure or from a convention read out of a real export; none
is invented from a mental model of the schema. That distinction is the whole
point: the previous attempt failed because its validator checked what the
author THOUGHT mattered instead of what the product enforces.

    python bp_import_check.py <candidate> [--as object|process|release]
                              [--reference <known-good export>]

--reference is strongly recommended: conventions (attribute casing, BOM) are
LEARNED from a real file rather than hardcoded, because the casing is
per-attribute and not guessable -- a real export carries published="True" AND
byrefcollection="true" in the same document.

Exit 0 = no BLOCK findings. Exit 1 = at least one thing that will fail import.
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

# --------------------------------------------------------------------------- #
# reading
# --------------------------------------------------------------------------- #
_BADREF = re.compile(r"&#(?:([0-9]+)|[xX]([0-9a-fA-F]+));")
_ATTR = re.compile(r'([A-Za-z_][\w.:-]*)="([^"]*)"')


def _illegal(n: int) -> bool:
    return not (n in (0x9, 0xA, 0xD) or 0x20 <= n <= 0xD7FF
                or 0xE000 <= n <= 0xFFFD or 0x10000 <= n <= 0x10FFFF)


def _read(path: Path) -> tuple[str, bool, ET.Element | None]:
    """(text, had_bom, root_or_None). Strips illegal character references so a
    real export parses; a candidate that needs stripping is reported, not hidden."""
    raw = path.read_bytes()
    bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig", errors="replace")
    try:
        return text, bom, ET.fromstring(text)
    except ET.ParseError:
        cleaned = _BADREF.sub(
            lambda m: "" if _illegal(int(m.group(1)) if m.group(1)
                                     else int(m.group(2), 16)) else m.group(0), text)
        try:
            return text, bom, ET.fromstring(cleaned)
        except ET.ParseError:
            return text, bom, None


def _local(tag: object) -> str:
    return str(tag).rsplit("}", 1)[-1]


def _kids(el, name):
    return [c for c in el if _local(c.tag) == name]


def _kid(el, name):
    for c in el:
        if _local(c.tag) == name:
            return c
    return None


# --------------------------------------------------------------------------- #
# conventions learned from a known-good file
# --------------------------------------------------------------------------- #
def learn(reference: Path) -> dict:
    """Attribute-value casing as a REAL export writes it. Not derivable from the
    schema: published="True" and byrefcollection="true" coexist in one file."""
    text, bom, _root = _read(reference)
    casing: dict[str, set] = defaultdict(set)
    for name, val in _ATTR.findall(text):
        if val.lower() in ("true", "false"):
            casing[name].add(val)
    return {"casing": {k: sorted(v) for k, v in casing.items()}, "bom": bom}


# --------------------------------------------------------------------------- #
# the checks
# --------------------------------------------------------------------------- #
def check(path: Path, kind: str, conv: dict | None) -> list[tuple]:
    """Returns [(severity, rule, message)]. BLOCK = observed to fail import."""
    out: list[tuple] = []
    text, bom, root = _read(path)
    if root is None:
        return [("BLOCK", "XML", "not well-formed even after stripping illegal "
                                 "character references -- Blue Prism cannot read it")]

    # R1 root element must match what is being imported (CONFIRMED failure)
    r = _local(root.tag)
    if kind in ("object", "process") and r != "process":
        out.append(("BLOCK", "R1-root",
                    f"root is <{r}>; a single {kind} import requires <process> as root"))
    if kind == "release" and r != "release":
        out.append(("BLOCK", "R1-root",
                    f"root is <{r}>; a release requires <bpr:release> as root"))

    # R2 non-standard wrapper (CONFIRMED failure)
    if kind in ("object", "process"):
        for el in root.iter():
            if _local(el.tag) == "object" and el.get("type"):
                out.append(("BLOCK", "R2-wrapper",
                            'non-standard <object type="..."> wrapper found; '
                            "a single artifact body is <process>"))
                break

    # R3 attribute casing must match a real export (CONFIRMED failure)
    if conv:
        for name, val in _ATTR.findall(text):
            if val.lower() not in ("true", "false"):
                continue
            good = conv["casing"].get(name)
            if good and val not in good:
                out.append(("BLOCK", "R3-casing",
                            f'{name}="{val}" but a real export writes '
                            f'{name}="{good[0]}" -- Blue Prism strict-parses this'))
    # de-duplicate the casing findings (one per attribute is enough)
    seen = set()
    dedup = []
    for sev, rule, msg in out:
        key = (rule, msg.split(" but ")[0])
        if rule == "R3-casing" and key in seen:
            continue
        seen.add(key)
        dedup.append((sev, rule, msg))
    out = dedup

    # walk artifact bodies
    bodies = []
    if r == "process":
        bodies.append(root)
    else:
        for w in root.iter():
            if _local(w.tag) in ("process", "object"):
                b = _kid(w, "process")
                if b is not None:
                    bodies.append(b)

    for body in bodies:
        declared = {ss.get("subsheetid") for ss in _kids(body, "subsheet")
                    if ss.get("subsheetid")}
        stages = _kids(body, "stage")
        ids = [s.get("stageid") for s in stages if s.get("stageid")]

        # R4 duplicate stage ids (INFERRED)
        dupes = {i for i in ids if ids.count(i) > 1}
        for d in sorted(dupes):
            out.append(("BLOCK", "R4-stageid", f"duplicate stageid {d}"))

        by_page_data: dict[str, list] = defaultdict(list)
        for st in stages:
            t = st.get("type") or ""
            ssid = (_kid(st, "subsheetid").text.strip()
                    if _kid(st, "subsheetid") is not None
                    and _kid(st, "subsheetid").text else None)

            # R5 SubSheetInfo without a subsheetid is orphaned (CONFIRMED failure)
            if t == "SubSheetInfo" and not ssid:
                out.append(("BLOCK", "R5-orphan",
                            f'SubSheetInfo stage "{st.get("name")}" has no <subsheetid>'))
            # R6 every referenced page must be declared (CONFIRMED failure)
            if ssid and declared and ssid not in declared:
                out.append(("BLOCK", "R6-subsheet",
                            f'stage "{st.get("name")}" references page {ssid} '
                            "with no matching <subsheet> declaration"))
            # R7 a Data stage without <private/> is GLOBAL -> name collisions
            if t == "Data":
                by_page_data[st.get("name") or ""].append(
                    _kid(st, "private") is not None)

        for name, privates in sorted(by_page_data.items()):
            if len(privates) > 1 and not all(privates):
                out.append(("BLOCK", "R7-private",
                            f'Data item "{name}" is declared {len(privates)} times and '
                            "is not marked <private/> -- Blue Prism reports a "
                            "conflict of names on import"))

        # R8 dangling flow links (INFERRED)
        known = set(ids)
        for st in stages:
            for tag in ("onsuccess", "ontrue", "onfalse"):
                for el in _kids(st, tag):
                    if el.text and el.text.strip() and el.text.strip() not in known:
                        out.append(("WARN", "R8-link",
                                    f'stage "{st.get("name")}" links to unknown '
                                    f"stage {el.text.strip()}"))

    # R9 BOM convention (INFERRED from the reference)
    if conv and conv.get("bom") and not bom:
        out.append(("WARN", "R9-bom",
                    "no UTF-8 BOM; a real Blue Prism export starts with one"))
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="bp_import_check")
    ap.add_argument("candidate", help="the file you want Blue Prism to import")
    ap.add_argument("--as", dest="kind", choices=("object", "process", "release"),
                    default="object", help="what you are importing it AS")
    ap.add_argument("--reference", help="a known-good real export to learn conventions from")
    a = ap.parse_args(argv)

    conv = learn(Path(a.reference)) if a.reference else None
    if conv is None:
        print("NOTE: no --reference given; attribute-casing and BOM checks are OFF. "
              "Those are the rules a generated file gets wrong most often.",
              file=sys.stderr)
    findings = check(Path(a.candidate), a.kind, conv)
    blocks = [f for f in findings if f[0] == "BLOCK"]
    for sev, rule, msg in findings:
        print(f"  {sev:5} {rule:12} {msg}")
    if not findings:
        print("  no findings")
    print(f"\n{len(blocks)} BLOCK, {len(findings) - len(blocks)} WARN")
    print("IMPORT CHECK " + ("FAIL" if blocks else "PASS"))
    return 1 if blocks else 0


if __name__ == "__main__":
    sys.exit(main())
