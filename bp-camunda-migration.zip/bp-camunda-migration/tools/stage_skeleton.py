#!/usr/bin/env python3
"""Dump one STRUCTURAL skeleton per stage type - tag and attribute NAMES only,
every value scrubbed - so the parser's remaining `# UNCONFIRMED` element shapes
can be confirmed against a real export WITHOUT moving any bank content.

The rendered summaries we have (from an ad-hoc extractor) tell us WHICH stage
types exist and what they mean, but not the raw XML tag names the parser must
match on: the flow-link tags (<onsuccess>/<ontrue>/<onfalse>?), and the
internals of Decision / ChoiceStart / Calculation / MultipleCalculation /
Collection / Action <resource> and the exception + loop stages. Those are
structure, not IP - only the VALUES (expressions, ids, names, code, narratives,
customer-referencing logic) are sensitive.

So this scrubs by construction, not by judgement: every attribute value and
every text node is replaced with a sentinel, and the only value kept is the
stage `type` (which is the whole point). What survives is tag names, attribute
names, nesting, and whether a link target lives in element TEXT vs an attribute.
Paste the output back safely; it cannot carry business content.

Stdlib only - runs on the embeddable-zip Python with no pip, like its siblings.

    python tools/stage_skeleton.py EXPORT.bprelease            # one per type
    python tools/stage_skeleton.py EXPORT.bpprocess --type Decision   # all of one
"""
import argparse
import copy
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

SENTINEL = "…"          # a single ellipsis: "a value was here, redacted"
_KEEP_ATTR = ("type",)       # structural, non-sensitive - the reason we're here


def _local(tag: str) -> str:
    """Tag without its XML namespace, e.g. '{..}stage' -> 'stage'."""
    return tag.rsplit("}", 1)[-1]


def _stages(root: ET.Element):
    """Every <stage> element anywhere in the document (all artifacts of a
    release included). Namespace-agnostic, like the parser."""
    return (el for el in root.iter() if _local(el.tag) == "stage")


def scrub(el: ET.Element) -> ET.Element:
    """A deep copy of `el` with all VALUES removed: namespaces stripped for
    readability, attribute values blanked (except the structural allowlist),
    and any non-whitespace text/tail replaced with the sentinel so its mere
    PRESENCE (e.g. a link target carried as element text) is still visible."""
    out = copy.deepcopy(el)
    for node in out.iter():
        node.tag = _local(node.tag)
        node.attrib = {
            k: (v if k in _KEEP_ATTR else SENTINEL) for k, v in node.attrib.items()
        }
        if node.text and node.text.strip():
            node.text = SENTINEL
        if node.tail and node.tail.strip():
            node.tail = None                      # tail is layout whitespace only
    return out


def _indent(el: ET.Element, level: int = 0) -> None:
    """ET.indent equivalent (kept explicit for older stdlib)."""
    pad = "\n" + "  " * level
    if len(el):
        if not (el.text and el.text.strip()):
            el.text = pad + "  "
        for child in el:
            _indent(child, level + 1)
            if not (child.tail and child.tail.strip()):
                child.tail = pad + "  "
        if not (el[-1].tail and el[-1].tail.strip()):
            el[-1].tail = pad
    elif level and not (el.tail and el.tail.strip()):
        el.tail = pad


def skeletons(root: ET.Element, only: str | None = None):
    """Yield (type, scrubbed_stage) - one representative per type by default,
    or every stage of `only` when a single type is requested. Untyped stages
    are grouped under '(no type)' so nothing is silently dropped."""
    seen: set[str] = set()
    for st in _stages(root):
        stype = st.get("type") or "(no type)"
        if only is not None:
            if stype == only:
                yield stype, scrub(st)
            continue
        if stype not in seen:
            seen.add(stype)
            yield stype, scrub(st)


def render(root: ET.Element, only: str | None = None) -> str:
    blocks = []
    for stype, sk in skeletons(root, only):
        _indent(sk)
        xml = ET.tostring(sk, encoding="unicode")
        blocks.append(f"# type = {stype}\n{xml}")
    return "\n\n".join(blocks)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("export", type=Path, help=".bprelease / .bpprocess / .bpobject")
    ap.add_argument("--type", dest="only", metavar="T",
                    help="dump EVERY stage of type T instead of one per type")
    args = ap.parse_args(argv)

    if not args.export.exists():
        print(f"error: no such file: {args.export}", file=sys.stderr)
        return 2
    try:
        root = ET.parse(args.export).getroot()
    except ET.ParseError as e:
        print(f"error: XML parse error: {e}", file=sys.stderr)
        return 2

    out = render(root, args.only)
    if not out:
        where = f" of type {args.only!r}" if args.only else ""
        print(f"error: no stages{where} found", file=sys.stderr)
        return 1
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
