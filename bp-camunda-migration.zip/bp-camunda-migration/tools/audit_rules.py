"""The deterministic half of `prompts/03-coding-rules-audit.md`.

    python tools/audit_rules.py <export-dir-or-file> [-o findings.json]

Prompt 03 states the rule this file exists to obey: *if a rule can be a regex,
it must be a regex*. Paying a model to pattern-match names and grep code blocks
buys false negatives at a price, because a model handed a 685-stage object will
sample a few pages and extrapolate the rest. Everything here is exact, free, and
covers 100% of stages every run.

## What this can and cannot claim

The bank's standard is held as reference (folder `rule/`, gitignored, never
committed), so each finding now cites the section it rests on, by TITLE - the
document's own numbering drifts, its titles do not. What it produces is still a
**candidate finding**: an observation that is certainly true about the export
and points at a named section, for a human to confirm against the text and drop
if the standard does not actually state it. Two honesty caveats survive in the
output: the three `CODE-*` pattern checks come from the team's own audit
methodology, not v5.0, and `CODE-IN-PROCESS` stays `UNMAPPED` because the
standard does not state it.

So this is deliberately conservative. Every check here is something that is
either true or false about the XML with no interpretation: a literal string in a
code block, a default stage name, an empty field. Judgement calls - "is this
really a Business Core page", "does this error handling recover or swallow" -
are left to the model half, which is the only part that needs the standard.

## checks_run is not decoration

Every check reports how many things it examined. A check that examined zero is
reported as `scanned: 0` and highlighted, because the most expensive bug in this
project so far looked exactly like a clean result: `queues=0` was read as "no
queues" when it meant "the parser did not recognise the queue VBO". A check that
finds nothing and a check that ran on nothing must never look the same.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass, field, asdict
from pathlib import Path
from xml.etree import ElementTree as ET

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from bp_estate.cli import _collect   # noqa: E402


# --------------------------------------------------------------------------- #
# Provenance. Prompt 03: "If the standard does not say it, it is not a rule, and
# you must not report it." Every check therefore declares where its rule comes
# from, and a check that cannot name a source says so in the report rather than
# borrowing authority from the ones that can.
# --------------------------------------------------------------------------- #
V5 = "BP Coding Rules v5.0"
SKILLS = "AUDIT_SKILLS_REFERENCE.md (the team's own audit methodology)"
NOT_IN_STANDARD = ("NOT TRACEABLE TO THE STANDARD - general Blue Prism "
                   "hygiene, offered for a human to accept or drop")

# Section each check's finding cites. The full v5.0 text is now held (folder
# `rule/`, 2026-07-26): its content list names 12 sections but the body carries
# 14 `###` headers with drifted numbering (a doubled "Common Coding Issues",
# plus "Folder Structure" and "UI Element Handling"). So findings cite by
# SECTION TITLE, which is stable, not by a number that the source itself gets
# wrong. A check with no entry here keeps rule_section "UNMAPPED".
_SECTION = {
    "CODE-BLOCKING-UI":  "AUDIT_SKILLS_REFERENCE §6 (VB.NET patterns) - not stated in Coding Rules v5.0",
    "CODE-SCRIPT-EXEC":  "AUDIT_SKILLS_REFERENCE §6 (VB.NET patterns) - not stated in Coding Rules v5.0",
    "CODE-COM-UNRELEASED": "AUDIT_SKILLS_REFERENCE §6 (VB.NET patterns) - not stated in Coding Rules v5.0",
    "STAGE-DEFAULT-NAME": "General Development Rules - Stage Names",
    "NARRATIVE-MISSING": "General Development Rules - Descriptions",
    "DATA-SECRET-NOT-PASSWORD": "General Development Rules - Credentials Management",
    "NAME-PREFIX-CONTRADICTS-TYPE": "General Development Rules - Naming Convention (Variable Structure)",
    "NAME-NO-PREFIX": "General Development Rules - Naming Convention (Variable Structure)",
    "EXC-NO-SCREENSHOT": "Process Level Rules - Error Handling (Save Screenshot on System Exception)",
    "EXC-EMPTY-DETAIL": "Process Level Rules - Error Handling (log exception type, detail, stage)",
    "ELEMENT-BRITTLE-MATCH": "Object Level Rules - Application Modeller (robust attributes)",
    "LOG-STAGE-ON-SUCCESS": "Deployment - Logging (Parameter off, Object/Process = Errors Only)",
    "IGNORE-VALUE-ABSENT": "Object Level Rules - UI Element Handling (Global Ignore Value)",
    # CODE-IN-PROCESS is deliberately absent: the standard separates logic from
    # application interaction but never bans a code stage in a process.
}

# The 12 sections as transcribed, with what this tool can actually do about
# each. `covered` is the honest answer to "is the audit on par with the rules".
SECTIONS = [
    ("naming (scope_datatype_name)", "full",
     ["NAME-PREFIX-CONTRADICTS-TYPE", "NAME-NO-PREFIX", "STAGE-DEFAULT-NAME"], ""),
    ("PID-based attach + Is-Connected check", "none", [],
     "buildable: standard mandates the PID be captured from Launch, every "
     "Attach be PID-based, and an Is-Connected check precede each Attach"),
    ("environment-agnostic (no hardcoded paths/hosts)", "none", [],
     "buildable: scan expressions for literal paths, UNCs and URLs"),
    ("standard VBOs (Login/Excel/Outlook/PDF/Credentials)", "none", [],
     "have the approved list (Login/Excel/Outlook/PDF/Credentials); detecting a "
     "custom re-implementation of one is judgement, the model half"),
    ("Main Page vs Business Core page", "none", [],
     "reading comprehension - the model half of prompt 03"),
    ("Recover/Resume + Save Screenshot on System Exception", "partial",
     ["EXC-NO-SCREENSHOT"],
     "the screenshot rule is checked; whether the handler RECOVERS or merely "
     "swallows is judgement"),
    ("work queue name = process name; status vocabulary", "none", [],
     "this export names its queue by expression, so no literal to compare"),
    ("one action per type (N/R/W/C)", "none", [],
     "buildable: standard defines the four action types, so this is a GROUP BY "
     "of actions per object per type, not a guess"),
    ("Global Ignore Value '###IGNORE SCREEN ELEMENT###'", "partial",
     ["IGNORE-VALUE-ABSENT"],
     "the literal's presence is checked; whether each Write BRANCHES on it is "
     "flow analysis this tool does not do"),
    ("Application Modeller robust-attribute rule", "full",
     ["ELEMENT-BRITTLE-MATCH"], ""),
    ("deployment logging (Parameter off, Object/Process = Errors Only)",
     "partial", ["LOG-STAGE-ON-SUCCESS"],
     "per-stage <loginhibit/> IS in the export and is checked; the instance-level "
     "'Errors Only' setting and parameter logging are not exported at all"),
    ("radio / checkbox handling", "none", [], "reading comprehension"),
]


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _kids(el: ET.Element, name: str) -> list[ET.Element]:
    return [k for k in el if _local(k.tag) == name]


def _text(el: ET.Element, name: str) -> str:
    for k in el:
        if _local(k.tag) == name:
            return (k.text or "").strip()
    return ""


_STR = re.compile(r'"(?:[^"]|"")*"')


def live_code(src: str) -> str:
    """Code with comments and string literals removed.

    The first run of this auditor reported a `block` finding for
    `MessageBox.Show` in the stock Excel VBO. The line was
    `'MessageBox.Show("RowOffset:" ...)` - a VB.NET comment. Dead text.

    Matching raw source means every commented-out experiment and every log
    message that happens to contain "powershell" becomes a production finding,
    and the first reviewer to open one stops trusting the whole report. String
    literals go too, for the same reason: `Log("do not use MsgBox here")` is
    not a dialog.
    """
    out = []
    for line in src.splitlines():
        line = _STR.sub('""', line)             # literals first, so ' inside them is gone
        for marker in ("'", "//"):
            i = line.find(marker)
            if i >= 0:
                line = line[:i]
        if line.strip().lower().startswith("rem "):
            continue
        out.append(line)
    return "\n".join(out)


def load_shipped(registry: Path) -> set[str]:
    """Names of vendor-shipped and engine-internal objects, lowercased.

    Auditing code Blue Prism wrote against the bank's standard is noise: it
    cannot be fixed, it will not be migrated as code, and `Process.Start`
    inside an object called "Start Process" is that object working correctly.
    Read straight out of the registry so the two never drift apart.
    """
    if not registry.exists():
        return set()
    doc = yaml.safe_load(registry.read_text(encoding="utf-8")) or {}
    return {o["name"].lower() for o in doc.get("objects") or []
            if o.get("tier") in ("shipped", "internal") and o.get("name")}


# --------------------------------------------------------------------------- #
# the fact base: every stage of every artifact, with its code and page
# --------------------------------------------------------------------------- #
@dataclass
class El:
    """A spied Application Modeller element and the attributes Blue Prism
    actually matches on (`inuse="True"`). An attribute that is merely recorded
    is not part of the match and must not be judged."""
    artifact: str
    name: str
    matched_on: list[str]


# Attributes that identify a control by WHERE it is or WHAT ORDER it is in.
# They change when the window is resized, a control is added, or the screen
# resolution differs between the developer's machine and the runtime VM.
_BRITTLE = {"X", "Y", "Width", "Height", "Ordinal", "MatchIndex", "MatchReverse",
            "ScreenBounds", "AncestorCount", "ChildCount", "Style"}
# Attributes that identify a control by WHAT IT IS.
_STABLE = {"WindowText", "ClassName", "TypeName", "AutomationId", "Name", "CtrlID",
           "pWindowText", "pClassName", "pTypeName", "Value", "Id", "Path", "Label"}


def load_elements(paths: list[Path]) -> list[El]:
    out: list[El] = []
    for path in paths:
        root = ET.parse(path).getroot()
        for wrapper in root.iter():
            if _local(wrapper.tag) not in ("process", "object"):
                continue
            body = next((k for k in wrapper if _local(k.tag) == "process"), None)
            if body is None:
                continue
            art = wrapper.get("name") or "?"
            for ad in _kids(body, "appdef"):
                for el in ad.iter():
                    if _local(el.tag) != "element" or not _kids(el, "attributes"):
                        continue
                    used = [a.get("name", "")
                            for bag in _kids(el, "attributes") for a in bag
                            if a.get("inuse") == "True"]
                    if used:
                        out.append(El(art, el.get("name") or "?", used))
    return out


@dataclass
class St:
    artifact: str
    art_type: str
    page: str
    id: str
    name: str
    type: str
    narrative: str
    code: str
    datatype: str
    expression: str
    calls: str = ""
    # `<loginhibit/>` present means this stage does not write a log entry when it
    # succeeds. Presence-based: the element carries no attributes in any export
    # seen so far, so it is read as a boolean and nothing finer is claimed.
    log_inhibit: bool = False
    # A Data stage's starting value, and a Write stage's per-field expressions.
    # `initialvalueenc` is deliberately NOT read: it is an encrypted secret.
    initial: str = ""
    steps: str = ""


def load(paths: list[Path]) -> list[St]:
    out: list[St] = []
    for path in paths:
        root = ET.parse(path).getroot()
        bodies = []
        if _local(root.tag) == "process" and not _kids(root, "process"):
            bodies = [(root.get("name") or path.stem, "process", root)]
        else:
            for w in root.iter():
                if _local(w.tag) not in ("process", "object"):
                    continue
                b = _kids(w, "process")
                if b:
                    bodies.append((w.get("name") or b[0].get("name") or "?",
                                   _local(w.tag), b[0]))
        for name, atype, body in bodies:
            pages = {s.get("subsheetid"): (_text(s, "name") or "?")
                     for s in _kids(body, "subsheet")}
            for st in _kids(body, "stage"):
                sid = st.get("stageid")
                if not sid:
                    continue
                out.append(St(
                    artifact=name, art_type=atype,
                    page=pages.get(_text(st, "subsheetid"), "Main Page"),
                    id=sid, name=st.get("name") or "", type=st.get("type") or "?",
                    narrative=_text(st, "narrative"),
                    code=live_code(_text(st, "code")),
                    datatype=_text(st, "datatype"), expression=_text(st, "expression"),
                    calls=" ".join(f"{r.get('object')}.{r.get('action')}"
                                   for r in _kids(st, "resource")),
                    log_inhibit=bool(_kids(st, "loginhibit")),
                    initial=_text(st, "initialvalue"),
                    steps=" ".join(k.get("expr", "") for k in _kids(st, "step")),
                ))
    return out


# --------------------------------------------------------------------------- #
# the checks
# --------------------------------------------------------------------------- #
@dataclass
class Finding:
    rule_id: str
    rule: str
    severity: str
    stageids: list[str]
    observed: str
    required: str
    artifact: str = ""
    page: str = ""
    fix_is_mechanical: bool = False
    rule_section: str = "UNMAPPED"
    confidence: str = "certain"


@dataclass
class Check:
    id: str
    what: str
    applies_to: str
    source: str = NOT_IN_STANDARD
    scanned: int = 0
    findings: list[Finding] = field(default_factory=list)


# Literal strings, per the table in prompt 03. Presence IS the finding.
_BLOCKING_UI = ("MessageBox.Show", "MsgBox(", "InputBox(", "Interaction.MsgBox")
_SCRIPT_EXEC = ("powershell", "cmd.exe", "Process.Start", "WScript.Shell",
                "python.exe")
_COM_ACQUIRE = ("GetObject(", "CreateObject(")
_COM_RELEASE = "Marshal.ReleaseComObject"
_DEFAULT_NAME = re.compile(
    r"^(Data|Collection|Decision|Action|Calculation|Note|Choice|Code|Read|Write|"
    r"Navigate|Wait|Loop|Block|Anchor|Page|Exception|Start|End|Resume|Recover)\d+$")
_SECRETY = re.compile(r"password|passwd|\bpwd\b|secret|token|apikey|api[_ ]key",
                      re.I)

# Stages that write a log entry when they SUCCEED, and so are the ones the
# "Errors Only" deployment setting is meant to silence. Exception, Recover and
# Resume are deliberately excluded: under Errors Only those are exactly the
# stages that SHOULD still log, so inhibiting them would be the real defect.
# Start/End/Anchor/Note/Block and the SubSheetInfo/ProcessInfo headers are
# excluded because they are structure, not executed work.
_LOGS_ON_SUCCESS = {"Action", "Decision", "Calculation", "MultipleCalculation",
                    "Read", "Write", "Navigate", "Code", "Choice", "WaitStart",
                    "SubSheet"}

# The standard's own literal, quoted exactly. A Write handed this value must
# leave the field alone instead of typing the marker into the application.
_IGNORE_VALUE = "###IGNORE SCREEN ELEMENT###"
# The value is often held in an environment variable or a global data item whose
# VALUE does not survive export - only its name does. So a name that plainly
# means "ignore this element" counts as the practice being present.
_IGNORE_NAMEISH = re.compile(r"ignore[\s_]*(screen[\s_]*)?element|ignore[\s_]*value",
                             re.I)

# --------------------------------------------------------------------------- #
# BP Coding Rules v5.0 (Sept 2020), naming section: scope_datatype_name.
# The tokens below are the standard's own, not a convention invented here.
# Longest-first in the alternation, or "datetime_x" matches as date + "time_x".
# --------------------------------------------------------------------------- #
_DT_TOKEN = {
    "txt": "text", "nr": "number", "flg": "flag", "pwd": "password",
    "datetime": "datetime", "date": "date", "timespan": "timespan",
    "time": "time", "img": "image", "bin": "binary", "col": "collection",
}
_NAME_RE = re.compile(
    r"^(?:(?P<scope>io|i|o|g|e)_)?"
    r"(?P<dt>datetime|timespan|date|time|txt|nr|flg|pwd|img|bin|col)_(?P<rest>.+)$",
    re.I)


def audit(stages: list[St], elements: list[El] | None = None) -> list[Check]:
    checks: list[Check] = []

    def add(c: Check) -> Check:
        checks.append(c)
        return c

    # -- code stages ------------------------------------------------------- #
    code_stages = [s for s in stages if s.code]

    c = add(Check("CODE-BLOCKING-UI",
                  "Code must not open a dialog. A bot runs unattended, so a "
                  "message box waits forever and the session hangs.",
                  "Code stages", source=SKILLS))
    c.scanned = len(code_stages)
    for s in code_stages:
        hit = [p for p in _BLOCKING_UI if p in s.code]
        if hit:
            c.findings.append(Finding(
                c.id, c.what, "block", [s.id],
                observed=f"code contains {', '.join(hit)}",
                required="remove the dialog; surface the value as an output "
                         "parameter or an exception instead",
                artifact=s.artifact, page=s.page))

    c = add(Check("CODE-SCRIPT-EXEC",
                  "Code must not shell out to a script interpreter.",
                  "Code stages", source=SKILLS))
    c.scanned = len(code_stages)
    for s in code_stages:
        hit = [p for p in _SCRIPT_EXEC if p.lower() in s.code.lower()]
        if hit:
            c.findings.append(Finding(
                c.id, c.what, "block", [s.id],
                observed=f"code contains {', '.join(hit)}",
                required="call a published object or an API instead of a shell",
                artifact=s.artifact, page=s.page))

    # COM is per-artifact: acquiring in one stage and releasing in another is
    # normal and correct, so a per-stage check here would be all false positives.
    c = add(Check("CODE-COM-UNRELEASED",
                  "An object that attaches to a COM instance must release it. "
                  "An unreleased reference leaves the host application resident "
                  "after the bot exits.",
                  "artifacts containing Code stages", source=SKILLS))
    by_art: dict[str, list[St]] = {}
    for s in code_stages:
        by_art.setdefault(s.artifact, []).append(s)
    c.scanned = len(by_art)
    for art, ss in sorted(by_art.items()):
        acq = [s for s in ss if any(p in s.code for p in _COM_ACQUIRE)]
        if acq and not any(_COM_RELEASE in s.code for s in ss):
            c.findings.append(Finding(
                c.id, c.what, "warn", sorted(s.id for s in acq),
                observed=f"{len(acq)} stage(s) acquire a COM object; "
                         f"{_COM_RELEASE} appears nowhere in this artifact",
                required=f"call {_COM_RELEASE} on every acquired reference",
                artifact=art))

    c = add(Check("CODE-IN-PROCESS",
                  "Custom code belongs in a business object, not in a process. "
                  "A process is orchestration and must stay readable to a "
                  "business reviewer.",
                  "Code stages in process artifacts", source=NOT_IN_STANDARD))
    proc_code = [s for s in code_stages if s.art_type == "process"]
    c.scanned = len([s for s in stages if s.art_type == "process"])
    if proc_code:
        c.findings.append(Finding(
            c.id, c.what, "warn", sorted(s.id for s in proc_code),
            observed=f"{len(proc_code)} Code stage(s) in a process",
            required="move the code into an object and call it as an action",
            artifact=proc_code[0].artifact, page=proc_code[0].page))

    # -- naming and documentation ------------------------------------------ #
    c = add(Check("STAGE-DEFAULT-NAME",
                  "A stage must be named for what it does. A default name "
                  "(Data1, Decision3) means no name was ever chosen.",
                  "all named stages", source=f"{V5} - naming"))
    named = [s for s in stages if s.type not in ("SubSheetInfo", "ProcessInfo")]
    c.scanned = len(named)
    hits = [s for s in named if _DEFAULT_NAME.match(s.name.strip())]
    for art in sorted({s.artifact for s in hits}):
        ss = [s for s in hits if s.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "warn", sorted(s.id for s in ss),
            observed=f"{len(ss)} stage(s) keep a default name, e.g. "
                     + ", ".join(sorted({s.name for s in ss})[:4]),
            required="rename to describe the step", artifact=art,
            fix_is_mechanical=True))

    c = add(Check("NARRATIVE-MISSING",
                  "Every Stage, Data Item, Collection and Page must carry a clear "
                  "description; the stage narrative is the part that survives "
                  "export. (v5.0 General Development Rules - Descriptions.)",
                  "Action, Decision, Code and Choice stages",
                  source=f"{V5} - Descriptions"))
    want = [s for s in stages if s.type in ("Action", "Decision", "Code", "Choice")]
    c.scanned = len(want)
    bare = [s for s in want if not s.narrative]
    for art in sorted({s.artifact for s in bare}):
        ss = [s for s in bare if s.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "info", sorted(s.id for s in ss),
            observed=f"{len(ss)} of {len([x for x in want if x.artifact == art])} "
                     "such stage(s) have an empty narrative",
            required="describe what the stage does and why", artifact=art))

    # -- secrets ------------------------------------------------------------ #
    c = add(Check("DATA-SECRET-NOT-PASSWORD",
                  "A data item holding a secret must have datatype Password, "
                  "so its value is masked in the log and never exported.",
                  "Data stages", source=f"{V5} - naming (pwd_) + credential handling"))
    data = [s for s in stages if s.type == "Data"]
    c.scanned = len(data)
    bad = [s for s in data
           if _SECRETY.search(s.name) and s.datatype.lower() != "password"]
    for art in sorted({s.artifact for s in bad}):
        ss = [s for s in bad if s.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "block", sorted(s.id for s in ss),
            observed="; ".join(f"{s.name!r} is {s.datatype or 'untyped'}"
                               for s in ss[:5]),
            required="set datatype to Password", artifact=art,
            fix_is_mechanical=True))

    # -- naming (BP Coding Rules v5.0) -------------------------------------- #
    # Two checks, not one, because they carry different confidence. A prefix
    # that contradicts the stage's real datatype is certainly wrong whatever
    # the rule's scope. A missing prefix is only wrong if the rule covers all
    # data items rather than just parameters - and a summary of the standard
    # cannot settle that, so it is reported separately and marked "likely".
    typed = [s for s in stages if s.type in ("Data", "Collection")]

    c = add(Check("NAME-PREFIX-CONTRADICTS-TYPE",
                  "A data item's name carries a datatype token "
                  "(scope_datatype_name). The token must agree with the item's "
                  "actual datatype, or every reader of the expression is misled.",
                  "Data and Collection stages that HAVE a datatype token", source=f"{V5} - naming"))
    # `scanned` must be what the check could judge, not what it looped over.
    # An item with no prefix is invisible to this rule, so counting all 48 here
    # while none of them carries a prefix would report a confident zero from a
    # check that evaluated nothing - the failure this field exists to prevent.
    prefixed = [(s, m) for s in typed if (m := _NAME_RE.match(s.name.strip()))]
    c.scanned = len(prefixed)
    wrong = []
    for s, m in prefixed:
        want = _DT_TOKEN[m.group("dt").lower()]
        have = (s.datatype or ("collection" if s.type == "Collection" else "")).lower()
        if have and have != want:
            wrong.append((s, m.group("dt"), have))
    for art in sorted({s.artifact for s, _, _ in wrong}):
        ss = [(s, tok, have) for s, tok, have in wrong if s.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "warn", sorted(s.id for s, _, _ in ss),
            observed="; ".join(f"{s.name!r} is typed {have}, not {tok}"
                               for s, tok, have in ss[:5]),
            required="rename to the token matching the datatype, or change the "
                     "datatype", artifact=art, fix_is_mechanical=True))

    c = add(Check("NAME-NO-PREFIX",
                  "Data items are named scope_datatype_name (i_/o_/io_/g_/e_ "
                  "plus txt_/nr_/flg_/pwd_/date_/datetime_/time_/timespan_/"
                  "img_/bin_/col_).",
                  "Data and Collection stages", source=f"{V5} - naming"))
    c.scanned = len(typed)
    bare_name = [s for s in typed if not _NAME_RE.match(s.name.strip())]
    for art in sorted({s.artifact for s in bare_name}):
        ss = [s for s in bare_name if s.artifact == art]
        tot = len([x for x in typed if x.artifact == art])
        c.findings.append(Finding(
            c.id, c.what, "warn", sorted(s.id for s in ss),
            observed=f"{len(ss)} of {tot} item(s) carry no datatype token, e.g. "
                     + ", ".join(repr(s.name) for s in ss[:4]),
            required="rename to scope_datatype_name", artifact=art,
            confidence="likely", fix_is_mechanical=True))

    c = add(Check("EXC-NO-SCREENSHOT",
                  "A System Exception handler saves a screenshot before it "
                  "resumes, or nobody can diagnose the failure afterwards.",
                  "pages containing a Recover stage", source=f"{V5} - error handling"))
    pages: dict[tuple[str, str], list[St]] = {}
    for s in stages:
        pages.setdefault((s.artifact, s.page), []).append(s)
    recov = {k: v for k, v in pages.items() if any(s.type == "Recover" for s in v)}
    c.scanned = len(recov)
    for (art, page), ss in sorted(recov.items()):
        if not any("screenshot" in s.calls.lower() or "screenshot" in s.name.lower()
                   for s in ss):
            c.findings.append(Finding(
                c.id, c.what, "warn",
                sorted(s.id for s in ss if s.type == "Recover"),
                observed="this page recovers from an exception but no stage on "
                         "it saves a screenshot",
                required="call Save Screenshot in the recovery path",
                artifact=art, page=page))

    c = add(Check("EXC-EMPTY-DETAIL",
                  "Every Exception stage must log the error detail (exception "
                  "type, detail and stage) before terminating or escalating. A "
                  "blank one gives support a failed item and nothing to act on. "
                  "(v5.0 Process Level Rules - Error Handling.)",
                  "Exception stages", source=f"{V5} - Error Handling"))
    exc = [s for s in stages if s.type == "Exception"]
    c.scanned = len(exc)
    # The detail lives in the stage's own expression/narrative; a stage with
    # neither, and a default name, is a placeholder nobody filled in.
    blank = [s for s in exc if not s.expression and not s.narrative]
    for art in sorted({s.artifact for s in blank}):
        ss = [s for s in blank if s.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "warn", sorted(s.id for s in ss),
            observed=f"{len(ss)} Exception stage(s) carry no detail and no "
                     "narrative",
            required="set an exception detail that names the failure",
            artifact=art))

    # -- Application Modeller (BP Coding Rules v5.0) ------------------------ #
    c = add(Check("ELEMENT-BRITTLE-MATCH",
                  "A spied element is identified by robust attributes. Matching "
                  "on position or ordinal breaks when the window is resized, a "
                  "control is added, or the runtime resolution differs from the "
                  "developer's.",
                  "spied elements with at least one match attribute",
                  source=f"{V5} - Application Modeller"))
    els = elements or []
    c.scanned = len(els)
    weak = [e for e in els
            if set(e.matched_on) & _BRITTLE and not set(e.matched_on) & _STABLE]
    for art in sorted({e.artifact for e in weak}):
        ee = [e for e in weak if e.artifact == art]
        c.findings.append(Finding(
            c.id, c.what, "warn", [],
            observed="; ".join(
                f"{e.name!r} matches only on "
                f"{', '.join(sorted(set(e.matched_on) & _BRITTLE))}"
                for e in ee[:5]),
            required="add a stable attribute (WindowText, ClassName, TypeName, "
                     "AutomationId) to the match",
            artifact=art))
    # Lower severity because the element does carry a stable anchor, but no
    # longer a hedge: the standard (Object Level Rules - Application Modeller)
    # explicitly flags "positional attributes like x, y" and recommends HTML ID,
    # Name or a static Class Name. A match that still leans on x/y/ordinal is a
    # real violation; the stable attribute only softens the blast radius.
    mixed = [e for e in els
             if set(e.matched_on) & _BRITTLE and set(e.matched_on) & _STABLE]
    for art in sorted({e.artifact for e in mixed}):
        ee = [e for e in mixed if e.artifact == art]
        c.findings.append(Finding(
            c.id, "An element's match includes a positional or ordinal "
            "attribute, which the standard flags, alongside a stable one.",
            "info", [],
            observed="; ".join(
                f"{e.name!r} also matches on "
                f"{', '.join(sorted(set(e.matched_on) & _BRITTLE))}"
                for e in ee[:5]),
            required="drop the positional/ordinal attribute from the match and "
                     "rely on HTML ID, Name or a static Class Name",
            artifact=art, confidence="certain"))

    # -- deployment settings (BP Coding Rules v5.0) ------------------------- #
    # Scoped honestly. The standard asks for THREE things at deployment:
    # parameter logging off, object logging Errors Only, process logging Errors
    # Only. Only one of the three leaves a trace in an export - the per-stage
    # <loginhibit/> - so that is the only one checked, and the finding says so
    # rather than implying the deployment was audited.
    c = add(Check("LOG-STAGE-ON-SUCCESS",
                  "A stage that logs on success is silenced before deployment; "
                  "the standard sets Object and Process logging to Errors Only "
                  "and parameter logging off. Full logging in production floods "
                  "the log, slows the bot, and can persist field values.",
                  "stages that emit a log entry on success",
                  source=f"{V5} - deployment logging"))
    loggy = [s for s in stages if s.type in _LOGS_ON_SUCCESS]
    c.scanned = len(loggy)
    noisy = [s for s in loggy if not s.log_inhibit]
    for art in sorted({s.artifact for s in noisy}):
        ss = [s for s in noisy if s.artifact == art]
        tot = len([x for x in loggy if x.artifact == art])
        by_type = Counter(s.type for s in ss)
        c.findings.append(Finding(
            c.id, c.what, "info", sorted(s.id for s in ss),
            observed=f"{len(ss)} of {tot} stage(s) still log on success ("
                     + ", ".join(f"{n} {t}" for t, n in by_type.most_common(4))
                     + ")",
            required="inhibit logging on these stages, and set the object's and "
                     "process's logging to Errors Only with parameter logging "
                     "off at deployment",
            artifact=art, confidence="likely"))

    # -- Global Ignore Value (BP Coding Rules v5.0) -------------------------- #
    c = add(Check("IGNORE-VALUE-ABSENT",
                  f"An object that writes to a screen honours the global "
                  f"'{_IGNORE_VALUE}' marker, so a caller can pass it to leave a "
                  "field untouched. Without it, every optional field needs its "
                  "own decision in every caller.",
                  "artifacts containing a Write stage",
                  source=f"{V5} - Global Ignore Value"))
    writers: dict[str, list[St]] = {}
    for s in stages:
        if s.type == "Write":
            writers.setdefault(s.artifact, []).append(s)
    c.scanned = len(writers)
    for art, ws in sorted(writers.items()):
        hay = " ".join(f"{s.name} {s.expression} {s.initial} {s.steps} {s.narrative}"
                       for s in stages if s.artifact == art)
        if _IGNORE_VALUE.lower() in hay.lower() or _IGNORE_NAMEISH.search(hay):
            continue
        c.findings.append(Finding(
            c.id, c.what, "info", sorted(s.id for s in ws),
            observed=f"{len(ws)} Write stage(s), and neither the literal "
                     f"'{_IGNORE_VALUE}' nor any item named for it appears "
                     "anywhere in this artifact",
            required="define the global ignore value and branch each Write on "
                     "it, so a caller can skip a field",
            artifact=art, confidence="likely"))

    # Stamp each finding with the section of the standard it cites. This is the
    # step prompt 03 wanted a human to do by hand; the full text is now held, so
    # the mapping is code. A check with no mapping (CODE-IN-PROCESS) keeps
    # UNMAPPED, which is the honest answer for a rule the standard does not state.
    for c in checks:
        section = _SECTION.get(c.id)
        if section:
            for f in c.findings:
                if f.rule_section == "UNMAPPED":
                    f.rule_section = section

    return checks


# --------------------------------------------------------------------------- #
def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("export")
    p.add_argument("-o", "--out", default="findings.json")
    p.add_argument("--registry",
                   default=str(Path(__file__).resolve().parent.parent
                               / "data" / "vbo_registry.yaml"))
    p.add_argument("--include-shipped", action="store_true",
                   help="also audit vendor-shipped and engine-internal objects "
                        "(off by default: their code is not yours to fix)")
    args = p.parse_args()

    stages = load(_collect([args.export]))
    if not stages:
        sys.exit("no stages parsed - refusing to report a clean audit of nothing")

    shipped = load_shipped(Path(args.registry))
    skipped = sorted({s.artifact for s in stages if s.artifact.lower() in shipped})
    if not args.include_shipped:
        stages = [s for s in stages if s.artifact.lower() not in shipped]
    if not stages:
        sys.exit(f"every artifact in this export is vendor-shipped ({len(skipped)} "
                 "of them) - there is nothing bank-authored here to audit. "
                 "Re-run with --include-shipped to audit them anyway.")
    elements = [e for e in load_elements(_collect([args.export]))
                if args.include_shipped or e.artifact.lower() not in shipped]
    checks = audit(stages, elements)

    findings = [f for c in checks for f in c.findings]
    doc = {
        "input_scope": f"{args.export}: {len(stages)} stage(s) across "
                       f"{len({s.artifact for s in stages})} artifact(s)",
        "out_of_scope": {
            "artifacts": skipped,
            "why": "vendor-shipped or engine-internal per the VBO registry. "
                   "Blue Prism wrote this code; the bank's standard does not "
                   "govern it and it will not be migrated as code."
        } if skipped and not args.include_shipped else None,
        "standard": {
            "mapped": True,
            "name": "BP Coding Rules v5.0 (Sept 2020)",
            "note": "Checks are mapped against the FULL text of the standard "
                    "(held 2026-07-26). Each finding cites a section by TITLE, "
                    "because the document's own numbering drifts (its content "
                    "list names 12 sections; the body carries 14 headers). Two "
                    "caveats remain: the three CODE-* pattern checks come from "
                    "the team's AUDIT_SKILLS_REFERENCE, not v5.0, and say so; "
                    "and CODE-IN-PROCESS stays UNMAPPED because the standard "
                    "does not state it. Still confirm before acting.",
        },
        "checks_run": [{"rule_id": c.id, "applies_to": c.applies_to,
                        "source": c.source,
                        "scanned": c.scanned, "findings": len(c.findings)}
                       for c in checks],
        "coverage": [{"section": sec, "covered": cov, "checks": ids,
                      "gap": gap} for sec, cov, ids, gap in SECTIONS],
        "findings": [asdict(f) for f in findings],
        "not_auditable": [
            {"rule_section": "queue name equals process name",
             "why": "this export declares its queue by expression, so the "
                    "literal name is not known statically"},
            {"rule_section": "parameter logging off; Object/Process = Errors Only",
             "why": "instance configuration, set at deployment and never "
                    "exported. The per-stage <loginhibit/> IS exported and is "
                    "checked by LOG-STAGE-ON-SUCCESS, but it is a proxy: a clean "
                    "result there does not prove the deployed settings are right"},
            {"rule_section": "each Write BRANCHES on the Global Ignore Value",
             "why": "IGNORE-VALUE-ABSENT proves the marker is present or absent; "
                    "proving every Write actually skips on it needs flow "
                    "analysis this tool does not do"},
            {"rule_section": "anything requiring intent (is this page really "
                             "Business Core, does this handler recover or "
                             "swallow)",
             "why": "reading comprehension - that is the model half of prompt 03"},
        ],
    }
    Path(args.out).write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n",
                              encoding="utf-8")

    print(f"{len(stages)} stage(s), {len({s.artifact for s in stages})} artifact(s)")
    for c in checks:
        flag = "  <-- SCANNED NOTHING" if c.scanned == 0 else ""
        print(f"  {c.id:<26} scanned {c.scanned:>4}  findings {len(c.findings):>2}{flag}")
    sev = {s: sum(1 for f in findings if f.severity == s)
           for s in ("block", "warn", "info")}
    print(f"{len(findings)} finding(s): {sev['block']} block, {sev['warn']} warn, "
          f"{sev['info']} info -> {args.out}")


if __name__ == "__main__":
    main()
