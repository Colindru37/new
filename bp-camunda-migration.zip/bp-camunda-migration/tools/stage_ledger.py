"""Emit the authoritative stage ledger for a page — the ground truth that
`prompts/04-process-spec.md` pastes into the model and then checks against.

The ledger is what turns "is the spec complete?" from a judgement call into set
equality, so it must come from the parser, never from the model.

    python tools/stage_ledger.py <export-dir-or-file>                  # list pages
    python tools/stage_ledger.py <export-dir-or-file> "Artifact"       # list its pages
    python tools/stage_ledger.py <export-dir-or-file> "Artifact" "Page"  # the ledger
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from bp_estate.model import Estate          # noqa: E402
from bp_estate.parse import parse_file      # noqa: E402

_EXTS = (".bpprocess", ".bpobject", ".bprelease", ".xml")


def load(target: Path) -> Estate:
    estate = Estate()
    files = [target] if target.is_file() else sorted(
        p for p in target.rglob("*") if p.suffix.lower() in _EXTS
    )
    if not files:
        sys.exit(f"no Blue Prism exports found under {target}")
    for f in files:
        parse_file(f, estate)
    return estate


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    estate = load(Path(sys.argv[1]))

    if len(sys.argv) == 2:
        for art in estate.artifacts:
            print(f"{art.type:8} {art.name}")
        return

    artifact = sys.argv[2]
    stages = estate.stages_by_artifact.get(artifact)
    if stages is None:
        known = ", ".join(sorted(estate.stages_by_artifact)) or "<none>"
        sys.exit(f"no artifact named {artifact!r}. Known: {known}")

    if len(sys.argv) == 3:
        # Pages a stage actually sits on — including "Main Page", which real
        # exports never declare as a <subsheet>.
        for page in sorted({s.subsheet for s in stages if s.subsheet}):
            n = sum(1 for s in stages if s.subsheet == page)
            print(f"{n:5}  {page}")
        return

    page = sys.argv[3]
    ids = [s.id for s in stages if s.subsheet == page and s.id]
    if not ids:
        pages = ", ".join(sorted({s.subsheet or "?" for s in stages}))
        sys.exit(f"no stages on page {page!r} of {artifact!r}. Pages: {pages}")
    print("\n".join(ids))


if __name__ == "__main__":
    main()
