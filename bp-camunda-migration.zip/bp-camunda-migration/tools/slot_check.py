#!/usr/bin/env python3
"""Run a JavaScript candidate for a Code-stage slot on a live Camunda 7 and
compare its outputs with the oracle's expected.json, case by case.

    python tools/slot_check.py <export(s)> --stage "Square" [--object Calc]
           --js square.js --cases cases.json --expected work/square/expected.json
           [--url http://localhost:8080/engine-rest]

The candidate runs in exactly the shape the emitter gives the slot: a scriptTask
(scriptFormat javascript) with the stage's inputs mapped in by their BP names
and its outputs mapped out by their BP names, inside a throwaway process. One
process instance per case. PASS means every output of every case matches
(numbers compared as numbers, 1e-9 tolerance; everything else exactly).
Stdlib only.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "port"))
import c7_runtime_check as c7  # noqa: E402
import slot_oracle as so        # noqa: E402

JS_TYPE = {"text": "String", "number": "Double", "flag": "Boolean", "date": "String",
           "datetime": "String", "time": "String", "timespan": "String", "password": "String"}


def harness_bpmn(pid: str, js: str, ins, outs) -> str:
    def getv(n):
        return "${execution.getVariable(" + json.dumps(n).replace('"', "'") + ")}"
    io = "".join(f"<camunda:inputParameter name={quoteattr(n)}>{escape(getv(n))}</camunda:inputParameter>"
                 for n, _ in ins)
    io += "".join(f"<camunda:outputParameter name={quoteattr('out:' + n)}>{escape(getv(n))}</camunda:outputParameter>"
                  for n, _ in outs)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" '
        'xmlns:camunda="http://camunda.org/schema/1.0/bpmn" id="slotcheck" '
        'targetNamespace="http://bank.example/bp-migration">\n'
        f'  <bpmn:process id="{pid}" isExecutable="true" camunda:historyTimeToLive="P1D">\n'
        '    <bpmn:startEvent id="s"/><bpmn:sequenceFlow id="f1" sourceRef="s" targetRef="t"/>\n'
        '    <bpmn:scriptTask id="t" name="slot" scriptFormat="javascript">'
        f'<bpmn:extensionElements><camunda:inputOutput>{io}</camunda:inputOutput></bpmn:extensionElements>'
        f'<bpmn:script>{escape(js)}</bpmn:script></bpmn:scriptTask>\n'
        '    <bpmn:sequenceFlow id="f2" sourceRef="t" targetRef="e"/><bpmn:endEvent id="e"/>\n'
        '  </bpmn:process>\n</bpmn:definitions>\n'
    )


def same(a, b) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) <= 1e-9 * max(1.0, abs(float(b)))
    if isinstance(a, (int, float)) and isinstance(b, str):
        try:
            return abs(float(a) - float(b)) <= 1e-9 * max(1.0, abs(float(b)))
        except ValueError:
            return False
    return a == b


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--stage", required=True)
    ap.add_argument("--object")
    ap.add_argument("--js", required=True, help="the JavaScript body for the slot")
    ap.add_argument("--cases", required=True)
    ap.add_argument("--expected", required=True, help="expected.json from slot_oracle.py")
    ap.add_argument("--url", default="http://localhost:8080/engine-rest")
    a = ap.parse_args(argv)

    art, _pi, st = so.find_stage([Path(p) for p in a.inputs], a.stage, a.object)
    ins, outs = so.params(st, "inputs"), so.params(st, "outputs")
    cases = json.loads(Path(a.cases).read_text(encoding="utf-8"))
    expected = json.loads(Path(a.expected).read_text(encoding="utf-8"))
    if len(cases) != len(expected):
        print(f"cases ({len(cases)}) and expected ({len(expected)}) differ in length")
        return 2
    code, _ = c7._req(f"{a.url}/engine")
    if code != 200:
        print(f"no engine at {a.url}")
        return 2
    pid = "slot_" + so.cs_ident(art + "_" + a.stage).lower()
    xml = harness_bpmn(pid, Path(a.js).read_text(encoding="utf-8"), ins, outs)
    ok, msg = c7.deploy(a.url, f"{pid}.bpmn", xml)
    if not ok:
        print(f"deploy FAIL: {msg}")
        return 1
    fails = 0
    for i, (case, want) in enumerate(zip(cases, expected)):
        if "__exception" in want:
            print(f"  case {i}: oracle threw ({want['__exception']}) -- not compared")
            continue
        variables = {}
        for n, t in ins:
            if n in case and case[n] is not None:
                v = case[n]
                variables[n] = {"value": v, "type": JS_TYPE.get(t, "String")}
        ok, inst = c7.start(a.url, pid, variables)
        if not ok:
            print(f"  case {i}: start FAIL {inst}")
            fails += 1
            continue
        done = c7.wait_done(a.url, inst)
        if not done or "incident" in (done or {}):
            print(f"  case {i}: FAIL {(done or {}).get('incident', 'did not finish')}")
            fails += 1
            continue
        got = c7.variables(a.url, inst)
        bad = []
        for n, _ in outs:
            have = got.get("out:" + n)
            if not same(have, want.get(n)):
                bad.append(f"{n}: got {have!r} want {want.get(n)!r}")
        print(f"  case {i}: {'OK' if not bad else 'MISMATCH ' + '; '.join(bad)}")
        fails += bool(bad)
    print("SLOT PASS" if not fails else f"SLOT FAIL: {fails} case(s)")
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
