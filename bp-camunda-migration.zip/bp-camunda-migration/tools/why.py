#!/usr/bin/env python3
"""Why did the emitter treat a stage the way it did? Prints the RAW numbers the
decisions are made from, so a wrong decision can be fixed against real values
instead of guessed at.

    python tools/why.py <exports...> [--max 20] [--stage "Recover7"]

Three sections:
  1. unwired stages (no path from a Start/Recover after preprocessing): for each,
     every XML element anywhere in the export whose text is that stage's id
     (= what links INTO it), as "<stage type 'name'> via <element>"; then a
     histogram of those element names over ALL unwired stages. An element name
     the parser does not read shows up here.
  2. Recovers that got NO Block: the Recover's x/y and every Block on its page
     with x/y/w/h, raw display markup included, and the containment/overlap test
     results.
  3. per page: the Start stages and whether each of their links resolves.
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter, defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "port"))
import bp_core  # noqa: E402
import bp_emit  # noqa: E402


def _loc(t):
    return t.split("}")[-1]


def raw_index(paths):
    """stage id -> (artifact name, stage element); and id -> [(referrer type, referrer name, element path)]"""
    stage_el: dict[str, tuple[str, ET.Element]] = {}
    refs: dict[str, list[tuple[str, str, str]]] = defaultdict(list)
    for p in paths:
        files = [p] if p.is_file() else sorted(p.rglob("*"))
        for f in files:
            if f.suffix.lower() not in (".xml", ".bpobject", ".bpprocess", ".bprelease"):
                continue
            root = bp_core.load_xml(f)
            for art in root.iter():
                if _loc(art.tag) not in ("process", "object") or not art.get("name"):
                    continue
                body = art if any(_loc(c.tag) == "stage" for c in art) else next((c for c in art if _loc(c.tag) == "process"), None)
                if body is None:
                    continue
                for st in body:
                    if _loc(st.tag) != "stage" or not st.get("stageid"):
                        continue
                    stage_el[st.get("stageid")] = (art.get("name"), st)
                    for el in st.iter():
                        if el is st:
                            continue
                        txt = (el.text or "").strip()
                        if len(txt) >= 32 and "-" in txt:          # looks like a stage id
                            refs[txt].append((st.get("type") or "?", st.get("name") or "", _loc(el.tag)))
                        for k, v in el.attrib.items():
                            if len(v) >= 32 and "-" in v:
                                refs[v].append((st.get("type") or "?", st.get("name") or "", f"{_loc(el.tag)}@{k}"))
    return stage_el, refs


def geometry(st: ET.Element) -> str:
    d = next((c for c in st if _loc(c.tag) == "display"), None)
    if d is not None:
        return "<display " + " ".join(f'{k}="{v}"' for k, v in d.attrib.items()) + "/>"
    parts = [f"<{_loc(c.tag)}>{(c.text or '').strip()}" for c in st if _loc(c.tag) in ("displayx", "displayy", "displaywidth", "displayheight")]
    return " ".join(parts) or "(no display markup)"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--max", type=int, default=20, help="unwired stages to detail")
    ap.add_argument("--stage", action="append", default=[], help="also explain this stage by name (repeatable)")
    a = ap.parse_args(argv)
    paths = [Path(p) for p in a.inputs]

    est = bp_core.Estate()
    bp_core.parse_paths(bp_core._collect([str(p) for p in paths]), est)
    stage_el, refs = raw_index(paths)

    hist: Counter = Counter()
    unwired_rows: list[str] = []
    recover_rows: list[str] = []
    start_rows: list[str] = []
    wanted = set(a.stage)
    for art_name, stages in est.stages_by_artifact.items():
        bp_emit._wire_choice_otherwise(stages)
        bp_emit._dissolve_pass_through(stages)
        for page, ps in bp_core._by_page(stages).items():
            by_id = {s.id: s for s in ps if s.id}
            # 1. unwired
            for sid, (typ, name) in bp_emit._unwired(ps).items():
                who = refs.get(sid, [])
                for t, n, el in who:
                    hist[el] += 1
                if not who:
                    hist["(nothing references this id)"] += 1
                if len(unwired_rows) < a.max or name in wanted:
                    src = ", ".join(f"{t} '{n}' via <{el}>" for t, n, el in who[:4]) or "NOTHING references its id"
                    unwired_rows.append(f"  {art_name} / {page}: {typ} '{name}'  <- {src}")
            # 2. recovers without a block
            blocks = [s for s in ps if s.type == "Block"]
            for rc in ps:
                if rc.type != "Recover":
                    continue
                blk = bp_core._enclosing_block(rc, blocks)
                if blk is not None and rc.name not in wanted:
                    continue
                raw = geometry(stage_el[rc.id][1]) if rc.id in stage_el else "?"
                recover_rows.append(f"  {art_name} / {page}: Recover '{rc.name}' x={rc.x} y={rc.y}  raw {raw}  -> block: {blk.name if blk else 'NONE'}")
                for b in blocks:
                    inside = bp_core._contains(b, rc)
                    over = bp_core._overlaps(b, rc) if hasattr(bp_core, "_overlaps") else "n/a"
                    braw = geometry(stage_el[b.id][1]) if b.id in stage_el else "?"
                    recover_rows.append(f"      Block '{b.name}' x={b.x} y={b.y} w={b.w} h={b.h}  raw {braw}  contains={inside} overlaps={over}")
            # 3. starts
            for s in ps:
                if s.type == "Start":
                    bad = [t for t in s.links if t not in by_id]
                    if bad or not s.links:
                        start_rows.append(f"  {art_name} / {page}: Start '{s.name}' links={s.links} unresolved={bad}")

    print(f"== 1. unwired stages: {sum(hist.values())} reference(s) found for them, by element:")
    for el, n in hist.most_common():
        print(f"     {el}: {n}")
    print("   first ones:")
    print("\n".join(unwired_rows) or "   (none)")
    print(f"\n== 2. Recovers with NO enclosing Block (or named with --stage): {sum(1 for r in recover_rows if not r.startswith('      '))}")
    print("\n".join(recover_rows) or "   (none)")
    print(f"\n== 3. Start stages with a missing or unresolved link: {len(start_rows)}")
    print("\n".join(start_rows) or "   (none)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
