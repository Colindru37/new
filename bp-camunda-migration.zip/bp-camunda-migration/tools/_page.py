"""Shared look for the generated documents. Not a CLI.

Every page these tools emit is read by the same people in the same sitting, so
they are one design system, not three that happen to be similar. The palette and
the shell live here; each renderer adds only the components it actually needs.

The one idea worth keeping: **type carries provenance.** Serif is prose a model
wrote. Mono is fact a parser read off the export. A reader can tell at a glance
which words are checkable, which is the whole claim these documents make.
"""
from __future__ import annotations

import html
from datetime import datetime, timezone
from pathlib import Path


def e(x) -> str:
    return html.escape(str(x or ""), quote=True)


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


_LIGHT = """--paper:#f5f6f3; --card:#fffffe; --ink:#15181c; --ink-soft:#5a6169;
  --rule:#dde0da; --rule-firm:#c3c8bf; --seal:#1d4e57;
  --pass:#2f6042; --fail:#8a3227; --flag:#8a6a1c;
  --input:#1d4e57; --press:#8a5a1c; --read:#5a6169; --secret:#8a3227"""

_DARK = """--paper:#131619; --card:#191d21; --ink:#e6e8e4; --ink-soft:#98a0a6;
  --rule:#282d32; --rule-firm:#3a4147; --seal:#79b6c2;
  --pass:#7fc79b; --fail:#e08f84; --flag:#d8b45f;
  --input:#79b6c2; --press:#d8a75f; --read:#98a0a6; --secret:#e08f84"""

# Tokens, then the shell every page shares. Components stay with their renderer.
SHELL = f"""
*,*::before,*::after{{box-sizing:border-box}}
:root{{
  {_LIGHT};
  --mono:ui-monospace,SFMono-Regular,"SF Mono",Consolas,"Liberation Mono",monospace;
  --serif:"Iowan Old Style",Palatino,"Palatino Linotype","Book Antiqua",Georgia,serif;
}}
@media (prefers-color-scheme:dark){{:root{{{_DARK}}}}}
:root[data-theme="dark"]{{{_DARK}}}
:root[data-theme="light"]{{{_LIGHT}}}

html{{-webkit-text-size-adjust:100%}}
body{{margin:0;background:var(--paper);color:var(--ink);font-family:var(--serif);
  font-size:17px;line-height:1.62}}
.wrap{{max-width:42rem;margin:0 auto;padding:3rem 1.25rem 6rem}}
:focus-visible{{outline:2px solid var(--seal);outline-offset:2px}}

/* mono = read off the export by a parser. serif = written by a model. */
.lbl{{font-family:var(--mono);font-size:.68rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft)}}
header{{display:flex;flex-direction:column;gap:.5rem;
  border-bottom:2px solid var(--ink);padding-bottom:1.1rem}}
h1{{font-size:1.9rem;line-height:1.15;margin:0;font-weight:600;
  text-wrap:balance;letter-spacing:-.01em}}
.artifact{{font-family:var(--mono);font-size:.8rem;color:var(--ink-soft);
  word-break:break-word}}
h2{{font-family:var(--mono);font-size:.7rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft);font-weight:500;
  margin:2.75rem 0 .9rem;padding-bottom:.4rem;border-bottom:1px solid var(--rule)}}
.lede{{font-size:1.12rem;line-height:1.55;margin:0 0 1.4rem;text-wrap:pretty}}

dl.meta{{display:grid;grid-template-columns:max-content 1fr;gap:.3rem 1.1rem;
  margin:0;align-items:baseline}}
dl.meta dt{{font-family:var(--mono);font-size:.68rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft)}}
dl.meta dd{{margin:0;font-size:.95rem}}

.scroll{{overflow-x:auto}}
table{{border-collapse:collapse;width:100%;font-size:.9rem}}
th,td{{text-align:left;padding:.45rem .7rem .45rem 0;
  border-bottom:1px solid var(--rule);vertical-align:top}}
th{{font-family:var(--mono);font-size:.68rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft);font-weight:500;white-space:nowrap}}
td.num{{font-family:var(--mono);font-variant-numeric:tabular-nums;
  text-align:right;white-space:nowrap;padding-right:0}}

ul.plain{{margin:0;padding-left:1.1rem}}
ul.plain li{{margin:.25rem 0}}
code{{font-family:var(--mono);font-size:.86em}}
footer{{margin-top:3.5rem;padding-top:1rem;border-top:1px solid var(--rule);
  font-family:var(--mono);font-size:.72rem;line-height:1.65;color:var(--ink-soft)}}
"""

# The verification banner. Shared because the verdict must look identical
# wherever it appears - a reader should recognise it without reading it.
SEAL = """
.seal{display:flex;align-items:center;gap:1.1rem;margin:1.75rem 0 2.25rem;
  border:1px solid var(--rule-firm);border-left:4px solid var(--mark);
  background:var(--card);padding:1.05rem 1.2rem}
.seal.is-pass{--mark:var(--pass)}
.seal.is-fail{--mark:var(--fail)}
.frac{font-family:var(--mono);font-variant-numeric:tabular-nums;
  font-size:1.85rem;line-height:1;color:var(--mark);white-space:nowrap;
  font-weight:600;margin:0}
.frac small{font-size:.95rem;opacity:.7}
.seal-txt{display:flex;flex-direction:column;gap:.2rem;min-width:0}
.seal-txt strong{font-family:var(--mono);font-size:.72rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--mark)}
.seal-txt span{font-size:.92rem;color:var(--ink-soft);line-height:1.45}
.seal-list{margin:.55rem 0 0;padding:0;list-style:none;
  font-family:var(--mono);font-size:.76rem;color:var(--fail);word-break:break-word}
.seal-list li{margin:.2rem 0}
@media (max-width:34rem){.seal{flex-direction:column;align-items:flex-start;gap:.6rem}}

ul.checks{margin:0;padding:0;list-style:none;font-family:var(--mono);
  font-size:.79rem;line-height:1.5;display:flex;flex-direction:column;gap:.3rem}
ul.checks li{display:grid;grid-template-columns:1.4rem 1fr;gap:.5rem;
  color:var(--ink-soft);word-break:break-word}
ul.checks li::before{content:"OK";color:var(--pass)}
ul.checks li.no::before{content:"NO";color:var(--fail)}
ul.checks li.no{color:var(--fail)}
ul.checks li.wa::before{content:"??";color:var(--flag)}
ul.checks li.wa{color:var(--flag)}
"""


def seal(passed: bool, got: int, total: int, head: str, why: str,
         fails: list[str]) -> str:
    o = [f'<div class="seal {"is-pass" if passed else "is-fail"}">',
         f'<p class="frac">{got}<small>/{total}</small></p>',
         '<div class="seal-txt">',
         f"<strong>{e(head)}</strong><span>{e(why)}</span>"]
    if fails:
        o.append('<ul class="seal-list">' +
                 "".join(f"<li>{e(m)}</li>" for m in fails) + "</ul>")
    o.append("</div></div>")
    return "\n".join(o)


def checks(oks: list[str], warns: list[str], fails: list[str]) -> str:
    o = ['<h2>Checks run</h2><ul class="checks">']
    o += [f"<li>{e(m)}</li>" for m in oks]
    o += [f'<li class="wa">{e(m)}</li>' for m in warns]
    o += [f'<li class="no">{e(m)}</li>' for m in fails]
    o.append("</ul>")
    return "\n".join(o)


def audit(page: str) -> None:
    """Assert the page is a page before anyone is told it is one.

    Twice now a renderer has produced a file that was described to a reader
    without being looked at: once with its stylesheet clobbered by a variable
    reassignment, once with a `(head, body)` tuple interpolated into the body
    so the whole document was a Python repr. Both files had plausible byte
    counts and a `<style>` tag, which is exactly why neither was caught.

    So the writer checks its own output, every time. These are structural
    facts, not taste - if one fails the file is not a page and must not ship.
    """
    for probe, why in (
        ("<title>", "no title"),
        ("<style>", "no stylesheet"),
        ('<div class="wrap"', "no content shell - the body is not page markup"),
    ):
        if probe not in page:
            raise AssertionError(f"refusing to write: {why}")
    css = page.split("<style>", 1)[1].split("</style>", 1)[0]
    if len(css) < 2000:
        raise AssertionError(f"refusing to write: stylesheet is {len(css)} bytes, "
                             "so it is not the shell - something clobbered it")
    if "\\n" in page:
        raise AssertionError("refusing to write: literal backslash-n in the "
                             "output - a container was interpolated as a string")


def write(out: Path, title: str, css: str, body: str, fragment: bool = False) -> None:
    if not isinstance(body, str):
        raise TypeError(f"body must be str, got {type(body).__name__} - "
                        "a render() returning a tuple silently becomes a repr")
    head = f"<title>{e(title)}</title>\n<style>{SHELL}{css}</style>"
    if fragment:
        page = f"{head}\n{body}\n"
    else:
        page = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
                '<meta name="viewport" content="width=device-width,initial-scale=1">\n'
                f"{head}\n</head>\n<body>\n{body}\n</body>\n</html>\n")
    audit(page)
    out.write_text(page, encoding="utf-8")
