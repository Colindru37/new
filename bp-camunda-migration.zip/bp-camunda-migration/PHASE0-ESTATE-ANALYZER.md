# Phase 0 — Estate Analyzer — Specification

**Status:** Draft v0.1
**Companion to:** `DESIGN.md`
**Position in pipeline:** runs **once** across the entire Blue Prism export set,
**before** any per-process conversion. Produces the map and backlog everything
else depends on.

---

## 1. Purpose

Handed one XML at a time, no tool (and no LLM) can see the estate. At >20
processes, the estate's *coupling* — shared objects, shared queues, shared
credentials, environment locks — is where naive per-file migration fails
silently. Phase 0 builds a complete, deterministic **fact base** of the estate
and derives from it: a dependency graph, a shared-resource map, a blocker
census, dead-code and duplicate-logic findings, complexity/risk scores, and a
proposed migration wave order.

**Phase 0 does not convert anything.** It reads, models, and reports.

## 2. Inputs

- `.bprelease` — package XML containing many processes, objects, work-queue defs, environment variables, calendars.
- `.bpprocess` — single process XML.
- `.bpobject` — single VBO XML.
- Optionally: multiple releases (e.g. successive exports) → version reconciliation (§9).

Processes and objects share the same underlying XML schema (a `<process>` root
with `<stage>` children); an object is a process with `type="object"` plus an
`<appdef>` (Application Modeler) section.

**Rule:** accept the raw exports as ground truth. Never require the analyst to
pre-annotate. Never silently skip an unparseable artifact — fail with the exact
file + XPath location.

## 3. Outputs (deliverables)

| Artifact | Format | Contents |
|---|---|---|
| `estate.json` | JSON | The normalized fact base (§6) — the source of truth for downstream tools |
| `callgraph.graphml` / `.dot` | Graph | Visualizable dependency graph |
| `estate-report.md` (+ html) | Human | Executive summary: counts, top shared objects, blockers, dead code, duplicate clusters, wave plan |
| `blockers.csv` | Tabular | Every blocker with precise location (artifact ▸ page ▸ stage) |
| `shared-resources.csv` | Tabular | Every object/queue/credential/env-var/lock used by >1 consumer |
| `waves.md` | Human | Proposed migration order with rationale |
| `unresolved.csv` | Tabular | References that could not be statically resolved (external deps, dynamic names) |

All outputs are **deterministic**: same input → byte-identical output (stable
sort order everywhere).

## 4. The fact base — what it extracts

### 4.1 Artifacts
Per process and per object: `id` (GUID/preferredid), `name`, `version`,
`bpversion`, `type` (process|object), `narrative`, page list, stage count.

### 4.2 Pages (subsheets)
Every subsheet (Main Page + named pages). Stages are tagged with their owning
subsheet. Page-reference stages define intra-artifact call edges.

### 4.3 Stages
Per stage: `id`, `name`, `type`, `subsheet`, outbound links
(`onsuccess`/`ontrue`/`onfalse`/ordered choice links), `inputs`/`outputs`
(data-item refs + expressions). **Every stage type is enumerated and
classified** — no "other" bucket without a report entry.

### 4.4 Data
- **Data items:** name, datatype, scope (private/local vs session-exposed), initial value, always-init flag.
- **Collections:** field definitions; flag PII-suspect field names (§7.5).
- **Environment variables:** name, type, value, referenced-by set.
- **Startup parameters:** each process's Main Page start-stage inputs.

### 4.5 References (edges)
- Process/Object → **Object.Action** (Action stage `object` + `action`).
- Process → **its own pages** (page-reference stages).
- Object → **Object.Action** (VBOs call other VBOs too).
- Anything → **work queue** / **credential** / **environment lock** / **calendar** (via internal-VBO recognition, §7).

### 4.6 Blocker-bearing constructs
- **Code stages:** language (C#/VB), LOC, per-stage.
- **Object-level `<references>`:** external DLLs + namespaces + global code.
- **Application Modeler elements:** count + spy-mode mix (win32/UIA/AA/HTML/region/surface), dynamic-attribute params → automation fragility proxy.
- **Exception constructs:** Exception/Recover/Resume counts, thrown exception types, recovery scopes.
- **Wait/timing:** Wait stages + timeouts.
- **Unstructured back-links:** links that jump to an already-passed stage → non-reducible cycles (§7.6).

## 5. Analyses performed

1. **Call graph.** Resolve every Action reference to its target object+action.
   Compute per-node **fan-in** (how many consumers — shared-blast-radius) and
   **fan-out** (god-process detector) and dependency **depth**.
2. **Shared-resource map.** Any object/queue/credential/env-var/lock used by >1
   consumer → a migration coupling point (migrate the shared thing once, or you
   fork it). This is the single most important Phase-0 output at scale.
3. **Dead-code detection.** Unreachable stages (no inbound path from a Start),
   unreferenced pages, unused data items, **orphan objects** (no process calls
   them), unused env vars/queues. Candidates to drop, not migrate.
4. **Duplicate / near-duplicate logic.** Normalize expression strings and stage
   subgraphs; hash and cluster. Surfaces the same idiom implemented N ways →
   consolidate *before* migrating (avoids N inconsistent BPMN translations).
5. **Blocker census.** All of §4.6, aggregated and located — the manual-work backlog.
6. **Complexity & risk scoring** (§8).
7. **Migration wave planning.** Topological order by dependency + score; propose
   waves (leaf / low-risk / low-coupling first).

## 6. Estate model schema (sketch)

```
Estate
 ├─ artifacts[]      { id, name, version, bpversion, type, pages[], stageCount, narrative }
 ├─ dataItems[]      { artifact, name, datatype, scope, initialValue, alwaysInit }
 ├─ collections[]    { artifact, name, fields[], piiSuspect }
 ├─ envVars[]        { name, type, value, referencedBy[] }
 ├─ queues[]         { name, keyField, maxAttempts, encrypted, usedBy[], dynamicName }
 ├─ credentials[]    { name, requestedBy[], dynamicName }
 ├─ envLocks[]       { name, lockedBy[], dynamicName }
 ├─ edges[]          { from(artifact/page), to(object.action|page|queue|cred|lock), kind, resolved }
 ├─ blockers[]       { artifact, page, stage, kind, detail, severity }
 ├─ appModel[]       { object, elementCount, spyModes{}, dynamicParams, fragilityScore }
 ├─ duplicates[]     { clusterId, members[], normalizedHash }
 ├─ deadCode[]       { artifact, kind(stage|page|dataitem|object|queue|envvar), ref }
 ├─ unresolved[]     { from, ref, reason(external|dynamic|missing) }
 └─ scores[]         { artifact, complexity, risk, coupling, wave }
```

## 7. Detection rules — the parts a naive parser gets wrong

### 7.1 Internal business objects vs shipped VBOs vs custom VBOs
Blue Prism ships three tiers, and they migrate differently:

| Tier | Examples | Migration meaning |
|---|---|---|
| **Internal business objects** (engine-provided, no VBO XML) | `Work Queues`, `Credentials`, `Environment - Locking`, `Calendars`, `Session` | Map to **Camunda features/connectors**, not re-hosted |
| **Shipped/standard VBOs** (have XML, may contain code) | `MS Excel VBO`, `MS Outlook Email VBO`, `Utility - Strings/Date/Collection`, `Data - SQL/OLEDB`, `Web Services` | Map to **connectors / libraries** where possible |
| **Custom VBOs** | project objects with Application Modeler + code | **Re-host or replace-with-API** — the real work |

The analyzer must **classify every referenced object into one of these tiers**,
because tier drives the migration path. Recognition is by canonical object name
**and** action signature — with a warning if an internal-VBO name looks renamed
or localized (do not assume English names survived; flag ambiguity, never guess).

### 7.2 Work queues
Recognized via Action stages targeting the `Work Queues` internal object
(`Add To Queue`, `Get Next Item`, `Mark Completion`, `Mark Exception`,
`Defer`, …). Extract the **queue name from the input expression**. If the name
is a data item / expression, not a literal → **`dynamicName: true`**, added to
`unresolved` (can't statically map). Capture retry semantics (max attempts) —
critical for the retry ≠ Zeebe-retry and idempotency risks in DESIGN.md.

### 7.3 Credentials
Recognized via the `Credentials` internal object (`Get`, etc.). Extract the
credential **name**; dynamic name → flag. Feeds the vault-mapping requirement.

### 7.4 Environment locks
Recognized via `Environment - Locking` (`Lock`/`Unlock`). Extract the **lock
token/name**. These have **no native Camunda equivalent** (external distributed
lock needed) and are easy to miss — this is exactly the kind of thing that
silently causes resource contention post-migration.

### 7.5 PII-suspect collections
Static heuristic only: flag collection fields whose names match PII patterns
(name/dob/iban/account/card/ssn/cnp/address/…). Not authoritative — a **review
flag**, feeding the data-residency/history concern.

### 7.6 Unstructured back-links
Detect links whose target is a stage already reachable earlier on the same path
(non-reducible cycle, i.e. not a clean Loop Start/End). These are the ones that
produce deadlocking/token-leaking BPMN. Count and locate them per artifact —
they're a top complexity driver and a manual-review trigger.

### 7.7 Dynamic action targets
If an Action stage's target object/action is itself computed (rare but exists)
→ `unresolved: dynamic`. If the target object is not present in the export set
→ `unresolved: missing` (external/global dependency = blocker).

## 8. Scoring

**Complexity (per artifact)** — weighted sum, weights tunable:
`stageCount`, `pageCount`, `objectFanOut`, `codeStageCount × LOC` (heavy),
`appModelElementCount × fragility`, `exceptionDepth`, `queueInvolvement`,
`backLinkCount` (heavy), `dataItemCount`, `globalDataUsage`.

**Risk (per artifact, bank-weighted)** — presence of: decimal/money
calculations, date/calendar/cut-off logic, credential usage, PII-suspect
collections, idempotency-sensitive queue ops, environment locks.

**Coupling (per artifact)** — fan-in of the objects/queues/creds it shares with
the rest of the estate (blast radius of touching it).

**Process-tree score** — roll artifact scores up the call graph so a "simple"
process that depends on a monster object inherits the monster's weight.

## 9. Edge cases & failure handling

- **Malformed / partial XML** → fail with exact file + XPath. Never skip silently.
- **Multiple versions of the same object** across releases → reconcile: prefer latest, but **report version conflicts** (a process may pin an older action signature).
- **Referenced object absent** → `unresolved: missing`, treated as an external dependency blocker.
- **Localized / renamed internal VBOs** → signature-based fallback recognition + warning.
- **Encrypted queues / `Password` items** → note; never attempt to read secret values.
- **Circular object references** → detect and report; do not infinite-loop.
- **Very large releases** → streaming/SAX parse; bounded memory.

## 10. Non-negotiable properties

1. **Deterministic** — no LLM in the core; same input → identical output. Stable ordering on every list.
2. **Complete accounting** — every artifact, page, stage, data item, and reference is either modeled or explicitly listed in `unresolved`/`blockers`. **Zero silent drops.**
3. **Read-only** — Phase 0 mutates nothing and converts nothing.
4. **Explainable** — every score and every classification traces back to the raw stage(s) that produced it.

**LLM (optional, edges only):** naming duplicate clusters, drafting the
human-readable narrative of `estate-report.md`. Never for classification,
resolution, or scoring.

## 11. Acceptance criteria

- Parses the full export set with zero silent skips; all failures precisely located.
- Call graph resolves or explicitly flags (`unresolved`) **every** action reference.
- Shared-resource map lists every >1-consumer object/queue/credential/env-var/lock.
- Blocker census enumerates every code stage, DLL reference, environment lock, dynamic name, and non-reducible cycle with location.
- Dead-code and duplicate-cluster reports produced.
- Complexity/risk/coupling scores computed per artifact and rolled up the call graph.
- Wave plan is a valid topological ordering consistent with the dependency graph.
- Re-running on the same input reproduces byte-identical outputs.

## 12. What Phase 0 unblocks

- **Wave planning** for the strangler-fig rollout (leaf/low-risk first).
- **Effort estimation** (blocker census + complexity scores).
- **Consolidation** decisions (duplicate clusters) before conversion.
- **The per-process converter**, which consumes `estate.json` instead of re-parsing raw XML and re-discovering context.
```
