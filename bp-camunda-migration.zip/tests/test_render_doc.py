"""The 05 process-documentation renderer, in the bank's house layout.

The layout is not ours - it is the format the team already generates and accepts
(overview, object dependencies, user stories, configuration). What IS ours, and
what these tests pin, is the three things laid on top of it: a completeness seal,
screenshot SLOTS instead of broken images, and configuration tables that are read
from the parser rather than written by the model. A renderer that quietly drops
any of those has removed the only reason to prefer it over the tool they already
run, so each is asserted directly.
"""
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

import render_doc as R  # noqa: E402
from _page import write  # noqa: E402
from bp_estate.model import DataItem, EnvVar, Estate  # noqa: E402


def _v(**over):
    """A passing verdict with empty config, overridable per test."""
    base = {"passed": True, "oks": ["section ledger balances"], "warns": [],
            "fails": [], "got": 6, "total": 6, "env_config": [], "session_vars": []}
    base.update(over)
    return base


def _doc(**over):
    d = {
        "artifact": "PROC-A - <PROCESS-A NAME>",
        "purpose": "Uploads KYC datasheets into the corresponding case in APP-A.",
        "trigger": "a scheduled run",
        "applications_used": [
            {"name": "APP-A", "how": "UI automation",
             "used_for": "reading the case and routing it", "steps": ["1"]},
            {"name": "APP-B", "how": "UI automation",
             "used_for": "downloading the datasheets", "steps": ["4"]},
        ],
        "processes_used": [{"name": "DB ORINOCO - General", "used_for": "login"}],
        "queues_used": [{"name": "Robotics_RR_Datasheet", "role": "both"}],
        "credentials_used": ["APP-A-Service"],
        "user_stories": [
            {"id": "US1", "title": "Process Initialization & Queue Population",
             "narrative": "As a robot, I must initialise and populate the queue.",
             "data_fetched": ["Application credentials", "Environment settings"]},
            {"id": "US2", "title": "Case Data Reading & Business Rule Verification",
             "narrative": "As a robot, for each case I must read and check it.",
             "data_fetched": ["Vorgangsnummer", "FKN"]},
        ],
        "steps": [
            {"id": "1", "title": "Launch APP-A", "detail": "Log in.",
             "application": "APP-A", "screenshot_required": True,
             "screenshot_shows": "the APP-A login screen",
             "spec_sections": ["Main Page/S1"], "on_failure": "UNKNOWN",
             "user_story": "US1"},
            {"id": "2", "title": "Populate work queue",
             "detail": "Read the worklist and enqueue items.",
             "application": "APP-A", "screenshot_required": False,
             "screenshot_shows": None, "spec_sections": ["Main Page/S2"],
             "on_failure": "the run aborts", "user_story": "US1"},
            {"id": "3", "title": "Open case and read data",
             "detail": "Extract key fields.", "application": "APP-A",
             "screenshot_required": True,
             "screenshot_shows": "the main customer data screen",
             "spec_sections": ["Read/S1"], "on_failure": "UNKNOWN",
             "user_story": "US2"},
        ],
        "not_documented": [{"spec_section": "Main Page/S9", "why": "a diagram anchor"}],
    }
    d.update(over)
    return d


def _render(doc=None, v=None):
    return R.render(doc or _doc(), v or _v(), "doc.json")


# --- the house layout is adopted ---------------------------------------------

def test_kyc_section_order():
    """Overview -> dependencies -> user stories -> configuration, in that order."""
    html = _render()
    pos = [html.find(h) for h in (
        "Process overview", "Object dependencies",
        "User stories &amp; automation steps",
        "Additional information &amp; configuration")]
    assert all(p != -1 for p in pos), pos
    assert pos == sorted(pos), "sections are out of the house order"


def test_dependencies_are_cards_grouped_by_application():
    html = _render()
    assert html.count('class="dep"') >= 3           # 2 apps + objects + queues...
    assert "APP-A" in html and "APP-B" in html
    assert "Objects &amp; processes used" in html


def test_user_stories_group_steps_with_narrative_and_data_fetched():
    html = _render()
    assert "US1: Process Initialization" in html
    assert "US2: Case Data Reading" in html
    assert "As a robot, I must initialise" in html    # narrative
    assert "Data to be fetched" in html and "Vorgangsnummer" in html


def test_step_numbering_restarts_per_story():
    """Each story gets its own <ol>, so US2 starts at 1 again - as the house doc
    does. One flat <ol> would number US2's first step 3."""
    html = _render()
    assert html.count('<ol class="steps">') == 2


# --- our three things, each asserted so a regression is caught ---------------

def test_seal_leads_the_page():
    html = _render()
    assert 'class="seal' in html
    assert html.find('class="seal') < html.find("Process overview")


def test_screenshot_is_a_slot_never_a_broken_image():
    html = _render()
    assert "<img" not in html                          # the whole point
    assert 'class="shot"' in html
    assert "the APP-A login screen" in html          # the instruction survives
    assert "2 of 3 steps need a capture" in html       # the running count


def test_slot_shows_the_z_filename_convention():
    """The team filters captures in a dropdown by app name in the filename, so the
    slot must state the expected Z: name - and it must carry the application."""
    html = _render()
    assert 'class="fname"' in html and "on Z:" in html
    assert "APP-A - login screen.png" in html        # app-prefixed, de-duped


@pytest.mark.parametrize("app,shows,title,expect", [
    ("APP-A", "the APP-A login screen", "Launch", "APP-A - login screen.png"),
    ("NOS", "the search results by FKN", "x", "NOS - search results by FKN.png"),
    ("APP-B", None, "Download datasheet", "APP-B - Download datasheet.png"),
    ("none", "a confirmation dialog", "x", "confirmation dialog.png"),  # no app
    ("APP-A", 'a path C:\\a/b:c screen', "x", "APP-A - path Cabc screen.png"),  # illegal chars stripped
])
def test_shot_filename_convention(app, shows, title, expect):
    assert R.shot_filename(app, shows, title) == expect


def test_shot_filename_carries_app_for_dropdown_filter():
    """Teodor's actual requirement: the app name is IN the name, always."""
    assert R.shot_filename("APP-A", "x", "y").startswith("APP-A - ")


def test_config_tables_are_rendered_and_labelled_as_parser_fact():
    v = _v(env_config=[{"name": "BizBanking Error Log Storage", "type": "text",
                        "value": "D:/logs", "refs": 3}],
           session_vars=[{"name": "Robot Working Time", "datatype": "Number",
                          "initial": "60"}])
    html = _render(v=v)
    assert "Environment configuration" in html
    assert "Process inputs / session variables" in html
    assert "BizBanking Error Log Storage" in html and "D:/logs" in html
    assert "Robot Working Time" in html
    assert "read from the export by the parser" in html   # provenance note


def test_empty_config_says_none_not_nothing():
    html = _render()                                    # default v has empty config
    assert "No environment variables are read" in html
    assert "defines no session variables" in html


# --- degrade + safety --------------------------------------------------------

def test_flat_steps_when_no_user_stories():
    """Backward compatible: a doc without user_stories still renders every step."""
    html = _render(doc=_doc(user_stories=[]))
    assert html.count('<ol class="steps">') == 1
    assert "Launch APP-A" in html and "Open case and read data" in html


def test_orphan_step_is_shown_never_dropped():
    """A step whose user_story matches no story must not silently vanish."""
    doc = _doc()
    doc["steps"][2]["user_story"] = "US_TYPO"           # matches no story
    html = _render(doc=doc)
    assert "Other steps" in html
    assert "Open case and read data" in html


def test_render_is_a_valid_page(tmp_path):
    """write() audits its own output; a body missing the shell raises. This is the
    guard that twice caught a stylesheet-less page being described as a page."""
    out = tmp_path / "doc.html"
    write(out, "t", R.SEAL + R._CSS, _render())
    page = out.read_text(encoding="utf-8")
    assert "<title>" in page and "<style>" in page and 'class="wrap"' in page


# --- the mechanical half: config comes from the parser, secrets withheld -----

def test_config_from_estate_reads_session_items_and_env_vars():
    est = Estate()
    art = "PROC-A - <PROCESS-A NAME>"
    est.data_items = [
        DataItem(artifact=art, name="Robot Working Time", datatype="Number",
                 scope="session", initial_value="60"),
        DataItem(artifact=art, name="scratch", datatype="Text",
                 scope="local", initial_value="x"),          # local -> excluded
        DataItem(artifact="Other", name="foreign", datatype="Text",
                 scope="session", initial_value="y"),         # other artifact
    ]
    est.env_vars = [EnvVar(name="Log Directory", type="text", value="D:/logs",
                           referenced_by=[art])]
    env, sess = R._config_from_estate({"artifact": art}, est)
    assert [r["name"] for r in sess] == ["Robot Working Time"]   # only session, this art
    assert sess[0]["initial"] == "60"
    assert [r["name"] for r in env] == ["Log Directory"]
    assert env[0]["value"] == "D:/logs" and env[0]["refs"] == 1


def test_config_withholds_secret_values():
    est = Estate()
    art = "A"
    est.data_items = [DataItem(artifact=art, name="ApiPassword", datatype="Password",
                               scope="session", initial_value="hunter2")]
    est.env_vars = [EnvVar(name="Service Secret", type="text", value="s3cr3t",
                           referenced_by=[art])]
    env, sess = R._config_from_estate({"artifact": art}, est)
    assert sess[0]["initial"] == "[hidden]" and "hunter2" not in str(sess)
    assert env[0]["value"] == "[hidden]" and "s3cr3t" not in str(env)


@pytest.mark.parametrize("token", ["<img", "![", "src="])
def test_no_image_markup_anywhere(token):
    assert token not in _render()
