"""Render a verified 05 step-documentation record as a single HTML page.

    python tools/render_doc.py <doc.json> <export> --specs <spec-dir> [-o out.html]

The layout mirrors the documentation the bank team already generates and accepts
(overview -> object dependencies grouped by application -> user stories with
steps -> environment/session configuration), so a reviewer reads it without
relearning where things live. Three things are laid on top of that house style,
and they are the reason this generator is worth having:

  1. Provenance by type. Mono is fact a parser read off the export; serif is
     prose the model wrote. A reader can see which claims are checkable. The two
     configuration tables are rendered from the parser, never from the model -
     the model cannot get a datatype or an environment-variable name wrong if it
     never supplies them.
  2. Real screenshot SLOTS, not broken images. A missing capture reads as an
     outstanding task with the exact instruction attached ("show the payment
     confirmation number"), which is actionable, plus a running count of how many
     are still owed - never an <img> that renders as a defect in the document.
  3. A completeness verdict at the top. This is the deliverable non-engineers
     read, so a confident omission does the most damage here; the page leads with
     the section-ledger seal, computed by the same checks as everything else.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import verify_llm_output as V   # noqa: E402
from _page import SEAL, checks, e, seal, stamp, write   # noqa: E402

# An environment variable's *value* is config, not a secret - but a name that
# advertises a secret should never have its value printed just in case.
_SECRET_NAME = re.compile(r"(?i)(password|secret|credential|token|api[_-]?key|apikey|pwd)")


def _config_from_estate(doc: dict, estate) -> tuple[list[dict], list[dict]]:
    """The two configuration tables, read off the export by the parser.

    They are NOT asked of the model: a datatype or an env-var name is a fact the
    parser already holds, and prose invented over facts is exactly what this
    pipeline exists to distrust. Password values are withheld here as they are
    everywhere else.
    """
    artl = (doc.get("artifact") or "").strip().lower()
    env = sorted(
        (ev for ev in estate.env_vars
         if any((r or "").strip().lower() == artl for r in (ev.referenced_by or []))),
        key=lambda ev: (ev.name or "").lower())
    env_config = [
        {"name": ev.name or "",
         "type": ev.type or "",
         "value": "[hidden]" if _SECRET_NAME.search(ev.name or "") else (ev.value or ""),
         "refs": len(ev.referenced_by or [])}
        for ev in env]

    sess = sorted(
        (di for di in estate.data_items
         if (di.artifact or "").strip().lower() == artl
         and (di.scope or "").lower() == "session"),
        key=lambda di: (di.name or "").lower())
    session_vars = [
        {"name": di.name or "",
         "datatype": di.datatype or "",
         "initial": "[hidden]" if (di.datatype or "").lower() == "password"
                    else (di.initial_value or "")}
        for di in sess]
    return env_config, session_vars


def verdict(doc: dict, export: str, specs: list[Path]) -> dict:
    V._oks.clear(); V._warns.clear(); V._fails.clear()
    estate, haystack = V.load_export(export)
    truth = V.load_spec_sections(specs) if specs else None
    stages = V.check_stageids(doc, estate)
    V.check_stage_ledger(doc, estate, stages)
    V.check_section_ledger(doc, truth)
    V.check_verbatim(doc, haystack)
    V.check_secrets(doc, estate)

    claimed = {s for st in doc.get("steps") or []
               for s in (st.get("spec_sections") or [])}
    claimed |= {n.get("spec_section") for n in doc.get("not_documented") or []
                if n.get("spec_section")}
    env_config, session_vars = _config_from_estate(doc, estate)
    return {"passed": not V._fails, "oks": list(V._oks), "warns": list(V._warns),
            "fails": list(V._fails),
            "got": len(claimed), "total": len(truth) if truth else len(claimed),
            "env_config": env_config, "session_vars": session_vars}


_CSS = """
/* object dependencies: cards grouped by application, house style */
.deps{display:flex;flex-direction:column;gap:.5rem;margin:.4rem 0 0}
.dep{background:var(--card);border:1px solid var(--rule);
  border-left:3px solid var(--seal);padding:.7rem .95rem;font-size:.95rem;
  line-height:1.5}
.dep b{font-weight:600}
.dep .how{font-family:var(--mono);font-size:.66rem;letter-spacing:.1em;
  text-transform:uppercase;color:var(--seal);margin-left:.4rem}
.dep .ml{font-family:var(--mono);font-size:.82rem;color:var(--ink-soft);
  word-break:break-word}

/* user stories: a serif arc heading over a per-story restarted step list */
h3.us{font-family:var(--serif);font-size:1.16rem;font-weight:600;
  margin:2.1rem 0 .35rem;text-wrap:balance;line-height:1.3}
.us-narr{font-style:italic;color:var(--ink-soft);margin:.15rem 0 .7rem}
.fetch-lbl{font-family:var(--mono);font-size:.66rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft);margin:.7rem 0 .2rem}
h3.sub{font-family:var(--mono);font-size:.7rem;letter-spacing:.14em;
  text-transform:uppercase;color:var(--ink-soft);font-weight:500;
  margin:1.7rem 0 .6rem}
.prov{font-family:var(--mono);font-size:.72rem;color:var(--ink-soft);
  margin:.7rem 0 0;line-height:1.5}

ol.steps{list-style:none;counter-reset:s;margin:0;padding:0;
  display:flex;flex-direction:column;gap:.55rem}
ol.steps>li{counter-increment:s;display:grid;grid-template-columns:2.15rem 1fr;
  gap:0 .85rem;background:var(--card);border:1px solid var(--rule);
  padding:1rem 1.15rem}
ol.steps>li::before{content:counter(s,decimal-leading-zero);
  font-family:var(--mono);font-variant-numeric:tabular-nums;font-size:.8rem;
  color:var(--seal);padding-top:.15rem}
.steps h4{grid-column:2;margin:0 0 .3rem;font-size:1.06rem;font-weight:600;
  line-height:1.3;text-wrap:balance}
.steps p{grid-column:2;margin:0}
.steps .fail{grid-column:2;margin:.55rem 0 0;font-size:.92rem;
  color:var(--ink-soft);padding-left:.7rem;border-left:2px solid var(--rule-firm)}
.steps .fail b{font-family:var(--mono);font-size:.68rem;letter-spacing:.14em;
  text-transform:uppercase;font-weight:500;display:block;margin-bottom:.15rem}
.shot{grid-column:2;margin:.7rem 0 0;padding:.6rem .75rem;
  border:1px dashed var(--flag);color:var(--flag);
  font-family:var(--mono);font-size:.74rem;line-height:1.5}
.shot b{letter-spacing:.14em;text-transform:uppercase;font-size:.66rem;
  font-weight:500;display:block;margin-bottom:.2rem;opacity:.85}
.shot .fname{display:block;margin-top:.4rem;opacity:.85}
.shot .fname code{color:var(--flag);font-size:.9em}
.tags{grid-column:2;margin:.7rem 0 0;display:flex;flex-wrap:wrap;gap:.3rem}
.tag{font-family:var(--mono);font-size:.7rem;border:1px solid var(--rule-firm);
  padding:.1rem .45rem;color:var(--ink-soft);white-space:nowrap}
.tag.app{border-color:var(--seal);color:var(--seal)}
.tag.unknown{border-color:var(--flag);color:var(--flag)}
@media (max-width:34rem){
  ol.steps>li{grid-template-columns:1fr}
  ol.steps>li::before{grid-column:1;margin-bottom:.3rem}
  .steps h4,.steps p,.steps .fail,.shot,.tags{grid-column:1}
}
.none{color:var(--ink-soft);font-size:.92rem;margin:0}
"""


def shot_filename(app: str | None, shows: str | None, title: str | None) -> str:
    """The expected capture filename on the Z: drive.

    The team stores screenshots on Z: and needs the application name IN the
    filename - it is how they filter the capture in the add-to-context dropdown
    (Teodor, 02-Jun). So the convention is `<Application> - <what it shows>.png`,
    derived here rather than asked of the model: a filename is a mechanical fact,
    and one the human needs to be exact to find the right image.
    """
    label = (shows or title or "screenshot").strip()
    label = re.sub(r"^(the|a|an)\s+", "", label, flags=re.I).strip()
    app = (app or "").strip()
    app = "" if app.lower() == "none" else app
    # avoid "APP-A - APP-A login screen" when the caption already names the app
    if app and label.lower().startswith(app.lower()):
        label = label[len(app):].lstrip(" -").strip() or "screenshot"
    label = re.sub(r'[\\/:*?"<>|]+', "", label)          # illegal filename chars
    label = re.sub(r"\s+", " ", label).strip().rstrip(".")
    if len(label) > 50:
        label = label[:50].rstrip()
    return f"{app} - {label}.png" if app else f"{label}.png"


def _steps_html(steps: list[dict]) -> str:
    """One <ol> so numbering restarts per user story, matching the house doc."""
    o = ['<ol class="steps">']
    for st in steps:
        o.append("<li>")
        o.append(f"<h4>{e(st.get('title'))}</h4>")
        o.append(f"<p>{e(st.get('detail'))}</p>")
        fail = st.get("on_failure")
        if fail and fail != "UNKNOWN":
            o.append(f'<p class="fail"><b>If it fails</b>{e(fail)}</p>')
        elif fail == "UNKNOWN":
            o.append('<p class="fail"><b>If it fails</b>UNKNOWN - the '
                     "specification does not say. A human must confirm this.</p>")
        if st.get("screenshot_required"):
            fname = shot_filename(st.get("application"),
                                  st.get("screenshot_shows"), st.get("title"))
            o.append('<div class="shot"><b>Screenshot required</b>'
                     f"{e(st.get('screenshot_shows') or 'not specified')}"
                     f'<span class="fname">on Z: <code>{e(fname)}</code></span>'
                     "</div>")
        tags = []
        app = st.get("application")
        if app and app != "none":
            tags.append(f'<span class="tag app">{e(app)}</span>')
        n = len(st.get("spec_sections") or [])
        tags.append(f'<span class="tag">{n} spec section'
                    f'{"s" if n != 1 else ""}</span>')
        o.append(f'<div class="tags">{"".join(tags)}</div>')
        o.append("</li>")
    o.append("</ol>")
    return "\n".join(o)


def render(doc: dict, v: dict, source: str) -> str:
    o = ['<div class="wrap">', "<header>",
         '<p class="lbl">Process documentation</p>',
         f"<h1>{e(doc.get('artifact') or 'Untitled')}</h1>", "</header>"]
    a = o.append

    # --- our thing #3: the completeness verdict leads the page ------------- #
    if v["passed"]:
        head, why = "Verified complete", (
            "Every section of every page specification is accounted for below. "
            "Nothing was dropped and nothing was invented.")
    else:
        head, why = "Do not trust this document", (
            "This document does not account for the whole process. Regenerate "
            "it - do not patch it by hand.")
    a(seal(v["passed"], v["got"], v["total"], head, why, v["fails"]))

    # --- process overview -------------------------------------------------- #
    a("<h2>Process overview</h2>")
    if doc.get("purpose"):
        a(f'<p class="lede">{e(doc["purpose"])}</p>')
    if doc.get("trigger"):
        a('<dl class="meta"><dt>Starts when</dt>'
          f"<dd>{e(doc['trigger'])}</dd></dl>")

    # --- object dependencies: cards grouped by application ----------------- #
    apps = doc.get("applications_used") or []
    procs = doc.get("processes_used") or []
    qs = doc.get("queues_used") or []
    creds = doc.get("credentials_used") or []
    if apps or procs or qs or creds:
        a("<h2>Object dependencies</h2>")
        a('<div class="deps">')
        for ap in apps:
            how = f'<span class="how">{e(ap.get("how"))}</span>' if ap.get("how") else ""
            a(f'<div class="dep"><b>{e(ap.get("name"))}</b>{how}<br>'
              f'{e(ap.get("used_for"))}</div>')
        if procs:
            names = ", ".join(e(p.get("name")) for p in procs)
            a(f'<div class="dep"><b>Objects &amp; processes used</b><br>'
              f'<span class="ml">{names}</span></div>')
        if qs:
            names = ", ".join(f"{e(q.get('name'))} ({e(q.get('role'))})" for q in qs)
            a(f'<div class="dep"><b>Work queues</b><br>'
              f'<span class="ml">{names}</span></div>')
        if creds:
            names = ", ".join(e(c) for c in creds)
            a(f'<div class="dep"><b>Credentials</b> '
              '<span class="how">names only</span><br>'
              f'<span class="ml">{names}</span></div>')
        a("</div>")

    # --- user stories & automation steps ----------------------------------- #
    steps = doc.get("steps") or []
    stories = doc.get("user_stories") or []
    shots = [s for s in steps if s.get("screenshot_required")]
    if steps:
        a("<h2>User stories &amp; automation steps</h2>")
        if stories:
            placed: set[str] = set()
            for us in stories:
                usid = us.get("id")
                label = f"{e(usid)}: {e(us.get('title'))}" if usid else e(us.get("title"))
                a(f'<h3 class="us">{label}</h3>')
                if us.get("narrative"):
                    a(f'<p class="us-narr">{e(us["narrative"])}</p>')
                df = us.get("data_fetched") or []
                if df:
                    a('<p class="fetch-lbl">Data to be fetched</p><ul class="plain">')
                    for d in df:
                        a(f"<li>{e(d)}</li>")
                    a("</ul>")
                grp = [s for s in steps if s.get("user_story") == usid]
                placed.update(id(s) for s in grp)
                a(_steps_html(grp))
            # a step whose user_story matches no story is shown, never dropped
            orphan = [s for s in steps if id(s) not in placed]
            if orphan:
                a('<h3 class="us">Other steps</h3>')
                a(_steps_html(orphan))
        else:
            a(_steps_html(steps))

    if shots:
        a("<h2>Screenshots still to capture</h2>")
        a(f'<p class="none">{len(shots)} of {len(steps)} steps need a capture. '
          "Static analysis cannot take these - each needs a run or a person with "
          "the application open. What must be visible is stated on each step "
          "above.</p>")

    # --- additional information & configuration (parser fact, not prose) --- #
    env_config = v.get("env_config") or []
    session_vars = v.get("session_vars") or []
    a("<h2>Additional information &amp; configuration</h2>")

    a('<h3 class="sub">Environment configuration</h3>')
    if env_config:
        a('<div class="scroll"><table><thead><tr><th>Variable</th><th>Type</th>'
          "<th>Value</th><th>Used by</th></tr></thead><tbody>")
        for r in env_config:
            a(f'<tr><td><code>{e(r["name"])}</code></td><td>{e(r["type"])}</td>'
              f'<td><code>{e(r["value"])}</code></td>'
              f'<td class="num">{r["refs"]}</td></tr>')
        a("</tbody></table></div>")
    else:
        a('<p class="none">No environment variables are read by this process.</p>')

    a('<h3 class="sub">Process inputs / session variables</h3>')
    if session_vars:
        a('<div class="scroll"><table><thead><tr><th>Name</th><th>Data type</th>'
          "<th>Initial value</th></tr></thead><tbody>")
        for r in session_vars:
            a(f'<tr><td><code>{e(r["name"])}</code></td>'
              f'<td>{e(r["datatype"])}</td>'
              f'<td><code>{e(r["initial"])}</code></td></tr>')
        a("</tbody></table></div>")
    else:
        a('<p class="none">This process defines no session variables.</p>')

    a('<p class="prov">Both tables are read from the export by the parser, not '
      "written by the model - a name, a datatype or a value here is a fact, not "
      "a description.</p>")

    # --- accounted-for-but-not-described, then the checks ------------------ #
    nd = doc.get("not_documented") or []
    if nd:
        a("<h2>Accounted for, not described</h2>")
        a('<div class="scroll"><table><thead><tr><th>Specification</th>'
          "<th>Why no step covers it</th></tr></thead><tbody>")
        for x in nd:
            a(f"<tr><td><code>{e(x.get('spec_section'))}</code></td>"
              f"<td>{e(x.get('why'))}</td></tr>")
        a("</tbody></table></div>")

    a(checks(v["oks"], v["warns"], v["fails"]))
    a(f"<footer>Generated from <code>{e(Path(source).name)}</code>, "
      f"{stamp()}.<br>No part of this page was written by hand. "
      "Regenerate it; never edit it.</footer></div>")
    return "\n".join(o)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("doc")
    p.add_argument("export")
    p.add_argument("--specs", nargs="*", default=[])
    p.add_argument("-o", "--out", default=None)
    p.add_argument("--fragment", action="store_true")
    args = p.parse_args()

    specs: list[Path] = []
    for raw in args.specs:
        q = Path(raw)
        specs.extend(sorted(q.glob("*.json")) if q.is_dir() else [q])
    if not specs:
        print("warning: no --specs given, so the section ledger cannot detect a "
              "dropped section - the verdict below is weaker than it looks")

    doc = V.load_answer(Path(args.doc))
    v = verdict(doc, args.export, specs)
    out = Path(args.out or Path(args.doc).with_suffix(".html"))
    write(out, f"{doc.get('artifact')} - process documentation",
          SEAL + _CSS, render(doc, v, args.doc), fragment=args.fragment)
    print(f"{'PASS' if v['passed'] else 'FAIL'} {v['got']}/{v['total']} -> {out}")
    sys.exit(0 if v["passed"] else 1)


if __name__ == "__main__":
    main()
