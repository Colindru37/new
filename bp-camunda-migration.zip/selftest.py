#!/usr/bin/env python3
"""Proves this copy is byte-faithful (line endings ignored) and the tools work.
Run BEFORE restoring placeholders:
    python selftest.py            # hashes + the five --selftest runs
    python selftest.py --hashes   # hashes only
"""
import hashlib, json, subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parent
MANIFEST = json.loads((root / "selftest.manifest.json").read_text())
bad = 0
for rel, h in sorted(MANIFEST.items()):
    p = root / rel
    if not p.exists():
        print("MISSING", rel); bad += 1; continue
    if hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest() != h:
        print("DIFFERS", rel); bad += 1
print(f"{len(MANIFEST) - bad}/{len(MANIFEST)} files match")
if "--hashes" in sys.argv:
    sys.exit(1 if bad else 0)
for rel in ("port/bp_core.py", "port/bp_full.py", "port/bp_emit.py", "port/bp_equiv.py", "tools/bpmn_lint.py"):
    cwd = root / "port" if rel.startswith("port") else root
    r = subprocess.run([sys.executable, str(root / rel), "--selftest"], capture_output=True, text=True, cwd=str(cwd))
    line = (r.stdout.strip().splitlines() or [r.stderr.strip()[-200:]])[-1]
    print(f"{rel}: {line}")
    bad += "PASS" not in line
print("SELFTEST PASS" if not bad else "SELFTEST FAIL")
sys.exit(1 if bad else 0)
