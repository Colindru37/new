# Radar — flight recorder for Blue Prism objects (prototype, 2026-10-20)

Problem (bank): heavy processes log Errors Only. A Write stage dies and the log has the error but not
the value it was writing; the team flips logging to full and waits for the failure to repeat.
Radar keeps a bounded in-memory trail and, only when something fails, writes one incident folder:
exception type/stage/detail, every data item on the failing page (the write's input, taken at the
instant of failure from the Recover block), the trail that led there, and a screenshot.

## Layout
```
core/Radar.cs          the recorder: static ring (Record), Dump -> incident.txt + incident.json (+ screenshot.png)
core/RadarSelfTest.cs  console self-test of the core (mcs/mono, C# 5 like BP code stages)
core/build.sh          compile + run the self-test                       -> SELF-TEST PASS
bp/gen_radar.py        rpa-bp generator: Radar VBO + Radar Demo Bank UI object + PRC000 demo process
bp/out/                importable XML: Radar VBO, Radar Demo Bank (instrumented), Demo Bank Plain (untouched),
                       House Logging (Radar inside), PRC000 Write Failure Demo, PRC000 House Logging Demo
bp/out_plain/          House Logging exactly as today (no Radar), for the A/B run
bp/run_test.py         the run gate: bprun executes the XML with a doubled Application Modeller,
                       Amount textbox missing -> Enter Amount dies -> dump; then a clean run -> no dump
bp/preview/            page SVGs (layout review)
bp/work/               incidents + bprun.log from the last run_test
```
Gates (all green on the dev machine): `core/build.sh`, `validate.py out --flow --estate --strict`
(ALL CLEAN), `compile_check.py out` (ALL COMPILED, mono = indicative), `run_test.py` (22/22); self-test covers two concurrent sessions on one resource.

## Radar VBO actions
| Action | Inputs | Output |
|---|---|---|
| Configure Radar | Root Folder (text, empty = %TEMP%\Radar), Capacity (number, 0 = keep 50) | |
| Record Event | Label, Detail | |
| Dump Incident | Process, Page, Exception Type/Detail/Stage, Data Items ("name=value" lines), Capture Screen | Dump Folder (or `ERROR: ...`, never throws) |
| Get Trail | | Trail (text, oldest first) |

## How an object is instrumented (see Radar Demo Bank / Enter Transfer)
1. `Record Event` before every stage: page entry with inputs, each write with the value it is about to write, each navigate with the element, each read with the value read back. In-memory append, no I/O.
2. The fallible stages sit in a work Block whose Recover captures type/detail/stage
   (recovery mode), calls `Dump Incident` with every page data item plus the inline write
   expressions as text, then rethrows preserving the exception. The bot's behaviour is unchanged.
3. The Data Items expression is mechanical: name + value for each data item on the page, and
   `expr:<stage>/<step>=<expression text>` for each Write step. This is what an instrument pass
   over the release XML (bp_core parser) would generate automatically; here it is hand-written.

## Two ways in (both generated, both run)
**Route A, no process changes (the one to pitch):** Radar lives INSIDE the house logging object.
Estate processes already call `Save Event` for progress and, from their Recover handlers, for
errors with the captured type/detail/stage. `bp/out/BPA Object - House Logging.xml` is a stand-in
for that object with Radar inside (every event -> Record; an Error event -> Dump);
`bp/out_plain/` is the same object as it is today. `run_test.py` runs the SAME process XML and the
SAME untouched UI object against both: plain = no incident, Radar inside = incident folder.
One object re-released, zero process edits. What you get: the trail of everything the processes
already log, the exception, the screenshot. What you do not get: per-write values or the page
data items at failure (the logging object never sees them).

**Route B, instrumented objects (per process, when it matters):** Record before every stage and
Dump from the object's own Recover with its page data items (`Radar Demo Bank`). Full detail,
but every instrumented process is a new release. Do it for the handful of processes that hurt.

Their real house logging object is `<HOUSE_LOG_OBJECT>.Save Event` per the estate conventions;
the stand-in's interface is a guess until we see the real one.

## The real case (2026-10-22): API answers HTML, JSON parse dies
The team's actual artefact is a "BPA Partial Session Log" CSV (Errors Only): one row per failing
stage, `ERROR: Internal : ...` in Result, and the parameter columns (Direction/Name/Type/Value)
EMPTY. `Demo API` + `PRC000 - Radar - API Failure Demo` reproduce that case: the API (doubled by the
`Demo API Response` Environment Variable) returns an HTML error page, JSON To Customer dies. The dump
carries the response text in the data items and a `response[0..300]=` trail line recorded BEFORE the
parse: the exact thing the CSV lacks. The process logs through House Logging (Radar inside) AND the
object is instrumented, so the same exception reaches Dump twice; Radar dedupes to one folder
(same detail+stage within 120 s). Same-millisecond folder names get a `~2` suffix.

Decision 2026-10-22: present BOTH routes. A (instrumented objects) for the investigation detail,
B (Radar in the house logging object) for zero process re-release; they combine.

## Logistics (decided 2026-10-20)
- Target = a network share (UNC) set once as the `Radar Root Folder` Environment Variable; the
  reporting DB is out. Dumps land in `<share>\<resource machine>\<time>_<process>_<stage>`, so the
  Control Room row (time, resource, stage) finds the folder without any link.
- One ring per session: resources run concurrent sessions, so the ring is keyed by the calling
  thread (one session = one runner thread). Verify on the first BP run that every action call of
  a session arrives on the same thread; if not, key by an explicit Session input instead.
- Optional later: tag the work queue item with the dump path (Work Queues 'Tag Item').
- Compliance questions to pre-empt: who reads the share, retention by folder age, screenshot as an
  opt-in flag per process, masking rules for named data items (none of these built yet).
- Adoption path that touches no process: put Record inside the estate's house logging action and
  Dump inside its Log Error action; one object re-release instead of 200. Loses page data items
  at failure until the instrument pass adds a Data Items input per process.

## What is proven and what is not
- Proven here: ring semantics, dump contents, never-throw, ring cleared after dump, nothing
  written on a clean run, the Recover-driven capture of the write's input at failure time.
- Simulated: the Write failure text (`Internal : Failed to perform step 1 in Write Stage ...`)
  is bprun's imitation of Blue Prism's. Get one real log line from the team to confirm the shape.
- Not proven: the screenshot (Windows only: user32 GetSystemMetrics + GDI CopyFromScreen;
  on Linux it reports `skipped (not Windows)`), Blue Prism's own compiler, import, and that
  a resource running non-interactively has a desktop to capture. First BP run answers these.
- Open items: PRC000 is the placeholder process prefix; Demo Bank elements must be spied after
  import; the Data Items text is built with NewLine() concatenation (fine for a page, an
  instrument pass should cap very long collections).
