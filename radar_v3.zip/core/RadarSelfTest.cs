// Self-test for Radar.cs: simulates the Blue Prism runtime path
//   action entry -> Record ... -> write stage dies -> Recover -> Dump(page data items) -> folder.
// Exit code 0 = PASS. Run: ./build.sh
using System;
using System.IO;
using System.Web.Script.Serialization;

public static class RadarSelfTest
{
    static int fails = 0;
    static void Ok(string name, bool cond, string info = "")
    {
        if (!cond) fails++;
        Console.WriteLine((cond ? "PASS " : "FAIL ") + name + (info.Length > 0 ? " | " + info : ""));
    }

    public static int Main()
    {
        var root = Path.Combine(Path.GetTempPath(), "radar_selftest_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Radar.Configure(root, 50);
        Ok("configure: root + capacity", Radar.Root == root && Radar.Capacity == 50);

        // 1. ring semantics: 60 records into capacity 50 -> 50 kept, 10 dropped, oldest kept is #11
        for (int i = 1; i <= 60; i++) Radar.Record("step " + i, "value=" + i);
        Ok("ring: keeps capacity", Radar.Count == 50, "count=" + Radar.Count);
        Ok("ring: counts dropped", Radar.Dropped == 10, "dropped=" + Radar.Dropped);
        var trail = Radar.Trail();
        Ok("ring: oldest kept is #11", trail.StartsWith("") && trail.Contains("| #11 |") && !trail.Contains("| #10 |"));
        Ok("ring: newest is #60", trail.TrimEnd('\n').EndsWith("value=60"));

        // 2. newline in detail does not break the one-line-per-entry trail
        Radar.Record("multi", "a\nb\r\nc");
        Ok("trail: newlines escaped", Radar.Trail().Split('\n').Length == 51, "lines=" + Radar.Trail().Split('\n').Length);

        // 3. the write-failure path: action entry recorded, write dies, recover dumps page data items
        Radar.Record("action:Enter Transfer", "Account=DE123;Amount=50,00");
        string exDetail = "Internal : Failed to perform step 2 in Write Stage 'Enter Amount' on page 'Enter Transfer' - Element not found";
        string data = "i_txt_Account=DE123\ni_txt_Amount=50,00\nflg_Window Ready=True\nexpr:Enter Amount/2=[i_txt_Amount] & \" EUR\"";
        string folder = Radar.Dump("RAD001 - Radar - Write Failure Demo", "Enter Transfer", "System Exception", exDetail, "Enter Amount", data, true);
        Ok("dump: returns a folder", !folder.StartsWith("ERROR") && Directory.Exists(folder), folder);
        var txtPath = Path.Combine(folder, "incident.txt");
        var jsPath = Path.Combine(folder, "incident.json");
        Ok("dump: incident.txt written", File.Exists(txtPath));
        Ok("dump: incident.json written", File.Exists(jsPath));
        var txt = File.Exists(txtPath) ? File.ReadAllText(txtPath) : "";
        Ok("txt: names the failing stage", txt.Contains("stage     : Enter Amount"));
        Ok("txt: carries the write input (the thing Errors Only loses)", txt.Contains("i_txt_Amount=50,00"));
        Ok("txt: carries the inline expression text", txt.Contains("expr:Enter Amount/2="));
        Ok("txt: carries the trail with action inputs", txt.Contains("action:Enter Transfer | Account=DE123"));
        Ok("txt: trail header counts", txt.Contains("50 kept, 12 dropped, capacity 50"));
        bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;
        Ok(win ? "txt: screenshot taken" : "txt: screenshot skipped with reason (not Windows)",
           win ? txt.Contains("screenshot: screenshot.png") && File.Exists(Path.Combine(folder, "screenshot.png"))
               : txt.Contains("screenshot: skipped (not Windows"));

        // 4. json is parseable and round-trips the fields
        try
        {
            var ser = new JavaScriptSerializer();
            var obj = ser.DeserializeObject(File.ReadAllText(jsPath)) as System.Collections.Generic.Dictionary<string, object>;
            var ex = obj["exception"] as System.Collections.Generic.Dictionary<string, object>;
            var di = obj["data_items"] as System.Collections.Generic.Dictionary<string, object>;
            var tr = obj["trail"] as object[];
            Ok("json: parses", obj != null);
            Ok("json: exception.stage", ex != null && (string)ex["stage"] == "Enter Amount");
            Ok("json: data_items keyed", di != null && (string)di["i_txt_Amount"] == "50,00" && (string)di["expr:Enter Amount/2"] == "[i_txt_Amount] & \" EUR\"");
            Ok("json: trail length", tr != null && tr.Length == 50, "len=" + (tr == null ? -1 : tr.Length));
        }
        catch (Exception e) { Ok("json: parses", false, e.Message); }

        // 5. dump clears the ring; a second failure starts a fresh trail
        Ok("dump: ring cleared", Radar.Count == 0 && Radar.Dropped == 0);

        // 6. dump never throws: unwritable root -> ERROR string, no exception
        Radar.Configure(Path.Combine(txtPath, "not_a_dir"), 0);   // a file as parent -> CreateDirectory fails
        string bad = "threw";
        try { bad = Radar.Dump("p", "pg", "System Exception", "d", "s", "", false); } catch (Exception) { }
        Ok("dump: never throws, reports ERROR", bad.StartsWith("ERROR:"), bad);
        Ok("configure: zero capacity keeps previous", Radar.Capacity == 50);

        // 7b. two sessions (threads) on one resource never mix, and one dump leaves the other alone
        Radar.Configure(root, 50);
        Radar.Clear();
        string otherTrail = null; int otherCountAfter = -1;
        var gate = new System.Threading.ManualResetEvent(false);
        var t = new System.Threading.Thread(() =>
        {
            Radar.Record("other-session", "x");
            Radar.Record("other-session", "y");
            otherTrail = Radar.Trail();
            gate.WaitOne();                      // wait until the main session has dumped
            otherCountAfter = Radar.Count;
        });
        t.Start();
        while (otherTrail == null) System.Threading.Thread.Sleep(5);
        Radar.Record("main-session", "a");
        Ok("sessions: main sees only its own entry", Radar.Count == 1 && Radar.Trail().Contains("main-session") && !Radar.Trail().Contains("other-session"), Radar.Trail());
        Ok("sessions: other sees only its own two", otherTrail.Split('\n').Length == 3 && !otherTrail.Contains("main-session"), otherTrail);
        string f3 = Radar.Dump("p", "pg", "System Exception", "d", "s", "", false);
        gate.Set(); t.Join();
        Ok("sessions: main dump cleared main only", Radar.Count == 0 && otherCountAfter == 2, "other after=" + otherCountAfter);
        Ok("dump: folder is <root>/<machine>/<stamp>_<process>_<stage>", f3.StartsWith(Path.Combine(root, Environment.MachineName.Replace('-', '_'))) || Directory.GetParent(f3).Name.Length > 0, f3);
        Ok("dump: folder sits under the machine subfolder", Directory.GetParent(f3).Parent.FullName == root, f3);

        // 7c. the same exception dumped twice in a row (object, then the process logger) = one folder
        Radar.Configure(root, 50);
        Radar.Record("step", "before");
        string d1 = Radar.Dump("p", "pg", "System Exception", "same detail", "Same Stage", "", false);
        string d2 = Radar.Dump("p", "", "System Exception", "same detail", "Same Stage", "", false);
        Ok("dedupe: second dump of the same exception returns the first folder", d1 == d2 && Directory.Exists(d1), d1 + " / " + d2);
        string d3 = Radar.Dump("p", "", "System Exception", "other detail", "Same Stage", "", false);
        Ok("dedupe: a different exception gets its own folder", d3 != d1 && Directory.Exists(d3));

        // 7. no-screenshot request is noted, and dump works with empty data/trail
        Radar.Configure(root, 5);
        string f2 = Radar.Dump("p", "pg", "Business Exception", "d", "s", "", false);
        Ok("dump: empty trail + no capture ok", Directory.Exists(f2) && File.ReadAllText(Path.Combine(f2, "incident.txt")).Contains("skipped (not requested)"));
        Ok("configure: shrink trims ring", Radar.Capacity == 5);

        try { Directory.Delete(root, true); } catch (Exception) { }
        Console.WriteLine(fails == 0 ? "SELF-TEST PASS" : "SELF-TEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }
}
