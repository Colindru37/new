# Radar core self-test, in-process via Add-Type (no binary is produced or started).
# Run in Windows PowerShell 5.1 from this folder:  powershell -ExecutionPolicy Bypass -File .\RadarSelfTest.ps1
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -Path (Join-Path $here 'Radar.cs'), (Join-Path $here 'RadarSelfTest.cs') `
         -ReferencedAssemblies 'System.Drawing', 'System.Web.Extensions', 'System.Core' `
         -Language CSharp
$rc = [RadarSelfTest]::Main()
Write-Host ("exit code " + $rc)
