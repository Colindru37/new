"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "0ffcfe26d50606fa8f43c8e6d25d1d161f8f751b55c76bb9e565c29eb88f9d64",
 "README.md": "3cb6348c17e32ff658b31638cb80b16975f13023adda2ae772eb5f5913e35edd",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Demo Bank Plain.xml": "712c9ba2dfc9f683fd495e63f21e858bc46f05d764a4428c5bb6260163b3e401",
 "bp/BPA Object - House Logging.xml": "c7da6b6b01550a1945821b5fe93e3a6e8afda142e938328773afdfa487d93d7a",
 "bp/BPA Object - Radar Demo Bank.xml": "cce187e98c9f3ac5ca1d8498367126458ceb73e8384cd4b778282c61f45adc6f",
 "bp/BPA Object - Radar.xml": "c29a358a0cdc2a0d1c572c4cbd2e85a185d5b2716404fd5b8f42e0def46e7e54",
 "bp/BPA Process - PRC000 - Radar - API Failure Demo.xml": "f7c140e3e53388a8d44fb1d6bfe7e40a2c9a3703f80abc4702f8c9711dabeac7",
 "bp/BPA Process - PRC000 - Radar - House Logging Demo.xml": "4ecf9ede3530ebaac689a8069af49682388fde61cf25ab6aacd7332fe0884f4e",
 "bp/BPA Process - PRC000 - Radar - Write Failure Demo.xml": "746eab6f06a70a6e453aed18f3f98c2de58fcb238cc9a4c092187ad9f6385c97",
 "core/Radar.cs": "3a8c22614597192083b60ad50a7d0a6980f97e34c34940c530a4bf60a728d23e",
 "core/RadarSelfTest.cs": "449a19b3335a083cac564869a028494ddde6f3ade3fd47d2fb1ffbe78a75e5f9",
 "core/RadarSelfTest.ps1": "21e6074afc6c5e08d8f8cf8c02db0c38c0130e6b559b12d0e2c9088c10263e77",
 "tools/bpwatch.ps1": "1305795f15318748b88264aa9d7842680d62077f90e635034deac77b024aabe7"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
