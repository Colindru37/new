# Radar on the Blue Prism machine

Nothing here produces or starts a binary. C# runs in-process through PowerShell Add-Type or inside Blue Prism.

1. `python selftest.py`: proves every file arrived intact.
2. `powershell -ExecutionPolicy Bypass -File core\RadarSelfTest.ps1`: compiles the core in-process and runs the self-test.
   Expect SELF-TEST PASS and, on Windows, a real screenshot.png in the temp incident folder (unverified item 1).
3. With the rpa-bp skill: `python lib/compile_check.py <this>/bp --ref-dir "<Blue Prism install dir>"` (unverified item 2).
4. Import. By hand, in this order: Radar, House Logging, Demo Bank Plain, Radar Demo Bank, Demo API, then the three
   PRC000 processes. Or on a DEV environment: `powershell -ExecutionPolicy Bypass -File tools\bpwatch.ps1 -Folder <inbox> -SSO -Once`
   after copying bp\*.xml into <inbox> (objects import before processes automatically; see the tools\bpwatch.ps1 header).
5. System Manager -> Environment Variables: `Radar Root Folder` (text; a UNC share or a local folder for the first run),
   `Demo API Response` (text; `{"id":"C1","name":"Ana Pop"}` for a clean run, any HTML for the failure).
6. Radar Demo Bank / Demo Bank Plain: Application Modeller elements exist by name but are unspied. For the first run
   you do not need a real app: run PRC000 - Radar - API Failure Demo first (no UI).
7. Run PRC000 - Radar - API Failure Demo with HTML in the variable -> one folder under <root>\<machine>\...
   Open incident.txt. Then run it with the JSON value -> no folder.
8. Verify: the real Write-failure message text (unverified 3) by letting Radar Demo Bank fail on an unspied element;
   one ring per session (unverified 4) by running two sessions on one resource and checking the trails do not mix.

House Logging here is a STAND-IN for the estate house logging object; the Radar calls inside it are what moves
into the real one.
