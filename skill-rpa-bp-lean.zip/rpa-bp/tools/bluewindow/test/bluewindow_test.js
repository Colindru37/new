// bluewindow test: the round trip is exact when nothing changes; every edit lands in the XML and only there;
// the result validates ALL CLEAN; versions and diff work; the page embeds everything.
const fs = require('fs'), path = require('path'), os = require('os');
const D = require('../bpdraw'), E = require('../bpedit'), BW = require('../bluewindow');
let fails = 0;
const ok = (n, c, info) => { if (!c) fails++; console.log((c ? 'PASS ' : 'FAIL ') + n + (info ? ' | ' + info : '')); };
const OUT = path.join(__dirname, '..', '..', '..', '..', '..', 'radar', 'bp', 'out');
const src = path.join(OUT, 'BPA Object - Demo API.xml');
const xml = fs.readFileSync(src, 'utf8');

// 0. the browser scripts parse (bpui is never required by node, a truncated file would still pass everything below)
for (const f of ['bpdraw.js', 'bpedit.js', 'bpui.js']) { let okp = true; try { new Function(fs.readFileSync(path.join(__dirname, '..', f), 'utf8')); } catch (e) { okp = false; } ok(f + ' parses', okp, null); }

// 1. identity round trip
const m0 = E.modelFrom(xml);
ok('round trip without edits is byte-identical', E.serialize(m0) === xml, null);

// 2. edits
const m = E.modelFrom(xml);
const byName = n => m.stages.find(s => s.name === n && !s.deleted);
const call = byName('Call API'), dec = byName('Succeeded?'), parse = byName('Parse Customer'), rec = byName('Record Customer Name');
E.move(call, call.x + 90, call.y + 15);
E.move(byName('Record Get Customer Entry'), byName('Record Get Customer Entry').x + 30, byName('Record Get Customer Entry').y);   // a pure move: lands in 'moved', not 'changed'
E.rename(dec, 'Response Parsed?');
E.setField(dec, 'decision', '[Error Text] = "" AND [Customer Name] <> ""');
E.setField(call, 'in:Customer ID', '"C2"');
E.setField(parse, 'out:Customer Name', 'Customer Name');
E.setField(parse, 'narrative', 'Parses the <json> & stores it');
const raise = byName('Raise Error'); E.setField(raise, 'exception', { type: 'Business Exception', detail: '"API said: " & [Error Text]' });
const dat = byName('Customer Name'); E.setField(dat, 'initialvalue', 'n/a');
// relink: Parse Customer -> End directly, drop Record Customer Name
const end = m.stages.find(s => s.type === 'End' && s.page === 'Get Customer Name');
E.setLink(parse, 'onsuccess', end.id);
E.remove(m, rec);
const out = E.serialize(m);
const bp = D.parseBp(out);
const g = n => bp.stages.find(s => s.name === n);
ok('moved stage has the new display', /x="105" y="45"/.test(g('Call API').body) || D.geom(g('Call API').body).x === call.x, D.geom(g('Call API').body).x + ',' + D.geom(g('Call API').body).y);
ok('renamed decision keeps its id', g('Response Parsed?') && g('Response Parsed?').id === dec.id, null);
ok('decision expression rewritten and escaped', /<decision expression="\[Error Text\] = &quot;&quot; AND \[Customer Name\] &lt;&gt; &quot;&quot;" \/>/.test(g('Response Parsed?').body), null);
ok('input value rewritten by name', /<input [^>]*name="Customer ID"[^>]*expr="&quot;C2&quot;"/.test(g('Call API').body), null);
ok('output store rewritten by name', /<output [^>]*name="Customer Name"[^>]*stage="Customer Name"/.test(g('Parse Customer').body), null);
ok('narrative inserted and escaped', /<narrative>Parses the &lt;json&gt; &amp; stores it<\/narrative>/.test(g('Parse Customer').body), null);
ok('exception type + detail rewritten', /<exception [^>]*type="Business Exception"[^>]*detail="&quot;API said: &quot; &amp; \[Error Text\]"/.test(g('Raise Error').body), g('Raise Error').body.match(/<exception [^>]*\/>/)[0]);
ok('data item initial value set', /<initialvalue>n\/a<\/initialvalue>/.test(g('Customer Name').body), null);
ok('deleted stage is gone', !g('Record Customer Name'), null);
ok('relinked stage points at End', D.tag(g('Parse Customer').body, 'onsuccess').trim() === end.id, null);
ok('no link points at the deleted stage', !out.includes('>' + rec.id + '<'), null);
const untouched = m.stages.filter(s => !s.deleted && !Object.keys(s.edits).length);
ok('untouched stages are byte-identical', untouched.every(s => out.includes(`<stage stageid="${s.id}" name="${s.orig.name.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}" type="${s.type}">${s.orig.body}</stage>`)), untouched.length + ' stages');
ok('the rest of the file is untouched', out.slice(0, out.indexOf('<stage ')) === xml.slice(0, xml.indexOf('<stage ')), null);

// 3. rules
const r0 = E.checkRules(m0);
ok('clean export passes the rules', !r0.some(x => x.level === 'error'), JSON.stringify(r0.filter(x => x.level === 'error')));
const mr = E.modelFrom(xml); const d2 = mr.stages.find(s => s.name === 'Succeeded?'); E.rename(d2, 'Succeeded'); E.setLink(d2, 'onfalse', null);
const r1 = E.checkRules(mr);
ok('rules catch a decision without ? and a missing No link', r1.some(x => /end with "\?"/.test(x.msg)) && r1.some(x => /Yes and a No/.test(x.msg)), null);
const mp = E.modelFrom(fs.readFileSync(path.join(OUT, 'BPA Process - PRC000 - Radar - Two Stage Demo.xml'), 'utf8'));
const fakeCode = mp.stages.find(s => s.type === 'Action'); fakeCode.type = 'Code';
ok('rules refuse a Code stage in a process', E.checkRules(mp).some(x => /Code stage in a process/.test(x.msg)), null);

// 4. versions + diff + page, through the CLI entry
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bluewindow-'));
const f1 = path.join(tmp, 'Demo API.xml'); fs.writeFileSync(f1, xml);
const r1v = BW.render(f1, { out: tmp, validate: false });
ok('v1 rendered', r1v.ver === 1 && fs.existsSync(r1v.htmlFile) && fs.existsSync(path.join(tmp, 'Demo API', 'Demo API.v1.xml')), r1v.htmlFile);
const f2 = path.join(tmp, 'Demo API', 'Demo API.v2.xml'); fs.writeFileSync(f2, out);
const r2v = BW.render(f2, { out: tmp, validate: false });
ok('v2 rendered in place with a diff', r2v.ver === 2 && r2v.diff && r2v.diff.removed.length === 1 && r2v.diff.renamed.length === 1 && r2v.diff.changed.length >= 4 && r2v.diff.moved.length >= 1, r2v.diff && JSON.stringify({ a: r2v.diff.added.length, r: r2v.diff.removed.length, c: r2v.diff.changed.length, m: r2v.diff.moved.length, n: r2v.diff.renamed.length }));
const html = fs.readFileSync(r2v.htmlFile, 'utf8');
ok('page embeds the model, the three scripts and the diff', /var BW_XML=/.test(html) && /BPDRAW/.test(html) && /BPEDIT/.test(html) && /modelFrom\(BW_XML\)/.test(html) && /"removed":\["Record Customer Name"\]/.test(html), null);
ok('page is self-contained', !/https?:\/\//.test(html.replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '')), null);

// 5. the edited xml validates with the skill's validator (strict estate profile)
const v = BW.validate(f2);
ok('edited xml validates ALL CLEAN', v.ran && v.ok, v.text.split('\n').slice(-3).join(' | '));

// 6. slice 2: a new page, stages from the palette, an action from the catalog, a page call; all inserted, all valid
const cat = E.catalogFrom([xml]);
ok('catalog lists the published actions with their parameters', cat.length === 1 && cat[0].object === 'Demo API' && cat[0].actions.some(a => a.name === 'Call Customer API' && a.inputs.length === 2 && a.outputs.length === 1), JSON.stringify(cat[0] && cat[0].actions.map(a => a.name)));
const pxml = fs.readFileSync(path.join(OUT, 'BPA Process - PRC000 - Radar - Two Stage Demo.xml'), 'utf8');
const m6 = E.modelFrom(pxml), pg6 = E.addPage(m6, 'Fetch Customer');
const act6 = E.addStage(m6, 'Action', 'Fetch Customer', 15, 30, { name: 'Call The API' }); const a6 = cat[0].actions.find(a => a.name === 'Call Customer API');
E.setResource(act6, 'Demo API', a6.name, a6.inputs, a6.outputs); E.setField(act6, 'in:Customer ID', '"C1"'); E.setField(act6, 'out:Response', 'Response');
const dec6 = E.addStage(m6, 'Decision', 'Fetch Customer', 15, 90, { name: 'Got A Response?' }); E.setField(dec6, 'decision', '[Response] <> ""');
const dat6 = E.addStage(m6, 'Data', 'Fetch Customer', -200, 30, { name: 'Response' });
E.setLink(pg6.start, 'onsuccess', act6.id); E.setLink(act6, 'onsuccess', dec6.id); E.setLink(dec6, 'ontrue', pg6.end.id); E.setLink(dec6, 'onfalse', pg6.end.id);
const start6 = m6.stages.find(s => s.type === 'Start' && s.page === 'Main Page'), first6 = E.linkOf(start6, 'onsuccess');
const call6 = E.addStage(m6, 'SubSheet', 'Main Page', 15, 300, { name: 'Fetch Customer' }); E.setPageCall(m6, call6, 'Fetch Customer'); E.setLink(call6, 'onsuccess', first6); E.setLink(start6, 'onsuccess', call6.id);
ok('new page + stages pass the live rules', !E.checkRules(m6).some(x => x.level === 'error'), JSON.stringify(E.checkRules(m6).filter(x => x.level === 'error')));
const out6 = E.serialize(m6), bp6 = D.parseBp(out6);
ok('page declaration + SubSheetInfo + Start/End landed in the xml', Object.values(bp6.pages).includes('Fetch Customer') && bp6.stages.filter(s => s.page === 'Fetch Customer').map(s => s.type).sort().join() === 'Action,Data,Decision,End,Start,SubSheetInfo', bp6.stages.filter(s => s.page === 'Fetch Customer').map(s => s.type).join());
const ab = bp6.stages.find(s => s.name === 'Call The API').body;
ok('action body: inputs/outputs from the catalog, resource last, verified order', /<display[^>]*\/>\s*<font[^>]*\/>\s*<inputs>[\s\S]*expr="&quot;C1&quot;"[\s\S]*<\/inputs>\s*<outputs>[\s\S]*stage="Response"[\s\S]*<\/outputs>\s*<onsuccess>[^<]+<\/onsuccess>\s*<resource object="Demo API" action="Call Customer API" \/>\s*$/.test(ab), ab.replace(/\s+/g, ' ').slice(0, 300));
ok('page call carries the processid of the new page', new RegExp('<processid>' + pg6.ssid + '</processid>').test(bp6.stages.find(s => s.name === 'Fetch Customer' && s.type === 'SubSheet').body), null);
ok('decision children in order: decision, ontrue, onfalse', /<decision [^>]*\/>\s*<ontrue>[^<]+<\/ontrue>\s*<onfalse>[^<]+<\/onfalse>/.test(bp6.stages.find(s => s.name === 'Got A Response?').body), null);
ok('the existing stages of the process are byte-identical', m6.stages.filter(s => !s.added && !Object.keys(s.edits).length).every(s => out6.includes(`<stage stageid="${s.id}" name="${s.orig.name}" type="${s.type}">${s.orig.body}</stage>`)), null);
const tmp6 = fs.mkdtempSync(path.join(os.tmpdir(), 'bluewindow6-')); const f6 = path.join(tmp6, 'BPA Process - T6.xml'); fs.writeFileSync(f6, out6);
const v6 = BW.validate(f6);
ok('the grown process validates ALL CLEAN', v6.ran && v6.ok, v6.text.split('\n').filter(l => /ERR|FAIL|CLEAN/.test(l)).join(' | '));
const r6 = BW.render(f6, { out: tmp6, validate: false, with: [OUT] });
ok('render embeds the object catalog it found', r6.objects.length >= 3 && /BW_OBJECTS=\[\{"object":/.test(fs.readFileSync(r6.htmlFile, 'utf8')), r6.objects.map(o => o.object).join(', '));
const d6 = E.diff(D.parseBp(pxml), bp6);
ok('diff reports the additions', d6.added.length === 7 && d6.changed.length === 1, JSON.stringify({ a: d6.added.length, c: d6.changed.map(s => s.name) }));

// 7. slice 3: loop pairs, block membership, page removal
const m7 = E.modelFrom(pxml); const p7 = E.addPage(m7, 'Rows');
const ls = E.addStage(m7, 'LoopStart', 'Rows', 15, 30), gid = /<groupid>([^<]*)</.exec(ls.orig.body)[1];
const le = E.addStage(m7, 'LoopEnd', 'Rows', 15, 150, { groupid: gid });
ok('loop pair found by groupid', E.partnerOf(m7, ls) === le && E.partnerOf(m7, le) === ls, null);
ok('rules: a loop without a collection is an error', E.checkRules(m7).some(x => /no collection/.test(x.msg)), null);
E.setField(ls, 'loopdata', 'col_Rows'); E.setLink(p7.start, 'onsuccess', ls.id); E.setLink(ls, 'onsuccess', le.id); E.setLink(le, 'onsuccess', p7.end.id);
ok('loopdata lands after looptype', /<looptype>ForEach<\/looptype>\s*<loopdata>col_Rows<\/loopdata>/.test(E.stageBody(ls)), E.stageBody(ls).replace(/\s+/g, ' '));
const blk = E.addStage(m7, 'Block', 'Rows', -30, 0, { name: 'Loop Body' });
ok('block membership is geometric', E.membersOf(m7, blk).map(s => s.name).sort().join() === 'End,Loop End,Loop Start', E.membersOf(m7, blk).map(s => s.name).join());
E.resize(blk, 120, 120);
ok('after a resize the block holds less', E.membersOf(m7, blk).map(s => s.name).sort().join() === 'End,Loop Start', E.membersOf(m7, blk).map(s => s.name).join());
const call7 = E.addStage(m7, 'SubSheet', 'Main Page', 15, 300, { name: 'Rows' }); E.setPageCall(m7, call7, 'Rows'); E.setLink(call7, 'onsuccess', E.linkOf(m7.stages.find(s => s.type === 'Start' && s.page === 'Main Page'), 'onsuccess'));
ok('a grown page with a loop validates', !E.checkRules(m7).some(x => x.level === 'error'), JSON.stringify(E.checkRules(m7).filter(x => x.level === 'error')));
E.removePage(m7, 'Rows');
ok('removing a page drops its stages and declaration, flags the caller', !E.pagesOf(m7).includes('Rows') && !E.serialize(m7).includes('<name>Rows</name>') && E.checkRules(m7).some(x => /calls a page that does not exist/.test(x.msg)), null);
const m7b = E.modelFrom(xml); const pgName = Object.values(m7b.pages).find(n => n !== 'Clean Up' && n !== 'Initialise');
E.removePage(m7b, pgName); const out7 = E.serialize(m7b);
ok('removing an existing page removes its declaration from the file', !new RegExp('<name>' + pgName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '</name>').test(out7) && D.parseBp(out7).stages.every(s => s.page !== pgName), pgName);

// 8. info boxes drawn, Code Options editable, compile step runs on an object
const svg8 = D.renderPage(D.parseBp(xml), 'Initialise', null) || D.renderPage(D.parseBp(xml), Object.values(D.parseBp(xml).pages)[0], null);
ok('page info box and Code Options drawn', /class="st info"[\s\S]*Code Options/.test(svg8) || /class="st info"/.test(svg8), null);
const m8 = E.modelFrom(xml), pi = m8.stages.find(s => s.type === 'ProcessInfo');
E.setField(pi, 'references', ['System.dll', 'System.Core.dll']); E.setField(pi, 'imports', ['System', 'System.Linq']); E.setField(pi, 'language', 'csharp'); E.setField(pi, 'code', 'static int Shared = 1;');
const pb = E.stageBody(pi);
ok('Code Options rewritten in order: references, imports, language, code', /<references>\s*<reference>System\.dll<\/reference>\s*<reference>System\.Core\.dll<\/reference>\s*<\/references>\s*<imports>\s*<import>System<\/import>\s*<import>System\.Linq<\/import>\s*<\/imports>\s*<language>csharp<\/language>[\s\S]*<code><!\[CDATA\[static int Shared = 1;\]\]><\/code>/.test(pb), pb.replace(/\s+/g, ' ').slice(0, 400));
const c8 = BW.compile(src, []);
ok('compile step runs compile_check on an object', c8 && c8.ran && c8.ok, c8 && c8.text.split('\n').slice(-2).join(' | '));
ok('compile step skips a process', BW.compile(path.join(OUT, 'BPA Process - PRC000 - Radar - Two Stage Demo.xml'), []) === null, null);
ok('svg bounds sit on the 15px grid', (() => { const m = /viewBox="(-?\d+) (-?\d+) (\d+) (\d+)"/.exec(svg8); return m && [1, 2, 3, 4].every(i => +m[i] % 15 === 0); })(), (/viewBox="[^"]*"/.exec(svg8) || [''])[0]);

console.log(fails ? 'BLUEWINDOW-TEST FAIL (' + fails + ')' : 'BLUEWINDOW-TEST PASS');
process.exit(fails ? 1 : 0);
