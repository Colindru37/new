# Gotchas (hard-won)

Things that will silently break a Blue Prism import or an XML build if ignored.

## Encoding & line endings
- **Write UTF-8 with `newline='\n'`.** `bp_gen.Proc.write()` already does this. Do NOT
  round-trip generated files through PowerShell `Set-Content` / `Out-File` -- they re-encode
  (BOM/UTF-16) and rewrite line endings, which corrupts CDATA code bodies and produces
  mojibake on import.
- **Keep narrative text ASCII-safe.** No smart quotes, em-dashes or arrows (use `->` not an
  arrow glyph). Non-ASCII in attributes is the usual cause of garbled labels after import.
  The generator now refuses non-ASCII names/narratives outright.

## Reading generated files from the shell (Windows / PowerShell)
- If the workspace root does not contain the output folder, the editor's file-read tool may
  refuse it. Use `Get-Content -LiteralPath '...'` in the terminal instead. Paths with spaces
  need `-LiteralPath` and quotes.
- **PowerShell's XML adapter has a footgun:** `$node.<childtag>` returns the `name`
  attribute value if a child has a `name` attribute, instead of the child element. Use
  `GetElementsByTagName()` and check `LocalName` when walking BP XML.

## Running Python via conda run (Windows estate machine only)
- `conda run ... python -c "<code>"` **fails if the `-c` code contains a newline** (conda
  asserts against it). Put multi-line checks in a `.py` file and run that file, or keep `-c`
  to a single line.
- Full invocation used in this project:
  `C:/Users/.../conda.exe run -p C:\Users\...\envname --no-capture-output python script.py`

## Code stages
- **Code Options belong in the ProcessInfo stage.** Put `<language>`, `<references>`,
  `<imports>`, `<globalcode>`, and the shared `<code>` body in the proven
  Code Options/ProcessInfo stage shape. Do not move these elements to the root `<process>`
  node; Blue Prism may import the XML but fail compilation and surface only a null-reference
  at the calling Action stage. (`validate.py` now fails on this.)
- **Keep root/shared `<globalcode>` empty for this estate.** If a proven project requires
  shared C# (for example GK Revoke), store the class/helper body in the ProcessInfo stage's
  `<code>` element, matching the source XML exactly.
- **Use `<imports>`, not `<namespaces>`.** The wrong element name can produce the same
  opaque compile/null-reference failure. (`validate.py` now fails on this.)
- Code bodies are passed through **verbatim** inside CDATA. The generator escapes a stray
  `]]>` but does not touch your C#. If a `<` or `&` appears in code that is fine inside
  CDATA -- do NOT HTML-escape code.
- **Any compile failure = null-ref at runtime, at the Action call, with no clue as to why.**
  Missing input mapping, output mapping to a stage that doesn't exist, unbalanced braces in a
  code stage -- all present the same way. If a stage null-refs, first suspect a compile
  problem in the object it calls, not a data problem. **Run `lib/compile_check.py` before
  every import** -- it turns this class of bug into a compiler error with stage name and
  line. `validate.py` catches the missing-output-item and cross-object mapping cases.
- **How Blue Prism wraps code (what compile_check reproduces, calibrated on the official
  MS Excel / Collection / Environment / File Management VBOs, 118 VB stages):** each code
  stage is a method NAMED AFTER THE STAGE (spaces -> underscores), so shared code can call a
  stage (`Create_Instance(Handle)`); outputs are ByRef; names that are keywords (`Set`) are
  escaped; duplicate imports are tolerated; reference file names are case-insensitive.
- **The Windows built-in `csc.exe` (Framework v4.0.30319) only knows C# 5.** If the Phase-0
  compiler probe showed Blue Prism accepts newer syntax (`$"..."`, `?.`, `nameof`), the gate
  will report those lines as errors -- either avoid the newer syntax (safest: then both
  compilers agree) or point `--csc` at a newer compiler.
- **Python `.format` slots are not C# format slots.** `"...[{}]...".format(i)` ported as
  `string.Format("...[{}]...", i)` throws `FormatException` at runtime -- and it compiles
  fine, so the gate cannot catch it. Use `.Replace("{}", i.ToString())`. Grep ported code
  for `"{}"` and `[{}]`.

## Machine prerequisites (runtime, not build)
When the object actually runs on a Blue Prism machine you typically need:
- The browser driver (e.g. `msedgedriver.exe`) at the configured path, **major version
  matching the installed Edge** (Edge auto-updates, the driver does not).
- For estate projects that DO use Selenium (not GK Revoke, which forbids it): `WebDriver.dll`
  and `WebDriver.Support.dll` referenced and deployed.
- Excel via OLEDB: the ACE OLEDB provider installed (the classic "missing provider / could
  not find installable ISAM" error otherwise). ACE `UPDATE` may silently no-op on `.xlsx` --
  see the project's Dev Prompt.
- Any other third-party DLL your code references must be deployed to the BP install, not
  just present at design time.

## Flow-link mistakes the validator catches
- A `goto`/decision target name that does not match any stage name -- the generator now
  **raises** instead of falling back to End. Hand-edited XML can still have links to End by
  mistake: run `validate.py --flow` and eyeball every `*(End)`.
- A `LoopEnd` whose `groupid` does not match its `LoopStart` will not pair. Always create
  loops via `loop_start()`/`loop_end()` so the ids stay matched (validator checks 1:1 pairing).

## Collections are their own stage type
A collection must be a `type="Collection"` stage, NOT a `type="Data"` stage with
`<datatype>collection</datatype>`. The latter can import as a degraded/untyped item and
break ForEach `<loopdata>` and `[Collection.Field]` references. The generator does this for
you (any `'collection'`-typed data item renders as a Collection stage) -- but if you
hand-write or post-process XML, preserve the distinction. Quick check: a ForEach's
`<loopdata>` name should resolve to a `type="Collection"` stage (validator checks this).

## Determinism
- Stage ids are `uuid5` of (object, page, kind, name, index). Renaming a stage or reordering
  steps changes ids -- expected. Keep names stable across rebuilds so Blue Prism treats
  re-imports as updates.

## Learned from the first run on real estate files
- **A PROCESS cannot run Code stages. Only objects compile code.** Process Studio has no Code
  stage on its toolbar; the importer still accepts one, Process Validation does not flag it, and
  the run fails at the first one reached with "This code stage could not be run because it was
  added or modified since the object was started" (the message is misleading: the process never
  compiled anything). Found on the estate 2026-10-12 with 46 such stages across 5 processes;
  every gate had passed because compile_check and bprun do their own compiling. The real estate
  process we had (1109 stages) had zero Code stages and its C# in `Utility - Environment (C#)`
  actions -- that was the rule, not a style. Now: `code()` on a process page is refused unless
  `Proc.code_home('<object>')` names the object that runs it; the code becomes an action
  '<prefix> - <stage>' of that object (`add_logic()` on the object's builder, from the
  `<process>.xml.logic.json` the process writes); validate.py errors on any Code stage in a
  `type="process"` file.
- **The object's Initialise (main) sheet needs Start linked to End, like every other sheet.**
  Blue Prism runs that sheet once when a session first touches the object. With no Start, or
  a Start not linked, the first action called fails at its first stage and the exception
  carries no detail (GK Revoke import 2026-10-12: "Master Populate fails at Load Config",
  every config correct, nothing in the logs). The same holds for Clean Up. bp_gen emits the
  pair on every object; validate.py refuses any sheet (Initialise, Main, Clean Up, action
  pages) without exactly one Start that reaches an End or Exception. If you hand-write XML or
  patch an export, draw the two stages and the link before anything else.
- **`published="True"` (capital T).** Real exports write the flag capitalised; a
  case-sensitive check reports every action as unpublished. Compare case-insensitively.
  (The generator writes lowercase `true`; Blue Prism imports it fine -- verified.)
- **Exports carry a default namespace** (`xmlns="http://www.blueprism.co.uk/product/process"`).
  A parser that searches for plain `stage` then finds NOTHING and reports the file as clean.
  Strip the namespace first (validate.py, compile_check.py and preview.py all do).
- **Code environment at the `<process>` root fails silently.** Two working-looking objects
  (an email and a Word VBO) had `<references>`/`<language>`/`<namespaces>` directly under
  `<process>`: they import, show their code, and never compile. Nothing called them, so
  nobody noticed. `validate.py` and `compile_check.py` both FAIL this shape now.
- **Code stage names are file-wide, not per page.** Each code stage becomes ONE method named
  after the stage; two code stages with the same name on DIFFERENT pages (same inputs) give
  CS0111 "already defined" even though Blue Prism Studio accepts the names (found when two
  pages of one process both had an `Evidence Prefix` code stage). The generator now refuses
  it and `validate.py --strict` reports it; compile_check catches it as well.
- **The Framework `csc.exe` is C# 5.** Blue Prism 7 compiles with its own Roslyn
  (`<Blue Prism install>\roslyn\`). Always pass `--ref-dir "<Blue Prism install>"` so the gate
  uses the same compiler; otherwise modern syntax (local functions etc.) shows as false errors.

## Learned from running the flows (bprun, GK Revoke port)
- **`XmlDocument.Save` indents INSIDE empty elements.** Saving a sheet XML with `Save(stream)`
  turned `<t></t>` into `<t>\n  </t>`: an "empty" cell read back as whitespace and every
  `= ""` check on it failed. Write with `XmlWriterSettings { Indent = false }` (or `OmitXmlDeclaration`
  as needed); Blue Prism's own compare is byte-exact on what you wrote.
- **`\` path joins and `UseDefaultCredentials` are Windows habits.** Fine on the estate, but a
  code stage that builds paths with `"\\"` or sets `UseDefaultCredentials = true` on an anonymous
  SMTP relay cannot be exercised anywhere else; use `Path.Combine` and leave the relay anonymous
  unless the estate says otherwise.
- **Outlook / Word from a code stage: late-bound COM, no interop reference.**
  `Type.GetTypeFromProgID("Outlook.Application")` + `InvokeMember` needs no `<reference>` and
  no DLL on the resource; a hard reference to an interop assembly fails to compile on a machine
  that lacks it. Release with `Marshal.FinalReleaseComObject` in `finally`.
- **The code-driven action page has one shape: use `Proc.code_action()`.** Inputs, outputs
  reset, try/catch into `Error Text`, `Succeeded?`, `Raise Error` (System Exception). Four
  objects hand-rolled it before the helper existed; the helper regenerates them byte-identical.
- **`?` (or `<>:"|*\`) in a CODE stage name breaks the Windows compiler.** compile_check puts
  `Object/Page/Stage` into `#line` / `#ExternalSource`, which csc treats as a file name:
  CS1560 "Invalid filename specified for preprocessor directive" on the estate, while mcs on a
  dev box accepts it. The gate now sanitises those names; still, keep `?` for Decisions.
- **A code stage input and output with the same name is a duplicate parameter.** Blue Prism
  makes every input a ByVal and every output a ByRef parameter of the stage's method, so
  `Rows` in + `Rows` out (a collection grown inside the stage) imports with "duplicate"
  errors and never compiles. The estate found it on GK Revoke Alice/BlueSpace (Roles, Results,
  Files, Memberships) after the gate had passed: compile_check merged the pair into one `ref`
  parameter. Now the generator renames the input `<name>_In` and prepends `Name = Name_In;`,
  `validate --strict` and compile_check both refuse the raw shape, and the self-test proves it.
- **Blocks never nest.** A Block drawn around a whole run with a per-item Block inside it is
  "Block overlaps another block" (error) in Process Validation. The outer scope must be the
  page-level Recover (`work_block(..., scope='page')`). bprun had modelled "innermost Block
  first, then the enclosing one" -- a scope rule Blue Prism does not have; now fixed too.
- **Internal objects are referenced by class name.** `<resource object="Work Queues">`
  imports as "does not seem to be installed"; the XML needs
  `Blueprism.Automate.clsWorkQueuesActions` / `Blueprism.Automate.clsCredentialsActions`.
  The generator maps the display names; validate.py refuses the display name in XML.


- **The generated class is named after the object.** Blue Prism compiles an object's code into a
  class whose name is the object's name (identifier-sanitised). A class or member in shared code
  with the same name as the object (object `Radar` + `public static class Radar`) is CS0542
  "member names cannot be the same as their enclosing type", shown at runtime as the usual
  null-reference at the calling Action. Found on the estate 2026-10-23. compile_check now names
  its class the same way, so this fails at the gate.

- **Every object needs a Code Options (ProcessInfo) stage, code or not.** An object imported
  without one (no code stages, so the generator skipped it) null-refs at the first Action that
  calls it, with the same blank "Object reference not set" as a compile failure. Found on the
  estate 2026-10-23 (House Logging). bp_gen now emits it for every object; `validate --estate`
  errors on an object without it.
  **Every PROCESS needs one too.** Without the ProcessInfo stage on the main page, Process Studio
  has no Process Info stage, so the Process Info dialog cannot be opened: the process cannot be
  published and never appears in Control Room (found 2026-11-04, PRC000 - Radar - Discover).
  bp_gen now emits it for every process as well; `validate --estate` errors on any artefact
  without it.
