@echo off
rem Compile Radar.cs + self-test with the .NET Framework compiler that ships with Windows, then run it.
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
"%CSC%" /nologo /langversion:5 /r:System.Drawing.dll /r:System.Web.Extensions.dll /out:radar_selftest.exe Radar.cs RadarSelfTest.cs && radar_selftest.exe
