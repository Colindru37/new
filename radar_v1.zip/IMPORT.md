# Radar on the Blue Prism machine

1. `python selftest.py` here: proves every file arrived intact.
2. `core\build.cmd`: compiles the core with the Windows .NET compiler and runs the self-test.
   Expect SELF-TEST PASS and, this time, a real screenshot.png in the temp incident folder (unverified item 1).
3. With the rpa-bp skill: `python lib/compile_check.py <this>/bp --ref-dir "<Blue Prism install dir>"` (unverified item 2).
4. Import, in this order: Radar, House Logging, Demo Bank Plain, Radar Demo Bank, Demo API, then the three PRC000 processes.
5. System Manager -> Environment Variables: `Radar Root Folder` (text; a UNC share or a local folder for the first run),
   `Demo API Response` (text; `{"id":"C1","name":"Ana Pop"}` for a clean run, any HTML for the failure).
6. Radar Demo Bank / Demo Bank Plain: Application Modeller elements exist by name but are unspied. For the write
   failure demo you do not need a real app: run PRC000 - Radar - API Failure Demo first (no UI).
7. Run PRC000 - Radar - API Failure Demo with HTML in the variable -> one folder under <root>\<machine>\...
   Open incident.txt. Then run it with the JSON value -> no folder.
8. Verify: the real Write-failure message text (unverified 3) by letting Radar Demo Bank fail on an unspied element;
   one ring per session (unverified 4) by running two sessions on one resource and checking the trails do not mix.

House Logging here is a STAND-IN for the estate house logging object; the Radar calls inside it are what moves
into the real one.
