<#
bpwatch.ps1 -- drop folder that imports Blue Prism XML / .bprelease files through AutomateC (Blue Prism's own
command-line tool). DEV environment only: AutomateC does no Process Validation and bypasses change management.

  powershell -ExecutionPolicy Bypass -File bpwatch.ps1 -Folder C:\bp\inbox -User admin -Password secret
  powershell -ExecutionPolicy Bypass -File bpwatch.ps1 -Folder C:\bp\inbox -SSO -Overwrite
  powershell -ExecutionPolicy Bypass -File bpwatch.ps1 -Folder C:\bp\inbox -User u -Password p -Connection "DEV"   # pick the environment
  powershell -ExecutionPolicy Bypass -File bpwatch.ps1 -Folder C:\bp\inbox -SSO -Once      # import what is there, exit
  powershell -ExecutionPolicy Bypass -File bpwatch.ps1 -Folder C:\bp\inbox -SSO -DryRun    # print the commands only

Behaviour: polls every few seconds; a file is taken only once its size has stopped changing; objects import before
processes (processes reference objects); each file moves to done\ or failed\ with AutomateC's output beside it in
bpwatch.log. Nothing is compiled or produced; the only program started is the installed AutomateC.exe.
#>
param(
    [string]$Folder = (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'inbox'),
    [string]$AutomateC = '',
    [string]$User = '',
    [string]$Password = '',
    [switch]$SSO,
    [string]$Connection = '',      # Blue Prism connection name as on the login screen (/dbconname); empty = the default one
    [switch]$Overwrite,
    [switch]$Once,
    [switch]$DryRun,
    [int]$PollSeconds = 3
)

$ErrorActionPreference = 'Stop'

function Find-AutomateC {
    if ($AutomateC -and (Test-Path $AutomateC)) { return $AutomateC }
    $candidates = @(
        'C:\Program Files\Blue Prism Limited\Blue Prism Automate\AutomateC.exe',
        'C:\Program Files (x86)\Blue Prism Limited\Blue Prism Automate\AutomateC.exe'
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    $running = Get-Process -Name Automate -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($running) {
        $c = Join-Path (Split-Path -Parent $running.Path) 'AutomateC.exe'
        if (Test-Path $c) { return $c }
    }
    throw 'AutomateC.exe not found: pass -AutomateC "<path>"'
}

function Write-Log([string]$msg) {
    $line = '{0} | {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg
    Write-Host $line
    Add-Content -Path (Join-Path $Folder 'bpwatch.log') -Value $line
}

function Get-AuthArgs {
    $a = @()
    if ($Connection) { $a += @('/dbconname', $Connection) }
    if ($SSO) { return $a + @('/sso') }
    if (-not $User) { throw 'pass -User and -Password, or -SSO' }
    return $a + @('/user', $User, $Password)
}

function Get-ImportArgs([System.IO.FileInfo]$f) {
    if ($f.Extension -ieq '.bprelease') { $a = @('/importrelease', $f.FullName) }
    else { $a = @('/import', $f.FullName) }
    if ($Overwrite) { $a += '/overwrite' }
    return $a + (Get-AuthArgs)
}

function Rank([System.IO.FileInfo]$f) {
    # import order inside one drop: releases (self-ordered), then objects, then processes
    if ($f.Extension -ieq '.bprelease') { return 0 }
    if ($f.Name -like 'BPA Object*') { return 1 }
    if ($f.Name -like 'BPA Process*') { return 3 }
    return 2
}

function Test-Stable([System.IO.FileInfo]$f) {
    $a = $f.Length; Start-Sleep -Milliseconds 800
    $f.Refresh(); return ($f.Length -eq $a -and $f.Length -gt 0)
}

function Import-One([string]$exe, [System.IO.FileInfo]$f) {
    $args = Get-ImportArgs $f
    $shown = ($args | ForEach-Object { if ($_ -eq $Password -and $Password) { '***' } else { $_ } }) -join ' '
    Write-Log ('import  ' + $f.Name + '  ->  "' + $exe + '" ' + $shown)
    if ($DryRun) { return }
    $out = & $exe @args 2>&1 | Out-String
    $rc = $LASTEXITCODE
    $ok = ($rc -eq 0) -and ($out -notmatch 'error|exception|failed')
    $dest = Join-Path $Folder $(if ($ok) { 'done' } else { 'failed' })
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $target = Join-Path $dest $f.Name
    if (Test-Path $target) { Remove-Item $target -Force }
    Move-Item $f.FullName $target
    Write-Log (('OK      ' , 'FAILED  ')[-not $ok] + $f.Name + ' (exit ' + $rc + ')')
    foreach ($l in ($out.Trim() -split "`r?`n")) { if ($l.Trim()) { Write-Log ('    ' + $l.Trim()) } }
}

New-Item -ItemType Directory -Force -Path $Folder | Out-Null
$exe = Find-AutomateC
Write-Log ('bpwatch start  folder=' + $Folder + '  automatec=' + $exe + '  auth=' + $(if ($SSO) { 'sso' } else { $User }) + $(if ($DryRun) { '  DRY RUN' } else { '' }))

while ($true) {
    $files = Get-ChildItem -Path $Folder -File | Where-Object { $_.Extension -in '.xml', '.bprelease' } |
             Sort-Object @{Expression = { Rank $_ }}, Name
    foreach ($f in $files) {
        if (-not (Test-Stable $f)) { Write-Log ('waiting ' + $f.Name + ' (still being written)'); continue }
        try { Import-One $exe $f } catch { Write-Log ('ERROR   ' + $f.Name + ': ' + $_.Exception.Message) }
    }
    if ($Once) { break }
    Start-Sleep -Seconds $PollSeconds
}
Write-Log 'bpwatch end'
