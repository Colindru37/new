"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "834269a003fa17a462e2d576dd1e6b6381c4db6da53a9f0ea46bbe7aca1967a3",
 "README.md": "3e9f64bc813c37d8183f82b4307d61f88100fc664ff507800c91ec9db361ce1e",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Demo Bank Plain.xml": "354e1fd86502e65808b3b6be3bc05bc372c9373525f3ba83691b93ac5880a49a",
 "bp/BPA Object - House Logging.xml": "8d1e0609521d21a5841650041f0ce118de38828894ea4e93c450572eead99052",
 "bp/BPA Object - Radar Demo Bank.xml": "e8ddbe599b2ca5373f3bfcfd661566b9d125d41868087790271fe3fbbe248629",
 "bp/BPA Object - Radar Probe.xml": "fc124277598cf3c9a15343d9ccc83ac8fd0918cea0fdc9b0b97b1367a6781962",
 "bp/BPA Object - Radar.xml": "87b3f41c34b2923529928b530f38f852c898bc3556d0bc3cb385d117d03fe189",
 "bp/BPA Process - PRC000 - Radar - API Failure Demo.xml": "eb0155c9291b5a03a8737028b38bfa8a89ea6098b8040ad670f15ede47c98e36",
 "bp/BPA Process - PRC000 - Radar - Discover.xml": "f35b868210ce11c875ac38717ff3901966a6575ed1ae6603a1e39eb9f408fdb1",
 "bp/BPA Process - PRC000 - Radar - House Logging Demo.xml": "d8d5fcfdeb1d633abec678f06bd2638aa11dcfedd0d6a3ef7fc2bde55e9328db",
 "bp/BPA Process - PRC000 - Radar - Probe Demo.xml": "9f4dac5b63534dc430b3a3c94d17d5913d456f9f62e330e1dfcdae682cf0e183",
 "bp/BPA Process - PRC000 - Radar - Two Stage Demo.xml": "5117028ee5f2c4a5488d52dc7d7cd94ea7d6f00a5f03cd759c2bc4c1ea672456",
 "bp/BPA Process - PRC000 - Radar - Write Failure Demo.xml": "434b4c8c17e7654b286bfa2875b156e1182b735a78e8524053cc47a64f00dfd0",
 "bp/gen_radar.py": "d96775d1dcfaa3d3e456f8c0aa6dd854c9059c5fd52017b13efd9a76cf543b10",
 "core/Radar.cs": "5baafd8a158450a0621c0b94dd58439b2c05af7b649d03a3e97d723a7637669f",
 "core/RadarDiscover.cs": "b5c004d46215934008eacf3604bbdeef45c4ebe28cff06272ea9119ef4ad3324",
 "core/RadarDiscoverSelfTest.cs": "fe447d3077bd65cbb65a2630abe0e018f2b97aacc38514122d72923dc0bc0c17",
 "core/RadarDiscoverSelfTest.ps1": "1d37f131ad699c3e4faa252f50c9ee68f279e39ae35e137fba6b0d4f83942095",
 "core/RadarProbe.cs": "3450e2f298082339c8d03b2b58a7c9fba4c5bac19d7827b4c5ae842715008285",
 "core/RadarProbeSelfTest.cs": "3dfc5fade2fd78c146c8df70a6104d23021b108983166f6229b8948a71ae82b3",
 "core/RadarProbeSelfTest.ps1": "82491e0af7e5c7eff6ffd590253471d2ce642eefccb1b4e00a24becdacc7e7ee",
 "core/RadarSelfTest.cs": "16d3b2f2b098fef744b399b17da67db5112608326bc530e95967456f596abaa6",
 "core/RadarSelfTest.ps1": "2a7af51a2e6b798ab6cc67a4fd34ab8d7b9e9ba5d2e150a67bea2ebbee442ffe",
 "tools/bpwatch.ps1": "601b4043ab5eddcbe3bd519f469d4cfb6c8ea16476ed6900fe8ba38a46fc386f"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
