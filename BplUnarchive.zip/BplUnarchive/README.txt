BplUnarchive - Blue Prism archived sessions (*.bpl.gz) -> SQL Server, no restore into prod.
.NET Framework 4.8, nothing to install: compiles with the csc.exe that ships with Windows.

0) If the laptop refuses to run a freshly built .exe ("Access is denied"), skip the compile and use
   PowerShell instead (same code, compiled in memory, no exe file):
     open PowerShell in this folder (File Explorer address bar -> type powershell -> Enter), then
     .\run.ps1 --selftest
     .\run.ps1 --src "<archive folder>" --dry-run out
     .\run.ps1 --src "<archive folder>" --conn "<connection string>" --session-table dbo.BPASession --log-table none
   If it says running scripts is disabled: start it as  powershell -ExecutionPolicy Bypass  and retry,
   or paste the body of run.ps1 into the window.

1) Compile (cmd.exe, inside this folder):
   C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /o /r:System.Data.dll BplUnarchive.cs

2) Self-test (must end with SELFTEST PASS):
   BplUnarchive --selftest

3) Dry run on real archives (no SQL; writes TSV files you can open in Excel):
   BplUnarchive --src "<archive folder>" --dry-run out
   Look at: "Done: N files, M entries, 0 failed" and that NO "XML elements not mapped" list is printed.
   If one is printed, photograph it.

4) Load into the UAT reporting DB (sessions only: that DB has no session log table):
   Windows login:
   BplUnarchive --src "<archive folder>" --conn "Server=fradbdbrpad4;Database=PCB_Ops_Germany_UAT_reporting;Integrated Security=SSPI" --session-table dbo.BPASession --log-table none
   SQL login:
   BplUnarchive --src "<archive folder>" --conn "Server=fradbdbrpad4;Database=PCB_Ops_Germany_UAT_reporting;User Id=<user>;Password=<pw>" --session-table dbo.BPASession --log-table none

   Optional: --from 20240101 --to 20240131 (by file-name date), --parallel 4, --batch-rows 50000
   Rerunning is safe: sessions already in BPASession are skipped. Problems go to bpl_unarchive_errors.log.

5) Check in SSMS:
   SELECT COUNT(*), MIN(startdatetime), MAX(startdatetime) FROM dbo.BPASession
   SELECT TOP 5 sessionnumber, statusid, laststage, lastupdated FROM dbo.BPASession ORDER BY startdatetime DESC

Exit codes: 0 ok, 1 some files failed (see log), 2 bad arguments, 3 fatal (e.g. cannot connect / table not found).
