# Runs BplUnarchive without producing an .exe (compiles the C# source in memory).
# Usage, from a PowerShell window opened in this folder:
#   .\run.ps1 --selftest
#   .\run.ps1 --src "<archive folder>" --dry-run out
#   .\run.ps1 --src "<archive folder>" --conn "<connection string>" --session-table dbo.BPASession --log-table none
# If scripts are blocked ("running scripts is disabled"), start PowerShell as:
#   powershell -ExecutionPolicy Bypass
# and run the same lines; or paste the body of this file into the window.
$ErrorActionPreference = "Stop"
$src = Get-Content -Raw -Path (Join-Path $PSScriptRoot "BplUnarchive.cs")
if (-not ("BplUnarchive" -as [type])) {
    Add-Type -TypeDefinition $src -Language CSharp -ReferencedAssemblies System.Data, System.Xml, System.IO.Compression, System.Core
}
exit [BplUnarchive]::Main([string[]]$args)
