# Radar on the Blue Prism machine

Nothing here produces or starts a binary. C# runs in-process through PowerShell Add-Type or inside Blue Prism.

1. `python selftest.py`: proves every file arrived intact.
2. `powershell -ExecutionPolicy Bypass -File core\RadarSelfTest.ps1`: compiles the core in-process and runs the self-test.
   Expect SELF-TEST PASS and, on Windows, a real screenshot.png in the temp incident folder (unverified item 1).
3. With the rpa-bp skill: `python lib/compile_check.py <this>/bp --ref-dir "<Blue Prism install dir>"` (unverified item 2).
4. Import. By hand, in this order: Radar, House Logging, Demo Bank Plain, Radar Demo Bank, Demo API, then the three
   PRC000 processes. Or on a DEV environment: `powershell -ExecutionPolicy Bypass -File tools\bpwatch.ps1 -Folder <inbox> -User u -Password p -Connection "<DEV connection name>" -Once`
   after copying bp\*.xml into <inbox> (objects import before processes automatically; see the tools\bpwatch.ps1 header).
5. System Manager -> Environment Variables: `Radar Root Folder` (text; a UNC share or a local folder for the first run),
   `Demo API Response` (text; `{"id":"C1","name":"Ana Pop"}` for a clean run, any HTML for the failure).
6. Radar Demo Bank / Demo Bank Plain: Application Modeller elements exist by name but are unspied. For the first run
   you do not need a real app: run PRC000 - Radar - API Failure Demo first (no UI).
7. Run PRC000 - Radar - API Failure Demo with HTML in the variable -> one folder under <root>\<machine>\...
   Open incident.txt. Then run it with the JSON value -> no folder.
8. Verify: the real Write-failure message text (unverified 3) by letting Radar Demo Bank fail on an unspied element;
   one ring per session (unverified 4) by running two sessions on one resource and checking the trails do not mix.

House Logging here is a STAND-IN for the estate house logging object; the Radar calls inside it are what moves
into the real one.

## The runtime-hook experiment (v10): Radar Probe

Question it answers: what does a first-chance exception hook see inside Automate, with NO instrumentation in any object?

1. `powershell -ExecutionPolicy Bypass -File core\RadarProbeSelfTest.ps1` -> expect SELF-TEST PASS with the hook checks
   running (PowerShell is .NET Framework, the event fires there; on mono they are skipped).
2. Import `bp\BPA Object - Radar Probe.xml` and `bp\BPA Process - PRC000 - Radar - Probe Demo.xml` (drop folder or by hand).
   Needs the objects from before: Demo Bank Plain, Demo API, and the two env vars. Put HTML in `Demo API Response`.
3. Run PRC000 - Radar - Probe Demo. It installs the hook, lets Demo Bank Plain die at its Write stage (unspied element)
   and Demo API die on the bad JSON, then writes a report. The process ends normally.
4. Open `<Radar Root Folder>\<machine>\probe_<stamp>\probe.log`. Read, in this order:
   - the header line `runtime raises first-chance events: YES` (NO = the whole idea is dead on this runtime)
   - how many records sit between `MARK before Enter Transfer` and `MARK process caught`: that is Blue Prism's own
     internal noise per failing stage. A handful = usable trail. Hundreds = needs a filter.
   - the record for the Write failure: does `type:`/`message:` carry more than the Errors-Only log text, and do the
     kept stack frames name the stage kind (look for Blue Prism class names such as clsWriteStage / clsProcess)?
   - `shot_000N.png`: taken at the throw, before Recover. Compare with what the screen looked like afterwards.
   - `report.txt`: counts per exception type for the whole run.
5. Decision: if the noise is small and the stack names the stage kind, the hook replaces route B (one Install call in
   the house logging Log Start, nothing else). Route A stays the only source of data item values.

## v11: the hook is inside Radar now

Finding from the probe run (2026-10-26, Blue Prism 7.2.1 Studio): code-stage exceptions arrive in the hook with the object
class and the stage method as the first frame (`Demo_API.Run_JSON_To_Customer`), the BP stage classes below
(`Stages.CodeStage` under `Stages.ActionStage`), and a screenshot at the throw. UI stage failures
(Navigate/Write/Read/Wait) and Exception stages do NOT throw .NET exceptions: the Recover-time Dump stays the only
capture for those. Noise = SocketException from PersistentConnection.CommsThread + MissingManifestResourceException,
both filtered.

What changed: `Configure Radar` installs the hook (once per Automate process) and marks the calling thread as a
session; from then on every real throw on that thread is a `throw:<Type>` line in the trail with
`<object>.<stage> (<StageKind>)`, the last 10 are written in full (frames) into incident.txt/json, and the latest
throw-time screenshot is copied in as `screenshot_at_throw.png`. New action `Hook Status` (text + Live flag).

Re-import only `bp\BPA Object - Radar.xml`. Run PRC000 - Radar - API Failure Demo with HTML in the variable: the
incident now carries the ArgumentException with its frames and screenshot_at_throw.png next to the Recover-time
screenshot. `core\RadarSelfTest.ps1` runs the hook checks on Windows (PowerShell is .NET Framework).

## v13: environment snapshot
Nothing to configure. Every incident folder now carries `env.txt`; the same text is the `environment at failure`
section of incident.txt. First run on a bot machine: check the `session` line says what you expect (ICA for Citrix,
RDP, or Console) and that the `apps` list shows the automated application with its window title. If the event log
section says unavailable, the run account cannot read the Application log; note it, the rest still works.


## v14: discovery run (Radar Probe / Discover Runtime)

What it is: one text report of what the .NET runtime exposes to a code stage. Reflection metadata only: nothing is
invoked, read or changed; the command line is masked. The two next capture layers get written against this report.

1. `powershell -ExecutionPolicy Bypass -File core\RadarDiscoverSelfTest.ps1` -> SELF-TEST PASS (in-process Add-Type).
2. Re-import `bp\BPA Object - Radar Probe.xml` (new action `Discover Runtime`) and import
   `bp\BPA Process - PRC000 - Radar - Discover.xml`. Needs the `Radar Root Folder` environment variable from before.
3. Run `PRC000 - Radar - Discover` ONCE from Control Room (a resource, not Studio: the frames above the stage differ
   and the Control Room ones are the ones that matter). If you also run it from Process Studio, keep both reports and
   label them; the `[host]`/`[stack]` sections tell them apart.
4. Open `<Radar Root Folder>\<machine>\discover_<stamp>\discover.txt`. Photograph or copy, in this order:
   - `[host]` + `[thread]` + `[stack]` whole (about 30 lines): the frame chain from `Run_Discover_Runtime` up to the
     runner, with parameter names and types; the line marked `<< stage class` and `stage anchor:`.
   - `[assemblies]` (the Blue Prism assembly list with versions) and `[roots]` whole.
   - `[key types]`: at least the blocks for the stage root, `CodeStage`, `ActionStage`, the sub-sheet reference stage,
     `clsProcess`, `clsSession`, every type whose name contains `Logging`, `clsProcessValue` and the data/collection
     stage classes. These blocks are long; a copy beats photos.
   - the summary the action returns (`Summary` output) as a last resort if the file cannot leave the machine.
5. If `Summary` starts with `ERROR:` or the report ends with `# ABORTED`, send that line; the rest of Radar is untouched.

Nothing else changes in v14; Radar itself (Configure / Record / Dump / Hook Status) is as in v13.

## v17: build on the Blue Prism machine + session-log noise cut
The capture layers (stage log, data chain) were written into `core\Radar.cs` ON the Blue Prism machine, so that
copy is the source of truth for the recorder code. The XML is regenerated there too:
1. Unzip the rpa-bp skill zip next to this folder (so `..\skill-rpa-bp\lib\bp_gen.py` exists) or set
   `RPA_BP_SKILL=<that folder>` in the shell.
2. If Configure gained inputs, edit the marked BANK-SIDE EDIT POINT in `bp\gen_radar.py` (inputs + body).
3. `python bp\gen_radar.py` then `python ..\skill-rpa-bp\lib\validate.py bp\out --flow --estate --strict`
   (expect ALL CLEAN), then import `bp\out\BPA Object - Radar.xml` and `BPA Object - House Logging.xml`.
   The Demo objects/processes only need re-import when the generator changed them.
4. `powershell -ExecutionPolicy Bypass -File core\RadarSelfTest.ps1` still has to PASS after every Radar.cs edit.
Noise cut: every Code/Decision stage of the Radar object and every Action stage calling Radar from House Logging
now carries "Don't log this stage" (`<loginhibit />`), so Radar leaves nothing in the Blue Prism session log.
Check it: run the API Failure Demo, export its session log, no Radar.* rows should be in it.
Output asks for the next Radar.cs edit (format only, keep the layers as they are):
- stage log: print parameters as `name=value; name=value`, not the raw `<parameters>` XML (lines 5x shorter);
- stage log: hide the house logging object's own inner stages the same way Radar's are hidden;
- when the data chain is live, Dump may ignore the Data Items input (the chain already has them), one line saying so;
- keep every section bounded: stage log last N stages (N from Configure, default 30), chain depth cap, 300 chars per value.

