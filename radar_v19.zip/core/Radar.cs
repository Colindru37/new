// Radar: in-memory flight recorder for Blue Prism objects. BCL-only, C# 5 (Blue Prism code stage / mono mcs).
// Nothing leaves memory on the happy path. Dump() writes one incident folder and never throws.
// This file is the single source: gen_radar.py embeds it as the Radar VBO's shared code (Code Options).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Diagnostics;
using System.Runtime.ExceptionServices;
using System.Collections;
using System.Reflection;
using System.Reflection.Emit;
using System.Text.RegularExpressions;

public static class RadarCore
{
    public class Entry
    {
        public long Seq;
        public DateTime At;
        public string Label;
        public string Detail;
    }

    // One ring per session. A Blue Prism resource runs each session on its own thread, so the
    // ring is keyed by the calling thread: two sessions on one resource never mix trails.
    // (To verify on the first BP run: that every action call of one session arrives on the same thread.)
    class Ring
    {
        public readonly List<Entry> Entries = new List<Entry>();
        public long Seq = 0;
        public long Dropped = 0;
        public string LastDumpKey;      // exception detail+stage of the last dump of this session
        public string LastDumpFolder;
        public DateTime LastDumpAt;
        public readonly List<Throw> Throws = new List<Throw>();   // .NET exceptions seen by the hook on this session's thread
        public string ThrowShot;        // staging file of the screenshot taken at the latest throw
        public DateTime ThrowShotAt;
    }
    const int DedupeSeconds = 120;
    const int ThrowsKept = 10;
    const int ThrowShotMinSeconds = 3;      // at most one throw-time screenshot per session per 3 s (handled-exception loops)

    /// One .NET exception at the moment it was thrown (first-chance), with the Blue Prism frames parsed.
    public class Throw
    {
        public DateTime At;
        public string Type, Message, Inner;
        public string Object, Stage, Kind;    // from the stack: generated object class, its method (the stage), the BP stage class
        public string Frames;                 // System.* frames removed, one per line
    }

    static readonly object Gate = new object();
    static readonly Dictionary<int, Ring> Rings = new Dictionary<int, Ring>();
    static int _capacity = 50;
    static string _root = null;

    // ---- the runtime hook: every .NET exception in the Automate process, at the moment of throw ----
    // Verified on Blue Prism 7.2.1 (2026-10-26): code-stage exceptions arrive with the object class and the stage
    // method as the first frame and the BP stage classes below; UI stage failures (Navigate/Write/Read/Wait) and
    // Exception stages do NOT throw .NET exceptions -- those still need the Recover-time Dump.
    static bool _hooked, _hookLive, _hookEnabled = true;
    static long _seen, _ignored, _recorded, _unknownThread;
    [ThreadStatic] static bool _inHook;
    [ThreadStatic] static bool _inRadar;   // Radar's own work on this thread (dump, env snapshot, layers): its internal throws are not the robot's
    [ThreadStatic] static bool _sawCheck;
    sealed class HookCheckException : Exception { public HookCheckException() : base("radar hook self-check") { } }

    public static bool HookEnabled { get { lock (Gate) return _hookEnabled; } set { lock (Gate) _hookEnabled = value; } }
    public static bool HookLive { get { lock (Gate) return _hookLive; } }
    /// "live" / "not live (runtime never raises the event)" / "off", plus counters.
    public static string HookStatus
    {
        get
        {
            lock (Gate)
                return (!_hookEnabled ? "off" : !_hooked ? "not installed" : _hookLive ? "live" : "not live (runtime never raises the event)")
                       + "; seen " + _seen + ", ignored " + _ignored + ", recorded " + _recorded + ", other threads " + _unknownThread
                       + "; stage log: " + StageLogStatusLocked() + "; data chain: " + DataChainStatusLocked();
        }
    }

    /// Subscribe once per process; returns HookStatus. Called by Configure. Never throws.
    public static string InstallHook()
    {
        try
        {
            lock (Gate)
            {
                if (!_hookEnabled) return HookStatus;
                if (!_hooked) { AppDomain.CurrentDomain.FirstChanceException += OnFirstChance; _hooked = true; }
            }
            _sawCheck = false;
            try { throw new HookCheckException(); } catch (HookCheckException) { }
            lock (Gate) _hookLive = _sawCheck;
        }
        catch (Exception) { }
        return HookStatus;
    }

    /// Known noise inside Automate: the resource connection retrying a host name, and localisation lookups.
    static bool IsNoise(Exception ex, string frames)
    {
        if (ex is HookCheckException) return true;
        var t = ex.GetType().FullName ?? "";
        if (t == "System.Resources.MissingManifestResourceException") return true;
        if (t == "System.Net.Sockets.SocketException" && (frames.Contains("PersistentConnection") || frames.Contains("TcpTalker"))) return true;
        if (t == "System.Threading.ThreadAbortException") return true;
        return false;
    }

    static void OnFirstChance(object sender, FirstChanceExceptionEventArgs a)
    {
        if (_inHook || _inRadar) return;
        _inHook = true;
        try
        {
            var ex = a.Exception;
            if (ex == null) return;
            if (ex is HookCheckException) { _sawCheck = true; return; }   // the liveness probe thrown by InstallHook
            lock (Gate) { if (!_hookEnabled) return; _seen++; }
            string obj, stage, kind;
            var frames = Frames(out obj, out stage, out kind);
            if (IsNoise(ex, frames)) { lock (Gate) _ignored++; return; }
            var th = new Throw
            {
                At = DateTime.Now, Type = ex.GetType().FullName, Message = OneLine(ex.Message, 600),
                Inner = ex.InnerException == null ? null : ex.InnerException.GetType().FullName + ": " + OneLine(ex.InnerException.Message, 300),
                Object = obj, Stage = stage, Kind = kind, Frames = frames
            };
            string shotFile = null;
            lock (Gate)
            {
                // only sessions that Configured/Recorded on this thread have a ring; anything else is not a session
                Ring r;
                if (!Rings.TryGetValue(System.Threading.Thread.CurrentThread.ManagedThreadId, out r)) { _unknownThread++; return; }
                _recorded++;
                r.Throws.Add(th); while (r.Throws.Count > ThrowsKept) r.Throws.RemoveAt(0);
                r.Seq++;
                r.Entries.Add(new Entry { Seq = r.Seq, At = th.At, Label = "throw:" + ShortType(th.Type),
                                          Detail = th.Message + (obj != null ? " | " + obj + "." + stage : "") + (kind != null ? " (" + kind + ")" : "") });
                Trim(r);
                if ((th.At - r.ThrowShotAt).TotalSeconds >= ThrowShotMinSeconds)
                {
                    r.ThrowShotAt = th.At;
                    shotFile = Path.Combine(Path.GetTempPath(), "radar_throw_" + System.Threading.Thread.CurrentThread.ManagedThreadId + ".png");
                    r.ThrowShot = shotFile;
                }
            }
            if (shotFile != null && Screenshot(shotFile) != "ok") lock (Gate) { var r = Mine(); if (r.ThrowShot == shotFile) r.ThrowShot = null; }
        }
        catch (Exception) { }
        finally { _inHook = false; }
    }

    static readonly Type Self = typeof(RadarCore);
    /// The call stack at the throw site with System.* frames removed; parses the generated object class
    /// (first frame outside BluePrism/Automate/System), its method (= the stage) and the first BP stage class.
    static string Frames(out string obj, out string stage, out string kind)
    {
        obj = stage = kind = null;
        var sb = new StringBuilder();
        try
        {
            var st = new StackTrace(2, false);
            int total = st.FrameCount, kept = 0;
            for (int i = 0; i < total && kept < 25; i++)
            {
                var m = st.GetFrame(i).GetMethod();
                if (m == null) continue;
                var t = m.DeclaringType;
                if (t == Self) continue;
                string tn = t == null ? "?" : (t.FullName ?? t.Name);
                if (tn.StartsWith("System.") || tn.StartsWith("Microsoft.") || tn == "System") continue;
                sb.Append(tn).Append('.').Append(m.Name).Append('\n');
                kept++;
                bool bp = tn.StartsWith("BluePrism.") || tn.StartsWith("Automate") || tn.StartsWith("LocaleTools");
                if (obj == null && !bp) { obj = tn; stage = m.Name.StartsWith("Run_") ? m.Name.Substring(4).Replace('_', ' ') : m.Name; }
                if (kind == null && tn.StartsWith("BluePrism.AutomateProcessCore.Stages.")) kind = tn.Substring("BluePrism.AutomateProcessCore.Stages.".Length);
            }
        }
        catch (Exception) { }
        return sb.ToString();
    }
    static string ShortType(string t) { if (t == null) return ""; int i = t.LastIndexOf('.'); return i < 0 ? t : t.Substring(i + 1); }
    static string OneLine(string s, int max)
    {
        if (s == null) return "";
        s = s.Replace("\r", " ").Replace("\n", " ");
        return s.Length > max ? s.Substring(0, max) + "..." : s;
    }

    static Ring Mine()
    {
        int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
        Ring r;
        if (!Rings.TryGetValue(id, out r)) { r = new Ring(); Rings[id] = r; }
        return r;
    }

    static void Trim(Ring r)
    {
        while (r.Entries.Count > _capacity) { r.Entries.RemoveAt(0); r.Dropped++; }
    }

    public static int Capacity { get { lock (Gate) return _capacity; } }
    public static string Root { get { lock (Gate) return _root ?? Path.Combine(Path.GetTempPath(), "Radar"); } }
    public static int SessionCount { get { lock (Gate) return Rings.Count; } }

    /// Set the incident root folder (a UNC share in production) and the ring capacity. Empty/zero keep the defaults.
    public static void Configure(string rootFolder, int capacity)
    {
        Configure(rootFolder, capacity, false, false);
    }

    /// Same, plus the two optional capture layers (both off by default). Off = no line of the layer runs.
    public static void Configure(string rootFolder, int capacity, bool stageLog, bool dataChain)
    {
        lock (Gate)
        {
            if (!string.IsNullOrEmpty(rootFolder)) _root = rootFolder;
            if (capacity > 0) _capacity = capacity;
            foreach (var r in Rings.Values) Trim(r);
            Mine();     // this thread is a session from now on: the hook records its throws
            _stageLogOn = stageLog; _dataChainOn = dataChain;
        }
        InstallHook();
        if (stageLog || dataChain) InstallStageEngine();
        NoteRadarAction();
    }

    /// Append one entry to this session's ring; the oldest falls off past Capacity. Cheap: no I/O.
    public static void Record(string label, string detail)
    {
        lock (Gate)
        {
            var r = Mine();
            r.Seq++;
            r.Entries.Add(new Entry { Seq = r.Seq, At = DateTime.Now, Label = label ?? "", Detail = detail ?? "" });
            Trim(r);
        }
        NoteRadarAction();
    }

    public static int Count { get { lock (Gate) return Mine().Entries.Count; } }
    public static long Dropped { get { lock (Gate) return Mine().Dropped; } }

    /// This session's trail as text, oldest first, one line per entry.
    public static string Trail()
    {
        lock (Gate)
        {
            var sb = new StringBuilder();
            foreach (var e in Mine().Entries)
                sb.Append(Line(e)).Append('\n');
            return sb.ToString();
        }
    }

    /// Forget this session's ring (called after a dump; also the right call at Clean Up).
    public static void Clear()
    {
        lock (Gate)
        {
            int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
            Rings.Remove(id); StageSessions.Remove(id);
        }
    }

    static string Line(Entry e)
    {
        return e.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + " | #" + e.Seq + " | " + e.Label + " | " + e.Detail.Replace("\r", "").Replace("\n", " \\n ");
    }

    /// Write one incident folder: incident.txt + incident.json (+ screenshot.png on Windows), then clear this session's ring.
    /// Returns the folder path, or "ERROR: ..." when even the folder could not be written. Never throws.
    public static string Dump(string process, string page, string exType, string exDetail, string exStage, string dataItems, bool captureScreen)
    {
        bool outer = !_inRadar;
        _inRadar = true;
        try { return DumpCore(process, page, exType, exDetail, exStage, dataItems, captureScreen); }
        catch (Exception ex) { return "ERROR: " + ex.GetType().Name + ": " + ex.Message; }
        finally { if (outer) _inRadar = false; }
    }

    static string DumpCore(string process, string page, string exType, string exDetail, string exStage, string dataItems, bool captureScreen)
    {
        try
        {
            var now = DateTime.Now;
            List<Entry> snapshot; long dropped; int cap; List<Throw> throws; string throwShot = null; string hookStatus;
            // Dedupe key = type + detail ONLY. Blue Prism reports a different ExceptionStage() at each
            // level (the inner stage in the object, the calling Action stage in the process -- seen on the
            // estate 2026-10-23), so the stage must not be part of the key.
            string key = (exType ?? "") + "\u0001" + (exDetail ?? "");
            lock (Gate)
            {
                var r = Mine();
                // The same exception reaches Dump twice when an instrumented object dumps and then the
                // process's logger dumps on the rethrow: one incident folder, not two.
                if (r.LastDumpKey == key && (now - r.LastDumpAt).TotalSeconds < DedupeSeconds && r.LastDumpFolder != null)
                {
                    // the later caller (usually the process's logger) may be the one that wants the screenshot
                    var shot = Path.Combine(r.LastDumpFolder, "screenshot.png");
                    if (captureScreen && !File.Exists(shot) && Directory.Exists(r.LastDumpFolder))
                    {
                        var note = Screenshot(shot);
                        try { File.AppendAllText(Path.Combine(r.LastDumpFolder, "incident.txt"),
                                                 "\nscreenshot: " + (note == "ok" ? "screenshot.png (taken by a later dump of the same exception)" : "skipped (" + note + ")") + "\n", new UTF8Encoding(false)); }
                        catch (Exception) { }
                    }
                    return r.LastDumpFolder;
                }
                snapshot = new List<Entry>(r.Entries); dropped = r.Dropped; cap = _capacity;
                throws = new List<Throw>(r.Throws);
                if (r.ThrowShot != null && File.Exists(r.ThrowShot) && (now - r.ThrowShotAt).TotalSeconds < DedupeSeconds) throwShot = r.ThrowShot;
                hookStatus = HookStatus;
            }
            // <root>\<resource machine>\<time>_<process>_<stage>: the Control Room row (time, resource, stage) finds it
            var folder = Path.Combine(Path.Combine(Root, Safe(Environment.MachineName)),
                                      now.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture) + "_" + Safe(process) + "_" + Safe(exStage));
            for (int n = 2; Directory.Exists(folder); n++)          // two incidents in the same millisecond never share a folder
                folder = folder.TrimEnd('0','1','2','3','4','5','6','7','8','9','~') + "~" + n;
            Directory.CreateDirectory(folder);

            string shotNote;
            string shotFile = null;
            if (captureScreen)
            {
                shotFile = Path.Combine(folder, "screenshot.png");
                shotNote = Screenshot(shotFile);
                if (shotNote != "ok") shotFile = null;
            }
            else shotNote = "not requested";
            string throwShotNote = "none";
            if (throwShot != null)
            {
                try { File.Copy(throwShot, Path.Combine(folder, "screenshot_at_throw.png"), true); throwShotNote = "screenshot_at_throw.png"; }
                catch (Exception e) { throwShotNote = "failed (" + e.GetType().Name + ")"; }
            }

            EnvInfo env; try { env = EnvSnapshot(); } catch (Exception ex) { env = new EnvInfo(); env.Text = "unavailable (" + ex.GetType().Name + ")\n"; }
            List<StageRec> stageLog; long stageDropped; List<ChainFrame> chain; string slStatus, dcStatus; List<PathRec> path; object runner; string runnerReason;
            SnapshotLayers(out stageLog, out stageDropped, out chain, out slStatus, out dcStatus, out path, out runner, out runnerReason);
            List<ChainCapture> chainItems = CaptureChain(chain);
            var sessionFields = new Dictionary<string, string>();
            string sessionText = SessionText(runner, sessionFields, runnerReason);
            try { File.WriteAllText(Path.Combine(folder, "env.txt"), env.Text, new UTF8Encoding(false)); } catch (Exception) { }

            var txt = new StringBuilder();
            txt.Append("RADAR INCIDENT ").Append(now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append('\n');
            txt.Append("process   : ").Append(process).Append('\n');
            txt.Append("page      : ").Append(page).Append('\n');
            txt.Append("machine   : ").Append(Environment.MachineName).Append(" / ").Append(Environment.UserName).Append('\n');
            txt.Append("exception : ").Append(exType).Append('\n');
            txt.Append("stage     : ").Append(exStage).Append('\n');
            txt.Append("detail    : ").Append(exDetail).Append('\n');
            txt.Append("screenshot: ").Append(shotFile != null ? "screenshot.png" : "skipped (" + shotNote + ")").Append('\n');
            txt.Append("at throw  : ").Append(throwShotNote).Append('\n');
            txt.Append("hook      : ").Append(hookStatus).Append('\n');
            txt.Append("session   : ").Append(sessionFields.ContainsKey("session_no") && sessionFields["session_no"] != null ? "number " + sessionFields["session_no"] + " id " + sessionFields["session_id"] : OneLine(sessionText, 160)).Append('\n');
            txt.Append("env       : ").Append(EnvLine()).Append('\n');
            txt.Append("\n--- environment at failure (also env.txt) ---\n").Append(env.Text);
            txt.Append("\n--- .NET exceptions at throw time (hook; last ").Append(ThrowsKept).Append(", oldest first) ---\n");
            if (throws.Count == 0) txt.Append("(none)\n");
            foreach (var t in throws)
            {
                txt.Append(t.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append(" | ").Append(t.Type).Append(": ").Append(t.Message).Append('\n');
                if (t.Inner != null) txt.Append("    inner: ").Append(t.Inner).Append('\n');
                if (t.Object != null) txt.Append("    thrown in: ").Append(t.Object).Append('.').Append(t.Stage).Append(t.Kind != null ? " (" + t.Kind + ")" : "").Append('\n');
                foreach (var f in t.Frames.Split('\n')) if (f.Length > 0) txt.Append("    ").Append(f).Append('\n');
            }
            txt.Append("\n--- data items at failure ---\n").Append(dataItems ?? "").Append(dataItems != null && dataItems.EndsWith("\n") ? "" : "\n");
            txt.Append("\n--- trail (oldest first; ").Append(snapshot.Count).Append(" kept, ").Append(dropped).Append(" dropped, capacity ").Append(cap).Append(") ---\n");
            foreach (var e in snapshot) txt.Append(Line(e)).Append('\n');
            AppendLayersText(txt, stageLog, stageDropped, chainItems, slStatus, dcStatus, path, sessionText);
            File.WriteAllText(Path.Combine(folder, "incident.txt"), txt.ToString(), new UTF8Encoding(false));

            var js = new StringBuilder();
            js.Append("{\n");
            js.Append("  \"at\": ").Append(J(now.ToString("o"))).Append(",\n");
            js.Append("  \"process\": ").Append(J(process)).Append(",\n");
            js.Append("  \"page\": ").Append(J(page)).Append(",\n");
            js.Append("  \"machine\": ").Append(J(Environment.MachineName)).Append(",\n");
            js.Append("  \"user\": ").Append(J(Environment.UserName)).Append(",\n");
            js.Append("  \"exception\": { \"type\": ").Append(J(exType)).Append(", \"stage\": ").Append(J(exStage)).Append(", \"detail\": ").Append(J(exDetail)).Append(" },\n");
            js.Append("  \"screenshot\": ").Append(shotFile != null ? J("screenshot.png") : "null").Append(",\n");
            js.Append("  \"screenshot_note\": ").Append(J(shotNote)).Append(",\n");
            js.Append("  \"screenshot_at_throw\": ").Append(throwShotNote.EndsWith(".png") ? J(throwShotNote) : "null").Append(",\n");
            js.Append("  \"hook\": ").Append(J(hookStatus)).Append(",\n");
            js.Append("  \"env\": ").Append(J(EnvLine())).Append(",\n");
            js.Append("  \"environment\": {");
            { bool first = true; foreach (var kv in env.Fields) { js.Append(first ? " " : ", ").Append(J(kv.Key)).Append(": ").Append(J(kv.Value)); first = false; } }
            js.Append(env.Fields.Count > 0 ? ", " : " ").Append("\"file\": \"env.txt\" },\n");
            js.Append("  \"throws\": [\n");
            for (int i = 0; i < throws.Count; i++)
            {
                var t = throws[i];
                js.Append("    { \"at\": ").Append(J(t.At.ToString("o"))).Append(", \"type\": ").Append(J(t.Type)).Append(", \"message\": ").Append(J(t.Message))
                  .Append(", \"inner\": ").Append(J(t.Inner)).Append(", \"object\": ").Append(J(t.Object)).Append(", \"stage\": ").Append(J(t.Stage))
                  .Append(", \"kind\": ").Append(J(t.Kind)).Append(", \"frames\": ").Append(J(t.Frames.TrimEnd('\n'))).Append(" }").Append(i + 1 < throws.Count ? ",\n" : "\n");
            }
            js.Append("  ],\n");
            js.Append("  \"data_items\": ").Append(DataItemsJson(dataItems)).Append(",\n");
            js.Append("  \"dropped\": ").Append(dropped).Append(",\n");
            js.Append("  \"trail\": [\n");
            for (int i = 0; i < snapshot.Count; i++)
            {
                var e = snapshot[i];
                js.Append("    { \"seq\": ").Append(e.Seq).Append(", \"at\": ").Append(J(e.At.ToString("o")))
                  .Append(", \"label\": ").Append(J(e.Label)).Append(", \"detail\": ").Append(J(e.Detail)).Append(" }")
                  .Append(i + 1 < snapshot.Count ? ",\n" : "\n");
            }
            js.Append("  ],\n");
            AppendLayersJson(js, stageLog, stageDropped, chainItems, path, sessionFields);
            js.Append("}\n");
            File.WriteAllText(Path.Combine(folder, "incident.json"), js.ToString(), new UTF8Encoding(false));

            lock (Gate)
            {
                Rings.Remove(System.Threading.Thread.CurrentThread.ManagedThreadId);
                var fresh = Mine();
                fresh.LastDumpKey = key; fresh.LastDumpFolder = folder; fresh.LastDumpAt = now;
            }
            return folder;
        }
        catch (Exception ex)
        {
            return "ERROR: " + ex.GetType().Name + ": " + ex.Message;
        }
    }

    /// "name=value" lines -> JSON object. A line without '=' becomes a key with null.
    static string DataItemsJson(string dataItems)
    {
        var sb = new StringBuilder("{");
        bool first = true;
        foreach (var raw in (dataItems ?? "").Replace("\r", "").Split('\n'))
        {
            var line = raw.Trim();
            if (line.Length == 0) continue;
            int eq = line.IndexOf('=');
            string k = eq < 0 ? line : line.Substring(0, eq).Trim();
            string v = eq < 0 ? null : line.Substring(eq + 1);
            sb.Append(first ? " " : ", ").Append(J(k)).Append(": ").Append(v == null ? "null" : J(v));
            first = false;
        }
        return sb.Append(first ? "}" : " }").ToString();
    }

    static string J(string s)
    {
        if (s == null) return "null";
        var sb = new StringBuilder("\"");
        foreach (var c in s)
        {
            switch (c)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.Append('"').ToString();
    }

    static string Safe(string s)
    {
        if (string.IsNullOrEmpty(s)) return "x";
        var sb = new StringBuilder();
        foreach (var c in s)
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var r = sb.ToString().Trim('_');
        return r.Length > 40 ? r.Substring(0, 40) : (r.Length == 0 ? "x" : r);
    }

    // ---- screenshot: whole virtual desktop via GDI+, Windows only; any failure is reported, never thrown ----
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int n);

    /// <summary>The machine fingerprint that changes between resources and explains "works on mine": culture
    /// (date/number formats), OS, bitness, screen size. One line, never throws.</summary>
    public static string EnvLine()
    {
        try
        {
            var c = CultureInfo.CurrentCulture;
            var sb = new StringBuilder();
            sb.Append("culture ").Append(c.Name).Append(" (ui ").Append(CultureInfo.CurrentUICulture.Name).Append(") date ")
              .Append(c.DateTimeFormat.ShortDatePattern).Append(" decimal '").Append(c.NumberFormat.NumberDecimalSeparator)
              .Append("' group '").Append(c.NumberFormat.NumberGroupSeparator).Append("' | os ").Append(Environment.OSVersion.Version)
              .Append(Environment.Is64BitProcess ? " x64" : " x86").Append(" clr ").Append(Environment.Version);
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
                sb.Append(" | screen ").Append(w).Append('x').Append(h);
            }
            return sb.ToString();
        }
        catch (Exception ex) { return "unavailable (" + ex.GetType().Name + ")"; }
    }
    const int SM_XVIRTUALSCREEN = 76, SM_YVIRTUALSCREEN = 77, SM_CXVIRTUALSCREEN = 78, SM_CYVIRTUALSCREEN = 79;

    // ---- environment snapshot at failure: session type, memory, disk, the automated apps' processes, event log,
    // network, clock. Plain .NET; every section reports "unavailable (...)" instead of throwing; bounded in time. ----
    public class EnvInfo
    {
        public string Text = "";
        public readonly Dictionary<string, string> Fields = new Dictionary<string, string>();
        public string Field(string k) { string v; return Fields.TryGetValue(k, out v) ? v : null; }
    }

    [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);
    [StructLayout(LayoutKind.Sequential)] struct MEMORYSTATUSEX
    {
        public uint dwLength, dwMemoryLoad;
        public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
    }
    const int SM_REMOTESESSION = 0x1000;
    const int EventLogMinutes = 10, EventLogMax = 20, EventLogScan = 400, AppLinesMax = 40;
    // process names of the things the estate automates or runs; everything else is only counted
    static readonly string[] WatchedApps = { "msedge", "chrome", "iexplore", "firefox", "excel", "winword", "outlook", "acrobat", "acrord32",
        "java", "javaw", "javaws", "wfica32", "mstsc", "cmd", "powershell", "sapgui", "saplogon", "notepad", "automate", "automatec", "appman", "bpserver" };

    static string Mb(ulong b) { return (b / (1024UL * 1024UL)).ToString(CultureInfo.InvariantCulture); }
    static string Mb(long b) { return (b / (1024L * 1024L)).ToString(CultureInfo.InvariantCulture); }

    /// <summary>Everything about the machine at the moment of failure that a session log never records.
    /// Each section is independent; a failing section prints its reason and the rest continue.</summary>
    public static EnvInfo EnvSnapshot()
    {
        bool outer = !_inRadar;
        _inRadar = true;
        try { return EnvSnapshotCore(); }
        finally { if (outer) _inRadar = false; }
    }

    static EnvInfo EnvSnapshotCore()
    {
        var e = new EnvInfo();
        var sb = new StringBuilder();
        var total = Stopwatch.StartNew();
        bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;

        // session: console / RDP / Citrix, interactive or not
        try
        {
            string sn = Environment.GetEnvironmentVariable("SESSIONNAME") ?? "", cn = Environment.GetEnvironmentVariable("CLIENTNAME") ?? "";
            bool remote = false; try { remote = win && GetSystemMetrics(SM_REMOTESESSION) != 0; } catch (Exception) { }
            string kind = sn.StartsWith("ICA", StringComparison.OrdinalIgnoreCase) ? "Citrix ICA" : sn.StartsWith("RDP", StringComparison.OrdinalIgnoreCase) ? "RDP" : sn.Length > 0 ? sn : "unknown";
            int sid = -1; try { sid = Process.GetCurrentProcess().SessionId; } catch (Exception) { }
            sb.Append("session   : ").Append(kind).Append(remote ? " (remote)" : " (local)").Append(" id ").Append(sid)
              .Append(" name '").Append(sn).Append("' client '").Append(cn).Append("' interactive ").Append(Environment.UserInteractive)
              .Append(" user ").Append(Environment.UserDomainName).Append('\\').Append(Environment.UserName).Append('\n');
            e.Fields["session"] = kind; e.Fields["remote"] = remote ? "true" : "false"; e.Fields["client"] = cn;
        }
        catch (Exception ex) { sb.Append("session   : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // memory + this process
        try
        {
            var m = new MEMORYSTATUSEX(); m.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            if (win && GlobalMemoryStatusEx(ref m))
            {
                sb.Append("memory    : ").Append(Mb(m.ullAvailPhys)).Append(" MB free of ").Append(Mb(m.ullTotalPhys)).Append(" MB (").Append(m.dwMemoryLoad).Append("% used), page file ")
                  .Append(Mb(m.ullAvailPageFile)).Append(" MB free of ").Append(Mb(m.ullTotalPageFile)).Append(" MB\n");
                e.Fields["mem_free_mb"] = Mb(m.ullAvailPhys); e.Fields["mem_total_mb"] = Mb(m.ullTotalPhys); e.Fields["mem_load_pct"] = m.dwMemoryLoad.ToString(CultureInfo.InvariantCulture);
            }
            else sb.Append("memory    : unavailable (not Windows)\n");
        }
        catch (Exception ex) { sb.Append("memory    : unavailable (").Append(ex.GetType().Name).Append(")\n"); }
        try
        {
            var p = Process.GetCurrentProcess();
            sb.Append("this proc : ").Append(p.ProcessName).Append(" pid ").Append(p.Id).Append(" working set ").Append(Mb(p.WorkingSet64)).Append(" MB, ")
              .Append(p.HandleCount).Append(" handles, ").Append(p.Threads.Count).Append(" threads, started ").Append(p.StartTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture))
              .Append(" | machine up ").Append((Environment.TickCount / 1000 / 60).ToString(CultureInfo.InvariantCulture)).Append(" min | ").Append(Environment.ProcessorCount).Append(" cpu\n");
            e.Fields["working_set_mb"] = Mb(p.WorkingSet64); e.Fields["handles"] = p.HandleCount.ToString(CultureInfo.InvariantCulture);
        }
        catch (Exception ex) { sb.Append("this proc : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // disk: the dump drive and the temp drive
        try
        {
            var seen = new List<string>();
            foreach (var path in new[] { Root, Path.GetTempPath() })
            {
                string rootName; try { rootName = Path.GetPathRoot(Path.GetFullPath(path)); } catch (Exception) { continue; }
                if (rootName == null || seen.Contains(rootName)) continue; seen.Add(rootName);
                try { var d = new DriveInfo(rootName); sb.Append("disk      : ").Append(rootName).Append(' ').Append(Mb(d.AvailableFreeSpace)).Append(" MB free of ").Append(Mb(d.TotalSize)).Append(" MB\n"); if (!e.Fields.ContainsKey("disk_free_mb")) e.Fields["disk_free_mb"] = Mb(d.AvailableFreeSpace); }
                catch (Exception ex) { sb.Append("disk      : ").Append(rootName).Append(" unavailable (").Append(ex.GetType().Name).Append(")\n"); }
            }
        }
        catch (Exception ex) { sb.Append("disk      : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // network + clock
        try
        {
            string host = ""; try { host = System.Net.Dns.GetHostName(); } catch (Exception) { }
            bool net = false; try { net = System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable(); } catch (Exception) { }
            var ips = new List<string>();
            try
            {
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up || ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback) continue;
                    foreach (var a in ni.GetIPProperties().UnicastAddresses)
                        if (a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && ips.Count < 4) ips.Add(a.Address.ToString());
                }
            }
            catch (Exception) { }
            sb.Append("network   : ").Append(net ? "available" : "NOT available").Append(" host ").Append(host).Append(" ip ").Append(ips.Count > 0 ? string.Join(",", ips.ToArray()) : "-").Append('\n');
            e.Fields["network"] = net ? "available" : "unavailable";
        }
        catch (Exception ex) { sb.Append("network   : unavailable (").Append(ex.GetType().Name).Append(")\n"); }
        try
        {
            var now = DateTime.Now;
            sb.Append("clock     : ").Append(now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)).Append(" local, utc").Append(TimeZoneInfo.Local.GetUtcOffset(now).TotalHours >= 0 ? "+" : "")
              .Append(TimeZoneInfo.Local.GetUtcOffset(now).TotalHours.ToString(CultureInfo.InvariantCulture)).Append(" (").Append(TimeZoneInfo.Local.Id).Append(")\n");
        }
        catch (Exception ex) { sb.Append("clock     : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // the automated apps: is the process the object attached to still alive, and what is its window called now
        try
        {
            var all = Process.GetProcesses();
            var lines = new List<string>(); var counts = new SortedDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in all)
            {
                string name; try { name = p.ProcessName; } catch (Exception) { continue; }
                int c; counts.TryGetValue(name, out c); counts[name] = c + 1;
                if (Array.IndexOf(WatchedApps, name.ToLowerInvariant()) < 0) continue;
                if (lines.Count >= AppLinesMax) continue;
                string title = "", started = "", ws = "", resp = "";
                try { title = p.MainWindowTitle ?? ""; } catch (Exception) { }
                try { started = p.StartTime.ToString("HH:mm:ss", CultureInfo.InvariantCulture); } catch (Exception) { started = "?"; }
                try { ws = Mb(p.WorkingSet64) + " MB"; } catch (Exception) { }
                try { resp = p.Responding ? "" : " NOT RESPONDING"; } catch (Exception) { }
                lines.Add("  " + name + " pid " + p.Id + " started " + started + " " + ws + resp + (title.Length > 0 ? " title \"" + OneLine(title, 100) + "\"" : " (no main window)"));
            }
            sb.Append("apps      : ").Append(all.Length).Append(" processes; watched ones:\n");
            if (lines.Count == 0) sb.Append("  (none of the watched apps is running)\n");
            lines.Sort(StringComparer.OrdinalIgnoreCase); foreach (var l in lines) sb.Append(l).Append('\n');
            var top = new List<KeyValuePair<string, int>>(counts); top.Sort((a, b) => b.Value.CompareTo(a.Value));
            var tops = new StringBuilder(); for (int i = 0; i < top.Count && i < 8; i++) tops.Append(i > 0 ? ", " : "").Append(top[i].Key).Append(" x").Append(top[i].Value);
            sb.Append("  most instances: ").Append(tops).Append('\n');
            e.Fields["processes"] = all.Length.ToString(CultureInfo.InvariantCulture); e.Fields["watched_apps"] = lines.Count.ToString(CultureInfo.InvariantCulture);
            foreach (var p in all) try { p.Dispose(); } catch (Exception) { }
        }
        catch (Exception ex) { sb.Append("apps      : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // event log: errors and warnings of the last minutes (Application + System), newest first, bounded scan
        try
        {
            if (!win) throw new PlatformNotSupportedException();
            var since = DateTime.Now.AddMinutes(-EventLogMinutes); int found = 0, scanned = 0; var ev = new StringBuilder();
            foreach (var logName in new[] { "Application", "System" })
            {
                try
                {
                    using (var log = new EventLog(logName))
                    {
                        var entries = log.Entries; int n = entries.Count;
                        for (int i = n - 1; i >= 0 && scanned < EventLogScan && found < EventLogMax; i--, scanned++)
                        {
                            EventLogEntry en; try { en = entries[i]; } catch (Exception) { break; }
                            if (en.TimeGenerated < since) break;
                            if (en.EntryType != EventLogEntryType.Error && en.EntryType != EventLogEntryType.Warning) continue;
                            found++;
                            ev.Append("  ").Append(en.TimeGenerated.ToString("HH:mm:ss", CultureInfo.InvariantCulture)).Append(' ').Append(logName).Append(' ').Append(en.EntryType).Append(' ').Append(en.Source).Append(": ").Append(OneLine(en.Message, 160)).Append('\n');
                        }
                    }
                }
                catch (Exception ex) { ev.Append("  ").Append(logName).Append(": unavailable (").Append(ex.GetType().Name).Append(")\n"); }
            }
            sb.Append("event log : ").Append(found).Append(" error/warning entries in the last ").Append(EventLogMinutes).Append(" min\n").Append(ev);
            e.Fields["event_errors"] = found.ToString(CultureInfo.InvariantCulture);
        }
        catch (Exception ex) { sb.Append("event log : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        sb.Append("snapshot  : took ").Append(total.ElapsedMilliseconds).Append(" ms\n");
        e.Fields["snapshot_ms"] = total.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture);
        e.Text = sb.ToString();
        return e;
    }

    static string Screenshot(string file)
    {
        if (Environment.OSVersion.Platform != PlatformID.Win32NT) return "not Windows (" + Environment.OSVersion.Platform + ")";
        try
        {
            int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
            int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
            if (w <= 0 || h <= 0) return "no screen (" + w + "x" + h + ")";
            using (var bmp = new System.Drawing.Bitmap(w, h))
            {
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                    g.CopyFromScreen(x, y, 0, 0, new System.Drawing.Size(w, h));
                bmp.Save(file, System.Drawing.Imaging.ImageFormat.Png);
            }
            return "ok";
        }
        catch (Exception ex)
        {
            return ex.GetType().Name + ": " + ex.Message;
        }
    }

    // =====================================================================================================================
    // v15: two optional capture layers for Dump. Both OFF by default (Configure flags), both self-disable
    // with a reason in HookStatus, neither can throw into the robot.
    //   Stage Log  : a LoggingEngine subclass built at runtime (Reflection.Emit) whose every abstract method
    //                forwards (method, args[]) to OnStageEvent; one instance is appended to the session's
    //                CompoundLoggingEngine with its public Add(). The DB engine is not touched or reordered.
    //   Data Chain : page -> sub-page -> object action -> stage, from the same event stream (push on
    //                Process/SubSheet/Object/Action Prologue, pop on the matching Epilogue); at Dump the data
    //                and collection stages of each frame's page are read from the frame stage's Process.
    // Blue Prism members used (discover.txt, BP 7.2.1.15451), all by reflection, all guarded:
    //   RunnerRecord.mRunnerThread : Thread, RunnerRecord.mProcess : BluePrismProcess, RunnerRecord.mLog : LoggingEngine
    //   BluePrismProcess.Logger : CompoundLoggingEngine (internal) / BluePrismProcess._logger, BluePrismProcess.Name,
    //   BluePrismProcess.GetStages(Guid) : List<ProcessStage>, CompoundLoggingEngine.Add(LoggingEngine)
    //   ProcessStage.Name / StageType / SubSheet / Process / GetSubSheetID(), ProcessSubSheet.Name
    //   DataStage.Value : ProcessValue, CollectionStage.CurrentCollection : Collection
    //   ProcessValue.DataType / FormattedValue / Collection, Collection.Count / Rows, CollectionRow : Dictionary<string, ProcessValue>
    //   Argument.Name / Argument.Value (NOT in discover.txt: only "Argument : object (14)"; read by name, ToString fallback)
    // =====================================================================================================================

    /// One stage-log row, the columns of a Complete session log export (clsSessionLogEntry).
    public class StageRec
    {
        public long Seq;
        public DateTime Start, End;
        public bool Open, Unwound;
        public string Method, StageName, StageType, Page, Process, ObjectName, ActionName, Result, InXml, OutXml;
        public string MemAutomate, MemTarget;   // LogInfo.AutomateWorkingSet / TargetAppWorkingSet at the prologue (memory per stage)
        internal object StageRef;
    }
    /// One event of the exception path: where it was thrown (LogError), each Exception stage (rethrow or new),
    /// where it was caught (Recover) and resumed (Resume), with the live stage's own fields.
    public class PathRec { public DateTime At; public string Method, Process, Page, Stage, Detail; }
    public class ChainFrame { public string Kind, Name; public object Stage; }
    public class ChainCapture
    {
        public string Kind, Process, Page, Stage, Note;
        public string Recovery;     // the frame's own BluePrismProcess: ExceptionSource / RecoverySource / RecoveryType / RecoveryDetail / RecoveryMode
        public string Elements;     // for an application stage: steps, element ids (GetElementsUsed), timeout, resolved element names/attributes
        public readonly List<KeyValuePair<string, string>> Items = new List<KeyValuePair<string, string>>();
    }
    class StageSession
    {
        public readonly List<StageRec> Ring = new List<StageRec>();
        public readonly List<ChainFrame> Chain = new List<ChainFrame>();   // Process/SubSheet/Object/Action frames, outermost first
        public readonly List<ChainFrame> Open = new List<ChainFrame>();    // every Prologue without its Epilogue (current stage = last)
        public readonly List<PathRec> Path = new List<PathRec>();          // exception path events, oldest first, bounded
        public object Runner;                                              // the session's RunnerRecord (session identity), when found
        public long Seq, Dropped, Events, Stages, ActionsSinceInstall, Hidden;
        public bool Installed, Probed;   // Probed: the handle search ran on this session (it runs at most once)
        public string Reason;            // why the layer is not available on this session (null = fine)
    }

    static readonly Dictionary<int, StageSession> StageSessions = new Dictionary<int, StageSession>();
    static bool _stageLogOn, _dataChainOn;
    static int _stageCapacity = 500;
    static long _stageProbes;
    [ThreadStatic] static long _lastHidden;
    static string[] _hiddenProcesses = new[] { "Radar" };
    /// Objects whose own stages are not written to the stage log (they still count for the chain). Default: Radar.
    public static string[] HiddenProcesses { get { lock (Gate) return (string[])_hiddenProcesses.Clone(); } set { lock (Gate) _hiddenProcesses = value ?? new string[0]; } }
    static bool IsHidden(string proc) { if (proc == null) return false; foreach (var h in _hiddenProcesses) if (string.Equals(h, proc, StringComparison.OrdinalIgnoreCase)) return true; return false; }
    const int ChainMax = 64, OpenMax = 64, NoEventActions = 5, ProbeMs = 2000, ProbeObjects = 20000, PathMax = 40;
    const int CaptureMs = 1000, CaptureItems = 200, CollRows = 5, ValueMax = 300, ParamsMax = 2000, ArgsMax = 50;
    static readonly Dictionary<Type, Type> Forwarders = new Dictionary<Type, Type>();

    /// How many times the handle probe ran in this process (stays 0 while both flags are off).
    public static long StageProbeCount { get { lock (Gate) return _stageProbes; } }
    public static int StageCapacity { get { lock (Gate) return _stageCapacity; } set { lock (Gate) if (value > 0) _stageCapacity = value; } }
    public static int StageLogCount { get { lock (Gate) { var s = StageMine(false); return s == null ? 0 : s.Ring.Count; } } }
    public static long StageLogDropped { get { lock (Gate) { var s = StageMine(false); return s == null ? 0 : s.Dropped; } } }
    public static int ChainDepth { get { lock (Gate) { var s = StageMine(false); return s == null ? 0 : s.Chain.Count; } } }

    static int Tid { get { return System.Threading.Thread.CurrentThread.ManagedThreadId; } }
    static StageSession StageMine(bool create)
    {
        StageSession s;
        if (!StageSessions.TryGetValue(Tid, out s) && create) { s = new StageSession(); StageSessions[Tid] = s; }
        return s;
    }

    static string LayerStatusLocked(bool log)
    {
        var s = StageMine(false);
        if (s == null) return "not available (not configured on this session)";
        if (s.Reason != null) return "not available (" + s.Reason + ")";
        if (s.Events == 0)
            return s.ActionsSinceInstall >= NoEventActions ? "not available (no events after " + NoEventActions + " Radar actions)" : "not available (no events yet)";
        return log ? "live (" + s.Ring.Count + " entries, " + s.Stages + " stages)" : "live (depth " + s.Chain.Count + ")";
    }
    static string StageLogStatusLocked() { return !_stageLogOn ? "off" : LayerStatusLocked(true); }
    static string DataChainStatusLocked() { return !_dataChainOn ? "off" : LayerStatusLocked(false); }

    /// Every Radar action of a session counts; an attached engine that saw nothing after N of them is declared dead.
    static void NoteRadarAction()
    {
        if (!_stageLogOn && !_dataChainOn) return;
        try { lock (Gate) { var s = StageMine(false); if (s != null && s.Installed && s.Events == 0) s.ActionsSinceInstall++; } }
        catch (Exception) { }
    }

    // ---- install: find this session's CompoundLoggingEngine, append one forwarder ----
    static void InstallStageEngine()
    {
        bool outer = !_inRadar; _inRadar = true;
        StageSession s = null;
        try
        {
            lock (Gate) { s = StageMine(true); if (s.Installed || s.Probed) return; s.Probed = true; _stageProbes++; }
            string why; object runner;
            object compound = FindCompoundEngine(out why, out runner);
            if (runner != null) lock (Gate) s.Runner = runner;
            if (compound == null) { lock (Gate) s.Reason = why; return; }
            Type baseType = BaseNamed(compound.GetType(), "LoggingEngine");
            if (baseType == null) { lock (Gate) s.Reason = "LoggingEngine not in the base chain of " + compound.GetType().FullName; return; }
            var en = compound as IEnumerable;
            if (en != null) foreach (var e in en) if (e != null && e.GetType().Name == "RadarStageForwarder") { lock (Gate) { s.Installed = true; s.Reason = null; } return; }
            string err;
            object eng = CreateStageForwarder(baseType, compound, out err);
            if (eng == null) { lock (Gate) s.Reason = "Emit failed: " + err; return; }
            var add = compound.GetType().GetMethod("Add", BindingFlags.Public | BindingFlags.Instance, null, new[] { baseType }, null);
            if (add == null) { lock (Gate) s.Reason = "CompoundLoggingEngine.Add(LoggingEngine) not found"; return; }
            add.Invoke(compound, new[] { eng });
            lock (Gate) { s.Installed = true; s.Reason = null; s.ActionsSinceInstall = 0; }
        }
        catch (Exception ex) { try { lock (Gate) { if (s == null) s = StageMine(true); s.Reason = "install failed: " + Inner(ex).GetType().Name + ": " + OneLine(Inner(ex).Message, 200); } } catch (Exception) { } }
        finally { if (outer) _inRadar = false; }
    }

    static Exception Inner(Exception e) { while (e is TargetInvocationException && e.InnerException != null) e = e.InnerException; return e; }
    static Type BaseNamed(Type t, string name) { for (; t != null; t = t.BaseType) if (t.Name == name) return t; return null; }

    /// No static handle to a logging engine exists in discover.txt [roots] (the section hit its cap). The way in:
    /// the RunnerRecord whose mRunnerThread is this thread, reached from static fields of the Blue Prism
    /// assemblies (depth 3, framework collections only), then its mProcess.Logger. Bounded: 2 s, 20000 objects.
    static object FindCompoundEngine(out string why, out object runnerOut)
    {
        why = null; runnerOut = null;
        var sw = Stopwatch.StartNew();
        Assembly appCore = null, procCore = null;
        var bp = new List<Assembly>();
        foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
        {
            string n; try { n = a.GetName().Name; } catch (Exception) { continue; }
            if (n == "AutomateAppCore") appCore = a;
            if (n == "AutomateProcessCore") procCore = a;
            if (n == "Automate" || n == "AutomateUI" || n == "AutomateAppCore" || n == "AutomateProcessCore") bp.Add(a);
        }
        if (procCore == null) { why = "AutomateProcessCore not loaded (not a Blue Prism runtime)"; return null; }
        Type runnerT = appCore == null ? null : appCore.GetType("BluePrism.AutomateAppCore.RunnerRecord", false);
        if (runnerT == null) { why = "RunnerRecord type not found"; return null; }
        const BindingFlags I = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var thrF = runnerT.GetField("mRunnerThread", I); var procF = runnerT.GetField("mProcess", I); var logF = runnerT.GetField("mLog", I);
        if (thrF == null || procF == null) { why = "RunnerRecord shape differs (no mRunnerThread/mProcess)"; return null; }
        var ctx = new Probe { Match = o => runnerT.IsInstanceOfType(o) && ReferenceEquals(SafeField(thrF, o), System.Threading.Thread.CurrentThread), Sw = sw, Bp = bp };
        // route 1: the open forms. frmResourcePC's view events are handled by ListenerResourceRunner, which holds
        // _mListener (TcpListener) -> _Runners (RunnerRecordList) -> mList -> ListenerRunnerRecord (discover.txt)
        string formsNote;
        object runner = ctx.VisitAll(OpenForms(out formsNote));
        string route1 = "forms route: " + formsNote + ", " + ctx.Scanned + " objects";
        if (runner == null)
        foreach (var asm in bp)
        {
            Type[] types; try { types = asm.GetTypes(); } catch (ReflectionTypeLoadException e) { types = e.Types; } catch (Exception) { continue; }
            foreach (var t in types)
            {
                if (t == null || t.IsGenericTypeDefinition || t.IsEnum || t.IsInterface) continue;
                FieldInfo[] fs; try { fs = t.GetFields(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly); } catch (Exception) { continue; }
                foreach (var f in fs)
                {
                    if (f.IsLiteral || f.FieldType.IsPrimitive || f.FieldType.IsEnum || f.FieldType == typeof(string)) continue;
                    if (ctx.Over) { why = route1 + "; static route: stopped at " + (sw.ElapsedMilliseconds >= ProbeMs ? "2 s" : ProbeObjects + " objects") + " (" + ctx.Scanned + " objects scanned, no RunnerRecord for this thread)"; return null; }
                    object v; try { v = f.GetValue(null); } catch (Exception) { continue; }
                    runner = ctx.Visit(v, 0);
                    if (runner != null) break;
                }
                if (runner != null) break;
            }
            if (runner != null) break;
        }
        if (runner == null) { why = "no RunnerRecord for this thread (" + route1 + "; static route: " + ctx.Scanned + " objects in total)"; return null; }
        runnerOut = runner;
        object proc = null; try { proc = procF.GetValue(runner); } catch (Exception) { }
        object compound = Get(proc, "Logger") ?? Get(proc, "_logger");
        if (compound == null && logF != null) { try { var l = logF.GetValue(runner); if (l != null && l.GetType().Name == "CompoundLoggingEngine") compound = l; } catch (Exception) { } }
        if (compound == null) { why = "RunnerRecord found, but its process has no CompoundLoggingEngine (Logger/_logger null)"; return null; }
        if (compound.GetType().Name != "CompoundLoggingEngine") { why = "logger is " + compound.GetType().FullName + ", not CompoundLoggingEngine"; return null; }
        return compound;
    }

    sealed class RefEq : IEqualityComparer<object>
    {
        public new bool Equals(object a, object b) { return ReferenceEquals(a, b); }
        public int GetHashCode(object o) { return System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode(o); }
    }
    static object SafeField(FieldInfo f, object o) { try { return f.GetValue(o); } catch (Exception) { return null; } }

    /// Application.OpenForms by reflection (System.Windows.Forms is loaded in Automate; no reference needed). Copy of the list.
    static List<object> OpenForms(out string note)
    {
        var res = new List<object>();
        try
        {
            Assembly wf = null;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies()) { try { if (a.GetName().Name == "System.Windows.Forms") { wf = a; break; } } catch (Exception) { } }
            if (wf == null) { note = "WinForms not loaded"; return res; }
            var app = wf.GetType("System.Windows.Forms.Application", false);
            var p = app == null ? null : app.GetProperty("OpenForms", BindingFlags.Public | BindingFlags.Static);
            var forms = p == null ? null : p.GetValue(null, null) as IEnumerable;
            if (forms == null) { note = "no OpenForms"; return res; }
            for (int attempt = 0; attempt < 3; attempt++)
            {
                try { res.Clear(); foreach (var f in forms) if (f != null) res.Add(f); break; }
                catch (InvalidOperationException) { }    // the UI thread changed the list while copying: retry
            }
            var names = new List<string>(); foreach (var f in res) names.Add(f.GetType().Name);
            note = res.Count + " forms (" + string.Join(", ", names.ToArray()) + ")";
        }
        catch (Exception ex) { note = "forms unreadable (" + ex.GetType().Name + ")"; }
        return res;
    }

    /// Breadth-limited object walk: framework containers are enumerated, delegates followed to their targets,
    /// other objects only through fields declared in the allowed assemblies. Reads fields, calls no Blue Prism code.
    public static object FindReachable(IEnumerable roots, Func<object, bool> match, List<Assembly> allowed, int maxDepth, out int scanned)
    {
        var ctx = new Probe { Match = match, Sw = Stopwatch.StartNew(), Bp = allowed, MaxDepth = maxDepth };
        var r = ctx.VisitAll(roots);
        scanned = ctx.Scanned;
        return r;
    }

    sealed class Probe
    {
        public Func<object, bool> Match; public Stopwatch Sw; public List<Assembly> Bp; public int MaxDepth = 7;
        public int Scanned;
        readonly HashSet<object> seen = new HashSet<object>(new RefEq());
        public bool Over { get { return Sw.ElapsedMilliseconds >= ProbeMs || Scanned >= ProbeObjects; } }
        public object VisitAll(IEnumerable roots)
        {
            if (roots == null) return null;
            foreach (var o in roots) { if (Over) return null; var r = Visit(o, 0); if (r != null) return r; }
            return null;
        }
        public object Visit(object o, int depth)
        {
            if (o == null || depth > MaxDepth || Over) return null;
            var t = o.GetType();
            if (t.IsPrimitive || t.IsEnum || o is string || o is Type || o is System.Threading.Thread || o is Assembly || o is MemberInfo || o is Stream) return null;
            if (t.IsValueType && !t.IsGenericType) return null;
            if (!seen.Add(o)) return null;
            Scanned++;
            bool hit = false; try { hit = Match(o); } catch (Exception) { }
            if (hit) return o;
            var del = o as Delegate;
            if (del != null)
            {
                Delegate[] list; try { list = del.GetInvocationList(); } catch (Exception) { return null; }
                foreach (var d in list) { var r = Visit(d.Target, depth + 1); if (r != null) return r; }
                return null;
            }
            string ns = t.Namespace ?? "";
            bool framework = t.IsArray || t.Assembly == typeof(object).Assembly || t.Assembly == typeof(Uri).Assembly || ns.StartsWith("System.Collections");
            if (framework)
            {
                var d = o as IDictionary;
                if (d != null)
                {
                    int k = 0;
                    try { foreach (DictionaryEntry e in d) { if (k++ > 500) break; var r = Visit(e.Value, depth + 1) ?? Visit(e.Key, depth + 1); if (r != null) return r; } } catch (Exception) { }
                    return null;
                }
                var en = o as IEnumerable;
                if (en != null)
                {
                    int k = 0;
                    try { foreach (var e in en) { if (k++ > 500) break; var r = Visit(e, depth + 1); if (r != null) return r; } } catch (Exception) { }
                    return null;
                }
            }
            else if (!Bp.Contains(t.Assembly)) return null;
            for (var x = t; x != null && x != typeof(object); x = x.BaseType)
            {
                if (!framework && !Bp.Contains(x.Assembly)) continue;    // skip WinForms/Component internals of a form
                FieldInfo[] fs; try { fs = x.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly); } catch (Exception) { continue; }
                foreach (var f in fs)
                {
                    if (f.FieldType.IsPrimitive || f.FieldType.IsEnum || f.FieldType == typeof(string)) continue;
                    object v; try { v = f.GetValue(o); } catch (Exception) { continue; }
                    var r = Visit(v, depth + 1); if (r != null) return r;
                }
            }
            return null;
        }
    }

    // ---- the Emit routine (proven under mono/PowerShell against a stand-in; the handle is proven on the bank machine) ----

    /// A sealed public subclass of baseType overriding every abstract method with: Sink?.Invoke(name, args[]).
    /// The emitted body cannot throw (its own try/catch). Cached per base type. Null + error when impossible.
    public static Type BuildStageForwarder(Type baseType, out string error)
    {
        error = null;
        try
        {
            lock (Forwarders) { Type ft; if (Forwarders.TryGetValue(baseType, out ft)) return ft; }
            if (baseType == null || baseType.IsSealed || baseType.IsInterface) { error = "base type unusable"; return null; }
            if (!baseType.IsPublic && !baseType.IsNestedPublic) { error = baseType.FullName + " is not public"; return null; }
            var an = new AssemblyName("RadarStageLog_" + Guid.NewGuid().ToString("N").Substring(0, 8));
            var ab = AppDomain.CurrentDomain.DefineDynamicAssembly(an, AssemblyBuilderAccess.Run);
            var mb = ab.DefineDynamicModule(an.Name);
            var tb = mb.DefineType("RadarStageForwarder", TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Class, baseType);
            var sinkT = typeof(Action<string, object[]>);
            var sink = tb.DefineField("Sink", sinkT, FieldAttributes.Public | FieldAttributes.Static);
            // never run (instances come from GetUninitializedObject); present so CreateType needs no base default ctor
            tb.DefineConstructor(MethodAttributes.Private, CallingConventions.Standard, Type.EmptyTypes).GetILGenerator().Emit(OpCodes.Ret);
            var invoke = sinkT.GetMethod("Invoke");
            int n = 0;
            foreach (var m in baseType.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (!m.IsAbstract) continue;
                if (m.IsGenericMethodDefinition) { error = "generic abstract method " + m.Name; return null; }
                if (m.IsAssembly || m.IsFamilyAndAssembly) { error = "internal abstract method " + m.Name; return null; }
                var ps = m.GetParameters(); var pts = new Type[ps.Length];
                for (int i = 0; i < ps.Length; i++) pts[i] = ps[i].ParameterType;
                var attrs = (m.IsPublic ? MethodAttributes.Public : MethodAttributes.Family) | MethodAttributes.Virtual | MethodAttributes.HideBySig;
                if (m.IsSpecialName) attrs |= MethodAttributes.SpecialName;
                var mbld = tb.DefineMethod(m.Name, attrs, m.ReturnType, pts);
                var il = mbld.GetILGenerator();
                var local = il.DeclareLocal(sinkT);
                var done = il.DefineLabel();
                il.Emit(OpCodes.Ldsfld, sink); il.Emit(OpCodes.Stloc, local);
                il.Emit(OpCodes.Ldloc, local); il.Emit(OpCodes.Brfalse, done);
                il.BeginExceptionBlock();
                il.Emit(OpCodes.Ldloc, local);
                il.Emit(OpCodes.Ldstr, m.Name);
                il.Emit(OpCodes.Ldc_I4, ps.Length); il.Emit(OpCodes.Newarr, typeof(object));
                for (int i = 0; i < ps.Length; i++)
                {
                    if (pts[i].IsByRef || pts[i].IsPointer) continue;    // none of the real abstract methods has one
                    il.Emit(OpCodes.Dup); il.Emit(OpCodes.Ldc_I4, i); il.Emit(OpCodes.Ldarg, (short)(i + 1));
                    if (pts[i].IsValueType || pts[i].IsGenericParameter) il.Emit(OpCodes.Box, pts[i]);
                    il.Emit(OpCodes.Stelem_Ref);
                }
                il.Emit(OpCodes.Callvirt, invoke);
                il.BeginCatchBlock(typeof(Exception)); il.Emit(OpCodes.Pop);
                il.EndExceptionBlock();
                il.MarkLabel(done);
                if (m.ReturnType != typeof(void)) { var rl = il.DeclareLocal(m.ReturnType); il.Emit(OpCodes.Ldloc, rl); }
                il.Emit(OpCodes.Ret);
                tb.DefineMethodOverride(mbld, m);
                n++;
            }
            if (n == 0) { error = "no abstract method on " + baseType.FullName; return null; }
            var t = tb.CreateType();
            t.GetField("Sink").SetValue(null, new Action<string, object[]>(OnStageEvent));
            lock (Forwarders) Forwarders[baseType] = t;
            return t;
        }
        catch (Exception ex) { error = Inner(ex).GetType().Name + ": " + OneLine(Inner(ex).Message, 200); return null; }
    }

    /// An instance of the forwarder without running any constructor; the base-class fields (the log context)
    /// are copied from copyFieldsFrom (the session's CompoundLoggingEngine, itself a LoggingEngine).
    public static object CreateStageForwarder(Type baseType, object copyFieldsFrom, out string error)
    {
        var t = BuildStageForwarder(baseType, out error);
        if (t == null) return null;
        try
        {
            object o = System.Runtime.Serialization.FormatterServices.GetUninitializedObject(t);
            GC.SuppressFinalize(o);
            if (copyFieldsFrom != null && baseType.IsInstanceOfType(copyFieldsFrom))
                for (var x = baseType; x != null && x != typeof(object); x = x.BaseType)
                    foreach (var f in x.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                        try { f.SetValue(o, f.GetValue(copyFieldsFrom)); } catch (Exception) { }
            return o;
        }
        catch (Exception ex) { error = Inner(ex).GetType().Name + ": " + OneLine(Inner(ex).Message, 200); return null; }
    }

    static bool IsChainKind(string k) { return k == "Process" || k == "SubSheet" || k == "Object" || k == "Action"; }
    static bool IsAppKind(string k) { return k == "Navigate" || k == "Read" || k == "Write" || k == "Wait" || k == "WaitStart"; }

    /// Called by the forwarder for every logging call of the session, on the session's thread. LogInfo inhibit
    /// flags are ignored on purpose: Radar keeps what the DB engine declines. Never throws.
    public static void OnStageEvent(string method, object[] args)
    {
        if (_inRadar || method == null) return;
        if (!_stageLogOn && !_dataChainOn) return;
        _inRadar = true;
        try
        {
            object stage = null, info = null; var strings = new List<string>(); var lists = new List<string>();
            if (args != null)
                foreach (var a in args)
                {
                    if (a == null) continue;
                    if (a is string) strings.Add((string)a);
                    else if (info == null && Member(a.GetType(), "AutomateWorkingSet") != null) info = a;   // LogInfo
                    else if (stage == null && IsStage(a)) stage = a;
                    else if (a is IEnumerable && !(a is IDictionary)) lists.Add(ArgsXml(a));
                    else if (a is int || a is long || a is bool || a is decimal) strings.Add(Convert.ToString(a, CultureInfo.InvariantCulture));
                    else if (Member(a.GetType(), "FormattedValue") != null) strings.Add(ValueText(a, 0));
                }
            bool pro = method.EndsWith("Prologue"), epi = method.EndsWith("Epilogue");
            string kind = pro ? method.Substring(0, method.Length - 8) : epi ? method.Substring(0, method.Length - 8) : method;
            string objName = null, actName = null;
            if ((kind == "Action" || kind == "Object" || kind == "Skill") && strings.Count >= 2) { objName = strings[0]; actName = strings[1]; strings.RemoveRange(0, 2); }
            string result = strings.Count == 0 ? null : Mask(string.Join(" | ", strings.ToArray()));
            if (method == "LogError" && result != null) result = "ERROR: " + result;
            string sName = null, sType = null, page = null, proc = null;
            if (stage != null)
            {
                sName = Str(Get(stage, "Name")); sType = Str(Get(stage, "StageType"));
                page = Str(Get(Get(stage, "SubSheet"), "Name")); proc = Str(Get(Get(stage, "Process"), "Name"));
            }
            string memA = info == null ? null : Str(Get(info, "AutomateWorkingSet")), memT = info == null ? null : Str(Get(info, "TargetAppWorkingSet"));
            string pathDetail = PathDetail(method, stage, result);
            var now = DateTime.Now;
            lock (Gate)
            {
                var s = StageMine(true);
                s.Events++; s.Reason = null;
                bool hide = IsHidden(proc);
                if (pathDetail != null && !hide)
                {
                    s.Path.Add(new PathRec { At = now, Method = method, Process = proc, Page = page, Stage = sName, Detail = pathDetail });
                    if (s.Path.Count > PathMax) s.Path.RemoveAt(0);
                }
                if (method == "RecoverPrologue" && stage != null) Unwind(s, stage, now);
                if (pro)
                {
                    if (!hide) s.Stages++;
                    if (hide) s.Hidden++;
                    var f = new ChainFrame { Kind = kind, Name = sName, Stage = stage };
                    s.Open.Add(f); if (s.Open.Count > OpenMax) s.Open.RemoveAt(0);
                    if (_dataChainOn && IsChainKind(kind)) { s.Chain.Add(f); if (s.Chain.Count > ChainMax) s.Chain.RemoveAt(0); }
                    if (_stageLogOn && !hide)
                    {
                        s.Seq++;
                        s.Ring.Add(new StageRec { Seq = s.Seq, Start = now, Open = true, Method = method, StageName = sName, StageType = sType, Page = page, Process = proc,
                                                  ObjectName = objName, ActionName = actName, Result = result, InXml = lists.Count > 0 ? lists[0] : null, StageRef = stage,
                                                  MemAutomate = memA, MemTarget = memT });
                        while (s.Ring.Count > _stageCapacity) { s.Ring.RemoveAt(0); s.Dropped++; }
                    }
                }
                else
                {
                    if (epi)
                    {
                        for (int i = s.Open.Count - 1; i >= 0; i--)
                            if (s.Open[i].Kind == kind && (stage == null || ReferenceEquals(s.Open[i].Stage, stage) || IsChainKind(kind))) { s.Open.RemoveAt(i); break; }
                        if (IsChainKind(kind))
                            for (int i = s.Chain.Count - 1; i >= 0; i--)
                                if (s.Chain[i].Kind == kind) { s.Chain.RemoveRange(i, s.Chain.Count - i); break; }
                    }
                    if (_stageLogOn && !hide)
                    {
                        StageRec rec = null;
                        for (int i = s.Ring.Count - 1, k = 0; i >= 0 && k < 200; i--, k++)
                            if (s.Ring[i].Open && ((stage != null && ReferenceEquals(s.Ring[i].StageRef, stage)) || (epi && IsChainKind(kind) && s.Ring[i].Method == kind + "Prologue"))) { rec = s.Ring[i]; break; }
                        if (rec != null)
                        {
                            if (epi) { rec.Open = false; rec.End = now; rec.StageRef = null; }
                            if (rec.MemAutomate == null) { rec.MemAutomate = memA; rec.MemTarget = memT; }
                            if (result != null) rec.Result = rec.Result == null ? result : rec.Result + " | " + result;
                            if (lists.Count > 0) rec.OutXml = lists[lists.Count - 1];
                        }
                        else
                        {
                            s.Seq++;
                            s.Ring.Add(new StageRec { Seq = s.Seq, Start = now, End = now, Method = method, StageName = sName, StageType = sType, Page = page, Process = proc,
                                                      ObjectName = objName, ActionName = actName, Result = result, OutXml = lists.Count > 0 ? lists[lists.Count - 1] : null,
                                                      MemAutomate = memA, MemTarget = memT });
                            while (s.Ring.Count > _stageCapacity) { s.Ring.RemoveAt(0); s.Dropped++; }
                        }
                    }
                }
            }
        }
        catch (Exception) { }
        finally { _inRadar = false; }
    }

    /// The exception-path events and what the live stage says about each. Null for every other event.
    /// ExceptionStage: ExceptionType / ExceptionDetail / UseCurrentException (rethrow) / SaveScreenCapture;
    /// RecoverStage: Attempts / MaxAttempts / LimitAttempts / AttemptsExceeded (retry loops). All guarded, all optional.
    static string PathDetail(string method, object stage, string result)
    {
        try
        {
            switch (method)
            {
                case "LogError": return result ?? "";
                case "ExceptionPrologue":
                {
                    var sb = new StringBuilder();
                    string ty = Str(Get(stage, "ExceptionType")), de = Str(Get(stage, "ExceptionDetail"));
                    bool cur = Str(Get(stage, "UseCurrentException")) == "True", shot = Str(Get(stage, "SaveScreenCapture")) == "True";
                    sb.Append(cur ? "rethrow (current exception)" : "new exception");
                    if (!string.IsNullOrEmpty(ty)) sb.Append(" type=").Append(ty);
                    if (!string.IsNullOrEmpty(de)) sb.Append(" detail=").Append(Mask(OneLine(de, ValueMax)));
                    if (shot) sb.Append(" (save screen capture)");
                    return sb.ToString();
                }
                case "RecoverPrologue":
                {
                    string at = Str(Get(stage, "Attempts")), mx = Str(Get(stage, "MaxAttempts")), lim = Str(Get(stage, "LimitAttempts")), ex = Str(Get(stage, "AttemptsExceeded"));
                    if (at == null && mx == null) return "caught";
                    return "caught; attempts " + (at ?? "?") + "/" + (mx ?? "?") + (lim == "True" ? " (limited)" : "") + (ex == "True" ? " EXCEEDED" : "");
                }
                case "ResumePrologue": return "resumed";
            }
        }
        catch (Exception) { }
        return null;
    }

    /// The frame's own BluePrismProcess exception state (every object is its own process): the stage that raised,
    /// what the last recovery was. Empty when nothing is set.
    static string RecoveryText(object proc)
    {
        try
        {
            if (proc == null) return null;
            var sb = new StringBuilder();
            string src = Str(Get(proc, "ExceptionSource")), rsrc = Str(Get(proc, "RecoverySource"));
            string rty = Str(Get(proc, "RecoveryType")), rde = Str(Get(proc, "RecoveryDetail")), rmo = Str(Get(proc, "RecoveryMode"));
            if (!string.IsNullOrEmpty(src) && src != Guid.Empty.ToString()) sb.Append("exception source ").Append(StageNameOrId(proc, src));
            if (!string.IsNullOrEmpty(rsrc) && rsrc != Guid.Empty.ToString()) sb.Append(sb.Length > 0 ? "; " : "").Append("recovery source ").Append(StageNameOrId(proc, rsrc));
            if (!string.IsNullOrEmpty(rty)) sb.Append(sb.Length > 0 ? "; " : "").Append("recovery type ").Append(rty);
            if (!string.IsNullOrEmpty(rde)) sb.Append(sb.Length > 0 ? "; " : "").Append("detail ").Append(Mask(OneLine(rde, ValueMax)));
            if (!string.IsNullOrEmpty(rmo) && rmo != "False") sb.Append(sb.Length > 0 ? "; " : "").Append("recovery mode ").Append(rmo);
            return sb.Length == 0 ? null : sb.ToString();
        }
        catch (Exception) { return null; }
    }
    static string StageNameOrId(object proc, string id)
    {
        try
        {
            Guid g; if (!Guid.TryParse(id, out g)) return id;
            object st = Call(proc, "GetStage", g);
            string n = Str(Get(st, "Name"));
            return n == null ? id : n + " (" + id + ")";
        }
        catch (Exception) { return id; }
    }

    /// For an application stage (Navigate/Read/Write/Wait): step count, the element ids it used (GetElementsUsed,
    /// confirmed on the wait stage), timeout, and a best-effort name/attribute lookup through the object's
    /// application definition. Member names of Step / ApplicationDefinition / ApplicationElement are not confirmed
    /// by discover.txt; whatever resolves is printed, the rest stays as ids.
    static string ElementsText(object stage, object proc)
    {
        try
        {
            if (stage == null) return null;
            var t = stage.GetType();
            bool app = Member(t, "Steps") != null || HasMethod(t, "GetElementsUsed");
            if (!app) return null;
            var sb = new StringBuilder();
            var steps = Get(stage, "Steps") as IEnumerable;
            int n = 0; if (steps != null) foreach (var st in steps) n++;
            sb.Append("steps ").Append(n);
            string to = Str(Get(stage, "Timeout")); if (!string.IsNullOrEmpty(to)) sb.Append("; timeout ").Append(to);
            var ids = Call(stage, "GetElementsUsed") as IEnumerable;
            object appDef = Get(proc, "_applicationDefinition") ?? Get(proc, "ApplicationDefinition");
            int k = 0;
            if (ids != null)
                foreach (var id in ids)
                {
                    if (k++ >= 10) { sb.Append("; ..."); break; }
                    sb.Append("; element ").Append(Str(id));
                    object el = appDef == null || id == null ? null : (Call(appDef, "FindElement", id) ?? Call(appDef, "GetElement", id));
                    if (el == null) continue;
                    string nm = Str(Get(el, "Name")); if (nm != null) sb.Append(" '").Append(nm).Append('\'');
                    var attrs = Get(el, "Attributes") as IEnumerable;
                    if (attrs != null)
                    {
                        int a = 0; sb.Append(" [");
                        foreach (var at in attrs) { if (a++ >= 12) { sb.Append(" ..."); break; } sb.Append(a > 1 ? "; " : "").Append(Mask(OneLine(Str(at), 120))); }
                        sb.Append(']');
                    }
                }
            if (k == 0 && steps != null)
                foreach (var st in steps)
                {
                    if (k++ >= 10) { sb.Append("; ..."); break; }
                    string eid = Str(Get(st, "ElementId") ?? Get(st, "ElementID") ?? Get(st, "mElementId"));
                    sb.Append("; step ").Append(eid ?? Mask(OneLine(Str(st), 120)));
                }
            return sb.ToString();
        }
        catch (Exception ex) { return "unreadable (" + Inner(ex).GetType().Name + ")"; }
    }
    static bool HasMethod(Type t, string name)
    {
        try { foreach (var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)) if (m.Name == name && m.GetParameters().Length == 0) return true; }
        catch (Exception) { }
        return false;
    }

    /// Session identity from the RunnerRecord (confirmed members: SessionID, SessionNo, SessionStarted, ProcessName,
    /// ProcessId, mResourceID, mUserID, mStartupParams, GetSessionVariables(), SessionExceptionDetail; BluePrismProcess.Version).
    /// Only reads. Text lines + flat fields for the json. Null runner -> one line saying so.
    static string SessionText(object runner, Dictionary<string, string> fields, string reason)
    {
        var sb = new StringBuilder();
        if (runner == null) { sb.Append("not available (").Append(reason ?? "layers off, runner not searched").Append(")\n"); return sb.ToString(); }
        try
        {
            string no = Str(Get(runner, "SessionNo")), id = Str(Get(runner, "SessionID")), started = Str(Get(runner, "SessionStarted"));
            string pn = Str(Get(runner, "ProcessName")), pid = Str(Get(runner, "ProcessId")), res = Str(Get(runner, "mResourceID")), usr = Str(Get(runner, "mUserID"));
            object proc = Get(runner, "mProcess"); string ver = Str(Get(proc, "Version"));
            sb.Append("number ").Append(no ?? "?").Append("; id ").Append(id ?? "?").Append("; started ").Append(started ?? "?").Append('\n');
            sb.Append("process ").Append(pn ?? "?").Append(ver != null ? " v" + ver : "").Append(" (").Append(pid ?? "?").Append(")").Append('\n');
            sb.Append("resource ").Append(Environment.MachineName).Append(" id ").Append(res ?? "?").Append("; user id ").Append(usr ?? "?").Append('\n');
            fields["session_no"] = no; fields["session_id"] = id; fields["session_started"] = started; fields["process_name"] = pn; fields["process_id"] = pid;
            fields["process_version"] = ver; fields["resource_id"] = res; fields["user_id"] = usr;
            var sp = Get(runner, "mStartupParams");
            if (sp is IEnumerable) { string x = ArgsXml(sp); sb.Append("startup params ").Append(x).Append('\n'); fields["startup_params"] = x; }
            var sv = Call(runner, "GetSessionVariables");
            if (sv is IEnumerable) { string x = ArgsXml(sv); sb.Append("session variables ").Append(x).Append('\n'); fields["session_variables"] = x; }
            string term = Str(Get(runner, "SessionExceptionDetail"));
            if (!string.IsNullOrEmpty(term)) { sb.Append("termination ").Append(Mask(OneLine(term, ValueMax))).Append('\n'); fields["termination"] = Mask(OneLine(term, ValueMax)); }
        }
        catch (Exception ex) { sb.Append("unreadable (").Append(Inner(ex).GetType().Name).Append(")\n"); }
        return sb.ToString();
    }

    /// A Recover stage means the exception unwound every stage below the recovering page without
    /// their Epilogues: drop those frames (Open and Chain) and mark their open log rows "unwound".
    static void Unwind(StageSession s, object recover, DateTime now)
    {
        object rp = Get(recover, "Process"); string rpg = Str(Call(recover, "GetSubSheetID"));
        int keep = -1;
        for (int i = s.Open.Count - 1; i >= 0; i--)
        {
            var f = s.Open[i];
            if (f.Kind == "Action" || !IsChainKind(f.Kind) || f.Stage == null) continue;
            if (ReferenceEquals(Get(f.Stage, "Process"), rp) && Str(Call(f.Stage, "GetSubSheetID")) == rpg) { keep = i; break; }
        }
        if (keep < 0) return;   // the recovering page is not on our stack: leave it as it is
        var gone = s.Open.GetRange(keep + 1, s.Open.Count - keep - 1);
        if (gone.Count == 0) return;
        s.Open.RemoveRange(keep + 1, gone.Count);
        s.Chain.RemoveAll(c => gone.Contains(c));
        foreach (var r in s.Ring)
            if (r.Open && r.StageRef != null)
                foreach (var g in gone)
                    if (ReferenceEquals(g.Stage, r.StageRef)) { r.Open = false; r.Unwound = true; r.End = now; r.StageRef = null; break; }
    }

    static bool IsStage(object o) { var t = o.GetType(); return BaseNamed(t, "ProcessStage") != null || (Member(t, "StageType") != null && Member(t, "Name") != null); }
    static bool IsDataStage(object o) { return BaseNamed(o.GetType(), "DataStage") != null; }
    static string Str(object o) { try { return o == null ? null : Convert.ToString(o, CultureInfo.InvariantCulture); } catch (Exception) { return null; } }

    /// ArgumentList -> <parameters><p name=".." type=".." value=".."/>...</parameters>, masked, bounded.
    static string ArgsXml(object list)
    {
        var sb = new StringBuilder("<parameters>");
        int n = 0;
        try
        {
            foreach (var a in (IEnumerable)list)
            {
                if (a == null) continue;
                if (n++ >= ArgsMax) { sb.Append("<more/>"); break; }
                string name = Str(Get(a, "Name"));
                object v = Get(a, "Value");
                string type = Str(Get(v, "DataType")) ?? "";
                string val = name == null && v == null ? Mask(OneLine(Str(a), ValueMax)) : MaskNamed(name, ValueText(v, 0));
                sb.Append("<p name=\"").Append(X(name)).Append("\" type=\"").Append(X(type)).Append("\" value=\"").Append(X(val)).Append("\"/>");
                if (sb.Length > ParamsMax) { sb.Length = ParamsMax; sb.Append("...<more/>"); break; }
            }
        }
        catch (Exception ex) { sb.Append("<unreadable reason=\"").Append(X(ex.GetType().Name)).Append("\"/>"); }
        return sb.Append("</parameters>").ToString();
    }
    static string X(string s) { return s == null ? "" : s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;"); }

    /// A ProcessValue as text. Password values are never read; collections as row count + first rows.
    static string ValueText(object pv, int depth)
    {
        if (pv == null) return "";
        try
        {
            string dt = Str(Get(pv, "DataType")) ?? "";
            if (dt.Equals("password", StringComparison.OrdinalIgnoreCase)) return "(password, not read)";
            if (dt.Equals("collection", StringComparison.OrdinalIgnoreCase)) return depth > 0 ? "(collection)" : CollectionText(Get(pv, "Collection"));
            string v = Str(Get(pv, "FormattedValue"));
            if (v == null) v = Str(pv);
            return Mask(OneLine(v, ValueMax));
        }
        catch (Exception ex) { return "(unreadable: " + ex.GetType().Name + ")"; }
    }
    static string CollectionText(object coll)
    {
        if (coll == null) return "(no collection)";
        var sb = new StringBuilder();
        sb.Append("rows=").Append(Str(Get(coll, "Count")) ?? "?");
        var rows = Get(coll, "Rows") as IEnumerable;
        if (rows == null) return sb.ToString();
        int r = 0;
        foreach (var row in rows)
        {
            if (r++ >= CollRows) { sb.Append(" ..."); break; }
            sb.Append(" [");
            var d = row as IDictionary; bool first = true;
            if (d != null) foreach (DictionaryEntry e in d) { sb.Append(first ? "" : "; ").Append(Str(e.Key)).Append('=').Append(MaskNamed(Str(e.Key), ValueText(e.Value, 1))); first = false; }
            else sb.Append(Mask(OneLine(Str(row), ValueMax)));
            sb.Append(']');
            if (sb.Length > ParamsMax) { sb.Append(" ..."); break; }
        }
        return sb.ToString();
    }

    // ---- masking: credentials, IBAN, CNP, card PAN ----
    static readonly Regex RxCred = new Regex(@"(?i)((?:[/\-]{1,2})?(?:password|passwd|pass|pwd|secret|token)\b[\s=:]+)(""[^""]*""|\S+)");
    static readonly Regex RxUser = new Regex(@"(?i)(/user\s+\S+\s+)(\S+)");
    static readonly Regex RxIban = new Regex(@"\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]){11,30}\b");
    static readonly Regex RxDigits = new Regex(@"(?<![\d])(?:\d[ \-]?){12,18}\d(?![\d])");
    static readonly Regex RxSecretName = new Regex(@"(?i)pass|pwd|secret|token|\bpin\b");

    /// Masks credentials (/password-style, and the password after "/user name"), IBANs, valid CNPs and Luhn-valid PANs.
    public static string Mask(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;
        try
        {
            s = RxCred.Replace(s, "$1***");
            s = RxUser.Replace(s, "$1***");
            s = RxIban.Replace(s, m => m.Value.Substring(0, 4) + "****");
            s = RxDigits.Replace(s, m =>
            {
                var d = new StringBuilder(); foreach (var c in m.Value) if (c >= '0' && c <= '9') d.Append(c);
                var ds = d.ToString();
                if (ds.Length < 13 || ds.Length > 19) return m.Value;
                if (ds.Length == 13 && IsCnp(ds)) return "[CNP masked]";
                if (Luhn(ds)) return "[PAN ****" + ds.Substring(ds.Length - 4) + "]";
                return m.Value;
            });
            return s;
        }
        catch (Exception) { return "(mask failed)"; }
    }
    static string MaskNamed(string name, string value) { return name != null && RxSecretName.IsMatch(name) ? "***" : value; }
    static bool IsCnp(string d)
    {
        if (d.Length != 13 || d[0] == '0') return false;
        int mm = (d[3] - '0') * 10 + (d[4] - '0'), dd = (d[5] - '0') * 10 + (d[6] - '0');
        if (mm < 1 || mm > 12 || dd < 1 || dd > 31) return false;
        const string w = "279146358279"; int sum = 0;
        for (int i = 0; i < 12; i++) sum += (d[i] - '0') * (w[i] - '0');
        int c = sum % 11; if (c == 10) c = 1;
        return c == d[12] - '0';
    }
    static bool Luhn(string d)
    {
        int sum = 0; bool dbl = false;
        for (int i = d.Length - 1; i >= 0; i--) { int x = d[i] - '0'; if (dbl) { x *= 2; if (x > 9) x -= 9; } sum += x; dbl = !dbl; }
        return sum % 10 == 0;
    }

    // ---- reflection helpers (cached, never throw) ----
    static readonly Dictionary<Type, Dictionary<string, MemberInfo>> MemberCache = new Dictionary<Type, Dictionary<string, MemberInfo>>();
    static MemberInfo Member(Type t, string name)
    {
        Dictionary<string, MemberInfo> byName; MemberInfo mi;
        lock (MemberCache)
        {
            if (!MemberCache.TryGetValue(t, out byName)) { byName = new Dictionary<string, MemberInfo>(); MemberCache[t] = byName; }
            if (byName.TryGetValue(name, out mi)) return mi;
        }
        try
        {
            for (var x = t; x != null && mi == null; x = x.BaseType)
            {
                foreach (var p in x.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    if (p.Name == name && p.CanRead && p.GetIndexParameters().Length == 0) { mi = p; break; }
                if (mi == null) mi = x.GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly);
            }
        }
        catch (Exception) { mi = null; }
        lock (MemberCache) byName[name] = mi;
        return mi;
    }
    static object Get(object o, string name)
    {
        if (o == null) return null;
        var mi = Member(o.GetType(), name);
        if (mi == null) return null;
        try { var p = mi as PropertyInfo; return p != null ? p.GetValue(o, null) : ((FieldInfo)mi).GetValue(o); }
        catch (Exception) { return null; }
    }
    static object Call(object o, string name, params object[] args)
    {
        if (o == null) return null;
        try
        {
            foreach (var m in o.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
            {
                if (m.Name != name || m.IsGenericMethodDefinition) continue;
                var ps = m.GetParameters();
                if (ps.Length != args.Length) continue;
                bool ok = true;
                for (int i = 0; i < ps.Length && ok; i++) ok = args[i] == null ? !ps[i].ParameterType.IsValueType : ps[i].ParameterType.IsInstanceOfType(args[i]);
                if (ok) return m.Invoke(o, args);
            }
        }
        catch (Exception) { }
        return null;
    }

    // ---- at Dump time ----
    static void SnapshotLayers(out List<StageRec> log, out long dropped, out List<ChainFrame> chain, out string slStatus, out string dcStatus,
                               out List<PathRec> path, out object runner, out string runnerReason)
    {
        log = new List<StageRec>(); chain = new List<ChainFrame>(); path = new List<PathRec>(); dropped = 0; _lastHidden = 0; runner = null; runnerReason = null;
        lock (Gate)
        {
            slStatus = StageLogStatusLocked(); dcStatus = DataChainStatusLocked();
            var s = StageMine(false);
            if (s == null) return;
            runner = s.Runner; runnerReason = s.Reason;
            if (_stageLogOn || _dataChainOn) path.AddRange(s.Path);
            if (_stageLogOn)
                foreach (var r in s.Ring)
                    log.Add(new StageRec { Seq = r.Seq, Start = r.Start, End = r.End, Open = r.Open, Unwound = r.Unwound, Method = r.Method, StageName = r.StageName, StageType = r.StageType, Page = r.Page,
                                           Process = r.Process, ObjectName = r.ObjectName, ActionName = r.ActionName, Result = r.Result, InXml = r.InXml, OutXml = r.OutXml,
                                           MemAutomate = r.MemAutomate, MemTarget = r.MemTarget });
            dropped = s.Dropped; _lastHidden = s.Hidden;
            if (_dataChainOn)
            {
                chain.AddRange(s.Chain);
                if (s.Open.Count > 0)
                {
                    var cur = s.Open[s.Open.Count - 1];
                    // the deepest open application stage (Navigate/Read/Write/Wait): the one that was looking for an element
                    // when the failure happened, even if an Exception stage has run since
                    ChainFrame app = null;
                    for (int i = s.Open.Count - 1; i >= 0 && app == null; i--) if (IsAppKind(s.Open[i].Kind)) app = s.Open[i];
                    if (app != null && !ReferenceEquals(app, cur) && !chain.Contains(app)) chain.Add(app);
                    if (!chain.Contains(cur)) chain.Add(cur);
                }
            }
        }
    }

    /// For each frame, outermost first: the data/collection stages of that frame's page with their current values.
    /// Bounded: 1 s and 200 items in total; a page already captured is not read twice.
    static List<ChainCapture> CaptureChain(List<ChainFrame> chain)
    {
        var res = new List<ChainCapture>();
        if (chain == null || chain.Count == 0) return res;
        var sw = Stopwatch.StartNew(); int items = 0;
        var pagesDone = new List<KeyValuePair<object, string>>();
        foreach (var f in chain)
        {
            var cc = new ChainCapture { Kind = f.Kind, Stage = f.Name };
            res.Add(cc);
            try
            {
                object proc = Get(f.Stage, "Process");
                cc.Process = Str(Get(proc, "Name")); cc.Page = Str(Get(Get(f.Stage, "SubSheet"), "Name"));
                if (IsHidden(cc.Process)) { res.Remove(cc); continue; }
                cc.Elements = ElementsText(f.Stage, proc);
                object pageId = Call(f.Stage, "GetSubSheetID");
                bool firstOfProc = true; foreach (var kv in pagesDone) if (ReferenceEquals(kv.Key, proc)) firstOfProc = false;
                if (firstOfProc) cc.Recovery = RecoveryText(proc);
                string pk = Str(pageId);
                bool dup = false; foreach (var kv in pagesDone) if (ReferenceEquals(kv.Key, proc) && kv.Value == pk) dup = true;
                if (dup) { cc.Note = "same page as above"; continue; }
                pagesDone.Add(new KeyValuePair<object, string>(proc, pk));
                var stages = (pageId == null ? null : Call(proc, "GetStages", pageId)) as IEnumerable;
                if (stages == null) { cc.Note = "page stages not readable"; continue; }
                foreach (var st in stages)
                {
                    if (st == null || !IsDataStage(st)) continue;
                    if (items >= CaptureItems || sw.ElapsedMilliseconds > CaptureMs) { cc.Note = "truncated (" + CaptureItems + " items / 1 s budget)"; break; }
                    string nm = Str(Get(st, "Name")) ?? "?";
                    string v = BaseNamed(st.GetType(), "CollectionStage") != null ? CollectionText(Get(st, "CurrentCollection")) : ValueText(Get(st, "Value"), 0);
                    cc.Items.Add(new KeyValuePair<string, string>(nm, MaskNamed(nm, v)));
                    items++;
                }
            }
            catch (Exception ex) { cc.Note = "unreadable (" + Inner(ex).GetType().Name + ")"; }
        }
        return res;
    }

    const double SlowSeconds = 5;
    static string Dur(StageRec r)
    {
        if (r.Open) return "";
        double sec = (r.End - r.Start).TotalSeconds; if (sec < 0) sec = 0;
        return " " + sec.ToString("0.000", CultureInfo.InvariantCulture) + " s" + (sec > SlowSeconds ? " SLOW" : "");
    }
    static void AppendLayersText(StringBuilder txt, List<StageRec> log, long dropped, List<ChainCapture> chain, string slStatus, string dcStatus, List<PathRec> path, string sessionText)
    {
        txt.Append("\n--- session ---\n").Append(sessionText);
        txt.Append("\n--- exception path (oldest first: thrown -> exception stages -> caught -> resumed) ---\n");
        if (path.Count == 0) txt.Append("(none)\n");
        foreach (var e in path)
            txt.Append(e.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append(" | ").Append(e.Method).Append(" | ").Append(e.Process).Append(" / ").Append(e.Page).Append(" / ").Append(e.Stage)
               .Append(" | ").Append(e.Detail).Append('\n');
        txt.Append("\n--- stage log (last ").Append(log.Count).Append(" stages, oldest first; duration per stage, SLOW over ").Append(SlowSeconds).Append(" s; mem = Automate / target app working set) ---\n");
        txt.Append("status: ").Append(slStatus).Append("; dropped ").Append(dropped).Append("; hidden (Radar's own stages) ").Append(_lastHidden).Append('\n');
        foreach (var r in log)
        {
            txt.Append(r.Start.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append(r.Open ? " -> (open)" : " -> " + r.End.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + (r.Unwound ? " (unwound)" : "") + Dur(r))
               .Append(" | #").Append(r.Seq).Append(" | ").Append(r.Process).Append(" | ").Append(r.Page).Append(" | ").Append(r.StageName)
               .Append(" (").Append(r.StageType).Append(") | ").Append(r.Method);
            if (r.ObjectName != null) txt.Append(" | ").Append(r.ObjectName).Append('.').Append(r.ActionName);
            if (r.Result != null) txt.Append(" | result: ").Append(OneLine(r.Result, 400));
            if (r.InXml != null) txt.Append(" | in: ").Append(r.InXml);
            if (r.OutXml != null) txt.Append(" | out: ").Append(r.OutXml);
            if (r.MemAutomate != null || r.MemTarget != null) txt.Append(" | mem ").Append(r.MemAutomate ?? "?").Append(" / ").Append(r.MemTarget ?? "?");
            txt.Append('\n');
        }
        txt.Append("\n--- data chain at failure ---\n");
        txt.Append("status: ").Append(dcStatus).Append('\n');
        foreach (var c in chain)
        {
            txt.Append(c.Process).Append(" / ").Append(c.Page).Append(" / ").Append(c.Stage).Append(" (").Append(c.Kind).Append(')');
            if (c.Note != null) txt.Append("  [").Append(c.Note).Append(']');
            txt.Append('\n');
            if (c.Recovery != null) txt.Append("    [recovery] ").Append(c.Recovery).Append('\n');
            if (c.Elements != null) txt.Append("    [elements] ").Append(c.Elements).Append('\n');
            foreach (var kv in c.Items) txt.Append("    ").Append(kv.Key).Append('=').Append(kv.Value).Append('\n');
        }
    }

    static void AppendLayersJson(StringBuilder js, List<StageRec> log, long dropped, List<ChainCapture> chain, List<PathRec> path, Dictionary<string, string> session)
    {
        js.Append("  \"session\": {");
        { bool first = true; foreach (var kv in session) { if (kv.Value == null) continue; js.Append(first ? " " : ", ").Append(J(kv.Key)).Append(": ").Append(J(kv.Value)); first = false; } js.Append(first ? "},\n" : " },\n"); }
        js.Append("  \"exception_path\": [");
        for (int i = 0; i < path.Count; i++)
        {
            var e = path[i];
            js.Append(i == 0 ? "\n" : ",\n").Append("    { \"at\": ").Append(J(e.At.ToString("o"))).Append(", \"method\": ").Append(J(e.Method)).Append(", \"process\": ").Append(J(e.Process))
              .Append(", \"page\": ").Append(J(e.Page)).Append(", \"stage\": ").Append(J(e.Stage)).Append(", \"detail\": ").Append(J(e.Detail)).Append(" }");
        }
        js.Append(path.Count > 0 ? "\n  ],\n" : "],\n");
        js.Append("  \"stage_log_dropped\": ").Append(dropped).Append(",\n");
        js.Append("  \"stage_log\": [");
        for (int i = 0; i < log.Count; i++)
        {
            var r = log[i];
            js.Append(i == 0 ? "\n" : ",\n").Append("    { \"seq\": ").Append(r.Seq).Append(", \"start\": ").Append(J(r.Start.ToString("o")))
              .Append(", \"end\": ").Append(r.Open ? "null" : J(r.End.ToString("o"))).Append(", \"unwound\": ").Append(r.Unwound ? "true" : "false").Append(", \"process\": ").Append(J(r.Process))
              .Append(", \"page\": ").Append(J(r.Page)).Append(", \"stage\": ").Append(J(r.StageName)).Append(", \"stage_type\": ").Append(J(r.StageType))
              .Append(", \"method\": ").Append(J(r.Method)).Append(", \"object\": ").Append(J(r.ObjectName)).Append(", \"action\": ").Append(J(r.ActionName))
              .Append(", \"result\": ").Append(J(r.Result)).Append(", \"attribute_xml\": ").Append(J((r.InXml ?? "") + (r.OutXml ?? "")))
              .Append(", \"ms\": ").Append(r.Open ? "null" : ((long)(r.End - r.Start).TotalMilliseconds).ToString(CultureInfo.InvariantCulture))
              .Append(", \"mem_automate\": ").Append(J(r.MemAutomate)).Append(", \"mem_target\": ").Append(J(r.MemTarget)).Append(" }");
        }
        js.Append(log.Count > 0 ? "\n  ],\n" : "],\n");
        js.Append("  \"data_chain\": [");
        for (int i = 0; i < chain.Count; i++)
        {
            var c = chain[i];
            js.Append(i == 0 ? "\n" : ",\n").Append("    { \"process\": ").Append(J(c.Process)).Append(", \"page\": ").Append(J(c.Page))
              .Append(", \"stage\": ").Append(J(c.Stage)).Append(", \"kind\": ").Append(J(c.Kind)).Append(", \"note\": ").Append(J(c.Note))
              .Append(", \"recovery\": ").Append(J(c.Recovery)).Append(", \"elements\": ").Append(J(c.Elements)).Append(", \"items\": {");
            for (int k = 0; k < c.Items.Count; k++) js.Append(k == 0 ? " " : ", ").Append(J(c.Items[k].Key)).Append(": ").Append(J(c.Items[k].Value));
            js.Append(c.Items.Count > 0 ? " } }" : "} }");
        }
        js.Append(chain.Count > 0 ? "\n  ]\n" : "]\n");
    }
}
