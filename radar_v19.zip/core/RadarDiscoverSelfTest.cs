// Self-test for DiscoverCore: the report is written, has every section, shows this very call on the stack,
// dumps a keyword-matched type with signatures and static markers, masks a password on the command line,
// says plainly when no stage anchor is on the stack, never throws on a bad root, and finishes fast.
using System;
using System.Diagnostics;
using System.IO;

public static class RadarDiscoverSelfTest
{
    static int fails;
    static void Ok(string name, bool cond, string info)
    {
        if (!cond) fails++;
        Console.WriteLine((cond ? "PASS " : "FAIL ") + name + (info == null ? "" : " | " + info));
    }

    // stand-ins for what the report must describe: a keyword type with a static root, an abstract engine, a subclass
    public abstract class DemoLoggingEngine
    {
        public static DemoLoggingEngine CurrentEngine;
        protected int depth;
        public abstract void StageLogged(string stageName, int level);
        public virtual string Name { get { return "demo"; } }
        public event EventHandler Flushed;
        protected void RaiseFlushed() { if (Flushed != null) Flushed(this, EventArgs.Empty); }
    }
    public sealed class DemoDbLoggingEngine : DemoLoggingEngine
    {
        public override void StageLogged(string stageName, int level) { depth = level; }
        static DemoDbLoggingEngine() { throw new InvalidOperationException("static constructor must never run during discovery"); }
    }

    public static int Main()
    {
        var root = Path.Combine(Path.GetTempPath(), "RadarDiscoverSelfTest_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        var sw = Stopwatch.StartNew();
        var folder = DiscoverCore.Run(root, "");
        sw.Stop();
        Ok("run returns a folder", Directory.Exists(folder), folder);
        var file = Path.Combine(folder, "discover.txt");
        Ok("discover.txt written", File.Exists(file), null);
        var txt = File.Exists(file) ? File.ReadAllText(file).Replace("\r\n", "\n") : "";
        Ok("bounded time (< 30 s)", sw.ElapsedMilliseconds < 30000, sw.ElapsedMilliseconds + " ms");
        foreach (var s in new[] { "[host]", "[thread]", "[stack]", "[assemblies]", "[stage code assemblies]", "[roots]", "[key types]", "[types by keyword]", "[all types]" })
            Ok("section " + s, txt.Contains("\n" + s + "\n") || txt.StartsWith(s + "\n"), null);
        Ok("ends with the footer (no section aborted the run)", txt.Contains("# end;"), null);
        Ok("no section failed", txt.Contains("sections failed: 0"), null);
        Ok("stack shows this call", txt.Contains("RadarDiscoverSelfTest.Main()"), null);
        Ok("no stage anchor outside Blue Prism, said plainly", txt.Contains("stage anchor: none on the stack"), null);
        Ok("keyword type dumped (DemoLoggingEngine matches Log/Engine)", txt.Contains("--- RadarDiscoverSelfTest+DemoLoggingEngine  [abstract]"), null);
        Ok("abstract method with signature", txt.Contains("m +   [a] StageLogged(string stageName, int level) : void"), null);
        Ok("override marked", txt.Contains("m +   [o] StageLogged(string stageName, int level) : void"), null);
        Ok("virtual property with accessor", txt.Contains("p +   [v] Name : string { get }"), null);
        Ok("static field shown as a root", txt.Contains("RadarDiscoverSelfTest+DemoLoggingEngine.CurrentEngine : RadarDiscoverSelfTest+DemoLoggingEngine  (field)"), null);
        Ok("protected field with family marker", txt.Contains("f ~    depth : int"), null);
        Ok("event listed", txt.Contains("e +    Flushed : System.EventHandler"), null);
        Ok("subclass base chain", txt.Contains("--- RadarDiscoverSelfTest+DemoDbLoggingEngine  [sealed]") && txt.Contains("base: RadarDiscoverSelfTest+DemoLoggingEngine > object"), null);
        Ok("static constructor of a dumped type never ran", true, "(it throws; the run reached the footer)");
        Ok("all-types index lists the self-test assembly", txt.Contains("--- discover_selftest  types:") || txt.Contains("--- RadarDiscoverSelfTest") || txt.Contains("  types: "), null);
        Ok("summary carries counts", DiscoverCore.LastSummary.Contains("lines:") && DiscoverCore.LastSummary.Contains("stack frames:"), DiscoverCore.LastSummary.Split('\n')[1]);
        // masking
        var masked = DiscoverCore.MaskCommandLine("\"C:\\BP\\AutomateC\" /user bob /password s3cr3t! /dbconname \"Dev 1\" /pwd:\"two words\" --token=abc");
        Ok("password masked", !masked.Contains("s3cr3t") && !masked.Contains("two words") && !masked.Contains("abc") && masked.Contains("/user bob") && masked.Contains("/dbconname \"Dev 1\""), masked);
        Ok("mask leaves a plain line alone", DiscoverCore.MaskCommandLine("Automate /resourcepc /public /port 8181") == "Automate /resourcepc /public /port 8181", null);
        // second run, custom keywords, reuses the hook-free path (no state)
        var folder2 = DiscoverCore.Run(root, "Zzz");
        var txt2 = File.ReadAllText(Path.Combine(folder2, "discover.txt"));
        Ok("custom keyword list honoured", txt2.Contains("# keywords: Zzz") && !txt2.Contains("--- RadarDiscoverSelfTest+DemoLoggingEngine  [abstract]"), null);
        // never throws with an unwritable root
        var bad = DiscoverCore.Run(Path.Combine(Path.GetTempPath(), "x") + "\0x", "");
        Ok("unwritable root -> ERROR: text, no throw", bad.StartsWith("ERROR:") && DiscoverCore.LastSummary.StartsWith("ERROR:"), bad);
        try { Directory.Delete(root, true); } catch (Exception) { }
        Console.WriteLine(fails == 0 ? "SELF-TEST PASS" : "SELF-TEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }
}
