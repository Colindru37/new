// Radar Discover: one text report of what the .NET runtime exposes to a Blue Prism code stage. Metadata only.
//   Run(root, keywords)   writes <root>\<machine>\discover_<stamp>\discover.txt and returns that folder
//   LastSummary           a few lines of counts for the caller's output
// Rules the report is written under (so it has zero effect on the running session):
//   - reflection metadata only: Type / MemberInfo / Assembly descriptors. No method is invoked, no property getter
//     is called, no field value is read (static or instance), so no static constructor is triggered either.
//   - only assemblies ALREADY loaded in the AppDomain are inspected (GetAssemblies); nothing is Assembly.Load-ed.
//     Enumerating a loaded assembly's types may make the CLR load the metadata of assemblies it references;
//     that is the one side effect and it is harmless.
//   - the command line is masked (any /password-style token), nothing else in the report is session data:
//     type and method names only (the generated object class names the object, Run_<Stage> names the stage).
// Sections, in reading order (photograph A first, copy B..D when needed):
//   A  [host] [thread] [stack] [assemblies] [stage code assemblies] [roots]      the small decisive part
//   B  [key types]       full member dump of the handful of classes the two capture layers will be written against
//   C  [types by keyword] full member dump of every type whose name matches a keyword (Log, Session, Process, ...)
//   D  [all types]       index of every type in the Blue Prism assemblies: name : base (member count)
// Never throws. BCL only, C# 5 (Blue Prism code stages / PowerShell Add-Type).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

public static class DiscoverCore
{
    public const string DefaultKeywords = "Log,Session,Process,Stage,Runner,Engine,Debug,Value,Collection,Resource,Listener,Runtime";
    static readonly string[] KeyTypeNames = {
        "clsProcess", "clsProcessStage", "clsSession", "clsProcessSession", "clsRunningProcess", "clsSubSheet",
        "clsLoggingEngine", "clsCompoundLoggingEngine", "clsDBLoggingEngine", "clsSessionLog", "clsSessionLogEntry",
        "clsProcessValue", "clsCollection", "clsCollectionRow", "clsDataStage", "clsCollectionStage",
        "CodeStage", "ActionStage", "SubSheetRefStage", "clsCodeStage", "clsActionStage", "clsSubSheetRefStage" };

    const int MaxLinesA = 1500, MaxLinesB = 12000, MaxLinesC = 60000, MaxLinesD = 15000, MaxMembersPerType = 600;

    static string _lastSummary = "";
    public static string LastSummary { get { return _lastSummary; } }

    public static string Run(string root, string keywords)
    {
        var sw = Stopwatch.StartNew();
        string folder = null;
        var rep = new Report();
        try
        {
            if (string.IsNullOrEmpty(root)) root = Path.Combine(Path.GetTempPath(), "Radar");
            folder = Path.Combine(Path.Combine(root, Environment.MachineName),
                                  "discover_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(folder);
            if (string.IsNullOrEmpty(keywords) || keywords.Trim().Length == 0) keywords = DefaultKeywords;
            var keys = new List<string>();
            foreach (var k in keywords.Split(',', ';', ' ')) if (k.Trim().Length > 0) keys.Add(k.Trim());

            rep.Line("# Radar discovery " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            rep.Line("# reflection metadata only: no method invoked, no property read, no field read, no static constructor run,");
            rep.Line("# no assembly loaded on purpose. Member markers: + public  ~ assembly/family  - private;  [s] static  [a] abstract  [v] virtual  [o] override");
            rep.Line("# keywords: " + string.Join(",", keys.ToArray()));
            rep.Line("");

            var ctx = new Context();
            ctx.Keys = keys;
            Section(rep, "host", delegate { Host(rep); });
            Section(rep, "thread", delegate { ThreadInfo(rep); });
            Section(rep, "stack", delegate { Stack(rep, ctx); });
            Section(rep, "assemblies", delegate { Assemblies(rep, ctx); });
            Section(rep, "stage code assemblies", delegate { DynamicAssemblies(rep, ctx); });
            Section(rep, "roots", delegate { Roots(rep, ctx); });
            rep.Cap = MaxLinesA + MaxLinesB;
            Section(rep, "key types", delegate { KeyTypes(rep, ctx); });
            rep.Cap += MaxLinesC;
            Section(rep, "types by keyword", delegate { KeywordTypes(rep, ctx); });
            rep.Cap += MaxLinesD;
            Section(rep, "all types", delegate { AllTypes(rep, ctx); });
            rep.Line("");
            rep.Line("# end; " + rep.Lines + " lines, " + sw.ElapsedMilliseconds + " ms, sections failed: " + rep.Failed);
            File.WriteAllText(Path.Combine(folder, "discover.txt"), rep.Text(), new UTF8Encoding(false));
            _lastSummary = "folder: " + folder + "\nlines: " + rep.Lines + "  ms: " + sw.ElapsedMilliseconds
                + "\nblue prism assemblies: " + ctx.BpAssemblies.Count + "  types indexed: " + ctx.TypesIndexed
                + "  types dumped: " + ctx.Dumped.Count + "\nstack frames: " + ctx.StackFrames
                + "  code stage frame: " + (ctx.CodeStageType == null ? "none" : ctx.CodeStageType.FullName)
                + "\nstage anchor: " + (ctx.StageRoot == null ? "none" : ctx.StageRoot.FullName)
                + "\nsections failed: " + rep.Failed;
            return folder;
        }
        catch (Exception ex)
        {
            try { if (folder != null) File.WriteAllText(Path.Combine(folder, "discover.txt"), rep.Text() + "\n# ABORTED: " + ex.GetType().Name + ": " + ex.Message + "\n", new UTF8Encoding(false)); } catch (Exception) { }
            _lastSummary = "ERROR: " + ex.GetType().Name + ": " + ex.Message;
            return "ERROR: " + ex.GetType().Name + ": " + ex.Message;
        }
    }

    // ------------------------------------------------------------------ plumbing
    sealed class Report
    {
        readonly StringBuilder _sb = new StringBuilder();
        public int Lines, Failed, Cap = MaxLinesA;
        bool _capped;
        public void Line(string s)
        {
            if (Lines >= Cap) { if (!_capped) { _sb.Append("    ... (section cap reached)\n"); _capped = true; } return; }
            _sb.Append(s).Append('\n'); Lines++;
        }
        public void Reset() { _capped = false; }
        public string Text() { return _sb.ToString(); }
    }
    sealed class Context
    {
        /// the assemblies the type sections scan: the Blue Prism / estate ones AND the in-memory ones (compiled code stages)
        public List<Assembly> Scan { get { var l = new List<Assembly>(BpAssemblies); l.AddRange(DynAssemblies); return l; } }
        public List<string> Keys;
        public readonly List<Assembly> BpAssemblies = new List<Assembly>();
        public readonly List<Assembly> DynAssemblies = new List<Assembly>();
        public readonly List<Type> StackTypes = new List<Type>();
        public readonly HashSet<Type> Dumped = new HashSet<Type>();
        public Type CodeStageType, StageRoot;
        public int StackFrames, TypesIndexed;
    }
    static void Section(Report rep, string name, Action body)
    {
        rep.Reset();
        rep.Line("[" + name + "]");
        try { body(); }
        catch (Exception ex) { rep.Failed++; rep.Line("    (section failed: " + ex.GetType().Name + ": " + OneLine(ex.Message, 200) + ")"); }
        rep.Line("");
    }

    // ------------------------------------------------------------------ A
    static void Host(Report rep)
    {
        var p = Process.GetCurrentProcess();
        rep.Line("machine: " + Environment.MachineName + "  user: " + Environment.UserDomainName + "\\" + Environment.UserName + "  pid: " + p.Id);
        rep.Line("clr: " + Environment.Version + "  64bit: " + Environment.Is64BitProcess + "  os: " + Environment.OSVersion + "  interactive: " + Environment.UserInteractive);
        string host = "?"; try { host = p.MainModule.FileName; } catch (Exception e) { host = "(" + e.GetType().Name + ")"; }
        rep.Line("host: " + host);
        rep.Line("command line: " + MaskCommandLine(Environment.CommandLine));
        rep.Line("appdomain: " + AppDomain.CurrentDomain.FriendlyName + "  base: " + AppDomain.CurrentDomain.BaseDirectory);
        rep.Line("process started: " + p.StartTime.ToString("yyyy-MM-dd HH:mm:ss") + "  threads (os): " + p.Threads.Count);
    }

    /// Mask the value after any password-like switch so the report never carries a credential.
    public static string MaskCommandLine(string cmd)
    {
        if (string.IsNullOrEmpty(cmd)) return "";
        try
        {
            cmd = Regex.Replace(cmd, @"(?i)((?:[/\-]{1,2})?(?:password|passwd|pass|pwd|secret|token)\b[\s=:]+)(""[^""]*""|\S+)", "$1***");
            return Regex.Replace(cmd, @"(?i)(/user\s+\S+\s+)(""[^""]*""|\S+)", "$1***");   // Resource PC form: /user <name> <password>
        }
        catch (Exception) { return "(mask failed)"; }
    }

    static void ThreadInfo(Report rep)
    {
        var t = Thread.CurrentThread;
        rep.Line("managed id: " + t.ManagedThreadId + "  name: " + (t.Name ?? "(none)") + "  pool: " + t.IsThreadPoolThread
                 + "  background: " + t.IsBackground + "  apartment: " + t.GetApartmentState() + "  priority: " + t.Priority);
        rep.Line("(one session = one runner thread is the Radar assumption; compare this id across two actions of one session)");
    }

    static void Stack(Report rep, Context ctx)
    {
        var st = new StackTrace(1, false);
        ctx.StackFrames = st.FrameCount;
        rep.Line("frames: " + st.FrameCount + "  (innermost first; every frame kept, System.* included)");
        int shown = 0;
        for (int i = 0; i < st.FrameCount; i++)
        {
            var m = st.GetFrame(i).GetMethod();
            if (m == null) { rep.Line("  " + (shown++).ToString().PadLeft(3) + "  ?"); continue; }
            var t = m.DeclaringType;
            if (IsSelf(t)) continue;
            string tag = "";
            if (ctx.CodeStageType == null && m.Name.StartsWith("Run_")) { ctx.CodeStageType = t; tag = "   << code stage method"; }
            if (t != null && IsStageType(t) && ctx.StageRoot == null) tag += "   << stage class";
            rep.Line("  " + (shown++).ToString().PadLeft(3) + "  " + AsmShort(t) + "!" + Sig(m) + tag);
            if (t != null && !IsSystem(t) && !ctx.StackTypes.Contains(t)) ctx.StackTypes.Add(t);
        }
        // the stage root: walk up from the first BluePrism stage class on the stack
        foreach (var t in ctx.StackTypes)
            if (IsStageType(t)) { ctx.StageRoot = RootInSameAssemblyFamily(t); break; }
        if (ctx.StageRoot == null)
        {
            foreach (var t in ctx.StackTypes)
            {
                var r = RootInSameAssemblyFamily(t);
                if (r != t && (r.Name.IndexOf("Stage", StringComparison.OrdinalIgnoreCase) >= 0)) { ctx.StageRoot = r; break; }
            }
        }
        rep.Line("stage anchor: " + (ctx.StageRoot == null ? "none on the stack (expected outside Blue Prism)" : TypeName(ctx.StageRoot) + "  from " + AsmShort(ctx.StageRoot)));
        if (ctx.CodeStageType != null)
        {
            rep.Line("code stage class: " + TypeName(ctx.CodeStageType) + "  base chain: " + BaseChain(ctx.CodeStageType) + "  assembly: " + AsmShort(ctx.CodeStageType)
                     + (IsDynamic(ctx.CodeStageType.Assembly) ? " (in-memory)" : ""));
        }
    }
    static bool IsSelf(Type t)
    {
        while (t != null) { if (t == typeof(DiscoverCore)) return true; t = t.DeclaringType; }
        return false;
    }
    static bool IsStageType(Type t)
    {
        string n = t.FullName ?? t.Name;
        return n.IndexOf(".Stages.", StringComparison.Ordinal) >= 0 || (n.StartsWith("BluePrism") && n.EndsWith("Stage"));
    }
    static Type RootInSameAssemblyFamily(Type t)
    {
        var cur = t;
        while (SafeBase(cur) != null && !IsSystem(SafeBase(cur)) && SafeBase(cur) != typeof(object)) cur = SafeBase(cur);
        return cur;
    }

    static void Assemblies(Report rep, Context ctx)
    {
        var all = AppDomain.CurrentDomain.GetAssemblies();
        var others = new List<string>();
        foreach (var a in all)
        {
            string name = SafeName(a);
            if (IsDynamic(a)) { ctx.DynAssemblies.Add(a); continue; }
            if (IsSystemAsm(name)) { others.Add(name); continue; }
            ctx.BpAssemblies.Add(a);
        }
        rep.Line("loaded: " + all.Length + "  blue prism / estate: " + ctx.BpAssemblies.Count + "  in-memory: " + ctx.DynAssemblies.Count + "  framework/system: " + others.Count);
        ctx.BpAssemblies.Sort(delegate(Assembly x, Assembly y) { return string.CompareOrdinal(SafeName(x), SafeName(y)); });
        foreach (var a in ctx.BpAssemblies)
        {
            string loc = "?"; try { loc = a.Location; } catch (Exception) { loc = "(no location)"; }
            string ver = "?"; try { ver = a.GetName().Version.ToString(); } catch (Exception) { }
            rep.Line("  " + SafeName(a) + "  " + ver + "  " + loc);
        }
        others.Sort(StringComparer.Ordinal);
        rep.Line("  framework/system: " + string.Join(", ", others.ToArray()));
    }
    static void DynamicAssemblies(Report rep, Context ctx)
    {
        rep.Line("in-memory assemblies (compiled code stages live here): " + ctx.DynAssemblies.Count);
        foreach (var a in ctx.DynAssemblies)
        {
            var types = SafeTypes(a);
            rep.Line("  " + SafeName(a) + "  types: " + types.Count);
            int n = 0;
            foreach (var t in types) { if (n++ >= 40) { rep.Line("      ..."); break; } rep.Line("      " + TypeName(t) + " : " + BaseChain(t)); }
        }
    }

    static void Roots(Report rep, Context ctx)
    {
        rep.Line("static fields and properties in the blue prism assemblies whose type is itself a blue prism type (or a collection of one):");
        rep.Line("these are the handles a later layer could reach without an instance; none is read here");
        int n = 0;
        foreach (var a in ctx.Scan)
        {
            foreach (var t in SafeTypes(a))
            {
                MemberInfo[] members;
                try { members = t.GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.DeclaredOnly); }
                catch (Exception) { continue; }
                foreach (var m in members)
                {
                    try {
                    Type mt = null;
                    var f = m as FieldInfo; var p = m as PropertyInfo;
                    if (f != null) mt = f.FieldType; else if (p != null) mt = p.PropertyType; else continue;
                    if (IsCompilerGenerated(t) || IsCompilerGenerated(m) || (!MentionsBp(mt, 0) && !RootishName(m.Name))) continue;
                    if (n++ >= 600) { rep.Line("    ... (root cap reached)"); return; }
                    rep.Line("  " + Vis(m) + " " + TypeName(t) + "." + m.Name + " : " + TypeName(mt) + (f != null ? "  (field" + (f.IsInitOnly ? ", readonly" : "") + ")" : "  (property)"));
                    } catch (Exception) { }
                }
            }
        }
        rep.Line("  roots found: " + n);
    }
    static bool IsCompilerGenerated(MemberInfo m)
    {
        string n = m.Name ?? "";
        return n.IndexOf('<') >= 0 || n.IndexOf('$') >= 0;
    }
    static bool RootishName(string n)
    {
        return n.IndexOf("Instance", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Current", StringComparison.OrdinalIgnoreCase) >= 0
            || n.IndexOf("Singleton", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Running", StringComparison.OrdinalIgnoreCase) >= 0
            || n.IndexOf("Sessions", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Processes", StringComparison.OrdinalIgnoreCase) >= 0;
    }
    static bool MentionsBp(Type t, int depth)
    {
        if (t == null || depth > 3) return false;
        try
        {
            if (t.IsArray) return MentionsBp(t.GetElementType(), depth + 1);
            if (t.IsByRef) return MentionsBp(t.GetElementType(), depth + 1);
            if (t.IsGenericType) foreach (var g in t.GetGenericArguments()) if (MentionsBp(g, depth + 1)) return true;
            if (t.IsGenericParameter) return false;
            return !IsSystem(t);
        }
        catch (Exception) { return false; }
    }

    // ------------------------------------------------------------------ B
    static void KeyTypes(Report rep, Context ctx)
    {
        var list = new List<Type>();
        if (ctx.CodeStageType != null) list.Add(ctx.CodeStageType);
        foreach (var t in ctx.StackTypes) if (!list.Contains(t)) list.Add(t);
        if (ctx.StageRoot != null && !list.Contains(ctx.StageRoot)) list.Add(ctx.StageRoot);
        var wanted = new HashSet<string>(KeyTypeNames, StringComparer.OrdinalIgnoreCase);
        foreach (var a in ctx.Scan)
            foreach (var t in SafeTypes(a))
                if (wanted.Contains(t.Name) && !list.Contains(t)) list.Add(t);
        rep.Line("the code stage class, every non-framework type on the stack, the stage root, and the usual names (" + list.Count + " types)");
        foreach (var t in list) { try { DumpType(rep, ctx, t, true); } catch (Exception ex) { rep.Line("--- " + t.Name + "  (unreadable: " + ex.GetType().Name + ")"); } }
        if (ctx.StageRoot != null)
        {
            rep.Line("--- stage hierarchy: every type deriving from " + TypeName(ctx.StageRoot));
            int n = 0;
            foreach (var a in ctx.Scan)
                foreach (var t in SafeTypes(a))
                {
                    bool sub = false; try { sub = t != ctx.StageRoot && ctx.StageRoot.IsAssignableFrom(t); } catch (Exception) { }
                    if (!sub) continue;
                    n++;
                    rep.Line("    " + TypeName(t) + " : " + TypeName(SafeBase(t)) + (t.IsAbstract ? "  [a]" : ""));
                }
            rep.Line("    (" + n + " stage types)");
        }
    }

    // ------------------------------------------------------------------ C
    static void KeywordTypes(Report rep, Context ctx)
    {
        rep.Line("every type in the blue prism assemblies whose name contains a keyword; types already in [key types] are referenced, not repeated");
        int n = 0;
        foreach (var a in ctx.Scan)
        {
            var types = SafeTypes(a);
            types.Sort(delegate(Type x, Type y) { return string.CompareOrdinal(x.FullName, y.FullName); });
            foreach (var t in types)
            {
                string key = Matches(t.Name, ctx.Keys);
                if (key == null) continue;
                n++;
                try
                {
                    if (ctx.Dumped.Contains(t)) { rep.Line("--- " + TypeName(t) + "  (" + key + ")  see [key types]"); continue; }
                    DumpType(rep, ctx, t, false);
                }
                catch (Exception ex) { rep.Line("--- " + t.Name + "  (unreadable: " + ex.GetType().Name + ")"); }
            }
        }
        rep.Line("    (" + n + " keyword types)");
    }
    static string Matches(string name, List<string> keys)
    {
        foreach (var k in keys) if (name.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0) return k;
        return null;
    }

    // ------------------------------------------------------------------ D
    static void AllTypes(Report rep, Context ctx)
    {
        foreach (var a in ctx.Scan)
        {
            var types = SafeTypes(a);
            types.Sort(delegate(Type x, Type y) { return string.CompareOrdinal(x.FullName, y.FullName); });
            rep.Line("--- " + SafeName(a) + "  types: " + types.Count);
            foreach (var t in types)
            {
                ctx.TypesIndexed++;
                try
                {
                    int count = 0;
                    try { count = t.GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly).Length; } catch (Exception) { }
                    rep.Line("  " + TypeName(t) + " : " + TypeName(SafeBase(t)) + "  (" + count + ")" + Kind(t));
                }
                catch (Exception ex) { rep.Line("  " + t.Name + "  (unreadable: " + ex.GetType().Name + ")"); }
            }
        }
    }

    // ------------------------------------------------------------------ type dump
    static void DumpType(Report rep, Context ctx, Type t, bool withChain)
    {
        if (!ctx.Dumped.Add(t)) return;
        rep.Line("--- " + TypeName(t) + Kind(t) + "  assembly: " + AsmShort(t) + (IsDynamic(t.Assembly) ? " (in-memory)" : ""));
        rep.Line("    base: " + BaseChain(t) + "  interfaces: " + Interfaces(t));
        if (t.IsEnum) { try { rep.Line("    values: " + string.Join(", ", Enum.GetNames(t))); } catch (Exception) { } }
        MemberInfo[] members;
        try { members = t.GetMembers(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly); }
        catch (Exception ex) { rep.Line("    (members unavailable: " + ex.GetType().Name + ")"); return; }
        var lines = new List<string>();
        foreach (var m in members)
        {
            try
            {
                var mi = m as MethodInfo;
                if (mi != null && mi.IsSpecialName) continue;             // property/event accessors shown with their property/event
                string s = Describe(m);
                if (s != null) lines.Add(s);
            }
            catch (Exception) { }
        }
        lines.Sort(StringComparer.Ordinal);
        int n = 0;
        foreach (var l in lines) { if (n++ >= MaxMembersPerType) { rep.Line("    ... (" + lines.Count + " members, cap " + MaxMembersPerType + ")"); break; } rep.Line("    " + l); }
        if (withChain)
        {
            var b = SafeBase(t);
            while (b != null && b != typeof(object) && !IsSystem(b))
            {
                if (!ctx.Dumped.Contains(b)) { rep.Line("    (base class follows)"); DumpType(rep, ctx, b, false); }
                b = SafeBase(b);
            }
        }
    }
    static string Describe(MemberInfo m)
    {
        var f = m as FieldInfo;
        if (f != null) return "f " + Vis(f) + (f.IsStatic ? "[s]" : "   ") + " " + f.Name + " : " + TypeName(f.FieldType) + (f.IsInitOnly ? "  readonly" : "") + (f.IsLiteral ? "  const" : "");
        var p = m as PropertyInfo;
        if (p != null)
        {
            var g = p.GetGetMethod(true); var s = p.GetSetMethod(true);
            var acc = g ?? s;
            return "p " + Vis(acc) + (acc != null && acc.IsStatic ? "[s]" : "   ") + Mods(acc) + " " + p.Name + Params(p.GetIndexParameters(), "[", "]") + " : " + TypeName(p.PropertyType)
                   + " {" + (g != null ? " get" : "") + (s != null ? " set" : "") + " }";
        }
        var mi = m as MethodInfo;
        if (mi != null) return "m " + Vis(mi) + (mi.IsStatic ? "[s]" : "   ") + Mods(mi) + " " + mi.Name + Generic(mi) + Params(mi.GetParameters(), "(", ")") + " : " + TypeName(mi.ReturnType);
        var c = m as ConstructorInfo;
        if (c != null) return "c " + Vis(c) + (c.IsStatic ? "[s]" : "   ") + " .ctor" + Params(c.GetParameters(), "(", ")");
        var e = m as EventInfo;
        if (e != null) return "e " + Vis(e.GetAddMethod(true)) + "    " + e.Name + " : " + TypeName(e.EventHandlerType);
        var nt = m as Type;
        if (nt != null) return "n      " + nt.Name + Kind(nt) + " : " + TypeName(nt.BaseType);
        return null;
    }
    static string Mods(MethodBase mb)
    {
        var mi = mb as MethodInfo;
        if (mi == null) return "";
        if (mi.IsAbstract) return "[a]";
        if (mi.IsVirtual && mi.GetBaseDefinition() != mi) return "[o]";
        if (mi.IsVirtual && !mi.IsFinal) return "[v]";
        return "";
    }
    static string Vis(MemberInfo m)
    {
        var f = m as FieldInfo; if (f != null) return f.IsPublic ? "+" : f.IsPrivate ? "-" : "~";
        var mb = m as MethodBase; if (mb != null) return mb.IsPublic ? "+" : mb.IsPrivate ? "-" : "~";
        var t = m as Type; if (t != null) return t.IsPublic || t.IsNestedPublic ? "+" : "~";
        return " ";
    }
    static string Params(ParameterInfo[] ps, string open, string close)
    {
        if (ps == null || ps.Length == 0) return open == "[" ? "" : open + close;
        var sb = new StringBuilder(open);
        for (int i = 0; i < ps.Length; i++)
        {
            if (i > 0) sb.Append(", ");
            var p = ps[i];
            if (p.IsOut) sb.Append("out "); else if (p.ParameterType.IsByRef) sb.Append("ref ");
            sb.Append(TypeName(p.ParameterType.IsByRef ? p.ParameterType.GetElementType() : p.ParameterType)).Append(' ').Append(p.Name);
        }
        return sb.Append(close).ToString();
    }
    static string Generic(MethodInfo m)
    {
        if (!m.IsGenericMethod) return "";
        var sb = new StringBuilder("<"); var gs = m.GetGenericArguments();
        for (int i = 0; i < gs.Length; i++) { if (i > 0) sb.Append(", "); sb.Append(gs[i].Name); }
        return sb.Append('>').ToString();
    }
    static string Sig(MethodBase m)
    {
        try { return TypeName(m.DeclaringType) + "." + m.Name + Params(m.GetParameters(), "(", ")"); }
        catch (Exception) { return (m.DeclaringType == null ? "?" : m.DeclaringType.Name) + "." + m.Name; }
    }
    static Type SafeBase(Type t) { try { return t.BaseType; } catch (Exception) { return null; } }
    static string Kind(Type t)
    {
        try { return KindRaw(t); } catch (Exception) { return ""; }
    }
    static string KindRaw(Type t)
    {
        if (t.IsInterface) return "  [interface]";
        if (t.IsEnum) return "  [enum]";
        if (t.IsValueType) return "  [struct]";
        if (t.IsAbstract && t.IsSealed) return "  [static]";
        if (t.IsAbstract) return "  [abstract]";
        if (t.IsSealed) return "  [sealed]";
        return "";
    }
    static string BaseChain(Type t)
    {
        var sb = new StringBuilder(); var b = SafeBase(t); int n = 0;
        while (b != null && n++ < 8) { if (sb.Length > 0) sb.Append(" > "); sb.Append(TypeName(b)); b = SafeBase(b); }
        return sb.Length == 0 ? "(none)" : sb.ToString();
    }
    static string Interfaces(Type t)
    {
        try
        {
            var ifs = t.GetInterfaces(); if (ifs.Length == 0) return "(none)";
            var names = new List<string>(); foreach (var i in ifs) if (!IsSystem(i) || names.Count < 6) names.Add(TypeName(i));
            return string.Join(", ", names.ToArray());
        }
        catch (Exception) { return "?"; }
    }
    public static string TypeName(Type t)
    {
        if (t == null) return "?";
        try
        {
            if (t.IsByRef) return TypeName(t.GetElementType()) + "&";
            if (t.IsArray) return TypeName(t.GetElementType()) + "[]";
            if (t.IsGenericParameter) return t.Name;
            if (t.IsGenericType)
            {
                string n = t.GetGenericTypeDefinition().FullName ?? t.Name; int i = n.IndexOf('`'); if (i > 0) n = n.Substring(0, i);
                var sb = new StringBuilder(Short(n)).Append('<'); var gs = t.GetGenericArguments();
                for (int k = 0; k < gs.Length; k++) { if (k > 0) sb.Append(", "); sb.Append(TypeName(gs[k])); }
                return sb.Append('>').ToString();
            }
            return Short(t.FullName ?? t.Name);
        }
        catch (Exception) { return t.Name; }
    }
    /// System.String -> string style shortening for the framework only; estate types keep their namespace.
    static string Short(string full)
    {
        switch (full)
        {
            case "System.String": return "string"; case "System.Int32": return "int"; case "System.Boolean": return "bool";
            case "System.Object": return "object"; case "System.Void": return "void"; case "System.Decimal": return "decimal";
            case "System.Double": return "double"; case "System.Int64": return "long"; case "System.DateTime": return "DateTime";
            case "System.Guid": return "Guid"; case "System.Byte": return "byte"; case "System.Char": return "char";
        }
        if (full.StartsWith("System.Collections.Generic.")) return full.Substring("System.Collections.Generic.".Length);
        return full;
    }

    // ------------------------------------------------------------------ helpers
    static bool IsSystem(Type t)
    {
        string n = t.Namespace ?? "";
        return n == "System" || n.StartsWith("System.") || n.StartsWith("Microsoft.") || n.StartsWith("MS.");
    }
    static bool IsSystemAsm(string name)
    {
        return name == "mscorlib" || name == "netstandard" || name.StartsWith("System") || name.StartsWith("Microsoft") || name.StartsWith("mscorlib")
            || name == "Accessibility" || name == "PresentationCore" || name == "PresentationFramework" || name == "WindowsBase" || name.StartsWith("UIAutomation")
            || name == "Newtonsoft.Json" || name == "Mono.Security" || name.StartsWith("Mono.") || name == "I18N" || name.StartsWith("I18N.");
    }
    static bool IsDynamic(Assembly a)
    {
        try { if (a.IsDynamic) return true; return string.IsNullOrEmpty(a.Location); } catch (Exception) { return true; }
    }
    static string SafeName(Assembly a) { try { return a.GetName().Name; } catch (Exception) { return "?"; } }
    static string AsmShort(Type t) { return t == null ? "?" : SafeName(t.Assembly); }
    static List<Type> SafeTypes(Assembly a)
    {
        var list = new List<Type>();
        try { list.AddRange(a.GetTypes()); }
        catch (ReflectionTypeLoadException ex) { if (ex.Types != null) foreach (var t in ex.Types) if (t != null) list.Add(t); }
        catch (Exception) { }
        return list;
    }
    static string OneLine(string s, int max)
    {
        if (s == null) return "";
        s = s.Replace("\r", " ").Replace("\n", " ");
        return s.Length > max ? s.Substring(0, max) + "..." : s;
    }
}
