"""Generate the Radar prototype for Blue Prism (importable XML, estate-native profile):
  BPA Object - Radar.xml                      the recorder VBO (shared code = ../core/Radar.cs)
  BPA Object - Radar Demo Bank.xml            a UI object whose action dies at a Write stage
  BPA Process - PRC000 - Radar - Write Failure Demo.xml   calls it, catches, ends
Run from this folder:  python gen_radar.py && python run_test.py
Open items: PRC000 is the placeholder prefix (estate rule); spy the Demo Bank elements after import."""
import sys, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
# The rpa-bp skill lib (bp_gen.py, validate.py). On the dev box it is the installed skill; on the Blue Prism
# machine set RPA_BP_SKILL to the unzipped skill folder, or unzip it next to this radar folder as ../skill-rpa-bp.
SKILL = os.environ.get('RPA_BP_SKILL') or next((d for d in [os.path.expanduser('~/.claude/skills/rpa-bp'),
                                                             os.path.join(HERE, '..', '..', 'skill-rpa-bp'),
                                                             os.path.join(HERE, '..', 'skill-rpa-bp')] if os.path.isdir(os.path.join(d, 'lib'))), None)
if SKILL is None:
    sys.exit('rpa-bp skill lib not found: set RPA_BP_SKILL=<folder that contains lib/bp_gen.py>')
sys.path.insert(0, os.path.join(SKILL, 'lib'))

# Session-log noise cut (2026-11-05): every stage of the Radar object, and every Action stage that calls Radar from
# another object, carries <loginhibit />, so Radar never appears in the Blue Prism session log. Only stage kinds that
# have the "Don't log this stage" option in Studio get it.
_INHIBIT_TYPES = ('Action', 'Code', 'Calculation', 'MultipleCalculation', 'Decision', 'Navigate', 'Read', 'Write', 'WaitStart', 'Note', 'Exception', 'Alert')
def inhibit_logging(path, only_calls_to=None):
    x = open(path, encoding='utf-8').read()
    n = 0
    def fix(m):
        nonlocal n
        head, body = m.group(1), m.group(2)
        stype = re.search(r'type="([^"]+)"', head).group(1)
        if stype not in _INHIBIT_TYPES or '<loginhibit' in body: return m.group(0)
        if only_calls_to and not re.search(r'<resource object="' + re.escape(only_calls_to) + '"', body): return m.group(0)
        n += 1
        return head + '\n  <loginhibit />' + body
    x = re.sub(r'(<stage stageid="[^"]+" name="[^"]+" type="[^"]+">)([\s\S]*?</stage>)', fix, x)
    open(path, 'w', encoding='utf-8', newline='\n').write(x)
    return n
from bp_gen import Proc, lit

OUT = os.path.join(HERE, 'out')

# ---- shared code: Radar.cs minus `using` lines (they become Namespace Imports) ----
def shared_code(name):
    src = open(os.path.join(HERE, '..', 'core', name), encoding='utf-8').read()
    return (re.findall(r'^using ([\w.]+);', src, re.M),
            '\n'.join(l for l in src.split('\n') if not l.startswith('using ') and not l.startswith('//')))
usings, shared = shared_code('Radar.cs')

# =============================== Radar VBO ===============================
r = Proc('Radar', 'object', 'In-memory flight recorder: Record is free, Dump writes one incident folder (trail, data items at failure, screenshot) only when something fails. Configure also hooks the .NET runtime: every exception thrown in a code stage or inside Blue Prism lands in the trail with object, stage and a throw-time screenshot.')
r.code_options(language='csharp',
               references=['System.dll', 'System.Data.dll', 'System.Xml.dll', 'System.Drawing.dll', 'System.Core.dll'],
               imports=sorted(set(['System', 'System.Data', 'System.Linq', 'System.Collections.Generic'] + usings)),
               globalcode=shared)
r.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
# BANK-SIDE EDIT POINT: if Radar.cs gained Configure inputs (e.g. Stage Log / Data Chain flags), add them to the
# inputs list and the body below, then regenerate. Flags: ('flag', 'Stage Log', 'Stage_Log').
r.code_action('Configure Radar', 'Set the incident root folder and ring capacity. Empty folder / zero capacity keep the defaults (%TEMP%\\Radar, 50).',
              inputs=[('text', 'Root Folder', 'Root_Folder'), ('number', 'Capacity', 'Capacity'),
                      ('flag', 'Stage Log', 'Stage_Log'), ('flag', 'Data Chain', 'Data_Chain')], outputs=[],
              body='RadarCore.Configure(Root_Folder, (int)Capacity, Stage_Log, Data_Chain);')
r.code_action('Record Event', 'Append one entry to the ring (label + detail). No I/O; the oldest entry falls off past capacity.',
              inputs=[('text', 'Label', 'Label'), ('text', 'Detail', 'Detail')], outputs=[],
              body='RadarCore.Record(Label, Detail);')
r.code_action('Dump Incident', 'Write the incident folder: trail, data items at failure, exception, screenshot. Clears the ring. Never throws; Dump Folder starts with ERROR: when the folder could not be written.',
              inputs=[('text', 'Process', 'Process'), ('text', 'Page', 'Page'),
                      ('text', 'Exception Type', 'Exception_Type'), ('text', 'Exception Detail', 'Exception_Detail'),
                      ('text', 'Exception Stage', 'Exception_Stage'), ('text', 'Data Items', 'Data_Items'),
                      ('flag', 'Capture Screen', 'Capture_Screen')],
              outputs=[('text', 'Dump Folder', 'Dump_Folder')],
              body='Dump_Folder = RadarCore.Dump(Process, Page, Exception_Type, Exception_Detail, Exception_Stage, Data_Items, Capture_Screen);')
r.code_action('Environment Snapshot', 'The machine at this moment: session type (console / RDP / Citrix), memory, disk, the automated apps\' processes with their window titles, event log errors of the last minutes, network, clock. Dump Incident takes the same snapshot by itself (env.txt); this action is for a manual check.',
              inputs=[], outputs=[('text', 'Snapshot', 'Snapshot')],
              body='Snapshot = RadarCore.EnvSnapshot().Text;')
r.code_action('Get Trail', 'Return the current ring as text, oldest first (inspection / tests).',
              inputs=[], outputs=[('text', 'Trail', 'Trail')],
              body='Trail = RadarCore.Trail();')
r.code_action('Hook Status', 'State of the runtime hook that Configure installs (live / not live / off) with its counters: seen, ignored as noise, recorded, other threads.',
              inputs=[], outputs=[('text', 'Status', 'Status'), ('flag', 'Live', 'Live')],
              body='Status = RadarCore.HookStatus;\nLive = RadarCore.HookLive;')
print(r.write('BPA Object - Radar.xml', outdir=OUT))
print('  log-inhibited stages in Radar:', inhibit_logging(os.path.join(OUT, 'BPA Object - Radar.xml')))

# =============================== Demo Bank UI object ===============================
APP = 'Demo Bank'
WIN, ACC, AMT, BTN, LBL = ('Window - Transfer - Win32', 'Textbox - Account - Win32', 'Textbox - Amount - Win32',
                           'Button - Submit - Win32', 'Label - Result - Win32')
LWIN, USR, LBTN, LSTAT = ('Window - Login - Win32', 'Textbox - User - Win32', 'Button - Log In - Win32', 'Label - Status - Win32')
o = Proc('Radar Demo Bank', 'object', 'Demo UI object: one action that fails at a Write stage to prove the Radar dump.')
o.application(APP, 'Win32Launch', {'Path': '', 'CommandLineParams': '', 'WorkingDirectory': '', 'NonInvasive': 'True'})
o.element(WIN, 'Window')
for el, t in ((ACC, 'Edit'), (AMT, 'Edit'), (BTN, 'Button'), (LBL, 'Label')):
    o.element(WIN + '/' + el, t)
o.element(LWIN, 'Window')
for el, t in ((USR, 'Edit'), (LBTN, 'Button'), (LSTAT, 'Label')):
    o.element(LWIN + '/' + el, t)

def rec(page, name, label, detail):
    """One Record call = what the instrument pass inserts before a stage."""
    page.action(name, 'Radar', 'Record Event', inputs=[('text', 'Label', lit(label)), ('text', 'Detail', detail)])
o.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
at = o.page('Attach', 'Attach to the running Demo Bank window.', published=False)
at.navigate('Attach Demo Bank', [(APP, 'AttachApplication')])

li = o.page('Log In', 'Type the user and press Log In; return the status line. Instrumented with Radar.')
li.add_input('text', 'User Name')
li.add_output('text', 'Status')
li.data('Login Timeout', 'number', initial='10')
li.page_ref('Attach For Login', page='Attach')
rec(li, 'Record Login Entry', 'page:Log In', '"User Name=" & [User Name]')
li.wait_for('Wait For Login Window', [(LWIN, 'CheckExists', 'NEXT')], '[Login Timeout]', on_timeout='Login Window Missing')
rec(li, 'Record Enter User', 'write:Enter User', '"' + USR + ' <= " & [User Name]')
li.write('Enter User', [(USR, '[User Name]')])
rec(li, 'Record Press Log In', 'navigate:Press Log In', lit(LBTN + ' Press'))
li.navigate('Press Log In', [(LBTN, 'Press')])
li.read('Read Login Status', [(LSTAT, 'GetWindowText', 'Status', 'text')])
rec(li, 'Record Login Status', 'read:Read Login Status', '"' + LSTAT + ' => " & [Status]', )
li.exception('Login Window Missing', 'System Exception', lit('Demo Bank login window did not appear'))
li.steps[-2]['goto'] = 'END'

pg = o.page('Enter Transfer', 'Type account and amount, submit, read the result line. Instrumented with Radar: entry recorded, failure dumped with the page data items.')
pg.add_input('text', 'Account')
pg.add_input('text', 'Amount')
pg.add_output('text', 'Result')
pg.data('Window Timeout', 'number', initial='10')
pg.data('txt_Ex Type', 'text')
pg.data('txt_Ex Detail', 'text')
pg.data('txt_Ex Stage', 'text')
pg.page_ref('Attach To Demo Bank', page='Attach')
rec(pg, 'Record Transfer Entry', 'page:Enter Transfer', '"Account=" & [Account] & ";Amount=" & [Amount]')
pg.wait_for('Wait For Transfer Window', [(WIN, 'CheckExists', 'NEXT')], '[Window Timeout]', on_timeout='Transfer Window Missing')
rec(pg, 'Record Enter Account', 'write:Enter Account', '"' + ACC + ' <= " & [Account]')
pg.write('Enter Account', [(ACC, '[Account]')])
rec(pg, 'Record Enter Amount', 'write:Enter Amount', '"' + AMT + ' <= " & [Amount] & " EUR"')
pg.write('Enter Amount', [(AMT, '[Amount] & " EUR"')])          # the stage that dies in the test
rec(pg, 'Record Press Submit', 'navigate:Press Submit', lit(BTN + ' Press'))
pg.navigate('Press Submit', [(BTN, 'Press')])
pg.read('Read Result', [(LBL, 'GetWindowText', 'Result', 'text')])
rec(pg, 'Record Result', 'read:Read Result', '"' + LBL + ' => " & [Result]')
pg.steps[-1]['goto'] = 'END'
pg.exception('Transfer Window Missing', 'System Exception', lit('Demo Bank transfer window did not appear'))
# every data item on the page + the inline write expressions, as "name=value" lines
DATA_ITEMS = ('"Account=" & [Account] & NewLine() & '
              '"Amount=" & [Amount] & NewLine() & '
              '"Window Timeout=" & [Window Timeout] & NewLine() & '
              '"expr:Enter Amount/1=[Amount] & "" EUR"""')
pg.work_block('Transfer Entry', first='Wait For Transfer Window', last='Record Result',
              capture=('txt_Ex Type', 'txt_Ex Detail', 'txt_Ex Stage'),
              handler=[('Dump Radar Incident', 'Radar', 'Dump Incident',
                        [('text', 'Process', lit('Radar Demo Bank')), ('text', 'Page', lit('Enter Transfer')),
                         ('text', 'Exception Type', '[txt_Ex Type]'), ('text', 'Exception Detail', '[txt_Ex Detail]'),
                         ('text', 'Exception Stage', '[txt_Ex Stage]'), ('text', 'Data Items', DATA_ITEMS),
                         ('flag', 'Capture Screen', 'True')])],
              then='RETHROW')
print(o.write('BPA Object - Radar Demo Bank.xml', outdir=OUT))
print('spy after import:', ', '.join(p.split('/')[-1] for p in o.spy_checklist()))

# =============================== Demo process ===============================
p = Proc('PRC000 - Radar - Write Failure Demo', 'process', 'Configure Radar, run one transfer that fails at a Write stage, catch it, end. Shows the dump the object leaves behind.')
m = p.page('Main', 'Configure, run, catch, end.')
m.data('Radar Root Folder', 'text', exposure='Environment')
m.data('g_txt_Result', 'text')
m.data('g_txt_Login Status', 'text')
m.data('g_txt_Ex Type', 'text')
m.data('g_txt_Ex Detail', 'text')
m.data('g_txt_Ex Stage', 'text')
m.action('Configure Radar', 'Radar', 'Configure Radar',
         inputs=[('text', 'Root Folder', '[Radar Root Folder]'), ('number', 'Capacity', '50'), ('flag', 'Stage Log', 'True'), ('flag', 'Data Chain', 'True')])
m.action('Log In', 'Radar Demo Bank', 'Log In',
         inputs=[('text', 'User Name', lit('rpa.bot'))], outputs=[('text', 'Status', 'g_txt_Login Status')])
m.action('Enter Transfer', 'Radar Demo Bank', 'Enter Transfer',
         inputs=[('text', 'Account', lit('DE123')), ('text', 'Amount', lit('50,00'))],
         outputs=[('text', 'Result', 'g_txt_Result')])
m.work_block('Transfer', first='Enter Transfer', last='Enter Transfer',
             capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'), then='END')
print(p.write('BPA Process - PRC000 - Radar - Write Failure Demo.xml', outdir=OUT))

# =============================== The no-process-change route ===============================
# Estate processes already log through a house logging object (Save Event) and already call it
# from their Recover handlers with the captured exception. Put Radar INSIDE that object: the
# processes stay byte-identical, only the logging object is re-released.
#   out/            House Logging WITH Radar inside
#   out_plain/      House Logging as it is today (no Radar) -- same interface, for the A/B run
OUT_PLAIN = os.path.join(HERE, 'out_plain')

def house_logging(with_radar):
    h = Proc('House Logging', 'object', 'Stand-in for the estate house logging object: one Save Event action.'
             + (' Radar inside: every event is recorded, an Error event dumps the incident.' if with_radar else ''))
    h.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
    pg = h.page('Save Event', 'Save one event (Info / Warning / Error) from a process.')
    for nm in ('Event Type', 'Message', 'Process', 'Exception Type', 'Exception Detail', 'Exception Stage'):
        pg.add_input('text', nm)
    pg.data('txt_Saved Event', 'text')
    pg.calc('Set Saved Event', '[Event Type] & ": " & [Message]', 'txt_Saved Event')   # where the real object writes its log
    if with_radar:
        pg.data('Radar Root Folder', 'text', exposure='Environment')
        # Configure once per session, not on every Save Event: the flag lives on the object's Initialise page,
        # so it survives between action calls of one session (Copilot's observation 2026-11-05).
        h.object_data('flg_Radar Configured', 'flag')
        pg.decision('Radar Configured?', '[flg_Radar Configured]', true_target='Record Event In Radar', false_target='NEXT')
        pg.action('Configure Radar', 'Radar', 'Configure Radar',
                  inputs=[('text', 'Root Folder', '[Radar Root Folder]'), ('number', 'Capacity', '50'), ('flag', 'Stage Log', 'True'), ('flag', 'Data Chain', 'True')])
        pg.calc('Mark Radar Configured', 'True', 'flg_Radar Configured')
        pg.action('Record Event In Radar', 'Radar', 'Record Event',
                  inputs=[('text', 'Label', '[Event Type] & ":" & [Process]'), ('text', 'Detail', '[Message]')])
        pg.decision('Error Event?', '[Event Type] = "Error"', true_target='NEXT', false_target='END')
        pg.action('Dump Radar Incident', 'Radar', 'Dump Incident',
                  inputs=[('text', 'Process', '[Process]'), ('text', 'Page', lit('')),
                          ('text', 'Exception Type', '[Exception Type]'), ('text', 'Exception Detail', '[Exception Detail]'),
                          ('text', 'Exception Stage', '[Exception Stage]'), ('text', 'Data Items', lit('')),
                          ('flag', 'Capture Screen', 'True')],
                  outputs=[('text', 'Dump Folder', 'txt_Dump Folder')])
    return h

print(house_logging(True).write('BPA Object - House Logging.xml', outdir=OUT))
print('  log-inhibited Radar calls in House Logging:', inhibit_logging(os.path.join(OUT, 'BPA Object - House Logging.xml'), only_calls_to='Radar'))
print(house_logging(False).write('BPA Object - House Logging.xml', outdir=OUT_PLAIN))

# the UI object as the estate has it today: no Radar calls, no Recover (the exception bubbles up)
q = Proc('Demo Bank Plain', 'object', 'Demo UI object exactly as an estate object is today: no Radar, no instrumentation.')
q.application(APP, 'Win32Launch', {'Path': '', 'CommandLineParams': '', 'WorkingDirectory': '', 'NonInvasive': 'True'})
q.element(WIN, 'Window')
for el, t in ((ACC, 'Edit'), (AMT, 'Edit'), (BTN, 'Button'), (LBL, 'Label')):
    q.element(WIN + '/' + el, t)
q.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
qa = q.page('Attach', 'Attach to the running Demo Bank window.', published=False)
qa.navigate('Attach Demo Bank', [(APP, 'AttachApplication')])
qp = q.page('Enter Transfer', 'Type account and amount, submit, read the result line.')
qp.add_input('text', 'Account'); qp.add_input('text', 'Amount'); qp.add_output('text', 'Result')
qp.data('Window Timeout', 'number', initial='10')
qp.page_ref('Attach To Demo Bank', page='Attach')
qp.wait_for('Wait For Transfer Window', [(WIN, 'CheckExists', 'NEXT')], '[Window Timeout]', on_timeout='Transfer Window Missing')
qp.write('Enter Account', [(ACC, '[Account]')])
qp.write('Enter Amount', [(AMT, '[Amount] & " EUR"')])
qp.navigate('Press Submit', [(BTN, 'Press')])
qp.read('Read Result', [(LBL, 'GetWindowText', 'Result', 'text')], goto='END')
qp.exception('Transfer Window Missing', 'System Exception', lit('Demo Bank transfer window did not appear'))
print(q.write('BPA Object - Demo Bank Plain.xml', outdir=OUT))

# the process as the estate writes it today: logs through House Logging, catches with capture, logs the error. NO Radar anywhere.
e = Proc('PRC000 - Radar - House Logging Demo', 'process', 'An ordinary estate process: logs progress and errors through House Logging only.')
em = e.page('Main', 'Log start, do the transfer, log the outcome.')
em.data('g_txt_Result', 'text')
em.data('g_txt_Ex Type', 'text'); em.data('g_txt_Ex Detail', 'text'); em.data('g_txt_Ex Stage', 'text')
LOGP = lit('PRC000 - Radar - House Logging Demo')
def ev(name, etype, msg, ex=False):
    em.action(name, 'House Logging', 'Save Event',
              inputs=[('text', 'Event Type', lit(etype)), ('text', 'Message', msg), ('text', 'Process', LOGP),
                      ('text', 'Exception Type', '[g_txt_Ex Type]' if ex else lit('')),
                      ('text', 'Exception Detail', '[g_txt_Ex Detail]' if ex else lit('')),
                      ('text', 'Exception Stage', '[g_txt_Ex Stage]' if ex else lit(''))])
ev('Log Start', 'Info', lit('Run started'))
ev('Log Item', 'Info', lit('Working item RITM0001: transfer DE123 / 50,00'))
em.action('Enter Transfer', 'Demo Bank Plain', 'Enter Transfer',
          inputs=[('text', 'Account', lit('DE123')), ('text', 'Amount', lit('50,00'))],
          outputs=[('text', 'Result', 'g_txt_Result')])
ev('Log Done', 'Info', '"Transfer result: " & [g_txt_Result]')
em.work_block('Transfer', first='Enter Transfer', last='Log Done',
              capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
              handler=[('Log Error', 'House Logging', 'Save Event',
                        [('text', 'Event Type', lit('Error')), ('text', 'Message', '[g_txt_Ex Detail]'), ('text', 'Process', LOGP),
                         ('text', 'Exception Type', '[g_txt_Ex Type]'), ('text', 'Exception Detail', '[g_txt_Ex Detail]'),
                         ('text', 'Exception Stage', '[g_txt_Ex Stage]')])],
              then='END')
print(e.write('BPA Process - PRC000 - Radar - House Logging Demo.xml', outdir=OUT))


# =============================== API / code failure demo (the real CSV case) ===============================
# What the bank log showed: an API answered with non-JSON ("H..."), JSON To Collection died, the
# Errors-Only log had the message but not the text that failed to parse. Here the API is doubled by an
# Environment Variable so the test can serve JSON or an HTML error page.
a = Proc('Demo API', 'object', 'Demo code object: fetch a customer from an API and parse the JSON. Instrumented with Radar.')
a.code_options(language='csharp',
               references=['System.dll', 'System.Data.dll', 'System.Xml.dll', 'System.Drawing.dll', 'System.Core.dll', 'System.Web.Extensions.dll'],
               imports=['System', 'System.Data', 'System.Linq', 'System.Collections.Generic', 'System.Web.Script.Serialization'])
a.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
a.code_action('Call Customer API', 'Return the raw API response for a customer (doubled: the response comes from the Demo API Response environment variable).',
              inputs=[('text', 'Customer ID', 'Customer_ID'), ('text', 'Canned Response', 'Canned_Response')],
              outputs=[('text', 'Response', 'Response')],
              body='Response = Canned_Response;')
a.code_action('JSON To Customer', 'Parse the customer JSON into a name (the stage that dies on a non-JSON response).',
              inputs=[('text', 'JSON', 'JSON')], outputs=[('text', 'Customer Name', 'Customer_Name')],
              body='var d = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(JSON);\nCustomer_Name = d["name"].ToString();')
gp = a.page('Get Customer Name', 'Call the API and parse the answer. Record the response before parsing; dump the page on failure.')
gp.add_input('text', 'Customer ID')
gp.add_output('text', 'Customer Name')
gp.data('Demo API Response', 'text', exposure='Environment')
gp.data('txt_Response', 'text')
gp.data('txt_Ex Type', 'text'); gp.data('txt_Ex Detail', 'text'); gp.data('txt_Ex Stage', 'text')
rec(gp, 'Record Get Customer Entry', 'page:Get Customer Name', '"Customer ID=" & [Customer ID]')
gp.action('Call API', 'Demo API', 'Call Customer API',
          inputs=[('text', 'Customer ID', '[Customer ID]'), ('text', 'Canned Response', '[Demo API Response]')],
          outputs=[('text', 'Response', 'txt_Response')])
rec(gp, 'Record API Response', 'read:Call API', '"response[0..300]=" & Left([txt_Response], 300)')
gp.action('Parse Customer', 'Demo API', 'JSON To Customer',
          inputs=[('text', 'JSON', '[txt_Response]')], outputs=[('text', 'Customer Name', 'Customer Name')])
rec(gp, 'Record Customer Name', 'read:Parse Customer', '"Customer Name=" & [Customer Name]')
gp.work_block('Customer Lookup', first='Call API', last='Record Customer Name',
              capture=('txt_Ex Type', 'txt_Ex Detail', 'txt_Ex Stage'),
              handler=[('Dump Radar Incident', 'Radar', 'Dump Incident',
                        [('text', 'Process', lit('Demo API')), ('text', 'Page', lit('Get Customer Name')),
                         ('text', 'Exception Type', '[txt_Ex Type]'), ('text', 'Exception Detail', '[txt_Ex Detail]'),
                         ('text', 'Exception Stage', '[txt_Ex Stage]'),
                         ('text', 'Data Items', '"Customer ID=" & [Customer ID] & NewLine() & "txt_Response=" & [txt_Response] & NewLine() & "Customer Name=" & [Customer Name]'),
                         ('flag', 'Capture Screen', 'False')])],
              then='RETHROW')
print(a.write('BPA Object - Demo API.xml', outdir=OUT))

# an ordinary estate process around it: logs through House Logging (Radar inside) AND calls the instrumented object.
# Both dump the same exception -> Radar dedupes to ONE incident folder.
f = Proc('PRC000 - Radar - API Failure Demo', 'process', 'Look up a customer through the API object; log through House Logging.')
fm = f.page('Main', 'Log, look up, log the outcome.')
fm.data('g_txt_Customer Name', 'text')
fm.data('g_txt_Ex Type', 'text'); fm.data('g_txt_Ex Detail', 'text'); fm.data('g_txt_Ex Stage', 'text')
LOGF = lit('PRC000 - Radar - API Failure Demo')
def evf(name, etype, msg):
    fm.action(name, 'House Logging', 'Save Event',
              inputs=[('text', 'Event Type', lit(etype)), ('text', 'Message', msg), ('text', 'Process', LOGF),
                      ('text', 'Exception Type', lit('')), ('text', 'Exception Detail', lit('')), ('text', 'Exception Stage', lit(''))])
evf('Log Start', 'Info', lit('Run started'))
evf('Log Item', 'Info', lit('Working item RITM0002: customer C1'))
fm.action('Get Customer Name', 'Demo API', 'Get Customer Name',
          inputs=[('text', 'Customer ID', lit('C1'))], outputs=[('text', 'Customer Name', 'g_txt_Customer Name')])
evf('Log Done', 'Info', '"Customer: " & [g_txt_Customer Name]')
fm.work_block('Customer', first='Get Customer Name', last='Log Done',
              capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
              handler=[('Log Error', 'House Logging', 'Save Event',
                        [('text', 'Event Type', lit('Error')), ('text', 'Message', '[g_txt_Ex Detail]'), ('text', 'Process', LOGF),
                         ('text', 'Exception Type', '[g_txt_Ex Type]'), ('text', 'Exception Detail', '[g_txt_Ex Detail]'),
                         ('text', 'Exception Stage', '[g_txt_Ex Stage]')])],
              then='END')
print(f.write('BPA Process - PRC000 - Radar - API Failure Demo.xml', outdir=OUT))


# =============================== The runtime hook experiment ===============================
# One code stage subscribes to AppDomain.FirstChanceException inside Automate: from then on EVERY exception
# thrown anywhere in the session (Blue Prism internals included) is logged at the moment of throw, with the
# call stack and a screenshot, with no instrumentation in any object. The process below installs the hook,
# then lets an UNinstrumented object die at a Write stage and a code stage die on bad JSON.
pusings, pshared = shared_code('RadarProbe.cs')
dusings, dshared = shared_code('RadarDiscover.cs')
pusings = sorted(set(pusings + dusings)); pshared = pshared + '\n' + dshared
pr = Proc('Radar Probe', 'object', 'Experiment: hook the .NET runtime Blue Prism runs in and log every exception at the moment it is thrown (type, message, call stack, screenshot). Install once per session.')
pr.code_options(language='csharp',
                references=['System.dll', 'System.Data.dll', 'System.Xml.dll', 'System.Drawing.dll', 'System.Core.dll'],
                imports=sorted(set(['System', 'System.Data', 'System.Linq', 'System.Collections.Generic'] + pusings)),
                globalcode=pshared)
pr.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
pr.code_action('Install Probe', 'Subscribe to first-chance exceptions (once per Automate process) and open <root>\\<machine>\\probe_<stamp>\\probe.log. Hook Live is False when this runtime never raises the event.',
               inputs=[('text', 'Root Folder', 'Root_Folder'), ('number', 'Max Screenshots', 'Max_Screenshots')],
               outputs=[('text', 'Probe Folder', 'Probe_Folder'), ('flag', 'Hook Live', 'Hook_Live')],
               body='Probe_Folder = ProbeCore.Install(Root_Folder, (int)Max_Screenshots);\nHook_Live = ProbeCore.Live;')
pr.code_action('Mark', 'Write a marker line into probe.log so the exceptions can be read against the process flow.',
               inputs=[('text', 'Text', 'Text')], outputs=[],
               body='ProbeCore.Mark(Text);')
pr.code_action('Probe Report', 'Counts per exception type and the last records; also written to report.txt in the probe folder.',
               inputs=[], outputs=[('text', 'Report', 'Report'), ('number', 'Exceptions Seen', 'Exceptions_Seen')],
               body='Report = ProbeCore.Report();\nExceptions_Seen = ProbeCore.Count;')
pr.code_action('Discover Runtime', 'Write one text report of what the .NET runtime exposes to this code stage: host, thread, full call stack, loaded Blue Prism assemblies, static roots, and the members of the logging / session / process / stage classes. Reflection metadata only: nothing is invoked, read or changed. Keywords empty = the default list.',
               inputs=[('text', 'Root Folder', 'Root_Folder'), ('text', 'Keywords', 'Keywords')],
               outputs=[('text', 'Report Folder', 'Report_Folder'), ('text', 'Summary', 'Summary')],
               body='Report_Folder = DiscoverCore.Run(Root_Folder, Keywords);\nSummary = DiscoverCore.LastSummary;')
print(pr.write('BPA Object - Radar Probe.xml', outdir=OUT))

# =============================== Discovery process ===============================
# Main -> sub-page -> object action -> code stage: the same nesting the capture layers must walk back,
# so the report's [stack] shows every runtime frame of that chain.
d = Proc('PRC000 - Radar - Discover', 'process', 'Discovery run for Radar: calls Radar Probe / Discover Runtime from a sub-page and ends. Read <root>\\<machine>\\discover_*\\discover.txt afterwards.')
dm = d.page('Main', 'Call the Discovery sub-page, keep its summary.')
dm.data('Radar Root Folder', 'text', exposure='Environment')
dm.data('g_txt_Report Folder', 'text'); dm.data('g_txt_Summary', 'text')
dm.page_ref('Discovery', 'Discovery', inputs=[('text', 'Root Folder', '[Radar Root Folder]')],
            outputs=[('text', 'Report Folder', 'g_txt_Report Folder'), ('text', 'Summary', 'g_txt_Summary')], goto='END')
ds = d.page('Discovery', 'Sub-page: one action call.')
ds.add_input('text', 'Root Folder'); ds.add_output('text', 'Report Folder'); ds.add_output('text', 'Summary')
# Second discovery (2026-11-05): the keyword list aimed at the work queue item and the application model element.
# Empty = DiscoverCore's default list (the first run). Edit here and regenerate for another targeted run.
ds.data('txt_Keywords', 'text', initial='WorkQueue,Queue,QueueItem,WorkItem,Item,ApplicationDefinition,AppDef,Element,Step,Attribute,Identifier,AMI,Spy,Application')
ds.action('Discover Runtime', 'Radar Probe', 'Discover Runtime',
          inputs=[('text', 'Root Folder', '[Root Folder]'), ('text', 'Keywords', '[txt_Keywords]')],
          outputs=[('text', 'Report Folder', 'Report Folder'), ('text', 'Summary', 'Summary')], goto='END')
print(d.write('BPA Process - PRC000 - Radar - Discover.xml', outdir=OUT))

h = Proc('PRC000 - Radar - Probe Demo', 'process', 'Install the runtime hook, then let an uninstrumented UI object die at a Write stage and a code stage die on bad JSON. Read <root>\\<machine>\\probe_*\\probe.log afterwards.')
hm = h.page('Main', 'Install, mark, fail twice, report.')
hm.data('Radar Root Folder', 'text', exposure='Environment')
hm.data('g_txt_Probe Folder', 'text'); hm.data('g_flg_Hook Live', 'flag')
hm.data('g_txt_Result', 'text'); hm.data('g_txt_Customer Name', 'text')
hm.data('g_txt_Report', 'text'); hm.data('g_num_Seen', 'number')
hm.data('g_txt_Ex Type', 'text'); hm.data('g_txt_Ex Detail', 'text'); hm.data('g_txt_Ex Stage', 'text')
def mark(name, expr):
    hm.action(name, 'Radar Probe', 'Mark', inputs=[('text', 'Text', expr)])
hm.action('Install Probe', 'Radar Probe', 'Install Probe',
          inputs=[('text', 'Root Folder', '[Radar Root Folder]'), ('number', 'Max Screenshots', '6')],
          outputs=[('text', 'Probe Folder', 'g_txt_Probe Folder'), ('flag', 'Hook Live', 'g_flg_Hook Live')])
mark('Mark Before Transfer', lit('before Enter Transfer (Demo Bank Plain, uninstrumented, dies at Write stage)'))
hm.action('Enter Transfer', 'Demo Bank Plain', 'Enter Transfer',
          inputs=[('text', 'Account', lit('DE123')), ('text', 'Amount', lit('50,00'))],
          outputs=[('text', 'Result', 'g_txt_Result')])
mark('Mark Transfer Done', lit('Enter Transfer returned without error'))
hm.work_block('Transfer', first='Enter Transfer', last='Mark Transfer Done',
              capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
              handler=[('Mark Transfer Caught', 'Radar Probe', 'Mark',
                        [('text', 'Text', '"process caught: " & [g_txt_Ex Type] & " / " & [g_txt_Ex Detail] & " / stage " & [g_txt_Ex Stage]')])],
              then='Mark Before API')
mark('Mark Before API', lit('before Get Customer Name (Demo API, code stage dies on bad JSON)'))
hm.action('Get Customer Name', 'Demo API', 'Get Customer Name',
          inputs=[('text', 'Customer ID', lit('C1'))], outputs=[('text', 'Customer Name', 'g_txt_Customer Name')])
mark('Mark API Done', lit('Get Customer Name returned without error'))
hm.work_block('Customer', first='Get Customer Name', last='Mark API Done',
              capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
              handler=[('Mark API Caught', 'Radar Probe', 'Mark',
                        [('text', 'Text', '"process caught: " & [g_txt_Ex Type] & " / " & [g_txt_Ex Detail] & " / stage " & [g_txt_Ex Stage]')])],
              then='Probe Report')
hm.action('Probe Report', 'Radar Probe', 'Probe Report',
          outputs=[('text', 'Report', 'g_txt_Report'), ('number', 'Exceptions Seen', 'g_num_Seen')], goto='END')
print(h.write('BPA Process - PRC000 - Radar - Probe Demo.xml', outdir=OUT))
