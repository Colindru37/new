#!/usr/bin/env python3
"""bpl_unarchive.py - load Blue Prism archived sessions (*.bpl.gz) straight into SQL Server.

Pure standard library for parsing and dry runs. The database step needs ONE of:
  pyodbc   (usual on Windows; uses the "ODBC Driver 17/18 for SQL Server" or the built-in "SQL Server" driver)
  pytds    (pip install python-tds; pure Python, no driver install)

Usage:
  python bpl_unarchive.py --selftest
  python bpl_unarchive.py --src <folder> --dry-run <outdir>                       (parse only, write TSV)
  python bpl_unarchive.py --src <folder> --conn "<connstr>" [--create-tables]
                          [--from yyyyMMdd] [--to yyyyMMdd] [--batch-rows 50000] [--log <file>]

Connection string, pyodbc form:
  "Driver={ODBC Driver 17 for SQL Server};Server=host;Database=reporting;Trusted_Connection=yes"
  (pytds form: "server=host;database=reporting;user=x;password=y"  or  "server=host;database=reporting;trusted=yes")

Target tables (created by --create-tables, never touches anything else):
  bpl_session     one row per archive file (PK sessionid)
  bpl_sessionlog  one row per <entry>
Each batch of files commits in one transaction; files whose sessionid is already in bpl_session
are skipped (by the XML id, not the file name), so a crashed or repeated run resumes without
duplicates. A batch SQL rejects is reloaded file by file so the good files land and the bad one
is named in the error log.

Same tables, same rows, same TSV layout as BplUnarchive.cs (the C# original); this is a port.
"""
import sys, os, re, gzip, uuid, time, datetime

VERSION = "1.0"

# ---------- parsing ----------

WRAPPERS = ("process", "page", "object", "action")   # wrapper elements whose name="" goes onto each entry

SESSION_COLS = ["sessionid", "sessionnumber", "startdatetime", "enddatetime", "processid", "starterresourceid",
                "starteruserid", "runningresourceid", "runningosusername", "status", "starttimezoneoffset",
                "endtimezoneoffset", "startparamsxml", "sessionsource", "logversion", "sourcefile"]
LOG_COLS = ["sessionid", "seq", "startdatetime", "startoffset", "enddatetime", "endoffset", "stageid", "stagename",
            "stagetype", "result", "resulttype", "processname", "pagename", "objectname", "actionname", "attributexml"]

_DT_FORMATS = ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S")


def dt(s):
    if not s:
        return None
    for f in _DT_FORMATS:
        try:
            return datetime.datetime.strptime(s, f)
        except ValueError:
            pass
    raise ValueError("bad datetime %r" % s)


def num(s):
    return int(s) if s else None


def guid(s):
    return uuid.UUID(s) if s else None


# XML 1.0 forbids control characters, but Blue Prism results may carry them, raw or as &#x1B;
# references. The C# original parses with CheckCharacters=false; expat cannot, so both forms are
# mapped into a private-use range before parsing and mapped back after, keeping every value intact.
_CTRL = re.compile(rb"[\x00-\x08\x0b\x0c\x0e-\x1f]|&#(?:x0*1?[0-9a-fA-F]|0*[0-9]|0*[12][0-9]|0*3[01]);")
_PUA = re.compile("[\ue000-\ue01f\ue100-\ue11f]")


def _hide_ctrl(b):
    def rep(m):
        t = m.group(0)
        if t[:1] == b"&":
            v = t[2:-1]
            code = int(v[1:], 16) if v[:1] in b"xX" else int(v)
            if code > 0x1F or code in (9, 10, 13):
                return t
        else:
            code = t[0]
        # raw byte -> U+E000+code; character reference -> U+E100+code (so raw markup can keep the reference)
        return chr((0xE000 if t[:1] != b"&" else 0xE100) + code).encode("utf-8")
    return _CTRL.sub(rep, b)


def _unhide(s):
    """Attribute value: both forms become the character (what an XML parser would deliver)."""
    return None if s is None else _PUA.sub(lambda m: chr(ord(m.group(0)) & 0x1F), s)


def _unhide_markup(s):
    """Raw markup: raw bytes come back raw, references come back as &#xHH; (the .NET XmlWriter form)."""
    return _PUA.sub(lambda m: chr(ord(m.group(0)) & 0x1F) if ord(m.group(0)) < 0xE100 else "&#x%X;" % (ord(m.group(0)) & 0x1F), s)


class Stats:
    def __init__(self):
        self.files = self.skipped = self.failed = 0
        self.entries = 0
        self.unknown = {}

    def count(self, name):
        self.unknown[name] = self.unknown.get(name, 0) + 1


def parse(gz_bytes, source_file, sess, log, st):
    """Parse one archive (gzipped bytes); append 1 row to sess and N rows to log. Returns the session id."""
    import xml.parsers.expat as expat
    data = _hide_ctrl(gzip.decompress(gz_bytes))
    if data[:3] == b"\xef\xbb\xbf":
        data = data[3:]
    first_log = len(log)
    state = {"sid": None, "seq": 0, "entry": None, "depth": 0, "attr_start": -1}
    stack = []          # (element, name) innermost last; same-name nesting restores the outer name

    def name_of(el):
        for e, n in reversed(stack):
            if e == el:
                return n
        return None

    p = expat.ParserCreate("utf-8")
    p.ordered_attributes = False

    def start(tag, attrs):
        g = attrs.get
        if state["entry"] is not None:
            state["depth"] += 1
            if tag == "attributexml" and state["depth"] == 1:
                # raw inner markup, as the C# ReadInnerXml: from after this start tag to before its end tag
                i = p.CurrentByteIndex
                j = data.index(b">", i) + 1
                state["attr_start"] = j
            elif state["depth"] == 1:
                st.count("entry/" + tag)
            return
        if tag == "session-log":
            state["sid"] = uuid.UUID(g("id"))
            sess.append([state["sid"], num(g("no")), dt(g("start")), dt(g("end")), guid(g("process")),
                         guid(g("starter-resource")), guid(g("starter-user")), guid(g("running-resource")),
                         _unhide(g("running-os-user")), _unhide(g("status")), num(g("starttimezoneoffset")),
                         num(g("endtimezoneoffset")), _unhide(g("startparamsxml")), _unhide(g("sessionsource")),
                         _unhide(g("version")), source_file])
        elif tag == "session-log-entries":
            pass
        elif tag == "entry":
            state["seq"] += 1
            state["entry"] = [state["sid"], state["seq"], dt(g("start")), num(g("startoffset")), dt(g("end")),
                              num(g("endoffset")), guid(g("stageid")), _unhide(g("stagename")), _unhide(g("stagetype")),
                              _unhide(g("result")), _unhide(g("resulttype")), name_of("process"), name_of("page"),
                              name_of("object"), name_of("action"), None]
            state["depth"] = 0
        else:
            if tag not in WRAPPERS:
                st.count(tag)
            stack.append((tag, _unhide(g("name"))))

    def end(tag):
        if state["entry"] is not None:
            if state["depth"] == 0:
                log.append(state["entry"])
                state["entry"] = None
                return
            if tag == "attributexml" and state["depth"] == 1:
                raw = data[state["attr_start"]:p.CurrentByteIndex].decode("utf-8")
                # the C# reader ignores whitespace-only text nodes between elements
                state["entry"][15] = _unhide_markup(re.sub(r">\s+<", "><", raw))
            state["depth"] -= 1
            return
        if stack and stack[-1][0] == tag:
            stack.pop()

    p.StartElementHandler = start
    p.EndElementHandler = end
    p.Parse(data, True)
    if state["sid"] is None:
        raise ValueError("no <session-log> element")
    for i in range(first_log, len(log)):
        log[i][0] = state["sid"]
    return state["sid"]


# ---------- SQL ----------

CREATE_SQL = """
IF OBJECT_ID('dbo.bpl_session') IS NULL
CREATE TABLE dbo.bpl_session (
  sessionid uniqueidentifier NOT NULL PRIMARY KEY,
  sessionnumber int NULL,
  startdatetime datetime2(3) NULL,
  enddatetime datetime2(3) NULL,
  processid uniqueidentifier NULL,
  starterresourceid uniqueidentifier NULL,
  starteruserid uniqueidentifier NULL,
  runningresourceid uniqueidentifier NULL,
  runningosusername nvarchar(255) NULL,
  status nvarchar(50) NULL,
  starttimezoneoffset int NULL,
  endtimezoneoffset int NULL,
  startparamsxml nvarchar(max) NULL,
  sessionsource nvarchar(50) NULL,
  logversion nvarchar(10) NULL,
  sourcefile nvarchar(400) NOT NULL,
  loadedat datetime2(0) NOT NULL DEFAULT SYSDATETIME());
IF OBJECT_ID('dbo.bpl_sessionlog') IS NULL
CREATE TABLE dbo.bpl_sessionlog (
  sessionid uniqueidentifier NOT NULL,
  seq int NOT NULL,
  startdatetime datetime2(3) NULL,
  startoffset int NULL,
  enddatetime datetime2(3) NULL,
  endoffset int NULL,
  stageid uniqueidentifier NULL,
  stagename nvarchar(255) NULL,
  stagetype nvarchar(50) NULL,
  result nvarchar(max) NULL,
  resulttype nvarchar(50) NULL,
  processname nvarchar(255) NULL,
  pagename nvarchar(255) NULL,
  objectname nvarchar(255) NULL,
  actionname nvarchar(255) NULL,
  attributexml nvarchar(max) NULL,
  CONSTRAINT PK_bpl_sessionlog PRIMARY KEY (sessionid, seq));
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_bpl_session_start')
CREATE INDEX IX_bpl_session_start ON dbo.bpl_session (startdatetime) INCLUDE (processid, status);"""


class Db:
    """Thin DB-API wrapper: pyodbc when importable (Windows), else pytds. One connection, explicit commits."""

    def __init__(self, conn_str):
        self.kind = None
        try:
            import pyodbc
            self.c = pyodbc.connect(conn_str, autocommit=False)
            self.kind = "pyodbc"
            self.q = "?"
        except ImportError:
            try:
                # a vendored copy of python-tds next to this script works without any install
                sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
                import pytds
            except ImportError:
                sys.exit("no SQL driver: install pyodbc (pip install pyodbc) or python-tds (pip install python-tds)")
            kw = {}
            for part in conn_str.split(";"):
                if "=" in part:
                    k, v = part.split("=", 1)
                    kw[k.strip().lower()] = v.strip()
            port = 1433
            server = kw.get("server", "localhost")
            if "," in server:
                server, port = server.split(",", 1)
                port = int(port)
            self.c = pytds.connect(server=server, port=port, database=kw.get("database"), user=kw.get("user"),
                                   password=kw.get("password"), autocommit=False,
                                   use_mars=False, **({"auth": None} if kw.get("trusted", "").lower() in ("yes", "true") else {}))
            self.kind = "pytds"
            self.q = "%s"

    def exec_(self, sql):
        cur = self.c.cursor()
        for stmt in [s for s in sql.split(";\n") if s.strip()]:
            cur.execute(stmt)
        self.c.commit()

    def loaded_ids(self):
        cur = self.c.cursor()
        cur.execute("SELECT sessionid FROM dbo.bpl_session")
        ids = set()
        for (v,) in cur.fetchall():
            ids.add(v if isinstance(v, uuid.UUID) else uuid.UUID(str(v)))
        self.c.commit()
        return ids

    def _prep(self, rows):
        # uuid -> str for both drivers; datetimes pass through
        return [[str(v) if isinstance(v, uuid.UUID) else v for v in r] for r in rows]

    def bulk_load(self, sess, log):
        cur = self.c.cursor()
        try:
            if self.kind == "pyodbc":
                cur.fast_executemany = True
            for table, cols, rows in (("bpl_session", SESSION_COLS, sess), ("bpl_sessionlog", LOG_COLS, log)):
                sql = "INSERT INTO dbo.%s (%s) VALUES (%s)" % (table, ", ".join(cols), ", ".join([self.q] * len(cols)))
                rows = self._prep(rows)
                for i in range(0, len(rows), 5000):
                    cur.executemany(sql, rows[i:i + 5000])
            self.c.commit()
        except Exception:
            self.c.rollback()
            raise


# ---------- files ----------

_NAME = re.compile(r"^(\d{8}) (\S+) ([0-9a-fA-F-]{36})\.bpl\.gz$", re.I)


def name_parts(path):
    """File name 'yyyyMMdd HHmmss <sessionid>.bpl.gz' -> (day, id) or None."""
    m = _NAME.match(path.replace("\\", "/").rsplit("/", 1)[-1])
    if not m:
        return None
    try:
        return m.group(1), uuid.UUID(m.group(3))
    except ValueError:
        return None


def cell(o):
    if o is None:
        return ""
    if isinstance(o, datetime.datetime):
        return o.strftime("%Y-%m-%d %H:%M:%S.") + "%03d" % (o.microsecond // 1000)
    if isinstance(o, bool):
        return "True" if o else "False"
    return str(o).replace("\t", " ").replace("\r", " ").replace("\n", " ")


def write_tsv(outdir, batch, sess, log):
    os.makedirs(outdir, exist_ok=True)
    for name, cols, rows in (("bpl_session", SESSION_COLS, sess), ("bpl_sessionlog", LOG_COLS, log)):
        with open(os.path.join(outdir, "%s_%04d.tsv" % (name, batch)), "w", encoding="utf-8-sig", newline="") as w:
            w.write("\t".join(cols) + "\n")
            for r in rows:
                w.write("\t".join(cell(v) for v in r) + "\n")


# ---------- run ----------

def run(a):
    src, conn, dry = a.get("src"), a.get("conn"), a.get("dry-run")
    frm, to = a.get("from"), a.get("to")
    batch_rows = int(a.get("batch-rows") or 50000)
    if not src or (conn is None and dry is None):
        usage()
        return 2
    db = Db(conn) if conn is not None else None
    if db and "create-tables" in a:
        db.exec_(CREATE_SQL)
    done = db.loaded_ids() if db else set()
    st = Stats()
    files = []
    for root, _, names in os.walk(src):
        for n in names:
            f = os.path.join(root, n)
            if not n.lower().endswith(".bpl.gz"):
                continue
            p = name_parts(f)
            if p:
                day, sid = p
                if frm and day < frm:
                    continue
                if to and day > to:
                    continue
                if sid in done:
                    st.skipped += 1
                    continue
            files.append(f)
    files.sort(key=str.lower)
    print("bpl_unarchive %s: %d files to load, %d already loaded%s" % (VERSION, len(files), st.skipped, "" if not db else " (driver %s)" % db.kind))

    log_path = a.get("log") or "bpl_unarchive_errors.log"
    err = open(log_path, "a", encoding="utf-8")
    t0 = time.time()
    seen = set(done)

    def log_error(f, msg):
        err.write("%s\t%s\t%s\n" % (datetime.datetime.now().isoformat(timespec="seconds"), f, msg))
        err.flush()

    def parse_into(f, sess, log):
        s0, l0 = len(sess), len(log)
        try:
            with open(f, "rb") as h:
                sid = parse(h.read(), f, sess, log, st)
            if sid not in seen:
                seen.add(sid)
                return True
            st.skipped += 1
            log_error(f, "duplicate: session %s already loaded (skipped)" % sid)
        except Exception as ex:
            st.failed += 1
            log_error(f, "%s: %s" % (type(ex).__name__, ex))
        del sess[s0:]
        del log[l0:]
        return False

    i, batch_no = 0, 0
    while i < len(files):
        sess, log, batch_files = [], [], []
        while i < len(files) and len(log) < batch_rows:
            f = files[i]
            i += 1
            if parse_into(f, sess, log):
                batch_files.append(f)
        if not batch_files:
            continue
        batch_no += 1
        ok, entries = len(batch_files), len(log)
        if dry is not None:
            write_tsv(dry, batch_no, sess, log)
        else:
            try:
                db.bulk_load(sess, log)
            except Exception as bex:
                print("  batch %d rejected (%s); retrying its %d files one by one" % (batch_no, str(bex).splitlines()[0].strip(), ok))
                ok = entries = 0
                for f in batch_files:
                    for r in sess:
                        if r[-1] == f:
                            seen.discard(r[0])
                    s1, l1 = [], []
                    if not parse_into(f, s1, l1):
                        continue
                    try:
                        db.bulk_load(s1, l1)
                        ok += 1
                        entries += len(l1)
                    except Exception as ex:
                        st.failed += 1
                        log_error(f, "SQL rejected: %s" % str(ex).splitlines()[0].strip())
        st.files += ok
        st.entries += entries
        print("  batch %d: %d files, %d entries  (total %d/%d files, %.0fs)" % (batch_no, ok, entries, st.files, len(files), time.time() - t0))
    err.close()
    print("Done: %d files, %d entries, %d failed, %d skipped, %.0fs" % (st.files, st.entries, st.failed, st.skipped, time.time() - t0))
    if st.failed:
        print("  failures listed in %s (rerun loads only the missing ones)" % log_path)
    if st.unknown:
        print("  XML elements not mapped (send this list back):")
        for k, v in sorted(st.unknown.items(), key=lambda kv: -kv[1]):
            print("    %s x%d" % (k, v))
    return 1 if st.failed else 0


# ---------- self-test ----------

# Shape copied from a real 7.2 archive; all values are fake. Identical to the C# sample.
SAMPLE = '''<?xml version="1.0" encoding="utf-8"?>
<session-log version="1" id="11111111-2222-3333-4444-555555555555" no="7" start="2025-10-02 14:57:39.957" end="2025-10-02 14:57:46.930" process="aaaaaaaa-0000-0000-0000-000000000001" starter-resource="bbbbbbbb-0000-0000-0000-000000000001" starter-user="cccccccc-0000-0000-0000-000000000001" running-resource="bbbbbbbb-0000-0000-0000-000000000001" running-os-user="" status="Completed" starttimezoneoffset="7200" endtimezoneoffset="7200" startparamsxml="&lt;inputs&gt;&lt;input name=&quot;Account&quot; type=&quot;text&quot; value=&quot;x&quot; /&gt;&lt;/inputs&gt;" sessionsource="Enterprise">
  <session-log-entries>
    <entry start="2025-10-02 14:57:40.300" startoffset="0" stageid="00000000-0000-0000-0000-000000000000" stagename="" stagetype="Undefined" result="Created session log" resulttype="text" />
    <process name="Test Process">
      <page name="Main Page">
        <entry start="2025-10-02 14:57:40.363" startoffset="7200" end="2025-10-02 14:57:40.457" endoffset="7200" stageid="47980482-a1ae-4e41-bdea-2b88c1c423d5" stagename="Get Credentials" stagetype="SubSheet">
          <attributexml><parameters><inputs><input name="acc" type="text" value="v" /></inputs><outputs><output name="Password" type="password" value="????" /></outputs></parameters></attributexml>
        </entry>
        <entry start="2025-10-02 14:57:40.470" startoffset="7200" stageid="5bd07cbe-d779-420b-91ad-24a5f8e2fec8" stagename="Is DB or PB" stagetype="Decision" result="True" resulttype="flag" />
        <object name="Inner VBO">
          <page name="Inner Page">
            <entry start="2025-10-02 14:57:40.500" startoffset="7200" stageid="5bd07cbe-d779-420b-91ad-24a5f8e2fec9" stagename="Inner Stage" stagetype="Action" result="esc\x1b[0m" resulttype="text" />
          </page>
        </object>
        <entry start="2025-10-02 14:57:40.600" startoffset="7200" stageid="5bd07cbe-d779-420b-91ad-24a5f8e2feca" stagename="After Inner" stagetype="Decision" result="False" resulttype="flag" />
      </page>
    </process>
    <object name="Test VBO">
      <action name="Login">
        <entry start="2025-10-02 14:57:41" startoffset="7200" stageid="faa640a4-9fa1-4c90-869e-360090b6e944" stagename="Use UI" stagetype="Decision" result="False" resulttype="flag" />
      </action>
    </object>
  </session-log-entries>
</session-log>'''


def selftest():
    fails = 0

    def check(ok, what):
        nonlocal fails
        print(("  PASS " if ok else "  FAIL ") + what)
        if not ok:
            fails += 1

    raw = SAMPLE.replace("\\x1b", "\x1b").encode("utf-8")
    gz = gzip.compress(b"\xef\xbb\xbf" + raw)
    sess, log, st = [], [], Stats()
    sid = parse(gz, "x.bpl.gz", sess, log, st)
    S = dict(zip(SESSION_COLS, sess[0]))
    L = [dict(zip(LOG_COLS, r)) for r in log]
    check(sid == uuid.UUID("11111111-2222-3333-4444-555555555555"), "session id")
    check(len(sess) == 1, "1 session row")
    check(S["sessionnumber"] == 7, "session number")
    check(S["status"] == "Completed", "status")
    check(S["startdatetime"].microsecond == 957000, "start ms")
    check(S["startparamsxml"].startswith('<inputs><input name="Account"'), "startparamsxml unescaped")
    check(S["runningosusername"] == "", "empty os user kept as empty")
    check(len(log) == 6 and [r["seq"] for r in L] == [1, 2, 3, 4, 5, 6], "6 entries, seq 1..6")
    check(L[0]["processname"] is None and L[0]["pagename"] is None, "entry outside wrappers -> NULL names")
    check(L[1]["processname"] == "Test Process" and L[1]["pagename"] == "Main Page", "process/page names")
    check(L[1]["attributexml"].startswith("<parameters><inputs>") and L[1]["attributexml"].endswith("</parameters>"), "attributexml raw inner xml")
    check(L[1]["enddatetime"] is not None and L[2]["enddatetime"] is None, "end datetime present / absent")
    check(L[3]["objectname"] == "Inner VBO" and L[3]["pagename"] == "Inner Page" and L[3]["processname"] == "Test Process", "nested object inside page: inner names")
    check(L[3]["result"] == "esc\x1b[0m", "control char kept in result")
    check(L[4]["pagename"] == "Main Page" and L[4]["objectname"] is None, "outer page name restored after inner page closes")
    check(L[5]["objectname"] == "Test VBO" and L[5]["actionname"] == "Login" and L[5]["processname"] is None, "object/action names, no process")
    check(L[5]["startdatetime"] == datetime.datetime(2025, 10, 2, 14, 57, 41), "datetime without fraction")
    check(st.unknown == {}, "no unknown elements")
    p = name_parts(r"C:\x\20250101 020304 11111111-2222-3333-4444-555555555555.bpl.gz")
    check(p is not None and p[0] == "20250101" and p[1] == sid, "file name parts")
    check(name_parts("copy_of_first.bpl.gz") is None, "odd file name -> no parts (still loaded, deduped by XML id)")
    check(cell(S["startdatetime"]) == "2025-10-02 14:57:39.957" and cell(None) == "" and cell("a\tb") == "a b", "tsv cells")
    try:
        parse(gzip.compress(b"<x/>"), "y", [], [], Stats())
        check(False, "missing session-log raises")
    except ValueError:
        check(True, "missing session-log raises")
    print("SELFTEST " + ("PASS" if fails == 0 else "FAIL (%d)" % fails))
    return 0 if fails == 0 else 1


# ---------- cli ----------

def usage():
    print("bpl_unarchive " + VERSION)
    print("  --selftest")
    print("  --src <folder> --dry-run <outdir>")
    print('  --src <folder> --conn "<connstr>" [--create-tables] [--from yyyyMMdd] [--to yyyyMMdd] [--batch-rows 50000] [--log <file>]')


def main(argv):
    a = {}
    i = 0
    while i < len(argv):
        if argv[i].startswith("--"):
            k = argv[i][2:]
            if i + 1 < len(argv) and not argv[i + 1].startswith("--"):
                a[k] = argv[i + 1]
                i += 1
            else:
                a[k] = ""
        i += 1
    try:
        if "selftest" in a:
            return selftest()
        return run(a)
    except SystemExit:
        raise
    except Exception as ex:
        print("ERROR: %s: %s" % (type(ex).__name__, ex), file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
