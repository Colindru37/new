// BplUnarchive - load Blue Prism archived sessions (*.bpl.gz) straight into SQL Server.
// .NET Framework 4.8, BCL only, C# 5 (compiles with the csc.exe that ships with Windows):
//   C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /o /r:System.Data.dll BplUnarchive.cs
//
// Usage:
//   BplUnarchive --selftest
//   BplUnarchive --src <folder> --dry-run <outdir>                       (parse only, write TSV)
//   BplUnarchive --src <folder> --conn "<connstr>" [--create-tables]
//                [--from yyyyMMdd] [--to yyyyMMdd] [--parallel 4] [--batch-rows 50000]
//
// Target tables (created by --create-tables, never touches anything else):
//   bpl_session     one row per archive file (PK sessionid)
//   bpl_sessionlog  one row per <entry>
// Each batch of files commits in one transaction; files whose sessionid is already in
// bpl_session are skipped, so a crashed or repeated run resumes without duplicates.

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

public static class BplUnarchive
{
    const string Version = "1.0";

    // ---------- parsing ----------

    static readonly string[] DateFormats = { "yyyy-MM-dd HH:mm:ss.FFFFFFF", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-ddTHH:mm:ss.FFFFFFF" };

    static object Dt(string s)
    {
        if (string.IsNullOrEmpty(s)) return DBNull.Value;
        return DateTime.ParseExact(s, DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None);
    }
    static object Int(string s)
    {
        if (string.IsNullOrEmpty(s)) return DBNull.Value;
        return int.Parse(s, CultureInfo.InvariantCulture);
    }
    static object Guid_(string s)
    {
        if (string.IsNullOrEmpty(s)) return DBNull.Value;
        return new Guid(s);
    }
    static object Str(string s) { return s == null ? (object)DBNull.Value : s; }

    // Wrapper elements around <entry> whose name="" we copy onto each log row.
    static readonly string[] Wrappers = { "process", "page", "object", "action" };

    class Stats { public int Files, Skipped, Failed; public long Entries; public Dictionary<string, int> UnknownElements = new Dictionary<string, int>(); }

    // Parses one archive stream; appends 1 row to sess and N rows to log. Returns the session id.
    static Guid Parse(Stream gz, string sourceFile, DataTable sess, DataTable log, Stats st)
    {
        // CheckCharacters=false: BP results may carry control chars (&#x1B; etc) that strict XML 1.0 rejects.
        var settings = new XmlReaderSettings { IgnoreWhitespace = true, IgnoreComments = true, DtdProcessing = DtdProcessing.Prohibit, CheckCharacters = false };
        Guid sessionId = Guid.Empty;
        // Open wrapper elements, innermost last, as (element, name). Same-name nesting (a page inside an
        // object inside a page) must restore the outer name when the inner closes, so no flat dictionary.
        var stack = new List<KeyValuePair<string, string>>();
        Func<string, object> nameOf = el =>
        {
            for (int i = stack.Count - 1; i >= 0; i--) if (stack[i].Key == el) return (object)stack[i].Value ?? DBNull.Value;
            return DBNull.Value;
        };
        int seq = 0;
        int firstLogRow = log.Rows.Count;

        using (var z = new GZipStream(gz, CompressionMode.Decompress))
        using (var r = XmlReader.Create(z, settings))
        {
            while (r.Read())
            {
                if (r.NodeType == XmlNodeType.EndElement)
                {
                    if (stack.Count > 0 && stack[stack.Count - 1].Key == r.LocalName) stack.RemoveAt(stack.Count - 1);
                    continue;
                }
                if (r.NodeType != XmlNodeType.Element) continue;

                switch (r.LocalName)
                {
                    case "session-log":
                        sessionId = new Guid(r.GetAttribute("id"));
                        var s = sess.NewRow();
                        s["sessionid"] = sessionId;
                        s["sessionnumber"] = Int(r.GetAttribute("no"));
                        s["startdatetime"] = Dt(r.GetAttribute("start"));
                        s["enddatetime"] = Dt(r.GetAttribute("end"));
                        s["processid"] = Guid_(r.GetAttribute("process"));
                        s["starterresourceid"] = Guid_(r.GetAttribute("starter-resource"));
                        s["starteruserid"] = Guid_(r.GetAttribute("starter-user"));
                        s["runningresourceid"] = Guid_(r.GetAttribute("running-resource"));
                        s["runningosusername"] = Str(r.GetAttribute("running-os-user"));
                        s["status"] = Str(r.GetAttribute("status"));
                        s["starttimezoneoffset"] = Int(r.GetAttribute("starttimezoneoffset"));
                        s["endtimezoneoffset"] = Int(r.GetAttribute("endtimezoneoffset"));
                        s["startparamsxml"] = Str(r.GetAttribute("startparamsxml"));
                        s["sessionsource"] = Str(r.GetAttribute("sessionsource"));
                        s["logversion"] = Str(r.GetAttribute("version"));
                        s["sourcefile"] = sourceFile;
                        sess.Rows.Add(s);
                        break;

                    case "session-log-entries":
                        break;

                    case "entry":
                    {
                        var e = log.NewRow();
                        e["sessionid"] = sessionId;
                        e["seq"] = ++seq;
                        e["startdatetime"] = Dt(r.GetAttribute("start"));
                        e["startoffset"] = Int(r.GetAttribute("startoffset"));
                        e["enddatetime"] = Dt(r.GetAttribute("end"));
                        e["endoffset"] = Int(r.GetAttribute("endoffset"));
                        e["stageid"] = Guid_(r.GetAttribute("stageid"));
                        e["stagename"] = Str(r.GetAttribute("stagename"));
                        e["stagetype"] = Str(r.GetAttribute("stagetype"));
                        e["result"] = Str(r.GetAttribute("result"));
                        e["resulttype"] = Str(r.GetAttribute("resulttype"));
                        e["processname"] = nameOf("process");
                        e["pagename"] = nameOf("page");
                        e["objectname"] = nameOf("object");
                        e["actionname"] = nameOf("action");
                        e["attributexml"] = DBNull.Value;
                        if (!r.IsEmptyElement)
                        {
                            // children of <entry>: <attributexml> (kept raw) or anything else (counted)
                            int depth = r.Depth;
                            bool advanced = r.Read();
                            while (advanced && !(r.NodeType == XmlNodeType.EndElement && r.Depth == depth))
                            {
                                if (r.NodeType == XmlNodeType.Element && r.LocalName == "attributexml")
                                {
                                    e["attributexml"] = r.ReadInnerXml();   // leaves the reader ON the next node
                                    advanced = true;
                                    continue;
                                }
                                if (r.NodeType == XmlNodeType.Element) Count(st, "entry/" + r.LocalName);
                                advanced = r.Read();
                            }
                        }
                        log.Rows.Add(e);
                        break;
                    }

                    default:
                        if (Array.IndexOf(Wrappers, r.LocalName) < 0) Count(st, r.LocalName);
                        if (!r.IsEmptyElement) stack.Add(new KeyValuePair<string, string>(r.LocalName, r.GetAttribute("name")));
                        break;
                }
            }
        }
        if (sessionId == Guid.Empty) throw new InvalidDataException("no <session-log> element");
        // entries parsed before session-log id was known can't happen in this format, but be safe
        for (int i = firstLogRow; i < log.Rows.Count; i++) log.Rows[i]["sessionid"] = sessionId;
        return sessionId;
    }

    static void Count(Stats st, string name)
    {
        lock (st.UnknownElements)
        {
            int n; st.UnknownElements.TryGetValue(name, out n); st.UnknownElements[name] = n + 1;
        }
    }

    // ---------- tables ----------

    static DataTable NewSessionTable()
    {
        var t = new DataTable("bpl_session");
        t.Columns.Add("sessionid", typeof(Guid));
        t.Columns.Add("sessionnumber", typeof(int));
        t.Columns.Add("startdatetime", typeof(DateTime));
        t.Columns.Add("enddatetime", typeof(DateTime));
        t.Columns.Add("processid", typeof(Guid));
        t.Columns.Add("starterresourceid", typeof(Guid));
        t.Columns.Add("starteruserid", typeof(Guid));
        t.Columns.Add("runningresourceid", typeof(Guid));
        t.Columns.Add("runningosusername", typeof(string));
        t.Columns.Add("status", typeof(string));
        t.Columns.Add("starttimezoneoffset", typeof(int));
        t.Columns.Add("endtimezoneoffset", typeof(int));
        t.Columns.Add("startparamsxml", typeof(string));
        t.Columns.Add("sessionsource", typeof(string));
        t.Columns.Add("logversion", typeof(string));
        t.Columns.Add("sourcefile", typeof(string));
        return t;
    }

    static DataTable NewLogTable()
    {
        var t = new DataTable("bpl_sessionlog");
        t.Columns.Add("sessionid", typeof(Guid));
        t.Columns.Add("seq", typeof(int));
        t.Columns.Add("startdatetime", typeof(DateTime));
        t.Columns.Add("startoffset", typeof(int));
        t.Columns.Add("enddatetime", typeof(DateTime));
        t.Columns.Add("endoffset", typeof(int));
        t.Columns.Add("stageid", typeof(Guid));
        t.Columns.Add("stagename", typeof(string));
        t.Columns.Add("stagetype", typeof(string));
        t.Columns.Add("result", typeof(string));
        t.Columns.Add("resulttype", typeof(string));
        t.Columns.Add("processname", typeof(string));
        t.Columns.Add("pagename", typeof(string));
        t.Columns.Add("objectname", typeof(string));
        t.Columns.Add("actionname", typeof(string));
        t.Columns.Add("attributexml", typeof(string));
        return t;
    }

    const string CreateSql = @"
IF OBJECT_ID('dbo.bpl_session') IS NULL
CREATE TABLE dbo.bpl_session (
  sessionid uniqueidentifier NOT NULL PRIMARY KEY,
  sessionnumber int NULL,
  startdatetime datetime2(3) NULL,
  enddatetime datetime2(3) NULL,
  processid uniqueidentifier NULL,
  starterresourceid uniqueidentifier NULL,
  starteruserid uniqueidentifier NULL,
  runningresourceid uniqueidentifier NULL,
  runningosusername nvarchar(255) NULL,
  status nvarchar(50) NULL,
  starttimezoneoffset int NULL,
  endtimezoneoffset int NULL,
  startparamsxml nvarchar(max) NULL,
  sessionsource nvarchar(50) NULL,
  logversion nvarchar(10) NULL,
  sourcefile nvarchar(400) NOT NULL,
  loadedat datetime2(0) NOT NULL DEFAULT SYSDATETIME());
IF OBJECT_ID('dbo.bpl_sessionlog') IS NULL
CREATE TABLE dbo.bpl_sessionlog (
  sessionid uniqueidentifier NOT NULL,
  seq int NOT NULL,
  startdatetime datetime2(3) NULL,
  startoffset int NULL,
  enddatetime datetime2(3) NULL,
  endoffset int NULL,
  stageid uniqueidentifier NULL,
  stagename nvarchar(255) NULL,
  stagetype nvarchar(50) NULL,
  result nvarchar(max) NULL,
  resulttype nvarchar(50) NULL,
  processname nvarchar(255) NULL,
  pagename nvarchar(255) NULL,
  objectname nvarchar(255) NULL,
  actionname nvarchar(255) NULL,
  attributexml nvarchar(max) NULL,
  CONSTRAINT PK_bpl_sessionlog PRIMARY KEY (sessionid, seq));
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_bpl_session_start')
CREATE INDEX IX_bpl_session_start ON dbo.bpl_session (startdatetime) INCLUDE (processid, status);";

    // ---------- loading ----------

    static void BulkLoad(string conn, DataTable sess, DataTable log)
    {
        using (var c = new SqlConnection(conn))
        {
            c.Open();
            using (var tx = c.BeginTransaction())
            {
                foreach (var t in new[] { sess, log })
                {
                    using (var bc = new SqlBulkCopy(c, SqlBulkCopyOptions.CheckConstraints, tx))
                    {
                        bc.DestinationTableName = "dbo." + t.TableName;
                        bc.BulkCopyTimeout = 0;
                        bc.BatchSize = 10000;
                        foreach (DataColumn col in t.Columns) bc.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                        bc.WriteToServer(t);
                    }
                }
                tx.Commit();
            }
        }
    }

    static HashSet<Guid> AlreadyLoaded(string conn)
    {
        var set = new HashSet<Guid>();
        using (var c = new SqlConnection(conn))
        using (var cmd = new SqlCommand("SELECT sessionid FROM dbo.bpl_session", c))
        {
            c.Open();
            using (var rd = cmd.ExecuteReader()) while (rd.Read()) set.Add(rd.GetGuid(0));
        }
        return set;
    }

    // File name: "yyyyMMdd HHmmss <sessionid>.bpl.gz"
    static bool TryNameParts(string path, out string day, out Guid id)
    {
        day = null; id = Guid.Empty;
        var n = Path.GetFileName(path);
        if (!n.EndsWith(".bpl.gz", StringComparison.OrdinalIgnoreCase)) return false;
        var parts = n.Substring(0, n.Length - 7).Split(' ');
        if (parts.Length != 3 || parts[0].Length != 8) return false;
        day = parts[0];
        return Guid.TryParse(parts[2], out id);
    }

    static int Run(Dictionary<string, string> a)
    {
        string src = Get(a, "src"), conn = Get(a, "conn"), dry = Get(a, "dry-run");
        string from = Get(a, "from"), to = Get(a, "to");
        int par = int.Parse(Get(a, "parallel") ?? "4");
        int batchRows = int.Parse(Get(a, "batch-rows") ?? "50000");
        if (src == null || (conn == null && dry == null)) { Usage(); return 2; }

        if (conn != null && a.ContainsKey("create-tables"))
            using (var c = new SqlConnection(conn)) { c.Open(); new SqlCommand(CreateSql, c).ExecuteNonQuery(); }

        var done = conn != null ? AlreadyLoaded(conn) : new HashSet<Guid>();
        var st = new Stats();
        var files = new List<string>();
        foreach (var f in Directory.EnumerateFiles(src, "*.bpl.gz", SearchOption.AllDirectories))
        {
            string day; Guid id;
            if (TryNameParts(f, out day, out id))
            {
                if (from != null && string.CompareOrdinal(day, from) < 0) continue;
                if (to != null && string.CompareOrdinal(day, to) > 0) continue;
                if (done.Contains(id)) { st.Skipped++; continue; }
            }
            files.Add(f);
        }
        files.Sort(StringComparer.OrdinalIgnoreCase);
        Console.WriteLine("BplUnarchive " + Version + ": " + files.Count + " files to load, " + st.Skipped + " already loaded");

        // --log <file>: where failures go (default: next to the running program; the Blue Prism object passes its own)
        StreamWriter errLog = new StreamWriter(Get(a, "log") ?? "bpl_unarchive_errors.log", true, Encoding.UTF8);
        var sw = System.Diagnostics.Stopwatch.StartNew();
        int next = -1, batchNo = 0;
        object ioLock = new object();

        var seen = new HashSet<Guid>(done);     // sessionids loaded before + parsed in this run (locked)
        Action<string, string> logError = (file, msg) =>
        {
            lock (ioLock) { errLog.WriteLine(DateTime.Now.ToString("s") + "\t" + file + "\t" + msg); errLog.Flush(); }
        };
        // Parses one file into the given tables. Returns false (and leaves the tables untouched) if the
        // file is unreadable or its session was already loaded (dedupe is by the XML id, not the file name).
        Func<string, DataTable, DataTable, bool> parseInto = (file, sess, log) =>
        {
            int sRows = sess.Rows.Count, lRows = log.Rows.Count;
            try
            {
                Guid id;
                using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16))
                    id = Parse(fs, file, sess, log, st);
                bool dup; lock (seen) dup = !seen.Add(id);
                if (!dup) return true;
                Interlocked.Increment(ref st.Skipped);
                logError(file, "duplicate: session " + id + " already loaded (skipped)");
            }
            catch (Exception ex) { Interlocked.Increment(ref st.Failed); logError(file, ex.Message); }
            while (sess.Rows.Count > sRows) sess.Rows.RemoveAt(sess.Rows.Count - 1);
            while (log.Rows.Count > lRows) log.Rows.RemoveAt(log.Rows.Count - 1);
            return false;
        };

        Action worker = () =>
        {
            while (true)
            {
                var sess = NewSessionTable(); var log = NewLogTable();
                var batchFiles = new List<string>();
                while (log.Rows.Count < batchRows)
                {
                    int i = Interlocked.Increment(ref next);
                    if (i >= files.Count) break;
                    if (parseInto(files[i], sess, log)) batchFiles.Add(files[i]);
                }
                if (batchFiles.Count == 0) return;
                int b = Interlocked.Increment(ref batchNo);
                long entries = log.Rows.Count; int ok = batchFiles.Count;
                if (dry != null) WriteTsv(dry, b, sess, log);
                else
                {
                    try { BulkLoad(conn, sess, log); }
                    catch (Exception batchEx)
                    {
                        // One rejected row rolled back the whole batch: reload file by file so the good
                        // ones land and the offending file(s) get named in the error log.
                        lock (ioLock) Console.WriteLine("  batch " + b + " rejected (" + batchEx.Message.Split('\n')[0].Trim() + "); retrying its " + ok + " files one by one");
                        ok = 0; entries = 0;
                        foreach (var f in batchFiles)
                        {
                            var s1 = NewSessionTable(); var l1 = NewLogTable();
                            lock (seen) seen.Remove(GuidOfSession(sess, f));
                            if (!parseInto(f, s1, l1)) continue;
                            try { BulkLoad(conn, s1, l1); ok++; entries += l1.Rows.Count; }
                            catch (Exception ex) { Interlocked.Increment(ref st.Failed); logError(f, "SQL rejected: " + ex.Message); }
                        }
                    }
                }
                Interlocked.Add(ref st.Files, ok);
                Interlocked.Add(ref st.Entries, entries);
                lock (ioLock)
                    Console.WriteLine(string.Format("  batch {0}: {1} files, {2} entries  (total {3}/{4} files, {5:F0}s)",
                        b, ok, entries, st.Files, files.Count, sw.Elapsed.TotalSeconds));
            }
        };

        var tasks = Enumerable.Range(0, Math.Max(1, par)).Select(_ => Task.Factory.StartNew(worker, TaskCreationOptions.LongRunning)).ToArray();
        try { Task.WaitAll(tasks); }
        finally { errLog.Dispose(); }

        Console.WriteLine(string.Format("Done: {0} files, {1} entries, {2} failed, {3} skipped, {4:F0}s",
            st.Files, st.Entries, st.Failed, st.Skipped, sw.Elapsed.TotalSeconds));
        if (st.Failed > 0) Console.WriteLine("  failures listed in " + (Get(a, "log") ?? "bpl_unarchive_errors.log") + " (rerun loads only the missing ones)");
        if (st.UnknownElements.Count > 0)
        {
            Console.WriteLine("  XML elements not mapped (send this list back):");
            foreach (var kv in st.UnknownElements.OrderByDescending(k => k.Value)) Console.WriteLine("    " + kv.Key + " x" + kv.Value);
        }
        return st.Failed > 0 ? 1 : 0;
    }

    static Guid GuidOfSession(DataTable sess, string sourceFile)
    {
        foreach (DataRow r in sess.Rows) if ((string)r["sourcefile"] == sourceFile) return (Guid)r["sessionid"];
        return Guid.Empty;
    }

    static void WriteTsv(string dir, int batch, DataTable sess, DataTable log)
    {
        Directory.CreateDirectory(dir);
        foreach (var t in new[] { sess, log })
            using (var w = new StreamWriter(Path.Combine(dir, t.TableName + "_" + batch.ToString("D4") + ".tsv"), false, Encoding.UTF8))
            {
                w.WriteLine(string.Join("\t", t.Columns.Cast<DataColumn>().Select(c => c.ColumnName)));
                foreach (DataRow row in t.Rows)
                    w.WriteLine(string.Join("\t", row.ItemArray.Select(o => Cell(o))));
            }
    }

    static string Cell(object o)
    {
        if (o == null || o == DBNull.Value) return "";
        if (o is DateTime) return ((DateTime)o).ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        return o.ToString().Replace("\t", " ").Replace("\r", " ").Replace("\n", " ");
    }

    // ---------- self-test ----------

    // Shape copied from a real 7.2 archive; all values are fake.
    const string Sample = @"<?xml version=""1.0"" encoding=""utf-8""?>
<session-log version=""1"" id=""11111111-2222-3333-4444-555555555555"" no=""7"" start=""2025-10-02 14:57:39.957"" end=""2025-10-02 14:57:46.930"" process=""aaaaaaaa-0000-0000-0000-000000000001"" starter-resource=""bbbbbbbb-0000-0000-0000-000000000001"" starter-user=""cccccccc-0000-0000-0000-000000000001"" running-resource=""bbbbbbbb-0000-0000-0000-000000000001"" running-os-user="""" status=""Completed"" starttimezoneoffset=""7200"" endtimezoneoffset=""7200"" startparamsxml=""&lt;inputs&gt;&lt;input name=&quot;Account&quot; type=&quot;text&quot; value=&quot;x&quot; /&gt;&lt;/inputs&gt;"" sessionsource=""Enterprise"">
  <session-log-entries>
    <entry start=""2025-10-02 14:57:40.300"" startoffset=""0"" stageid=""00000000-0000-0000-0000-000000000000"" stagename="""" stagetype=""Undefined"" result=""Created session log"" resulttype=""text"" />
    <process name=""Test Process"">
      <page name=""Main Page"">
        <entry start=""2025-10-02 14:57:40.363"" startoffset=""7200"" end=""2025-10-02 14:57:40.457"" endoffset=""7200"" stageid=""47980482-a1ae-4e41-bdea-2b88c1c423d5"" stagename=""Get Credentials"" stagetype=""SubSheet"">
          <attributexml><parameters><inputs><input name=""acc"" type=""text"" value=""v"" /></inputs><outputs><output name=""Password"" type=""password"" value=""????"" /></outputs></parameters></attributexml>
        </entry>
        <entry start=""2025-10-02 14:57:40.470"" startoffset=""7200"" stageid=""5bd07cbe-d779-420b-91ad-24a5f8e2fec8"" stagename=""Is DB or PB"" stagetype=""Decision"" result=""True"" resulttype=""flag"" />
      </page>
    </process>
    <object name=""Test VBO"">
      <action name=""Login"">
        <entry start=""2025-10-02 14:57:41"" startoffset=""7200"" stageid=""faa640a4-9fa1-4c90-869e-360090b6e944"" stagename=""Use UI"" stagetype=""Decision"" result=""False"" resulttype=""flag"" />
      </action>
    </object>
  </session-log-entries>
</session-log>";

    static int SelfTest()
    {
        int fails = 0;
        Action<bool, string> check = (ok, what) => { Console.WriteLine((ok ? "  PASS " : "  FAIL ") + what); if (!ok) fails++; };

        var ms = new MemoryStream();
        using (var z = new GZipStream(ms, CompressionMode.Compress, true))
        {
            var bytes = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(Sample)).ToArray();
            z.Write(bytes, 0, bytes.Length);
        }
        ms.Position = 0;
        var sess = NewSessionTable(); var log = NewLogTable(); var st = new Stats();
        var id = Parse(ms, "x.bpl.gz", sess, log, st);

        check(id == new Guid("11111111-2222-3333-4444-555555555555"), "session id");
        check(sess.Rows.Count == 1, "1 session row");
        check((int)sess.Rows[0]["sessionnumber"] == 7, "session number");
        check((string)sess.Rows[0]["status"] == "Completed", "status");
        check(((DateTime)sess.Rows[0]["startdatetime"]).Millisecond == 957, "start ms");
        check(((string)sess.Rows[0]["startparamsxml"]).StartsWith("<inputs><input name=\"Account\""), "startparamsxml unescaped");
        check((string)sess.Rows[0]["runningosusername"] == "", "empty os user kept as empty");
        check(log.Rows.Count == 4, "4 log rows");
        check(log.Rows[0]["processname"] == DBNull.Value, "entry before <process> has no process");
        check((string)log.Rows[1]["processname"] == "Test Process" && (string)log.Rows[1]["pagename"] == "Main Page", "process/page names");
        check(((string)log.Rows[1]["attributexml"]).StartsWith("<parameters><inputs>"), "attributexml raw");
        check(log.Rows[1]["result"] == DBNull.Value && log.Rows[1]["enddatetime"] != DBNull.Value, "subsheet: no result, has end");
        check((string)log.Rows[2]["stagename"] == "Is DB or PB" && log.Rows[2]["attributexml"] == DBNull.Value, "entry after attributexml entry");
        check(log.Rows[3]["processname"] == DBNull.Value && log.Rows[3]["pagename"] == DBNull.Value, "names popped after </process>");
        check((string)log.Rows[3]["objectname"] == "Test VBO" && (string)log.Rows[3]["actionname"] == "Login", "object/action names");
        check(log.Rows.Cast<DataRow>().Select(r => (int)r["seq"]).SequenceEqual(new[] { 1, 2, 3, 4 }), "seq 1..4");
        check(st.UnknownElements.Count == 0, "no unknown elements");

        // Nested same-name wrappers, control chars, and a sibling element after <attributexml>.
        const string Nested = @"<?xml version=""1.0"" encoding=""utf-8""?>
<session-log version=""1"" id=""22222222-2222-3333-4444-555555555555"" no=""8"" start=""2025-10-02 14:57:39"" end=""2025-10-02 14:57:46"" status=""Completed"">
  <session-log-entries>
    <process name=""P"">
      <page name=""Outer"">
        <entry start=""2025-10-02 14:57:40"" startoffset=""0"" stageid=""47980482-a1ae-4e41-bdea-2b88c1c423d5"" stagename=""Call"" stagetype=""Action"">
          <attributexml><parameters /></attributexml><extra>x</extra>
        </entry>
        <object name=""O"">
          <action name=""A"">
            <page name=""Inner"">
              <entry start=""2025-10-02 14:57:41"" startoffset=""0"" stageid=""47980482-a1ae-4e41-bdea-2b88c1c423d6"" stagename=""Esc&#x1B;[0m"" stagetype=""Navigate"" result=""a&#x1;b"" resulttype=""text"" />
            </page>
          </action>
        </object>
        <entry start=""2025-10-02 14:57:42"" startoffset=""0"" stageid=""47980482-a1ae-4e41-bdea-2b88c1c423d7"" stagename=""After"" stagetype=""Decision"" result=""True"" resulttype=""flag"" />
      </page>
    </process>
  </session-log-entries>
</session-log>";
        var ms2 = new MemoryStream();
        using (var z = new GZipStream(ms2, CompressionMode.Compress, true)) { var by = Encoding.UTF8.GetBytes(Nested); z.Write(by, 0, by.Length); }
        ms2.Position = 0;
        var sess2 = NewSessionTable(); var log2 = NewLogTable(); var st2 = new Stats();
        Parse(ms2, "n.bpl.gz", sess2, log2, st2);
        check(log2.Rows.Count == 3, "nested: 3 rows");
        check((string)log2.Rows[0]["pagename"] == "Outer" && log2.Rows[0]["objectname"] == DBNull.Value, "nested: outer entry");
        check((string)log2.Rows[1]["pagename"] == "Inner" && (string)log2.Rows[1]["objectname"] == "O" && (string)log2.Rows[1]["actionname"] == "A"
              && (string)log2.Rows[1]["processname"] == "P", "nested: inner page inside object keeps process");
        check((string)log2.Rows[2]["pagename"] == "Outer" && log2.Rows[2]["objectname"] == DBNull.Value && log2.Rows[2]["actionname"] == DBNull.Value,
              "nested: outer page name restored after inner page closes");
        check(((string)log2.Rows[1]["stagename"]).Contains("\u001B") && ((string)log2.Rows[1]["result"]).Contains("\u0001"), "control chars accepted");
        check((string)log2.Rows[0]["attributexml"] == "<parameters />", "attributexml before sibling");
        check(st2.UnknownElements.ContainsKey("entry/extra") && st2.UnknownElements.Count == 1, "sibling after attributexml is counted, not skipped");
        check(sess2.Rows[0]["processid"] == DBNull.Value && sess2.Rows[0]["startparamsxml"] == DBNull.Value, "missing session attrs -> NULL");

        string day; Guid fid;
        check(TryNameParts(Path.Combine("a", "20190906 082910 4c8f1e4a-1a07-4ad5-9a73-1484ebf99c8d.bpl.gz"), out day, out fid)
              && day == "20190906" && fid == new Guid("4c8f1e4a-1a07-4ad5-9a73-1484ebf99c8d"), "file name parts");

        Console.WriteLine(fails == 0 ? "SELFTEST PASS" : "SELFTEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }

    // ---------- cli ----------

    static string Get(Dictionary<string, string> a, string k) { string v; return a.TryGetValue(k, out v) ? v : null; }

    static void Usage()
    {
        Console.WriteLine("BplUnarchive " + Version);
        Console.WriteLine("  --selftest");
        Console.WriteLine("  --src <folder> --dry-run <outdir>");
        Console.WriteLine("  --src <folder> --conn \"<connstr>\" [--create-tables] [--from yyyyMMdd] [--to yyyyMMdd] [--parallel 4] [--batch-rows 50000] [--log <file>]");
    }

    public static int Main(string[] args)
    {
        var a = new Dictionary<string, string>();
        for (int i = 0; i < args.Length; i++)
        {
            if (!args[i].StartsWith("--")) continue;
            string k = args[i].Substring(2);
            a[k] = (i + 1 < args.Length && !args[i + 1].StartsWith("--")) ? args[++i] : "";
        }
        try
        {
            if (a.ContainsKey("selftest")) return SelfTest();
            return Run(a);
        }
        catch (Exception ex) { Console.Error.WriteLine("ERROR: " + ex); return 3; }
    }
}
