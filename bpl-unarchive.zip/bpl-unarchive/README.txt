bpl_unarchive.py 1.0 - load Blue Prism archived sessions (*.bpl.gz) straight into SQL Server.
Plain Python 3 (3.8+), standard library only for parsing. The database step needs one of:
  pyodbc        if already installed (uses the "ODBC Driver 17/18 for SQL Server" or the built-in "SQL Server" driver)
  pytds         the folder shipped next to the script (python-tds 1.17.1, pure Python): NOTHING TO INSTALL.
                Windows login works with ...;trusted=yes  (SSPI through ctypes), or user=/password=.

1. Prove the copy:
     python bpl_unarchive.py --selftest                      -> must print SELFTEST PASS
2. Dry run, no database:
     python bpl_unarchive.py --src <archive folder> --dry-run <outdir>
   writes bpl_session_NNNN.tsv / bpl_sessionlog_NNNN.tsv
3. Live load (creates bpl_session / bpl_sessionlog once; rerunning is safe, loaded sessions are skipped):
     python bpl_unarchive.py --src <archive folder> --conn "<connstr>" --create-tables
                             [--from yyyyMMdd] [--to yyyyMMdd] [--batch-rows 50000] [--log <file>]
   connstr with pyodbc:  "Driver={ODBC Driver 17 for SQL Server};Server=host;Database=reporting;Trusted_Connection=yes"
   connstr with pytds:   "server=host;database=reporting;user=x;password=y"
   Exit code 0 = all loaded, 1 = some files failed (named in --log, default bpl_unarchive_errors.log next to
   the script), 2 = bad arguments. A batch SQL rejects is reloaded file by file so the good files land.

Same tables, same rows, same TSV layout as BplUnarchive.cs (the C# original, kept for reference).
test/ = the dev-side proof: simulate.py builds archives + truth from a .bprelease, compare.py checks a dry run
against the truth, run_py_e2e.sh loads into SQL Server (docker) and diffs the reporting query old vs new.
