USE reporting;
GO
CREATE OR ALTER VIEW dbo.rpt_monthly_new AS
SELECT CAST(s.startdatetime AS date) AS day, p.name AS process, r.name AS resource, u.username AS starter,
       COUNT(*) AS runs,
       SUM(CASE WHEN s.status = 'Completed' THEN 1 ELSE 0 END) AS completed,
       SUM(CASE WHEN s.status = 'Terminated' THEN 1 ELSE 0 END) AS terminated,
       SUM(CASE WHEN s.status = 'Stopped' THEN 1 ELSE 0 END) AS stopped,
       AVG(DATEDIFF(ms, s.startdatetime, s.enddatetime)) AS avg_ms,
       MAX(DATEDIFF(ms, s.startdatetime, s.enddatetime)) AS max_ms,
       SUM(l.entries) AS entries, SUM(l.exceptions) AS exceptions
FROM dbo.bpl_session s
JOIN dbo.BPAProcess p ON p.processid = s.processid
JOIN dbo.BPAResource r ON r.resourceid = s.runningresourceid
JOIN dbo.BPAUser u ON u.userid = s.starteruserid
CROSS APPLY (SELECT COUNT(*) AS entries,
                    SUM(CASE WHEN x.resulttype = 'text' AND x.stagename LIKE '%Exception%' THEN 1 ELSE 0 END) AS exceptions
             FROM dbo.bpl_sessionlog x WHERE x.sessionid = s.sessionid) l
GROUP BY CAST(s.startdatetime AS date), p.name, r.name, u.username;
GO
