-- Generic stand-in for the bank's reporting DB. Approximates the Blue Prism 7.x tables the OLD path
-- fills (BPASession + BPASessionLog_NonUnicode, restored one archive at a time) plus the lookups.
-- The NEW path (BplUnarchive) fills bpl_session / bpl_sessionlog instead. Both are reported on by
-- the same monthly query (rpt_monthly_old / rpt_monthly_new) and the harness diffs the two.
IF DB_ID('reporting') IS NULL CREATE DATABASE reporting;
GO
USE reporting;
GO
IF OBJECT_ID('dbo.BPASessionLog_NonUnicode') IS NOT NULL DROP TABLE dbo.BPASessionLog_NonUnicode;
IF OBJECT_ID('dbo.BPASession') IS NOT NULL DROP TABLE dbo.BPASession;
IF OBJECT_ID('dbo.BPAProcess') IS NOT NULL DROP TABLE dbo.BPAProcess;
IF OBJECT_ID('dbo.BPAResource') IS NOT NULL DROP TABLE dbo.BPAResource;
IF OBJECT_ID('dbo.BPAUser') IS NOT NULL DROP TABLE dbo.BPAUser;
IF OBJECT_ID('dbo.BPAStatus') IS NOT NULL DROP TABLE dbo.BPAStatus;
IF OBJECT_ID('dbo.bpl_sessionlog') IS NOT NULL DROP TABLE dbo.bpl_sessionlog;
IF OBJECT_ID('dbo.bpl_session') IS NOT NULL DROP TABLE dbo.bpl_session;
GO
CREATE TABLE dbo.BPAProcess (processid uniqueidentifier PRIMARY KEY, name nvarchar(255), ProcessType char(1));
CREATE TABLE dbo.BPAResource (resourceid uniqueidentifier PRIMARY KEY, name nvarchar(255));
CREATE TABLE dbo.BPAUser (userid uniqueidentifier PRIMARY KEY, username nvarchar(255));
CREATE TABLE dbo.BPAStatus (statusid int PRIMARY KEY, description nvarchar(50));
CREATE TABLE dbo.BPASession (
  sessionid uniqueidentifier PRIMARY KEY, sessionnumber int NOT NULL UNIQUE,
  startdatetime datetime2(3), enddatetime datetime2(3), processid uniqueidentifier,
  starterresourceid uniqueidentifier, starteruserid uniqueidentifier, runningresourceid uniqueidentifier,
  runningosusername nvarchar(255), statusid int, startparamsxml nvarchar(max), sessionsource nvarchar(50),
  starttimezoneoffset int, endtimezoneoffset int);
CREATE TABLE dbo.BPASessionLog_NonUnicode (
  sessionnumber int NOT NULL, seq int NOT NULL,
  stageid uniqueidentifier, stagename nvarchar(255), stagetype int, processname nvarchar(255), pagename nvarchar(255),
  objectname nvarchar(255), actionname nvarchar(255), result nvarchar(max), resulttype nvarchar(50),
  startdatetime datetime2(3), enddatetime datetime2(3), attributexml nvarchar(max),
  starttimezoneoffset int, endtimezoneoffset int, PRIMARY KEY (sessionnumber, seq));
GO
-- The "monthly reporting query", written once per path. Rows per process / resource / day:
-- runs, completed, terminated, stopped, avg + max duration, logged entries, exceptions raised.
CREATE OR ALTER VIEW dbo.rpt_monthly_old AS
SELECT CAST(s.startdatetime AS date) AS day, p.name AS process, r.name AS resource, u.username AS starter,
       COUNT(*) AS runs,
       SUM(CASE WHEN st.description = 'Completed' THEN 1 ELSE 0 END) AS completed,
       SUM(CASE WHEN st.description = 'Terminated' THEN 1 ELSE 0 END) AS terminated,
       SUM(CASE WHEN st.description = 'Stopped' THEN 1 ELSE 0 END) AS stopped,
       AVG(DATEDIFF(ms, s.startdatetime, s.enddatetime)) AS avg_ms,
       MAX(DATEDIFF(ms, s.startdatetime, s.enddatetime)) AS max_ms,
       SUM(l.entries) AS entries, SUM(l.exceptions) AS exceptions
FROM dbo.BPASession s
JOIN dbo.BPAProcess p ON p.processid = s.processid
JOIN dbo.BPAResource r ON r.resourceid = s.runningresourceid
JOIN dbo.BPAUser u ON u.userid = s.starteruserid
JOIN dbo.BPAStatus st ON st.statusid = s.statusid
CROSS APPLY (SELECT COUNT(*) AS entries,
                    SUM(CASE WHEN x.resulttype = 'text' AND x.stagename LIKE '%Exception%' THEN 1 ELSE 0 END) AS exceptions
             FROM dbo.BPASessionLog_NonUnicode x WHERE x.sessionnumber = s.sessionnumber) l
GROUP BY CAST(s.startdatetime AS date), p.name, r.name, u.username;
GO
