#!/usr/bin/env python3
"""Simulate Blue Prism session runs from a real .bprelease and emit BOTH views of each run:

  out/archive/<yyyyMMdd HHmmss sessionid>.bpl.gz   what BP's archiver writes (input to BplUnarchive)
  out/truth/BPASession.tsv, BPASessionLog.tsv       what BP's "restore into prod" would put in its tables
  out/truth/BPAProcess.tsv, BPAResource.tsv, BPAUser.tsv, BPAStatus.tsv   lookup tables

The walker follows the real stage graph (onsuccess / ontrue / onfalse / subsheet / object action),
so stage ids, names, types, pages, objects and actions are genuine. Timings, branch choices,
resources, users and statuses are random (seeded).

usage: simulate.py <file.bprelease> <outdir> [--sessions N] [--seed S] [--months M]
"""
import sys, os, gzip, random, uuid, argparse, html, datetime as dt
import xml.etree.ElementTree as ET
from xml.sax.saxutils import quoteattr as _quoteattr
import re as _re
def quoteattr(v):  # like saxutils but control chars become numeric refs, as a real XML writer emits them
    return _re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", lambda m: "&#x%X;" % ord(m.group()), _quoteattr(v))

NSR = "{http://www.blueprism.co.uk/product/release}"
NSP = "{http://www.blueprism.co.uk/product/process}"

LOGGED = {"Start", "End", "Action", "Decision", "Calculation", "MultipleCalculation", "Code",
          "Navigate", "Read", "Write", "WaitStart", "WaitEnd", "Exception", "Recover", "Resume",
          "SubSheet", "LoopStart", "LoopEnd", "ChoiceStart", "ChoiceEnd", "Alert"}
# BP stores stagetype as an int bitflag; we only need a stable mapping for the truth table.
STAGETYPE_CODE = {t: 1 << i for i, t in enumerate(sorted(LOGGED | {"Undefined"}))}
STATUS = {"Completed": 4, "Terminated": 2, "Stopped": 3}
BASE_TS = dt.datetime(2024, 1, 1)


class Proc:
    def __init__(self, el, kind):
        self.kind = kind
        self.id = el.get("id")
        inner = next(c for c in el if c.tag == NSP + "process")
        self.name = inner.get("name")
        self.stages = {s.get("stageid"): s for s in inner if s.tag == NSP + "stage"}
        self.sheets = {s.get("subsheetid"): s.findtext(NSP + "name") for s in inner if s.tag == NSP + "subsheet"}
        self.sheet_by_name = {v: k for k, v in self.sheets.items()}
        self.page_start = {}
        for s in self.stages.values():
            if s.get("type") == "Start":
                self.page_start[s.findtext(NSP + "subsheetid")] = s.get("stageid")  # None = main page

    def page_name(self, stage):
        sid = stage.findtext(NSP + "subsheetid")
        return "Main Page" if sid is None else self.sheets.get(sid, "?")


def load(path):
    root = ET.parse(path).getroot()
    procs, objs = [], {}
    for x in root.find(NSR + "contents"):
        if x.tag == NSP + "process":
            procs.append(Proc(x, "process"))
        elif x.tag == NSP + "object":
            o = Proc(x, "object"); objs[o.name] = o
    return procs, objs


class Run:
    def __init__(self, procs, objs, rnd, start):
        self.objs = objs; self.rnd = rnd
        self.entries = []          # dicts: stage, proc(Proc), wrappers [(kind,name),...]
        self.t = start
        self.status = "Completed"
        self.steps = 0
        self.proc = procs[0]

    def tick(self):
        self.t += dt.timedelta(milliseconds=self.rnd.randint(20, 1500))
        return self.t

    def log(self, proc, stage, wrappers, start, end=None, result=None, resulttype=None, attr=None):
        self.entries.append(dict(stage=stage, proc=proc, wrappers=list(wrappers), start=start, end=end,
                                 result=result, resulttype=resulttype, attr=attr))

    def walk_page(self, proc, page_sid, wrappers):
        """Walk one page from its Start; returns normally on End, raises StopRun on exception/stop."""
        cur = proc.page_start.get(page_sid)
        guard = 0
        while cur is not None:
            self.steps += 1; guard += 1
            if self.steps > 3000 or guard > 400:
                self.status = "Stopped"; raise StopRun()
            s = proc.stages.get(cur)
            if s is None: return
            t = s.get("type")
            start = self.tick()
            nxt = s.findtext(NSP + "onsuccess")
            if t == "Start":
                self.log(proc, s, wrappers, start)
            elif t == "End":
                self.log(proc, s, wrappers, start); return
            elif t == "Decision":
                v = self.rnd.random() < 0.7
                self.log(proc, s, wrappers, start, result=str(v), resulttype="flag")
                nxt = s.findtext(NSP + "ontrue") if v else s.findtext(NSP + "onfalse")
            elif t == "SubSheet":
                target = s.findtext(NSP + "processid")
                self.log(proc, s, wrappers, start, attr=self.params_xml(s))
                nxt = self.call(proc, s, nxt, lambda: self.walk_page(proc, target, wrappers))
            elif t == "Action":
                res = s.find(NSP + "resource")
                oname, aname = (res.get("object"), res.get("action")) if res is not None else (None, None)
                obj = self.objs.get(oname)
                self.log(proc, s, wrappers, start, attr=self.params_xml(s))
                if obj is not None and aname in obj.sheet_by_name:
                    nxt = self.call(proc, s, nxt, lambda: self.walk_page(obj, obj.sheet_by_name[aname], [("object", obj.name), ("action", aname)]))
                else:
                    self.unresolved.add((oname, aname))
            elif t == "Exception":
                ex = s.find(NSP + "exception")
                detail = ex.get("detail", "") if ex is not None else ""
                self.log(proc, s, wrappers, start, result=detail, resulttype="text")
                raise BpException()   # bubbles up to the nearest page with a Recover stage
            elif t == "WaitStart":
                choices = s.findall(NSP + "choices/" + NSP + "choice")
                if choices and self.rnd.random() < 0.9:
                    c = self.rnd.choice(choices)
                    self.log(proc, s, wrappers, start, result=c.findtext(NSP + "name"), resulttype="text")
                    nxt = c.findtext(NSP + "ontrue")
                else:  # timeout -> WaitEnd of the same group
                    gid = s.findtext(NSP + "groupid")
                    we = next((x for x in proc.stages.values() if x.get("type") == "WaitEnd" and x.findtext(NSP + "groupid") == gid), None)
                    self.log(proc, s, wrappers, start, result="Timeout", resulttype="text")
                    nxt = we.get("stageid") if we is not None else None
            elif t in ("Calculation", "MultipleCalculation", "Code", "Navigate", "Read", "Write",
                       "WaitEnd", "Recover", "Resume", "LoopStart", "LoopEnd", "Alert"):
                self.log(proc, s, wrappers, start, end=self.tick(), attr=self.params_xml(s) if t == "Code" else None)
            # Anchor / Data / Collection / Note / Block etc: not logged, just follow onsuccess
            cur = nxt
        # dangling link: treat as page end

    def call(self, proc, stage, nxt, fn):
        """Run a sub-page; if it throws, recover on the caller's page (Recover stage) or re-raise."""
        try:
            fn(); return nxt
        except BpException:
            page = stage.findtext(NSP + "subsheetid")
            rec = [x for x in proc.stages.values() if x.get("type") == "Recover" and x.findtext(NSP + "subsheetid") == page]
            if not rec or self.rnd.random() < 0.15: raise
            return rec[0].get("stageid")

    def params_xml(self, s):
        ins = s.findall(NSP + "inputs/" + NSP + "input"); outs = s.findall(NSP + "outputs/" + NSP + "output")
        if not ins and not outs: return None
        def p(tag, items):
            return "".join('<%s name=%s type=%s value=%s />' % (tag, quoteattr(i.get("name", "")), quoteattr(i.get("type", "text")),
                           quoteattr(self.rnd.choice(["", "ok", "12", "True", "C:\\tmp\\x.xlsx", "ä<>&\"'", "esc\x1b[0m"]))) for i in items)
        return "<parameters><inputs>%s</inputs><outputs>%s</outputs></parameters>" % (p("input", ins), p("output", outs))

    def run(self):
        self.unresolved = set()
        try:
            self.walk_page(self.proc, None, [("process", self.proc.name)])
        except StopRun:
            pass
        except BpException:
            self.status = "Terminated"
        if self.status == "Completed" and self.rnd.random() < 0.05:
            self.status = "Stopped"
        return self


class StopRun(Exception): pass
class BpException(Exception): pass


def esc(s): return html.escape(s if s is not None else "", quote=True)
def fmt(t): return t.strftime("%Y-%m-%d %H:%M:%S.") + "%03d" % (t.microsecond // 1000)
def tsv(v):
    if v is None: return ""
    if isinstance(v, dt.datetime): return fmt(v)
    return str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("bprelease"); ap.add_argument("out")
    ap.add_argument("--sessions", type=int, default=500); ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--months", type=int, default=6)
    a = ap.parse_args()
    rnd = random.Random(a.seed)
    procs, objs = load(a.bprelease)
    print("process:", procs[0].name, "| objects:", len(objs))

    resources = [(str(uuid.UUID(int=rnd.getrandbits(128))), "VM-RPA-%02d" % i) for i in range(1, 7)]
    users = [(str(uuid.UUID(int=rnd.getrandbits(128))), n) for n in ("scheduler", "ana.pop", "ion.i")]
    os.makedirs(os.path.join(a.out, "archive"), exist_ok=True)
    os.makedirs(os.path.join(a.out, "truth"), exist_ok=True)
    fs = open(os.path.join(a.out, "truth", "BPASession.tsv"), "w", encoding="utf-8", newline="\n")
    fl = open(os.path.join(a.out, "truth", "BPASessionLog.tsv"), "w", encoding="utf-8", newline="\n")
    fs.write("\t".join(["sessionid", "sessionnumber", "startdatetime", "enddatetime", "processid", "starterresourceid",
                        "starteruserid", "runningresourceid", "runningosusername", "statusid", "startparamsxml",
                        "sessionsource", "starttimezoneoffset", "endtimezoneoffset"]) + "\n")
    fl.write("\t".join(["sessionnumber", "seq", "stageid", "stagename", "stagetype", "processname", "pagename", "objectname",
                        "actionname", "result", "resulttype", "startdatetime", "enddatetime", "attributexml",
                        "starttimezoneoffset", "endtimezoneoffset"]) + "\n")

    total_entries = 0; unresolved = set(); by_status = {}
    for n in range(1, a.sessions + 1):
        start = BASE_TS + dt.timedelta(days=rnd.randint(0, 30 * a.months - 1), seconds=rnd.randint(6 * 3600, 20 * 3600))
        r = Run(procs, objs, rnd, start).run()
        unresolved |= r.unresolved
        sid = str(uuid.UUID(int=rnd.getrandbits(128)))
        res = rnd.choice(resources); usr = rnd.choice(users)
        end = r.t + dt.timedelta(milliseconds=rnd.randint(10, 900))
        tz = 7200 if 3 < start.month < 11 else 3600
        params = '<inputs><input name="Account" type="text" value="ewp001" /><input name="UI" type="flag" value="False" /></inputs>'
        by_status[r.status] = by_status.get(r.status, 0) + 1
        total_entries += len(r.entries)

        # ---- truth rows (what BP's own tables would hold after a restore)
        fs.write("\t".join(tsv(v) for v in [sid, n, start, end, r.proc.id, res[0], usr[0], res[0], "", STATUS[r.status],
                                            params, "Enterprise", tz, tz]) + "\n")
        for i, e in enumerate(r.entries, 1):
            w = dict(e["wrappers"]); s = e["stage"]
            fl.write("\t".join(tsv(v) for v in [n, i, s.get("stageid"), s.get("name"), STAGETYPE_CODE[s.get("type")],
                                                r.proc.name, e["proc"].page_name(s), w.get("object"), w.get("action"),
                                                e["result"], e["resulttype"], e["start"], e["end"], e["attr"], tz,
                                                tz if e["end"] else None]) + "\n")

        # ---- archive file (what BP's archiver writes), same shape as a real 7.2 file
        x = ['<?xml version="1.0" encoding="utf-8"?>',
             '<session-log version="1" id="%s" no="%d" start="%s" end="%s" process="%s" starter-resource="%s" starter-user="%s" '
             'running-resource="%s" running-os-user="" status="%s" starttimezoneoffset="%d" endtimezoneoffset="%d" '
             'startparamsxml="%s" sessionsource="Enterprise">' % (sid, n, fmt(start), fmt(end), r.proc.id, res[0], usr[0], res[0],
                                                                    r.status, tz, tz, esc(params)),
             '\t<session-log-entries>']
        # Nesting mirrors the call tree: an object action called from a process page sits INSIDE that
        # page (<process><page><object><action><page>...</page></action></page></process>), so the loader
        # must restore the outer page name when the inner one closes.
        open_w = []   # currently open wrapper elements [(kind,name)]
        def close_to(common):
            while len(open_w) > common:
                k, _ = open_w.pop(); x.append("\t" * (2 + len(open_w)) + "</%s>" % k)
        caller_page = None
        for e in r.entries:
            w = e["wrappers"]; pg = e["proc"].page_name(e["stage"])
            if w[0][0] == "process":
                want = [w[0], ("page", pg)]; caller_page = pg
            else:
                want = [("process", r.proc.name), ("page", caller_page or "Main Page"), w[0], w[1], ("page", pg)]
            common = 0
            while common < min(len(open_w), len(want)) and open_w[common] == want[common]: common += 1
            close_to(common)
            for k, nm in want[common:]:
                x.append("\t" * (2 + len(open_w)) + "<%s name=%s>" % (k, quoteattr(nm))); open_w.append((k, nm))
            s = e["stage"]; ind = "\t" * (2 + len(open_w))
            attrs = 'start="%s" startoffset="%d"' % (fmt(e["start"]), tz)
            if e["end"]: attrs += ' end="%s" endoffset="%d"' % (fmt(e["end"]), tz)
            attrs += ' stageid="%s" stagename=%s stagetype="%s"' % (s.get("stageid"), quoteattr(s.get("name")), s.get("type"))
            if e["result"] is not None: attrs += ' result=%s resulttype="%s"' % (quoteattr(e["result"]), e["resulttype"])
            if e["attr"]:
                x.append("%s<entry %s>\n%s\t<attributexml>%s</attributexml>\n%s</entry>" % (ind, attrs, ind, e["attr"], ind))
            else:
                x.append("%s<entry %s />" % (ind, attrs))
        close_to(0)
        x += ['\t</session-log-entries>', '</session-log>']
        name = "%s %s.bpl.gz" % (start.strftime("%Y%m%d %H%M%S"), sid)
        with gzip.open(os.path.join(a.out, "archive", name), "wb") as g:
            g.write(b"\xef\xbb\xbf" + "\r\n".join(x).encode("utf-8"))
    fs.close(); fl.close()

    with open(os.path.join(a.out, "truth", "BPAProcess.tsv"), "w") as f:
        f.write("processid\tname\tProcessType\n")
        for p in procs: f.write("%s\t%s\tP\n" % (p.id, p.name))
        for o in objs.values(): f.write("%s\t%s\tO\n" % (o.id, o.name))
    with open(os.path.join(a.out, "truth", "BPAResource.tsv"), "w") as f:
        f.write("resourceid\tname\n"); f.writelines("%s\t%s\n" % r for r in resources)
    with open(os.path.join(a.out, "truth", "BPAUser.tsv"), "w") as f:
        f.write("userid\tusername\n"); f.writelines("%s\t%s\n" % u for u in users)
    with open(os.path.join(a.out, "truth", "BPAStatus.tsv"), "w") as f:
        f.write("statusid\tdescription\n"); f.writelines("%d\t%s\n" % (v, k) for k, v in STATUS.items())
    print("sessions:", a.sessions, "entries:", total_entries, "status:", by_status)
    if unresolved: print("actions not resolved to an object page (logged as plain entries):", sorted(unresolved))


if __name__ == "__main__":
    main()
