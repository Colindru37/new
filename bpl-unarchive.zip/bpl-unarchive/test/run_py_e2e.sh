#!/usr/bin/env bash
# End-to-end: SQL Server in docker, old path (truth bulk-inserted into BPA* tables) vs new path
# (bpl_unarchive.py over the .bpl.gz archives, pytds driver), same reporting query on both, diff must be empty.
set -euo pipefail
cd "$(dirname "$0")"
PW='Bpl!Test2026'
IMG=mcr.microsoft.com/mssql/server:2022-latest
CONN="server=127.0.0.1,1433;database=reporting;user=sa;password=$PW"
SQL() { docker exec -i bpltest /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$PW" -C -b "$@"; }

if ! docker ps --format '{{.Names}}' | grep -qx bpltest; then
  docker rm -f bpltest >/dev/null 2>&1 || true
  docker run -d --name bpltest -e ACCEPT_EULA=Y -e "MSSQL_SA_PASSWORD=$PW" -p 1433:1433 "$IMG" >/dev/null
  echo "waiting for SQL Server..."
  for i in $(seq 1 60); do SQL -Q "SELECT 1" >/dev/null 2>&1 && break; sleep 2; done
fi
SQL -Q "SELECT @@VERSION" | head -2

echo "== schema"
SQL -i /dev/stdin < reporting_db.sql
rm -rf out/truth16 && mkdir out/truth16 && for f in out/truth/*.tsv; do printf "\xff\xfe" > "out/truth16/$(basename $f)"; tail -n +2 "$f" | iconv -f UTF-8 -t UTF-16LE >> "out/truth16/$(basename $f)"; done
docker rm -f bpltest >/dev/null 2>&1; docker run -d --name bpltest -e ACCEPT_EULA=Y -e "MSSQL_SA_PASSWORD=$PW" -p 1433:1433 "$IMG" >/dev/null; for i in $(seq 1 60); do SQL -Q "SELECT 1" >/dev/null 2>&1 && break; sleep 2; done
SQL -i /dev/stdin < reporting_db.sql
docker cp out/truth16 bpltest:/tmp/truth
echo "== old path: truth rows into BPA* tables"
for t in BPAProcess BPAResource BPAUser BPAStatus BPASession BPASessionLog_NonUnicode; do
  src=$t; [ "$t" = BPASessionLog_NonUnicode ] && src=BPASessionLog
  SQL -d reporting -Q "BULK INSERT dbo.$t FROM '/tmp/truth/$src.tsv' WITH (DATAFILETYPE='widechar', FIELDTERMINATOR='\t', ROWTERMINATOR='\n', KEEPNULLS)"
done
SQL -d reporting -Q "SET NOCOUNT ON; SELECT 'BPASession', COUNT(*) FROM BPASession UNION ALL SELECT 'BPASessionLog', COUNT(*) FROM BPASessionLog_NonUnicode" -h -1

echo "== new path: BplUnarchive over the archives (+ a renamed duplicate, + a file SQL must reject)"
rm -f bpl_unarchive_errors.log
rm -rf out/archive_plus && cp -r out/archive out/archive_plus
first=$(find out/archive -name "*.bpl.gz" -print -quit); cp "$first" "out/archive_plus/copy_of_first.bpl.gz"
python3 - <<'PY'
import gzip, uuid
sid = uuid.uuid4()
x = ('<?xml version="1.0"?><session-log version="1" id="%s" no="999999" start="2024-01-01 00:00:00" end="2024-01-01 00:00:01" status="Completed">'
     '<session-log-entries><process name="P"><page name="M"><entry start="2024-01-01 00:00:00" startoffset="0" stageid="%s" stagename="%s" stagetype="Action" /></page></process></session-log-entries></session-log>') % (sid, uuid.uuid4(), "X" * 300)
gzip.open("out/archive_plus/20240101 000000 %s.bpl.gz" % sid, "wb").write(x.encode())
PY
PY=${PY:-~/videos/spire/.venv/bin/python}; $PY -I ../bpl_unarchive.py --src out/archive_plus --conn "$CONN" --create-tables --batch-rows 20000 --log bpl_unarchive_errors.log || echo "(loader exit code $? as expected: 1 failure)"
echo "-- error log (expect exactly: 1 duplicate skipped, 1 SQL rejected):"; cat bpl_unarchive_errors.log
[ "$(grep -c 'duplicate' bpl_unarchive_errors.log)" = 1 ] && [ "$(grep -c 'SQL rejected' bpl_unarchive_errors.log)" = 1 ] || { echo "E2E FAIL: error log"; exit 1; }
echo "== rerun must skip everything (idempotence)"
$PY -I ../bpl_unarchive.py --src out/archive --conn "$CONN" --log bpl_unarchive_errors.log | tail -1
SQL -d reporting -Q "SET NOCOUNT ON; SELECT 'bpl_session', COUNT(*) FROM bpl_session UNION ALL SELECT 'bpl_sessionlog', COUNT(*) FROM bpl_sessionlog" -h -1

SQL -i /dev/stdin < rpt_new.sql
echo "== reporting query: old vs new"
Q() { SQL -d reporting -Q "SET NOCOUNT ON; SELECT * FROM dbo.$1 ORDER BY day, process, resource, starter" -s '|' -W -h -1; }
Q rpt_monthly_old > out/rpt_old.txt; Q rpt_monthly_new > out/rpt_new.txt
wc -l out/rpt_old.txt out/rpt_new.txt
if diff -q out/rpt_old.txt out/rpt_new.txt >/dev/null; then echo "E2E PASS: reporting output identical ($(wc -l < out/rpt_old.txt) rows)"; else echo "E2E FAIL"; diff out/rpt_old.txt out/rpt_new.txt | head -20; exit 1; fi

echo "== row-level: every log entry equal (join on sessionid+seq)"
SQL -d reporting -h -1 -W -Q "SET NOCOUNT ON;
SELECT 'missing_or_extra', COUNT(*) FROM (SELECT s.sessionnumber, l.seq FROM BPASessionLog_NonUnicode l JOIN BPASession s ON s.sessionnumber=l.sessionnumber
  FULL OUTER JOIN bpl_sessionlog n ON n.sessionid=s.sessionid AND n.seq=l.seq WHERE n.seq IS NULL OR l.seq IS NULL) d
UNION ALL
SELECT 'field_diff', COUNT(*) FROM BPASessionLog_NonUnicode l JOIN BPASession s ON s.sessionnumber=l.sessionnumber JOIN bpl_sessionlog n ON n.sessionid=s.sessionid AND n.seq=l.seq
 WHERE l.stageid<>n.stageid OR l.stagename<>n.stagename OR ISNULL(l.pagename,'')<>ISNULL(n.pagename,'') OR ISNULL(l.objectname,'')<>ISNULL(n.objectname,'')
    OR ISNULL(l.actionname,'')<>ISNULL(n.actionname,'') OR ISNULL(l.result,'')<>ISNULL(n.result,'') OR l.startdatetime<>n.startdatetime
    OR ISNULL(l.enddatetime,'19000101')<>ISNULL(n.enddatetime,'19000101') OR ISNULL(l.attributexml,'')<>ISNULL(n.attributexml,'')"
