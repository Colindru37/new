#!/usr/bin/env python3
"""Compare BplUnarchive's dry-run TSVs against the simulator's truth tables, entry by entry.
usage: compare.py <truthdir> <dryrundir>"""
import sys, csv, glob, os
csv.field_size_limit(1 << 30)

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter="\t", quoting=csv.QUOTE_NONE))

truth, dry = sys.argv[1], sys.argv[2]
ts = {r["sessionid"].lower(): r for r in read(os.path.join(truth, "BPASession.tsv"))}
num2sid = {r["sessionnumber"]: r["sessionid"].lower() for r in ts.values()}
tl = {}
for r in read(os.path.join(truth, "BPASessionLog.tsv")):
    tl.setdefault(num2sid[r["sessionnumber"]], []).append(r)

ds = {}
for f in sorted(glob.glob(os.path.join(dry, "bpl_session_*.tsv"))):
    for r in read(f): ds[r["sessionid"].lower()] = r
dl = {}
for f in sorted(glob.glob(os.path.join(dry, "bpl_sessionlog_*.tsv"))):
    for r in read(f): dl.setdefault(r["sessionid"].lower(), []).append(r)
for v in dl.values(): v.sort(key=lambda r: int(r["seq"]))

bad = 0
def fail(msg):
    global bad; bad += 1
    if bad <= 15: print("  MISMATCH", msg)

if set(ts) != set(ds): fail("session sets differ: truth=%d loaded=%d" % (len(ts), len(ds)))
SESS_FIELDS = ["sessionnumber", "startdatetime", "enddatetime", "processid", "starterresourceid", "starteruserid",
               "runningresourceid", "runningosusername", "startparamsxml", "sessionsource", "starttimezoneoffset", "endtimezoneoffset"]
LOG_FIELDS = ["stageid", "stagename", "processname", "pagename", "objectname", "actionname", "result", "resulttype",
              "startdatetime", "enddatetime", "attributexml"]
entries = 0
for sid in ts:
    if sid not in ds: continue
    for k in SESS_FIELDS:
        if ts[sid][k].lower() != ds[sid][k].lower(): fail("%s %s: %r vs %r" % (sid[:8], k, ts[sid][k], ds[sid][k]))
    a, b = tl.get(sid, []), dl.get(sid, [])
    if len(a) != len(b): fail("%s entry count %d vs %d" % (sid[:8], len(a), len(b))); continue
    for i, (x, y) in enumerate(zip(a, b)):
        entries += 1
        for k in LOG_FIELDS:
            if x[k].lower() != y[k].lower(): fail("%s entry %d %s: %r vs %r" % (sid[:8], i + 1, k, x[k], y[k]))
print("compared %d sessions, %d entries, %d mismatches" % (len(ts), entries, bad))
sys.exit(1 if bad else 0)
