# Sheriff: automatic pre-investigation of Radar incidents

A VS Code extension. It watches the Radar incident root, and for every new incident folder it:
1. exports the process/object definitions through AutomateC (export_xml.ps1), cuts the failing page and the pages it calls to one line per stage, deletes the export;
2. sends the skill (SHERIFF.md) + incident.txt + the cut definitions + the last human verdicts to GitHub Copilot through the VS Code Language Model API (your Copilot licence, nothing else installed);
3. writes `pre-investigation.md` next to incident.txt, with a Verdict block at the bottom.

When a developer fills `verdict:` (and `cause:`) in that block, the next scan copies the incident + note + verdict into `<root>\cases\`. The newest cases ride along in every later prompt. Nobody sends anything anywhere; the folder is the feedback.

## Install (VS Code with GitHub Copilot Chat signed in)
1. Extensions view > `...` > Install from VSIX > `sheriff-0.1.0.vsix`.
2. Settings (search "sheriff"):
   - `sheriff.root` = the Radar root (the folder with one subfolder per machine), e.g. `C:\Temp\Radar` or the share.
   - `sheriff.export.user` / `sheriff.export.password` (DEV) or `sheriff.export.sso`; `sheriff.export.connection` if not the default connection.
   - For a first test without AutomateC: `sheriff.export.enabled` = false and `sheriff.xmlFallbackDir` = a folder with exported XML files.
   - `sheriff.backend` = `dry` writes only `sheriff-prompt.txt` (pipeline test, no model).
3. Watch the status bar item "Sheriff: watching" and the Output channel "Sheriff" (command "Sheriff: show log").
   The first log line lists the Copilot models the API offers. "NONE" = Copilot Chat not signed in, or the org policy
   blocks extension access to models. The first real request pops a consent dialog from VS Code; accept it once.
4. Run the Radar demo; within ~10 s a notification offers to open the pre-investigation.

## Log mode (no Radar needed)
Command "Sheriff: pre-investigate a session log export". Pick a Complete or Errors Only session log exported from
Control Room (.csv or .xlsx, nothing to convert), then a variant: `log-only` (the log as the team has it), `log-xml`
(plus the exported definitions), `radar-only` / `radar-xml` (the same facts laid out like a Radar incident), or all four.
Each variant gets its own folder under `<root>\logs\<stamp>_<process>\<variant>\` with `incident.txt` (the cut:
first error, all ERROR rows with counts, run timeline with retries collapsed, the rows around the failure with their
recorded parameters), `sheriff-prompt.txt` and `pre-investigation.md`. Compare the notes with what the developer
concluded by hand; that comparison is the test of the whole idea.

Commands: scan now, pre-investigate a session log, pre-investigate a chosen folder (re-runs even if a note exists), show log, pause/resume.
Per incident, Sheriff leaves: `pre-investigation.md`, `sheriff-prompt.txt` (exactly what the model saw), and on failure `sheriff-error.txt` (delete it to retry).

## Files
- `ext/` the extension (core.js = logic without VS Code, extension.js = watcher + model call, skill/SHERIFF.md, tools/export_xml.ps1)
- `tools/build_vsix.py` packages ext/ into the .vsix (plain zip), `tools/export_xml.ps1` same script standalone
- `test/cut_test.js` self-test of the cutter and prompt against the Radar demo exports (`node test/cut_test.js`)
