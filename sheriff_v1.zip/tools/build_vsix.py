#!/usr/bin/env python3
"""Package ext/ as sheriff-<version>.vsix (a plain zip with the manifest VS Code expects). No node tooling needed."""
import json, os, sys, zipfile
here = os.path.dirname(os.path.abspath(__file__)); ext = os.path.join(here, '..', 'ext')
pkg = json.load(open(os.path.join(ext, 'package.json')))
name, ver, pub = pkg['name'], pkg['version'], pkg['publisher']
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, '..', 'release', f'{name}-{ver}.vsix')
os.makedirs(os.path.dirname(out), exist_ok=True)
manifest = f'''<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011" xmlns:d="http://schemas.microsoft.com/developer/vsx-schema-design/2011">
  <Metadata>
    <Identity Language="en-US" Id="{name}" Version="{ver}" Publisher="{pub}" />
    <DisplayName>{pkg['displayName']}</DisplayName>
    <Description xml:space="preserve">{pkg['description']}</Description>
    <Tags>blue prism,radar</Tags>
    <Categories>Other</Categories>
    <Properties>
      <Property Id="Microsoft.VisualStudio.Code.Engine" Value="{pkg['engines']['vscode']}" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionDependencies" Value="" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionPack" Value="" />
      <Property Id="Microsoft.VisualStudio.Code.ExtensionKind" Value="workspace,ui" />
      <Property Id="Microsoft.VisualStudio.Code.LocalizedLanguages" Value="" />
    </Properties>
  </Metadata>
  <Installation><InstallationTarget Id="Microsoft.VisualStudio.Code" /></Installation>
  <Dependencies />
  <Assets><Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" /></Assets>
</PackageManifest>
'''
types = '''<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="json" ContentType="application/json" />
  <Default Extension="js" ContentType="application/javascript" />
  <Default Extension="md" ContentType="text/markdown" />
  <Default Extension="ps1" ContentType="text/plain" />
  <Default Extension="vsixmanifest" ContentType="text/xml" />
</Types>
'''
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('extension.vsixmanifest', manifest)
    z.writestr('[Content_Types].xml', types)
    for dp, dn, fn in os.walk(ext):
        for f in fn:
            p = os.path.join(dp, f)
            z.write(p, 'extension/' + os.path.relpath(p, ext).replace(os.sep, '/'))
print('wrote', os.path.abspath(out), os.path.getsize(out), 'bytes')
