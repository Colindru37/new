// Sheriff log mode: turn a Blue Prism session log export (Complete or Partial/Errors Only, .csv or .xlsx)
// into the same inputs the Radar path produces: an incident text, an incident json (for the XML cut) and names to export.
// Pure node, no dependencies.
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// ---------- table readers ----------
function parseCsv(text) {
  const rows = []; let row = [], field = '', q = false;
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = ''; rows.push(row); row = [];
    } else field += c;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows.filter(r => r.some(x => x !== ''));
}

// minimal xlsx: central directory -> entries -> inflateRaw; sharedStrings + first worksheet
function unzip(buf) {
  const files = {};
  let eocd = buf.length - 22;
  while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('not a zip/xlsx file');
  const n = buf.readUInt16LE(eocd + 10); let off = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10), csize = buf.readUInt32LE(off + 20), usize = buf.readUInt32LE(off + 24);
    const nlen = buf.readUInt16LE(off + 28), elen = buf.readUInt16LE(off + 30), clen = buf.readUInt16LE(off + 32);
    const lho = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nlen);
    const lnlen = buf.readUInt16LE(lho + 26), lelen = buf.readUInt16LE(lho + 28);
    const start = lho + 30 + lnlen + lelen;
    const data = buf.slice(start, start + csize);
    files[name] = method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : null;
    if (files[name] && usize && files[name].length !== usize) { /* tolerate */ }
    off += 46 + nlen + elen + clen;
  }
  return files;
}
function xmlText(s) { return s.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&apos;/g, "'").replace(/&amp;/g, '&').replace(/_x([0-9A-Fa-f]{4})_/g, (m, h) => String.fromCharCode(parseInt(h, 16))); }
function colIndex(ref) { let n = 0; for (const ch of ref.replace(/[0-9]+$/, '')) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; }
function parseXlsx(buf) {
  const files = unzip(buf);
  const shared = [];
  const ss = files['xl/sharedStrings.xml'];
  if (ss) {
    const re = /<si>([\s\S]*?)<\/si>/g; let m;
    while ((m = re.exec(ss.toString('utf8')))) {
      const parts = []; const tre = /<t[^>]*>([\s\S]*?)<\/t>/g; let t;
      while ((t = tre.exec(m[1]))) parts.push(xmlText(t[1]));
      shared.push(parts.join(''));
    }
  }
  // first sheet by workbook order
  let sheetPath = 'xl/worksheets/sheet1.xml';
  const wb = files['xl/workbook.xml'] && files['xl/workbook.xml'].toString('utf8');
  const rels = files['xl/_rels/workbook.xml.rels'] && files['xl/_rels/workbook.xml.rels'].toString('utf8');
  if (wb && rels) {
    const rid = (/<sheet [^>]*r:id="([^"]+)"/.exec(wb) || [])[1];
    const tgt = rid && (new RegExp('Id="' + rid + '"[^>]*Target="([^"]+)"').exec(rels) || new RegExp('Target="([^"]+)"[^>]*Id="' + rid + '"').exec(rels) || [])[1];
    if (tgt) sheetPath = (tgt.startsWith('/') ? tgt.slice(1) : 'xl/' + tgt).replace(/^xl\/xl\//, 'xl/');
  }
  const sheet = files[sheetPath];
  if (!sheet) throw new Error('worksheet not found in xlsx (' + sheetPath + ')');
  const rows = [];
  const rre = /<row[^>]*>([\s\S]*?)<\/row>/g; let r;
  while ((r = rre.exec(sheet.toString('utf8')))) {
    const row = [];
    const cre = /<c r="([A-Z]+)[0-9]+"([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g; let c;
    while ((c = cre.exec(r[1]))) {
      const idx = colIndex(c[1]); const attrs = c[2] || ''; const inner = c[3] || '';
      const type = (/t="([^"]+)"/.exec(attrs) || [])[1];
      let v = '';
      if (type === 's') { const i = (/<v>([^<]*)<\/v>/.exec(inner) || [])[1]; v = shared[Number(i)] || ''; }
      else if (type === 'inlineStr') { v = (/<t[^>]*>([\s\S]*?)<\/t>/.exec(inner) || [, ''])[1]; v = xmlText(v); }
      else { v = (/<v>([^<]*)<\/v>/.exec(inner) || [, ''])[1]; v = xmlText(v); if (type === 'b') v = v === '1' ? 'TRUE' : 'FALSE'; }
      while (row.length < idx) row.push('');
      row[idx] = v;
    }
    if (row.some(x => x !== '')) rows.push(row);
  }
  return rows;
}
function readTable(file) {
  const ext = path.extname(file).toLowerCase();
  if (ext === '.xlsx' || ext === '.xlsm') return parseXlsx(fs.readFileSync(file));
  return parseCsv(fs.readFileSync(file, 'utf8'));
}

// ---------- column mapping (by header name, tolerant) ----------
const COLS = {
  logNumber: /^log\s*(number|no)/i, stageId: /^stage\s*id/i, stageName: /^stage\s*name/i, stageType: /^stage\s*type/i,
  process: /^process(\s*name)?$/i, page: /^page/i, object: /^(business\s*)?object/i, action: /^action/i,
  result: /^result$/i, resultType: /^result\s*type/i, start: /^(resource\s*)?start/i, end: /^(resource\s*)?end/i,
  direction: /^direction/i, name: /^name$/i, type: /^(data\s*)?type$/i, value: /^value/i,
};
function mapColumns(header) {
  const idx = {};
  header.forEach((h, i) => { const t = String(h || '').trim(); for (const k in COLS) if (idx[k] == null && COLS[k].test(t)) idx[k] = i; });
  if (idx.stageName == null || idx.result == null) throw new Error('not a Blue Prism session log export (no Stage Name / Result columns). Header: ' + header.join(' | '));
  return idx;
}

// ---------- cut ----------
function cutLog(table, opts) {
  opts = opts || {};
  const TRAIL = opts.trail || 80, TIMELINE = opts.timeline || 150;
  let h = 0; while (h < table.length && !/stage\s*name/i.test(table[h].join('|'))) h++;
  if (h >= table.length) throw new Error('header row with "Stage Name" not found');
  const idx = mapColumns(table[h]);
  const g = (row, k) => idx[k] == null ? '' : String(row[idx[k]] == null ? '' : row[idx[k]]).trim();
  // stage rows + parameter rows (parameter rows: no stage name, a Direction/Name/Value)
  const stages = [];
  for (let i = h + 1; i < table.length; i++) {
    const row = table[i];
    const sn = g(row, 'stageName');
    if (sn) stages.push({ i, logNumber: g(row, 'logNumber'), name: sn, type: g(row, 'stageType'), process: g(row, 'process'), page: g(row, 'page'), object: g(row, 'object'), action: g(row, 'action'), result: g(row, 'result'), resultType: g(row, 'resultType'), start: g(row, 'start'), end: g(row, 'end'), params: [] });
    else if (stages.length && (g(row, 'direction') || g(row, 'name') || g(row, 'value'))) stages[stages.length - 1].params.push({ dir: g(row, 'direction'), name: g(row, 'name'), type: g(row, 'type'), value: g(row, 'value') });
    if (sn && (g(row, 'direction') || g(row, 'value'))) stages[stages.length - 1].params.push({ dir: g(row, 'direction'), name: g(row, 'name'), type: g(row, 'type'), value: g(row, 'value') });
  }
  const full = stages.some(s => s.params.some(p => p.value !== '' || p.name !== ''));
  const isErr = s => /^ERROR\b/i.test(s.result) || /exception/i.test(s.type) && s.result;
  const errors = stages.filter(isErr);
  const process = (stages.find(s => s.process) || {}).process || '';
  const resource = '';
  // main error: first ERROR row; prefer the inner (object) one, keep the calling process stage too
  const first = errors[0] || null;
  let mainIdx = first ? stages.indexOf(first) : stages.length - 1;
  const main = stages[mainIdx] || {};
  const caller = first ? errors.slice(1).find(e => e.process && !e.object && e.result === first.result) || errors.find(e => e.process && !e.object) : null;
  const page = (caller && caller.page) || main.page || (function () { for (let k = mainIdx; k >= 0; k--) if (stages[k].process && stages[k].page) return stages[k].page; return ''; })();
  const detail = (main.result || '').replace(/^ERROR:\s*/i, '');
  const objects = [...new Set(stages.map(s => s.object).filter(Boolean))];
  // timeline: segments of (process page | object::action), consecutive repeats merged
  const segs = [];
  for (const s of stages) {
    const label = s.object ? s.object + ' :: ' + (s.action || s.page) : (s.process ? 'process page ' + (s.page || '?') : '?');
    const last = segs[segs.length - 1];
    if (last && last.label === label) { last.n++; last.end = s.end || s.start || last.end; if (isErr(s)) last.err = (last.err || 0) + 1; }
    else segs.push({ label, n: 1, start: s.start, end: s.end || s.start, err: isErr(s) ? 1 : 0 });
  }
  // merge repeating patterns of segments (retry loops): collapse runs where the same label sequence repeats
  const merged = [];
  for (let i = 0; i < segs.length;) {
    let done = false;
    for (let L = Math.min(6, Math.floor((segs.length - i) / 2)); L >= 1 && !done; L--) {
      let reps = 1;
      while (i + (reps + 1) * L <= segs.length && segs.slice(i, i + L).every((s, k) => s.label === segs[i + reps * L + k].label)) reps++;
      if (reps >= 2) {
        const block = segs.slice(i, i + L).map(s => ({ ...s }));
        for (let r = 1; r < reps; r++) for (let k = 0; k < L; k++) { block[k].n += segs[i + r * L + k].n; block[k].err += segs[i + r * L + k].err; block[k].end = segs[i + r * L + k].end; }
        merged.push({ group: true, reps, items: block, start: segs[i].start, end: segs[i + reps * L - 1].end });
        i += reps * L; done = true;
      }
    }
    if (!done) merged.push(segs[i++]);
  }
  const tl = [];
  const segLine = (s, ind) => (ind || '') + (s.start ? s.start + '  ' : '') + s.label + '  (' + s.n + ' stage' + (s.n > 1 ? 's' : '') + (s.err ? ', ' + s.err + ' ERROR' : '') + ')';
  for (const m of merged) {
    if (m.group) { tl.push('x' + m.reps + ' repeats of {  ' + (m.start ? m.start + ' .. ' + m.end : '')); for (const s of m.items) tl.push(segLine(s, '    ')); tl.push('}'); }
    else tl.push(segLine(m));
  }
  const timeline = tl.length > TIMELINE ? tl.slice(0, 30).concat(['... ' + (tl.length - 130) + ' lines omitted ...'], tl.slice(-100)) : tl;
  // trail: last TRAIL stage rows up to and including the main error (and the rows after it, up to 15, to show the recover path)
  const from = Math.max(0, mainIdx - TRAIL + 1), to = Math.min(stages.length, mainIdx + 16);
  const trail = []; const trailRows = to - from;
  for (let k = from; k < to; k++) {
    const s = stages[k];
    const where = s.object ? s.object + ' :: ' + (s.action || s.page) : (s.page ? 'page ' + s.page : '');
    let line = (s.start || '') + ' | ' + (s.logNumber ? '#' + s.logNumber + ' | ' : '') + (s.type ? s.type + ' ' : '') + s.name + (where ? ' | ' + where : '') + (s.result ? ' | ' + (isErr(s) ? '' : 'result: ') + s.result : '');
    if (k === mainIdx) line = '>>> ' + line;
    trail.push(line);
    for (const p of s.params) if (p.name || p.value) trail.push('        ' + (p.dir || '') + ' ' + p.name + (p.type ? ' [' + p.type + ']' : '') + ' = ' + p.value);
  }
  // launch-style outputs that matter later: numbers (PIDs, handles) output earlier and referenced by the error text
  const refs = [], refSeen = new Set();
  const nums = (detail.match(/\b\d{3,}\b/g) || []);
  for (const n of nums) for (const s of stages) for (const p of s.params) if (p.value === n) {
    const k = n + '|' + (s.object || s.name) + '|' + p.dir + '|' + p.name;
    if (refSeen.has(k) || refs.length >= 8) continue; refSeen.add(k);
    refs.push('value ' + n + ' in the error appears earlier as a parameter: ' + (s.start || '') + ' ' + (s.object ? s.object + ' :: ' + s.action : 'stage ' + s.name) + ' -> ' + p.dir + ' ' + p.name + ' = ' + p.value);
  }
  return { full, idx, header: table[h], stages, errors, trailRows, process, page, stage: main.name || '', object: main.object || '', action: main.action || '', detail, resultType: main.resultType || '', at: main.start || '', firstAt: (stages[0] || {}).start || '', lastAt: (stages[stages.length - 1] || {}).end || (stages[stages.length - 1] || {}).start || '', objects, timeline, trail, refs, resource, mainIdx };
}

// ---------- renderings ----------
function errorList(cut) {
  const seen = new Map();
  for (const e of cut.errors) { const k = e.result; const v = seen.get(k) || { n: 0, first: e.start, where: (e.object ? e.object + ' :: ' + e.action : 'page ' + e.page) + ' / ' + e.name }; v.n++; seen.set(k, v); }
  return [...seen].map(([k, v]) => (v.n > 1 ? 'x' + v.n + '  ' : '') + v.first + '  ' + v.where + '\n    ' + k);
}
// variant 'log': the session log as the team has it, cut; variant 'radar': the same facts in Radar's incident layout
function renderIncident(cut, variant, meta) {
  meta = meta || {};
  const L = [];
  if (variant === 'radar') {
    L.push('RADAR INCIDENT ' + (cut.at || '') + '   (DERIVED FROM A SESSION LOG, not a live Radar dump: no screenshot, no .NET hook, no data items at failure; values below are only what the log recorded)');
    L.push('process   : ' + cut.process);
    L.push('page      : ' + cut.page);
    L.push('machine   : ' + (meta.machine || 'unknown (session log export)'));
    L.push('exception : ' + (cut.resultType || 'System Exception'));
    L.push('stage     : ' + cut.stage + (cut.object ? '   (in ' + cut.object + ' :: ' + cut.action + ')' : ''));
    L.push('detail    : ' + cut.detail);
    L.push('screenshot: none (session log)');
    L.push('hook      : none (session log)');
    L.push('log       : ' + (cut.full ? 'Complete session log (parameters recorded)' : 'Errors Only / partial log (parameters NOT recorded)') + '; run ' + cut.firstAt + ' .. ' + cut.lastAt + '; ' + cut.stages.length + ' stage rows, ' + cut.errors.length + ' ERROR rows');
    L.push('');
    L.push('--- all ERROR rows (deduplicated, with counts) ---');
    L.push(...errorList(cut));
    if (cut.refs.length) { L.push(''); L.push('--- values in the error text that appeared earlier as outputs ---'); L.push(...cut.refs); }
    L.push('');
    L.push('--- data items at failure ---');
    L.push(cut.full ? '(not available from a session log; the IN/OUT parameters in the trail are the recorded values)' : '(not available: Errors Only log)');
    L.push('');
    L.push('--- run timeline (pages and object actions in order; repeats collapsed) ---');
    L.push(...cut.timeline);
    L.push('');
    L.push('--- trail (oldest first; the ' + cut.trailRows + ' stage rows around the failure; >>> marks the failing row; indented lines are the stage\'s recorded parameters) ---');
    L.push(...cut.trail);
  } else {
    L.push('SESSION LOG EXTRACT   (' + (cut.full ? 'Complete session log: parameters recorded' : 'Errors Only / partial log: parameters NOT recorded') + ')');
    L.push('file      : ' + (meta.file || ''));
    L.push('process   : ' + cut.process);
    L.push('run       : ' + cut.firstAt + ' .. ' + cut.lastAt + '  (' + cut.stages.length + ' stage rows, ' + cut.errors.length + ' ERROR rows)');
    L.push('first ERROR: ' + cut.at + '  ' + (cut.object ? cut.object + ' :: ' + cut.action : 'page ' + cut.page) + ' / ' + cut.stage);
    L.push('            ' + cut.detail);
    L.push('');
    L.push('--- all ERROR rows (deduplicated, with counts) ---');
    L.push(...errorList(cut));
    if (cut.refs.length) { L.push(''); L.push('--- values in the error text that appeared earlier as outputs ---'); L.push(...cut.refs); }
    L.push('');
    L.push('--- run timeline (pages and object actions in order; repeats collapsed) ---');
    L.push(...cut.timeline);
    L.push('');
    L.push('--- rows around the failure (oldest first; >>> marks the failing row; indented lines are recorded parameters) ---');
    L.push(...cut.trail);
  }
  return L.join('\n') + '\n';
}

// incident.json shape the XML cutter understands (process/page + objects as Info trail labels)
function incidentJson(cut, meta) {
  const trail = cut.objects.map((o, i) => ({ seq: i + 1, at: '', label: 'Info:' + o, detail: 'object seen in the session log' }));
  if (cut.object && cut.stage) trail.push({ seq: trail.length + 1, at: cut.at, label: 'Info:' + cut.object, detail: 'failing action ' + cut.action });
  return {
    at: cut.at, process: cut.process, page: cut.page, machine: (meta && meta.machine) || '', user: '',
    exception: { type: cut.resultType || 'System Exception', stage: cut.stage, detail: cut.detail },
    source: 'session-log', full_log: cut.full,
    throws: cut.object ? [{ object: cut.object, stage: cut.action || cut.page }] : [],
    data_items: {}, dropped: 0, trail,
  };
}

function safeName(s) { return String(s || '').replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_').slice(0, 60); }
function stamp(d) { d = d || new Date(); const p = n => String(n).padStart(2, '0'); return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()); }

module.exports = { parseCsv, parseXlsx, readTable, cutLog, renderIncident, incidentJson, safeName, stamp };
