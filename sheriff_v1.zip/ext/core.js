// Sheriff core: everything that does not need VS Code. Pure node, BCL only.
//   scanIncidents(root)         -> incident folders that have incident.json and no pre-investigation.md yet
//   loadIncident(folder)        -> parsed incident.json + incident.txt
//   namesToExport(incident)     -> process/object names worth exporting for this incident
//   cutXml(xml, page, opts)     -> compact text of one page (+ Main Page data items, app model elements it touches)
//   buildPrompt(skill, incident, cuts, cases) -> the single user message sent to the model
//   harvestVerdicts(root)       -> copies incident folders whose pre-investigation.md has a filled verdict into <root>/cases
//   loadCases(root, n)          -> last n harvested cases as short text for the prompt
'use strict';
const fs = require('fs');
const path = require('path');

const PRE = 'pre-investigation.md';
const BUSY = '.sheriff-busy';
const FAILED = 'sheriff-error.txt';

function listDirs(p) {
  try { return fs.readdirSync(p, { withFileTypes: true }).filter(d => d.isDirectory()).map(d => path.join(p, d.name)); }
  catch (e) { return []; }
}
function exists(p) { try { fs.accessSync(p); return true; } catch (e) { return false; } }
function readText(p) { try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; } }
function ageMs(p) { try { return Date.now() - fs.statSync(p).mtimeMs; } catch (e) { return 0; } }

// <root>/<machine>/<stamp>_<process>_<stage>/incident.json ; skip the cases folder
function scanIncidents(root, opts) {
  opts = opts || {};
  const minAgeMs = opts.minAgeMs == null ? 3000 : opts.minAgeMs;  // Radar writes txt, json, png in a row; wait for it to settle
  const out = [];
  for (const machine of listDirs(root)) {
    if (/^(cases|logs)$/i.test(path.basename(machine))) continue;
    for (const inc of listDirs(machine)) {
      const js = path.join(inc, 'incident.json');
      if (!exists(js)) continue;
      if (exists(path.join(inc, PRE)) || exists(path.join(inc, BUSY)) || exists(path.join(inc, FAILED))) continue;
      if (ageMs(js) < minAgeMs) continue;
      out.push(inc);
    }
  }
  return out.sort();
}

function loadIncident(folder) {
  const json = JSON.parse(readText(path.join(folder, 'incident.json')));
  const txt = readText(path.join(folder, 'incident.txt'));
  return { folder, json, txt };
}

// names Blue Prism knows: the incident's process/object, objects the hook saw (class name -> object name), objects from Action trail labels
function namesToExport(inc) {
  const names = new Set();
  const j = inc.json || {};
  if (j.process) names.add(j.process);
  for (const t of j.throws || []) if (t.object) names.add(String(t.object).replace(/_/g, ' '));
  for (const e of j.trail || []) {
    const m = /^(Info|page):(.+)$/.exec(e.label || '');
    if (m && m[1] === 'Info') names.add(m[2].trim());
  }
  return [...names];
}

// ---------- XML cut ----------
function attr(s, name) { const m = new RegExp(name + '="([^"]*)"').exec(s); return m ? unescapeXml(m[1]) : ''; }
function unescapeXml(s) { return s.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&apos;/g, "'").replace(/&amp;/g, '&'); }
function tag(s, name) { const m = new RegExp('<' + name + '>([\\s\\S]*?)</' + name + '>').exec(s); return m ? m[1] : ''; }

function parseBp(xml) {
  const head = /<process [^>]*>/.exec(xml);
  const name = head ? attr(head[0], 'name') : '?';
  const type = head ? attr(head[0], 'type') : '?';
  const pages = {};   // subsheetid -> name
  const reSub = /<subsheet subsheetid="([^"]+)"[^>]*>\s*<name>([^<]*)<\/name>/g;
  let m;
  while ((m = reSub.exec(xml))) pages[m[1]] = unescapeXml(m[2]);
  const stages = [];
  const reStage = /<stage stageid="([^"]+)" name="([^"]*)" type="([^"]+)">([\s\S]*?)<\/stage>/g;
  while ((m = reStage.exec(xml))) {
    const body = m[4];
    const sid = tag(body, 'subsheetid');
    stages.push({ id: m[1], name: unescapeXml(m[2]), type: m[3], page: sid ? (pages[sid] || sid) : 'Main Page', body });
  }
  const elements = {};  // id -> { name, attrs }
  const reEl = /<element name="([^"]*)">\s*<id>([^<]+)<\/id>([\s\S]*?)(?=<element name=|<\/element>\s*<\/element>|<\/appdef>)/g;
  while ((m = reEl.exec(xml))) {
    const attrs = [];
    const reA = /<attribute name="([^"]+)" inuse="True">\s*<ProcessValue[^>]*value="([^"]*)"/g;
    let a; while ((a = reA.exec(m[3]))) attrs.push(a[1] + '=' + unescapeXml(a[2]));
    elements[m[2]] = { name: unescapeXml(m[1]), attrs };
  }
  return { name, type, pages, stages, elements };
}

function stageLine(st, bp, idName) {
  const b = st.body;
  const parts = [];
  const next = tag(b, 'onsuccess'); if (next) parts.push('next=' + (idName[next] || next));
  if (st.type === 'Action') { const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b); if (r) parts.push('calls ' + unescapeXml(r[1]) + ' :: ' + unescapeXml(r[2])); }
  const inputs = [...b.matchAll(/<input [^>]*name="([^"]*)"[^>]*expr="([^"]*)"/g)].map(x => unescapeXml(x[1]) + '=' + unescapeXml(x[2]));
  if (inputs.length) parts.push('in{' + inputs.join('; ') + '}');
  const outputs = [...b.matchAll(/<output [^>]*name="([^"]*)"[^>]*stage="([^"]*)"/g)].map(x => unescapeXml(x[1]) + '->' + unescapeXml(x[2]));
  if (outputs.length) parts.push('out{' + outputs.join('; ') + '}');
  if (st.type === 'Calculation' || st.type === 'MultipleCalculation') {
    const calcs = [...b.matchAll(/<calculation expression="([^"]*)" stage="([^"]*)"/g)].map(x => unescapeXml(x[2]) + ' = ' + unescapeXml(x[1]));
    if (calcs.length) parts.push(calcs.join(' ; '));
  }
  if (st.type === 'Decision') { const d = /<decision expression="([^"]*)"/.exec(b); if (d) parts.push('if ' + unescapeXml(d[1]) + ' true=' + (idName[tag(b, 'ontrue')] || '?') + ' false=' + (idName[tag(b, 'onfalse')] || '?')); }
  if (st.type === 'Exception') { const e = /<exception [^>]*type="([^"]*)"[^>]*detail="([^"]*)"/.exec(b); if (/usecurrent="(yes|true)"/i.test(b)) parts.push('rethrow current exception'); else if (e) parts.push('throw ' + unescapeXml(e[1]) + ': ' + unescapeXml(e[2])); }
  if (st.type === 'Data') { const dt = attr(b, 'datatype') || tag(b, 'datatype'); parts.push('type=' + (dt || '?') + ' initial=' + JSON.stringify(tag(b, 'initialvalue'))); }
  for (const step of b.matchAll(/<step([^>]*)>\s*<element id="([^"]+)"[^>]*\/>\s*(?:<action><id>([^<]+)<\/id><\/action>)?/g)) {
    const el = bp.elements[step[2]], expr = attr(step[1], 'expr'), into = attr(step[1], 'stage');
    parts.push((step[3] ? step[3] + ' ' : '') + 'element "' + (el ? el.name : step[2]) + '"' + (expr ? ' expr=' + expr : '') + (into ? ' -> ' + into : '') + (el ? ' match[' + (el.attrs.length ? el.attrs.join(', ') : 'NO ATTRIBUTES') + ']' : ' (element id not in app model)'));
  }
  for (const ch of b.matchAll(/<choice [^>]*>\s*<name>([^<]*)<\/name>[\s\S]*?<element id="([^"]+)"[\s\S]*?<condition><id>([^<]+)<\/id><\/condition>/g)) {
    const el = bp.elements[ch[2]];
    parts.push('wait ' + ch[3] + ' on "' + (el ? el.name : ch[2]) + '"' + (el ? ' match[' + (el.attrs.length ? el.attrs.join(', ') : 'NO ATTRIBUTES') + ']' : ''));
  }
  const code = tag(b, 'code');
  if (code) parts.push('code:\n' + unescapeXml(code.replace(/<!\[CDATA\[|\]\]>/g, '')).trim().split('\n').map(l => '      ' + l).join('\n'));
  return '  [' + st.type + '] ' + st.name + (parts.length ? '  ' + parts.join(' | ') : '');
}

// compact text of one page of one process/object; falls back to every page when the page is unknown
function cutXml(xml, page, opts) {
  opts = opts || {};
  const bp = parseBp(xml);
  const idName = {}; for (const s of bp.stages) idName[s.id] = s.name;
  if (!page && bp.type === 'process') page = 'Main Page';
  const wanted = page && bp.stages.some(s => s.page === page) ? [page] : [...new Set(bp.stages.map(s => s.page))];
  const out = [];
  out.push('=== ' + bp.type + ' "' + bp.name + '" (' + (wanted.length === 1 ? 'page "' + wanted[0] + '"' : 'all pages; page "' + page + '" not found') + ') ===');
  if (opts.appmodel && Object.keys(bp.elements).length) {
    out.push('application model elements:');
    for (const id in bp.elements) out.push('  ' + bp.elements[id].name + ' match[' + (bp.elements[id].attrs.length ? bp.elements[id].attrs.join(', ') : 'NO ATTRIBUTES') + ']');
  }
  const globals = bp.stages.filter(s => s.type === 'Data' && s.page === 'Main Page' && !wanted.includes('Main Page'));
  if (globals.length) { out.push('Main Page data items:'); for (const g of globals) out.push(stageLine(g, bp, idName)); }
  for (const p of wanted) {
    if (wanted.length > 1) out.push('page "' + p + '":');
    for (const s of bp.stages.filter(s => s.page === p)) out.push(stageLine(s, bp, idName));
  }
  const calls = [];
  for (const s of bp.stages) if (wanted.includes(s.page) && s.type === 'Action') { const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(s.body); if (r) calls.push({ object: unescapeXml(r[1]), action: unescapeXml(r[2]) }); }
  return { text: out.join('\n'), name: bp.name, type: bp.type, calls, pages: Object.values(bp.pages) };
}

// cut everything one incident needs: the failing page, then every page it calls (depth 1), from the exports we have.
// xmlByName: { "<process or object name>": xmlText }. Returns [{text,name,type,...}] plus a note on what was missing.
function cutIncident(inc, xmlByName) {
  const j = inc.json || {};
  const cuts = [], missing = [], seen = new Set();
  const norm = n => String(n || '').trim().toLowerCase();
  const find = n => { for (const k in xmlByName) if (norm(k) === norm(n)) return xmlByName[k]; return null; };
  const want = [{ name: j.process, page: j.page || 'Main Page', appmodel: true }];
  for (const t of j.throws || []) if (t.object) want.push({ name: String(t.object).replace(/_/g, ' '), page: t.stage, appmodel: false });
  for (const e of j.trail || []) { const m = /^Info:(.+)$/.exec(e.label || ''); if (m) want.push({ name: m[1].trim(), page: 'Main Page', appmodel: false }); }
  const queue = want.filter(w => w.name);
  let depth = 0;
  while (queue.length && depth < 40) {
    depth++;
    const w = queue.shift();
    const key = norm(w.name) + '|' + norm(w.page);
    if (seen.has(key)) continue; seen.add(key);
    const xml = find(w.name);
    if (!xml) { if (!missing.includes(w.name)) missing.push(w.name); continue; }
    const c = cutXml(xml, w.page, { appmodel: w.appmodel && !seen.has(norm(w.name) + '|appmodel') });
    seen.add(norm(w.name) + '|appmodel');
    cuts.push(c);
    for (const call of c.calls) if (!/^(Radar|House Logging)$/i.test(call.object)) queue.push({ name: call.object, page: call.action, appmodel: false });
  }
  return { cuts, missing };
}

// ---------- prompt ----------
function buildPrompt(skill, inc, cuts, cases) {
  const j = inc.json || {};
  const s = [];
  s.push(skill.trim());
  s.push('\n\n# INCIDENT (Radar incident.txt, verbatim)\n```\n' + (inc.txt || JSON.stringify(j, null, 2)).trim() + '\n```');
  if (cuts && cuts.length) {
    s.push('\n# PROCESS / OBJECT DEFINITIONS (cut from the Blue Prism export; one line per stage)');
    for (const c of cuts) s.push('```\n' + c.text + '\n```');
  } else s.push('\n# PROCESS / OBJECT DEFINITIONS\n(none exported: reason below)\n' + (inc.exportNote || ''));
  if (cases && cases.length) {
    s.push('\n# PAST CASES WITH A HUMAN VERDICT (newest first; use them as examples of what tends to be the real cause here)');
    for (const c of cases) s.push('- ' + c);
  }
  s.push('\n# NOW\nWrite the pre-investigation for THIS incident in the exact output format of the skill. Cite incident/definition lines for every claim.');
  return s.join('\n');
}

// ---------- verdict harvest ----------
const VERDICT_BLOCK = '\n\n---\n## Verdict (the developer fills this after the fix; Sheriff collects it into cases/)\nverdict: \ncause: \n';

function readVerdict(preText) {
  const v = /^verdict:[ \t]*(.+)$/m.exec(preText), c = /^cause:[ \t]*(.*)$/m.exec(preText);
  if (!v || !v[1].trim()) return null;
  return { verdict: v[1].trim(), cause: c ? c[1].trim() : '' };
}

function harvestVerdicts(root) {
  const done = [];
  const casesDir = path.join(root, 'cases');
  for (const machine of listDirs(root)) {
    if (/^(cases|logs)$/i.test(path.basename(machine))) continue;
    for (const inc of listDirs(machine)) {
      const pre = path.join(inc, PRE);
      if (!exists(pre) || exists(path.join(inc, '.harvested'))) continue;
      const vd = readVerdict(readText(pre));
      if (!vd) continue;
      const dst = path.join(casesDir, path.basename(inc));
      fs.mkdirSync(dst, { recursive: true });
      for (const f of ['incident.txt', 'incident.json', PRE]) if (exists(path.join(inc, f))) fs.copyFileSync(path.join(inc, f), path.join(dst, f));
      let js = {}; try { js = JSON.parse(readText(path.join(inc, 'incident.json'))); } catch (e) { }
      const ex = js.exception || {};
      fs.writeFileSync(path.join(dst, 'case.json'), JSON.stringify({ folder: path.basename(inc), process: js.process, page: js.page, stage: ex.stage, type: ex.type, detail: ex.detail, verdict: vd.verdict, cause: vd.cause, harvested: new Date().toISOString() }, null, 2));
      fs.writeFileSync(path.join(inc, '.harvested'), new Date().toISOString());
      done.push(dst);
    }
  }
  return done;
}

function loadCases(root, n) {
  const dirs = listDirs(path.join(root, 'cases')).sort().reverse().slice(0, n || 5);
  const out = [];
  for (const d of dirs) {
    try {
      const c = JSON.parse(readText(path.join(d, 'case.json')));
      out.push(`${c.process} / ${c.page} / stage "${c.stage}": ${String(c.detail || '').slice(0, 160)} => verdict: ${c.verdict}${c.cause ? '; real cause: ' + c.cause : ''}`);
    } catch (e) { }
  }
  return out;
}

// Read every .xml / .bprelease in a folder; return { "<process or object name>": xml } for each <process ...> element found
// (a release file holds many; an export holds one). File names do not matter.
function loadXmlDir(dir) {
  const out = {}, files = [];
  let names = [];
  try { names = fs.readdirSync(dir); } catch (e) { return { xml: out, files }; }
  for (const f of names) {
    if (!/\.(xml|bprelease)$/i.test(f)) continue;
    const text = readText(path.join(dir, f));
    const re = /<process\b[^>]*\bname="([^"]*)"[^>]*>[\s\S]*?<\/process>/g; let m, n = 0;
    while ((m = re.exec(text))) { const name = unescapeXml(m[1]); if (!out[name]) { out[name] = m[0]; n++; } }
    files.push(f + ' (' + n + ')');
  }
  return { xml: out, files };
}

module.exports = { loadXmlDir, scanIncidents, loadIncident, namesToExport, parseBp, cutXml, cutIncident, buildPrompt, harvestVerdicts, loadCases, readVerdict, VERDICT_BLOCK, PRE, BUSY, FAILED };
