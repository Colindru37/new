// Sheriff sketch: draw Blue Prism pages from export XML the way Studio shows them, as one self-contained HTML
// (every page of every process/object given, SVG per page, page list, stage search, hover = stage details).
// With an incident.json (Radar) on top: failing stage red, exception path numbered, data-chain pages marked and
// their data item values written into the data boxes, last stage-log rows numbered. Pure node, no dependencies.
//
//   node sketch.js <xml|bprelease|dir>... [--incident <incident.json>] [--out <sketch.html>]
//   const { sketch } = require('./sketch'); fs.writeFileSync(f, sketch({ xml: {name: xmlText}, incident: json }));
'use strict';
const fs = require('fs'), path = require('path');
const core = require('./core');

const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unx = s => String(s || '').replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const tag = (s, n) => { const m = new RegExp('<' + n + '>([\\s\\S]*?)</' + n + '>').exec(s); return m ? m[1] : ''; };
const attr = (s, n) => { const m = new RegExp('\\b' + n + '="([^"]*)"').exec(s); return m ? unx(m[1]) : ''; };

// Studio-like palette per stage type (fill, stroke)
const LOOK = {
  Start: ['#dcedc8', '#558b2f'], End: ['#dcedc8', '#558b2f'], Action: ['#e3f2fd', '#1565c0'], SubSheet: ['#ede7f6', '#4527a0'],
  Decision: ['#fff8e1', '#f9a825'], Calculation: ['#e0f7fa', '#00838f'], MultipleCalculation: ['#e0f7fa', '#00838f'],
  Data: ['#f5f5f5', '#757575'], Collection: ['#f5f5f5', '#757575'], Note: ['#fffde7', '#c0a000'],
  Exception: ['#ffebee', '#c62828'], Recover: ['#fce4ec', '#ad1457'], Resume: ['#fce4ec', '#ad1457'],
  Code: ['#eceff1', '#37474f'], Navigate: ['#e8f5e9', '#2e7d32'], Read: ['#e8f5e9', '#2e7d32'], Write: ['#e8f5e9', '#2e7d32'],
  WaitStart: ['#fff8e1', '#f9a825'], WaitEnd: ['#fff8e1', '#f9a825'], ChoiceStart: ['#fff8e1', '#f9a825'], ChoiceEnd: ['#fff8e1', '#f9a825'],
  LoopStart: ['#f3e5f5', '#6a1b9a'], LoopEnd: ['#f3e5f5', '#6a1b9a'], Alert: ['#fff3e0', '#ef6c00'], Skill: ['#e3f2fd', '#1565c0'],
};
const DIAMOND = new Set(['Decision', 'ChoiceStart', 'WaitStart']);
const ROUND = new Set(['Start', 'End', 'LoopStart', 'LoopEnd', 'Data', 'Collection']);

function geom(body) {
  const d = /<display x="([^"]*)" y="([^"]*)"(?: w="([^"]*)")?(?: h="([^"]*)")?/.exec(body);
  if (d) return { x: +d[1] || 0, y: +d[2] || 0, w: +d[3] || 60, h: +d[4] || 30 };
  return { x: +tag(body, 'displayx') || 0, y: +tag(body, 'displayy') || 0, w: +tag(body, 'displaywidth') || 60, h: +tag(body, 'displayheight') || 30 };
}

// one-paragraph description of a stage for the tooltip
function describe(st, bp, idName) {
  const b = st.body, L = [st.type + '  ' + st.name];
  const ins = [...b.matchAll(/<input [^>]*name="([^"]*)"[^>]*expr="([^"]*)"/g)].map(m => unx(m[1]) + ' = ' + unx(m[2]));
  const outs = [...b.matchAll(/<output [^>]*name="([^"]*)"[^>]*stage="([^"]*)"/g)].map(m => unx(m[1]) + ' -> ' + unx(m[2]));
  const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b); if (r) L.push('calls ' + unx(r[1]) + ' :: ' + unx(r[2]));
  if (st.type === 'SubSheet') L.push('calls page ' + (bp.pages[tag(b, 'processid')] || '?'));
  const dec = /<decision expression="([^"]*)"/.exec(b); if (dec) L.push('if ' + unx(dec[1]));
  for (const c of b.matchAll(/<calculation expression="([^"]*)" stage="([^"]*)"/g)) L.push(unx(c[2]) + ' = ' + unx(c[1]));
  const ex = /<exception [^>]*type="([^"]*)"[^>]*detail="([^"]*)"/.exec(b); if (ex) L.push('throw ' + unx(ex[1]) + ': ' + unx(ex[2]));
  if (/usecurrent="(yes|true)"/i.test(b)) L.push('rethrow current exception');
  if (st.type === 'Data' || st.type === 'Collection') L.push('type ' + (tag(b, 'datatype') || attr(b, 'datatype') || '?') + ' initial ' + JSON.stringify(unx(tag(b, 'initialvalue'))) + (/<alwaysinit/.test(b) ? ' (always init)' : ''));
  for (const s of b.matchAll(/<step([^>]*)>\s*<element id="([^"]+)"[^>]*\/>\s*(?:<action><id>([^<]+)<\/id><\/action>)?/g)) {
    const el = bp.elements[s[2]];
    L.push((s[3] ? s[3] + ' ' : '') + 'element "' + (el ? el.name : s[2]) + '"' + (attr(s[1], 'expr') ? ' expr=' + attr(s[1], 'expr') : '') + (attr(s[1], 'stage') ? ' -> ' + attr(s[1], 'stage') : ''));
  }
  for (const ch of b.matchAll(/<choice [^>]*>\s*<name>([^<]*)<\/name>[\s\S]*?<element id="([^"]+)"[\s\S]*?<condition><id>([^<]+)<\/id><\/condition>/g)) {
    const el = bp.elements[ch[2]]; L.push('choice "' + unx(ch[1]) + '": wait ' + ch[3] + ' on "' + (el ? el.name : ch[2]) + '"');
  }
  if (ins.length) L.push('in: ' + ins.join('; '));
  if (outs.length) L.push('out: ' + outs.join('; '));
  const code = tag(b, 'code'); if (code) { const lines = unx(code.replace(/<!\[CDATA\[|\]\]>/g, '')).trim().split('\n'); L.push('code: ' + lines.slice(0, 12).join('\n      ') + (lines.length > 12 ? '\n      ... (' + lines.length + ' lines)' : '')); }
  const nar = tag(b, 'narrative'); if (nar) L.push(unx(nar));
  const nt = /<note>([\s\S]*?)<\/note>/.exec(b) || null; if (nt) L.push(unx(nt[1]));
  return L.join('\n');
}


// ---------- the properties sheet of a stage (what Studio shows when you open it) ----------
function stageInfo(st, bp, idName) {
  const b = st.body, info = { id: st.id, name: st.name, type: st.type, page: st.page, desc: unx(tag(b, 'narrative')), fields: [], tables: [], code: '' };
  const F = (k, v) => { if (v !== undefined && v !== null && String(v) !== '') info.fields.push([k, String(v)]); };
  const T = (title, cols, rows) => { if (rows.length) info.tables.push({ title, cols, rows }); };
  const ins = [...b.matchAll(/<input ([^>]*)\/>/g)].map(m => [attr(m[1], 'friendlyname') || attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'expr')]);
  const outs = [...b.matchAll(/<output ([^>]*)\/>/g)].map(m => [attr(m[1], 'friendlyname') || attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]);
  const next = tag(b, 'onsuccess').trim();
  switch (st.type) {
    case 'Action': { const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b); if (r) { F('Business Object', unx(r[1])); F('Action', unx(r[2])); } break; }
    case 'SubSheet': F('Page', bp.pages[tag(b, 'processid')] || tag(b, 'processid')); break;
    case 'Decision': { const d = /<decision expression="([^"]*)"/.exec(b); F('Expression', d ? unx(d[1]) : ''); F('Yes', idName[tag(b, 'ontrue').trim()]); F('No', idName[tag(b, 'onfalse').trim()]); break; }
    case 'Calculation': case 'MultipleCalculation': T('Calculations', ['Expression', 'Store In'], [...b.matchAll(/<calculation expression="([^"]*)" stage="([^"]*)"/g)].map(m => [unx(m[1]), unx(m[2])])); break;
    case 'Data': F('Data Type', tag(b, 'datatype') || attr(b, 'datatype')); F('Initial Value', unx(tag(b, 'initialvalue'))); F('Exposure', tag(b, 'exposure')); F('Private', /<private\s*\/>/.test(b) ? 'yes' : ''); F('Always init', /<alwaysinit\s*\/>/.test(b) ? 'yes' : ''); break;
    case 'Collection': F('Initial rows', tag(b, 'initialvalue') ? 'yes' : ''); F('Private', /<private\s*\/>/.test(b) ? 'yes' : ''); T('Fields', ['Name', 'Type', 'Description'], [...b.matchAll(/<field ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'narrative')])); break;
    case 'Exception': { const e = /<exception ([^>]*)\/>/.exec(b); if (e) { F('Type', attr(e[1], 'type')); F('Detail', attr(e[1], 'detail')); F('Use current exception', /usecurrent="(yes|true)"/i.test(e[1]) ? 'yes' : ''); F('Preserve type', /preserve="(yes|true)"/i.test(e[1]) ? 'yes' : ''); } break; }
    case 'WaitStart': case 'ChoiceStart': {
      F('Timeout', unx(tag(b, 'timeout')));
      const rows = [];
      for (const ch of b.matchAll(/<choice [^>]*>([\s\S]*?)<\/choice>/g)) {
        const c = ch[1], el = bp.elements[(/<element id="([^"]+)"/.exec(c) || [])[1]];
        rows.push([unx(tag(c, 'name')), el ? el.name : (tag(c, 'expression') ? unx(tag(c, 'expression')) : ''), tag(c, 'condition').replace(/<\/?id>/g, ''), tag(c, 'comparetype'), unx(attr(c, 'expr') || tag(c, 'expr'))]);
      }
      T('Conditions', ['Name', 'Element / Expression', 'Condition', 'Compare', 'Value'], rows); break;
    }
    case 'LoopStart': F('Collection', unx(tag(b, 'loopdata'))); break;
    case 'Note': F('Note', unx(tag(b, 'note'))); break;
    case 'Alert': F('Alert', unx(tag(b, 'alert'))); break;
  }
  if (/^(Navigate|Read|Write)$/.test(st.type)) {
    const rows = [];
    for (const s of b.matchAll(/<step([^>]*)>([\s\S]*?)<\/step>/g)) {
      const eid = (/<element id="([^"]+)"/.exec(s[2]) || [])[1], el = bp.elements[eid];
      const act = (/<action>\s*<id>([^<]+)<\/id>/.exec(s[2]) || [])[1] || '';
      const args = [...s[2].matchAll(/<arguments>[\s\S]*?<\/arguments>/g)].map(a => [...a[0].matchAll(/<argument name="([^"]*)">\s*<ProcessValue[^>]*value="([^"]*)"/g)].map(m => m[1] + '=' + unx(m[2])).join(', ')).join(' ');
      rows.push([el ? el.name : (eid || '?'), act, attr(s[1], 'expr'), attr(s[1], 'stage'), args, el ? (el.attrs.length ? el.attrs.join(', ') : 'NOT SPIED (no attributes)') : '']);
    }
    T('Steps', ['Element', 'Action', 'Value', 'Store In', 'Arguments', 'Element attributes (spy)'], rows);
  }
  if (st.type === 'Start' || st.type === 'End') {
    if (st.type === 'Start') T('Page inputs', ['Name', 'Type', 'Store In'], [...b.matchAll(/<input ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]));
    else T('Page outputs', ['Name', 'Type', 'From'], [...b.matchAll(/<output ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]));
  } else {
    T('Inputs', ['Name', 'Data Type', 'Value'], ins);
    T('Outputs', ['Name', 'Data Type', 'Store In'], outs);
  }
  const code = tag(b, 'code'); if (code) info.code = unx(code.replace(/<!\[CDATA\[|\]\]>/g, '')).trim();
  info.logging = /<loginhibit\s*\/>/.test(b) ? "Don't log this stage" : /<loginhibit onsuccess="true"/.test(b) ? 'Log only on error' : 'Logged';
  if (next && st.type !== 'Decision') info.next = idName[next] || '';
  return info;
}

// overlay for one page: { fail: Set(stageName), path: Map(stageName -> [n,...]), values: Map(dataItem -> value), log: Map(stageName -> [seq,...]), chain: bool }
function pageOverlay(ov, procName, pageName) {
  const k = (procName + '|' + pageName).toLowerCase();
  return ov && ov.pages[k] ? ov.pages[k] : null;
}

function renderPage(bp, pageName, ov) {
  const stages = bp.stages.filter(s => s.page === pageName && s.type !== 'SubSheetInfo' && s.type !== 'ProcessInfo');
  if (!stages.length) return null;
  const idName = {}; for (const s of bp.stages) idName[s.id] = s.name;
  const boxes = {}, links = [], blocks = [], groups = {};
  for (const st of stages) {
    const g = geom(st.body);
    if (st.type === 'Block') { blocks.push({ name: st.name, ...g }); continue; }
    if (st.type === 'Anchor') { g.w = g.h = 8; }
    boxes[st.id] = { st, ...g };
    if (/^(ChoiceStart|ChoiceEnd|WaitStart|WaitEnd|LoopStart|LoopEnd)$/.test(st.type)) {
      const gid = (tag(st.body, 'groupid') || '').trim();
      const grp = groups[gid] = groups[gid] || { choices: [] };
      grp[/End$/.test(st.type) ? 'end' : 'start'] = st.id;
      if (/Start$/.test(st.type) && st.type !== 'LoopStart') {
        for (const ch of st.body.matchAll(/<choice [^>]*>\s*<name>([^<]*)<\/name>[\s\S]*?<distance>([^<]*)<\/distance>[\s\S]*?<ontrue>([^<]*)<\/ontrue>/g)) grp.choices.push({ name: unx(ch[1]), dist: +ch[2] || 0, target: ch[3].trim() });
        continue;
      }
    }
    for (const t of ['onsuccess', 'ontrue', 'onfalse']) { const v = tag(st.body, t).trim(); if (v) links.push({ from: st.id, to: v, kind: t }); }
  }
  const all = Object.values(boxes);
  const xs = all.map(b => b.x - b.w / 2).concat(blocks.map(b => b.x)), xe = all.map(b => b.x + b.w / 2).concat(blocks.map(b => b.x + b.w));
  const ys = all.map(b => b.y - b.h / 2).concat(blocks.map(b => b.y)), ye = all.map(b => b.y + b.h / 2).concat(blocks.map(b => b.y + b.h));
  const pad = 40, minx = Math.min(...xs) - pad, miny = Math.min(...ys) - pad, W = Math.max(...xe) - minx + pad, H = Math.max(...ye) - miny + pad;
  const o = [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minx} ${miny} ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI, Arial, sans-serif" font-size="9">`,
    '<defs><marker id="arr" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#555"/></marker>',
    '<marker id="arrR" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#c62828"/></marker></defs>',
    `<rect x="${minx}" y="${miny}" width="${W}" height="${H}" fill="#fafafa"/>`];
  for (const b of blocks) o.push(`<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" fill="#7fb2e5" fill-opacity="0.08" stroke="#7fb2e5" stroke-dasharray="4,3"/><text x="${b.x + 4}" y="${b.y + 11}" fill="#3b6ea5" font-weight="bold">${esc(b.name)}</text>`);
  // choice / wait / loop group lines
  for (const grp of Object.values(groups)) {
    if (!grp.start || !grp.end || !boxes[grp.start] || !boxes[grp.end]) continue;
    const s = boxes[grp.start], e = boxes[grp.end];
    o.push(`<line x1="${s.x}" y1="${s.y}" x2="${e.x}" y2="${e.y}" stroke="#777" stroke-dasharray="3,2"/>`);
    const len = Math.hypot(e.x - s.x, e.y - s.y) || 1;
    for (const c of grp.choices) {
      const px = s.x + (e.x - s.x) * c.dist / len, py = s.y + (e.y - s.y) * c.dist / len, id = 'pt:' + grp.start + ':' + c.dist;
      boxes[id] = { st: { id, name: c.name, type: 'ChoicePoint', body: '' }, x: px, y: py, w: 0, h: 0 };
      links.push({ from: id, to: c.target, kind: 'ontrue', label: c.name });
    }
    if (boxes[grp.start].st.type === 'LoopStart') links.push({ from: grp.end, to: grp.start, kind: 'loop' });
  }
  const pov = ov ? pageOverlay(ov, bp.name, pageName) : null;
  const pathEdges = new Set();
  if (pov && pov.pathOrder.length > 1) for (let i = 1; i < pov.pathOrder.length; i++) pathEdges.add(pov.pathOrder[i - 1] + '>' + pov.pathOrder[i]);
  for (const l of links) {
    const a = boxes[l.from], b = boxes[l.to]; if (!a || !b) continue;
    const colour = { ontrue: '#2e7d32', onfalse: '#c62828', loop: '#6a1b9a' }[l.kind] || '#555';
    const red = pathEdges.has(a.st.name + '>' + b.st.name);
    const stroke = red ? '#c62828' : colour, sw = red ? 2.5 : 1, mk = red ? 'arrR' : 'arr';
    const dot = t => t === 'Anchor' || t === 'ChoicePoint';
    const dx = b.x - a.x, dy = b.y - a.y, horizontal = Math.abs(dx) > Math.abs(dy);
    let x1 = a.x, y1 = a.y, x2 = b.x, y2 = b.y;
    if (!dot(a.st.type)) { if (horizontal) x1 = a.x + Math.sign(dx) * a.w / 2; else y1 = a.y + Math.sign(dy || 1) * a.h / 2; }
    if (!dot(b.st.type)) { if (horizontal) x2 = b.x - Math.sign(dx) * b.w / 2; else y2 = b.y - Math.sign(dy || 1) * b.h / 2; }
    if (l.kind === 'loop' || (!horizontal && dy < 0 && Math.abs(dx) < 1)) o.push(`<path d="M${a.x + a.w / 2},${a.y} C${a.x + a.w / 2 + 50},${a.y} ${b.x + b.w / 2 + 50},${b.y} ${b.x + b.w / 2},${b.y}" fill="none" stroke="${stroke}" stroke-width="${sw}" marker-end="url(#${mk})"${l.kind === 'loop' ? ' stroke-dasharray="5,3"' : ''}/>`);
    else o.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${sw}" marker-end="url(#${mk})"/>`);
    const lab = l.label || { ontrue: 'Yes', onfalse: 'No' }[l.kind];
    if (lab && a.st.type !== 'ChoicePoint') o.push(`<text x="${(x1 + x2) / 2 + 4}" y="${(y1 + y2) / 2 - 2}" fill="${colour}" font-size="8">${esc(lab)}</text>`);
  }
  for (const b of all.concat(Object.values(boxes).filter(x => x.st.type === 'ChoicePoint'))) {
    const st = b.st, t = st.type;
    if (t === 'ChoicePoint') { o.push(`<circle cx="${b.x}" cy="${b.y}" r="4" fill="#fff59d" stroke="#666"/><text x="${b.x}" y="${b.y - 7}" text-anchor="middle" fill="#555" font-size="8">${esc(st.name)}</text>`); continue; }
    if (t === 'Anchor') { o.push(`<circle cx="${b.x}" cy="${b.y}" r="3.5" fill="#555"><title>${esc(st.name)}</title></circle>`); continue; }
    const [fill, stroke] = LOOK[t] || ['#ffffff', '#666'];
    const fail = pov && pov.fail.has(st.name), onPath = pov && pov.path.has(st.name), logSeq = pov && pov.log.get(st.name);
    const f = fail ? '#ff5252' : fill, s = fail ? '#b71c1c' : onPath ? '#c62828' : stroke, sw = fail ? 3 : onPath ? 2 : 1;
    const title = `<title>${esc(describe(st, bp, idName))}</title>`;
    o.push(`<g class="st" data-sid="${esc(st.id)}" style="cursor:pointer">`);
    if (DIAMOND.has(t)) o.push(`<polygon points="${b.x},${b.y - b.h / 2} ${b.x + b.w / 2},${b.y} ${b.x},${b.y + b.h / 2} ${b.x - b.w / 2},${b.y}" fill="${f}" stroke="${s}" stroke-width="${sw}">${title}</polygon>`);
    else o.push(`<rect x="${b.x - b.w / 2}" y="${b.y - b.h / 2}" width="${b.w}" height="${b.h}" rx="${ROUND.has(t) ? 10 : 2}" fill="${f}" stroke="${s}" stroke-width="${sw}">${title}</rect>`);
    if (t === 'SubSheet' || t === 'Collection') o.push(`<rect x="${b.x - b.w / 2 + 3}" y="${b.y - b.h / 2 + 3}" width="${b.w - 6}" height="${b.h - 6}" rx="${t === 'Collection' ? 8 : 1}" fill="none" stroke="${s}" stroke-width="0.6"/>`);
    const max = Math.max(6, Math.floor(b.w / 5.2));
    const label = st.name.length > max ? st.name.slice(0, max - 2) + '..' : st.name;
    o.push(`<text x="${b.x}" y="${b.y + 3}" text-anchor="middle" font-size="${t === 'Anchor' ? 7 : 9}"${fail ? ' fill="#fff" font-weight="bold"' : ''}>${esc(label)}</text>`);
    if (pov && (t === 'Data' || t === 'Collection') && pov.values.has(st.name)) {
      const v = String(pov.values.get(st.name)); const vv = v.length > 28 ? v.slice(0, 26) + '..' : v;
      o.push(`<text x="${b.x}" y="${b.y + b.h / 2 + 10}" text-anchor="middle" fill="#1565c0" font-size="8"><title>${esc(st.name + ' = ' + v)}</title>= ${esc(vv)}</text>`);
    }
    if (onPath) for (const [i, n] of [...pov.path.get(st.name)].entries()) o.push(`<circle cx="${b.x + b.w / 2 - 2 + i * 14}" cy="${b.y - b.h / 2 - 2}" r="7" fill="#c62828"/><text x="${b.x + b.w / 2 - 2 + i * 14}" y="${b.y - b.h / 2 + 1}" text-anchor="middle" fill="#fff" font-size="8" font-weight="bold">${n}</text>`);
    if (logSeq && logSeq.length) o.push(`<text x="${b.x - b.w / 2 - 3}" y="${b.y + 3}" text-anchor="end" fill="#777" font-size="7">#${logSeq.join(',#')}</text>`);
    o.push('</g>');
  }
  o.push('</svg>');
  return o.join('\n');
}

// Build the overlay index from a Radar incident.json: pages[proc|page] = {fail, path, pathOrder, values, log, chain}
function overlayFrom(inc) {
  if (!inc) return null;
  const pages = {}, norm = s => String(s || '').trim();
  const get = (p, g) => { const k = (norm(p) + '|' + norm(g)).toLowerCase(); return pages[k] = pages[k] || { fail: new Set(), path: new Map(), pathOrder: [], values: new Map(), log: new Map(), chain: false }; };
  const ex = inc.exception || {};
  if (inc.process && ex.stage) get(inc.process, inc.page || 'Main Page').fail.add(ex.stage);
  // throws name the object class and the stage (hook strips the generated Run_ prefix); the page is resolved in sketch()
  const throwsAt = [];
  for (const t of inc.throws || []) if (t.object && t.stage) throwsAt.push({ object: String(t.object).replace(/_/g, ' ').toLowerCase(), stage: t.stage });
  let n = 0;
  for (const e of inc.exception_path || []) if (e.process && e.page && e.stage) { n++; const p = get(e.process, e.page); if (!p.path.has(e.stage)) p.path.set(e.stage, []); p.path.get(e.stage).push(n); p.pathOrder.push(e.stage); }
  for (const c of inc.data_chain || []) {
    if (!c.process || !c.page) continue;
    const p = get(c.process, c.page); p.chain = true;
    if (c.stage) p.path.has(c.stage) || p.pathOrder.length || p.path.set(c.stage, []);
    const items = c.items || c.data_items || {};
    if (Array.isArray(items)) for (const it of items) p.values.set(it.name, it.value); else for (const k of Object.keys(items)) p.values.set(k, items[k]);
  }
  if (inc.process && inc.data_items && typeof inc.data_items === 'object') { const p = get(inc.process, inc.page || 'Main Page'); for (const k of Object.keys(inc.data_items)) if (!/^expr:/.test(k) && !p.values.has(k)) p.values.set(k, inc.data_items[k]); }
  for (const r of (inc.stage_log || []).slice(-60)) if (r.process && r.page && r.stage) { const p = get(r.process, r.page); if (!p.log.has(r.stage)) p.log.set(r.stage, []); if (p.log.get(r.stage).length < 3) p.log.get(r.stage).push(r.seq); }
  return { pages, throwsAt };
}

function sketch(opts) {
  const xml = opts.xml || {}, inc = opts.incident || null, ov = overlayFrom(inc);
  const bps = Object.keys(xml).map(k => { try { return core.parseBp(xml[k]); } catch (e) { return null; } }).filter(Boolean);
  if (ov) for (const t of ov.throwsAt) for (const bp of bps) {
    if (bp.name.toLowerCase() !== t.object) continue;
    for (const st of bp.stages) if (st.name === t.stage || st.name === 'Run ' + t.stage) pageOverlayCreate(ov, bp.name, st.page).fail.add(st.name);
  }
  const entries = [], INFO = {};
  for (const bp of bps) {
    const idName = {}; for (const st of bp.stages) idName[st.id] = st.name;
    for (const st of bp.stages) if (!/^(SubSheetInfo|ProcessInfo|Anchor|Block)$/.test(st.type)) { const i = stageInfo(st, bp, idName); i.proc = bp.name; INFO[st.id] = i; }
    const pageNames = [...new Set(bp.stages.map(s => s.page))];
    for (const pg of pageNames) {
      const svg = renderPage(bp, pg, ov); if (!svg) continue;
      const pov = ov ? pageOverlay(ov, bp.name, pg) : null;
      entries.push({ proc: bp.name, type: bp.type, page: pg, svg, mark: pov ? (pov.fail.size ? 'fail' : pov.path.size || pov.chain ? 'path' : '') : '' });
    }
  }
  const order = { fail: 0, path: 1, '': 2 };
  entries.sort((a, b) => order[a.mark] - order[b.mark] || a.proc.localeCompare(b.proc) || a.page.localeCompare(b.page));
  const head = inc ? `${esc(inc.process || '')} / ${esc(inc.page || '')} : ${esc((inc.exception || {}).stage || '')} : ${esc((inc.exception || {}).detail || '')}` : 'Blue Prism sketch';
  const list = entries.map((e, i) => `<li data-i="${i}" class="${e.mark}"><span class="t">${e.type === 'object' ? 'O' : 'P'}</span>${esc(e.proc)}<br><b>${esc(e.page)}</b></li>`).join('');
  const panes = entries.map((e, i) => `<section id="p${i}" ${i ? 'hidden' : ''}><h2>${esc(e.proc)} / ${esc(e.page)}</h2>${e.svg}</section>`).join('\n');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Sheriff sketch</title><style>
body{margin:0;font-family:Segoe UI,Arial,sans-serif;font-size:13px;display:flex;height:100vh}
nav{width:270px;min-width:200px;overflow:auto;border-right:1px solid #ddd;background:#f6f6f6}
nav h1{font-size:12px;margin:8px;color:#333;word-break:break-word}nav input{width:calc(100% - 16px);margin:0 8px 6px}
nav ul{list-style:none;margin:0;padding:0}nav li{padding:6px 8px;border-bottom:1px solid #e5e5e5;cursor:pointer;line-height:1.3}
nav li:hover{background:#e8f0fe}nav li.on{background:#dbe6fb}nav li .t{display:inline-block;width:14px;color:#888;font-size:10px}
nav li.fail{border-left:4px solid #c62828}nav li.path{border-left:4px solid #f9a825}
main{flex:1;overflow:auto;padding:8px}main h2{font-size:13px;margin:4px 0 8px;color:#444}
svg{border:1px solid #ddd;background:#fafafa;transform-origin:0 0}.zoom{position:fixed;right:12px;top:8px}
.legend{position:fixed;right:12px;bottom:8px;background:#fff;border:1px solid #ddd;padding:6px 8px;font-size:11px;line-height:1.5}
.legend i{display:inline-block;width:10px;height:10px;margin-right:4px;vertical-align:middle}
aside#sheet{width:380px;min-width:300px;border-left:1px solid #ddd;background:#fff;overflow:auto;font-size:12px}
aside .sh{position:sticky;top:0;background:#e8f0fe;padding:8px 10px;border-bottom:1px solid #c5d3ea;display:flex;align-items:center;gap:8px}
aside .sh span{font-size:10px;color:#fff;background:#1565c0;border-radius:3px;padding:1px 5px}aside .sh b{flex:1;word-break:break-word}
aside .sh button{border:none;background:none;font-size:18px;cursor:pointer;color:#555}
#sh-body{padding:8px 10px}#sh-body h4{margin:12px 0 4px;font-size:11px;color:#555;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid #eee}
#sh-body dl{margin:0;display:grid;grid-template-columns:110px 1fr;gap:3px 8px}#sh-body dt{color:#666}#sh-body dd{margin:0;word-break:break-word;font-family:Consolas,monospace;font-size:11px}
#sh-body table{border-collapse:collapse;width:100%;font-size:11px}#sh-body th{text-align:left;background:#f3f3f3;padding:3px 4px;border:1px solid #e3e3e3;font-weight:600}
#sh-body td{padding:3px 4px;border:1px solid #e3e3e3;vertical-align:top;font-family:Consolas,monospace;word-break:break-word}
#sh-body pre{background:#f7f7f7;border:1px solid #e3e3e3;padding:6px;font-size:11px;overflow:auto;max-height:50vh}#sh-body p.desc{color:#444;margin:4px 0}
g.st.on rect,g.st.on polygon{filter:drop-shadow(0 0 3px #1565c0)}
</style></head><body><nav><h1>${head}</h1><input id="q" placeholder="find a stage (Enter)"><ul id="pages">${list}</ul></nav>
<main>${panes}</main>
<aside id="sheet" hidden><div class="sh"><span id="sh-type"></span><b id="sh-name"></b><button onclick="closeSheet()" title="close">&times;</button></div><div id="sh-body"></div></aside>
<script>var INFO=${JSON.stringify(INFO).replace(/<\/script/gi, '<\\/script')};</script>
<div class="zoom"><button onclick="z(1.25)">+</button> <button onclick="z(0.8)">-</button> <button onclick="z(0)">1:1</button></div>
<div class="legend"><i style="background:#ff5252"></i>failing stage &nbsp; <i style="background:#c62828;border-radius:50%"></i>exception path step &nbsp; <span style="color:#1565c0">= value</span> data item at failure &nbsp; <span style="color:#777">#n</span> stage log row</div>
<script>
var cur=0,scale=1,items=document.querySelectorAll('#pages li');
function show(i){document.getElementById('p'+cur).hidden=true;items[cur].classList.remove('on');cur=i;document.getElementById('p'+i).hidden=false;items[i].classList.add('on');}
items.forEach(function(li){li.onclick=function(){show(+li.dataset.i)}});if(items.length)items[0].classList.add('on');
function z(f){scale=f?scale*f:1;document.querySelectorAll('svg').forEach(function(s){s.style.transform='scale('+scale+')'})}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function closeSheet(){document.getElementById('sheet').hidden=true;document.querySelectorAll('g.st.on').forEach(function(g){g.classList.remove('on')})}
function openSheet(sid){var i=INFO[sid];if(!i)return;document.querySelectorAll('g.st.on').forEach(function(g){g.classList.remove('on')});
 document.querySelectorAll('g.st[data-sid="'+sid+'"]').forEach(function(g){g.classList.add('on')});
 document.getElementById('sh-type').textContent=i.type;document.getElementById('sh-name').textContent=i.name;var h='';
 if(i.desc)h+='<p class="desc">'+esc(i.desc)+'</p>';
 h+='<h4>Stage</h4><dl><dt>Page</dt><dd>'+esc(i.proc+' / '+i.page)+'</dd>';for(var k=0;k<i.fields.length;k++)h+='<dt>'+esc(i.fields[k][0])+'</dt><dd>'+esc(i.fields[k][1])+'</dd>';
 if(i.next)h+='<dt>Next</dt><dd>'+esc(i.next)+'</dd>';h+='</dl>';
 for(var t=0;t<i.tables.length;t++){var tb=i.tables[t];h+='<h4>'+esc(tb.title)+'</h4><table><tr>';for(var c=0;c<tb.cols.length;c++)h+='<th>'+esc(tb.cols[c])+'</th>';h+='</tr>';
  for(var r=0;r<tb.rows.length;r++){h+='<tr>';for(var c2=0;c2<tb.rows[r].length;c2++)h+='<td>'+esc(tb.rows[r][c2])+'</td>';h+='</tr>'}h+='</table>'}
 if(i.code)h+='<h4>Code</h4><pre>'+esc(i.code)+'</pre>';
 h+='<h4>Logging</h4><dl><dt>Setting</dt><dd>'+esc(i.logging)+'</dd></dl>';
 document.getElementById('sh-body').innerHTML=h;document.getElementById('sheet').hidden=false}
document.addEventListener('click',function(e){var g=e.target.closest&&e.target.closest('g.st');if(g)openSheet(g.getAttribute('data-sid'))});
document.getElementById('q').onkeydown=function(e){if(e.key!=='Enter')return;var q=this.value.toLowerCase();if(!q)return;
 var secs=document.querySelectorAll('main section');for(var i=0;i<secs.length;i++){var hit=[].some.call(secs[i].querySelectorAll('text'),function(t){return t.textContent.toLowerCase().indexOf(q)>=0});if(hit){show(i);return}}alert('no stage named like that')};
</script></body></html>`;
}
function pageOverlayCreate(ov, proc, page) { const k = (proc + '|' + page).toLowerCase(); return ov.pages[k] = ov.pages[k] || { fail: new Set(), path: new Map(), pathOrder: [], values: new Map(), log: new Map(), chain: false }; }

// ---------- CLI ----------
if (require.main === module) {
  const args = process.argv.slice(2); let incFile = null, out = 'sketch.html'; const inputs = [];
  for (let i = 0; i < args.length; i++) { if (args[i] === '--incident') incFile = args[++i]; else if (args[i] === '--out') out = args[++i]; else inputs.push(args[i]); }
  if (!inputs.length) { console.error('usage: node sketch.js <xml|bprelease|dir>... [--incident incident.json] [--out sketch.html]'); process.exit(2); }
  const xml = {};
  for (const p of inputs) {
    if (fs.statSync(p).isDirectory()) { Object.assign(xml, core.loadXmlDir(p).xml); continue; }
    const text = fs.readFileSync(p, 'utf8'), lib = core.loadXmlDir(path.dirname(p)).xml;
    for (const m of text.matchAll(/<process\b[^>]*\bname="([^"]*)"/g)) { const n = unx(m[1]); if (lib[n]) xml[n] = lib[n]; }
  }
  const incident = incFile ? JSON.parse(fs.readFileSync(incFile, 'utf8')) : null;
  const html = sketch({ xml, incident });
  fs.writeFileSync(out, html, 'utf8');
  console.log('wrote ' + out + ' (' + Object.keys(xml).length + ' definitions, ' + (html.match(/<section /g) || []).length + ' pages)');
}
module.exports = { sketch, renderPage, overlayFrom, stageInfo };
