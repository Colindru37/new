// Sheriff VS Code extension: watch the Radar incident root, pre-investigate every new incident with GitHub Copilot
// through the VS Code Language Model API (vscode.lm), write pre-investigation.md into the incident folder,
// and collect human verdicts into <root>/cases. All logic that does not need VS Code lives in core.js.
'use strict';
const vscode = require('vscode');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const core = require('./core');
const logs = require('./logs');

let out, status, timer, paused = false, busy = false, ctx;

function cfg() { return vscode.workspace.getConfiguration('sheriff'); }
function root() { return cfg().get('root') || path.join(os.tmpdir(), 'Radar'); }
function log(s) { const line = new Date().toISOString().slice(11, 19) + ' ' + s; out.appendLine(line); }
function setStatus(t, tip) { status.text = '$(law) Sheriff: ' + t; status.tooltip = tip || t; status.show(); }

function activate(context) {
  ctx = context;
  out = vscode.window.createOutputChannel('Sheriff');
  status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 50);
  status.command = 'sheriff.showLog';
  context.subscriptions.push(out, status);
  context.subscriptions.push(vscode.commands.registerCommand('sheriff.scanNow', () => scan(true)));
  context.subscriptions.push(vscode.commands.registerCommand('sheriff.showLog', () => out.show(true)));
  context.subscriptions.push(vscode.commands.registerCommand('sheriff.pause', () => { paused = !paused; log(paused ? 'paused' : 'resumed'); setStatus(paused ? 'paused' : 'watching'); }));
  context.subscriptions.push(vscode.commands.registerCommand('sheriff.runFolder', async () => {
    const pick = await vscode.window.showOpenDialog({ canSelectFolders: true, canSelectFiles: false, canSelectMany: false, openLabel: 'Pre-investigate this incident folder' });
    if (pick && pick[0]) { if (fs.existsSync(path.join(pick[0].fsPath, core.PRE))) fs.unlinkSync(path.join(pick[0].fsPath, core.PRE)); await handle(pick[0].fsPath); }
  }));
  context.subscriptions.push(vscode.commands.registerCommand('sheriff.runLog', runLog));
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(e => { if (e.affectsConfiguration('sheriff')) restartTimer(); }));
  log('Sheriff active; root = ' + root() + '; backend = ' + cfg().get('backend'));
  setStatus('watching', root());
  restartTimer();
  listModels();
}

function restartTimer() {
  if (timer) clearInterval(timer);
  const s = Math.max(3, Number(cfg().get('pollSeconds')) || 10);
  timer = setInterval(() => scan(false), s * 1000);
  ctx.subscriptions.push({ dispose: () => clearInterval(timer) });
  setTimeout(() => scan(false), 1500);
}

async function listModels() {
  try {
    const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
    log('copilot models available: ' + (models.length ? models.map(m => m.family + ' (' + m.name + ', max input ' + m.maxInputTokens + ')').join('; ') : 'NONE (is GitHub Copilot Chat installed and signed in? is "extension access to models" allowed by the org policy?)'));
  } catch (e) { log('listing models failed: ' + e.message); }
}

async function scan(manual) {
  if (paused && !manual) return;
  if (busy) { if (manual) log('busy, try again in a moment'); return; }
  busy = true;
  try {
    const r = root();
    if (!fs.existsSync(r)) { if (manual) log('root does not exist: ' + r); return; }
    const harvested = core.harvestVerdicts(r);
    for (const h of harvested) log('verdict collected into ' + h);
    const incidents = core.scanIncidents(r);
    if (manual) log('scan: ' + incidents.length + ' new incident(s) under ' + r);
    for (const inc of incidents) await handle(inc);
  } catch (e) { log('scan error: ' + (e.stack || e.message)); }
  finally { busy = false; setStatus(paused ? 'paused' : 'watching', root()); }
}

async function handle(folder, opts) {
  opts = opts || {};
  const busyFile = path.join(folder, core.BUSY);
  const t0 = Date.now();
  try {
    fs.writeFileSync(busyFile, new Date().toISOString());
    setStatus('working on ' + path.basename(folder));
    log('--- incident ' + folder + (opts.label ? ' [' + opts.label + ']' : ''));
    const inc = core.loadIncident(folder);
    const names = core.namesToExport(inc);
    log('names to export: ' + names.join(' | '));
    let xmlByName = {};
    if (opts.noExport) { inc.exportNote = 'definitions deliberately not supplied for this run (' + (opts.label || 'log only') + ')'; log('export skipped: ' + opts.label); }
    else xmlByName = await exportXml(names, folder, inc);
    const { cuts, missing } = core.cutIncident(inc, xmlByName);
    if (missing.length) { inc.exportNote = (inc.exportNote || '') + '\nnot exported: ' + missing.join(', '); log('definitions missing for: ' + missing.join(', ')); }
    log('definitions cut: ' + cuts.map(c => c.type + ' "' + c.name + '"').join(', ') + ' (' + cuts.reduce((n, c) => n + c.text.length, 0) + ' chars)');
    const skill = fs.readFileSync(cfg().get('skillPath') || path.join(ctx.extensionPath, 'skill', 'SHERIFF.md'), 'utf8');
    const cases = core.loadCases(root(), Number(cfg().get('pastCases')) || 5);
    const prompt = core.buildPrompt(skill, inc, cuts, cases);
    fs.writeFileSync(path.join(folder, 'sheriff-prompt.txt'), prompt, 'utf8');
    let answer;
    if (cfg().get('backend') === 'dry') answer = '# Pre-investigation (DRY RUN, no model asked)\n\nPrompt written to sheriff-prompt.txt (' + prompt.length + ' chars).';
    else answer = await askCopilot(prompt);
    const head = '<!-- Sheriff ' + new Date().toISOString() + ' | model: ' + (answer.model || 'none') + (opts.label ? ' | variant: ' + opts.label : '') + ' | ' + ((Date.now() - t0) / 1000).toFixed(1) + ' s | prompt ' + prompt.length + ' chars -->\n\n';
    fs.writeFileSync(path.join(folder, core.PRE), head + (answer.text || answer) + core.VERDICT_BLOCK, 'utf8');
    log('written ' + path.join(folder, core.PRE) + ' in ' + ((Date.now() - t0) / 1000).toFixed(1) + ' s');
    vscode.window.showInformationMessage('Sheriff: pre-investigation ready for ' + path.basename(folder), 'Open').then(b => { if (b) vscode.workspace.openTextDocument(path.join(folder, core.PRE)).then(d => vscode.window.showTextDocument(d)); });
  } catch (e) {
    log('FAILED ' + folder + ': ' + (e.stack || e.message));
    try { fs.writeFileSync(path.join(folder, core.FAILED), new Date().toISOString() + '\n' + (e.stack || e.message) + '\n\nDelete this file to retry.'); } catch (e2) { }
  } finally { try { fs.unlinkSync(busyFile); } catch (e) { } }
}

// Log mode: a session log export (Complete or Errors Only, .csv/.xlsx) instead of a Radar incident.
// Four variants of the same case: the log as the team has it / the log in Radar's layout, each with and without the XML.
const VARIANTS = [
  { key: 'log-only', variant: 'log', xml: false, label: 'session log only (what the team has today)' },
  { key: 'log-xml', variant: 'log', xml: true, label: 'session log + process/object definitions' },
  { key: 'radar-only', variant: 'radar', xml: false, label: 'log rendered as a Radar incident, no definitions' },
  { key: 'radar-xml', variant: 'radar', xml: true, label: 'log rendered as a Radar incident + definitions' },
];
async function runLog() {
  const pick = await vscode.window.showOpenDialog({ canSelectFiles: true, canSelectFolders: false, canSelectMany: false, openLabel: 'Pre-investigate this session log', filters: { 'Session log': ['csv', 'xlsx', 'xlsm', 'txt'] } });
  if (!pick || !pick[0]) return;
  const file = pick[0].fsPath;
  const items = VARIANTS.map(v => ({ label: v.key, description: v.label, v })).concat([{ label: 'all four', description: 'run every variant, one note each', v: null }]);
  const chosen = await vscode.window.showQuickPick(items, { placeHolder: 'Which variant?' });
  if (!chosen) return;
  const todo = chosen.v ? [chosen.v] : VARIANTS;
  let cut;
  try { cut = logs.cutLog(logs.readTable(file)); }
  catch (e) { log('log mode: cannot read ' + file + ': ' + e.message); vscode.window.showErrorMessage('Sheriff: ' + e.message); return; }
  log('log mode: ' + path.basename(file) + ' -> ' + (cut.full ? 'complete' : 'errors-only') + ' log, ' + cut.stages.length + ' stage rows, ' + cut.errors.length + ' ERROR rows; process "' + cut.process + '", first error at ' + cut.at + ' in ' + (cut.object || cut.page) + ' / ' + cut.stage);
  const base = path.join(root(), 'logs', logs.stamp() + '_' + logs.safeName(cut.process || path.basename(file, path.extname(file))));
  for (const v of todo) {
    const folder = path.join(base, v.key);
    fs.mkdirSync(folder, { recursive: true });
    fs.writeFileSync(path.join(folder, 'incident.txt'), logs.renderIncident(cut, v.variant, { file: path.basename(file) }), 'utf8');
    fs.writeFileSync(path.join(folder, 'incident.json'), JSON.stringify(logs.incidentJson(cut, {}), null, 2), 'utf8');
    fs.writeFileSync(path.join(folder, 'source-log.txt'), path.basename(file) + '\n' + file + '\n', 'utf8');
    await handle(folder, { noExport: !v.xml, label: v.key });
  }
  log('log mode done: ' + base);
  vscode.window.showInformationMessage('Sheriff: log run finished, notes in ' + base, 'Open folder').then(b => { if (b) vscode.commands.executeCommand('revealFileInOS', vscode.Uri.file(base)); });
}

// returns { "<name>": xml }
async function exportXml(names, folder, inc) {
  const c = cfg();
  const result = {};
  const notes = [];
  if (c.get('export.enabled') && process.platform === 'win32') {
    const outDir = path.join(folder, 'xml');
    const script = c.get('export.script') || path.join(ctx.extensionPath, '..', 'tools', 'export_xml.ps1');
    const script2 = fs.existsSync(script) ? script : path.join(ctx.extensionPath, 'tools', 'export_xml.ps1');
    const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script2, '-Out', outDir, '-Names'].concat(names);
    if (c.get('export.automateC')) args.push('-AutomateC', c.get('export.automateC'));
    if (c.get('export.sso')) args.push('-SSO');
    if (c.get('export.user')) args.push('-User', c.get('export.user'), '-Password', c.get('export.password') || '');
    if (c.get('export.connection')) args.push('-Connection', c.get('export.connection'));
    const r = await run('powershell', args, 180000);
    log('export: ' + r.out.trim().replace(/\r?\n/g, ' / ').slice(0, 500));
    notes.push('export: ' + r.out.trim());
    for (const n of names) {
      const f = path.join(outDir, n.replace(/[\\/:*?"<>|]/g, '_') + '.xml');
      if (fs.existsSync(f)) result[n] = fs.readFileSync(f, 'utf8');
    }
    if (!c.get('export.keepXml')) { try { fs.rmSync(outDir, { recursive: true, force: true }); } catch (e) { } }
  } else notes.push('export disabled' + (process.platform !== 'win32' ? ' (not Windows)' : ''));
  const fb = c.get('xmlFallbackDir');
  if (fb && fs.existsSync(fb)) {
    const lib = core.loadXmlDir(fb);
    const norm = n => String(n || '').trim().toLowerCase();
    let used = [];
    for (const n of names) {
      if (result[n]) continue;
      const k = Object.keys(lib.xml).find(x => norm(x) === norm(n));
      if (k) { result[n] = lib.xml[k]; used.push(k); }
    }
    notes.push('fallback folder ' + fb + ': files ' + lib.files.join(', ') + '; used: ' + (used.join(', ') || 'none'));
    log('fallback xml: ' + Object.keys(lib.xml).length + ' definitions in ' + lib.files.length + ' file(s); used ' + used.length);
  }
  inc.exportNote = notes.join('\n');
  return result;
}

function run(cmd, args, timeoutMs) {
  return new Promise(resolve => {
    let buf = '';
    let p;
    try { p = spawn(cmd, args, { windowsHide: true }); } catch (e) { return resolve({ code: -1, out: String(e.message) }); }
    const t = setTimeout(() => { try { p.kill(); } catch (e) { } buf += '\n(timeout)'; }, timeoutMs);
    p.stdout.on('data', d => buf += d); p.stderr.on('data', d => buf += d);
    p.on('error', e => { buf += '\n' + e.message; });
    p.on('close', code => { clearTimeout(t); resolve({ code, out: buf }); });
  });
}

async function askCopilot(prompt) {
  const fam = cfg().get('modelFamily');
  let models = await vscode.lm.selectChatModels(fam ? { vendor: 'copilot', family: fam } : { vendor: 'copilot' });
  if (!models.length && fam) { log('model family "' + fam + '" not available, using the first Copilot model'); models = await vscode.lm.selectChatModels({ vendor: 'copilot' }); }
  if (!models.length) throw new Error('no Copilot chat model available (Copilot Chat signed in? org policy allows extension access to models?)');
  const model = models[0];
  log('asking ' + model.family + ' (' + model.name + ')');
  const messages = [vscode.LanguageModelChatMessage.User(prompt)];
  const cts = new vscode.CancellationTokenSource();
  const timer = setTimeout(() => cts.cancel(), 240000);
  try {
    const resp = await model.sendRequest(messages, {}, cts.token);
    let text = '';
    for await (const chunk of resp.text) text += chunk;
    return { text, model: model.family };
  } catch (e) {
    if (e instanceof vscode.LanguageModelError) throw new Error('LanguageModelError ' + e.code + ': ' + e.message + ' (NoPermissions = you have not consented yet or the org blocks it; Blocked = content filter)');
    throw e;
  } finally { clearTimeout(timer); }
}

function deactivate() { if (timer) clearInterval(timer); }
module.exports = { activate, deactivate };
