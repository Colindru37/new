<#
export_xml.ps1 -- export Blue Prism processes/objects to XML through AutomateC (Blue Prism's installed command-line tool).
Sheriff calls it with the names from an incident; it runs AutomateC /export <name> for each one (processes and objects alike).
  -Names "A","B"  names to export        -Out <folder>  where the XML files go (created)
  -AutomateC <path> optional explicit path to AutomateC.exe (default: the installed one, or next to the running Automate)
  -User/-Password or -SSO, -Connection <dbconname>  as on the login screen (same as bpwatch.ps1)
Writes <Out>\<name>.xml and prints one line per name: OK <name> (<process|object>) or FAIL <name>: <AutomateC output>.
Exit code 0 when at least one export succeeded.
#>
param(
    [Parameter(Mandatory = $true)][string[]]$Names,
    [Parameter(Mandatory = $true)][string]$Out,
    [string]$AutomateC = '',
    [string]$User = '',
    [string]$Password = '',
    [switch]$SSO,
    [string]$Connection = ''
)
$ErrorActionPreference = 'Stop'

function Find-AutomateC {
    if ($AutomateC -and (Test-Path $AutomateC)) { return $AutomateC }
    $candidates = @(
        'C:\Program Files\Blue Prism Limited\Blue Prism Automate\AutomateC.exe',
        'C:\Program Files (x86)\Blue Prism Limited\Blue Prism Automate\AutomateC.exe'
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    $running = Get-Process -Name Automate -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($running) {
        $c = Join-Path (Split-Path -Parent $running.Path) 'AutomateC.exe'
        if (Test-Path $c) { return $c }
    }
    throw 'AutomateC not found; pass -AutomateC <path>'
}
function Auth-Args {
    $a = @()
    if ($Connection) { $a += @('/dbconname', $Connection) }
    if ($SSO) { return $a + @('/sso') }
    if (-not $User) { throw 'pass -User/-Password or -SSO' }
    return $a + @('/user', $User, $Password)
}
function Safe([string]$s) { return ($s -replace '[\\/:*?"<>|]', '_') }

$exe = Find-AutomateC
New-Item -ItemType Directory -Force -Path $Out | Out-Null
$ok = 0
$exeDir = Split-Path -Parent $exe
foreach ($n in $Names) {
    # AutomateC syntax (verified on the bank install): /export "<name>" prints "Exported process" and writes an XML file
    # named after the process/object, in the working folder. Which folder and which exact file name differ by
    # install, so the file is located after the call: newest .xml created since the call, in the likely folders.
    $file = Join-Path $Out ((Safe $n) + '.xml')
    if (Test-Path $file) { Remove-Item $file -Force }
    $t0 = (Get-Date).AddSeconds(-2)
    $prevCwd = [Environment]::CurrentDirectory
    Push-Location $Out
    [Environment]::CurrentDirectory = $Out
    try {
        $args = (Auth-Args) + @('/export', $n)
        $outp = & $exe @args 2>&1 | Out-String
    } finally { Pop-Location; [Environment]::CurrentDirectory = $prevCwd }
    $dirs = @($Out, $prevCwd, $PWD.Path, $exeDir, (Join-Path $env:USERPROFILE 'Documents'), $env:TEMP) | Select-Object -Unique
    $found = $null
    foreach ($d in $dirs) {
        if (-not (Test-Path $d)) { continue }
        $c = Get-ChildItem -Path $d -Filter *.xml -File -ErrorAction SilentlyContinue |
             Where-Object { $_.LastWriteTime -ge $t0 -and $_.Length -gt 0 } |
             Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($c) { $found = $c; break }
    }
    if ($found) {
        if ($found.FullName -ne $file) { Move-Item $found.FullName $file -Force }
        $kind = if ((Get-Content $file -TotalCount 3 | Out-String) -match 'type="object"') { 'object' } else { 'process' }
        Write-Output "OK $n ($kind)  [was $($found.FullName)]"; $ok++
    } else {
        Write-Output ("FAIL ${n}: " + (($outp.Trim() -replace '\s+', ' ')) + "  [no new .xml in: " + ($dirs -join '; ') + "]")
    }
}
if ($ok -gt 0) { exit 0 } else { exit 1 }
