// Sketch test: every page of the sample exports renders, the incident overlay lands on the right page,
// values from the data items / data chain show, the HTML is self-contained (no external URLs).
const fs = require('fs'), path = require('path');
const core = require('../ext/core'), sk = require('../ext/sketch');
const out = path.join(__dirname, '..', '..', 'radar', 'bp', 'out');
let fails = 0;
const ok = (name, cond, info) => { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (info ? ' | ' + info : '')); };

const lib = core.loadXmlDir(out);
ok('sample exports load', Object.keys(lib.xml).length >= 10, Object.keys(lib.xml).length + ' definitions');

// every page renders to an svg
let pages = 0, failedPages = [];
for (const name of Object.keys(lib.xml)) {
  const bp = core.parseBp(lib.xml[name]);
  for (const pg of new Set(bp.stages.map(s => s.page))) {
    const svg = sk.renderPage(bp, pg, null);
    if (svg === null) continue;
    pages++;
    if (!/<svg /.test(svg) || !/<\/svg>$/.test(svg)) failedPages.push(name + '/' + pg);
  }
}
ok('every page renders', failedPages.length === 0, pages + ' pages' + (failedPages.length ? ', bad: ' + failedPages.join(', ') : ''));

// Studio shapes: a Decision is a diamond, Start/End rounded, Yes/No labels on decision links, blocks dashed
const api = core.parseBp(lib.xml['Demo API']);
const svgCall = sk.renderPage(api, 'Call Customer API', null);
ok('decision drawn as a diamond', /<polygon [^>]*><title>Decision/.test(svgCall), null);
ok('yes/no labels on a decision', /font-size="8">Yes<\/text>/.test(svgCall) && /font-size="8">No<\/text>/.test(svgCall), null);
ok('blocks drawn dashed with their name', /stroke-dasharray="4,3"\/><text [^>]*>Input Variables/.test(svgCall), null);
ok('hover text carries the stage detail', /<title>Code  Run Call Customer API[\s\S]*?code: /.test(svgCall), null);

// incident overlay: a v20-shaped incident puts the failing stage, the path and the chain values on the right pages
const inc = {
  process: 'Demo API', page: 'Get Customer Name', exception: { type: 'System Exception', stage: 'Parse Customer', detail: 'JSON To Customer: Invalid JSON primitive: .' },
  throws: [{ object: 'Demo_API', stage: 'JSON To Customer' }],
  exception_path: [{ process: 'Demo API', page: 'JSON To Customer', stage: 'Raise Error' }, { process: 'Demo API', page: 'Get Customer Name', stage: 'Parse Customer' }, { process: 'Demo API', page: 'Get Customer Name', stage: 'Recover Customer Lookup' }],
  data_chain: [{ process: 'PRC000 - Radar - Two Stage Demo', page: 'Main Page', stage: 'Get Customer Name', kind: 'Action', items: { 'g_txt_Customer Name': '' } },
               { process: 'Demo API', page: 'Get Customer Name', stage: 'Parse Customer', kind: 'Object', items: { 'Customer ID': 'C1', 'txt_Response': '<html>503</html>' } }],
  stage_log: [{ seq: 17, process: 'Demo API', page: 'Get Customer Name', stage: 'Call API' }, { seq: 23, process: 'Demo API', page: 'Get Customer Name', stage: 'Parse Customer' }],
};
const html = sk.sketch({ xml: lib.xml, incident: inc });
ok('html is self-contained', !/https?:\/\//.test(html.replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '')), null);
ok('failing page listed first and marked', /<li data-i="0" class="fail"><span class="t">O<\/span>Demo API<br><b>Get Customer Name<\/b>/.test(html), null);
const failPage = /<section id="p0"[^>]*>[\s\S]*?<\/section>/.exec(html)[0];
ok('failing stage painted red', /fill="#ff5252" stroke="#b71c1c" stroke-width="3"><title>Action  Parse Customer/.test(failPage), null);
ok('exception path numbered on the page', /<circle [^>]*fill="#c62828"\/><text [^>]*>2<\/text>/.test(failPage) && /<text [^>]*>3<\/text>/.test(failPage), null);
ok('chain values written under the data items', /= C1<\/text>/.test(failPage) && /= &lt;html&gt;503&lt;\/html&gt;<\/text>/.test(failPage), null);
ok('stage log rows numbered', /#17<\/text>/.test(failPage) && /#23<\/text>/.test(failPage), null);
const pathPage = /<section id="p1"[^>]*>[\s\S]*?<\/section>/.exec(html)[0];
ok('the throw page is next (path step 1 on Raise Error)', /JSON To Customer<\/h2>/.test(pathPage) && /<text [^>]*>1<\/text>/.test(pathPage), null);
ok('one section per page', (html.match(/<section id="p/g) || []).length === pages, (html.match(/<section id="p/g) || []).length + ' vs ' + pages);

// data items section (no chain) still gives values on the failing page
const inc2 = { process: 'Demo API', page: 'Get Customer Name', exception: { stage: 'Parse Customer' }, data_items: { 'Customer ID': 'C9', 'expr:Enter Amount/2': 'x' } };
const html2 = sk.sketch({ xml: { 'Demo API': lib.xml['Demo API'] }, incident: inc2 });
ok('data items section values shown, expr: keys skipped', /= C9<\/text>/.test(html2) && !/expr:Enter/.test(html2), null);

// the properties sheet: every drawn stage carries its id, the embedded sheet data has the Studio fields
const apiPage = core.parseBp(lib.xml['Demo API']);
const idName = {}; for (const st of apiPage.stages) idName[st.id] = st.name;
const byName = n => apiPage.stages.find(st => st.name === n);
const act = sk.stageInfo(byName('Call API'), apiPage, idName);
ok('sheet: action names object + action and its inputs/outputs', act.fields.some(f => f[0] === 'Business Object' && f[1] === 'Demo API') && act.tables.some(t => t.title === 'Inputs' && t.rows.length) && act.tables.some(t => t.title === 'Outputs'), JSON.stringify(act.fields));
const dec = sk.stageInfo(byName('Succeeded?'), apiPage, idName);
ok('sheet: decision expression + yes/no targets', dec.fields.some(f => f[0] === 'Expression') && dec.fields.some(f => f[0] === 'Yes') && dec.fields.some(f => f[0] === 'No'), JSON.stringify(dec.fields));
const code = sk.stageInfo(byName('Run Call Customer API'), apiPage, idName);
ok('sheet: code stage carries its code and logging', code.code.length > 20 && /log/i.test(code.logging), null);
const dat = sk.stageInfo(byName('Demo API Response'), apiPage, idName);
ok('sheet: data item type + exposure', dat.fields.some(f => f[0] === 'Data Type' && f[1] === 'text') && dat.fields.some(f => f[0] === 'Exposure' && f[1] === 'Environment'), JSON.stringify(dat.fields));
const bank = core.parseBp(lib.xml['Radar Demo Bank']); const bn = {}; for (const st of bank.stages) bn[st.id] = st.name;
const wr = sk.stageInfo(bank.stages.find(st => st.type === 'Write'), bank, bn);
ok('sheet: write stage lists its steps with element and spy attributes column', wr.tables.some(t => t.title === 'Steps' && t.rows[0][0] && /NOT SPIED|=/.test(t.rows[0][5])), JSON.stringify(wr.tables));
const wt = sk.stageInfo(bank.stages.find(st => st.type === 'WaitStart'), bank, bn);
ok('sheet: wait stage has timeout and conditions', wt.fields.some(f => f[0] === 'Timeout') && wt.tables.some(t => t.title === 'Conditions' && t.rows.length), JSON.stringify(wt.fields));
ok('html: shapes carry data-sid and the sheet data is embedded', /<g class="st" data-sid="/.test(html) && /var INFO=\{/.test(html) && /id="sheet"/.test(html), null);

console.log(fails === 0 ? 'SKETCH-TEST PASS' : 'SKETCH-TEST FAIL (' + fails + ')');
process.exit(fails ? 1 : 0);
