// Log-mode self-test: a synthetic Complete Session Log shaped like the real bank export (Edge attach-by-PID case),
// as CSV and as XLSX, through cutLog + both renderings + the XML-cut json.  node test/log_test.js
'use strict';
const path = require('path'), fs = require('fs'), os = require('os');
const { execFileSync } = require('child_process');
const logs = require(path.join(__dirname, '..', 'ext', 'logs.js'));
const core = require(path.join(__dirname, '..', 'ext', 'core.js'));

const HEADER = ['LogNumber', 'StageID', 'StageName', 'StageType', 'Process', 'Page', 'Object', 'Action', 'Result', 'ResultType', 'Resource Start', 'Resource End', 'Blue Prism Start', 'Target App Start', 'Target Mem', 'Direction', 'Name', 'Type', 'Value'];
let n = 0;
const rows = [HEADER];
const t = (m, s) => '27/10/2026 09:' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
function stage(name, type, proc, page, obj, act, result, rt, start, params) {
  n++;
  rows.push([String(n), 'guid-' + n, name, type, proc, page, obj, act, result, rt, start, start, '', '', '', '', '', '', '']);
  for (const p of params || []) rows.push(['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', p[0], p[1], p[2], p[3]]);
}
const P = 'DB - KLWC - EMEA - Kondor DealID Extraction';
stage('Created session log', 'Undefined', P, '', '', '', '', '', t(0, 1));
stage('Start', 'Start', P, 'Main Page', '', '', '', '', t(0, 2));
stage('Launch', 'Action', P, 'Main Page', '', '', '', '', t(0, 3), [['IN', 'URL', 'Text', 'https://klwc.example/login'], ['IN', 'Window Name', 'Text', ''], ['IN', 'Load the URL in MS Edge IE Mode?', 'Flag', 'True']]);
stage('Start MS Edge', 'Action', '', '', 'DB MS Edge - Start', 'Start MS Edge', '', '', t(0, 4), [['OUT', 'Collection ProcessName', 'Text', 'msedge'], ['OUT', 'Collection ProcessID', 'Text', '67816'], ['OUT', 'Collection SessionID', 'Text', '2'], ['OUT', 'Collection WindowTitle', 'Text', 'Deutsche Bank Login - Work - Microsoft Edge'], ['OUT', 'Collection ProcessHandle', 'Text', '10320'], ['OUT', 'Collection ParentProcessID', 'Text', '17596'], ['OUT', 'Collection Responding', 'Text', 'TRUE']]);
stage('Login', 'Action', P, 'Main Page', '', '', '', '', t(0, 9));
stage('Attach', 'Navigate', '', 'Attach', 'DB - KLWC - EMEA - Basic Actions', 'Attach', '', '', t(0, 10), [['IN', 'Window Title', 'Text', '*Deutsche*'], ['IN', 'Process Name', 'Text', 'msedge']]);
stage('Write Credentials', 'Write', '', 'W - Username Password', 'DB - KLWC - EMEA - Basic Actions', 'W - Username Password', '', '', t(0, 12));
for (let i = 1; i <= 3; i++) {
  stage('Deal SS Path', 'Calculation', P, 'AMS T2 Kondor DealID Extraction', '', '', 'C:\\ss\\deal' + i + '.png', 'Text', t(1, i * 10));
  stage('Get Curency Priority Num', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', '', '', t(1, i * 10 + 2));
  stage('Set AMS', 'Calculation', P, 'AMS T2 Kondor DealID Extraction', '', '', 'AMS', 'Text', t(1, i * 10 + 3));
  stage('Work Queues::Add To Queue', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', '', '', t(1, i * 10 + 4), [['IN', 'Queue Name', 'Text', 'Kondor Deals'], ['OUT', 'Item ID', 'Text', 'item-' + i]]);
  stage('Kondor Deals', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', '', '', t(1, i * 10 + 5));
  stage('Attach', 'Navigate', '', 'Attach', 'DB - KLWC - EMEA - Basic Actions', 'Attach', '', '', t(1, i * 10 + 6), [['IN', 'Window Title', 'Text', '*Deutsche*'], ['IN', 'Process Name', 'Text', 'msedge']]);
  stage('Read Deal', 'Read', '', 'Kondor Internal Deal Details Extraction', 'DB - KLWC - EMEA - Basic Actions', 'Kondor Internal Deal Details Extraction', '', '', t(1, i * 10 + 7), [['OUT', 'Deal Id', 'Text', 'KD-00' + i]]);
  stage('Get CounterParty Id', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', '', '', t(1, i * 10 + 8));
}
// close: attach by PID, retried 3 times with a sleep between
for (let r = 1; r <= 3; r++) {
  stage('Close Kondor', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', '', '', t(2, r * 15), [['IN', 'Process ID', 'Number', '67816']]);
  stage('Attach', 'Navigate', '', 'Attach', 'DB - KLWC - EMEA - Basic Actions', 'Attach', "ERROR: Internal : Failed to perform step 1 in Navigate Stage 'Attach' on page 'Attach' - Process with an Id of 67816 is not running.", '', t(2, r * 15 + 1));
  stage('Close Kondor', 'Action', P, 'AMS T2 Kondor DealID Extraction', '', '', "ERROR: Internal : Failed to perform step 1 in Navigate Stage 'Attach' on page 'Attach' - Process with an Id of 67816 is not running.", '', t(2, r * 15 + 1));
  stage('Increment Counter', 'Calculation', P, 'AMS T2 Kondor DealID Extraction', '', '', String(r), 'Number', t(2, r * 15 + 2));
  stage('Max Retries?', 'Decision', P, 'AMS T2 Kondor DealID Extraction', '', '', r < 3 ? 'False' : 'True', 'Flag', t(2, r * 15 + 3));
  if (r < 3) { stage('Initialise', 'Action', '', 'Initialise', 'Utility - General', 'Initialise', '', '', t(2, r * 15 + 4)); stage('Sleep', 'Action', '', 'Sleep', 'Utility - General', 'Sleep', '(1) Time Out - Sleep', 'Text', t(2, r * 15 + 5)); }
}
stage('Exception', 'Exception', P, 'AMS T2 Kondor DealID Extraction', '', '', 'ERROR: Internal : Max retries reached closing Kondor', 'System Exception', t(3, 0));

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sheriff-log-'));
const csv = path.join(tmp, 'BPA Complete Session Log_27th Oct_DB.csv');
fs.writeFileSync(csv, rows.map(r => r.map(x => /[",\n]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x).join(',')).join('\r\n') + '\r\n', 'utf8');
// xlsx via python zipfile (shared strings + inline numbers), to exercise the reader
const xlsx = path.join(tmp, 'log.xlsx');
const py = `
import zipfile, json, sys
rows = json.load(open(sys.argv[1], encoding='utf8'))
def esc(s): return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;')
shared=[]; sidx={}
def si(s):
    if s not in sidx: sidx[s]=len(shared); shared.append(s)
    return sidx[s]
def col(i):
    s=''; i+=1
    while i: i,r=divmod(i-1,26); s=chr(65+r)+s
    return s
xr=[]
for r,row in enumerate(rows,1):
    cells=[]
    for c,v in enumerate(row):
        if v=='': continue
        ref=col(c)+str(r)
        if v.lstrip('-').isdigit() and len(v)<9: cells.append('<c r="%s"><v>%s</v></c>'%(ref,v))
        else: cells.append('<c r="%s" t="s"><v>%d</v></c>'%(ref,si(v)))
    xr.append('<row r="%d">%s</row>'%(r,''.join(cells)))
sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>%s</sheetData></worksheet>'%''.join(xr)
ss='<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">%s</sst>'%(len(shared),len(shared),''.join('<si><t xml:space="preserve">%s</t></si>'%esc(s) for s in shared))
wb='<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="27th Oct" sheetId="1" r:id="rId1"/></sheets></workbook>'
rels='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>'
ct='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/></Types>'
rr='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'
with zipfile.ZipFile(sys.argv[2],'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml',ct); z.writestr('_rels/.rels',rr); z.writestr('xl/workbook.xml',wb); z.writestr('xl/_rels/workbook.xml.rels',rels); z.writestr('xl/sharedStrings.xml',ss); z.writestr('xl/worksheets/sheet1.xml',sheet)
`;
fs.writeFileSync(path.join(tmp, 'rows.json'), JSON.stringify(rows));
fs.writeFileSync(path.join(tmp, 'mk.py'), py);
execFileSync('python3', ['-I', path.join(tmp, 'mk.py'), path.join(tmp, 'rows.json'), xlsx]);

let fails = 0;
function check(name, ok, extra) { console.log((ok ? 'ok   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) fails++; }

const tCsv = logs.readTable(csv), tX = logs.readTable(xlsx);
check('csv rows == xlsx rows', tCsv.length === tX.length, tCsv.length + ' vs ' + tX.length);
check('xlsx cells equal csv cells', JSON.stringify(tCsv) === JSON.stringify(tX.map(r => { while (r.length < HEADER.length) r.push(''); return r; })));
const cut = logs.cutLog(tCsv);
check('full log detected', cut.full === true);
check('process', cut.process === P, cut.process);
check('page from caller', cut.page === 'AMS T2 Kondor DealID Extraction', cut.page);
check('failing stage is the inner Attach', cut.stage === 'Attach' && cut.object === 'DB - KLWC - EMEA - Basic Actions', cut.stage + ' / ' + cut.object);
check('detail stripped of ERROR:', /^Internal : Failed to perform step 1/.test(cut.detail), cut.detail.slice(0, 40));
check('error rows counted', cut.errors.length === 7, String(cut.errors.length));
check('PID 67816 traced to launch output', cut.refs.some(r => /67816/.test(r) && /DB MS Edge - Start/.test(r) && /ProcessID/.test(r)), cut.refs[0]);
check('retry loop collapsed in timeline', cut.timeline.some(l => /^x[23] repeats/.test(l)), cut.timeline.filter(l => /repeats/.test(l)).join(' / '));
check('trail marks failing row', cut.trail.some(l => l.startsWith('>>> ') && /67816/.test(l)));
check('trail carries parameters', cut.trail.some(l => /OUT Collection ProcessID \[Text\] = 67816/.test(l)));
const radar = logs.renderIncident(cut, 'radar', { file: csv }), raw = logs.renderIncident(cut, 'log', { file: csv });
check('radar rendering labelled derived', /DERIVED FROM A SESSION LOG/.test(radar) && /^process   : /m.test(radar));
check('log rendering has first ERROR', /first ERROR: .*Basic Actions :: Attach \/ Attach/.test(raw));
const j = logs.incidentJson(cut);
const names = core.namesToExport({ json: j, txt: radar });
check('names to export include process + objects', names.includes(P) && names.includes('DB MS Edge - Start') && names.includes('DB - KLWC - EMEA - Basic Actions'), names.join(' | '));
const prompt = core.buildPrompt('SKILL', { json: j, txt: raw, exportNote: 'log-only run' }, [], []);
check('prompt builds without XML', /SESSION LOG EXTRACT/.test(prompt) && /none exported/.test(prompt));
// partial (errors only) log: strip params, keep ERROR rows only
const partial = [HEADER].concat(rows.slice(1).filter(r => r[2] && /^ERROR/.test(r[8])).map(r => r.slice(0, 15).concat(['', '', '', ''])));
const cutP = logs.cutLog(partial);
check('partial log detected', cutP.full === false && cutP.errors.length === 7, cutP.errors.length + ' errors');
console.log(fails ? 'LOG-TEST FAIL (' + fails + ')' : 'LOG-TEST PASS');
if (process.argv.includes('--show')) { console.log('\n' + radar); console.log('\n' + raw); }
fs.writeFileSync(path.join(tmp, 'radar.txt'), radar); fs.writeFileSync(path.join(tmp, 'log.txt'), raw);
console.log('outputs in ' + tmp);
process.exit(fails ? 1 : 0);
