"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "93d2410196e41a34d47f0a7abc89ece3737b8b67e92b5ac67d6bc28603e9bc33",
 "README.md": "3e9f64bc813c37d8183f82b4307d61f88100fc664ff507800c91ec9db361ce1e",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Demo Bank Plain.xml": "354e1fd86502e65808b3b6be3bc05bc372c9373525f3ba83691b93ac5880a49a",
 "bp/BPA Object - House Logging.xml": "30b15194260cb30e60462aba0639e809bbd8f592f002242e1f51a3e3114eda39",
 "bp/BPA Object - Radar Demo Bank.xml": "e8ddbe599b2ca5373f3bfcfd661566b9d125d41868087790271fe3fbbe248629",
 "bp/BPA Object - Radar Probe.xml": "d80d728f578920d92fa4d8007c07c8fd9277311fc3541be21f50ef9a0ec71ed4",
 "bp/BPA Object - Radar.xml": "fdc049ad77ebad7f798de45c7f48226d65910c61a6f5400d8a160dcda22d7196",
 "bp/BPA Process - PRC000 - Radar - API Failure Demo.xml": "eb0155c9291b5a03a8737028b38bfa8a89ea6098b8040ad670f15ede47c98e36",
 "bp/BPA Process - PRC000 - Radar - Discover.xml": "1cba72f9733a8bf57f01cfdf16af46761ebc63f42ab8689ba755fb039d0acfa1",
 "bp/BPA Process - PRC000 - Radar - House Logging Demo.xml": "d8d5fcfdeb1d633abec678f06bd2638aa11dcfedd0d6a3ef7fc2bde55e9328db",
 "bp/BPA Process - PRC000 - Radar - Probe Demo.xml": "9f4dac5b63534dc430b3a3c94d17d5913d456f9f62e330e1dfcdae682cf0e183",
 "bp/BPA Process - PRC000 - Radar - Write Failure Demo.xml": "032924ebb39e9f109bb2166b80755c72a6e0d84d9e282f0da9e66b509575853b",
 "core/Radar.cs": "2b0982071d641bed8256285fcc9b1f2bcde2ad292b567bb33b0ecb75e7aeadf7",
 "core/RadarDiscover.cs": "c063a27fc1827103e71fa7910d07a640662c07f927fd8dabcf993e4b4f619294",
 "core/RadarDiscoverSelfTest.cs": "fe447d3077bd65cbb65a2630abe0e018f2b97aacc38514122d72923dc0bc0c17",
 "core/RadarDiscoverSelfTest.ps1": "1d37f131ad699c3e4faa252f50c9ee68f279e39ae35e137fba6b0d4f83942095",
 "core/RadarProbe.cs": "3450e2f298082339c8d03b2b58a7c9fba4c5bac19d7827b4c5ae842715008285",
 "core/RadarProbeSelfTest.cs": "3dfc5fade2fd78c146c8df70a6104d23021b108983166f6229b8948a71ae82b3",
 "core/RadarProbeSelfTest.ps1": "82491e0af7e5c7eff6ffd590253471d2ce642eefccb1b4e00a24becdacc7e7ee",
 "core/RadarSelfTest.cs": "64ce5072c2951b730ee850b55b8d32653b8a9c4231d242554bd6b8782bab8824",
 "core/RadarSelfTest.ps1": "2a7af51a2e6b798ab6cc67a4fd34ab8d7b9e9ba5d2e150a67bea2ebbee442ffe",
 "tools/bpwatch.ps1": "601b4043ab5eddcbe3bd519f469d4cfb6c8ea16476ed6900fe8ba38a46fc386f"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
