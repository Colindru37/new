// Radar: in-memory flight recorder for Blue Prism objects. BCL-only, C# 5 (Blue Prism code stage / mono mcs).
// Nothing leaves memory on the happy path. Dump() writes one incident folder and never throws.
// This file is the single source: gen_radar.py embeds it as the Radar VBO's shared code (Code Options).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Diagnostics;
using System.Runtime.ExceptionServices;

public static class RadarCore
{
    public class Entry
    {
        public long Seq;
        public DateTime At;
        public string Label;
        public string Detail;
    }

    // One ring per session. A Blue Prism resource runs each session on its own thread, so the
    // ring is keyed by the calling thread: two sessions on one resource never mix trails.
    // (To verify on the first BP run: that every action call of one session arrives on the same thread.)
    class Ring
    {
        public readonly List<Entry> Entries = new List<Entry>();
        public long Seq = 0;
        public long Dropped = 0;
        public string LastDumpKey;      // exception detail+stage of the last dump of this session
        public string LastDumpFolder;
        public DateTime LastDumpAt;
        public readonly List<Throw> Throws = new List<Throw>();   // .NET exceptions seen by the hook on this session's thread
        public string ThrowShot;        // staging file of the screenshot taken at the latest throw
        public DateTime ThrowShotAt;
    }
    const int DedupeSeconds = 120;
    const int ThrowsKept = 10;
    const int ThrowShotMinSeconds = 3;      // at most one throw-time screenshot per session per 3 s (handled-exception loops)

    /// One .NET exception at the moment it was thrown (first-chance), with the Blue Prism frames parsed.
    public class Throw
    {
        public DateTime At;
        public string Type, Message, Inner;
        public string Object, Stage, Kind;    // from the stack: generated object class, its method (the stage), the BP stage class
        public string Frames;                 // System.* frames removed, one per line
    }

    static readonly object Gate = new object();
    static readonly Dictionary<int, Ring> Rings = new Dictionary<int, Ring>();
    static int _capacity = 50;
    static string _root = null;

    // ---- the runtime hook: every .NET exception in the Automate process, at the moment of throw ----
    // Verified on Blue Prism 7.2.1 (2026-10-26): code-stage exceptions arrive with the object class and the stage
    // method as the first frame and the BP stage classes below; UI stage failures (Navigate/Write/Read/Wait) and
    // Exception stages do NOT throw .NET exceptions -- those still need the Recover-time Dump.
    static bool _hooked, _hookLive, _hookEnabled = true;
    static long _seen, _ignored, _recorded, _unknownThread;
    [ThreadStatic] static bool _inHook;
    [ThreadStatic] static bool _sawCheck;
    sealed class HookCheckException : Exception { public HookCheckException() : base("radar hook self-check") { } }

    public static bool HookEnabled { get { lock (Gate) return _hookEnabled; } set { lock (Gate) _hookEnabled = value; } }
    public static bool HookLive { get { lock (Gate) return _hookLive; } }
    /// "live" / "not live (runtime never raises the event)" / "off", plus counters.
    public static string HookStatus
    {
        get
        {
            lock (Gate)
                return (!_hookEnabled ? "off" : !_hooked ? "not installed" : _hookLive ? "live" : "not live (runtime never raises the event)")
                       + "; seen " + _seen + ", ignored " + _ignored + ", recorded " + _recorded + ", other threads " + _unknownThread;
        }
    }

    /// Subscribe once per process; returns HookStatus. Called by Configure. Never throws.
    public static string InstallHook()
    {
        try
        {
            lock (Gate)
            {
                if (!_hookEnabled) return HookStatus;
                if (!_hooked) { AppDomain.CurrentDomain.FirstChanceException += OnFirstChance; _hooked = true; }
            }
            _sawCheck = false;
            try { throw new HookCheckException(); } catch (HookCheckException) { }
            lock (Gate) _hookLive = _sawCheck;
        }
        catch (Exception) { }
        return HookStatus;
    }

    /// Known noise inside Automate: the resource connection retrying a host name, and localisation lookups.
    static bool IsNoise(Exception ex, string frames)
    {
        if (ex is HookCheckException) return true;
        var t = ex.GetType().FullName ?? "";
        if (t == "System.Resources.MissingManifestResourceException") return true;
        if (t == "System.Net.Sockets.SocketException" && (frames.Contains("PersistentConnection") || frames.Contains("TcpTalker"))) return true;
        if (t == "System.Threading.ThreadAbortException") return true;
        return false;
    }

    static void OnFirstChance(object sender, FirstChanceExceptionEventArgs a)
    {
        if (_inHook) return;
        _inHook = true;
        try
        {
            var ex = a.Exception;
            if (ex == null) return;
            if (ex is HookCheckException) { _sawCheck = true; return; }   // the liveness probe thrown by InstallHook
            lock (Gate) { if (!_hookEnabled) return; _seen++; }
            string obj, stage, kind;
            var frames = Frames(out obj, out stage, out kind);
            if (IsNoise(ex, frames)) { lock (Gate) _ignored++; return; }
            var th = new Throw
            {
                At = DateTime.Now, Type = ex.GetType().FullName, Message = OneLine(ex.Message, 600),
                Inner = ex.InnerException == null ? null : ex.InnerException.GetType().FullName + ": " + OneLine(ex.InnerException.Message, 300),
                Object = obj, Stage = stage, Kind = kind, Frames = frames
            };
            string shotFile = null;
            lock (Gate)
            {
                // only sessions that Configured/Recorded on this thread have a ring; anything else is not a session
                Ring r;
                if (!Rings.TryGetValue(System.Threading.Thread.CurrentThread.ManagedThreadId, out r)) { _unknownThread++; return; }
                _recorded++;
                r.Throws.Add(th); while (r.Throws.Count > ThrowsKept) r.Throws.RemoveAt(0);
                r.Seq++;
                r.Entries.Add(new Entry { Seq = r.Seq, At = th.At, Label = "throw:" + ShortType(th.Type),
                                          Detail = th.Message + (obj != null ? " | " + obj + "." + stage : "") + (kind != null ? " (" + kind + ")" : "") });
                Trim(r);
                if ((th.At - r.ThrowShotAt).TotalSeconds >= ThrowShotMinSeconds)
                {
                    r.ThrowShotAt = th.At;
                    shotFile = Path.Combine(Path.GetTempPath(), "radar_throw_" + System.Threading.Thread.CurrentThread.ManagedThreadId + ".png");
                    r.ThrowShot = shotFile;
                }
            }
            if (shotFile != null && Screenshot(shotFile) != "ok") lock (Gate) { var r = Mine(); if (r.ThrowShot == shotFile) r.ThrowShot = null; }
        }
        catch (Exception) { }
        finally { _inHook = false; }
    }

    static readonly Type Self = typeof(RadarCore);
    /// The call stack at the throw site with System.* frames removed; parses the generated object class
    /// (first frame outside BluePrism/Automate/System), its method (= the stage) and the first BP stage class.
    static string Frames(out string obj, out string stage, out string kind)
    {
        obj = stage = kind = null;
        var sb = new StringBuilder();
        try
        {
            var st = new StackTrace(2, false);
            int total = st.FrameCount, kept = 0;
            for (int i = 0; i < total && kept < 25; i++)
            {
                var m = st.GetFrame(i).GetMethod();
                if (m == null) continue;
                var t = m.DeclaringType;
                if (t == Self) continue;
                string tn = t == null ? "?" : (t.FullName ?? t.Name);
                if (tn.StartsWith("System.") || tn.StartsWith("Microsoft.") || tn == "System") continue;
                sb.Append(tn).Append('.').Append(m.Name).Append('\n');
                kept++;
                bool bp = tn.StartsWith("BluePrism.") || tn.StartsWith("Automate") || tn.StartsWith("LocaleTools");
                if (obj == null && !bp) { obj = tn; stage = m.Name.StartsWith("Run_") ? m.Name.Substring(4).Replace('_', ' ') : m.Name; }
                if (kind == null && tn.StartsWith("BluePrism.AutomateProcessCore.Stages.")) kind = tn.Substring("BluePrism.AutomateProcessCore.Stages.".Length);
            }
        }
        catch (Exception) { }
        return sb.ToString();
    }
    static string ShortType(string t) { if (t == null) return ""; int i = t.LastIndexOf('.'); return i < 0 ? t : t.Substring(i + 1); }
    static string OneLine(string s, int max)
    {
        if (s == null) return "";
        s = s.Replace("\r", " ").Replace("\n", " ");
        return s.Length > max ? s.Substring(0, max) + "..." : s;
    }

    static Ring Mine()
    {
        int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
        Ring r;
        if (!Rings.TryGetValue(id, out r)) { r = new Ring(); Rings[id] = r; }
        return r;
    }

    static void Trim(Ring r)
    {
        while (r.Entries.Count > _capacity) { r.Entries.RemoveAt(0); r.Dropped++; }
    }

    public static int Capacity { get { lock (Gate) return _capacity; } }
    public static string Root { get { lock (Gate) return _root ?? Path.Combine(Path.GetTempPath(), "Radar"); } }
    public static int SessionCount { get { lock (Gate) return Rings.Count; } }

    /// Set the incident root folder (a UNC share in production) and the ring capacity. Empty/zero keep the defaults.
    public static void Configure(string rootFolder, int capacity)
    {
        lock (Gate)
        {
            if (!string.IsNullOrEmpty(rootFolder)) _root = rootFolder;
            if (capacity > 0) _capacity = capacity;
            foreach (var r in Rings.Values) Trim(r);
            Mine();     // this thread is a session from now on: the hook records its throws
        }
        InstallHook();
    }

    /// Append one entry to this session's ring; the oldest falls off past Capacity. Cheap: no I/O.
    public static void Record(string label, string detail)
    {
        lock (Gate)
        {
            var r = Mine();
            r.Seq++;
            r.Entries.Add(new Entry { Seq = r.Seq, At = DateTime.Now, Label = label ?? "", Detail = detail ?? "" });
            Trim(r);
        }
    }

    public static int Count { get { lock (Gate) return Mine().Entries.Count; } }
    public static long Dropped { get { lock (Gate) return Mine().Dropped; } }

    /// This session's trail as text, oldest first, one line per entry.
    public static string Trail()
    {
        lock (Gate)
        {
            var sb = new StringBuilder();
            foreach (var e in Mine().Entries)
                sb.Append(Line(e)).Append('\n');
            return sb.ToString();
        }
    }

    /// Forget this session's ring (called after a dump; also the right call at Clean Up).
    public static void Clear()
    {
        lock (Gate) { Rings.Remove(System.Threading.Thread.CurrentThread.ManagedThreadId); }
    }

    static string Line(Entry e)
    {
        return e.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + " | #" + e.Seq + " | " + e.Label + " | " + e.Detail.Replace("\r", "").Replace("\n", " \\n ");
    }

    /// Write one incident folder: incident.txt + incident.json (+ screenshot.png on Windows), then clear this session's ring.
    /// Returns the folder path, or "ERROR: ..." when even the folder could not be written. Never throws.
    public static string Dump(string process, string page, string exType, string exDetail, string exStage, string dataItems, bool captureScreen)
    {
        try
        {
            var now = DateTime.Now;
            List<Entry> snapshot; long dropped; int cap; List<Throw> throws; string throwShot = null; string hookStatus;
            // Dedupe key = type + detail ONLY. Blue Prism reports a different ExceptionStage() at each
            // level (the inner stage in the object, the calling Action stage in the process -- seen on the
            // estate 2026-10-23), so the stage must not be part of the key.
            string key = (exType ?? "") + "\u0001" + (exDetail ?? "");
            lock (Gate)
            {
                var r = Mine();
                // The same exception reaches Dump twice when an instrumented object dumps and then the
                // process's logger dumps on the rethrow: one incident folder, not two.
                if (r.LastDumpKey == key && (now - r.LastDumpAt).TotalSeconds < DedupeSeconds && r.LastDumpFolder != null)
                {
                    // the later caller (usually the process's logger) may be the one that wants the screenshot
                    var shot = Path.Combine(r.LastDumpFolder, "screenshot.png");
                    if (captureScreen && !File.Exists(shot) && Directory.Exists(r.LastDumpFolder))
                    {
                        var note = Screenshot(shot);
                        try { File.AppendAllText(Path.Combine(r.LastDumpFolder, "incident.txt"),
                                                 "\nscreenshot: " + (note == "ok" ? "screenshot.png (taken by a later dump of the same exception)" : "skipped (" + note + ")") + "\n", new UTF8Encoding(false)); }
                        catch (Exception) { }
                    }
                    return r.LastDumpFolder;
                }
                snapshot = new List<Entry>(r.Entries); dropped = r.Dropped; cap = _capacity;
                throws = new List<Throw>(r.Throws);
                if (r.ThrowShot != null && File.Exists(r.ThrowShot) && (now - r.ThrowShotAt).TotalSeconds < DedupeSeconds) throwShot = r.ThrowShot;
                hookStatus = HookStatus;
            }
            // <root>\<resource machine>\<time>_<process>_<stage>: the Control Room row (time, resource, stage) finds it
            var folder = Path.Combine(Path.Combine(Root, Safe(Environment.MachineName)),
                                      now.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture) + "_" + Safe(process) + "_" + Safe(exStage));
            for (int n = 2; Directory.Exists(folder); n++)          // two incidents in the same millisecond never share a folder
                folder = folder.TrimEnd('0','1','2','3','4','5','6','7','8','9','~') + "~" + n;
            Directory.CreateDirectory(folder);

            string shotNote;
            string shotFile = null;
            if (captureScreen)
            {
                shotFile = Path.Combine(folder, "screenshot.png");
                shotNote = Screenshot(shotFile);
                if (shotNote != "ok") shotFile = null;
            }
            else shotNote = "not requested";
            string throwShotNote = "none";
            if (throwShot != null)
            {
                try { File.Copy(throwShot, Path.Combine(folder, "screenshot_at_throw.png"), true); throwShotNote = "screenshot_at_throw.png"; }
                catch (Exception e) { throwShotNote = "failed (" + e.GetType().Name + ")"; }
            }

            EnvInfo env; try { env = EnvSnapshot(); } catch (Exception ex) { env = new EnvInfo(); env.Text = "unavailable (" + ex.GetType().Name + ")\n"; }
            try { File.WriteAllText(Path.Combine(folder, "env.txt"), env.Text, new UTF8Encoding(false)); } catch (Exception) { }

            var txt = new StringBuilder();
            txt.Append("RADAR INCIDENT ").Append(now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append('\n');
            txt.Append("process   : ").Append(process).Append('\n');
            txt.Append("page      : ").Append(page).Append('\n');
            txt.Append("machine   : ").Append(Environment.MachineName).Append(" / ").Append(Environment.UserName).Append('\n');
            txt.Append("exception : ").Append(exType).Append('\n');
            txt.Append("stage     : ").Append(exStage).Append('\n');
            txt.Append("detail    : ").Append(exDetail).Append('\n');
            txt.Append("screenshot: ").Append(shotFile != null ? "screenshot.png" : "skipped (" + shotNote + ")").Append('\n');
            txt.Append("at throw  : ").Append(throwShotNote).Append('\n');
            txt.Append("hook      : ").Append(hookStatus).Append('\n');
            txt.Append("env       : ").Append(EnvLine()).Append('\n');
            txt.Append("\n--- environment at failure (also env.txt) ---\n").Append(env.Text);
            txt.Append("\n--- .NET exceptions at throw time (hook; last ").Append(ThrowsKept).Append(", oldest first) ---\n");
            if (throws.Count == 0) txt.Append("(none)\n");
            foreach (var t in throws)
            {
                txt.Append(t.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append(" | ").Append(t.Type).Append(": ").Append(t.Message).Append('\n');
                if (t.Inner != null) txt.Append("    inner: ").Append(t.Inner).Append('\n');
                if (t.Object != null) txt.Append("    thrown in: ").Append(t.Object).Append('.').Append(t.Stage).Append(t.Kind != null ? " (" + t.Kind + ")" : "").Append('\n');
                foreach (var f in t.Frames.Split('\n')) if (f.Length > 0) txt.Append("    ").Append(f).Append('\n');
            }
            txt.Append("\n--- data items at failure ---\n").Append(dataItems ?? "").Append(dataItems != null && dataItems.EndsWith("\n") ? "" : "\n");
            txt.Append("\n--- trail (oldest first; ").Append(snapshot.Count).Append(" kept, ").Append(dropped).Append(" dropped, capacity ").Append(cap).Append(") ---\n");
            foreach (var e in snapshot) txt.Append(Line(e)).Append('\n');
            File.WriteAllText(Path.Combine(folder, "incident.txt"), txt.ToString(), new UTF8Encoding(false));

            var js = new StringBuilder();
            js.Append("{\n");
            js.Append("  \"at\": ").Append(J(now.ToString("o"))).Append(",\n");
            js.Append("  \"process\": ").Append(J(process)).Append(",\n");
            js.Append("  \"page\": ").Append(J(page)).Append(",\n");
            js.Append("  \"machine\": ").Append(J(Environment.MachineName)).Append(",\n");
            js.Append("  \"user\": ").Append(J(Environment.UserName)).Append(",\n");
            js.Append("  \"exception\": { \"type\": ").Append(J(exType)).Append(", \"stage\": ").Append(J(exStage)).Append(", \"detail\": ").Append(J(exDetail)).Append(" },\n");
            js.Append("  \"screenshot\": ").Append(shotFile != null ? J("screenshot.png") : "null").Append(",\n");
            js.Append("  \"screenshot_note\": ").Append(J(shotNote)).Append(",\n");
            js.Append("  \"screenshot_at_throw\": ").Append(throwShotNote.EndsWith(".png") ? J(throwShotNote) : "null").Append(",\n");
            js.Append("  \"hook\": ").Append(J(hookStatus)).Append(",\n");
            js.Append("  \"env\": ").Append(J(EnvLine())).Append(",\n");
            js.Append("  \"environment\": {");
            { bool first = true; foreach (var kv in env.Fields) { js.Append(first ? " " : ", ").Append(J(kv.Key)).Append(": ").Append(J(kv.Value)); first = false; } }
            js.Append(env.Fields.Count > 0 ? ", " : " ").Append("\"file\": \"env.txt\" },\n");
            js.Append("  \"throws\": [\n");
            for (int i = 0; i < throws.Count; i++)
            {
                var t = throws[i];
                js.Append("    { \"at\": ").Append(J(t.At.ToString("o"))).Append(", \"type\": ").Append(J(t.Type)).Append(", \"message\": ").Append(J(t.Message))
                  .Append(", \"inner\": ").Append(J(t.Inner)).Append(", \"object\": ").Append(J(t.Object)).Append(", \"stage\": ").Append(J(t.Stage))
                  .Append(", \"kind\": ").Append(J(t.Kind)).Append(", \"frames\": ").Append(J(t.Frames.TrimEnd('\n'))).Append(" }").Append(i + 1 < throws.Count ? ",\n" : "\n");
            }
            js.Append("  ],\n");
            js.Append("  \"data_items\": ").Append(DataItemsJson(dataItems)).Append(",\n");
            js.Append("  \"dropped\": ").Append(dropped).Append(",\n");
            js.Append("  \"trail\": [\n");
            for (int i = 0; i < snapshot.Count; i++)
            {
                var e = snapshot[i];
                js.Append("    { \"seq\": ").Append(e.Seq).Append(", \"at\": ").Append(J(e.At.ToString("o")))
                  .Append(", \"label\": ").Append(J(e.Label)).Append(", \"detail\": ").Append(J(e.Detail)).Append(" }")
                  .Append(i + 1 < snapshot.Count ? ",\n" : "\n");
            }
            js.Append("  ]\n}\n");
            File.WriteAllText(Path.Combine(folder, "incident.json"), js.ToString(), new UTF8Encoding(false));

            lock (Gate)
            {
                Rings.Remove(System.Threading.Thread.CurrentThread.ManagedThreadId);
                var fresh = Mine();
                fresh.LastDumpKey = key; fresh.LastDumpFolder = folder; fresh.LastDumpAt = now;
            }
            return folder;
        }
        catch (Exception ex)
        {
            return "ERROR: " + ex.GetType().Name + ": " + ex.Message;
        }
    }

    /// "name=value" lines -> JSON object. A line without '=' becomes a key with null.
    static string DataItemsJson(string dataItems)
    {
        var sb = new StringBuilder("{");
        bool first = true;
        foreach (var raw in (dataItems ?? "").Replace("\r", "").Split('\n'))
        {
            var line = raw.Trim();
            if (line.Length == 0) continue;
            int eq = line.IndexOf('=');
            string k = eq < 0 ? line : line.Substring(0, eq).Trim();
            string v = eq < 0 ? null : line.Substring(eq + 1);
            sb.Append(first ? " " : ", ").Append(J(k)).Append(": ").Append(v == null ? "null" : J(v));
            first = false;
        }
        return sb.Append(first ? "}" : " }").ToString();
    }

    static string J(string s)
    {
        if (s == null) return "null";
        var sb = new StringBuilder("\"");
        foreach (var c in s)
        {
            switch (c)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.Append('"').ToString();
    }

    static string Safe(string s)
    {
        if (string.IsNullOrEmpty(s)) return "x";
        var sb = new StringBuilder();
        foreach (var c in s)
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var r = sb.ToString().Trim('_');
        return r.Length > 40 ? r.Substring(0, 40) : (r.Length == 0 ? "x" : r);
    }

    // ---- screenshot: whole virtual desktop via GDI+, Windows only; any failure is reported, never thrown ----
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int n);

    /// <summary>The machine fingerprint that changes between resources and explains "works on mine": culture
    /// (date/number formats), OS, bitness, screen size. One line, never throws.</summary>
    public static string EnvLine()
    {
        try
        {
            var c = CultureInfo.CurrentCulture;
            var sb = new StringBuilder();
            sb.Append("culture ").Append(c.Name).Append(" (ui ").Append(CultureInfo.CurrentUICulture.Name).Append(") date ")
              .Append(c.DateTimeFormat.ShortDatePattern).Append(" decimal '").Append(c.NumberFormat.NumberDecimalSeparator)
              .Append("' group '").Append(c.NumberFormat.NumberGroupSeparator).Append("' | os ").Append(Environment.OSVersion.Version)
              .Append(Environment.Is64BitProcess ? " x64" : " x86").Append(" clr ").Append(Environment.Version);
            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
                sb.Append(" | screen ").Append(w).Append('x').Append(h);
            }
            return sb.ToString();
        }
        catch (Exception ex) { return "unavailable (" + ex.GetType().Name + ")"; }
    }
    const int SM_XVIRTUALSCREEN = 76, SM_YVIRTUALSCREEN = 77, SM_CXVIRTUALSCREEN = 78, SM_CYVIRTUALSCREEN = 79;

    // ---- environment snapshot at failure: session type, memory, disk, the automated apps' processes, event log,
    // network, clock. Plain .NET; every section reports "unavailable (...)" instead of throwing; bounded in time. ----
    public class EnvInfo
    {
        public string Text = "";
        public readonly Dictionary<string, string> Fields = new Dictionary<string, string>();
        public string Field(string k) { string v; return Fields.TryGetValue(k, out v) ? v : null; }
    }

    [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX m);
    [StructLayout(LayoutKind.Sequential)] struct MEMORYSTATUSEX
    {
        public uint dwLength, dwMemoryLoad;
        public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
    }
    const int SM_REMOTESESSION = 0x1000;
    const int EventLogMinutes = 10, EventLogMax = 20, EventLogScan = 400, AppLinesMax = 40;
    // process names of the things the estate automates or runs; everything else is only counted
    static readonly string[] WatchedApps = { "msedge", "chrome", "iexplore", "firefox", "excel", "winword", "outlook", "acrobat", "acrord32",
        "java", "javaw", "javaws", "wfica32", "mstsc", "cmd", "powershell", "sapgui", "saplogon", "notepad", "automate", "automatec", "appman", "bpserver" };

    static string Mb(ulong b) { return (b / (1024UL * 1024UL)).ToString(CultureInfo.InvariantCulture); }
    static string Mb(long b) { return (b / (1024L * 1024L)).ToString(CultureInfo.InvariantCulture); }

    /// <summary>Everything about the machine at the moment of failure that a session log never records.
    /// Each section is independent; a failing section prints its reason and the rest continue.</summary>
    public static EnvInfo EnvSnapshot()
    {
        var e = new EnvInfo();
        var sb = new StringBuilder();
        var total = Stopwatch.StartNew();
        bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;

        // session: console / RDP / Citrix, interactive or not
        try
        {
            string sn = Environment.GetEnvironmentVariable("SESSIONNAME") ?? "", cn = Environment.GetEnvironmentVariable("CLIENTNAME") ?? "";
            bool remote = false; try { remote = win && GetSystemMetrics(SM_REMOTESESSION) != 0; } catch (Exception) { }
            string kind = sn.StartsWith("ICA", StringComparison.OrdinalIgnoreCase) ? "Citrix ICA" : sn.StartsWith("RDP", StringComparison.OrdinalIgnoreCase) ? "RDP" : sn.Length > 0 ? sn : "unknown";
            int sid = -1; try { sid = Process.GetCurrentProcess().SessionId; } catch (Exception) { }
            sb.Append("session   : ").Append(kind).Append(remote ? " (remote)" : " (local)").Append(" id ").Append(sid)
              .Append(" name '").Append(sn).Append("' client '").Append(cn).Append("' interactive ").Append(Environment.UserInteractive)
              .Append(" user ").Append(Environment.UserDomainName).Append('\\').Append(Environment.UserName).Append('\n');
            e.Fields["session"] = kind; e.Fields["remote"] = remote ? "true" : "false"; e.Fields["client"] = cn;
        }
        catch (Exception ex) { sb.Append("session   : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // memory + this process
        try
        {
            var m = new MEMORYSTATUSEX(); m.dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            if (win && GlobalMemoryStatusEx(ref m))
            {
                sb.Append("memory    : ").Append(Mb(m.ullAvailPhys)).Append(" MB free of ").Append(Mb(m.ullTotalPhys)).Append(" MB (").Append(m.dwMemoryLoad).Append("% used), page file ")
                  .Append(Mb(m.ullAvailPageFile)).Append(" MB free of ").Append(Mb(m.ullTotalPageFile)).Append(" MB\n");
                e.Fields["mem_free_mb"] = Mb(m.ullAvailPhys); e.Fields["mem_total_mb"] = Mb(m.ullTotalPhys); e.Fields["mem_load_pct"] = m.dwMemoryLoad.ToString(CultureInfo.InvariantCulture);
            }
            else sb.Append("memory    : unavailable (not Windows)\n");
        }
        catch (Exception ex) { sb.Append("memory    : unavailable (").Append(ex.GetType().Name).Append(")\n"); }
        try
        {
            var p = Process.GetCurrentProcess();
            sb.Append("this proc : ").Append(p.ProcessName).Append(" pid ").Append(p.Id).Append(" working set ").Append(Mb(p.WorkingSet64)).Append(" MB, ")
              .Append(p.HandleCount).Append(" handles, ").Append(p.Threads.Count).Append(" threads, started ").Append(p.StartTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture))
              .Append(" | machine up ").Append((Environment.TickCount / 1000 / 60).ToString(CultureInfo.InvariantCulture)).Append(" min | ").Append(Environment.ProcessorCount).Append(" cpu\n");
            e.Fields["working_set_mb"] = Mb(p.WorkingSet64); e.Fields["handles"] = p.HandleCount.ToString(CultureInfo.InvariantCulture);
        }
        catch (Exception ex) { sb.Append("this proc : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // disk: the dump drive and the temp drive
        try
        {
            var seen = new List<string>();
            foreach (var path in new[] { Root, Path.GetTempPath() })
            {
                string rootName; try { rootName = Path.GetPathRoot(Path.GetFullPath(path)); } catch (Exception) { continue; }
                if (rootName == null || seen.Contains(rootName)) continue; seen.Add(rootName);
                try { var d = new DriveInfo(rootName); sb.Append("disk      : ").Append(rootName).Append(' ').Append(Mb(d.AvailableFreeSpace)).Append(" MB free of ").Append(Mb(d.TotalSize)).Append(" MB\n"); if (!e.Fields.ContainsKey("disk_free_mb")) e.Fields["disk_free_mb"] = Mb(d.AvailableFreeSpace); }
                catch (Exception ex) { sb.Append("disk      : ").Append(rootName).Append(" unavailable (").Append(ex.GetType().Name).Append(")\n"); }
            }
        }
        catch (Exception ex) { sb.Append("disk      : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // network + clock
        try
        {
            string host = ""; try { host = System.Net.Dns.GetHostName(); } catch (Exception) { }
            bool net = false; try { net = System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable(); } catch (Exception) { }
            var ips = new List<string>();
            try
            {
                foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up || ni.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback) continue;
                    foreach (var a in ni.GetIPProperties().UnicastAddresses)
                        if (a.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork && ips.Count < 4) ips.Add(a.Address.ToString());
                }
            }
            catch (Exception) { }
            sb.Append("network   : ").Append(net ? "available" : "NOT available").Append(" host ").Append(host).Append(" ip ").Append(ips.Count > 0 ? string.Join(",", ips.ToArray()) : "-").Append('\n');
            e.Fields["network"] = net ? "available" : "unavailable";
        }
        catch (Exception ex) { sb.Append("network   : unavailable (").Append(ex.GetType().Name).Append(")\n"); }
        try
        {
            var now = DateTime.Now;
            sb.Append("clock     : ").Append(now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)).Append(" local, utc").Append(TimeZoneInfo.Local.GetUtcOffset(now).TotalHours >= 0 ? "+" : "")
              .Append(TimeZoneInfo.Local.GetUtcOffset(now).TotalHours.ToString(CultureInfo.InvariantCulture)).Append(" (").Append(TimeZoneInfo.Local.Id).Append(")\n");
        }
        catch (Exception ex) { sb.Append("clock     : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // the automated apps: is the process the object attached to still alive, and what is its window called now
        try
        {
            var all = Process.GetProcesses();
            var lines = new List<string>(); var counts = new SortedDictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var p in all)
            {
                string name; try { name = p.ProcessName; } catch (Exception) { continue; }
                int c; counts.TryGetValue(name, out c); counts[name] = c + 1;
                if (Array.IndexOf(WatchedApps, name.ToLowerInvariant()) < 0) continue;
                if (lines.Count >= AppLinesMax) continue;
                string title = "", started = "", ws = "", resp = "";
                try { title = p.MainWindowTitle ?? ""; } catch (Exception) { }
                try { started = p.StartTime.ToString("HH:mm:ss", CultureInfo.InvariantCulture); } catch (Exception) { started = "?"; }
                try { ws = Mb(p.WorkingSet64) + " MB"; } catch (Exception) { }
                try { resp = p.Responding ? "" : " NOT RESPONDING"; } catch (Exception) { }
                lines.Add("  " + name + " pid " + p.Id + " started " + started + " " + ws + resp + (title.Length > 0 ? " title \"" + OneLine(title, 100) + "\"" : " (no main window)"));
            }
            sb.Append("apps      : ").Append(all.Length).Append(" processes; watched ones:\n");
            if (lines.Count == 0) sb.Append("  (none of the watched apps is running)\n");
            lines.Sort(StringComparer.OrdinalIgnoreCase); foreach (var l in lines) sb.Append(l).Append('\n');
            var top = new List<KeyValuePair<string, int>>(counts); top.Sort((a, b) => b.Value.CompareTo(a.Value));
            var tops = new StringBuilder(); for (int i = 0; i < top.Count && i < 8; i++) tops.Append(i > 0 ? ", " : "").Append(top[i].Key).Append(" x").Append(top[i].Value);
            sb.Append("  most instances: ").Append(tops).Append('\n');
            e.Fields["processes"] = all.Length.ToString(CultureInfo.InvariantCulture); e.Fields["watched_apps"] = lines.Count.ToString(CultureInfo.InvariantCulture);
            foreach (var p in all) try { p.Dispose(); } catch (Exception) { }
        }
        catch (Exception ex) { sb.Append("apps      : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        // event log: errors and warnings of the last minutes (Application + System), newest first, bounded scan
        try
        {
            if (!win) throw new PlatformNotSupportedException();
            var since = DateTime.Now.AddMinutes(-EventLogMinutes); int found = 0, scanned = 0; var ev = new StringBuilder();
            foreach (var logName in new[] { "Application", "System" })
            {
                try
                {
                    using (var log = new EventLog(logName))
                    {
                        var entries = log.Entries; int n = entries.Count;
                        for (int i = n - 1; i >= 0 && scanned < EventLogScan && found < EventLogMax; i--, scanned++)
                        {
                            EventLogEntry en; try { en = entries[i]; } catch (Exception) { break; }
                            if (en.TimeGenerated < since) break;
                            if (en.EntryType != EventLogEntryType.Error && en.EntryType != EventLogEntryType.Warning) continue;
                            found++;
                            ev.Append("  ").Append(en.TimeGenerated.ToString("HH:mm:ss", CultureInfo.InvariantCulture)).Append(' ').Append(logName).Append(' ').Append(en.EntryType).Append(' ').Append(en.Source).Append(": ").Append(OneLine(en.Message, 160)).Append('\n');
                        }
                    }
                }
                catch (Exception ex) { ev.Append("  ").Append(logName).Append(": unavailable (").Append(ex.GetType().Name).Append(")\n"); }
            }
            sb.Append("event log : ").Append(found).Append(" error/warning entries in the last ").Append(EventLogMinutes).Append(" min\n").Append(ev);
            e.Fields["event_errors"] = found.ToString(CultureInfo.InvariantCulture);
        }
        catch (Exception ex) { sb.Append("event log : unavailable (").Append(ex.GetType().Name).Append(")\n"); }

        sb.Append("snapshot  : took ").Append(total.ElapsedMilliseconds).Append(" ms\n");
        e.Fields["snapshot_ms"] = total.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture);
        e.Text = sb.ToString();
        return e;
    }

    static string Screenshot(string file)
    {
        if (Environment.OSVersion.Platform != PlatformID.Win32NT) return "not Windows (" + Environment.OSVersion.Platform + ")";
        try
        {
            int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
            int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
            if (w <= 0 || h <= 0) return "no screen (" + w + "x" + h + ")";
            using (var bmp = new System.Drawing.Bitmap(w, h))
            {
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                    g.CopyFromScreen(x, y, 0, 0, new System.Drawing.Size(w, h));
                bmp.Save(file, System.Drawing.Imaging.ImageFormat.Png);
            }
            return "ok";
        }
        catch (Exception ex)
        {
            return ex.GetType().Name + ": " + ex.Message;
        }
    }
}
