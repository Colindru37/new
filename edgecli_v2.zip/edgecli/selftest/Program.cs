using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace EdgeCli
{
    internal static class Program
    {
        private static int _pass, _fail;
        private static void Check(string name, bool ok, string detail)
        {
            if (ok) { _pass++; Console.WriteLine("PASS  " + name); }
            else { _fail++; Console.WriteLine("FAIL  " + name + "  -> " + detail); }
        }

        // The `ask` algorithm, same as edge.ps1's: type + Enter, wait for a new
        // reply element, then wait until its text stops changing.
        // Mode enforcement, same as edge.ps1: the option must be ON before every
        // send; click it if it is not; verify; refuse to send if it still is not.
        private static void EnsureMode(Browser b, string modeX, string verifyX)
        {
            if (string.IsNullOrEmpty(modeX)) return;
            if (b.Count(verifyX) > 0) return;
            if (b.Count(modeX) == 0) throw new Exception("mode control not found: " + modeX);
            b.Click(modeX);
            Thread.Sleep(300);
            if (b.Count(verifyX) == 0) throw new Exception("mode did not activate: " + verifyX);
        }

        private static string Ask(Browser b, string inputX, string replyX, string prompt, int settleMs, int timeoutMs)
        {
            return Ask(b, inputX, replyX, null, null, prompt, settleMs, timeoutMs);
        }

        private static string Ask(Browser b, string inputX, string replyX, string modeX, string verifyX, string prompt, int settleMs, int timeoutMs)
        {
            EnsureMode(b, modeX, verifyX);
            int before = b.Count(replyX);
            b.SendKeysAndEnter(inputX, prompt);
            int waited = 0;
            while (b.Count(replyX) <= before)
            {
                Thread.Sleep(250); waited += 250;
                if (waited > timeoutMs) throw new Exception("no reply appeared");
            }
            string last = null; int stable = 0;
            while (stable < settleMs)
            {
                var all = b.GetElementsText(replyX);
                string now = all[all.Count - 1];
                if (now == last) stable += 250; else { stable = 0; last = now; }
                Thread.Sleep(250); waited += 250;
                if (waited > timeoutMs) break;
            }
            return last;
        }

        private static int Main(string[] args)
        {
            string driver = args.Length > 0 ? args[0] : "geckodriver";
            string browser = args.Length > 1 ? args[1] : "firefox";
            string pageUrl = new Uri(Path.GetFullPath("page.html")).AbsoluteUri;
            string png = Path.GetFullPath("out.png"), pdf = Path.GetFullPath("out.pdf");
            File.Delete(png); File.Delete(pdf);

            var b = new Browser();
            try
            {
                b.Start(driver, 9515, true, browser);
                Check("start -> exactly one tab", b.GetWindowHandles().Count == 1, b.GetWindowHandles().Count.ToString());

                b.Navigate(pageUrl);
                Check("title", b.GetTitle() == "EdgeCli Test Page", b.GetTitle());
                Check("url", b.GetUrl().EndsWith("page.html"), b.GetUrl());

                object r = b.ExecuteScript("return arguments[0] * 7 + document.querySelectorAll('.row').length;", 6);
                Check("js returns computed value", Convert.ToInt32(r) == 45, Convert.ToString(r));
                object o = b.ExecuteScript("return {a: 1, b: ['x','y']};");
                var dict = o as Dictionary<string, object>;
                Check("js returns object", dict != null && Convert.ToInt32(dict["a"]) == 1 && ((ArrayList)dict["b"]).Count == 2, Convert.ToString(o));

                var rows = b.GetElementsText("//li[@class='row']");
                Check("elements text", rows.Count == 3 && rows[1] == "beta", string.Join("|", rows.ToArray()));
                Check("count", b.Count("//li") == 3 && b.Count("//li[@id='nope']") == 0, "");

                string src = b.GetPageSource();
                Check("page source", src.Contains("id=\"heading\""), src.Length.ToString());

                b.Screenshot(png);
                var pb = File.ReadAllBytes(png);
                Check("screenshot is PNG", pb.Length > 100 && pb[1] == (byte)'P' && pb[2] == (byte)'N' && pb[3] == (byte)'G', pb.Length.ToString());

                b.PrintToPdf(pdf);
                var db = File.ReadAllBytes(pdf);
                Check("print is PDF", db.Length > 100 && db[0] == (byte)'%' && db[1] == (byte)'P' && db[2] == (byte)'D' && db[3] == (byte)'F', db.Length.ToString());

                string t2 = b.NewTab();
                Check("new tab -> 2 handles", b.GetWindowHandles().Count == 2, "");
                b.SwitchToWindow(t2);
                b.Navigate("about:blank");
                b.CloseTab();
                Check("close tab -> 1 handle, back on page", b.GetWindowHandles().Count == 1 && b.GetTitle() == "EdgeCli Test Page", b.GetTitle());

                b.NewTab(); b.NewTab();
                b.EnsureSingleFreshTab();
                Check("ensure single fresh tab", b.GetWindowHandles().Count == 1 && b.GetUrl().StartsWith("about:"), b.GetUrl());

                b.Navigate(pageUrl);
                string a1 = Ask(b, "//textarea[@id='prompt']", "//div[@class='ai']", "hello", 1200, 15000);
                Check("ask: waits for streamed reply to settle", a1 == "echo:hello [quick]", a1);
                string a2 = Ask(b, "//textarea[@id='prompt']", "//div[@class='ai']", "second", 1200, 15000);
                Check("ask: second question reads the NEW reply", a2 == "echo:second [quick]", a2);

                const string modeX = "//button[@id='mode']";
                const string verifyX = "//button[@id='mode'][@aria-pressed='true']";
                string d1 = Ask(b, "//textarea[@id='prompt']", "//div[@class='ai']", modeX, verifyX, "deep1", 1200, 15000);
                Check("mode: off -> clicked on -> reply is deep", d1 == "echo:deep1 [deep]", d1);
                string d2 = Ask(b, "//textarea[@id='prompt']", "//div[@class='ai']", modeX, verifyX, "deep2", 1200, 15000);
                Check("mode: already on -> NOT toggled off", d2 == "echo:deep2 [deep]", d2);
                b.ExecuteScript("document.getElementById('mode').setAttribute('aria-pressed','false');");
                bool mthrew = false;
                try { Ask(b, "//textarea[@id='prompt']", "//div[@class='ai']", "//button[@id='nomode']", verifyX, "x", 500, 2000); } catch { mthrew = true; }
                int replies = b.Count("//div[@class='ai']");
                Check("mode: control missing -> refuses, nothing sent", mthrew && replies == 4, replies.ToString());

                // positive control: a wrong reply selector must fail, not pass vacuously
                bool threw = false;
                try { Ask(b, "//textarea[@id='prompt']", "//div[@class='ghost']", "x", 500, 2000); } catch { threw = true; }
                Check("ask: wrong selector fails loudly", threw, "expected timeout");
            }
            finally { b.Quit(); }

            Console.WriteLine();
            Console.WriteLine("RESULT  " + _pass + " passed, " + _fail + " failed");
            return _fail == 0 ? 0 : 1;
        }
    }
}
