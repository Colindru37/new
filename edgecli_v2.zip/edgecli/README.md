# edgecli — Edge as a CLI

On a machine where nothing can be installed, Edge is the one runtime you have:
JS engine, network, your SSO sessions, renderer, PDF printer. This makes all of it
reachable from a PowerShell prompt, so Edge is an engine you script, not an app
you look at. The Copilot web chat is one verb (`edge ask`), not the point.

Files
- `EdgeCli.cs`  W3C WebDriver client, .NET 4.8 BCL only, C# 5 (Add-Type loads it).
  Superset of `pythontoc/webdriver/WebDriverClient.cs`: + ExecuteScript, Screenshot,
  PrintToPdf, page source, elements/count, tabs, EnsureSingleFreshTab.
- `edge.ps1`  dot-source it; `edge <verb>`; config blocks `$EdgeCfg` + `$AskCfg` at the top.
- `edge.selftest.ps1`  run on the target machine, proves the PS layer on `selftest/page.html`.
- `selftest/Program.cs`  the same checks as a mono program (what was executed here).

Proven on the build box (Linux, mono, geckodriver + headless Firefox 157): 19/19, see selftest/Program.cs.
edge.selftest.ps1: 14/14 on the target (Edge 157, PS 5.1) as of v2.

Target setup
1. Put the folder anywhere; set `$EdgeCfg.Driver` to the msedgedriver.exe the bots use and
   `$EdgeCfg.Profile` to the profile copy. Driver major version must match Edge.
2. `powershell -ExecutionPolicy Bypass -File .\edge.selftest.ps1` → expect 15/15.
3. `$AskCfg` ships filled for the Microsoft 365 Copilot chat (probed 2026-11-09). If a
   verb stops finding things, `edge open <url>` + `edge probe` shows the new names.
4. Think Deeper: `$AskCfg.Mode` is clicked before EVERY send unless `$AskCfg.ModeVerify`
   already matches; if it cannot be activated, ask refuses to send (never silently auto).
   If the mode lives in a dropdown, set `$AskCfg.ModeOpen` to the opener. Confirm the
   labels with `edge probe` (it lists think/deep/quick/mode/model controls with their
   aria-pressed/checked state). On M365 Copilot the picker is a dropdown ("Auto, Model
   Selector" -> "Think deeper, Model Selector"), handled via ModeOpen + ModeVerify.

Session model: one shell = one Edge (Add-Type state lives as long as the shell).
Start closes the news/start tab and any restored tabs: exactly one fresh tab, always.
