# edge.ps1 — Edge as a CLI. Windows PowerShell 5.1, .NET Framework 4.8, nothing to install.
#
#   . C:\path\edgecli\edge.ps1          (dot-source once per shell)
#   edge open https://example.com
#   edge js "return document.title"
#   edge text "//h1"
#   edge shot C:\tmp\page.png
#   edge ask "explain this error: ..."
#   Get-Content err.txt | edge ask "what does this mean?"
#   edge help
#
# One shell = one Edge. The first verb starts msedgedriver + Edge on the profile
# COPY below (your logins come along); every later verb reuses that session;
# `edge quit` or closing the shell ends it. On start the browser is reduced to
# exactly one fresh tab: the news/start tab and any restored tabs are closed.

$script:EdgeCfg = @{
    Driver   = 'C:\Tools\msedgedriver.exe'          # the driver the Selenium bots already use
    Profile  = 'C:\Tools\EdgeProfileCopy'           # COPY of the real profile ('' = clean profile, no SSO)
    Headless = $false                               # $true hides the window (SSO pages may still need a look)
    Port     = 9515
    Browser  = 'edge'                               # 'firefox' for a geckodriver test bed
}

# `edge ask` — the chat verb. Selectors are XPath. Fix them once with F12 for
# the Copilot you use (run `edge open <url>` then `edge probe` to see candidates).
$script:AskCfg = @{
    # Probed on the Microsoft 365 Copilot chat, 2026-11-09. If Microsoft moves
    # things, `edge probe` on the page shows the new names.
    Url        = 'https://m365.cloud.microsoft/chat'
    Input      = "//*[@id='m365-chat-editor-target-element']"                      # contenteditable span, role=textbox
    Reply      = "//div[contains(@class,'fai-CopilotMessage__content')]"           # one per Copilot answer
    # Mode: forced ON before EVERY send (auto is the weak model). The model picker is a
    # dropdown button labelled "<current>, Model Selector"; its text flips Auto -> Think deeper.
    ModeOpen   = "//button[contains(@aria-label,'Model Selector')]"
    Mode       = "//*[(@role='menuitemradio' or @role='menuitem' or @role='option' or @role='radio') and contains(translate(normalize-space(.),'D','d'),'Think deeper')]"
    ModeVerify = "//button[contains(@aria-label,'Model Selector') and contains(translate(normalize-space(.),'D','d'),'Think deeper')]"
    SettleMs   = 3000      # reply counts as finished when its text is unchanged this long
    TimeoutMs  = 300000    # Think deeper can take minutes
}

if (-not ('EdgeCli.Browser' -as [type])) {
    Add-Type -Path (Join-Path $PSScriptRoot 'EdgeCli.cs') `
        -ReferencedAssemblies 'System.Net.Http.dll', 'System.Web.Extensions.dll'
}

function Get-Edge {
    $b = [EdgeCli.Browser]::Current
    if ($b -ne $null -and $b.IsOpen) { return $b }
    $b = New-Object EdgeCli.Browser
    $bargs = @()
    if ($script:EdgeCfg.Profile) {
        if ($script:EdgeCfg.Browser -eq 'edge') { $bargs += ('--user-data-dir=' + $script:EdgeCfg.Profile) }
        else { $bargs += '-profile'; $bargs += $script:EdgeCfg.Profile }
    }
    $b.Start($script:EdgeCfg.Driver, [int]$script:EdgeCfg.Port, [bool]$script:EdgeCfg.Headless,
             $script:EdgeCfg.Browser, [string[]]$bargs)
    [EdgeCli.Browser]::Current = $b
    return $b
}

# Put text into an input without typing it key by key (so newlines don't submit
# and React/Lexical editors see a proper input event), then press Enter.
function Invoke-EdgeAsk([string]$Prompt) {
    $b = Get-Edge
    $cfg = $script:AskCfg
    if (-not $b.GetUrl().StartsWith($cfg.Url)) {
        $b.Navigate($cfg.Url)
        if (-not $b.WaitForElement($cfg.Input, 30000)) { throw "ask: input not found: $($cfg.Input)" }
    }
    if ($cfg.Mode) {
        if ($b.Count($cfg.ModeVerify) -eq 0) {
            if ($cfg.ModeOpen) { $b.Click($cfg.ModeOpen); Start-Sleep -Milliseconds 400 }
            if ($b.Count($cfg.Mode) -eq 0) { throw "ask: mode control not found: $($cfg.Mode)" }
            $b.Click($cfg.Mode); Start-Sleep -Milliseconds 400
            if ($b.Count($cfg.ModeVerify) -eq 0) { throw "ask: mode did not activate (refusing to send in auto): $($cfg.ModeVerify)" }
        }
    }
    $before = $b.Count($cfg.Reply)
    $set = @'
var el = document.evaluate(arguments[0], document, null, 9, null).singleNodeValue;
if (!el) return 'NOINPUT';
el.focus();
if (el.isContentEditable) { document.execCommand('selectAll', false, null); document.execCommand('insertText', false, arguments[1]); }
else {
  var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, arguments[1]);
  el.dispatchEvent(new Event('input', { bubbles: true }));
}
return 'OK';
'@
    $r = $b.ExecuteScript($set, @($cfg.Input, $Prompt))
    if ($r -ne 'OK') { throw "ask: could not fill input ($r)" }
    $b.SendKeys($cfg.Input, [EdgeCli.Browser]::EnterKey)

    $waited = 0
    while ($b.Count($cfg.Reply) -le $before) {
        Start-Sleep -Milliseconds 250; $waited += 250
        if ($waited -gt $cfg.TimeoutMs) { throw 'ask: no reply appeared' }
    }
    $last = $null; $stable = 0
    while ($stable -lt $cfg.SettleMs) {
        $all = $b.GetElementsText($cfg.Reply)
        $now = $all[$all.Count - 1]
        if ($now -eq $last) { $stable += 250 } else { $stable = 0; $last = $now }
        Start-Sleep -Milliseconds 250; $waited += 250
        if ($waited -gt $cfg.TimeoutMs) { break }
    }
    return $last
}

$script:ProbeJs = @'
var out = [];
var q = document.querySelectorAll('textarea, input[type=text], [contenteditable="true"], [role="textbox"]');
for (var i = 0; i < q.length; i++) { var e = q[i];
  out.push('INPUT  <' + e.tagName.toLowerCase() + '> id=' + (e.id||'-') + ' role=' + (e.getAttribute('role')||'-') +
           ' aria-label=' + (e.getAttribute('aria-label')||'-') + ' placeholder=' + (e.getAttribute('placeholder')||'-')); }
var bs = document.querySelectorAll('button, [role=button], [role=radio], [role=switch], [role=menuitemradio], [role=option]');
for (var j = 0; j < bs.length; j++) { var el = bs[j]; var l = ((el.getAttribute('aria-label')||'') + ' | ' + (el.title||'') + ' | ' + (el.textContent||'')).replace(/\s+/g,' ').trim();
  if (/send|submit|trimite|think|deep|quick|mode|smart|model|reason/i.test(l)) out.push('CTRL   <' + el.tagName.toLowerCase() + '> role=' + (el.getAttribute('role')||'-') + ' pressed=' + (el.getAttribute('aria-pressed')||el.getAttribute('aria-checked')||el.getAttribute('aria-selected')||'-') + ' testid=' + (el.getAttribute('data-testid')||'-') + ' :: ' + l.substring(0,90)); }
var d = document.querySelectorAll('[data-content], [data-message-author-role], [data-testid*="message" i], [class*="message" i]');
var seen = {}; for (var k = 0; k < d.length; k++) { var el = d[k];
  var key = el.tagName.toLowerCase() + ' ' + (el.getAttribute('data-content')||el.getAttribute('data-message-author-role')||el.getAttribute('data-testid')||el.className.toString().substring(0,50));
  if (!seen[key]) { seen[key] = 1; out.push('MSG    ' + key); } }
return out.join('\n');
'@

function edge {
    [CmdletBinding()]
    param(
        [Parameter(Position = 0)][string]$Verb = 'help',
        [Parameter(Position = 1, ValueFromRemainingArguments = $true)][string[]]$Rest,
        [Parameter(ValueFromPipeline = $true)]$InputObject
    )
    begin { $piped = New-Object System.Collections.ArrayList }
    process { if ($InputObject -ne $null) { [void]$piped.Add([string]$InputObject) } }
    end {
        # @() on both sides: a one-element array coming out of an if-statement is
        # unrolled to a scalar, and then $a[0] is the first CHARACTER (-> https://f).
        $a = @(); if ($Rest) { $a = @($Rest) }
        $tail = ''; if ($a.Count -gt 1) { $tail = ($a[1..($a.Count-1)] -join ' ') }
        $joined = ($a -join ' ')
        if ($piped.Count -gt 0) { $joined = ($joined + "`n`n" + ($piped -join "`n")).Trim() }
        switch ($Verb) {
            'start' { [void](Get-Edge); 'edge: session open' }
            'quit'  { $b = [EdgeCli.Browser]::Current; if ($b) { $b.Quit() }; [EdgeCli.Browser]::Current = $null; 'edge: closed' }
            'open'  { $u = $a[0]; if ($u -notmatch '^[a-z]+:') { $u = 'https://' + $u }; (Get-Edge).Navigate($u); (Get-Edge).GetTitle() }
            'url'   { (Get-Edge).GetUrl() }
            'title' { (Get-Edge).GetTitle() }
            'html'  { (Get-Edge).GetPageSource() }
            'js'    { $s = $a[0]; if ($s -notmatch '\breturn\b') { $s = 'return (' + $s + ')' }
                      $rest = @(); if ($a.Count -gt 1) { $rest = @($a[1..($a.Count-1)]) }
                      (Get-Edge).ExecuteScript($s, [object[]]$rest) }
            'text'  { (Get-Edge).GetElementText($a[0]) }
            'texts' { (Get-Edge).GetElementsText($a[0]) }
            'count' { (Get-Edge).Count($a[0]) }
            'click' { (Get-Edge).Click($a[0]) }
            'type'  { (Get-Edge).SendKeys($a[0], $tail) }
            'enter' { (Get-Edge).SendKeysAndEnter($a[0], $tail) }
            'wait'  { $ms = if ($a.Count -gt 1) { [int]$a[1] } else { 10000 }; (Get-Edge).WaitForElement($a[0], $ms) }
            'shot'  { $p = [IO.Path]::GetFullPath($(if ($a) { $a[0] } else { 'edge.png' })); (Get-Edge).Screenshot($p); $p }
            'pdf'   { $p = [IO.Path]::GetFullPath($(if ($a) { $a[0] } else { 'edge.pdf' })); (Get-Edge).PrintToPdf($p); $p }
            'tab'   { (Get-Edge).NewTab() | Out-Null; (Get-Edge).SwitchToWindow(((Get-Edge).GetWindowHandles() | Select-Object -Last 1)) }
            'tabs'  { (Get-Edge).GetWindowHandles() }
            'close' { (Get-Edge).CloseTab() }
            'ask'   { Invoke-EdgeAsk $joined }
            'probe' { (Get-Edge).ExecuteScript($script:ProbeJs) }
            default {
@"
edge <verb> ...        one shell = one Edge; first verb starts it, 'edge quit' ends it
  open <url>           navigate (https:// assumed)          url | title | html
  js <script> [args]   run JS in the page, prints the value (arguments[0..] = args)
  text <xpath>         text of first match                  texts <xpath>  all matches
  count <xpath>        matches                               wait <xpath> [ms]
  click <xpath>        type <xpath> <text>                   enter <xpath> <text>
  shot [file.png]      screenshot                            pdf [file.pdf]  print page
  tab | tabs | close   new tab / list / close current
  ask <prompt>         chat: fill input, Enter, wait for the reply to settle, print it
                       pipe text in:  Get-Content x.log | edge ask "what broke?"
  probe                list input / mode+send controls / message candidates (to fill AskCfg)
  start | quit
config: `$EdgeCfg (driver, profile copy, headless)   `$AskCfg (url + xpaths for ask)
"@
            }
        }
    }
}
