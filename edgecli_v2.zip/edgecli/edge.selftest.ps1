# edge.selftest.ps1 — run ON the target machine:  powershell -ExecutionPolicy Bypass -File .\edge.selftest.ps1
# Proves the PowerShell layer against selftest\page.html (no network, no Copilot).
# Uses the driver/profile from edge.ps1's $EdgeCfg but overrides the ask selectors.
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'edge.ps1')
$pass = 0; $fail = 0
function Check($name, $ok, $detail) {
    if ($ok) { $script:pass++; "PASS  $name" } else { $script:fail++; "FAIL  $name  -> $detail" }
}
$page = (New-Object Uri ([IO.Path]::Combine($PSScriptRoot, 'selftest', 'page.html'))).AbsoluteUri
$script:AskCfg = @{ Url = $page; Input = "//textarea[@id='prompt']"; Reply = "//div[@class='ai']"; Mode = ''; ModeVerify = ''; ModeOpen = ''; SettleMs = 1200; TimeoutMs = 15000 }
try {
    edge start | Out-Null
    Check 'start -> one tab' ((edge tabs).Count -eq 1) ((edge tabs).Count)
    $t = edge open $page
    Check 'open/title' ($t -eq 'EdgeCli Test Page') $t
    $v = edge js 'arguments[0] * 7 + document.querySelectorAll(".row").length' 6
    Check 'js value' ([int]$v -eq 45) $v
    $rows = edge texts "//li[@class='row']"
    Check 'texts' ($rows.Count -eq 3 -and $rows[1] -eq 'beta') ($rows -join '|')
    Check 'count' ((edge count '//li') -eq 3) ''
    $png = edge shot (Join-Path $env:TEMP 'edgecli.png')
    $pb = [IO.File]::ReadAllBytes($png)
    Check 'screenshot is PNG' ($pb.Length -gt 100 -and $pb[1] -eq 80 -and $pb[2] -eq 78 -and $pb[3] -eq 71) $pb.Length
    $pdf = edge pdf (Join-Path $env:TEMP 'edgecli.pdf')
    $db = [IO.File]::ReadAllBytes($pdf)
    Check 'print is PDF' ($db.Length -gt 100 -and $db[0] -eq 37 -and $db[1] -eq 80) $db.Length
    edge tab; Check 'tab -> 2' ((edge tabs).Count -eq 2) ''
    edge close; Check 'close -> 1' ((edge tabs).Count -eq 1) ''
    edge open $page | Out-Null
    $a1 = edge ask hello
    Check 'ask settles streamed reply' ($a1 -eq 'echo:hello [quick]') $a1
    $a2 = 'line two' | edge ask 'piped:'
    Check 'ask with piped text reads NEW reply' ($a2.StartsWith('echo:piped:') -and $a2.EndsWith('line two [quick]')) $a2   # getText collapses newlines; no -like: [quick] is a wildcard class
    $script:AskCfg.Mode = "//button[@id='mode']"; $script:AskCfg.ModeVerify = "//button[@id='mode'][@aria-pressed='true']"
    $d1 = edge ask deep1
    Check 'mode: off -> clicked on -> deep reply' ($d1 -eq 'echo:deep1 [deep]') $d1
    $d2 = edge ask deep2
    Check 'mode: already on -> not toggled off' ($d2 -eq 'echo:deep2 [deep]') $d2
    edge js "document.getElementById('mode').setAttribute('aria-pressed','false'); return 1" | Out-Null
    $script:AskCfg.Mode = "//button[@id='nomode']"
    $threw = $false; try { edge ask x | Out-Null } catch { $threw = $true }
    Check 'mode: control missing -> refuses to send' ($threw -and (edge count "//div[@class='ai']") -eq 4) ''
    $script:AskCfg.Mode = ''
} finally { edge quit | Out-Null }
""
"RESULT  $pass passed, $fail failed"
if ($fail -gt 0) { exit 1 }
