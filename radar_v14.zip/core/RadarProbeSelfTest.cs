// Self-test for ProbeCore: the hook sees a thrown-and-caught exception, keeps its type/message/stack,
// does not re-enter itself, marks land in order, Report never throws, Install twice keeps one hook.
using System;
using System.IO;

public static class RadarProbeSelfTest
{
    static int fails;
    static void Ok(string name, bool cond, string info)
    {
        if (!cond) fails++;
        Console.WriteLine((cond ? "PASS " : "FAIL ") + name + (info == null ? "" : " | " + info));
    }

    sealed class DemoWriteStage
    {
        public void Run(string element) { throw new InvalidOperationException("Failed to perform step 1 in Write Stage 'Enter Amount' - Element not found: " + element); }
    }

    public static int Main()
    {
        var root = Path.Combine(Path.GetTempPath(), "RadarProbeSelfTest_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        var folder = ProbeCore.Install(root, 2);
        Ok("install returns a folder", Directory.Exists(folder), folder);
        Ok("hooked", ProbeCore.Hooked, null);
        bool live = ProbeCore.SelfCheck();
        Ok("Live matches the self-check", ProbeCore.Live == live, null);
        var log0 = File.ReadAllText(Path.Combine(folder, "probe.log"));
        Ok("header says whether the runtime fires first-chance events", log0.Contains("first-chance events: " + (live ? "YES" : "NO")), null);
        if (!live)
        {
            // Mono has the event but never raises it; the .NET Framework runtime (Blue Prism, PowerShell) does.
            Console.WriteLine("SKIP hook checks: this runtime never raises FirstChanceException (expected on mono, a FAIL on Windows .NET)");
            Ok("Live property reports the dead hook", !ProbeCore.Live, null);
            var bad0 = ProbeCore.Install(Path.Combine(Path.GetTempPath(), "x") + "\0x", 1);
            Ok("unwritable root -> ERROR: text, no throw", bad0.StartsWith("ERROR:"), bad0);
            Console.WriteLine(fails == 0 ? "SELF-TEST PASS (hook untestable here)" : "SELF-TEST FAIL (" + fails + ")");
            return fails == 0 ? 0 : 1;
        }
        int before = ProbeCore.Count;
        ProbeCore.Mark("before demo write");
        try { new DemoWriteStage().Run("Textbox - Amount"); }
        catch (InvalidOperationException) { }
        ProbeCore.Mark("after demo write (caught)");
        Ok("one exception counted", ProbeCore.Count == before + 1, ProbeCore.Count.ToString());
        var log = File.ReadAllText(Path.Combine(folder, "probe.log"));
        Ok("type recorded", log.Contains("type: System.InvalidOperationException"), null);
        Ok("message recorded", log.Contains("Write Stage 'Enter Amount'"), null);
        Ok("non-System frame kept (the throwing class)", log.Contains("DemoWriteStage.Run"), null);
        int iMark1 = log.IndexOf("MARK before demo write"), iRec = log.IndexOf("--- #"), iMark2 = log.IndexOf("MARK after demo write");
        Ok("marks bracket the record", iMark1 >= 0 && iMark1 < iRec && iRec < iMark2, iMark1 + "/" + iRec + "/" + iMark2);
        Ok("screenshot attempted (ok or skipped with a reason)", log.Contains("screenshot: shot_0001.png"), null);
        // dedupe of screenshots: same type+message again -> no second shot; different message -> second shot
        try { new DemoWriteStage().Run("Textbox - Amount"); } catch (InvalidOperationException) { }
        try { new DemoWriteStage().Run("Textbox - Account"); } catch (InvalidOperationException) { }
        try { throw new ApplicationException("third distinct"); } catch (ApplicationException) { }
        log = File.ReadAllText(Path.Combine(folder, "probe.log"));
        Ok("screenshots capped at maxShots=2 and deduped", log.Contains("shot_0003.png") && !log.Contains("shot_0002.png") && !log.Contains("shot_0004.png"), null);
        // a handler that throws internally must not recurse: force by passing a null-ish situation via Report on a weird state
        var rep = ProbeCore.Report();
        Ok("report lists counts", rep.Contains("System.InvalidOperationException") && rep.Contains("exceptions seen: 4"), rep.Split('\n')[1]);
        Ok("report.txt written", File.Exists(Path.Combine(folder, "report.txt")), null);
        // second Install: new folder, counters reset, still one hook (a second hook would double-count)
        var folder2 = ProbeCore.Install(root, 1);
        try { throw new ApplicationException("after reinstall"); } catch (ApplicationException) { }
        Ok("reinstall: counters reset and single hook", ProbeCore.Count == 1, ProbeCore.Count.ToString());
        Ok("reinstall: logs into the new folder", File.ReadAllText(Path.Combine(folder2, "probe.log")).Contains("after reinstall"), null);
        // never throws with an unwritable root
        var bad = ProbeCore.Install(Path.Combine(Path.GetTempPath(), "RadarProbeSelfTest_file_" + Guid.NewGuid().ToString("N")) + "\0x", 1);
        Ok("unwritable root -> ERROR: text, no throw", bad.StartsWith("ERROR:"), bad);
        try { Directory.Delete(root, true); } catch (Exception) { }
        Console.WriteLine(fails == 0 ? "SELF-TEST PASS" : "SELF-TEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }
}
