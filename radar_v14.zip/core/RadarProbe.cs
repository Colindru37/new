// Radar Probe: hook the .NET runtime that Blue Prism runs in and log EVERY exception at the moment it is thrown.
// Experiment, not product: answers "what does a first-chance hook see inside Automate?"
//   Install(root, maxShots)  subscribes once (static, survives for the life of the Automate process),
//                            opens <root>\<machine>\probe_<stamp>\probe.log and returns that folder
//   Mark(text)               writes a marker line so the log can be read against the process flow
//   Report()                 counts per exception type + the last records, also written to report.txt
// Each record: seq, utc time, managed thread, exception type, message, inner exception, and the call
// stack at the throw site with the System.* frames removed (Blue Prism's own frames stay: they say which
// kind of stage was running). Up to maxShots screenshots, one per distinct type+message.
// Never throws, never re-enters itself (an exception inside the handler would fire the handler again).
// BCL only, C# 5 (Blue Prism code stages / PowerShell Add-Type).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class ProbeCore
{
    static readonly object Gate = new object();
    static bool _hooked;
    static string _folder;
    static int _maxShots = 5, _shots, _seq, _cap = 5000;
    static readonly HashSet<string> ShotKeys = new HashSet<string>();
    static readonly Dictionary<string, int> PerType = new Dictionary<string, int>();
    static readonly List<string> Last = new List<string>();
    [ThreadStatic] static bool _busy;

    public static string Folder { get { lock (Gate) return _folder; } }
    public static int Count { get { lock (Gate) return _seq; } }
    public static bool Hooked { get { lock (Gate) return _hooked; } }
    static bool _live;
    /// <summary>True when the runtime actually delivered the self-check exception to the hook (set by Install).</summary>
    public static bool Live { get { lock (Gate) return _live; } }

    public static string Install(string root, int maxShots)
    {
        try
        {
            if (string.IsNullOrEmpty(root)) root = Path.Combine(Path.GetTempPath(), "Radar");
            var folder = Path.Combine(Path.Combine(root, Environment.MachineName),
                                      "probe_" + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            Directory.CreateDirectory(folder);
            lock (Gate)
            {
                _folder = folder; _maxShots = maxShots; _shots = 0; _seq = 0;
                ShotKeys.Clear(); PerType.Clear(); Last.Clear();
                if (!_hooked)
                {
                    AppDomain.CurrentDomain.FirstChanceException += OnFirstChance;
                    _hooked = true;
                }
            }
            var head = new StringBuilder();
            head.AppendLine("# Radar probe " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            head.AppendLine("# machine " + Environment.MachineName + " user " + Environment.UserName
                            + " pid " + Process.GetCurrentProcess().Id + " clr " + Environment.Version
                            + " 64bit " + Environment.Is64BitProcess);
            string host = "?";
            try { host = Process.GetCurrentProcess().MainModule.FileName; } catch (Exception) { }
            head.AppendLine("# host " + host);
            head.AppendLine("# appdomain " + AppDomain.CurrentDomain.FriendlyName + " thread " + Thread.CurrentThread.ManagedThreadId);
            bool live = SelfCheck();
            lock (Gate) _live = live;
            head.AppendLine("# hook installed; runtime raises first-chance events: " + (live ? "YES" : "NO (this runtime never fires the event; nothing will be logged)"));
            Append(head.ToString());
            return folder;
        }
        catch (Exception ex) { return "ERROR: " + ex.GetType().Name + ": " + ex.Message; }
    }

    sealed class ProbeCheckException : Exception { public ProbeCheckException() : base("probe self-check") { } }
    [ThreadStatic] static bool _sawCheck;
    /// <summary>Throw and catch a private exception; true when the handler saw it (the runtime fires the event).</summary>
    public static bool SelfCheck()
    {
        _sawCheck = false;
        try { throw new ProbeCheckException(); } catch (ProbeCheckException) { }
        return _sawCheck;
    }

    public static void Mark(string text)
    {
        try { Append("=== " + DateTime.Now.ToString("HH:mm:ss.fff") + " MARK " + (text ?? "") + Environment.NewLine); }
        catch (Exception) { }
    }

    public static string Report()
    {
        try
        {
            var sb = new StringBuilder();
            lock (Gate)
            {
                sb.AppendLine("probe folder: " + _folder);
                sb.AppendLine("exceptions seen: " + _seq + "  screenshots: " + _shots);
                var keys = new List<string>(PerType.Keys); keys.Sort();
                foreach (var k in keys) sb.AppendLine("  " + PerType[k].ToString().PadLeft(5) + "  " + k);
                sb.AppendLine("last records:");
                foreach (var l in Last) sb.AppendLine(l);
            }
            var txt = sb.ToString();
            try { if (_folder != null) File.WriteAllText(Path.Combine(_folder, "report.txt"), txt, Encoding.UTF8); } catch (Exception) { }
            return txt;
        }
        catch (Exception ex) { return "ERROR: " + ex.GetType().Name + ": " + ex.Message; }
    }

    static void OnFirstChance(object sender, FirstChanceExceptionEventArgs a)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            var ex = a.Exception;
            if (ex is ProbeCheckException) { _sawCheck = true; return; }
            int seq; bool shoot; string key;
            string type = ex == null ? "(null)" : ex.GetType().FullName;
            string msg = OneLine(ex == null ? "" : ex.Message, 600);
            lock (Gate)
            {
                if (_folder == null || _seq >= _cap) { if (_seq == _cap) { _seq++; AppendRaw("# cap reached, logging stopped" + Environment.NewLine); } return; }
                seq = ++_seq;
                int n; PerType.TryGetValue(type, out n); PerType[type] = n + 1;
                key = type + "\u0001" + msg;
                shoot = _shots < _maxShots && ShotKeys.Add(key);
                if (shoot) _shots++;
            }
            var sb = new StringBuilder();
            sb.Append("--- #").Append(seq).Append(' ').Append(DateTime.Now.ToString("HH:mm:ss.fff"))
              .Append(" thread ").Append(Thread.CurrentThread.ManagedThreadId).AppendLine();
            sb.Append("type: ").AppendLine(type);
            sb.Append("message: ").AppendLine(msg);
            if (ex != null && ex.InnerException != null)
                sb.Append("inner: ").Append(ex.InnerException.GetType().FullName).Append(": ").AppendLine(OneLine(ex.InnerException.Message, 300));
            if (ex != null && ex.TargetSite != null && ex.TargetSite.DeclaringType != null)
                sb.Append("thrown by: ").Append(ex.TargetSite.DeclaringType.FullName).Append('.').AppendLine(ex.TargetSite.Name);
            sb.AppendLine("stack (System.* frames removed):");
            sb.Append(Frames());
            if (shoot)
            {
                var file = Path.Combine(_folder, "shot_" + seq.ToString("0000") + ".png");
                sb.Append("screenshot: ").Append(Path.GetFileName(file)).Append(' ').AppendLine(Screenshot(file));
            }
            var rec = sb.ToString();
            lock (Gate) { Last.Add("#" + seq + " " + type + ": " + OneLine(msg, 160)); if (Last.Count > 40) Last.RemoveAt(0); }
            Append(rec);
        }
        catch (Exception) { }
        finally { _busy = false; }
    }

    static string Frames()
    {
        var sb = new StringBuilder();
        try
        {
            var st = new StackTrace(2, false);
            int total = st.FrameCount, kept = 0;
            for (int i = 0; i < total && kept < 40; i++)
            {
                var m = st.GetFrame(i).GetMethod();
                if (m == null) continue;
                var t = m.DeclaringType;
                string tn = t == null ? "?" : t.FullName ?? t.Name;
                if (t == ProbeType) continue;
                if (tn.StartsWith("System.") || tn.StartsWith("Microsoft.") || tn == "System") continue;
                sb.Append("    ").Append(tn).Append('.').AppendLine(m.Name);
                kept++;
            }
            sb.Append("    (").Append(kept).Append(" of ").Append(total).AppendLine(" frames)");
        }
        catch (Exception e) { sb.AppendLine("    (stack unavailable: " + e.GetType().Name + ")"); }
        return sb.ToString();
    }
    static readonly Type ProbeType = typeof(ProbeCore);

    static string OneLine(string s, int max)
    {
        if (s == null) return "";
        s = s.Replace("\r", " ").Replace("\n", " ");
        return s.Length > max ? s.Substring(0, max) + "..." : s;
    }

    static void Append(string text) { lock (Gate) AppendRaw(text); }
    static void AppendRaw(string text)
    {
        if (_folder == null) return;
        try { File.AppendAllText(Path.Combine(_folder, "probe.log"), text, Encoding.UTF8); } catch (Exception) { }
    }

    const int SM_XVIRTUALSCREEN = 76, SM_YVIRTUALSCREEN = 77, SM_CXVIRTUALSCREEN = 78, SM_CYVIRTUALSCREEN = 79;
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int n);
    static string Screenshot(string file)
    {
        if (Environment.OSVersion.Platform != PlatformID.Win32NT) return "skipped (not Windows)";
        try
        {
            int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
            int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
            if (w <= 0 || h <= 0) return "no screen (" + w + "x" + h + ")";
            using (var bmp = new System.Drawing.Bitmap(w, h))
            {
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                    g.CopyFromScreen(x, y, 0, 0, new System.Drawing.Size(w, h));
                bmp.Save(file, System.Drawing.Imaging.ImageFormat.Png);
            }
            return "ok";
        }
        catch (Exception ex) { return "failed (" + ex.GetType().Name + ": " + ex.Message + ")"; }
    }
}
