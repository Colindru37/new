# Radar discovery self-test, in-process via Add-Type (no binary is produced or started).
# Run in Windows PowerShell 5.1 from this folder:  powershell -ExecutionPolicy Bypass -File .\RadarDiscoverSelfTest.ps1
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -Path (Join-Path $here 'RadarDiscover.cs'), (Join-Path $here 'RadarDiscoverSelfTest.cs') -ReferencedAssemblies 'System.Core'
$rc = [RadarDiscoverSelfTest]::Main()
Write-Host ("exit code " + $rc)
