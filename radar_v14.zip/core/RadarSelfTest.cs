// Self-test for RadarCore.cs: simulates the Blue Prism runtime path
//   action entry -> Record ... -> write stage dies -> Recover -> Dump(page data items) -> folder.
// Exit code 0 = PASS. Run: ./build.sh
using System;
using System.IO;
using System.Web.Script.Serialization;

public static class RadarSelfTest
{
    // stand-ins for the frames Blue Prism produces: the generated object class with its Run_<stage> method,
    // and the resource connection thread whose socket errors are noise
    sealed class Demo_API { public void Run_JSON_To_Customer() { throw new ArgumentException("Invalid JSON primitive: ."); } }
    sealed class PersistentConnection { public void CommsThread() { throw new System.Net.Sockets.SocketException(11001); } }

    static int fails = 0;
    static void Ok(string name, bool cond, string info = "")
    {
        if (!cond) fails++;
        Console.WriteLine((cond ? "PASS " : "FAIL ") + name + (info.Length > 0 ? " | " + info : ""));
    }

    public static int Main()
    {
        var root = Path.Combine(Path.GetTempPath(), "radar_selftest_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        RadarCore.Configure(root, 50);
        Ok("configure: root + capacity", RadarCore.Root == root && RadarCore.Capacity == 50);

        // 1. ring semantics: 60 records into capacity 50 -> 50 kept, 10 dropped, oldest kept is #11
        for (int i = 1; i <= 60; i++) RadarCore.Record("step " + i, "value=" + i);
        Ok("ring: keeps capacity", RadarCore.Count == 50, "count=" + RadarCore.Count);
        Ok("ring: counts dropped", RadarCore.Dropped == 10, "dropped=" + RadarCore.Dropped);
        var trail = RadarCore.Trail();
        Ok("ring: oldest kept is #11", trail.StartsWith("") && trail.Contains("| #11 |") && !trail.Contains("| #10 |"));
        Ok("ring: newest is #60", trail.TrimEnd('\n').EndsWith("value=60"));

        // 2. newline in detail does not break the one-line-per-entry trail
        RadarCore.Record("multi", "a\nb\r\nc");
        Ok("trail: newlines escaped", RadarCore.Trail().Split('\n').Length == 51, "lines=" + RadarCore.Trail().Split('\n').Length);

        // 3. the write-failure path: action entry recorded, write dies, recover dumps page data items
        RadarCore.Record("action:Enter Transfer", "Account=DE123;Amount=50,00");
        string exDetail = "Internal : Failed to perform step 2 in Write Stage 'Enter Amount' on page 'Enter Transfer' - Element not found";
        string data = "i_txt_Account=DE123\ni_txt_Amount=50,00\nflg_Window Ready=True\nexpr:Enter Amount/2=[i_txt_Amount] & \" EUR\"";
        string folder = RadarCore.Dump("RAD001 - Radar - Write Failure Demo", "Enter Transfer", "System Exception", exDetail, "Enter Amount", data, true);
        Ok("dump: returns a folder", !folder.StartsWith("ERROR") && Directory.Exists(folder), folder);
        var txtPath = Path.Combine(folder, "incident.txt");
        var jsPath = Path.Combine(folder, "incident.json");
        Ok("dump: incident.txt written", File.Exists(txtPath));
        Ok("dump: incident.json written", File.Exists(jsPath));
        var txt = File.Exists(txtPath) ? File.ReadAllText(txtPath) : "";
        Ok("txt: names the failing stage", txt.Contains("stage     : Enter Amount"));
        Ok("txt: carries the write input (the thing Errors Only loses)", txt.Contains("i_txt_Amount=50,00"));
        Ok("txt: carries the inline expression text", txt.Contains("expr:Enter Amount/2="));
        Ok("txt: carries the trail with action inputs", txt.Contains("action:Enter Transfer | Account=DE123"));
        Ok("txt: trail header counts", txt.Contains("50 kept, 12 dropped, capacity 50"));
        Ok("txt: env fingerprint line (culture, date pattern, decimal, os)", System.Text.RegularExpressions.Regex.IsMatch(txt, @"env       : culture [A-Za-z-]* \(ui [A-Za-z-]*\) date \S+ decimal .+ \| os "), txt.Split((char)10)[10]);
        Ok("json: env field", File.ReadAllText(jsPath).Contains("\"env\": \"culture "));
        bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;
        Ok(win ? "txt: screenshot taken" : "txt: screenshot skipped with reason (not Windows)",
           win ? txt.Contains("screenshot: screenshot.png") && File.Exists(Path.Combine(folder, "screenshot.png"))
               : txt.Contains("screenshot: skipped (not Windows"));

        // 3b. environment snapshot: present, every section answered (value or reason), bounded in time, env.txt beside it
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var env = RadarCore.EnvSnapshot();
            sw.Stop();
            Ok("env: every section present", env.Text.Contains("session   : ") && env.Text.Contains("memory    : ") && env.Text.Contains("this proc : ") && env.Text.Contains("disk      : ")
                                             && env.Text.Contains("network   : ") && env.Text.Contains("clock     : ") && env.Text.Contains("apps      : ") && env.Text.Contains("event log : "), env.Text);
            Ok("env: bounded (< 8 s)", sw.ElapsedMilliseconds < 8000, sw.ElapsedMilliseconds + " ms");
            Ok("env: this process is described", env.Text.Contains(" pid " + System.Diagnostics.Process.GetCurrentProcess().Id + " working set "));
            Ok("env: fields carry session + processes", env.Field("session") != null && env.Field("processes") != null && env.Field("snapshot_ms") != null);
            Ok("env: non-Windows sections say why", win || (env.Text.Contains("memory    : unavailable") && env.Text.Contains("event log : unavailable")));
            Ok("dump: environment section in incident.txt", txt.Contains("--- environment at failure (also env.txt) ---") && txt.Contains("\nsession   : "));
            Ok("dump: env.txt written", File.Exists(Path.Combine(folder, "env.txt")) && File.ReadAllText(Path.Combine(folder, "env.txt")).Contains("snapshot  : took "));
            Ok("json: environment object", File.ReadAllText(jsPath).Contains("\"environment\": { ") && File.ReadAllText(jsPath).Contains("\"file\": \"env.txt\" }"));
        }

        // 4. json is parseable and round-trips the fields
        try
        {
            var ser = new JavaScriptSerializer();
            var obj = ser.DeserializeObject(File.ReadAllText(jsPath)) as System.Collections.Generic.Dictionary<string, object>;
            var ex = obj["exception"] as System.Collections.Generic.Dictionary<string, object>;
            var di = obj["data_items"] as System.Collections.Generic.Dictionary<string, object>;
            var tr = obj["trail"] as object[];
            Ok("json: parses", obj != null);
            Ok("json: exception.stage", ex != null && (string)ex["stage"] == "Enter Amount");
            Ok("json: data_items keyed", di != null && (string)di["i_txt_Amount"] == "50,00" && (string)di["expr:Enter Amount/2"] == "[i_txt_Amount] & \" EUR\"");
            Ok("json: trail length", tr != null && tr.Length == 50, "len=" + (tr == null ? -1 : tr.Length));
            var envj = obj["environment"] as System.Collections.Generic.Dictionary<string, object>;
            Ok("json: environment parses with fields", envj != null && envj.ContainsKey("session") && envj.ContainsKey("processes"));
        }
        catch (Exception e) { Ok("json: parses", false, e.Message); }

        // 5. dump clears the ring; a second failure starts a fresh trail
        Ok("dump: ring cleared", RadarCore.Count == 0 && RadarCore.Dropped == 0);

        // 6. dump never throws: unwritable root -> ERROR string, no exception
        RadarCore.Configure(Path.Combine(txtPath, "not_a_dir"), 0);   // a file as parent -> CreateDirectory fails
        string bad = "threw";
        try { bad = RadarCore.Dump("p", "pg", "System Exception", "d", "s", "", false); } catch (Exception) { }
        Ok("dump: never throws, reports ERROR", bad.StartsWith("ERROR:"), bad);
        Ok("configure: zero capacity keeps previous", RadarCore.Capacity == 50);

        // 7b. two sessions (threads) on one resource never mix, and one dump leaves the other alone
        RadarCore.Configure(root, 50);
        RadarCore.Clear();
        string otherTrail = null; int otherCountAfter = -1;
        var gate = new System.Threading.ManualResetEvent(false);
        var t = new System.Threading.Thread(() =>
        {
            RadarCore.Record("other-session", "x");
            RadarCore.Record("other-session", "y");
            otherTrail = RadarCore.Trail();
            gate.WaitOne();                      // wait until the main session has dumped
            otherCountAfter = RadarCore.Count;
        });
        t.Start();
        while (otherTrail == null) System.Threading.Thread.Sleep(5);
        RadarCore.Record("main-session", "a");
        Ok("sessions: main sees only its own entry", RadarCore.Count == 1 && RadarCore.Trail().Contains("main-session") && !RadarCore.Trail().Contains("other-session"), RadarCore.Trail());
        Ok("sessions: other sees only its own two", otherTrail.Split('\n').Length == 3 && !otherTrail.Contains("main-session"), otherTrail);
        string f3 = RadarCore.Dump("p", "pg", "System Exception", "d", "s", "", false);
        gate.Set(); t.Join();
        Ok("sessions: main dump cleared main only", RadarCore.Count == 0 && otherCountAfter == 2, "other after=" + otherCountAfter);
        Ok("dump: folder is <root>/<machine>/<stamp>_<process>_<stage>", f3.StartsWith(Path.Combine(root, Environment.MachineName.Replace('-', '_'))) || Directory.GetParent(f3).Name.Length > 0, f3);
        Ok("dump: folder sits under the machine subfolder", Directory.GetParent(f3).Parent.FullName == root, f3);

        // 7c. the same exception dumped twice in a row (object, then the process logger) = one folder
        RadarCore.Configure(root, 50);
        RadarCore.Record("step", "before");
        string d1 = RadarCore.Dump("p", "pg", "System Exception", "same detail", "Same Stage", "", false);
        string d2 = RadarCore.Dump("p", "", "System Exception", "same detail", "Same Stage", "", false);
        Ok("dedupe: second dump of the same exception returns the first folder", d1 == d2 && Directory.Exists(d1), d1 + " / " + d2);
        string d2b = RadarCore.Dump("p", "", "System Exception", "same detail", "Calling Action Stage", "", false);
        Ok("dedupe: same detail reported at the PROCESS level (different stage) = same folder", d2b == d1, d2b);
        string d2c = RadarCore.Dump("p", "", "System Exception", "same detail", "Calling Action Stage", "", true);
        bool winShot = Environment.OSVersion.Platform == PlatformID.Win32NT;
        Ok("dedupe: a later dump asking for the screenshot adds it to the existing folder",
           d2c == d1 && (winShot ? File.Exists(Path.Combine(d1, "screenshot.png")) : File.ReadAllText(Path.Combine(d1, "incident.txt")).Contains("skipped (not Windows")), d2c);
        string d3 = RadarCore.Dump("p", "", "System Exception", "other detail", "Same Stage", "", false);
        Ok("dedupe: a different exception gets its own folder", d3 != d1 && Directory.Exists(d3));

        // 7. no-screenshot request is noted, and dump works with empty data/trail
        RadarCore.Configure(root, 5);
        string f2 = RadarCore.Dump("p", "pg", "Business Exception", "d", "s", "", false);
        Ok("dump: empty trail + no capture ok", Directory.Exists(f2) && File.ReadAllText(Path.Combine(f2, "incident.txt")).Contains("skipped (not requested)"));
        Ok("configure: shrink trims ring", RadarCore.Capacity == 5);

        // ---- the runtime hook (live only on .NET Framework; mono never raises FirstChanceException) ----
        RadarCore.Configure(root, 50);
        Ok("hook: status readable", RadarCore.HookStatus.Length > 0, RadarCore.HookStatus);
        if (!RadarCore.HookLive)
        {
            Console.WriteLine("SKIP hook checks: " + RadarCore.HookStatus);
        }
        else
        {
            RadarCore.Clear(); RadarCore.Configure(root, 50);
            RadarCore.Record("action:Parse", "start");
            try { new Demo_API().Run_JSON_To_Customer(); } catch (ArgumentException) { }
            try { new PersistentConnection().CommsThread(); } catch (System.Net.Sockets.SocketException) { }
            var tr = RadarCore.Trail();
            Ok("hook: the code-stage throw is in the trail with object + stage", tr.Contains("throw:ArgumentException | Invalid JSON primitive: . | ") && tr.Contains("Demo_API.JSON To Customer"), tr);
            Ok("hook: the socket noise from the resource connection is ignored", !tr.Contains("SocketException"), tr);
            Ok("hook: counters", RadarCore.HookStatus.Contains("recorded 1"), RadarCore.HookStatus);
            var fh = RadarCore.Dump("p", "pg", "System Exception", "JSON To Customer: Invalid JSON primitive: .", "Get Customer Name", "", false);
            var th = File.ReadAllText(Path.Combine(fh, "incident.txt"));
            Ok("hook: dump lists the throw with its frames", th.Contains("System.ArgumentException: Invalid JSON primitive: .") && th.Contains("thrown in: ") && th.Contains("Demo_API.Run_JSON_To_Customer"), th);
            Ok("hook: throw-time screenshot attached on Windows / noted otherwise", th.Contains("at throw  : screenshot_at_throw.png") || th.Contains("at throw  : none"), th);
            Ok("hook: json carries throws", File.ReadAllText(Path.Combine(fh, "incident.json")).Contains("\"throws\": [\n    { \"at\""));
            Ok("hook: ring of throws cleared by the dump", !RadarCore.Trail().Contains("throw:"), RadarCore.Trail());
        }

        try { Directory.Delete(root, true); } catch (Exception) { }
        Console.WriteLine(fails == 0 ? "SELF-TEST PASS" : "SELF-TEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }
}
