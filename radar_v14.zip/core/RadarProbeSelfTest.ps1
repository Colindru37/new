# Radar probe self-test, in-process via Add-Type (no binary is produced or started).
# Run in Windows PowerShell 5.1 from this folder:  powershell -ExecutionPolicy Bypass -File .\RadarProbeSelfTest.ps1
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -Path (Join-Path $here 'RadarProbe.cs'), (Join-Path $here 'RadarProbeSelfTest.cs') -ReferencedAssemblies 'System.Drawing', 'System.Core'
$rc = [RadarProbeSelfTest]::Main()
Write-Host ("exit code " + $rc)
