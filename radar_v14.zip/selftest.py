"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "1c1a59f146ea7cc3c495e347df9ddeba4de4a5580f8e936a4a8159b7aac9f110",
 "README.md": "c5b90fdf4d1aed10179e5495db2c5476205a9517390fcfc281f92f9ea6689195",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Demo Bank Plain.xml": "354e1fd86502e65808b3b6be3bc05bc372c9373525f3ba83691b93ac5880a49a",
 "bp/BPA Object - House Logging.xml": "30b15194260cb30e60462aba0639e809bbd8f592f002242e1f51a3e3114eda39",
 "bp/BPA Object - Radar Demo Bank.xml": "e8ddbe599b2ca5373f3bfcfd661566b9d125d41868087790271fe3fbbe248629",
 "bp/BPA Object - Radar Probe.xml": "0b147e8d9fef36aea8a64c8ae21fb7e9412083536767f49adf66a9119f46115e",
 "bp/BPA Object - Radar.xml": "9d2a98ad5119ed84d144f0b01f2f972287327c201e85257f77932300b9131559",
 "bp/BPA Process - PRC000 - Radar - API Failure Demo.xml": "f7c140e3e53388a8d44fb1d6bfe7e40a2c9a3703f80abc4702f8c9711dabeac7",
 "bp/BPA Process - PRC000 - Radar - Discover.xml": "44de290ee72b847700579bb3913234af8404f8f9b66cce4436a61f09de8f647b",
 "bp/BPA Process - PRC000 - Radar - House Logging Demo.xml": "4ecf9ede3530ebaac689a8069af49682388fde61cf25ab6aacd7332fe0884f4e",
 "bp/BPA Process - PRC000 - Radar - Probe Demo.xml": "8cadbbc3d6f2f69de01f50e70ea0e5111843fb8378f577a0d9143a10aef93f6d",
 "bp/BPA Process - PRC000 - Radar - Write Failure Demo.xml": "746eab6f06a70a6e453aed18f3f98c2de58fcb238cc9a4c092187ad9f6385c97",
 "core/Radar.cs": "e871a0ac22bcedea47847ec70faa221a0fa221086f856cf047a4ba0b815d04ca",
 "core/RadarDiscover.cs": "7d88c501bb11d053cf92189ff0bf41087cb4e58a110251e5b63f069696e1883b",
 "core/RadarDiscoverSelfTest.cs": "fa60e442e2266acca868d16a8c7ae5b92a285b37755ced4b66c3652a1e23aae6",
 "core/RadarDiscoverSelfTest.ps1": "1d37f131ad699c3e4faa252f50c9ee68f279e39ae35e137fba6b0d4f83942095",
 "core/RadarProbe.cs": "3450e2f298082339c8d03b2b58a7c9fba4c5bac19d7827b4c5ae842715008285",
 "core/RadarProbeSelfTest.cs": "3dfc5fade2fd78c146c8df70a6104d23021b108983166f6229b8948a71ae82b3",
 "core/RadarProbeSelfTest.ps1": "82491e0af7e5c7eff6ffd590253471d2ce642eefccb1b4e00a24becdacc7e7ee",
 "core/RadarSelfTest.cs": "64ce5072c2951b730ee850b55b8d32653b8a9c4231d242554bd6b8782bab8824",
 "core/RadarSelfTest.ps1": "2a7af51a2e6b798ab6cc67a4fd34ab8d7b9e9ba5d2e150a67bea2ebbee442ffe",
 "tools/bpwatch.ps1": "601b4043ab5eddcbe3bd519f469d4cfb6c8ea16476ed6900fe8ba38a46fc386f"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
