@echo off
rem usage: run_gates.bat "C:\Program Files\Blue Prism Limited\Blue Prism Automate"
cd /d "%~dp0"
python compile_check.py --self-test
python compile_check.py ..\xml --ref-dir %1
python validate.py ..\xml --flow --strict
