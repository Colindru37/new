"""Put the real values back into the scrubbed files of this package.

1. Fill restore_values.txt: one line per token, TOKEN = value (SCRUB_SHEET.md says where each
   value is in the original Python INIs). No quotes. Lines starting with # are ignored.
2. python restore_config.py            -> restores in place, then proves every restored file is
                                          byte-identical to the build machine's (restored.sha256)
   python restore_config.py --check    -> only checks the package arrived intact (MANIFEST.sha256)
Nothing is installed, only the standard library is used. A backup of every scrubbed file is kept
in _scrubbed_backup/ so a typo can be fixed and the script run again."""
import hashlib, json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP = os.path.join(HERE, '_scrubbed_backup')


def sha(path):
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def read_hashes(name):
    out = {}
    with open(os.path.join(HERE, name), encoding='utf-8') as f:
        for line in f:
            if line.strip():
                h, p = line.rstrip('\n').split('  ', 1)
                out[p] = h
    return out


def check_package():
    bad = 0
    for rel, h in read_hashes('MANIFEST.sha256').items():
        if rel == 'restore_values.txt':      # you fill this one in
            continue
        p = os.path.join(HERE, rel)
        src = os.path.join(BACKUP, rel) if os.path.exists(os.path.join(BACKUP, rel)) else p
        if not os.path.exists(src):
            print('MISSING ', rel); bad += 1
        elif sha(src) != h:
            print('CHANGED ', rel); bad += 1
    print('PACKAGE OK' if bad == 0 else f'PACKAGE DAMAGED: {bad} file(s)')
    return bad == 0


CHECKS = {
    'SHARE_ROOT': (r'^\\\\[^\\]+\\.+[^\\]$', 'starts with \\\\server\\ and has no trailing \\'),
    'SNOW_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'ALICE_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'BLUESPACE_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'ALICE_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'BLUESPACE_MAKER_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'BLUESPACE_CHECKER_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'LABEL_GUID': (r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', 'a lower-case GUID'),
}


def main():
    if '--check' in sys.argv:
        sys.exit(0 if check_package() else 1)
    sheet = json.load(open(os.path.join(HERE, 'scrub_counts.json'), encoding='utf-8'))
    tokens, files = sheet['tokens'], sheet['files']        # files: {rel: {TOKEN: count}}
    values = {}
    with open(os.path.join(HERE, 'restore_values.txt'), encoding='utf-8') as f:
        for n, line in enumerate(f, 1):
            s = line.rstrip('\r\n')
            if not s.strip() or s.lstrip().startswith('#'):
                continue
            if '=' not in s:
                sys.exit(f'restore_values.txt line {n}: no "=": {s!r}')
            k, v = s.split('=', 1)
            values[k.strip()] = v.strip()
    errors = []
    for t in tokens:
        v = values.get(t, '')
        if not v:
            errors.append(f'{t}: empty')
        elif t in CHECKS and not re.match(CHECKS[t][0], v):
            errors.append(f'{t}: {v!r} does not look right ({CHECKS[t][1]})')
        elif '{{' in v or v.startswith('"') or v.startswith("'"):
            errors.append(f'{t}: {v!r} (no quotes, no tokens)')
    for k in values:
        if k not in tokens:
            errors.append(f'{k}: not a token of this package (typo?)')
    if errors:
        print('restore_values.txt is not ready:'); [print('  ' + e) for e in errors]; sys.exit(1)

    # start from the scrubbed originals every time (a second run after a typo fix is safe)
    for rel in files:
        p, b = os.path.join(HERE, rel), os.path.join(BACKUP, rel)
        if os.path.exists(b):
            shutil.copyfile(b, p)
        else:
            os.makedirs(os.path.dirname(b), exist_ok=True); shutil.copyfile(p, b)
    expected = read_hashes('restored.sha256')
    ok_all = True
    for rel, counts in files.items():
        p = os.path.join(HERE, rel)
        with open(p, encoding='utf-8', newline='') as f:
            text = f.read()
        for t, c in counts.items():
            found = text.count('{{' + t + '}}')
            if found != c:
                print(f'STOP {rel}: {{{{{t}}}}} found {found} times, expected {c} (file edited after scrub?)'); sys.exit(1)
            text = text.replace('{{' + t + '}}', values[t])
        if '{{' in text and re.search(r'\{\{[A-Z_]+\}\}', text):
            print(f'STOP {rel}: a token is left: {re.search(r"{{[A-Z_]+}}", text).group(0)}'); sys.exit(1)
        with open(p, 'w', encoding='utf-8', newline='') as f:
            f.write(text)
        good = sha(p) == expected.get(rel)
        ok_all &= good
        print(('OK      ' if good else 'DIFFERS ') + rel + ('' if good else '   check: ' + ', '.join(sorted(counts))))
    if ok_all:
        print('RESTORED: every file is byte-identical to the build machine\'s config.')
    else:
        print('RESTORED WITH DIFFERENCES: a value above is mistyped (or the estate value changed since).\n'
              'Fix restore_values.txt and run again; the scrubbed copies are in _scrubbed_backup/.')
        sys.exit(2)


if __name__ == '__main__':
    main()
