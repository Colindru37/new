# GK Revoke BlueSpace: the BlueSpace (fabric) application object

Built 2026-10-10 with the rpa-bp skill from `../../source/bluespace_maker.py` /
`bluespace_checker.py`. Calls `GK Revoke Browser`; holds no XPaths (the `bluespace_*` config keys).

| Path | What |
|---|---|
| `out/BPA Object - GK Revoke BlueSpace.xml` | Clean Up + 10 actions (225 stages). Import after the Browser object. |
| `build_bluespace.py` | The generator. |

## Actions
Login (URL Key, Username, Password) -> Window Handle | Open User Admin (Window Handle) |
Find User (Window Handle, Username) -> Listed, Found, Status, Edit Available |
Open User Edit (Window Handle) -> Status | Set User Inactive (Window Handle) | Save User (Window Handle) -> Status |
Get Memberships (Window Handle) -> Memberships[Kind, Index, Name, Key], Group Count, Team Count |
Remove Membership (Window Handle, Kind group/team, Index) |
Check Memberships (Memberships, Roles To Check[Role Name]) -> Results[Role Name, Status], All Revoked (code only) |
Capture Screenshot (Window Handle, File Path)

## Design points
- **One route into the grid.** The Maker Python clicked Settings -> User and entered `iFrameHolder`;
  the Checker refreshed the page it was already on and entered the iframe. `Open User Admin` always
  reloads the URL, presses Settings and User and enters the iframe, so neither process depends on
  where the page was left. Every other action re-enters the iframe from the top.
- **Login form is optional** (SSO): the probe waits 5 s for the username field; when it shows, the
  credential comes from Credential Manager (`GK Revoke BlueSpace Credential Name`), never the INI
  `username` / `pass` keys (fix #6 of INTERFACE.md section 8). The password is unwrapped in a code
  stage only for the Send Keys call and cleared right after.
- **Find User reads the result row** (user id, status, Edit link) the way the Checker did; the Maker
  Python only probed for the Edit link, so the Maker config gained `bluespace_result_user` /
  `bluespace_user_active_status` (config/CHANGES.md).
- **Memberships are read once** into a collection with a normalised Key: the part before `:` with
  leading zeros removed. The Maker stripped one leading `0`, the Checker none (BLUESPACE_NOTES): both
  sides now compare without leading zeros (section 8, item 16).
- **Remove Membership** presses the remove symbol only; `Save User` commits, and returns the status
  dropdown so the process can detect a deactivation that did not stick ("Technical User Exception").
- Statuses are the live strings: "Entitlement not Revoked, RITM Skipped." / "Entitlement Revoked".

## Gates (here)
| Gate | Result |
|---|---|
| validate `--flow --strict --with ../browser/out` | ALL CLEAN (every Browser call matched to a real action and its exact inputs) |
| compile_check | 5 code stages compiled (C# 5) |
| end to end | all 10 actions executed by the BlueSpace Maker + Checker in `../../tools/bprun` against the mock portal (login form path included) |
