# The five processes: Master Populate Queue, Alice Maker / Checker, BlueSpace Maker / Checker

Built 2026-10-10 with the rpa-bp skill from `../../source/*.py` (the transcribed bots) and
`../INTERFACE.md`. All five follow the estate recipe (`examples/minimal_orchestration.py`).

| Path | What |
|---|---|
| `out/BPA Process - GK Revoke - Master Populate Queue.xml` | 4 pages, 160 stages |
| `out/BPA Process - GK Revoke - Alice Maker.xml` | 11 pages, 363 stages |
| `out/BPA Process - GK Revoke - Alice Checker.xml` | 11 pages, 377 stages |
| `out/BPA Process - GK Revoke - BlueSpace Maker.xml` | 9 pages, 369 stages |
| `out/BPA Process - GK Revoke - BlueSpace Checker.xml` | 9 pages, 319 stages |
| `build_*.py` | The generators. |
| `run_gate.sh` | Generate all, validate `--flow --strict --with` every object and the internal-object stubs, compile. |
| `flow.txt` | The last resolved-link report. |
| `../stubs/` | Interface stubs of `Work Queues` and `Credentials` (validation only, never imported). |

## Shape (Maker and Checker)
- **Main** = the control framework: Reset Global Data -> Initialise Session -> `Continue To Work?`
  (IsStopRequested OR the session flag) -> Get Next Item from the bot's queue -> `Work RITM` inside
  the `Work The RITM` block -> Mark Completed (Maker also queues the RITM for the Checker) -> loop.
  A failure in the block is captured in recovery mode, `Handle RITM Failure` runs (tracker Fail +
  reason, internal tracker rows marked, task assigned to Ops; best effort), then Mark Exception:
  Business = no retry, System = retry + the consecutive-failure guard. Everything from set-up to
  tear-down sits in the outer `Run Bot` block: a failure there emails the team (`Report Fatal`),
  marks the bot Offline, closes the browser and rethrows.
- **Initialise Session**: Load Config, read bot_name / Bot_status_file / sample_email_file_path (the
  INI keeps the paths ops edit today), Update Bot Status Running, Launch Browser (edge, SSO profile
  copy, download folder = attachment_folder_path for the Maker), Login SNOW, Credentials.Get ->
  Login Alice. **Shut Down Session**: Close Browser, Offline.
- **Work RITM (Maker)** = the Python main() body: tracker Inprogress, clear the attachment folder,
  Open Task (Found/Reason -> Business Exception), RCRT tab present?, Work in progress, Download +
  Read Attachment, then per user (grouped by `account` like the pandas groupby): `Process User`.
  Finally `Close Maker Task` (Closed complete + "Maker Task Done", maker rows Comment = computer -
  Done, tracker Completed).
- **Process User (Maker)**: `Plan Revocation` (code): revoke account wins if any row asks for it;
  entitlements split by the `_EMEA/_APAC/_AMER` suffix, no suffix = all three regions. Entitlement:
  per region `Revoke Roles In Region` (Open Region -> Find User -> Select -> Get Roles -> Revoke
  Roles; the AliceUser rule deletes the user; user absent = all "User access already revoked").
  Account: `Delete User In Region` x3. `Combine Results` (code) = the Python
  combineStatusDictsSeparateRequestIds (status priority, region names "europe,americas,asia pacific")
  and builds the 14-column maker tracker rows; Update RCRT Status (MT) with the status as comment;
  no RCRT row matched -> rows written with MTStatus Not Done, then Business Exception.
- **Work RITM (Checker)**: tracker Inprogress, maker rows for the RITM (none -> Business Exception),
  Open Task, Work in progress, per owner `Check User`, then `Attach Evidence And Close`.
- **Check User (Checker)**: `Plan Check` (code) from the maker rows (regions from "Region Name" text,
  the Python contains-match). Entitlement: per region `Check Roles In Region` (Open Region -> Find
  User -> Select -> Get Roles -> Check Roles -> Open User Info -> Capture Page Evidence -> Close;
  absent user = one screenshot of the search + "Entitlement revoked"). Account: `Check Account In
  Region` x3 (gone = not listed; one screenshot each). `Write Results` builds the 12-column checker
  rows; all revoked -> Update RCRT Status (CT) -> rows; else rows (Not Done) + Business Exception
  ("All roles not revoked" / "User not revoked").
- **Attach Evidence And Close**: list `<RITM>_*.png`, Build Evidence Docs (batch = config
  `screenshot_file_count`), Apply Sensitivity Label per doc (Environment Variable `GK Revoke Label
  ID`), Upload Attachments (timeout = config `explicit_delay4`), Closed complete + "CT Done",
  checker rows Task Complete Closed = Done, tracker Completed.

## Shape (BlueSpace Maker and Checker)
Same Main / session / failure pages as Alice (BlueSpace queues, `GK Revoke BlueSpace Credential Name`).
- **Work RITM (Maker)**: as Alice up to Read Attachment, then per (account, action) group (the Python
  groupby): `Process Group`. Account: Find User -> Open User Edit -> Active? -> Set User Inactive -> Save
  User (still Active = System Exception "Technical User Exception") -> "User Account Revoked"; Inactive
  or no Edit link = "User Account Already Revoked". Entitlement: Open User Edit; Active -> per requested
  number: Get Memberships -> group found (last group = also Set User Inactive, "No entitlement left.
  Hence, user account revoked") / team found ("User Entitlement Revoked") / nowhere ("User Entitlement
  Already Revoked") -> Save User once when anything was removed; Inactive or no Edit link = all "User
  Entitlement Already Revoked". One maker tracker row per request id (13 BlueSpace columns).
  Then `Update ServiceNow And Close` (the Python ServiceNow_Update_Function): Requests = this RITM's
  maker rows (comment = remark) -> Update RCRT Status (MT, **Unmatched Comment "role already
  revoked"**: every RCRT row gets MT true, the Python behaviour) -> no RCRT rows = Business Exception
  -> Closed complete "MT Done" -> matched rows stamped (SC_Updation_Time, Comment "<computer> - Done",
  MTStatus "MT Status as:True") -> tracker Completed -> Checker queue.
- **Work RITM (Checker)**: as Alice; `Check User`: Open User Admin -> Find User; entitlement: user
  found and Active -> Open User Edit -> Get Memberships -> Check Memberships; absent / Inactive = all
  "Entitlement Revoked"; account: gone = not listed or Inactive ("User revoke completed"). One
  screenshot per owner (`<RITM>_<owner>.png`). Then CT status, rows, evidence docs, upload, close.

## Shape (Master Populate Queue)
One pass per run: Initialise (Master config, SNOW queue URL) -> Get Open RITMs -> for each: `Register
RITM` (already in the tracker -> skip; else Read RITM Details -> NAR ID lookup in
Revocation_Application_list -> Add RITMs -> in scope (Active + task assignment group = config
`assignment_group`) -> Add To Queue (the Alice or the BlueSpace maker queue by Application, data RITM
Number + Application; an application without a maker = out of scope); out of scope ->
both statuses Fail + "RITM not in Bot scope"). Each RITM in its own block: a failure counts and the
pass continues. Shut down. The Python's threads/subprocess dispatch is replaced by the queues.

## Environment Variables (create in System Manager)
Email (all five processes, used by `Report Fatal`): `GK Revoke SMTP Server` ("host" or "host:port";
empty = send from the Outlook .msg template of the config instead), `GK Revoke Email From`,
`GK Revoke Email To` (`;` separated).
`GK Revoke Alice Maker Config Path`, `GK Revoke Alice Checker Config Path`, `GK Revoke Master Config
Path` (the INIs in `../config/`), `GK Revoke Run Mode` (`test` / `dryrun` / `live`), `GK Revoke
Driver Path` (msedgedriver.exe), `GK Revoke Profile Root` (the Edge user-data folder the Python
copied: `C:\Users\<bot>\tep`), `GK Revoke Log Folder`, the four queue names `GK Revoke Alice Maker
Queue Name` / `GK Revoke Alice Checker Queue Name` / `GK Revoke BlueSpace Maker Queue Name` / `GK Revoke
BlueSpace Checker Queue Name`, `GK Revoke Max Consecutive Failures` (e.g. 3), `GK Revoke Alice
Credential Name`, `GK Revoke BlueSpace Credential Name`, `GK Revoke BlueSpace Maker Config Path`,
`GK Revoke BlueSpace Checker Config Path`, `GK Revoke Label ID` (the AIP GUID). Session variable: `GK Revoke Stop After Next Item`.
Queues: key column `RITM Number`; the names are ours (the Python never used Work Queues): `GK Revoke Alice Maker`, `GK Revoke Alice Checker`, `GK Revoke BlueSpace Maker`, `GK Revoke BlueSpace Checker`.

## Gates (here)
| Gate | Result |
|---|---|
| validate `--flow --strict --with` all 7 objects + stubs | ALL CLEAN for the five processes: every object call matched to a real action and its exact inputs, every page call to its Start inputs / End outputs, every decision target, no unused data, no dead ends |
| compile_check | 13 + 15 + 1 + 13 + 9 code stages compiled (C# 5) |
| Link report + previews | Main (nested blocks), Process User, Check User, Register RITM reviewed |
| Found and fixed | Two code stages named `Evidence Prefix` on different pages of the Checker compiled to one method (CS0111): renamed; the rule is now enforced by the generator and `validate.py --strict`, and recorded in the skill's gotchas |

Executed end to end here with `../../tools/bprun` (2026-10-10, 70/70 assertions over all five processes + the email object, see its README). First laptop run: `GK Revoke Run Mode = test` (no browser) to prove the wiring,
then `dryrun` against the real portals (reads only; every click is logged as `WOULD`), then `live`
on one fake ticket.
