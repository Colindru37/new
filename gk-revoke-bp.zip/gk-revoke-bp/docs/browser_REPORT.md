# GK Revoke Browser: the transport object, built from scratch here

Built 2026-10-09 with the rpa-bp skill. Replaces the laptop's `GK Revoke Browser - Generic`
(7.5k lines, never testable off the machine). Nothing sent yet.

## What is here

| Path | What |
|---|---|
| `out/BPA Object - GK Revoke Browser.xml` | The object: Clean Up + 37 actions. Import this. |
| `GkBrowser.cs` | The shared code (Code Options `<code>`): `Cfg` (config.ini) + `Wd` (WebDriver session). ~560 lines. |
| `build_gk_browser.py` | The generator. Edit this or `GkBrowser.cs`, rerun; never hand-edit the XML. |
| `test/run_tests.sh` | The whole gate: generate, validate `--flow --strict`, compile every stage, run the stage code against a real browser. |
| `test/Harness.cs` | 97 checks through the generated stage methods (`Run_<Action>`), exactly what Blue Prism calls. |
| `test/site/`, `test/serve.py`, `test/mock.ini` | Mock portal (iframes, select, checkboxes, popup window, alert, download, upload, late/vanishing elements, tall page) and a config in the bots' INI format. |
| `../PROFILE.md` | The architecture profile (project-compatible exception) and every override of the estate default. |

## Design

- **Transport.** Plain W3C WebDriver over HTTP: `System.Net.Http` + `System.Web.Extensions`
  (JavaScriptSerializer). Both are in .NET Framework 4.8. No Selenium, no Newtonsoft, no DLL to
  place anywhere. `msedgedriver.exe` on the estate, `geckodriver` here: same protocol, only the
  capabilities block differs (`Browser` input: `edge` / `firefox`).
- **Locators are config keys.** Every action takes `XPath Key` (an `[XPATHS]` key, or a literal
  XPath) and `Index` (fills the Python `{}` slot with `.Replace`, never `string.Format`). URLs are
  `[URLS]` keys. `Load Config` reads the bot's INI with Python ConfigParser semantics (`%%` -> `%`,
  keys case-insensitive, sections case-sensitive, `#`/`;` comments, continuation lines). Same
  reader logic as the skill's `ini_reader.cs`.
- **Waits match Selenium.** `Launch Browser` sets the implicit wait (`implicit_delay`, 10 s) so
  `Get Text`/`Count Elements`/... retry like `find_element` did, and the explicit wait
  (`explicit_delay`, 30 s) for `Click`/`Send Keys`/`Get Text` (= `element_to_be_clickable` /
  `visibility_of_element_located`). `Wait For Element` takes a Condition (present / visible /
  clickable / absent) and returns `Found` instead of raising, so the process decides.
- **Three run modes, one gate.** `live`, `dryrun` (real navigation and reads; every click, key
  press, upload and alert-accept is skipped and logged as `WOULD ...`), `test` (no browser at all:
  lookups succeed, reads return `""`). Unknown mode fails at launch. The gate is one function
  (`Would`) that every mutating call passes through.
- **Flight recorder.** Every HTTP call is logged `time | frames | method path | ms | status |
  request | reply(300)` to `<Log Folder>\browser-YYYY-MM-DD.log`. The frame breadcrumb
  (`top>//iframe[@id="gsft_main"]>...`) is on every line and inside every error message.
- **Failure dump.** Any failing action writes `dump-<time>-<action>.html/.png/.txt` (page source,
  browser-only screenshot, URL/frames/window count + the last 60 calls) and puts the path in the
  System Exception detail. `Dump Page` does the same on demand.
- **Edge profile reuse (SSO).** `Launch Browser` with `Profile Root` copies `Local State` and the
  profile folder (caches skipped) into a temp root, patches `Preferences` (download folder, no
  prompt, no popups) and starts Edge on the copy, like the Python `setDriver`; `Close Browser`
  deletes the copy. Then it opens one clean tab and closes whatever the restored profile brought
  back, like the Python did.
- **Evidence screenshots are browser-only** (`GET /screenshot`), not full-desktop `mss`, so nothing
  else on the screen leaks into the evidence and the screen does not need to be unlocked.
- **Error contract.** A failing action raises a System Exception
  `"<Action>: <reason> | frames=<breadcrumb> url=<url> | dump=<path>\nLast calls:\n<8 lines>"`.
  Timeouts on `Wait For Element` / `Wait For Download` / `Accept Alert` are NOT errors (they return
  Found = False / ""), because the bots branch on them.

## Actions (37)

| Group | Actions |
|---|---|
| Config | Load Config, Get Setting, Has Setting, Get XPath |
| Session | Launch Browser, Close Browser |
| Navigation | Navigate, Refresh Page, Get Title, Get URL |
| Elements | Wait For Element, Click, Send Keys (Clear First, Press Enter), Upload File, Get Text, Get Attribute, Count Elements, Is Displayed, Is Enabled, Get Selected Option, Double Click |
| Frames / windows | Switch To Frame, Switch To Top, Get Windows, Switch To Window, Switch To Last Window, New Tab, Close Window |
| Scripts | Execute Script, Scroll To Element, Scroll Page, Get Page Heights |
| Alerts / evidence / files | Accept Alert, Take Screenshot, Wait For Download, Dump Page, Get Trace |

These cover every Selenium call the six bots make (inventory: 71 window switches, 70
`element_to_be_clickable`, 47 `find_element`, 34 `execute_script`, 24 `find_elements`, 11 double
clicks, 6 `Select`, 4 alerts, ...). Not included on purpose: `maximize_window` (done at launch),
`implicitly_wait` (a launch input), `mss` full-screen capture (replaced by browser screenshots).

## Results

| Gate | Result |
|---|---|
| `validate.py --flow --strict` | ALL CLEAN (Clean Up + 37 action pages) |
| `compile_check.py` | ALL COMPILED: 37 code stages + shared code, as C# 5 (indicative here; rerun with `--ref-dir` on the laptop) |
| Live harness (`test/run_tests.sh`) | **97/97** through the generated stage methods against Firefox 157 + geckodriver 0.36 and the mock portal: config semantics (`%%`, case, `{}` slot rules, literal XPaths, unknown keys), navigate/title/url, clear+type, click, Enter, enabled/disabled, checked via property, `value` via property, selected option, counts with and without the implicit wait, indexed rows, double click, hidden/missing elements, waits (appear after 1.5 s, vanish after 1 s, timeout -> False, bad condition -> error), error text carries key + frames + dump path, nested iframes and back to top, refresh, popup window (count, switch last, close, back), new tab, JS with/without element, page heights, scroll page / scroll to element, alert accept + none, real xlsx download, file upload, screenshot file, manual dump, trace content and file, dryrun (nothing changes, `WOULD` logged), test mode (no driver), bad run mode and missing driver errors |
| Positive controls | 6 bugs planted one at a time, **6/6 turned the gate red**: dry-run gate removed (3 fails), Switch To Frame does nothing (4), implicit wait removed (1), `{}` slot always 1 (3), alert never accepted (3), no dump on failure (1). Restored build green and byte-identical |

Found by the harness and fixed before this report: mono's JSON serializer returns arrays as
`ArrayList` where .NET returns `object[]` (both handled now); `Get Attribute "value"` returned the
HTML attribute instead of the live value (Selenium semantics restored).

## Not verified here (needs the laptop)

1. **Edge itself.** Everything ran against Firefox/geckodriver. The Edge-specific parts are the
   capabilities block (`ms:edgeOptions` args + prefs) and the profile clone; both are direct ports
   of the Python `setDriver`, but the first Edge run is on the laptop. Run the mock harness there
   with `Browser = edge` and the real `msedgedriver.exe` if possible, then dryrun on the real pages.
2. **Blue Prism's compiler.** Run `compile_check.py out --ref-dir "<Blue Prism folder>"` on the
   laptop. The code is C# 5, so the old Framework compiler also accepts it.
3. **The Pdfx-style DLL question does not arise**: this object needs no DLL at all.
