# GK Revoke Alice: the Alice-Global application object

Built 2026-10-09 with the rpa-bp skill. Calls `GK Revoke Browser`; holds no XPaths.

| Path | What |
|---|---|
| `out/BPA Object - GK Revoke Alice.xml` | Clean Up + 12 actions (305 stages). Import after the Browser object. |
| `build_alice.py` | The generator. |
| `preview/*.svg` | One diagram per page. |

## Actions
Login (URL Key, User ID) -> Window Handle | Open Region (Window Handle, Region EMEA/AMER/APAC) |
Find User (Window Handle, Username) -> Listed, Found, Email | Select User (Window Handle) |
Get Roles (Window Handle) -> Roles[Index, Role Name, Key, Checked], Count |
Revoke Roles (Window Handle, Roles, Roles To Revoke[Role Name]) -> Results[Role Name, Status], Changed |
Check Roles (Roles, Roles To Check[Role Name]) -> Results, All Revoked (code only) | Delete User (Window Handle) |
Open User Info (Window Handle) -> Info Handle | Capture Page Evidence (Window Handle, Folder, File Prefix) -> Files[File Path], Count |
Close User Info (Info Handle, Main Handle) | Capture Screenshot (Window Handle, File Path)

## Design points
- **Frames.** Alice is `(//frame)[1]` then `//iframe[@name="content"]`. Every page starts with
  Switch To Window -> Switch To Top -> first frame -> content frame, so no page depends on the frame
  state left by the previous one. The region page shell (top -> first frame -> heading (best effort)
  -> content frame -> warning window -> top -> first -> content) is the Python's repeated block, once.
- **The warning window** is dismissed the way the Python did it: wait up to 10 s for the OK button,
  then `document.querySelector('#ext-gen18').click()` through Execute Script (a plain click did not
  work for them; the XPath key is still used to detect the window).
- **Login** retries 5 times in a work block like ServiceNow. The login-form probe waits 5 s (SSO
  normally skips the form); the user id comes from the process (Credential Manager), not a hard-coded map.
- **Region by link position** (1st/2nd/3rd ` User Admin ` link = EMEA/AMER/APAC) is kept; an unknown
  region is a Business Exception.
- **Roles are read once** (Get Roles) into a collection with a normalised Key (no spaces, upper case,
  the Maker's compare); Revoke Roles and Check Roles work on that collection, so the process calls
  Get Roles then one of them. Check Roles has no browser calls at all. The Checker's exact-string
  compare is replaced by the same normalised compare (fix #12: the two bots compared differently).
- **Evidence** is browser-only screenshots of the user-info window, scrolled viewport by viewport
  (step = viewport height - 100, like the Python; the Python's odd `scroll + 100 == viewport` tweak is
  dropped), bounded at 40 shots. "User not listed" evidence is one screenshot of the search result
  page, with no window switching (fix #3).
- Statuses are the live strings the trackers expect: "Entitlement/revoke completed" / "Role already
  revoked" (Maker), "Entitlement revoked" / "Entitlement not revoked, RITM Skipped." (Checker).

## Gates (here)
validate `--flow --strict --with ../browser/out`: ALL CLEAN. compile_check: 8 code stages compiled.
Link report reviewed (Choice branches, retry back-edges, role loop, evidence loop). Not runnable here.
