# GK Revoke Tracker: the shared Excel files, without Excel

Built 2026-10-10 with the rpa-bp skill.

| Path | What |
|---|---|
| `out/BPA Object - GK Revoke Tracker.xml` | Clean Up + 8 actions. |
| `Tracker.cs` | Shared code: `Xlsx` (read / append / update / claim on .xlsx via zip + XML, create new workbooks) + the file lock. ~330 lines, C# 5. |
| `build_tracker.py` | The generator. |
| `test/run_tests.sh` | Gate: generate, validate `--strict`, compile, run the stage code on pandas-written fixtures, read everything back with pandas/openpyxl. |

## Actions
Claim Next RITM (Tracker Path, Application, Status Column, Requires Column, Requires Value) -> RITM Number, Found, Row |
Update RITM Status (Tracker Path, RITM Number, Status Column, Status, Remark) -> Updated Count |
Append Rows (Tracker Path, Rows) -> Appended Count | Read Rows (Tracker Path, Filter Column, Filter Value) -> Rows, Count |
Update Field (Tracker Path, Match Column, Match Value, Match Column 2, Match Value 2, Column, Value) -> Updated Count |
Add RITMs (Tracker Path, RITMs[RITM Number, Created, Application], Ticketing Tool) -> Added Count | Read Attachment (File Path) -> Rows, Count |
Update Bot Status (Status File, Bot Name, Status) -> Updated Count

## Design
- **In-place edits.** An update changes only the target cells of the sheet XML (as inline strings);
  every other cell, style and sheet stays byte-identical. The Python (pandas `to_excel`) rewrote the
  whole file and dropped formatting; this keeps whatever the team has in those files.
- **Reads** return every cell as text; whole numbers lose their `.0` (pandas stores request ids as
  numbers), empty cells are `""`, and header names are kept exactly (the live Checker tracker has a
  header with a trailing space) while lookups ignore case and surrounding spaces.
- **Matching** is text, case-insensitive, and numeric-tolerant (`4711` matches a numeric `4711.0`).
- **Lock.** `<file>.lock` created exclusively (`CreateNew`), retried every 2 s for up to 5 min, always
  released; a lock older than 10 min (crashed bot) is taken over. Reads lock too, so nobody reads a
  half-written file. The folder is created first (an append into a new folder used to spin on the lock).
- **New files** (an internal tracker that does not exist yet) are minimal valid workbooks (one sheet,
  the header row, a Normal style) that Excel, pandas and openpyxl open.
- **Add RITMs** writes the Master's row shape (Date, Time, Ticketing Tool from the config, Application, Revocation,
  Ticket, Open, Open, "") and skips tickets already present.

## Results (here)
| Gate | Result |
|---|---|
| validate `--flow --strict` | ALL CLEAN |
| compile_check | 8 code stages + shared code compiled (C# 5) |
| Harness (`test/Harness.cs`) | **42/42** through the generated stage methods: reads (headers, empty cells, numeric text, filters, bad column, missing file), the attachment, claim (skips Completed, takes Open then empty, Checker requires Maker = Completed, nothing left -> Found false), status/field updates (other cells untouched, unknown ticket -> error, 0 matches is not an error), bot status, appends (subset of columns, new tracker in a new folder, unknown column -> error, leading/trailing spaces kept), Add RITMs (skips existing, date/time split, today when empty, idempotent), the lock (held -> waits then errors; stale -> taken over; released) |
| pandas/openpyxl judge (`test/judge.py`) | **10/10**: the files the C# wrote open in pandas with the right values; numeric ids stay numeric; the new workbook opens; untouched cells unchanged; no lock files left |
| Positive controls | 5 bugs planted: 4 turned the gate red (update ignores the match, append by position, claim rejects Open, non-exclusive lock). The 5th (dropping the `.0` normalisation) was **not** caught because the fixtures hold integer cells only: that path is untested; it only matters for float-typed request columns (pandas writes those when a column has blanks). |

## Not verified here
Real tracker files from the laptop (written by pandas over months, possibly hand-edited). First run:
`Read Rows` on each of the four files and compare row counts with Excel before any write.

## 2026-10-10 fix found by the end-to-end run
`XmlDocument.Save(Stream)` (mono) wrote the indentation INSIDE an empty `<t>` so an empty cell read
back as `"\n          "` in pandas/Excel; the sheet is now saved compact through an `XmlWriter`
(`Indent = false`) and the reader concatenates only the `<t>` runs of an inline string. Judge check
added (`unset + explicitly empty columns ... read back EMPTY`), positive-controlled against the old
save path (fails with the old code, passes now). 55 checks.
