# GK Revoke ServiceNow: the ServiceNow application object

Built 2026-10-09 with the rpa-bp skill. Calls `GK Revoke Browser` for everything; holds no XPaths.

| Path | What |
|---|---|
| `out/BPA Object - GK Revoke ServiceNow.xml` | Clean Up + 9 actions (328 stages). Import after the Browser object. |
| `build_servicenow.py` | The generator. |
| `preview/*.svg` | One diagram per page. |

## Actions
Login (URL Key) -> Window Handle | Open Task (Window Handle, RITM Number) -> Task ID, Task State, Found, Reason |
Set Task State (Window Handle, State Key, Work Note, Save) | Download Attachment (Window Handle, Folder, Timeout) -> File Path |
Update RCRT Status (Window Handle, Status Kind MT/CT, Requests[Request Id, Comment]) -> Matched[Request Id, RCRT Number], Matched Count, RCRT Present |
Assign To Ops (Window Handle, Assignment Group, Work Note) | Upload Attachments (Window Handle, Files[File Path], Upload Timeout) -> Uploaded Count |
Get Open RITMs (Window Handle) -> RITMs[RITM Number, Created], Count | Read RITM Details (Window Handle, RITM Number) -> NAR ID, Assignment Group, Additional Details

## Design points
- **Every page re-enters the frame explicitly**: Switch To Window -> Switch To Top -> Switch To Frame
  `snow_iframe_xpath`. No page depends on where the previous action left the frame context (the
  Python's "element not found after refresh" class of failure).
- **Login** retries up to 5 times like the Python: a `Load Portal` work block (Recover inside) so a
  transport error, a missing search box or a missing frame all go through `Retry Allowed?`; after 5
  it raises with the last exception detail. The pop-up probe waits 5 s instead of the Python's full
  explicit_delay (30-60 s wasted on every login when there is no pop-up).
- **Open Task** scans the task rows for Active = `true` (the Checker's logic) for both bots; returns
  Found/Reason instead of raising so the process can skip, assign to Ops or continue.
- **Update RCRT Status** is one page for MT (Maker) and CT (Checker): the three status keys are built
  from Status Kind (`MT_status`, `MT_status_true_option`, `MT_status_save_option` / `CT_*`). It walks
  rows by index until the row XPath stops matching (works whether `RCRT_row` counts a header row or
  not), pages with the next button until its class contains `disabled`, matches request ids with a
  leading-zero-tolerant compare, retries the comment editor double-click 3 times, and ends with Save & Stay.
- **Upload Attachments** waits for the n-th row checkbox per file (Upload Timeout = the config
  `explicit_delay4` = 480 s), closes the dialog, accepts the alert and closes again if one shows; a
  file whose row never appears closes the dialog, accepts any alert and raises.
- Work notes / comments / assignment group are inputs (they differed per bot).

## Gates (here)
validate `--flow --strict --with ../browser/out`: ALL CLEAN (every call checked against the Browser's
real inputs). compile_check: 6 code stages compiled. Link report reviewed: all decisions and loop
back-edges land where intended (`Next Row`, `Start Page`, `Count Editor Attempt`, `Count Attempt`).
Not runnable here (Blue Prism flow); the live run is on the laptop, test -> dryrun -> live.

## Config edits this object needs (canonical keys, applied in `../config/`)
1. Alice Maker `snow_task_id_xpath` / `snow_active_status_column`: `tr[1]` -> `tr[{}]` (the Checker's
   shape; Open Task indexes rows).
2. The Master keys `snow_RITM_number_list`, `snow_RITM_xpath`, `snow_RITM_Created_Date`,
   `snow_additional_details_field_xpath`, `snow_Task_assignment_group` live in the Master config only
   (Get Open RITMs / Read RITM Details are Master actions; the Master process loads the Master config).
3. BlueSpace (later): its `SN_*` keys get the canonical names added.
