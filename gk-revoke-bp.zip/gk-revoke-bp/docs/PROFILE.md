# Architecture profile: project-compatible exception (GK Revoke)

Selected 2026-10-09 for the from-scratch rebuild of the GK Revoke solution (Master, Alice, BlueSpace).

Source of truth: the six transcribed Python bots in `../source/` and their six `config.ini` files
(`../source/config/`), plus the existing laptop solution's runtime contract (DEV_PROMPT, Migration Guide).

Overrides of the estate defaults, and why:
1. **No Application Modeller / no spying.** All 234 locators already exist as XPaths in the per-bot
   INIs and are proven against the real pages. The transport object (`GK Revoke Browser`) drives Edge
   through the W3C WebDriver HTTP protocol in C# code stages (BCL only: System.Net.Http +
   System.Web.Extensions, both in .NET 4.8). This is the only architecture that can be tested here,
   on the dev box, against a real browser before transfer.
2. **Per-bot INI files stay** (sections ELEMENTS / URLS / XPATHS, Python ConfigParser semantics).
   The INI path, run mode, driver path and profile root come from process inputs / Environment
   Variables, never hard-coded.
3. **Credentials via Credential Manager** (estate default kept). The Python read a plaintext `pass`
   (BlueSpace) and a hard-coded login map; neither is ported.
4. **Work Queues AND the Excel RITM List tracker** both stay, as today, so the team's existing
   reporting keeps working. Tracker writes go through one locked code stage (FileLock equivalent).
5. **Bugs found in the Python are fixed, not ported**; each fix is listed in the handover
   (`../source/*_NOTES.md` is the inventory).
6. Shared C# lives in the object's Code Options `<code>` (ProcessInfo), root `<globalcode>` empty.
7. Language: C# (compile_check covers it; the laptop's GK solution is C#; C# 5 syntax only so the
   Framework csc can compile it too).

Objects: GK Revoke Browser (transport) -> GK Revoke ServiceNow, GK Revoke Alice (app objects, call the
transport) -> Tracker/Evidence helpers. Processes: Master Populate -> Alice Maker -> Alice Checker.
Validation: `validate.py --flow --strict` (no `--estate`, exception recorded here) + compile_check +
a mono harness driving the real stage code against Firefox/geckodriver and mock pages.
