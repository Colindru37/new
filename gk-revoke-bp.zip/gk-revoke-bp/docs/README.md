# GK Revoke rebuild (Master + Alice) -- what is here and how to take it to the laptop

Built 2026-10-09/10 from the six transcribed Python bots (`../source/`) with the rpa-bp skill.
Nothing here has been on the laptop yet. Everything was generated, validated and (where possible)
executed on this machine. Read `PROFILE.md` (architecture decisions) and `INTERFACE.md` (the
contract + the Python behaviours changed on purpose) first.

## Deliverables (import in this order: objects before processes)

| # | File | Tested here | Report |
|---|---|---|---|
| 1 | `browser/out/BPA Object - GK Revoke Browser.xml` | **yes**: 98 checks against a real browser, 6/6 mutants caught | `browser/REPORT.md` |
| 2 | `tracker/out/BPA Object - GK Revoke Tracker.xml` | **yes**: 42 checks + pandas read-back, 4/5 mutants | `tracker/REPORT.md` |
| 3 | `servicenow/out/BPA Object - GK Revoke ServiceNow.xml` | **yes**: all 9 actions executed in the end-to-end run against the mock portal | `servicenow/REPORT.md` |
| 4 | `alice/out/BPA Object - GK Revoke Alice.xml` | **yes**: all 12 actions executed in the end-to-end run | `alice/REPORT.md` |
| 5 | `evidence/out/BPA Object - GK Revoke Evidence.xml` | compile only (needs Word); a double stood in for it in the e2e | this file, below |
| 6 | `common/out/BPA Object - GK Revoke Common.xml` | **yes**: `Send Email` (SMTP, Cc + attachment) and the fatal-failure exception email ran in the e2e against a mail sink; only the Outlook-template path needs Windows | this file, below |
| 7 | `bluespace/out/BPA Object - GK Revoke BlueSpace.xml` | **yes**: all 10 actions executed in the end-to-end run (login form path included) | `bluespace/REPORT.md` |
| 8 | `processes/out/BPA Process - GK Revoke - Master Populate Queue.xml` | **yes**: executed end to end in `../tools/bprun` | `processes/REPORT.md` |
| 9 | `processes/out/BPA Process - GK Revoke - Alice Maker.xml` | **yes**: same run, one RITM with entitlement + account rows | `processes/REPORT.md` |
| 10 | `processes/out/BPA Process - GK Revoke - Alice Checker.xml` | **yes**: same run, evidence + CT status + close | `processes/REPORT.md` |
| 11 | `processes/out/BPA Process - GK Revoke - BlueSpace Maker.xml` | **yes**: one RITM with entitlement + account groups, every RCRT row MT-marked | `processes/REPORT.md` |
| 12 | `processes/out/BPA Process - GK Revoke - BlueSpace Checker.xml` | **yes**: memberships / status verified, evidence, CT, close | `processes/REPORT.md` |
| - | `config/*.ini` | the six bot configs (documented edits + canonical aliases, `config/CHANGES.md`) | |

Not deliverables: `stubs/` (validation stubs of the internal objects), every `test/` folder, the
`build_*.py` generators (keep them here; regenerate instead of hand-editing XML).

## End-to-end run here (2026-10-10, Master + Alice + BlueSpace)
`../tools/bprun/` interprets the generated XML (code stages run as the real C# under mono) and drove
Master Populate -> Alice Maker -> Alice Checker -> BlueSpace Maker -> BlueSpace Checker against mock
ServiceNow / Alice / BlueSpace pages built on the configs' real XPaths, with Firefox. **70/70
assertions pass**: Master registers the RITMs and queues each in-scope one on its application's queue; Maker revokes the roles / deletes the account in the right regions, sets MT +
comments on the right RCRT rows, closes the task "Maker Task Done", writes the maker rows, queues
the Checker; Checker verifies every region, captures scrolled evidence, builds + labels the docs
(double), uploads them, sets CT, closes "CT Done", writes the checker rows; BlueSpace Maker removes
the group / team memberships, deactivates the emptied and the requested accounts, marks every RCRT
row MT (unmatched = "role already revoked"), closes "MT Done", stamps the rows; BlueSpace Checker
verifies memberships / status per owner, one screenshot each, CT, docs, upload, "CT Done". The
control user and the lookalike team number stay untouched. What it cannot prove:
Edge, Word, Outlook, Blue Prism's own runtime. See `../tools/bprun/README.md` for the defects it
found (all fixed at the source).

## Before import, on the laptop
1. Unzip, then from the skill folder: `python lib\compile_check.py <folder> --ref-dir "C:\Program Files\Blue Prism Limited\Blue Prism Automate"`
   for each `out/` folder. The line must say Blue Prism's own compiler. (All code is C# 5, so the
   Framework compiler accepts it too.)
2. `python lib\validate.py processes\out --flow --strict --with browser\out --with servicenow\out --with alice\out --with bluespace\out --with tracker\out --with evidence\out --with common\out --with stubs\out`
   must print ALL CLEAN (it does here).
3. Create the Environment Variables listed in `processes/REPORT.md`, the four Work Queues (key
   column `RITM Number`: GK Revoke Alice Maker / Alice Checker / BlueSpace Maker / BlueSpace Checker), the Alice and BlueSpace
   credentials, and point the five config variables at `config/`.

## First runs, in this order
1. `GK Revoke Run Mode = test`: Alice Maker on an empty queue. No browser is started; proves the
   session set-up, tracker access (`Update Bot Status`), and tear-down.
2. Object smoke tests from Object Studio with `live` mode on the mock-free parts: Tracker `Read Rows`
   on each real tracker file (compare row counts with Excel before any write); Evidence `Build
   Evidence Docs` on two PNGs, then `Apply Sensitivity Label` on the result and check the label in
   Word; Common `Send Email` to yourself with `GK Revoke SMTP Server` set to the estate relay
   (the same server the estate email VBO is given), then `Send Exception Email` once each way:
   with the SMTP Server (SMTP) and with it empty (Outlook .msg template, as the Python did).
3. Browser alone, `live`: `Load Config` + `Launch Browser` (edge, the real msedgedriver, Profile Root
   = the folder the Python copied) + `Navigate snow_url` + `Get Title` + `Close Browser`. This is the
   first time the Edge capabilities block runs for real. The trace file in the log folder shows every call.
4. `dryrun` with one fake RITM in the Maker queue: real navigation and reads, every click logged as
   `WOULD ...`, nothing changes. Read `browser-<date>.log` end to end before going further.
5. `live` on the fake ticket, Maker then Checker.

## Known gaps (to close on the laptop)
- Edge itself (only Firefox here), Blue Prism's compiler, Word (evidence docs + label), the Outlook
  template path of the email: see the per-object reports.
- Email is built here on purpose (decision 2026-10-10), not the estate email VBO: `Common.Send Email`
  is plain `System.Net.Mail.SmtpClient`, no TLS, anonymous, server from `GK Revoke SMTP Server`
  ("host" or "host:port", 25 default), which is exactly what the estate VBO does today. The real
  relay host name is still needed (whatever the estate VBO's callers pass as SMTP server).
- Work Queues: the Python never had them; the four names are ours (`GK Revoke Alice Maker`,
  `GK Revoke Alice Checker`, `GK Revoke BlueSpace Maker`, `GK Revoke BlueSpace Checker`), key =
  RITM number. Create them in Control Room with those names (or any name, the Environment
  Variables carry them).
- BlueSpace config: the `[7]`-th `tbody.list2_body` RCRT locators and `(//a[...])[2]` link indexes
  are the Maker Python's own values and were only exercised against the mock; verify on the real
  Maker task form in `dryrun`. `bluespace_checker.ini` keeps `username` / `pass` (unused now).

## Transfer
Scrub before any public upload: bank domains, share paths, user ids and the label GUID live only in
`config/*.ini` and the transcribed sources; none of the generated XML or the generators carry them
(the processes read paths from the INI and Environment Variables). Verified 2026-10-10 with a
case-insensitive grep for the bank domain, the share root, the bot user prefixes and the GUID over
`build/`: only `config/` matched. Ship `config/` through the secret channel, not the public repo.
