# Interface contract: objects and actions for Master + Alice (review before anything is generated)

Derived from `../source/*.py` and `../source/config/*.ini`. Every action below is what the three
processes (Master Populate, Alice Maker, Alice Checker) call. Where the six bots differed, the
difference is a **parameter**, not a separate action. BlueSpace (added 2026-10-10) reuses them plus one object (3b).

Conventions (all objects): C#, no DLLs, C# 5 syntax; each action = one page, errors raise
`System Exception "<Action>: <reason>"`; timeouts in seconds; collections have named columns as listed.
Locators are `[XPATHS]` keys resolved by the Browser object (the app objects never hold XPaths).

## 1. GK Revoke Browser (built, 37 actions) -- see `browser/REPORT.md`

## 2. GK Revoke ServiceNow

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Login | URL Key (`snow_url`) | - | openSnowUrl: navigate, optional pop-up (checkbox + OK), wait search box, enter `snow_iframe_xpath`; 5 attempts, refresh between |
| Open Task | RITM Number | Task ID, Task State, Found (flag), Reason | openRITM: search RITM, enter iframe, find the task row whose Active = `true`, open it, read the State dropdown. Found = False with Reason when no task / none active / state not Open |
| Set Task State | State Key (`snow_work_in_progress_status` / `snow_closed_complete_status`), Work Note, Save (`stay` / `exit`) | - | the Open -> Work in progress (save & stay) and Closed complete + work note (save & exit) steps. Work notes were "Maker Task Done" / "CT Done" / "Verified & SS attached": now an input |
| Download Attachment | Folder, Timeout | File Path | downloadAttachment: click `snow_download_attachment_xpath`, Wait For Download xlsx |
| Update RCRT Status | Status Kind (`MT` / `CT`), Requests (collection: Request Id, Comment), Form ID | Matched (collection: Request Id, RCRT Number), Matched Count | updateMtStatus / updateCtStatus: RCRT tab -> remediation link -> refresh; page through rows; for each row whose Request number is in Requests: double-click comment cell, type Comment (MT only, when not empty; the "...submitted Form ID " + Form ID case is a Comment the process builds), save; double-click status cell, pick True, save; next page until the button is disabled; final Save & Stay. Raises when the RCRT tab is missing |
| Assign To Ops | Assignment Group, Work Note | - | assignRITMToOps: group field, work note, save & stay. Work Note was `self.comment` / "System/Business Exception": now an input |
| Upload Attachments | Files (collection: File Path) | Uploaded Count | uploadScreenshotFile: attachment icon, disclaimer tick, per file send path to `snow_choose_option_Tick`, wait for row checkbox n, close icon, accept alert if any. Raises on a file that does not appear |
| Get Open RITMs | - | RITMs (collection: RITM Number, Created) , Count | Master fetchRITMSFromQueue: `snow_RITM_number_list` count, `snow_RITM_xpath`[{}] / `snow_RITM_Created_Date`[{}] per row (the queue URL is the Master's `snow_url`) |
| Read RITM Details | RITM Number | NAR ID, Assignment Group, Additional Details | Master openRITMAndGetNARID: search, `snow_additional_details_field_xpath` text, regex `_(\d+-\d+)`, `snow_Task_assignment_group` |

Canonical key names = the Alice configs (`snow_*`, `RCRT_*`, `MT_status*`, `CT_status*`) plus the
Master's `snow_RITM_*`. The BlueSpace Maker used `SN_*` names for the same elements: when BlueSpace
is ported, its config gets the canonical names added (same XPaths), the old keys stay.

## 3. GK Revoke Alice (Alice-Global portal)

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Login | URL Key (`alice_url`) | Window Handle | openAliceUrl: new tab, navigate, optional username + Next (SSO already logged in = skip), top -> `alice_first_frame` -> heading -> `alice_iframe` -> warning OK; 5 attempts |
| Open Region | Region (`EMEA` / `AMER` / `APAC`) | - | the block repeated in revokeUser / revokeEntitlement / checkUser / checkUserAndRole: switch to the Alice tab, reload `alice_url`, top -> first frame -> click `alice_user_admin_option_<region>` -> top -> first frame -> heading -> `alice_iframe` -> warning OK -> top -> first frame -> `alice_iframe`. Region maps to europe / america / asia_pacific keys (link position 1/2/3) |
| Find User | Username | Found (flag), Email | search box + Enter, `alice_users_list` count > 1, `alice_user_email_id` equals Username (case-insensitive). Found = False = "no such user in this region" |
| Select User | - | - | click `alice_user_surname_column` (after Find User) |
| Get Roles | - | Roles (collection: Index, Role Name, Checked (flag)) | `alice_user_roles_list` count; per index `alice_user_role_name`[i] text (spaces removed, upper) and `alice_user_role_checkbox`[i] checked |
| Revoke Roles | Roles To Revoke (collection: Role Name) | Results (collection: Role Name, Status), Changed (flag) | revokeEntitlement loop: for each role: found + checked -> click checkbox -> "Entitlement/revoke completed"; found + unchecked or not found -> "Role already revoked". Click `alice_update_button` once when anything changed |
| Delete User | - | - | click `alice_user_delete_button` (revoke account, and the AliceUser rule) |
| Check Roles | Roles To Check (collection: Role Name) | Results (collection: Role Name, Status), All Revoked (flag) | checkUserAndRole loop: checked -> "Entitlement not revoked, RITM Skipped." else "Entitlement revoked" |
| Open User Info | - | Window Handle | click `alice_user_info_button`, switch to the new window |
| Capture Page Evidence | Folder, File Prefix | Files (collection: File Path), Count | the scroll-and-screenshot loop (viewport height - 100 steps, browser-only PNGs `<prefix>_<n>.png`) |
| Close User Info | Main Handle | - | close the info window, switch back to Main Handle |
| Capture Screenshot | File Path | - | one browser-only PNG of the current page (checkUser / already-revoked evidence) |

## 3b. GK Revoke BlueSpace (fabric portal) -- added 2026-10-10

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Login | URL Key (`bluespace_url`), Username, Password | Window Handle | loginToBluespacePortal / openBlueSpaceUrl: new tab, navigate, optional credentials, wait Settings; 5 attempts |
| Open User Admin | Window Handle | - | Settings -> User tab -> `bluespace_iframe` (Maker route; the Checker only refreshed) |
| Find User | Window Handle, Username | Listed, Found, Status, Edit Available | filter -> username -> submit; result user id / status / Edit link |
| Open User Edit | Window Handle | Status | Edit link -> status dropdown selected option |
| Set User Inactive | Window Handle | - | `bluespace_status_inactive_option` |
| Save User | Window Handle | Status | Save, then the dropdown re-read (Maker's "Technical User Exception" probe) |
| Get Memberships | Window Handle | Memberships (Kind, Index, Name, Key), Group Count, Team Count | the group / team lists; Key = number before ":" without leading zeros |
| Remove Membership | Window Handle, Kind, Index | - | the remove symbol (`*_delete_option`[i]) |
| Check Memberships | Memberships, Roles To Check (Role Name) | Results (Role Name, Status), All Revoked | checkUserAndRole compare (code only) |
| Capture Screenshot | Window Handle, File Path | - | the `mss` shot, browser-only |

ServiceNow `Update RCRT Status` gained `Unmatched Comment`: "" = Alice behaviour (untouched rows),
"role already revoked" = the BlueSpace Maker behaviour (every RCRT row set true).

## 4. GK Revoke Tracker (the shared Excel files; code stages, no Excel application needed)

xlsx read/write in C# over `System.IO.Compression` (the files are plain OOXML written by pandas; the
Python rewrote whole files without formatting too). Every write: take `<file>.lock` exclusively
(retry 2 s, bounded 5 min), read, change, write, release -- the FileLock pattern.

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Claim Next RITM | Tracker Path, Application, Status Column (`Maker Task Status` / `Checker Task Status`), Requires (`` / `Maker Task Status=Completed`) | RITM Number, Found (flag) | the claim block in main(): first row where Status Column is empty/Open and Application matches (and Requires holds); set it to `Inprogress` and Comment = computer name |
| Update RITM Status | Tracker Path, RITM Number, Status Column, Status, Remark | - | updateRITMListTracker: Comment = `<computer> - <remark>` |
| Append Rows | Tracker Path, Rows (collection) | - | addResultInInternalTracker / MakerTaskUpdateFunction: create with the headings if missing, append |
| Read Rows | Tracker Path, Filter Column, Filter Value | Rows (collection), Count | the pandas reads (maker tracker for a RITM, Revocation_Application_list) |
| Update Field | Tracker Path, Match Column, Match Value, Match Column 2, Match Value 2, Column, Value | Updated Count | the `df.loc[(RITMNumber==x)&(Request_Id==y), col] = v` writes |
| Add RITMs | Tracker Path, RITMs (collection: RITM Number, Created, Application), Ticketing Tool | Added Count | Master: append new tickets (skip ones already present) with Open/Open statuses |
| Read Attachment | File Path | Rows (collection: account, action, entitlement, application, request_no), Count | `pd.read_excel(attachment)` |
| Update Bot Status | Status File, Bot Name, Status | - | updateBotStatus |

Column names are the live ones: RITM List tracker (Date, Time, Ticketing Tool, Application, UseCase,
Ticket, Maker Task Status, Checker Task Status, Comment); Maker internal tracker (RITMNumber, Maker Task
ID, Attachd File Name, Current Date, Current Time, Request_Type, Owner, Role_Name, Region Name,
Request_Id, Remarks, SC_Updation_Time, MTStatus, Comment); Checker internal tracker (RITM Number,
Task Id, Processing Date , Processing Time, Owner, Entitlement, Action, Request Id, Checker Task ID,
Set CT Status, Task Complete Closed, Remark). Typos kept on purpose: other tools read these files.

## 5. GK Revoke Evidence

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Build Evidence Docs | Image Files (collection: File Path), Output Folder, File Stem, Batch Size | Docs (collection: File Path), Count | createWordFile: one .docx per Batch Size images (config `screenshot_file_count` = 40), `<stem>_batch_<n>.docx`; docx written in C# (OOXML), no Word needed |
| Apply Sensitivity Label | File Path, Label ID | - | Word's own sensitivity setting through Word (the way the laptop's Word VBO does it; never tested yet). **No PowerShell** (decided 2026-10-09). Label ID from an Environment Variable (was hard-coded). Verified on the laptop only |

## 6. GK Revoke Common

| Action | Inputs | Outputs | Python origin |
|---|---|---|---|
| Send Exception Email | Template Path, Bot Name, Exception Text | - | sendExceptionEmail. The estate has an email VBO (name + signature needed from the laptop); until then a late-bound Outlook COM code stage (no interop DLL), verified on the laptop only |
| Clear Folder | Folder | - | Clear_Folder (create if missing) |
| Get Computer Name | - | Computer Name | `os.environ["COMPUTERNAME"]` |
| Extract NAR ID | Text | NAR ID | Master regex `_(\d+-\d+)` |

## 7. Processes

- **Master Populate**: Login SNOW -> Get Open RITMs -> Add RITMs -> for each new RITM: Read RITM Details
  -> look up NAR ID in the application list (Read Rows) + assignment group check -> set Application or
  Fail/Fail "RITM not in Bot scope" -> for each application with open work: Add To Queue (Maker queue,
  one item per RITM) **and** the tracker stays as today. The Python then started the bots as
  subprocesses; here the Maker/Checker processes are started by the scheduler and consume the queues.
- **Alice Maker**: claim loop (Work Queue item; tracker row set Inprogress) -> Open Task (Work in
  progress) -> Download Attachment -> Read Attachment -> group by account -> per request type: revoke
  entitlement (region split from `_EMEA/_APAC/_AMER` suffix, else all three) / revoke account (Delete
  User in all three regions) -> Update RCRT Status (MT) -> Append Rows -> Set Task State (Closed
  complete, "Maker Task Done") -> Update RITM Status Completed -> Add To Queue (Checker queue). Any
  failure: Append Rows with the reason, Update RITM Status Fail, Assign To Ops, Mark Exception.
- **Alice Checker**: claim loop (Checker queue; tracker Maker = Completed) -> Read Rows (maker tracker
  for the RITM) -> Open Task -> per owner: Check Roles per region with evidence (Open User Info ->
  Capture Page Evidence -> Close) or Find User per region (revoke account) -> Update RCRT Status (CT)
  -> Build Evidence Docs + Apply Sensitivity Label -> Upload Attachments -> Set Task State (Closed
  complete, "CT Done") -> Update RITM Status Completed. Failures as above.

## 8. Python behaviour changed on purpose (each goes in the handover)

| # | Where | Python did | Rebuild does | Why |
|---|---|---|---|---|
| 1 | Alice Maker, Open Task | opened task row 1 only (`tr[1]`) | finds the row with Active = true | the Checker already did this; row 1 is not always the maker task |
| 2 | Alice Maker, revoke-account failure branch | wrote the tracker rows twice | once | duplicate rows |
| 3 | Alice Checker, "already revoked" evidence | switched to the last window and closed it (closes the Alice tab when no info window exists) | screenshots the current page, no window switching | real bug |
| 4 | Alice Checker, RCRT loop | `range(1, count)` vs Maker `count + 1` (each right for its own XPath) | iterate index 1.. while the row exists | one loop for both XPath shapes |
| 5 | All, evidence | `mss` full-screen capture | browser-only screenshot | no other windows in evidence; screen need not be unlocked |
| 6 | All, login identity | hard-coded Windows-login -> `idam-0xx` map | Credential Manager (`Alice Credential Name` Environment Variable) when a login form appears | estate rule; the map does not scale |
| 7 | Checker, label | GUID hard-coded in code | Environment Variable | same label, no code change to rotate it |
| 8 | Master Populate | `len(data_dict) > 0` always true; status from the last matching row; relaunched the browser every loop | ticket count; first matching Active row; one browser | real bugs |
| 9 | Master Checker | `driver.quit()` on a driver that was never created | n/a (the Checker is a queue consumer, no dispatcher needed) | crash on the error path |
| 10 | Master dispatch | threads + `subprocess.run(python ...)` | Work Queues + scheduler | Blue Prism native; retries and audit for free |
| 11 | BlueSpace (see 15-19) | N x N role loop; `.strip()` on int in the teams branch | one edit session per user, memberships read fresh per role | the outer loop broke after its first iteration anyway; the teams branch would have crashed |

Kept as-is (deliberately): Alice treats "no user row in this region" as already revoked (in Alice a
missing user really is removed); region names written to the tracker stay "europe" / "americas" /
"asia pacific"; tracker column names and typos; the config key names.

12. Checker `Upload Attachments`: the Python did `snow_attachment_checkbox.format(index + 1)` on an XPath
    without a `{}` slot, so it waited for ANY row; the config key now has the slot and the object waits
    for the n-th uploaded file's row (`config/CHANGES.md`).
13. Checker `Update RCRT Status`: the shared ServiceNow page follows the Maker Python (tab -> remediation
    link -> Refresh List -> rows); the Checker config gained `RCRT_remediation` ([1]) and
    `RCRT_refresh_list`. Verify the [1] link on the real Checker task form.
14. Checker tracker: one row per role per region (as the Python), so a role revoked in three regions is
    three rows with the same Request Id. Not changed, recorded because it surprised the e2e harness.
15. BlueSpace Maker, account rows: the Python wrote ONE maker row with the request ids joined ("4713,
    4714") and Role_Name "N/A"; the Checker then did `int(row['Request_Id'])` / `int(row['Role_Name'])`
    and would have crashed on both. Rebuild: one row per request id, Role_Name "" for account rows.
16. BlueSpace role numbers: the Maker stripped one leading `0` from the page value, the Checker none,
    both compared as strings; now both sides compare without leading zeros (object `Key`).
17. BlueSpace Maker RCRT: every row gets MT true; matched rows carry the remark, unmatched "role already
    revoked" -- KEPT (ServiceNow `Unmatched Comment`), flagged in BLUESPACE_NOTES as risky: an RCRT
    row for a request the attachment never mentioned is marked done.
18. BlueSpace Maker: no RCRT rows after the tab was found = Business Exception (the Python closed the
    task "MT Done" with nothing marked).
19. BlueSpace Maker: the failure path wrote a junk maker row (`[ritm, 0, 0, date, time, 0, ...]`); the
    rebuild marks existing rows "<computer> - Failed" like Alice.

## 9. Open questions (answers 2026-10-09)

1. Work Queue names / key column: **no real names exist** (2026-10-10: the Python never used Work
   Queues). The four queues are created for this build: `GK Revoke Alice Maker`, `GK Revoke Alice
   Checker`, `GK Revoke BlueSpace Maker`, `GK Revoke BlueSpace Checker`, key = RITM number, carried by
   the `GK Revoke <App> <Maker|Checker> Queue Name` Environment Variables.
2. Nothing else reads the trackers during a run: **no** -> the simple lock file is enough.
3. Email: **built here, not the estate email VBO** (decision 2026-10-10: "better if we built
   everything here so we know how everything was done"). The estate VBO (per its own summary) is
   plain SMTP through `System.Net.Mail.SmtpClient`, encryption disabled, server supplied by the
   caller, plus an Outlook-COM template action that hides errors. `GK Revoke Common` now has the same
   two paths: `Send Email` (SMTP: Server, From, To, Cc, Subject, HTML Body, Attachments) and
   `Send Exception Email` (SMTP when `GK Revoke SMTP Server` is set, else the Outlook .msg template
   like the Python). Proven here against a mail sink (e2e). Still needed: the relay host name.
4. Label: through **Word's sensitivity setting** (as the laptop's Word VBO does), never tested
   yet. **No PowerShell.** First test is on the laptop with one file.
