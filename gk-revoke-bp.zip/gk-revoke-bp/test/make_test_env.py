r"""Make a LOCAL test environment on the laptop, so the first runs never touch the PROD share.

    python make_test_env.py C:\GKRevokeTest

Reads the restored ..\config\*.ini, writes copies into test\config\ where every share path is moved
under the given root (same sub-folders as PROD), creates those folders, drops the seed Excel files
(empty RITM list, Bot_Status with the five bots Offline, the application list) where the configs
expect them, and writes test\ENV_VARS.txt with the exact Environment Variable values for this
root. Standard library only. Run it again any time to reset the test folder's trackers."""
import configparser, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.normpath(os.path.join(HERE, '..', 'config'))
OUT = os.path.join(HERE, 'config')
SEED = os.path.join(HERE, 'seed')
SEEDS = {'Bot_status_file': 'Bot_Status.xlsx', 'RITM_List_tracker_path': 'RITM_List_Tracker.xlsx',
         'RITM_list_tracker_path': 'RITM_List_Tracker.xlsx', 'revocation_application_list': 'Revocation_Application_list.xlsx'}
INIS = ['master_populate.ini', 'alice_maker.ini', 'alice_checker.ini', 'bluespace_maker.ini', 'bluespace_checker.ini']

if len(sys.argv) != 2 or not sys.argv[1].strip():
    sys.exit(__doc__)
root = sys.argv[1].rstrip('\\/')
os.makedirs(OUT, exist_ok=True)
for ini in INIS:
    src = os.path.join(CFG, ini)
    with open(src, encoding='utf-8') as fh:
        tokens_left = '{{' in fh.read()
    if tokens_left:
        sys.exit(f'{src} still has scrub tokens: run restore_config.py first')
cp0 = configparser.RawConfigParser(); cp0.optionxform = str
cp0.read(os.path.join(CFG, 'master_populate.ini'), encoding='utf-8')
prod = cp0.get('ELEMENTS', 'RITM_List_tracker_path')
share = prod[:prod.upper().index('\\PYTHON')]                 # the share root, whatever it is
print('share root  :', share)
print('test root   :', root)

copied, folders = set(), set()
for ini in INIS:
    cp = configparser.RawConfigParser(); cp.optionxform = str
    cp.read(os.path.join(CFG, ini), encoding='utf-8')
    for sec in cp.sections():
        for k, v in cp.items(sec):
            if not v.upper().startswith(share.upper()) or v.lower().endswith('.msg') or v.lower().endswith('.py'):
                continue                                      # keep the Outlook templates and the old Python paths
            nv = root + v[len(share):]
            cp.set(sec, k, nv)
            is_file = os.path.splitext(nv)[1].lower() in ('.xlsx', '.xls', '.csv', '.txt', '.log')
            folder = os.path.dirname(nv) if is_file else nv
            if folder not in folders:
                os.makedirs(folder, exist_ok=True); folders.add(folder)
            if k in SEEDS and nv not in copied:
                shutil.copyfile(os.path.join(SEED, SEEDS[k]), nv); copied.add(nv)
                print('seed        :', nv)
    with open(os.path.join(OUT, ini), 'w', encoding='utf-8') as f:
        cp.write(f, space_around_delimiters=True)
    print('config      :', os.path.join(OUT, ini))

env = [
    ('GK Revoke Run Mode', 'test', 'test = no browser; dryrun = browser, every click only logged; live = real'),
    ('GK Revoke Browser Kind', 'edge', ''),
    ('GK Revoke Driver Path', 'C:\\...\\msedgedriver.exe', 'FILL: the real msedgedriver.exe'),
    ('GK Revoke Profile Root', 'C:\\Users\\<bot user>\\tep', 'the Edge user-data folder the Python copied'),
    ('GK Revoke Log Folder', root + '\\Logs', ''),
    ('GK Revoke Master Config Path', os.path.join(OUT, 'master_populate.ini'), ''),
    ('GK Revoke Alice Maker Config Path', os.path.join(OUT, 'alice_maker.ini'), ''),
    ('GK Revoke Alice Checker Config Path', os.path.join(OUT, 'alice_checker.ini'), ''),
    ('GK Revoke BlueSpace Maker Config Path', os.path.join(OUT, 'bluespace_maker.ini'), ''),
    ('GK Revoke BlueSpace Checker Config Path', os.path.join(OUT, 'bluespace_checker.ini'), ''),
    ('GK Revoke Alice Maker Queue Name', 'GK Revoke Alice Maker', 'create the queue with this name, key column RITM Number'),
    ('GK Revoke Alice Checker Queue Name', 'GK Revoke Alice Checker', 'same'),
    ('GK Revoke BlueSpace Maker Queue Name', 'GK Revoke BlueSpace Maker', 'same'),
    ('GK Revoke BlueSpace Checker Queue Name', 'GK Revoke BlueSpace Checker', 'same'),
    ('GK Revoke Alice Credential Name', 'GK Revoke Alice', 'Credential Manager entry: the Alice bot account + password'),
    ('GK Revoke BlueSpace Credential Name', 'GK Revoke BlueSpace', 'Credential Manager entry: the BlueSpace bot account + password'),
    ('GK Revoke Max Consecutive Failures', '3', 'number'),
    ('GK Revoke Label ID', cp0.get('ELEMENTS', 'LabelID') if cp0.has_option('ELEMENTS', 'LabelID') else '<LabelID from master_populate.ini>', 'the sensitivity label GUID'),
    ('GK Revoke SMTP Server', '', 'FILL: the estate relay ("host" or "host:port"); empty = Outlook .msg template of the config'),
    ('GK Revoke Email From', '', 'FILL: sender address (with SMTP)'),
    ('GK Revoke Email To', '', 'FILL: team addresses, ; separated (with SMTP)'),
]
os.makedirs(root + '\\Logs', exist_ok=True)
with open(os.path.join(HERE, 'ENV_VARS.txt'), 'w', encoding='utf-8') as f:
    f.write('Environment Variables (System Manager > Environment Variables), all text unless noted. Session variable: GK Revoke Stop After Next Item (flag).\n\n')
    for n, v, note in env:
        f.write(f'{n} = {v}' + (f'      # {note}' if note else '') + '\n')
print('env vars    :', os.path.join(HERE, 'ENV_VARS.txt'))
print(f'done: {len(folders)} folders, {len(copied)} seed files, {len(INIS)} test configs')
