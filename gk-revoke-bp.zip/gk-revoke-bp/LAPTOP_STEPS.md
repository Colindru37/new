# GK Revoke on Blue Prism: laptop steps

This is the full build: 7 objects + 5 processes, generated and tested on the dev box
(70/70 end to end against mock ServiceNow / Alice / BlueSpace, see tools/bprun/README.md).
Nothing here needs installing. Python is only used for the checks and the restore.

## 1. Arrive
1. Unzip. `python restore_config.py --check` -> `PACKAGE OK`.
2. Skill self-test: `cd skill-rpa-bp` then `python selftest.py` -> PASS.

## 2. Put the real values back (build/config only)
Follow SCRUB_SHEET.md: fill restore_values.txt, `python restore_config.py` -> all `OK` +
`RESTORED ... byte-identical`. The XML files never contained bank values, they need nothing.

## 3. Gates with Blue Prism's own compiler
See build/README.md "Before import": compile_check with `--ref-dir` on every `out/` folder, then
validate the processes with all objects. Both must be green before import.

## 4. Import and set up
Import the 7 objects (`build/*/out/BPA Object - *.xml`, not `stubs/`), then the 5 processes.
Create: the Environment Variables in build/processes/REPORT.md (incl. GK Revoke SMTP Server /
Email From / Email To; SMTP Server empty = the Outlook template path), the 4 Work Queues
(key `RITM Number`), the Alice and BlueSpace credentials.

## 5. First runs, in this order
test -> object smoke tests -> Browser alone on Edge -> dryrun on one fake RITM -> live on the fake
ticket. Details: build/README.md "First runs". Send back photos of anything red.

## Still to fill on the laptop
- `GK Revoke SMTP Server`: the relay the estate email VBO's callers pass.
- `GK Revoke Driver Path`: the real msedgedriver.exe.
