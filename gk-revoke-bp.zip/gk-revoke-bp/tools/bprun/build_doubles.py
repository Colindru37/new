"""Test doubles of the two objects that need Word / Outlook: same object names, pages, inputs and
outputs as the real ones (validate.py --with checks that), but the code writes a dummy .docx /
records the email in a text file. Used ONLY by run_e2e.py; never imported into Blue Prism.
Run: python build_doubles.py -> doubles/*.xml"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.expanduser('~/.claude/skills/rpa-bp/lib'))
from bp_gen import Proc, DEFAULT_IMPORTS

OUT = os.path.join(HERE, 'doubles')


def action(o, name, narrative, ins, outs, body):
    pg = o.page(name, narrative)
    for dt, nm, _ in ins:
        pg.add_input(dt, nm)
    for dt, nm, _ in outs:
        pg.add_output(dt, nm)
    code = ('Error_Text = "";\n'
            + ''.join({'text': f'{cs} = "";\n', 'number': f'{cs} = 0;\n', 'flag': f'{cs} = false;\n',
                       'collection': f'{cs} = new System.Data.DataTable();\n'}[dt] for dt, _, cs in outs)
            + 'try\n{\n' + '\n'.join('    ' + l for l in body.strip('\n').split('\n'))
            + '\n}\ncatch (Exception ex)\n{\n    Error_Text = "' + name + ': " + ex.Message;\n}')
    pg.code('Run ' + name, code, inputs=[(dt, cs, f'[{nm}]') for dt, nm, cs in ins],
            outputs=[(dt, cs, nm) for dt, nm, cs in outs] + [('text', 'Error_Text', 'Error Text')])
    pg.decision('Succeeded?', '[Error Text] = ""', true_target='END', false_target='Raise Error')
    pg.exception('Raise Error', 'System Exception', '[Error Text]')


ev = Proc('GK Revoke Evidence', 'object', 'TEST DOUBLE (no Word): writes placeholder .docx files and a label marker.')
ev.code_options('csharp', imports=DEFAULT_IMPORTS)
ev.page('Clean Up', 'Double.', page_type='CleanUp')
action(ev, 'Build Evidence Docs', 'Double: one placeholder .docx per batch, listing the images it would contain.',
       [('collection', 'Image Files', 'Image_Files'), ('text', 'Output Folder', 'Output_Folder'), ('text', 'File Stem', 'File_Stem'), ('number', 'Batch Size', 'Batch_Size')],
       [('collection', 'Docs', 'Docs'), ('number', 'Count', 'Count')],
       'int batch = Batch_Size > 0 ? (int)Batch_Size : 40;\n'
       'var images = new System.Collections.Generic.List<string>();\n'
       'foreach (System.Data.DataRow r in Image_Files.Rows) { string f = Convert.ToString(r["File Path"]); if (!System.IO.File.Exists(f)) throw new Exception("Screenshot not found: " + f); images.Add(f); }\n'
       'if (images.Count == 0) throw new Exception("No screenshots to bundle");\n'
       'System.IO.Directory.CreateDirectory(Output_Folder);\n'
       'Docs.Columns.Add("File Path", typeof(string));\n'
       'for (int start = 0, n = 1; start < images.Count; start += batch, n++)\n'
       '{\n'
       '    string path = System.IO.Path.Combine(Output_Folder, File_Stem + "_batch_" + n + ".docx");\n'
       '    System.IO.File.WriteAllText(path, "DOUBLE DOCX\\n" + string.Join("\\n", images.GetRange(start, Math.Min(batch, images.Count - start)).ToArray()));\n'
       '    Docs.Rows.Add(path);\n'
       '}\n'
       'Count = Docs.Rows.Count;')
action(ev, 'Apply Sensitivity Label', 'Double: appends a label marker line to the file.',
       [('text', 'File Path', 'File_Path'), ('text', 'Label ID', 'Label_ID'), ('text', 'Justification', 'Justification')], [],
       'if (!System.IO.File.Exists(File_Path)) throw new Exception("Document not found: " + File_Path);\n'
       'if (string.IsNullOrEmpty(Label_ID)) throw new Exception("Label ID is empty");\n'
       'System.IO.File.AppendAllText(File_Path, "\\nLABEL " + Label_ID + " (" + Justification + ")");')
ev.write('BPA Object - GK Revoke Evidence.xml', outdir=OUT)

print('doubles written to', OUT)
