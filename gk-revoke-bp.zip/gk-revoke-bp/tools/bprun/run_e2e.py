"""End-to-end: Master Populate -> Alice Maker -> Alice Checker -> BlueSpace Maker -> BlueSpace Checker against the mock SNOW + Alice + BlueSpace, with the
real objects (Browser on Firefox/geckodriver, Tracker on xlsx, Common with SMTP into a mail sink) and the Evidence double.
Usage: python run_e2e.py [show]   (show = headed Firefox)"""
import os, sys, json, subprocess, time, re
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from bprun import Runtime, BPException, Collection

B = os.path.expanduser('~/videos/pythontoc/build')
PORT = 8766
WORK = os.path.join(HERE, 'work')
headed = len(sys.argv) > 1 and sys.argv[1] == 'show'
if not headed:
    os.environ['MOZ_HEADLESS'] = '1'
fails = 0


def ok(name, cond, info=''):
    global fails
    fails += not cond
    print(('PASS ' if cond else 'FAIL ') + name + (' | ' + str(info) if info else ''))


subprocess.run([sys.executable, os.path.join(HERE, 'build_doubles.py')], check=True, capture_output=True)
subprocess.run([sys.executable, os.path.join(HERE, 'build_server.py'), os.path.join(HERE, 'stage_server_e2e.exe')]
               + [f'{B}/{d}/out' for d in ['browser', 'servicenow', 'alice', 'bluespace', 'tracker', 'common', 'processes']] + [os.path.join(HERE, 'doubles')],
               check=True, capture_output=True)
subprocess.run([os.path.expanduser('~/videos/spire/.venv/bin/python'), os.path.join(HERE, 'make_e2e_fixtures.py'), WORK, str(PORT)], check=True, capture_output=True)
srv = subprocess.Popen([sys.executable, os.path.join(HERE, 'mock', 'serve.py'), str(PORT)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
smtp = subprocess.Popen([sys.executable, os.path.join(HERE, 'mock', 'smtp_sink.py'), str(PORT + 1), os.path.join(WORK, 'mail')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.5)
env = json.load(open(os.path.join(WORK, 'env.json')))
log = open(os.path.join(WORK, 'logs', 'bprun.log'), 'w')
rt = Runtime([f'{B}/{d}/out' for d in ['browser', 'servicenow', 'alice', 'bluespace', 'tracker', 'common', 'processes']] + [os.path.join(HERE, 'doubles')],
             os.path.join(HERE, 'stage_server_e2e.exe'), env['environment'], env['credentials'],
             log=lambda s: (log.write(s + '\n'), log.flush()), wait_scale=0.2)
def T(f):
    path = os.path.join(WORK, 'trackers', f)
    return pd.read_excel(path).fillna('') if os.path.exists(path) else pd.DataFrame()
try:
    # ---------------- Master ----------------
    t0 = time.time()
    rt.run_process('GK Revoke - Master Populate Queue')
    ok('Master finished', True, f'{time.time() - t0:.0f}s, {rt.stage_count} stages')
    r = T('RITM_List_Tracker.xlsx')
    ok('Master: 3 new RITMs registered (1 already known)', len(r) == 4 and set(r.Ticket) == {'RITM0000001', 'RITM0000010', 'RITM0000011', 'RITM0000012'}, r.Ticket.tolist())
    ok('Master: BlueSpace RITM has Application + Open/Open', r.loc[r.Ticket == 'RITM0000012', ['Application', 'Maker Task Status', 'Checker Task Status']].values.tolist() == [['BlueSpace', 'Open', 'Open']])
    ok('Master: in-scope RITM has Application + Open/Open', r.loc[r.Ticket == 'RITM0000010', ['Application', 'Maker Task Status', 'Checker Task Status']].values.tolist() == [['Alice-Global', 'Open', 'Open']])
    ok('Master: out-of-scope RITM Fail/Fail + comment', r.loc[r.Ticket == 'RITM0000011', ['Maker Task Status', 'Checker Task Status', 'Comment']].values.tolist() == [['Fail', 'Fail', 'RITM not in Bot scope']])
    mq = rt.queues.q('GK Revoke Alice Maker')
    ok('Master: exactly one Alice Maker queue item (RITM0000010)', len(mq) == 1 and mq[0]['data'].rows[0]['RITM Number'] == 'RITM0000010', [i['data'].rows[0] for i in mq])
    bq = rt.queues.q('GK Revoke BlueSpace Maker')
    ok('Master: exactly one BlueSpace Maker queue item (RITM0000012)', len(bq) == 1 and bq[0]['data'].rows[0]['RITM Number'] == 'RITM0000012', [i['data'].rows[0] for i in bq])
    ok('Master: bot back Offline', T('Bot_Status.xlsx').set_index('Bot Name').Status['Maker Master Bot'] == 'Offline')

    # ---------------- Maker ----------------
    t0 = time.time()
    rt.run_process('GK Revoke - Alice Maker')
    ok('Maker finished', True, f'{time.time() - t0:.0f}s')
    ok('Maker: queue item completed', mq[0]['status'] == 'Completed', mq[0]['status'] + ' ' + mq[0]['exception'])
    r = T('RITM_List_Tracker.xlsx')
    ok('Maker: tracker Completed', r.loc[r.Ticket == 'RITM0000010', 'Maker Task Status'].iloc[0] == 'Completed', r.loc[r.Ticket == 'RITM0000010', ['Maker Task Status', 'Comment']].values.tolist())
    m = T('Maker_Tracker.xlsx')
    ok('Maker: 3 maker tracker rows (4711, 4712, 4713)', sorted(m.Request_Id.astype(str).tolist()) == ['4711', '4712', '4713'], m[['Owner', 'Role_Name', 'Region Name', 'Request_Id', 'Remarks', 'MTStatus']].values.tolist())
    byreq = m.set_index(m.Request_Id.astype(str))
    ok('Maker: 4711 ROLE_A europe revoke completed', byreq.loc['4711', 'Remarks'] == 'Entitlement/revoke completed' and byreq.loc['4711', 'Region Name'] == 'europe')
    ok('Maker: 4712 ROLE_B all regions -> user absent in AMER wins (Python priority)', byreq.loc['4712', 'Remarks'] == 'User access already revoked' and set(byreq.loc['4712', 'Region Name'].split(',')) == {'europe', 'americas', 'asia pacific'}, byreq.loc['4712', ['Remarks', 'Region Name']].tolist())
    ok('Maker: 4713 account deleted', byreq.loc['4713', 'Remarks'] == 'Entitlement/revoke completed' and byreq.loc['4713', 'Request_Type'] == 'revoke account')
    ok('Maker: rows marked MT Done + Comment computer - Done', (m.MTStatus == 'Done').all() and m.Comment.str.endswith(' - Done').all(), m.Comment.tolist())
    cq = rt.queues.q('GK Revoke Alice Checker')
    ok('Maker: RITM handed to the Checker queue', len(cq) == 1 and cq[0]['data'].rows[0]['RITM Number'] == 'RITM0000010')
    ok('Maker: attachment downloaded into the attachment folder', any(f.endswith('.xlsx') for f in os.listdir(os.path.join(WORK, 'attachments'))))

    # ---------------- Checker ----------------
    t0 = time.time()
    rt.run_process('GK Revoke - Alice Checker')
    ok('Checker finished', True, f'{time.time() - t0:.0f}s')
    ok('Checker: queue item completed', cq[0]['status'] == 'Completed', cq[0]['status'] + ' ' + cq[0]['exception'])
    r = T('RITM_List_Tracker.xlsx')
    ok('Checker: tracker Completed', r.loc[r.Ticket == 'RITM0000010', 'Checker Task Status'].iloc[0] == 'Completed', r.loc[r.Ticket == 'RITM0000010', ['Checker Task Status', 'Comment']].values.tolist())
    c = T('Checker_Tracker.xlsx')
    ok('Checker: rows for 4711, 4712 (x3 regions), 4713, all CT Done + closed', 'Request Id' in c and sorted(c['Request Id'].astype(str).tolist()) == ['4711', '4712', '4712', '4712', '4713'] and (c['Entitlement'].str.strip() == c['Entitlement']).all() and (c['Set CT Status'] == 'Done').all() and (c['Task Complete Closed'] == 'Done').all(),
       c[['Owner', 'Entitlement', 'Action', 'Request Id', 'Set CT Status', 'Task Complete Closed', 'Remark']].values.tolist() if 'Request Id' in c else list(c.columns))
    shots = sorted(f for f in os.listdir(os.path.join(WORK, 'screenshots')) if f.endswith('.png'))
    ok('Checker: evidence screenshots per region/user (info page scrolled where the user exists, one shot where absent)',
       any(f.startswith('RITM0000010_EMEA_john.doe') and f.endswith('_2.png') for f in shots) and 'RITM0000010_AMER_john.doe@example.com.png' in shots
       and 'RITM0000010_EMEA_jane@example.com.png' in shots, shots)
    docs = sorted(f for f in os.listdir(os.path.join(WORK, 'screenshots')) if f.endswith('.docx'))
    ok('Checker: evidence docs built in batches of 3 and labelled', len(docs) >= 2 and all('LABEL LABEL-GUID-TEST' in open(os.path.join(WORK, 'screenshots', d)).read() for d in docs), docs)

    # ---------------- BlueSpace Maker ----------------
    t0 = time.time()
    rt.run_process('GK Revoke - BlueSpace Maker')
    ok('BS Maker finished', True, f'{time.time() - t0:.0f}s')
    ok('BS Maker: queue item completed', bq[0]['status'] == 'Completed', bq[0]['status'] + ' ' + bq[0]['exception'])
    r = T('RITM_List_Tracker.xlsx')
    ok('BS Maker: tracker Completed', r.loc[r.Ticket == 'RITM0000012', 'Maker Task Status'].iloc[0] == 'Completed', r.loc[r.Ticket == 'RITM0000012', ['Maker Task Status', 'Comment']].values.tolist())
    m = T('BlueSpace_Maker_Tracker.xlsx')
    ok('BS Maker: one row per request id 5001-5006', sorted(m.Request_Id.astype(str).tolist()) == ['5001', '5002', '5003', '5004', '5005', '5006'],
       m[['Owner', 'Role_Name', 'Request_Type', 'Request_Id', 'Remarks', 'MTStatus']].values.tolist() if 'Request_Id' in m else list(m.columns))
    byreq = m.set_index(m.Request_Id.astype(str)) if 'Request_Id' in m else None
    if byreq is not None:
        ok('BS Maker: 5001 group 123 removed', byreq.loc['5001', 'Remarks'] == 'User Entitlement Revoked' and str(byreq.loc['5001', 'Role_Name']).split('.')[0] == '123', byreq.loc['5001', ['Role_Name', 'Remarks']].tolist())
        ok('BS Maker: 5002 team 456 removed', byreq.loc['5002', 'Remarks'] == 'User Entitlement Revoked')
        ok('BS Maker: 5003 role 999 nowhere -> already revoked', byreq.loc['5003', 'Remarks'] == 'User Entitlement Already Revoked')
        ok('BS Maker: 5004 only group removed -> user deactivated', byreq.loc['5004', 'Remarks'] == 'No entitlement left. Hence, user account revoked')
        ok('BS Maker: 5005 account deactivated', byreq.loc['5005', 'Remarks'] == 'User Account Revoked' and byreq.loc['5005', 'Request_Type'] == 'revoke account')
        ok('BS Maker: 5006 unknown user -> already revoked', byreq.loc['5006', 'Remarks'] == 'User Account Already Revoked')
        ok('BS Maker: rows stamped MT Status as:True + computer - Done', (m.MTStatus == 'MT Status as:True').all() and m.Comment.str.endswith(' - Done').all() and (m.SC_Updation_Time.astype(str).str.len() > 10).all(), m[['MTStatus', 'Comment', 'SC_Updation_Time']].values.tolist())
    bcq = rt.queues.q('GK Revoke BlueSpace Checker')
    ok('BS Maker: RITM handed to the BlueSpace Checker queue', len(bcq) == 1 and bcq[0]['data'].rows[0]['RITM Number'] == 'RITM0000012')

    # ---------------- BlueSpace Checker ----------------
    t0 = time.time()
    rt.run_process('GK Revoke - BlueSpace Checker')
    ok('BS Checker finished', True, f'{time.time() - t0:.0f}s')
    ok('BS Checker: queue item completed', bcq[0]['status'] == 'Completed', bcq[0]['status'] + ' ' + bcq[0]['exception'])
    r = T('RITM_List_Tracker.xlsx')
    ok('BS Checker: tracker Completed', r.loc[r.Ticket == 'RITM0000012', 'Checker Task Status'].iloc[0] == 'Completed', r.loc[r.Ticket == 'RITM0000012', ['Checker Task Status', 'Comment']].values.tolist())
    c = T('BlueSpace_Checker_Tracker.xlsx')
    ok('BS Checker: rows 5001-5006, all CT Done + closed', 'Request Id' in c and sorted(c['Request Id'].astype(str).tolist()) == ['5001', '5002', '5003', '5004', '5005', '5006'] and (c['Set CT Status'] == 'Done').all() and (c['Task Complete Closed'] == 'Done').all(),
       c[['Owner', 'Entitlement', 'Action', 'Request Id', 'Set CT Status', 'Task Complete Closed', 'Remark']].values.tolist() if 'Request Id' in c else list(c.columns))
    shots = sorted(f for f in os.listdir(os.path.join(WORK, 'bs_screenshots')) if f.endswith('.png'))
    ok('BS Checker: one screenshot per owner', shots == ['RITM0000012_asmith.png', 'RITM0000012_bjones.png', 'RITM0000012_ghost.png', 'RITM0000012_jdoe.png'], shots)
    docs = sorted(f for f in os.listdir(os.path.join(WORK, 'bs_screenshots')) if f.endswith('.docx'))
    ok('BS Checker: evidence docs built and labelled', len(docs) == 2 and all('LABEL LABEL-GUID-TEST' in open(os.path.join(WORK, 'bs_screenshots', d)).read() for d in docs), docs)
    # ---------------- Email (real Common object over SMTP into the sink) ----------------
    import email, glob as _glob
    MAIL = os.path.join(WORK, 'mail')
    def mails():
        return [email.message_from_file(open(f, encoding='utf-8')) for f in sorted(_glob.glob(os.path.join(MAIL, '*.eml')))]
    att = os.path.join(WORK, 'trackers', 'Bot_Status.xlsx')
    rt.call_object('GK Revoke Common', 'Send Email', {
        'SMTP Server': env['environment']['GK Revoke SMTP Server'], 'From': 'gk-revoke-bot@example.com', 'To': 'a@example.com; b@example.com',
        'Cc': 'c@example.com', 'Subject': 'GK Revoke e2e report', 'HTML Body': '<p>Hello <b>team</b></p>', 'Attachments': att})
    m = mails()
    ok('Email: Send Email delivered one message', len(m) == 1, len(m))
    if m:
        ok('Email: envelope To = To + Cc, From as given', m[0]['X-Envelope-To'] == 'a@example.com, b@example.com, c@example.com' and m[0]['X-Envelope-From'] == 'gk-revoke-bot@example.com', dict(m[0].items()))
        ok('Email: subject / Cc header / multipart with the xlsx attached', m[0]['Subject'] == 'GK Revoke e2e report' and m[0]['Cc'] == 'c@example.com'
           and m[0].is_multipart() and any(p.get_filename() == 'Bot_Status.xlsx' for p in m[0].walk()), [p.get_content_type() for p in m[0].walk()])
        html = next((p.get_payload(decode=True).decode() for p in m[0].walk() if p.get_content_type() == 'text/html'), '')
        ok('Email: HTML body intact', 'Hello <b>team</b>' in html, html[:80])
    try:
        rt.call_object('GK Revoke Common', 'Send Email', {'SMTP Server': '', 'From': 'x@example.com', 'To': 'y@example.com', 'Cc': '', 'Subject': 's', 'HTML Body': '', 'Attachments': ''})
        ok('Email: empty SMTP Server raises', False)
    except BPException as e:
        ok('Email: empty SMTP Server raises a System Exception', e.etype == 'System Exception' and 'SMTP Server is empty' in e.detail, e.detail)
    # a fatal failure outside the per-RITM block: the Alice Maker with a config that does not exist
    saved = rt.env['GK Revoke Alice Maker Config Path']
    rt.env['GK Revoke Alice Maker Config Path'] = os.path.join(WORK, 'config', 'does_not_exist.ini')
    try:
        rt.run_process('GK Revoke - Alice Maker')
        ok('Fatal: Main re-raised the failure', False)
    except BPException as e:
        ok('Fatal: Main re-raised the failure after Report Fatal', e.etype == 'System Exception' and 'does_not_exist.ini' in e.detail, e.detail[:120])
    finally:
        rt.env['GK Revoke Alice Maker Config Path'] = saved
    m = mails()
    ok('Fatal: exception email sent over SMTP to the configured team', len(m) == 2 and m[1]['X-Envelope-To'] == 'l1-team@example.com, idam-rpa@example.com', len(m))
    if len(m) == 2:
        html = next((p.get_payload(decode=True).decode() for p in m[1].walk() if p.get_content_type() == 'text/html'), '')
        ok('Fatal: subject "<bot> Automation Exception", body names the exception', m[1]['Subject'].endswith(' Automation Exception') and 'does_not_exist.ini' in html and 'stopped working' in html, (m[1]['Subject'], html[:200]))

except BPException as e:
    ok(f'process failed: {e.etype} at {e.stage!r}: {e.detail[:300]}', False)
except Exception as e:
    ok(f'harness error: {type(e).__name__}: {str(e)[:300]}', False)

# the mocks keep their state on the server (each browser launch is a fresh profile); read it directly
try:
    import urllib.request
    snow = json.loads(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/state/snow_state').read() or b'{}')
    alice = json.loads(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/state/alice_state').read() or b'{}')
    bs = json.loads(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/state/bluespace_state').read() or b'{}')
    ok('mock state readable', bool(snow) and bool(alice) and bool(bs))
    if snow:
        R = snow['ritms']['RITM0000010']
        mt = {r['request']: r['mt'] for r in R['rcrt']}
        ok('SNOW: MT status true on 4711/4712/4713, untouched on 4799', mt == {'4711': 'true', '4712': 'true', '4713': 'true', '4799': 'false'}, mt)
        cm = {r['request']: r['comment'] for r in R['rcrt']}
        ok('SNOW: comments carry the statuses', cm['4711'] == 'Entitlement/revoke completed' and cm['4712'] == 'User access already revoked' and cm['4799'] == '', cm)
        task = R['tasks'][0]
        ok('SNOW: maker task closed complete with "Maker Task Done"', task['state'] == 'Closed complete' and 'Maker Task Done' in task['notes'], (task['state'], task['notes']))
        t2 = R['tasks'][1]
        ok('SNOW: checker task closed complete with "CT Done"', t2['state'] == 'Closed complete' and 'CT Done' in t2['notes'], (t2['state'], t2['notes']))
        ok('SNOW: attachment downloaded (mock log)', any(e.startswith('download') for e in snow['log']))
    if snow:
        R = snow['ritms']['RITM0000012']
        mt = {r['request']: r['mt'] for r in R['rcrt']}
        ok('SNOW BS: MT true on every RCRT row incl. the unmatched 5099 (Python behaviour)', all(v == 'true' for v in mt.values()), mt)
        cm = {r['request']: r['comment'] for r in R['rcrt']}
        ok('SNOW BS: comments = the remarks, unmatched = "role already revoked"',
           cm['5001'] == 'User Entitlement Revoked' and cm['5004'] == 'No entitlement left. Hence, user account revoked' and cm['5006'] == 'User Account Already Revoked' and cm['5099'] == 'role already revoked', cm)
        ct = {r['request']: r['ct'] for r in R['rcrt']}
        ok('SNOW BS: CT true on 5001-5006, untouched on 5099', ct == {'5001': 'true', '5002': 'true', '5003': 'true', '5004': 'true', '5005': 'true', '5006': 'true', '5099': 'false'}, ct)
        ok('SNOW BS: maker task closed "MT Done", checker task closed "CT Done"',
           R['tasks'][0]['state'] == 'Closed complete' and 'MT Done' in R['tasks'][0]['notes'] and R['tasks'][1]['state'] == 'Closed complete' and 'CT Done' in R['tasks'][1]['notes'],
           [(t['state'], t['notes']) for t in R['tasks']])
        ok('SNOW BS: attachment downloaded (mock log)', any(e == 'download attach_RITM0000012.xlsx' for e in snow['log']))
    if bs:
        U = bs['users']
        ok('BlueSpace: jdoe lost group 123 and team 456, kept 777, still Active', U['jdoe']['groups'] == ['777: Operations'] and U['jdoe']['teams'] == [] and U['jdoe']['status'] == 'Active', U['jdoe'])
        ok('BlueSpace: asmith lost its only group and is Inactive', U['asmith']['groups'] == [] and U['asmith']['status'] == 'Inactive', U['asmith'])
        ok('BlueSpace: bjones Inactive, group untouched', U['bjones']['status'] == 'Inactive' and U['bjones']['groups'] == ['888: Finance'], U['bjones'])
        ok('BlueSpace: carol (control, team 123 lookalike) untouched', U['carol'] == {'status': 'Active', 'groups': ['555: Control'], 'teams': ['123: Lookalike']}, U['carol'])
        ok('BlueSpace: login form was used once (session created by the Maker)', bool(json.loads(urllib.request.urlopen(f'http://127.0.0.1:{PORT}/state/bluespace_session').read() or b'{}')))
    if alice:
        E, A, P = alice['regions']['EMEA'], alice['regions']['AMER'], alice['regions']['APAC']
        ok('Alice EMEA: john ROLE_A and ROLE_B unticked, ROLE_C kept', [r['checked'] for r in E['john.doe@example.com']['roles']] == [False, False, True], E['john.doe@example.com']['roles'])
        ok('Alice APAC: john untouched (ROLE_B was already unticked)', [r['checked'] for r in P['john.doe@example.com']['roles']] == [False, True])
        ok('Alice: jane deleted in EMEA and APAC', 'jane@example.com' not in E and 'jane@example.com' not in P, alice['log'])
        ok('Alice AMER: nothing changed', list(A.keys()) == ['other@example.com'])
except BPException as e:
    ok(f'state read failed: {e.detail[:200]}', False)

print('ALL PASS' if fails == 0 else f'{fails} FAILED')
rt.close(); srv.terminate(); srv.wait(5); smtp.terminate(); smtp.wait(5); log.close()
print('log:', os.path.join(WORK, 'logs', 'bprun.log'))
sys.exit(1 if fails else 0)
