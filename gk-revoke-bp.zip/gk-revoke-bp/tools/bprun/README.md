# bprun -- run the generated Blue Prism XML here, end to end

`bprun.py` interprets the XML that `build/*/build_*.py` generate: every stage type the generator
emits (action, code, decision, choice, calc/multi-calc, loop, page reference, wait, exception,
Block/Recover/Resume by geometry, data exposure), Blue Prism expressions (the subset the flows use),
Work Queues and Credentials (simulated in Python), Environment/Session variables. Code stages are
NOT re-implemented: `stage_server.exe` (mono) hosts the exact C# that `compile_check.py` extracts
from the XML and executes each stage by reflection, so the browser, the trackers, the INI reader run
the real code. Collections cross the wire as `{"columns":[{name,type}],"rows":[...]}`.

| File | What |
|---|---|
| `bprun.py` | the interpreter (library + CLI) |
| `StageServer.cs`, `build_server.py` | compile the stage classes of every object/process + the doubles into `stage_server_e2e.exe` |
| `build_doubles.py` -> `doubles/` | stand-in for the one object that needs Windows: Evidence (Word) writes `.docx` text files and appends `LABEL <id>` |
| `mock/smtp_sink.py` | minimal SMTP server (no auth, no TLS, like the estate relay) on port+1; every message lands as `work/mail/<n>.eml` |
| `mock/serve.py`, `mock/snow/`, `mock/alice/`, `mock/bluespace/` | mock ServiceNow, Alice and BlueSpace on 127.0.0.1:8766 with the REAL XPaths of the configs; state lives on the server (each browser launch is a fresh profile) |
| `make_e2e_fixtures.py` | work folder: the five INIs pointed at the mock, trackers, the SNOW attachment, env.json |
| `run_e2e.py` | Master Populate -> Alice Maker -> Alice Checker -> BlueSpace Maker -> BlueSpace Checker then the real Common object: `Send Email` with Cc + attachment, and a forced fatal run (Alice Maker, missing config) that must email the team; 70 assertions on queues, trackers, evidence files, mail, SNOW / Alice / BlueSpace state |

Run (needs mono, Firefox + `~/tools/geckodriver/geckodriver`, the spire venv for pandas):
```
cd tools/bprun && timeout 1200 ~/videos/spire/.venv/bin/python run_e2e.py
```
Result 2026-10-10: **ALL PASS (70/70)**, ~2 min. Log: `work/logs/bprun.log` (every stage, every
object call with inputs/outputs, every decision), browser trace in `work/logs/`.

## What the e2e found (all fixed at the source, see build/README.md)
Alice Login checked a frame from inside another frame; the browser kind was hard-coded; in+out
code-stage items did not flow back (compile_check now marks them `ref`); the wrong Recover was
picked for nested Blocks (innermost Block owns the exception); `Update Field` on a tracker that does
not exist yet; the Checker config lacked `RCRT_remediation`/`RCRT_refresh_list`; the attachment
checkbox XPath had no index slot (the Python's `.format()` silently ignored the index); the
tracker's `XmlDocument.Save` wrote indentation INSIDE empty cells (an empty entitlement read back
as whitespace); `OR` in my evaluator short-circuited and left the right operand unparsed.

## Mock conventions worth knowing
State lives on the server (`/state/<name>`, sync XHR from the pages) because every process launch is
a fresh browser profile. The BlueSpace mock shows its login form until a session exists, so the Maker
exercises the credential path and the Checker the SSO path. The SNOW task page carries both locator
shapes the configs use: `div[@aria-label=...]` lists [1]/[2] for Alice and 7 `tbody.list2_body`
for the BlueSpace Maker (5 hidden dummies first), `id="sysverb_update"` on Save & Exit,
`id="cell_edit_ok"` on the cell editor save, per-RITM `attach_<RITM>.xlsx`.

## Dev-box-only shims (no effect on the estate)
- `Wd.Screenshot` maps `\` to the platform separator (flows join paths with `\`, correct on Windows).
- `StageServer.ToTable` matches row keys to columns by trimmed name: mono's JavaScriptSerializer
  trims dictionary keys (`"Processing Date "` arrives as `"Processing Date"`). Blue Prism never
  goes through JSON.
- Firefox/geckodriver instead of Edge/msedgedriver (the `edge` capabilities block is untested here).

## Limits
Expressions: `& + - * / = <> < > <= >= AND OR`, `Len Left Right Mid Trim Replace InStr Upper Lower
Instr ToNumber Round Now Today FormatDate IsStopRequested ExceptionType ExceptionDetail ExceptionStage`
and what else the generated flows use; anything else raises. Waits are scaled by `wait_scale`.
Not a Blue Prism: no runtime resources, no locking semantics, no multi-robot queue contention.
