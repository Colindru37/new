"""Set up a fresh e2e work folder: the three bot INIs (canonical configs with URLs/paths pointed at
the mock and the work folder), the tracker files, the SNOW attachment, the email template and
env.json. Usage: python make_e2e_fixtures.py <work_dir> <port>"""
import os, sys, json, shutil, configparser
import pandas as pd

work, port = os.path.abspath(sys.argv[1]), int(sys.argv[2])
HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.expanduser('~/videos/pythontoc/build/config')
if os.path.exists(work):
    shutil.rmtree(work)
for d in ['config', 'trackers', 'attachments', 'screenshots', 'logs']:
    os.makedirs(os.path.join(work, d))
W = lambda *p: os.path.join(work, *p)

trk = W('trackers', 'RITM_List_Tracker.xlsx')
pd.DataFrame({"Date": ["2026-10-01"], "Time": ["09:00:00"], "Ticketing Tool": ["Test Ticketing Tool"], "Application": ["Alice-Global"],
              "UseCase": ["Revocation"], "Ticket": ["RITM0000001"], "Maker Task Status": ["Completed"], "Checker Task Status": ["Completed"],
              "Comment": ["PC1 - done long ago"]}).to_excel(trk, index=False)
pd.DataFrame({"Bot Name": ["Alice-Global Maker Bot-1", "Alice-Global Checker Bot", "Maker Master Bot", "BlueSpcae Maker Bot-1", "BlueSpcae Checker Bot"], "Status": ["Offline"] * 5}) \
    .to_excel(W('trackers', 'Bot_Status.xlsx'), index=False)
pd.DataFrame({"NAR ID": ["10001-1", "20002-1"], "Application Name": ["Alice-Global", "BlueSpace"], "Status": ["Active", "Active"]}) \
    .to_excel(W('trackers', 'Revocation_Application_list.xlsx'), index=False)
# the SNOW attachment for RITM0000010 (served by the mock as attach.xlsx)
att = pd.DataFrame({"account": ["john.doe@example.com", "john.doe@example.com", "jane@example.com"],
                    "action": ["revoke entitlement", "revoke entitlement", "revoke account"],
                    "entitlement": ["ROLE_A_EMEA", "ROLE_B", None], "application": ["Alice-Global"] * 3, "request_no": [4711, 4712, 4713]})
att.to_excel(os.path.join(HERE, 'mock', 'snow', 'attach_RITM0000010.xlsx'), index=False)
# the BlueSpace attachment for RITM0000012 (entitlement = group/team number)
pd.DataFrame({"account": ["jdoe", "jdoe", "jdoe", "asmith", "bjones", "ghost"],
              "action": ["revoke entitlement"] * 4 + ["revoke account"] * 2,
              "entitlement": [123, 456, 999, 321, None, None], "application": ["BlueSpace"] * 6,
              "request_no": [5001, 5002, 5003, 5004, 5005, 5006]}).to_excel(os.path.join(HERE, 'mock', 'snow', 'attach_RITM0000012.xlsx'), index=False)
for stale in ['attach.xlsx']:
    if os.path.exists(os.path.join(HERE, 'mock', 'snow', stale)): os.remove(os.path.join(HERE, 'mock', 'snow', stale))
open(W('config', 'exception.msg'), 'w').write('template')


def rewrite(src, dst, elements, urls):
    cp = configparser.RawConfigParser(); cp.optionxform = str
    cp.read(os.path.join(CFG, src), encoding='utf-8')
    for k, v in elements.items():
        cp.set('ELEMENTS', k, v)
    for k, v in urls.items():
        cp.set('URLS', k, v)
    with open(dst, 'w', encoding='utf-8') as f:
        cp.write(f, space_around_delimiters=True)


snow = f'http://127.0.0.1:{port}/snow/nav_to.do?uri=%%2Fcom.glideapp.servicecatalog_cat_item_view.do%%3Fv%%3D1'
alice = f'http://127.0.0.1:{port}/alice/LocalAlice/'
common = {'log_path': W('logs'), 'Bot_status_file': W('trackers', 'Bot_Status.xlsx'),
          'RITM_list_tracker_path': trk, 'sample_email_file_path': W('config', 'exception.msg'),
          'Maker_task_internal_tracker_path': W('trackers', 'Maker_Tracker.xlsx'),
          'implicit_delay': '3', 'explicit_delay': '5', 'explicit_delay2': '5', 'explicit_delay3': '5', 'explicit_delay4': '10'}
rewrite('alice_maker.ini', W('config', 'alice_maker.ini'), dict(common, attachment_folder_path=W('attachments')), {'snow_url': snow, 'alice_url': alice})
rewrite('alice_checker.ini', W('config', 'alice_checker.ini'),
        dict(common, checker_task_internal_tracker_path=W('trackers', 'Checker_Tracker.xlsx'), screenshot_folder_path=W('screenshots'),
             screenshot_file_count='3'), {'snow_url': snow, 'alice_url': alice})
rewrite('master_populate.ini', W('config', 'master_populate.ini'),
        {'log_path': W('logs'), 'Bot_status_file': W('trackers', 'Bot_Status.xlsx'), 'RITM_List_tracker_path': trk,
         'revocation_application_list': W('trackers', 'Revocation_Application_list.xlsx'), 'sample_email_file_path': W('config', 'exception.msg'),
         'implicit_delay': '3', 'explicit_delay': '5', 'assignment_group': 'RPA_TEST_GROUP', 'ticketing_tool': 'Test Ticketing Tool'},
        {'snow_url': f'http://127.0.0.1:{port}/snow/nav_to.do?uri=%%2Fsc_task_list.do%%3Fsysparm_query%%3Dactive'})

bluespace = f'http://127.0.0.1:{port}/bluespace/index.html#/administration/user'
bs_common = {'log_path': W('logs'), 'Bot_status_file': W('trackers', 'Bot_Status.xlsx'), 'RITM_list_tracker_path': trk,
             'sample_email_file_path': W('config', 'exception.msg'), 'implicit_delay': '3', 'explicit_delay': '5'}
rewrite('bluespace_maker.ini', W('config', 'bluespace_maker.ini'),
        dict(bs_common, Attchment=W('bs_attachments'), attachment_folder_path=W('bs_attachments'),
             Maker_Internal_tracker_path=W('trackers', 'BlueSpace_Maker_Tracker.xlsx'), Maker_task_internal_tracker_path=W('trackers', 'BlueSpace_Maker_Tracker.xlsx')),
        {'snow_url': snow, 'URLFile': snow, 'bluespace_url': bluespace, 'BluespaceApplicationURL': bluespace})
rewrite('bluespace_checker.ini', W('config', 'bluespace_checker.ini'),
        dict(bs_common, Maker_task_internal_tracker_path=W('trackers', 'BlueSpace_Maker_Tracker.xlsx'),
             checker_task_internal_tracker_path=W('trackers', 'BlueSpace_Checker_Tracker.xlsx'), screenshot_folder_path=W('bs_screenshots'),
             screenshot_file_count='3', explicit_delay2='5', explicit_delay3='5', explicit_delay4='10'),
        {'snow_url': snow, 'blueSpace_url': bluespace})
os.makedirs(W('bs_attachments')); os.makedirs(W('bs_screenshots'))

env = {'environment': {
    'GK Revoke SMTP Server': f'127.0.0.1:{int(sys.argv[2]) + 1}', 'GK Revoke Email From': 'gk-revoke-bot@example.com',
    'GK Revoke Email To': 'l1-team@example.com; idam-rpa@example.com',
    'GK Revoke BlueSpace Maker Config Path': W('config', 'bluespace_maker.ini'),
    'GK Revoke BlueSpace Checker Config Path': W('config', 'bluespace_checker.ini'),
    'GK Revoke BlueSpace Maker Queue Name': 'GK Revoke BlueSpace Maker', 'GK Revoke BlueSpace Checker Queue Name': 'GK Revoke BlueSpace Checker',
    'GK Revoke BlueSpace Credential Name': 'BlueSpace Bot',
    'GK Revoke Alice Maker Config Path': W('config', 'alice_maker.ini'),
    'GK Revoke Alice Checker Config Path': W('config', 'alice_checker.ini'),
    'GK Revoke Master Config Path': W('config', 'master_populate.ini'),
    'GK Revoke Run Mode': 'live', 'GK Revoke Driver Path': os.path.expanduser('~/tools/geckodriver/geckodriver'),
    'GK Revoke Profile Root': '', 'GK Revoke Browser Kind': 'firefox', 'GK Revoke Log Folder': W('logs'),
    'GK Revoke Alice Maker Queue Name': 'GK Revoke Alice Maker', 'GK Revoke Alice Checker Queue Name': 'GK Revoke Alice Checker',
    'GK Revoke Max Consecutive Failures': 3, 'GK Revoke Alice Credential Name': 'Alice Bot', 'GK Revoke Label ID': 'LABEL-GUID-TEST'},
    'credentials': {'Alice Bot': ['idam-test@mock', 'secret'], 'BlueSpace Bot': ['bsbot', 'bs-secret']}}
json.dump(env, open(W('env.json'), 'w'), indent=1)
print('fixtures in', work)
