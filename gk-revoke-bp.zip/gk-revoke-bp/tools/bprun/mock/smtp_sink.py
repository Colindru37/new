"""Mail sink for the e2e: a minimal SMTP server (no auth, no TLS, like the estate relay the email VBO
talks to) that stores every message as <outdir>/<n>.eml. Usage: python smtp_sink.py <port> <outdir>"""
import asyncio, os, sys

PORT, OUT = int(sys.argv[1]), sys.argv[2]
os.makedirs(OUT, exist_ok=True)
count = 0


async def session(reader, writer):
    global count
    async def say(s):
        writer.write((s + '\r\n').encode()); await writer.drain()
    await say('220 sink ESMTP')
    data, in_data, env = [], False, {'from': '', 'to': []}
    while True:
        line = await reader.readline()
        if not line:
            break
        text = line.decode('utf-8', 'replace').rstrip('\r\n')
        if in_data:
            if text == '.':
                in_data = False
                count += 1
                with open(os.path.join(OUT, f'{count:03d}.eml'), 'w', encoding='utf-8') as f:
                    f.write(f'X-Envelope-From: {env["from"]}\nX-Envelope-To: {", ".join(env["to"])}\n')
                    f.write('\n'.join(l[1:] if l.startswith('..') else l for l in data) + '\n')
                data, env = [], {'from': '', 'to': []}
                await say('250 OK queued')
            else:
                data.append(text)
            continue
        verb = text.split(' ', 1)[0].upper()
        if verb in ('EHLO', 'HELO'):
            await say('250-sink\r\n250 8BITMIME')
        elif verb == 'MAIL':
            env['from'] = text.split(':', 1)[1].strip().strip('<>'); await say('250 OK')
        elif verb == 'RCPT':
            env['to'].append(text.split(':', 1)[1].strip().strip('<>')); await say('250 OK')
        elif verb == 'DATA':
            in_data = True; await say('354 End data with <CR><LF>.<CR><LF>')
        elif verb == 'QUIT':
            await say('221 Bye'); break
        elif verb in ('RSET', 'NOOP'):
            await say('250 OK')
        else:
            await say('500 unknown')
    writer.close()


async def main():
    server = await asyncio.start_server(session, '127.0.0.1', PORT)
    async with server:
        await server.serve_forever()

asyncio.run(main())
