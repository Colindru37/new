<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>ServiceNow (mock)</title>
<style>body{font-family:sans-serif} #popup{border:1px solid #888;padding:10px;background:#eee} iframe{width:100%;height:900px;border:1px solid #ccc}</style>
</head>
<body>
<h3>ServiceNow (mock)</h3>
<div id="popup">
  <p>Welcome. Tick to continue: <span class="input-group-checkbox" onclick="document.getElementById('ok').disabled=false; this.textContent='[x]'">[ ]</span></p>
  <button id="ok" disabled onclick="localStorage.setItem('snow_popup_done','1'); document.getElementById('popup').style.display='none'">OK</button>
</div>
<p>Search: <input id="sysparm_search" type="text" placeholder="RITM..."
   onkeydown="if(event.key==='Enter'){document.getElementById('gsft_main').src='frame.html?q='+encodeURIComponent(this.value)}"></p>
<iframe id="gsft_main" name="gsft_main" src=""></iframe>
<script>
  if (localStorage.getItem('snow_popup_done')) document.getElementById('popup').style.display = 'none';
  var q = new URLSearchParams(location.search).get('uri') || '';
  // the Master's queue URL lists the open tasks; the bots' URL shows an empty frame until a search
  document.getElementById('gsft_main').src = q.indexOf('sc_task_list') >= 0 ? 'frame.html?view=queue' : 'frame.html?view=home';
</script>
</body></html>
