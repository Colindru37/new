"""Mock SNOW + Alice on one port: http://127.0.0.1:PORT/snow/... and /alice/LocalAlice/...
attach.xlsx is served with the Excel content type and a download disposition."""
import http.server, sys, os, threading
STATE, LOCK = {}, threading.Lock()   # server-side state: survives browser relaunches (each launch = fresh profile)
ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)


class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                      '.do': 'text/html'}

    def do_GET(self):
        if self.path.startswith('/state/'):
            with LOCK:
                body = STATE.get(self.path[7:], '').encode('utf-8')
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(body)))
            self.end_headers(); self.wfile.write(body); return
        if self.path.startswith('/snow/nav_to.do'):
            self.path = '/snow/nav_to.do'   # drop the query for the file lookup; the page reads location.search
        return super().do_GET()

    def do_PUT(self):
        n = int(self.headers.get('Content-Length', '0'))
        body = self.rfile.read(n).decode('utf-8')
        with LOCK:
            STATE[self.path[7:]] = body
        self.send_response(204); self.end_headers()

    def end_headers(self):
        if self.path.endswith('.xlsx'):
            self.send_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(self.path))
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def log_message(self, *a):
        pass


if __name__ == '__main__':
    http.server.ThreadingHTTPServer(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
