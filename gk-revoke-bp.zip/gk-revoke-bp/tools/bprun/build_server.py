"""Build stage_server.exe: every object/process XML in the given dirs -> compile_check's extracted
stage class (the exact source compile_check gates) + StageServer.cs, compiled with mcs (C# 5).
Usage: python build_server.py <out.exe> <dir> [<dir> ...]"""
import sys, os, glob, subprocess
import xml.etree.ElementTree as ET
sys.path.insert(0, os.path.expanduser('~/.claude/skills/rpa-bp/lib'))
import compile_check as cc

HERE = os.path.dirname(os.path.abspath(__file__))
exe, dirs = sys.argv[1], sys.argv[2:]
sources, refs = [], set(['System.Net.Http.dll', 'System.Web.Extensions.dll', 'System.Data.dll', 'System.Xml.dll',
                        'System.Core.dll', 'System.Drawing.dll', 'System.IO.Compression.dll', 'System.IO.Compression.FileSystem.dll'])
for d in dirs:
    for path in sorted(glob.glob(os.path.join(d, '*.xml'))):
        root = ET.parse(path).getroot()
        cc.strip_ns(root)
        name = root.get('name')
        src, lang, n, labels = cc.build_source(root, name)
        if src is None:
            continue
        if lang != 'csharp':
            raise SystemExit(f'{path}: {lang} not supported by the stage server')
        info = next(st for st in root.iter('stage') if st.get('type') == 'ProcessInfo')
        for r in info.iter('reference'):
            refs.add(r.text.strip())
        sources.append((name, src))
        print(f'  {name}: {n} code stages')
work = os.path.join(HERE, 'build')
os.makedirs(work, exist_ok=True)
files = []
for i, (name, src) in enumerate(sources):
    f = os.path.join(work, f'{i:02d}_{cc.ident(name)}.cs')
    with open(f, 'w', encoding='utf-8') as fh:
        fh.write(src)
    files.append(f)
cmd = ['mcs', '-langversion:5', '-nowarn:0162,0168,0219,0414,0649', '-out:' + exe] + [f'-r:{r}' for r in sorted(refs)] \
      + [os.path.join(HERE, 'StageServer.cs')] + files
r = subprocess.run(cmd, capture_output=True, text=True)
if r.returncode != 0:
    print(r.stdout, r.stderr)
    raise SystemExit('stage server build failed')
print('built', exe, 'from', len(sources), 'objects/processes')
