// Stage server: hosts the stage classes compile_check extracts from every object/process
// (BPCheck_<ident(name)>, one method per Code stage) and executes them on request, so the
// Python flow interpreter can run the exact C# that Blue Prism would. Static state (the browser
// session, the loaded config) lives here for the life of the process, like a Blue Prism session.
// Protocol: one JSON object per line on stdin -> one JSON object per line on stdout.
//   {"obj":"GK Revoke Browser","stage":"Run Click","args":{"XPath_Key":"go","Index":0,"Timeout":0}}
//   {"ok":true,"out":{"Error_Text":""}}   |   {"ok":false,"error":"..."}
// Collections travel as {"columns":[{"name":..,"type":"string|bool|decimal|datetime|double"}],"rows":[{..}]}.
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Web.Script.Serialization;

static class StageServer
{
    static readonly JavaScriptSerializer json = new JavaScriptSerializer();

    static string Ident(string name)
    {
        string s = System.Text.RegularExpressions.Regex.Replace(name.Trim().Replace(' ', '_'), "[^A-Za-z0-9_]", "_");
        return (s.Length == 0 || char.IsDigit(s[0])) ? "_" + s : s;
    }

    static void Main()
    {
        json.MaxJsonLength = int.MaxValue;
        var instances = new Dictionary<string, object>();
        string line;
        var stdout = Console.Out;
        while ((line = Console.ReadLine()) != null)
        {
            if (line.Trim().Length == 0) continue;
            string reply;
            try { reply = Handle(line, instances); }
            catch (Exception e) { reply = json.Serialize(new Dictionary<string, object> { { "ok", false }, { "error", Describe(e) } }); }
            stdout.WriteLine(reply); stdout.Flush();
        }
    }

    static string Describe(Exception e)
    {
        var t = e as TargetInvocationException;
        if (t != null && t.InnerException != null) e = t.InnerException;
        return e.GetType().Name + ": " + e.Message;
    }

    static string Handle(string line, Dictionary<string, object> instances)
    {
        var req = json.Deserialize<Dictionary<string, object>>(line);
        string obj = Convert.ToString(req["obj"]), stage = Convert.ToString(req["stage"]);
        if (obj == "__ping__") return json.Serialize(new Dictionary<string, object> { { "ok", true }, { "out", new Dictionary<string, object>() } });
        string cls = "BPCheck_" + Ident(obj);
        Type type = Type.GetType(cls);
        if (type == null) foreach (Type t in Assembly.GetExecutingAssembly().GetTypes()) if (t.Name == cls) { type = t; break; }
        if (type == null) throw new Exception("No stage class for object '" + obj + "' (" + cls + ")");
        object inst;
        if (!instances.TryGetValue(cls, out inst)) { inst = Activator.CreateInstance(type); instances[cls] = inst; }
        string meth = Ident(stage);
        MethodInfo m = type.GetMethod(meth, BindingFlags.Public | BindingFlags.Instance);
        if (m == null) throw new Exception("No code stage '" + stage + "' (" + meth + ") in " + obj);
        var args = req.ContainsKey("args") && req["args"] != null ? (Dictionary<string, object>)req["args"] : new Dictionary<string, object>();
        ParameterInfo[] ps = m.GetParameters();
        object[] vals = new object[ps.Length];
        for (int i = 0; i < ps.Length; i++)
        {
            if (ps[i].IsOut && !args.ContainsKey(ps[i].Name) && !args.ContainsKey(ps[i].Name.TrimStart('@'))) { vals[i] = null; continue; }
            object raw;
            if (!args.TryGetValue(ps[i].Name, out raw) && !args.TryGetValue(ps[i].Name.TrimStart('@'), out raw))
                throw new Exception("Missing input '" + ps[i].Name + "' for " + obj + "." + stage);
            vals[i] = Convert_(raw, ps[i].ParameterType);
        }
        m.Invoke(inst, vals);
        var outs = new Dictionary<string, object>();
        for (int i = 0; i < ps.Length; i++) if (ps[i].ParameterType.IsByRef) outs[ps[i].Name] = Export(vals[i]);   // out AND ref (input+output items)
        return json.Serialize(new Dictionary<string, object> { { "ok", true }, { "out", outs } });
    }

    static object Convert_(object raw, Type t)
    {
        if (t.IsByRef) t = t.GetElementType();
        if (t == typeof(string)) return raw == null ? "" : Convert.ToString(raw);
        if (t == typeof(decimal)) return raw == null ? 0m : Convert.ToDecimal(raw, System.Globalization.CultureInfo.InvariantCulture);
        if (t == typeof(bool)) return raw != null && (raw is bool ? (bool)raw : Convert.ToString(raw).ToLowerInvariant() == "true");
        if (t == typeof(DateTime)) return raw == null || Convert.ToString(raw).Length == 0 ? DateTime.MinValue : DateTime.Parse(Convert.ToString(raw), System.Globalization.CultureInfo.InvariantCulture);
        if (t == typeof(System.Security.SecureString))
        {
            var ss = new System.Security.SecureString();
            foreach (char c in Convert.ToString(raw ?? "")) ss.AppendChar(c);
            return ss;
        }
        if (t == typeof(DataTable)) return ToTable(raw);
        throw new Exception("Unsupported parameter type " + t.Name);
    }

    static Type ColType(string name)
    {
        switch ((name ?? "string").ToLowerInvariant())
        {
            case "bool": return typeof(bool);
            case "decimal": return typeof(decimal);
            case "double": return typeof(double);
            case "int": return typeof(int);
            case "datetime": return typeof(DateTime);
            default: return typeof(string);
        }
    }

    static DataTable ToTable(object raw)
    {
        var t = new DataTable();
        var d = raw as Dictionary<string, object>;
        if (d == null) return t;
        if (d.ContainsKey("columns"))
            foreach (object c in (System.Collections.IEnumerable)d["columns"])
            {
                var cd = (Dictionary<string, object>)c;
                t.Columns.Add(Convert.ToString(cd["name"]), ColType(cd.ContainsKey("type") ? Convert.ToString(cd["type"]) : "string"));
            }
        if (d.ContainsKey("rows"))
            foreach (object r in (System.Collections.IEnumerable)d["rows"])
            {
                var rd = (Dictionary<string, object>)r;
                var row = t.NewRow();
                foreach (var kv in rd)
                {
                    // mono's JavaScriptSerializer trims dictionary keys ("Processing Date " -> "Processing Date"):
                    // match row keys to the declared columns by trimmed name so a header keeps its exact text
                    DataColumn col = null;
                    foreach (DataColumn c in t.Columns) if (c.ColumnName.Trim() == kv.Key.Trim()) { col = c; break; }
                    if (col == null) col = t.Columns.Add(kv.Key, typeof(string));
                    row[col] = kv.Value == null ? DBNull.Value : Convert_(kv.Value, col.DataType);
                }
                t.Rows.Add(row);
            }
        return t;
    }

    static object Export(object v)
    {
        if (v == null) return null;
        var t = v as DataTable;
        if (t != null)
        {
            var cols = new List<object>();
            foreach (DataColumn c in t.Columns)
            {
                string ty = c.DataType == typeof(bool) ? "bool" : c.DataType == typeof(decimal) ? "decimal" : c.DataType == typeof(double) ? "double"
                    : c.DataType == typeof(int) ? "int" : c.DataType == typeof(DateTime) ? "datetime" : "string";
                cols.Add(new Dictionary<string, object> { { "name", c.ColumnName }, { "type", ty } });
            }
            var rows = new List<object>();
            foreach (DataRow r in t.Rows)
            {
                var rd = new Dictionary<string, object>();
                foreach (DataColumn c in t.Columns) rd[c.ColumnName] = r[c] == DBNull.Value ? null : Export(r[c]);
                rows.Add(rd);
            }
            return new Dictionary<string, object> { { "columns", cols }, { "rows", rows } };
        }
        if (v is decimal) return Convert.ToDouble((decimal)v);
        if (v is DateTime) return ((DateTime)v).ToString("s");
        if (v is System.Security.SecureString) return "***";
        return v;
    }
}
