# GK Revoke on Blue Prism

The full build: 7 objects + 5 processes (`xml/`), generated and run end to end on the dev box
(70/70 against mock ServiceNow / Alice / BlueSpace). Nothing here needs installing; Python is only
used for the three helper scripts and the two gate tools (standard library only).

## 1. Unzip, check, restore the real values (5 minutes)
```
python restore_config.py --check          -> PACKAGE OK
notepad restore_values.txt                -> fill each value (SCRUB_SHEET.md says where to read it)
python restore_config.py                  -> every file OK, "RESTORED ... byte-identical"
```
`config/` is now the PROD config (same values as the Python INIs, plus the keys in `config/CHANGES.md`).

## 2. Make the local test environment (1 minute)
```
cd test
python make_test_env.py C:\GKRevokeTest
```
Writes `test/config/*.ini` (same INIs, every share path moved under `C:\GKRevokeTest`), creates
the folders, drops the seed trackers (empty RITM list, Bot_Status with the five bots, the
application list) and writes `test/ENV_VARS.txt` with every Environment Variable value for this root.
First runs use `test/config`; switch the five config-path variables to `config/` only when going live.

## 3. Gates with Blue Prism's own compiler (2 minutes)
```
cd gate
run_gates.bat "C:\Program Files\Blue Prism Limited\Blue Prism Automate"
```
Both must end green: `ALL COMPILED` (the line must say Blue Prism's own compiler) and `ALL CLEAN`.

## 4. Import and set up
Import `xml/` (objects first, then processes). Create: the Environment Variables from
`test/ENV_VARS.txt` (three are marked FILL: driver path, SMTP relay, email addresses; SMTP empty =
Outlook template), the 4 Work Queues (key column `RITM Number`), the 2 credentials
(`GK Revoke Alice`, `GK Revoke BlueSpace`: bot account + password).

## 5. First runs, in this order (docs/README.md "First runs" has the detail)
1. `GK Revoke Run Mode = test`, Alice Maker on an empty queue: no browser, proves set-up + trackers.
2. Object Studio smoke tests: Tracker `Read Rows` on a seed file; Evidence on two PNGs + the label;
   Common `Send Email` to yourself.
3. Browser alone, `live`: Load Config + Launch Browser (Edge, real driver) + Navigate + Close.
4. Two fake tickets (one Alice, one BlueSpace) with the example attachments from `test/seed/`
   filled with test users; `dryrun`: real navigation, every click only logged as `WOULD ...`.
5. `live` on the fake tickets: Master, Maker, Checker. Photos of anything red.

## Folders
`xml/` the 12 importable files | `config/` PROD config (scrubbed until step 1) | `test/` test-env
maker + seed Excel files | `gate/` validate.py + compile_check.py (+ bp_gen.py for its self-test) | `docs/` README, INTERFACE
(the contract + every Python bug fixed), per-object and process reports.
