# Canonical configs (copies of ../../source/config with the edits the rebuilt objects need)
- alice_maker.ini: snow_task_id_xpath / snow_active_status_column `tr[1]` -> `tr[{}]` (+ `/a` on the task
  id link, as in the Checker config), because ServiceNow.Open Task scans task rows by index.
- alice_checker.ini: added `RCRT_remediation` (index [1], the Checker's related list; the Maker uses [2]) and
  `RCRT_refresh_list`, because the shared ServiceNow.Update RCRT Status follows the Maker Python (tab ->
  remediation link -> Refresh List -> rows). The Checker Python read the rows straight after the tab click.
  CHECK on the real portal that the [1] link is the one on the Checker task form.
- alice_checker.ini and bluespace_checker.ini: `snow_attachment_checkbox` wrapped as `(...)[{}]`. The Python did `.format(index + 1)` on
  a key without a slot (Python silently ignores the argument, so it waited for ANY row); the rebuilt object
  really waits for the n-th uploaded file's row, which is what the code meant.
- bluespace_maker.ini: canonical aliases appended (`attachment_folder_path`, `Maker_task_internal_tracker_path`,
  `snow_assignment_group_name`, `snow_url`, `bluespace_url`, the `snow_*` / `RCRT_*` / `MT_status*` /
  `task_assignee_comment*` and `bluespace_*` XPath names) so the shared ServiceNow / BlueSpace objects find
  their keys; values copied from the `SN_*` / `BS_*` keys of the same file. Three keys have no `SN_`/`BS_`
  original: `snow_task_id_list` / `snow_task_id_xpath` / `snow_active_status_column` / `snow_state_dropdown`
  (the Alice task-row scan, same ServiceNow page), `bluespace_result_user` / `bluespace_user_active_status`
  (from the Checker config: the shared Find User reads the result row the Maker Python only probed for an
  Edit button). The old keys stay.
- bluespace_checker.ini: `bluespace_user_tab_option`, `bluespace_status_*` (its `blueSpace_url` already matches
  `bluespace_url`: INI keys are case-insensitive, as in Python's ConfigParser)
  (Maker values; the shared Open User Admin / Open User Edit pages use them).
Everything else byte-identical to the transcription.

## 2026-10-10: master_populate.ini `ticketing_tool`
New key `[ELEMENTS] ticketing_tool = {{TICKETING_TOOL}}`. The Python hard-coded this text in the
"Ticketing Tool" column of the RITM List tracker; the Tracker's `Add RITMs` now takes it as an input
and the Master reads it here, so no bank-specific text lives in the generated XML.
