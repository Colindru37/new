# Scrub sheet (2026-10-10)

Every bank-specific value in this package was replaced by a `{{TOKEN}}`. Only the files in `config/`
contain tokens (the XML never had bank values). Put the values back with one of the two ways below.

| Token | What it is | Times | Files | Where to read the value on the laptop |
|---|---|---|---|---|
| `{{SHARE_ROOT}}` | UNC root of every shared folder (trackers, logs, templates, attachments) | 60 | alice_checker.ini, alice_maker.ini, bluespace_checker.ini, bluespace_maker.ini, master_checker.ini, master_populate.ini | start of RITM_List_tracker_path in any bot INI, everything before \PYTHON\Reporting |
| `{{SNOW_BASE_URL}}` | ServiceNow instance base URL | 7 | alice_checker.ini, alice_maker.ini, bluespace_checker.ini, bluespace_maker.ini, master_checker.ini, master_populate.ini | start of snow_url, everything before /nav_to.do |
| `{{ALICE_BASE_URL}}` | Alice-Global base URL | 2 | alice_checker.ini, alice_maker.ini | start of alice_url (Alice Maker INI), without the trailing / |
| `{{BLUESPACE_BASE_URL}}` | BlueSpace base URL | 3 | bluespace_checker.ini, bluespace_maker.ini | start of BluespaceApplicationURL (BlueSpace Maker INI), everything before /#/ |
| `{{ALICE_BOT_ACCOUNT}}` | Alice bot account (user_id) | 2 | alice_checker.ini, alice_maker.ini | user_id in the Alice Maker INI |
| `{{BLUESPACE_MAKER_BOT_ACCOUNT}}` | BlueSpace Maker bot account | 1 | bluespace_maker.ini | username in the BlueSpace Maker INI |
| `{{BLUESPACE_CHECKER_BOT_ACCOUNT}}` | BlueSpace Checker bot account | 1 | bluespace_checker.ini | username in the BlueSpace Checker INI |
| `{{LABEL_GUID}}` | sensitivity label id for the evidence docs | 2 | master_checker.ini, master_populate.ini | LabelID in the Master Maker INI |
| `{{MASTER_ASSIGNMENT_GROUP}}` | ServiceNow group the Master works for | 2 | master_checker.ini, master_populate.ini | assignment_group in the Master Maker INI |
| `{{ALICE_ASSIGNMENT_GROUP}}` | Alice task assignment group | 2 | alice_checker.ini, alice_maker.ini | snow_assignment_group_name in the Alice Maker INI |
| `{{BLUESPACE_ASSIGNMENT_GROUP}}` | BlueSpace task assignment group | 3 | bluespace_checker.ini, bluespace_maker.ini | snow_assignment_group_name in the BlueSpace Maker INI |
| `{{TICKETING_TOOL}}` | text the Master writes in the Ticketing Tool column of the RITM List tracker | 2 | CHANGES.md, master_populate.ini | column Ticketing Tool of RITM_List_Tracker.xlsx (any existing row) |
| `{{APP_CS_FOLDER}}` | client screening app folder name (unused dispatch paths) | 2 | master_checker.ini, master_populate.ini | folder after Revocation\ in dbclientScreening_maker_bot_path (Master Maker INI), after the 99759-1_ |
| `{{APP_CS_MAKER_FILE}}` | client screening maker file prefix (unused) | 1 | master_populate.ini | file name in dbclientScreening_maker_bot_path, before _Maker_Task |
| `{{APP_CS_CHECKER_FILE}}` | client screening checker file prefix (unused) | 1 | master_checker.ini | file name in dbclientScreening_Checker_bot_path, before _Checker_Task |
| `{{APP_CS_KEY}}` | client screening INI key prefix (unused) | 2 | master_checker.ini, master_populate.ini | key name dbclientScreening_maker_bot_path, before _maker |
| `{{APP_CC_FOLDER}}` | CAR CRED app folder + file prefix (unused dispatch paths) | 6 | master_checker.ini, master_populate.ini | folder after 59248-1_ in dbcar_maker_bot_path |
| `{{APP_CC_KEY}}` | CAR CRED INI key prefix (unused) | 3 | master_checker.ini, master_populate.ini | key name dbcar_maker_bot_path, before _maker |

## Way 1: the script (recommended)
1. `python restore_config.py --check` -> `PACKAGE OK` (the upload/download did not damage anything).
2. Open `restore_values.txt`, write each value after its `=` (no quotes).
3. `python restore_config.py` -> every file `OK`, then `RESTORED: ... byte-identical`.
   A `DIFFERS` line names the tokens of that file: fix the typo, run again (safe to repeat).

## Way 2: by hand (Notepad++ "Replace in Files" / VS Code)
Folder `config`, match case ON, regular expressions OFF. For each token: Find `{{TOKEN}}`, Replace
with the value, Replace All; "Times" is how many replacements to expect. Afterwards a search for `{{`
in `config` must find nothing. Way 1 still works afterwards as a check.

## Kept on purpose (not tokenised)
- Application NAR ids in folder names (e.g. `15003-3_Alice-Global`): internal numbers that do not name
  the bank once domain and share root are gone; eleven of them, eleven more values to type otherwise.
- ServiceNow sys_id hex strings inside the URLs (instance-internal).
- XPaths, timeouts, file names, bot names: needed to read the build, nothing bank-specific.

## Which file holds which tokens

- `config/CHANGES.md`: TICKETING_TOOL x1
- `config/alice_checker.ini`: SHARE_ROOT x7, ALICE_BASE_URL x1, SNOW_BASE_URL x1, ALICE_BOT_ACCOUNT x1, ALICE_ASSIGNMENT_GROUP x1
- `config/alice_maker.ini`: SHARE_ROOT x6, ALICE_BASE_URL x1, SNOW_BASE_URL x1, ALICE_BOT_ACCOUNT x1, ALICE_ASSIGNMENT_GROUP x1
- `config/bluespace_checker.ini`: SHARE_ROOT x7, BLUESPACE_BASE_URL x1, SNOW_BASE_URL x1, BLUESPACE_CHECKER_BOT_ACCOUNT x1, BLUESPACE_ASSIGNMENT_GROUP x1
- `config/bluespace_maker.ini`: SHARE_ROOT x8, BLUESPACE_BASE_URL x2, SNOW_BASE_URL x2, BLUESPACE_MAKER_BOT_ACCOUNT x1, BLUESPACE_ASSIGNMENT_GROUP x2
- `config/master_checker.ini`: SHARE_ROOT x16, LABEL_GUID x1, SNOW_BASE_URL x1, APP_CS_FOLDER x1, APP_CS_CHECKER_FILE x1, APP_CS_KEY x1, MASTER_ASSIGNMENT_GROUP x1, APP_CC_FOLDER x2, APP_CC_KEY x1
- `config/master_populate.ini`: SHARE_ROOT x16, LABEL_GUID x1, SNOW_BASE_URL x1, APP_CS_FOLDER x1, TICKETING_TOOL x1, APP_CS_MAKER_FILE x1, APP_CS_KEY x1, MASTER_ASSIGNMENT_GROUP x1, APP_CC_FOLDER x4, APP_CC_KEY x2
