"""UI object, option B: generate the stages AND an empty Application Modeller, spy after.

After import: open the object in Object Studio -> Application Modeller. Every element below
is there by name but has no attributes. Run the application, select each element and
Identify it (spy). Blue Prism keeps the element id, so the Write/Read/Navigate/Wait stages
already wired to it stay connected. validate.py prints the list of elements still to spy.

Extending an EXISTING object instead (option A): replace application()/element() with
    o.use_model('BPA Object - <existing>.xml')     # its spied model; elements by name
Run from the skill root:
  python examples/minimal_ui_object.py
  python lib/validate.py out --flow --estate --strict"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lib'))
from bp_gen import Proc, lit

o = Proc('Portal UI', 'object', 'Log in to the portal and read the status line.')
o.application('Portal', 'Win32Launch',
              {'Path': '', 'CommandLineParams': '', 'WorkingDirectory': '', 'NonInvasive': 'True'})
# element names: follow the estate grammar (object-conventions.md s.3)
o.element('Window - Login - Win32', 'Window')
o.element('Window - Login - Win32/Textbox - User - Win32', 'Edit')
o.element('Window - Login - Win32/Button - Log In - Win32', 'Button')
o.element('Window - Login - Win32/Label - Status - Win32', 'Label')

o.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
pg = o.page('Log In', 'Log in and return the status text.')
pg.add_input('text', 'User Name')
pg.add_output('text', 'Status')
pg.data('Login Timeout', 'number', initial='10')
pg.wait_for('Wait For Login Window', [('Window - Login - Win32', 'CheckExists', 'NEXT')],
            '[Login Timeout]', on_timeout='Login Window Missing')
pg.write('Enter User Name', [('Textbox - User - Win32', '[User Name]')])
pg.navigate('Press Log In', [('Button - Log In - Win32', 'Press')])
pg.wait('Pause For Status', '2')                       # a plain pause (no conditions)
pg.read('Read Status Line', [('Label - Status - Win32', 'GetWindowText', 'Status', 'text')],
        goto='END')
pg.exception('Login Window Missing', 'System Exception', lit('Login window did not appear'))
print(o.write('BPA Object - Portal UI.xml', outdir='out'))
print('spy after import:', ', '.join(p.split('/')[-1] for p in o.spy_checklist()))
