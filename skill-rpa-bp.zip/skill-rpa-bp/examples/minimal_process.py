"""Minimal business object: Clean Up page + one published action with a
Navigate call, a decision, a code stage and a Recover handler.
Run from the skill root:  python examples/minimal_process.py && python lib/validate.py out --flow --estate"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lib'))
from bp_gen import Proc, lit

p = Proc('My Object', 'object', 'What this object does.')
p.code_options()                                   # only if you use code() stages
p.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
m = p.page('Get Status', 'Read and return the current status.')
m.add_input('text', 'URL')
m.add_output('text', 'Status')
m.data('Loaded', 'flag')

m.action('Navigate', 'MS Edge Browser', 'Navigate', inputs=[('text', 'URL', '[URL]')])
m.decision('Loaded?', '[Loaded]', true_target='NEXT', false_target='END')
m.code('Read Status', 'Status = Loaded ? "ready" : "not ready";',
       inputs=[('flag', 'Loaded', '[Loaded]')],
       outputs=[('text', 'Status', 'Status')])
m.recover_action('Log', 'Utility - General', 'Nothing',
                 inputs=[('text', 'Message', lit('Get Status failed'))])
print(p.write('BPA Object - My Object.xml', outdir='out'))
