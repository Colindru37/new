"""Estate process recipe: the full control framework, built only from verified pieces.

  Main: Reset Global Data -> Continue To Work? -> Get Next Item -> [Item ID] <> "" ?
        -> Work Item (page call, inside a work block) -> Mark Completed -> back to the top
        A failure inside Work Item is captured IN RECOVERY MODE (type/detail/stage), then:
          Business Exception -> Mark Exception (no retry) -> back to the top
          System Exception   -> Mark Exception (retry)    -> consecutive-failure guard
  Work Item: route by item type with a Choice, ForEach over rows, and a bounded retry
             around the fallible call (attempt counter + max + '?' decision).

Placeholders to replace with your estate's objects: 'Ticket System' (the application
object), 'Utility - General'.'Log' (use the house logging object). 'Work Queues' is the
real internal object (signatures: reference/estate-objects.md).
Run from the skill root:
  python examples/minimal_orchestration.py
  python lib/validate.py out --flow --estate --strict
  python lib/preview.py "out/BPA Process - Example - Claim Loop.xml" preview"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lib'))
from bp_gen import Proc, lit

LOG = ('Utility - General', 'Log')        # placeholder: the house logging object

p = Proc('PRC000 - Example - Claim Loop', 'process', 'Claim items until none left.')

# ---------------- Main: the control framework ----------------
main = p.page('Main', 'Control framework: reset, stop checks, claim, work, mark, repeat.')
main.data('Example Queue Name', 'text', exposure='Environment')     # Environment Variable
main.data('Example Max Consecutive Failures', 'number', exposure='Environment')
main.data('g_txt_Item ID', 'text')
main.data('g_col_Item Data', 'collection')
main.data('g_flg_Continue', 'flag')
main.data('g_num_Consecutive Failures', 'number')
main.data('g_txt_Ex Type', 'text')
main.data('g_txt_Ex Detail', 'text')
main.data('g_txt_Ex Stage', 'text')

main.page_ref('Reset Data', page='Reset Global Data',
              outputs=[('number', 'o_num_Consecutive Failures', 'g_num_Consecutive Failures')])
main.page_ref('Check Continue To Work', page='Continue To Work',
              outputs=[('flag', 'o_flg_Continue', 'g_flg_Continue')])
main.decision('Continue Working?', '[g_flg_Continue]', true_target='NEXT', false_target='END')
main.action('Get Next Item', 'Work Queues', 'Get Next Item',
            inputs=[('text', 'Queue Name', '[Example Queue Name]')],
            outputs=[('text', 'Item ID', 'g_txt_Item ID'), ('collection', 'Data', 'g_col_Item Data')])
main.decision('Item Available?', '[g_txt_Item ID] <> ""', true_target='NEXT', false_target='END')
main.page_ref('Work Item', page='Work Item',
              inputs=[('collection', 'i_col_Item Data', '[g_col_Item Data]')])
main.action('Mark Completed', 'Work Queues', 'Mark Completed',
            inputs=[('text', 'Item ID', '[g_txt_Item ID]')])
main.calc('Reset Consecutive Failures', '0', 'g_num_Consecutive Failures', goto='Check Continue To Work')
# continuation of the work block below: details were captured in recovery mode
main.decision('Business Exception?', '[g_txt_Ex Type] = "Business Exception"',
              true_target='Mark Business Exception', false_target='Mark System Exception')
main.action('Mark Business Exception', 'Work Queues', 'Mark Exception',
            inputs=[('text', 'Item ID', '[g_txt_Item ID]'), ('text', 'Exception Reason', '[g_txt_Ex Detail]'),
                    ('flag', 'Retry', 'False')],
            goto='Check Continue To Work')                   # bad data: never retried
main.action('Mark System Exception', 'Work Queues', 'Mark Exception',
            inputs=[('text', 'Item ID', '[g_txt_Item ID]'),
                    ('text', 'Exception Reason', '[g_txt_Ex Stage] & ": " & [g_txt_Ex Detail]'),
                    ('flag', 'Retry', 'True')])
main.calc('Count Consecutive Failure', '[g_num_Consecutive Failures] + 1', 'g_num_Consecutive Failures')
main.decision('Too Many Consecutive Failures?',
              '[g_num_Consecutive Failures] >= [Example Max Consecutive Failures]',
              true_target='Stop On Consecutive Failures', false_target='Check Continue To Work')
main.exception('Stop On Consecutive Failures', 'System Exception',
               lit('Stopped: too many consecutive system exceptions'))
main.work_block('Work The Item', 'Work Item', 'Mark Completed',
                capture=('g_txt_Ex Type', 'g_txt_Ex Detail', 'g_txt_Ex Stage'),
                handler=[('Log Item Failure', LOG[0], LOG[1],
                          [('text', 'Message', '"Item " & [g_txt_Item ID] & " failed"')])],
                then='Business Exception?')

# ---------------- Reset Global Data ----------------
rg = p.page('Reset Global Data', 'Reset run-level state before the first item.')
rg.add_output('number', 'o_num_Consecutive Failures')
rg.calc('Reset Failure Counter', '0', 'o_num_Consecutive Failures')

# ---------------- Continue To Work ----------------
cw = p.page('Continue To Work', 'Stop request (Control Room), session item limit, working hours.')
cw.add_output('flag', 'o_flg_Continue')
cw.data('Example Stop After Next Item', 'flag', initial='False', exposure='Session')
cw.data('Example Working Hours End', 'number', exposure='Environment')     # e.g. 18 (hour)
cw.decision('Stop Requested?', '(IsStopRequested() OR [Example Stop After Next Item])',
            true_target='Stop Working', false_target='NEXT')
cw.decision('Outside Working Hours?', 'Hour(Now()) >= [Example Working Hours End]',
            true_target='Stop Working', false_target='NEXT')
cw.calc('Keep Working', 'True', 'o_flg_Continue', goto='END')
cw.calc('Stop Working', 'False', 'o_flg_Continue')

# ---------------- Work Item: Choice + ForEach + bounded retry ----------------
v = p.page('Work Item', 'Route by item type, process its rows, close it with up to 3 attempts.')
v.add_input('collection', 'i_col_Item Data')
v.data('l_txt_Item Type', 'text')
v.data('l_col_Rows', 'collection')
v.data('l_num_Attempt', 'number')
v.data('l_num_Max Attempts', 'number', initial='3')
v.data('l_txt_Ex Type', 'text')
v.data('l_txt_Ex Detail', 'text')
v.calc('Read Item Type', '[i_col_Item Data.Type]', 'l_txt_Item Type')
v.choice('Item Type?', [('Account', '[l_txt_Item Type]="Account"', 'Load Rows'),
                        ('Entitlement', '[l_txt_Item Type]="Entitlement"', 'Load Rows')],
         otherwise='Reject Unknown Type')
v.action('Load Rows', 'Utility - Collection Manipulation', 'Copy Rows',      # real VBO signature
         inputs=[('number', 'Start Row', '0'), ('number', 'Number of Rows to Copy', '1'),
                 ('collection', 'Source Collection', '[i_col_Item Data]')],
         outputs=[('collection', 'Output Collection', 'l_col_Rows')])
v.loop_start('l_col_Rows', 'Rows Loop Start')
v.action('Record Row', LOG[0], LOG[1], inputs=[('text', 'Message', '[l_col_Rows.Name]')])
v.loop_end('Rows Loop End')
# bounded retry: counter + max + increment + '?' decision (estate MUST)
v.calc('Count Attempt', '[l_num_Attempt] + 1', 'l_num_Attempt')
v.action('Close In Application', 'Ticket System', 'Close Ticket',
         inputs=[('text', 'Ticket ID', '[i_col_Item Data.Key]')], goto='END')
v.decision('Retry Allowed?', '[l_txt_Ex Type] = "System Exception" AND [l_num_Attempt] < [l_num_Max Attempts]',
           true_target='Count Attempt', false_target='Close Failure Is Business?')
v.decision('Close Failure Is Business?', '[l_txt_Ex Type] = "Business Exception"',
           true_target='Raise Close Business Exception', false_target='Give Up Close')
v.exception('Raise Close Business Exception', 'Business Exception', '[l_txt_Ex Detail]')
v.exception('Give Up Close', 'System Exception', '"Close failed after retries: " & [l_txt_Ex Detail]')
v.exception('Reject Unknown Type', 'Business Exception', lit('Unknown item type'))
v.work_block('Close Attempt', 'Close In Application', 'Close In Application',
             capture=('l_txt_Ex Type', 'l_txt_Ex Detail', None),
             then='Retry Allowed?')
print(p.write('BPA Process - Example - Claim Loop.xml', outdir='out'))
