# Prompt: add a flight recorder to GK Revoke Browser - Generic

Paste into Copilot on the work machine. One change, one compile pass.

---

You are editing `BPA Object - GK Revoke Browser - Generic.xml` (C#, shared code lives in the
Code Options / ProcessInfo `<code>` element). Goal: when a real (non-test) run fails, leave
enough evidence on disk that a human can diagnose it WITHOUT Blue Prism debugging.
Do NOT change any behaviour, XPath, page, input or output. Add code only.

1. **Call log in `WdSend()`** (the single HTTP choke point). Append ONE line per call to
   `<log_path>\wd_trace_<yyyyMMdd>.log`:
   `HH:mm:ss.fff | <METHOD> <path> | <ms> ms | HTTP <status> | frames=<breadcrumb> | <first 300 chars of response>`
   On any non-2xx or W3C `"error"` value, log the FULL response body.
   Also log the request body for `/element`, `/elements`, `/frame` and `/url` calls (that is
   where the XPath / frame / URL is).

2. **Frame breadcrumb.** Keep a static `List<string> FramePath`. Every frame switch appends
   the XPath key it switched into; switching to top (`{"id":null}`) clears it; switching to
   parent removes the last item; navigating to a URL or refreshing clears it. It is printed
   in every log line as `top>alice_first_frame>alice_iframe`.

3. **`DumpOnFailure(string where)`** helper. It must NEVER throw (wrap everything in
   try/catch and log the inner error). It writes, next to the log:
   - `fail_<where>_<HHmmss>.html` from `GET /session/{id}/source`
   - `fail_<where>_<HHmmss>.png` from `GET /session/{id}/screenshot` (base64 -> bytes)
   - one log line with current URL, window handle count and `FramePath`.

4. In every existing `catch` that rethrows or returns failure in a subsheet that touches the
   browser, call `DumpOnFailure("<subsheet name>")` first, then keep the existing behaviour.
   Never add an empty catch.

5. TestMode: when `TestMode()` is true, log the lines but skip the dump files.

**Acceptance (must do all):**
- Object imports and compiles. Test-mode run still all green.
- POSITIVE CONTROL: in a copy of the Alice Maker ini, break `alice_user_search_box`
  (e.g. `//input[@name="NOPE"]`), run non-test up to the user search. The trace must show
  the `/element` request with `NOPE` in it, the error body, and the frame breadcrumb, and a
  `fail_*.html` + `fail_*.png` pair must exist. If any of these are missing, it is not done.
- Restore the ini.

Report: lines added, the exact log path used, and the positive-control log excerpt.
