# Object conventions (measured)

Source: `bp_object_conventions` report over the estate's business objects (sa.xml).
Y = 8 objects. Every ESTABLISHED line carries its count. GK Revoke objects are NOT in the
set (they are the no-spying exception). Where this file and estate-conventions.md differ
on objects, this file wins: it is measured, the other was partly inferred.

## Tiers
- **Established (6-8 of 8)** -> MUST for new and changed objects.
- **Split / minority** -> follow the object being edited; for a NEW object use the
  recommended default given here and say so in the handover.
- **Anti-pattern** -> never generate it, even though it exists in the files.

## 1. Structure
- 8/8 Initialise/main canvas with Start, End, ProcessInfo, explanatory note. MUST.
- 8/8 Clean Up subsheet `type="CleanUp"`, `published="True"`. MUST.
- 8/8 at least one published action page; 8/8 keep action logic on subsheets, main holds
  only metadata, notes, blocks, global data. MUST.
- 6/8 have unpublished helper pages; 6/8 have an Attach helper page. Default for new UI objects.
- Split: only 2/8 publish every subsheet. "One action per page" means one caller-visible
  capability per page, NOT one stage: pages commonly combine attach, wait, navigate,
  read-back, decision, logging and exception stages.

## 2. Action interface
- 8/8 actions with inputs and outputs. Inputs: Text 341, Number 207, Flag 114, Password 11,
  Collection 5. Outputs: Text 69, Flag 45, Number 20, Collection 11.
- 8/8 verb-first action names. Most common first words: Get, Set, Close, Add, Open, Create,
  Insert, Delete, Format, Hide, Remove, Save, Write, Extract, Select, Execute.
- 6/8 prefix some input items `i_`; 4/8 prefix some outputs `o_` -- but only 3/8 map ALL
  inputs to `i_` items and 1/8 all outputs to `o_`. Within one object: be consistent.
  These counts are about the INTERNAL data items an action maps its parameters into; the
  caller-facing parameter names themselves are Title Case (see estate-conventions.md,
  data-item naming). A new object: Title Case interface, prefixed internals.
- Defaults live on internal Data stages, not on the Start-stage interface.
- **Both failure contracts are established**: 6/8 expose success/result-style output flags
  AND 6/8 contain Exception stages. Rule: match the contract of sibling actions in the same
  object; never mix both for equivalent actions. (The old "MUST NOT return a Success flag"
  rule is withdrawn -- it contradicted 6/8 objects.)

## 3. Application Modeller
- 8/8 have an Application Modeller definition; 3/8 use group nodes.
- In-use match attributes (full set): ClassName 150, ScreenVisible 148, Visible 144,
  MatchIndex 126, Enabled 90, WindowText 69, Role 67, parent Role 54, Name 52.
- 4/8 use dynamic attributes (parent Y 11, MatchIndex 7, Y 5, WindowText 4, parent X 3,
  X 2, Name 1, ClassName 1). 4/8 use Wildcard (WindowText 16, AncestorsText 6, ClassName 5,
  Name 2, Role 2).
- **0/8 use XPath.** XPath is absent from the estate's App Modeller usage. Do not describe
  it as an established technique (GK Revoke's XPaths live in INI files, not the model).
- Extend an object with its own element-name grammar, tree grouping and match-attribute
  families of sibling elements in the same branch.

## 4. Waits
- 5/8 use WaitStart/WaitEnd (89 pairs), always linked by the same `groupid`. MUST pair.
- Timeout style is SPLIT: 2/8 use data-item timeouts for every wait, 3/8 have literal
  timeouts. Follow the object; for a new object use a named timeout data item.
  (The old "MUST use a named timeout data item" is downgraded to this default.)
- 6/8 also use Sleep / wait utilities outside WaitStart/WaitEnd.

## 5. Navigate / Read / Write
- 5/8 Navigate, 5/8 Read, 4/8 Write; 4/8 mouse-click in Navigate.
- Navigate actions: SendKeyEvents 40, ActivateApp 35, centre-click variants 22/16/15,
  AttachApplication 8, DetachApplication 6. Read: GetWindowText 42,
  GetWindowIdentifier 20, checkbox state 17, IsConnected 9.
- Keep multi-step Navigate stages together only when they are one atomic interface
  operation; keep read-back verification where sibling write actions use it.

## 6. Code
- **Language is split: 5/8 Visual Basic, 3/8 C#.** Use the language already declared by the
  object being changed. For a NEW object, C# is the recommendation (estate JSON =
  Newtonsoft; compile_check covers C#), but it is a recommendation, not an estate fact.
- 4/8 contain code stages (161 total); 8/8 have ProcessInfo with references/imports.
  Shared code sizes: 3,430 / 11,073 / 76,070 / 8,985 chars.
- Uses seen: database (connect/command/transaction/commit/rollback/cleanup), OS support,
  workbook/worksheet automation, document extraction and passwords.
- Name code stages with descriptive verb-first names, not "Code1".

## 7. Run mode and environment
- **7/8 `runmode="Exclusive"`, 1/8 Background, 0/8 Foreground.** Preserve the object's run
  mode; a NEW object defaults to Exclusive (the generator does this).
- 4/8 contain session-related data items; 0/8 contain a distinct environment-variable
  item. Do not claim an environment-variable convention for objects.

## 8. Exceptions
- 6/8 contain Exception stages: 141 stages, 136 `System Exception`, 3 a worksheet-not-found
  type, 1 invalid-input type, 1 EMPTY type (anti-pattern).
- 6/8 contain Recover and the same 6 contain Resume. Where Recover is introduced, include
  the Resume path or an explicit rethrow path.
- UI objects commonly build an event string before throwing a System Exception: construct
  diagnostic text, then throw the established type.

## 9. Data items, blocks, anchors, layout
- 6/8 typed prefixes (`txt_`, `nr_`, `flg_`, `col_`); 3/8 `g_` globals; 6/8 `i_` inputs;
  4/8 `o_` outputs. Seen in the shapes: `o_flg_SAP Kontenliste`, `i_flg_Mark First
  Checkbox`, `txt_Current Value` -> the de-facto grammar is `<scope>_<type>_<Meaning>`
  with spaces allowed in the meaning.
- 7/8 Blocks (286 total); 7/8 Anchors (302 total); 7/8 Calculation; 6/8 MultipleCalculation;
  1/8 ChoiceStart/ChoiceEnd (2 of each).
- Blocks group inputs, outputs, globals, locals, timeouts, object data and functional
  sections. Colour meaning is NOT stable -- do not infer a colour legend.
- Both vertical and horizontal layouts occur; spacing often follows a grid, but no single
  distance or direction is shared by all 8. Preserve the page's flow direction and rhythm.

## 10. Anti-patterns (never generate)
- 7/8 generic numbered Anchor names -> generated anchors get purpose names.
- 8/8 ProcessInfo with a generic numbered name -> the generator names it `Code Options`.
- 6/8 mix published actions with unpublished helpers without a naming rule that
  distinguishes them.
- 4/8 dynamic attributes based on coordinates/indexes.
- 3/8 literal WaitStart timeouts while others use shared timeout items (in the same object).
- 1/8 Exception stage with an empty type.
- 4/8 generic code-stage names / legacy code labels.
- Also seen: unfinished notes, generic End names, duplicate stage names, inconsistent
  capitalisation, language mixing, spelling variation, unconnected outputs, helper-call
  outputs mapped to no data item, model attributes holding captured window text/indexes.
- Do not use an existing inconsistency as proof of a release-wide rule.

## 11. Review checklist (objects)
- [ ] Run mode unchanged (new: Exclusive)
- [ ] Initialise/main holds only shared state + metadata
- [ ] Clean Up present and published
- [ ] Caller-facing actions published; helpers follow the object's publication pattern
- [ ] Each action page = one caller-visible capability; verb-first name
- [ ] Inputs/outputs names, types and internal mappings follow sibling actions
- [ ] Defaults explicit on the mapped Data stages
- [ ] Result flags vs exceptions follow comparable actions
- [ ] App Modeller names/match attributes follow sibling elements; dynamic/Wildcard only
      where the branch already uses them
- [ ] WaitStart/WaitEnd share a groupid; timeout style matches the object
- [ ] Navigate action IDs match the element's spying technology
- [ ] Code uses the object's declared language, references, imports; descriptive names
- [ ] Exception type populated; Recover has Resume or explicit rethrow
- [ ] Data-item prefixes consistent within the object; Blocks reuse the object's categories
- [ ] Anchors have meaningful names where they affect troubleshooting
- [ ] Layout follows the page's existing flow direction
- [ ] No real environment values, secrets, paths or identifiers in docs/examples
