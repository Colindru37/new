# Config contract (explicit no-spying project exception)

This is **not** the estate default. Use it only when the user's named project or existing
source-of-truth XML explicitly requires raw-driver/no-Application-Modeller automation (for
example, GK Revoke). New estate-native UI objects use Application Modeller elements and Blue
Prism Environment Variables as specified in [estate-conventions.md](estate-conventions.md).

When porting a UI-automation bot to Blue Prism **without using the spy/model tree**, drive
every element from an external `config.ini` read at runtime by a code stage. This keeps
selectors out of the diagram and lets ops change them without editing the object.

## Three sections

```ini
[ELEMENTS]
# logical name -> human label / description (documentation + optional lookups)
login_button = Sign in
username_field = User name

[URLS]
# logical name -> full URL. Read at runtime; never hard-code in the diagram.
portal = https://portal.example.com/login
search = https://portal.example.com/search

[XPATHS]
# logical name -> XPath (or CSS) selector used by the driver
login_button = //button[@id='signin']
username_field = //input[@name='user']
results_row = //table[@id='res']//tr
```

## Rules
1. **No spying.** The object contains zero spied elements. All targeting comes from
   `[XPATHS]` / `[URLS]`. This rule applies only after the no-spying exception has been
   selected and recorded.
2. **Read once, pass around.** A `Read Config` code/action stage loads the ini into a
   collection or individual data items at the top of the run; downstream stages consume
   those, not the file.
3. **URLs are config, not literals.** Even the landing URL comes from `[URLS]` so
   environments (dev/uat/prod) differ only by ini. The INI path itself must come from an
   Environment Variable or an explicit process input; never hardcode a developer path into
   generated XML.
4. **Placeholders live in defaults, not logic.** If a data item has a sample value, it is
   only a design-time default; the real value is injected from config/queue at runtime.
5. **Selectors are XPaths by convention.** The driver code resolves `[XPATHS].name` to an
   XPath locator. Swap to CSS per project if preferred, but keep one convention.
6. **Credentials do not come from the INI.** Fetch them through Blue Prism Credential
   Manager, type secret parameters as `password`, and override any plaintext credentials
   inherited from the source application.

## Python-ini traps when the reader is C#
These bit the GK Revoke port; any INI ported from a Python bot has them.
- **`%%` is Python ConfigParser escaping.** `%%` in the file means `%` at runtime. The C#
  reader must convert `%%` -> `%` (URL-encoded ServiceNow URLs are full of these).
- **`{}` is a Python `str.format` slot, not a C# one.** XPaths like
  `(//table[@id="roles"]//tr/td[2])[{}]` are filled with `.format(i)` in Python. In C#,
  `string.Format("...[{}]...", i)` throws `FormatException` (C# needs `{0}`), and `{}` in a
  format string is invalid even when no argument is passed. Fill these with
  `xpath.Replace("{}", i.ToString())`, and grep every `[XPATHS]` value for `{}` -- they
  travel in packs (row indexes, page indexes, region indexes).
- **Both `#` and `;` start comments**, and keys are case-insensitive in ConfigParser. Match
  that, or a "missing key" is really a case mismatch.
- **Indented lines continue the previous value** in ConfigParser (multi-line values). A
  line-by-line C# reader drops them silently. Check the INI for values that wrap onto an
  indented next line; if any exist, append them (joined with `\n`, like Python) to the
  previous key.
- **`:` is also a key/value separator** in ConfigParser (`key: value`). A reader that only
  splits on `=` misses those keys.
- **Exact-text XPaths with spaces** (`//a[text()=' User Admin ']`) depend on the page's
  whitespace. If the page uses `&nbsp;` or trims differently, prefer
  `//a[normalize-space()='User Admin']` -- but only change a selector after the failure
  dump proves it is the culprit (the Python version worked against the real page).

## Why
- Selectors change often; ini edits need no republish and no BP Studio.
- The diagram stays readable (no giant element trees).
- The same object runs against multiple environments unchanged.

## Minimal reader (C# code stage sketch)
```csharp
// Inputs: ConfigPath (text). Outputs: collections/data items you need.
var lines = System.IO.File.ReadAllLines(ConfigPath);
string section = "";
foreach (var raw in lines) {
    var line = raw.Trim();
    if (line == "" || line.StartsWith(";") || line.StartsWith("#")) continue;
    if (line.StartsWith("[") && line.EndsWith("]")) { section = line.Trim('[', ']'); continue; }
    int eq = line.IndexOf('=');
    if (eq < 0) continue;
    string key = line.Substring(0, eq).Trim();
    string val = line.Substring(eq + 1).Trim().Replace("%%", "%");
    // store into a case-insensitive Dictionary<string,string> per section
}
```
