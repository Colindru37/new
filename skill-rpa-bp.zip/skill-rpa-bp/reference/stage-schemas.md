# Stage schemas (verified)

Every stage below marked **verified** has been checked against real Blue Prism 7.x release
XML. The generator (`lib/bp_gen.py`) emits exactly these shapes. This file is the source of
truth if you ever need to hand-edit or extend the generator.

All shapes in this file are now verified against real exports. A NEW stage type not listed
here: build a tiny object that uses it, import, export back, diff, then add it here.

Common facts:
- Root element is always `<process ...>` even for business objects (`type="object"`). The
  `type` attribute distinguishes them.
- Every stage has a unique `stageid` (GUID) and a `<display .../>` box.
- Non-main pages: every stage carries `<subsheetid>` matching its page. The implicit main
  page of a `type="process"` omits `<subsheetid>`.
- Flow is expressed by child link elements holding a target `stageid`:
  `<onsuccess>`, `<ontrue>`, `<onfalse>`.

---

## Start (verified)
```xml
<stage stageid="..." name="Start" type="Start">
  <subsheetid>...</subsheetid>                 <!-- omitted on process main page -->
  <display x="15" y="-30" w="60" h="30" />
  <font .../>
  <inputs>                                     <!-- optional: page parameters in -->
    <input type="text" name="Foo" friendlyname="Foo" stage="Foo" />
  </inputs>
  <onsuccess>{first-stage-id}</onsuccess>
</stage>
```

## End (verified)
```xml
<stage stageid="..." name="End" type="End">
  <subsheetid>...</subsheetid>
  <display x="15" y="..." w="60" h="30" />
  <font .../>
  <outputs>                                    <!-- optional: page parameters out -->
    <output type="text" name="Bar" friendlyname="Bar" stage="Bar" />
  </outputs>
</stage>
```

## Action (call another object/VBO action) (verified)
```xml
<stage stageid="..." name="Do Thing" type="Action">
  <subsheetid>...</subsheetid>
  <display x="15" y="..." w="150" h="30" />
  <font .../>
  <inputs>
    <input type="text" name="Url" friendlyname="Url" expr="[Url]" />
  </inputs>
  <outputs>
    <output type="flag" name="Ok" friendlyname="Ok" stage="Ok" />
  </outputs>
  <onsuccess>{next-id}</onsuccess>
  <resource object="MS Edge Browser" action="Navigate" />
</stage>
```
Note: action inputs/outputs carry `friendlyname`. Code stage inputs/outputs do NOT.
`object`/`action` resolve by EXACT string match against the called object's internal name
and page name; input `name`s must match that page's Start inputs exactly.

## Code (.NET) (verified)
```xml
<stage stageid="..." name="Compute" type="Code">
  <subsheetid>...</subsheetid>
  <display x="15" y="..." w="150" h="30" />
  <font .../>
  <inputs>
    <input type="collection" name="Rows" expr="[Rows]" />
  </inputs>
  <outputs>
    <output type="number" name="Total" stage="Total" />
  </outputs>
  <onsuccess>{next-id}</onsuccess>
  <code><![CDATA[ Total = Rows.Rows.Count; ]]></code>
</stage>
```
The code body is passed through verbatim inside CDATA. The object-level language,
references and imports live in a single `ProcessInfo` stage (see below). Inside the body,
only the stage's declared inputs/outputs exist as variables (names with spaces become
underscores) -- a page input that is not mapped onto the stage is NOT visible.

## ProcessInfo (object-level .NET environment; one per object) (verified)
```xml
<stage stageid="..." name="Code Options" type="ProcessInfo">
  <display x="-345" y="-255" w="150" h="90" />
  <references>
    <reference>System.dll</reference>
  </references>
  <imports>
    <import>System</import>
  </imports>
  <language>csharp</language>
  <globalcode><![CDATA[]]></globalcode>
  <code><![CDATA[ /* object-level shared helpers, fields, usings-in-body */ ]]></code>
</stage>
```
> **CRITICAL -- shared code goes in `<code>`, NOT `<globalcode>`.** Real Blue Prism stores
> object-level shared code (static fields like a shared WebDriver, helper methods called by
> every code stage, etc.) in the ProcessInfo `<code>` element. `<globalcode>` exists but is
> left **empty** -- verified against a real release (thousands of populated `<code>`, zero
> populated `<globalcode>`) and the shipped MS Excel VBO. Putting shared code in
> `<globalcode>` makes Blue Prism ignore it, so every code stage that calls a shared helper
> fails to compile ("the name '...' does not exist"). The generator writes whatever you pass
> to `code_options(globalcode=...)` into `<code>` and keeps `<globalcode>` empty for you.

## Decision (verified)
```xml
<stage stageid="..." name="Item Available?" type="Decision">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="15" y="..." w="150" h="30" />
  <font .../>
  <decision expression="[Item ID] &lt;&gt; &quot;&quot;" />
  <ontrue>{true-target-id}</ontrue>
  <onfalse>{false-target-id}</onfalse>
</stage>
```
`expression` is a Blue Prism boolean expression, e.g. `[Item ID] <> ""`,
`[Status]="Completed"`, `[Count]>0`.

## LoopStart / LoopEnd (ForEach) (verified)
A loop is a matched pair sharing the SAME `<groupid>`.
```xml
<stage stageid="..." name="Rows Loop Start" type="LoopStart">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display .../>
  <font .../>
  <onsuccess>{first-body-stage-id}</onsuccess>
  <groupid>{GUID}</groupid>
  <looptype>ForEach</looptype>
  <loopdata>Rows</loopdata>            <!-- collection name, no brackets -->
</stage>

<stage stageid="..." name="Rows Loop End" type="LoopEnd">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display .../>
  <font .../>
  <onsuccess>{stage-after-loop-id}</onsuccess>
  <groupid>{SAME GUID as its LoopStart}</groupid>
</stage>
```
Blue Prism draws the back-edge automatically from LoopEnd to LoopStart; you only wire the
forward links. There is no `loopdata` on the LoopEnd.

## SubSheet (page-reference; call another page of a process) (verified)
Invokes another subsheet page of the SAME process (verified against a live multi-page
process export). The link to the target page is `<processid>` = the target page's
**subsheetid** (NOT a stage id).
```xml
<stage stageid="..." name="Validate Item" type="SubSheet">
  <subsheetid>...</subsheetid>                 <!-- the calling page; omit on main -->
  <loginhibit onsuccess="true" />
  <display x="15" y="..." w="150" h="30" />
  <font .../>
  <inputs>                                     <!-- map to target page's Start params -->
    <input type="text" name="ItemId" expr="[ItemId]" />
  </inputs>
  <outputs>                                    <!-- receive target page's End params -->
    <output type="flag" name="IsValid" stage="IsValid" />
  </outputs>
  <onsuccess>{next-id}</onsuccess>
  <processid>{target-page-subsheetid}</processid>
</stage>
```
Notes: inputs/outputs use the code-stage style (`name`+`expr` / `name`+`stage`, no
`friendlyname`). `<loginhibit onsuccess="true" />` like Recover/Resume. The generator emits
this via `page_ref(name, page='Target Page', inputs, outputs)` and resolves `<processid>`
from the target page name. Only meaningful in a `type="process"`.

## Recover / Resume (error handler) (verified)
A parallel flow that Blue Prism jumps to automatically on ANY unhandled exception on the
page. Resume clears recovery mode; then normal stages run to an End.
```xml
<stage stageid="..." name="Recover" type="Recover">
  <subsheetid>...</subsheetid>
  <loginhibit onsuccess="true" />
  <display x="-620" y="..." w="60" h="30" />
  <font .../>
  <onsuccess>{resume-id}</onsuccess>
</stage>

<stage stageid="..." name="Resume" type="Resume">
  <subsheetid>...</subsheetid>
  <loginhibit onsuccess="true" />
  <display x="-620" y="..." w="60" h="30" />
  <font .../>
  <onsuccess>{first-handler-action-id}</onsuccess>
</stage>
```
Note the `onsuccess="true"` attribute on `<loginhibit>` for BOTH stages -- this differs from
Decision/Loop which use a bare `<loginhibit />`.

## Data (verified)
```xml
<stage stageid="..." name="Counter" type="Data">
  <subsheetid>...</subsheetid>
  <display x="-345" y="..." w="120" h="30" />
  <font .../>
  <datatype>number</datatype>
  <initialvalue>0</initialvalue>
  <private />
  <alwaysinit />
</stage>
```

## Data with exposure (verified, 6.x export)
```xml
<!-- Environment Variable: reads the System Manager value of the SAME NAME -->
<stage stageid="..." name="Queue Name" type="Data">
  <display .../><font .../>
  <datatype>text</datatype>
  <initialvalue />
  <exposure>Environment</exposure>
</stage>
<!-- Session variable: Control Room can change it while the process runs -->
<stage stageid="..." name="Stop After Next Item" type="Data">
  <display .../><font .../>
  <datatype>flag</datatype>
  <initialvalue>False</initialvalue>
  <exposure>Session</exposure>
</stage>
```
No `<private />` / `<alwaysinit />` on exposed items. Generator: `data(..., exposure=...)`.

## Collection (verified)
A collection is its OWN stage type -- NOT a Data stage with a collection datatype. This
matters: ForEach `<loopdata>` and `[Collection.Field]` references depend on it, and a
collection emitted as `type="Data"` can import degraded. It carries no `<initialvalue>`.
```xml
<stage stageid="..." name="Rows" type="Collection">
  <subsheetid>...</subsheetid>
  <display x="-345" y="..." w="120" h="30" />
  <font .../>
  <datatype>collection</datatype>
  <private />
  <alwaysinit />
</stage>
```
The generator handles this automatically: any data item whose type is `collection` (declared
via `data('Rows', 'collection')`, or auto-created from a `collection` output) is rendered as
a Collection stage, not a Data stage. You do not do anything special -- just use
`'collection'` as the type.

## Note (canvas sticky) (verified)
```xml
<stage stageid="..." name="Purpose" type="Note">
  <subsheetid>...</subsheetid>
  <display x="240" y="..." w="330" h="80" />
  <font family="Segoe UI" size="10" style="Regular" color="008000" />
  <narrative>Free text explaining intent.</narrative>
</stage>
```

## SubSheetInfo (defines a page; one per non-main page) (verified)
```xml
<stage stageid="..." name="MAIN" type="SubSheetInfo">
  <subsheetid>...</subsheetid>
  <narrative>What this page does.</narrative>
  <display x="-345" y="-135" w="220" h="120" />
  <font family="Segoe UI" size="10" style="Bold" color="3366FF" />
  <published>true</published>
</stage>
```
Must be paired with a top-level `<subsheet subsheetid="..."><name>MAIN</name></subsheet>`
declaration. The validator checks these two agree. Publication is decided by the
`published` attribute on the `<subsheet>` declaration.

---

## Shapes from the estate's 7.x objects (bp_object_conventions s.12)
Each is ONE scrubbed real instance: tag and attribute names exact, values replaced. Child
tags can depend on the instance; this is what the estate's files contain, not a full schema.
Re-typed from a photo -- if an import complains, suspect a transcription slip first.

### Calculation (verified)
```xml
<stage stageid="..." name="..." type="Calculation">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{next-id}</onsuccess>
  <calculation expression="..." stage="o_flg_Result" />
</stage>
```

### MultipleCalculation (verified)
```xml
<stage stageid="..." name="..." type="MultipleCalculation">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{next-id}</onsuccess>
  <steps>
    <calculation expression="..." stage="i_flg_Click" />
    <calculation expression="..." stage="i_flg_Mark First Checkbox" />
  </steps>
</stage>
```

### Exception (verified)
```xml
<stage stageid="..." name="..." type="Exception">
  <subsheetid>...</subsheetid>
  <loginhibit onsuccess="true" />
  <display x="..." y="..." />
  <exception type="System Exception" detail="..." />
</stage>
<!-- rethrow, from a 6.x export (same element, different attributes): -->
<exception localized="yes" type="" detail="" usecurrent="yes" />
```

### Block (verified) -- a rectangle; membership is geometric, it has no links
```xml
<stage stageid="..." name="..." type="Block">
  <display x="..." y="..." w="..." h="..." />
  <font family="Segoe UI" size="10" style="Regular" color="33CCCC" />
</stage>
```
The sample has no `<subsheetid>` (a main-page block); a block on a subsheet carries one like
every other stage (6.x export confirms). Colour is the font colour; meaning is not stable
across the estate -- do not encode meaning in colour alone.

### Anchor (verified)
```xml
<stage stageid="..." name="..." type="Anchor">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." w="..." h="..." />   <!-- 6.x sample: w=10 h=10 -->
  <onsuccess>{target-id}</onsuccess>
</stage>
```

### ChoiceStart / ChoiceEnd (verified; 1/8 objects use them)
```xml
<stage stageid="..." name="..." type="ChoiceStart">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <groupid>{GUID}</groupid>
  <choices>
    <choice expression="...">
      <name>...</name><distance>75</distance><ontrue>{id}</ontrue>
    </choice>
    <choice expression="...">
      <name>...</name><distance>150</distance><ontrue>{id}</ontrue>
    </choice>
  </choices>
</stage>

<stage stageid="..." name="..." type="ChoiceEnd">          <!-- = the Otherwise path -->
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{otherwise-target-id}</onsuccess>
  <groupid>{SAME GUID as its ChoiceStart}</groupid>
</stage>
```
The source ChoiceEnd also had `<breakpoint type="0"><condition /></breakpoint>` -- a
developer's debug breakpoint, NOT part of the shape. Never generate it; the validator
should flag breakpoints left in exports.

### WaitStart / WaitEnd (verified; 5/8 objects, 89 pairs, always same groupid)
```xml
<stage stageid="..." name="..." type="WaitStart">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." w="..." h="..." />
  <groupid>{GUID}</groupid>
  <choices>
    <choice reply="True">
      <name>...</name><distance>75</distance><ontrue>{id}</ontrue>
      <element id="{app-model-element-id}" />
      <condition><id>{condition-id}</id></condition>
      <comparetype>Equal</comparetype>
    </choice>
  </choices>
  <timeout>...</timeout>
</stage>

<stage stageid="..." name="..." type="WaitEnd">            <!-- = the time-out path -->
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." w="..." h="..." />
  <onsuccess>{timeout-target-id}</onsuccess>
  <groupid>{SAME GUID as its WaitStart}</groupid>
</stage>
```

### Navigate (verified)
```xml
<stage stageid="..." name="..." type="Navigate" interval="...">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{next-id}</onsuccess>
  <step><element id="{element-id}" /><action><id>{action-id}</id></action></step>
</stage>
```

### Read (verified)
```xml
<stage stageid="..." name="..." type="Read">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{next-id}</onsuccess>
  <step stage="txt_Current Value"><element id="{element-id}" /><action><id>{action-id}</id></action></step>
</stage>
```

### Write (verified)
```xml
<stage stageid="..." name="..." type="Write">
  <subsheetid>...</subsheetid>
  <loginhibit />
  <display x="..." y="..." />
  <onsuccess>{next-id}</onsuccess>
  <step expr="...">
    <element id="{element-id}">
      <elementparameter>
        <name>...</name><expression>...</expression>
        <datatype>number</datatype><comparisontype>Equal</comparisontype>
      </elementparameter>
    </element>
  </step>
</stage>
```

### Application Modeller element (verified, abbreviated)
```xml
<element name="...">
  <id>{GUID}</id>
  <type>AAEdit</type><basetype>AAEdit</basetype>
  <datatype>text</datatype>
  <diagnose>False</diagnose>
  <attributes>
    <attribute name="..." inuse="True"><ProcessValue datatype="flag" value="..." /></attribute>
    <attribute name="..."><ProcessValue datatype="text" value="..." /></attribute>
    <!-- one <attribute> per match attribute (dozens); inuse="True" marks the ones matched on -->
  </attributes>
</element>
```
The generator emits every shape above, including Wait/Navigate/Read/Write wired to
Application Modeller elements by name, and the model itself (empty slots, or copied from a
spied export). It never invents match attributes: elements must be spied on the real
application. Generated Navigate/Read/Write/Wait stages need real element ids from an
existing model.

## Data types (the `type=`/`<datatype>` vocabulary)
`text`, `number`, `flag`, `date`, `datetime`, `time`, `timespan`, `password`, `collection`,
`binary`, `image`.

C# types inside code stages (what `compile_check.py` assumes):
text=`string`, number=`decimal`, flag=`bool`, date/datetime/time=`DateTime`,
timespan=`TimeSpan`, password=`SecureString`, collection=`DataTable`, binary=`byte[]`,
image=`Bitmap`.
