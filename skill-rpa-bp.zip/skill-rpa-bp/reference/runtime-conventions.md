# Runtime conventions (what makes a Blue Prism bot debuggable)

`validate.py` and `compile_check.py` prove the XML imports and the C# compiles. Neither says
anything about what happens against the real application. A bot that is "all green in test
mode" can still fail on the first real page. These rules make that failure readable from a
log file instead of a Blue Prism debugging session -- which matters doubly when the AI that
helps you cannot see or step through Blue Prism.

Applies to every object that drives a UI or an external system, estate-native or not.

## 1. Three run modes, one switch
Every bot supports, from its config (INI `[SETTINGS] run_mode` or an Environment Variable):

| Mode | Talks to real apps | Changes anything | Use |
|---|---|---|---|
| `test` | no -- canned replies/seed files | no | structural run, CI, refactors |
| `dryrun` | **yes** -- real navigation, real reads | **no** -- every mutating click/save/delete/close is skipped and logged as `WOULD <action> <target>` | first contact with a real environment; production smoke test |
| `live` | yes | yes | production |

- **MUST** route every mutating call (save, update, delete, close task, upload, send) through
  one helper that checks the mode. A mutation that bypasses the helper is a defect.
- **MUST** fail loudly at start if the mode value is unknown. Never default to `live`.
- `dryrun` is the step between "green in test mode" and "trusted in live". Skipping it means
  the first real run is also the first real mutation.

## 2. Test-mode seam (keep it when porting)
Every subsheet that navigates or scrapes has an explicit `if (TestMode())` early-out that
logs and returns canned data. The browser transport (`WdSend()` or equivalent) returns
canned JSON in test mode. **When porting a new bot, mirror this pattern** -- one new
subsheet without a test branch collapses the whole test-mode run.

## 3. Flight recorder (trace every external call)
- **MUST** log every driver/HTTP call from the single transport choke point:
  `time | method path | ms | status | context | first 300 chars of response`; full body on
  error. Log the request body for element lookups, frame switches and navigation (that is
  where the selector, frame and URL are).
- **MUST** keep a **frame breadcrumb** for browser work (`top>frame_a>iframe_b`) and print it
  on every line. Switching to top clears it; navigation/refresh clears it. Wrong frame
  context is the #1 cause of "element not found" after a refresh or region switch.
- **MUST** write the trace to the bot's log folder, one file per day, never to the BP
  install directory.

## 4. Failure dump
- **MUST** provide `DumpOnFailure(where)`: page source (`GET /session/{id}/source`) and a
  browser-only screenshot (`GET /session/{id}/screenshot`), plus current URL, window count
  and frame breadcrumb, written next to the trace. It must never throw.
- **MUST** call it in every catch on a browser-facing subsheet before rethrowing/returning.
- Evidence screenshots for business purposes use the same browser-only call -- not a
  full-desktop capture (which can leak other windows into evidence).

## 5. Waits and re-finds
- After any click that reloads a frame or page, **re-find** elements; never reuse an element
  reference across a reload (stale element).
- After `refresh` or navigation, switch to top, then back down the frame path explicitly.
- Every wait/poll loop is bounded (count or time) and logs what it waited for on timeout.

## 6. Positive control for every gate
Any check you add (trace, dump, dry-run guard) is proven by breaking something on purpose
and seeing the check fire: break one XPath key -> the trace shows the failing lookup and a
dump pair exists; set `dryrun` -> the trace shows `WOULD ...` and the target is unchanged.
A gate that has never failed has not been tested.
