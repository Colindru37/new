# Flow conventions

How to think about wiring a page. The generator turns a **linear list of steps** plus a few
explicit jumps into a correct Blue Prism flow graph.

## 1. The default flow is linear
Steps added with `action()` / `code()` fall through to the next step in the list via
`onsuccess`. You almost never wire the happy path by hand -- just add steps in order. Start
links to the first step; the last step links to End.

```python
pg.action('Login', ...)      # -> Load Data
pg.code('Load Data', ...)    # -> Save
pg.action('Save', ...)       # -> End
```

## 2. Jumps use stage NAMES, resolved at render time
Every construct that redirects flow takes a target that is one of:
- `'NEXT'` -> the following step in the list (the default)
- `'END'`  -> the page's End stage
- an exact **stage name** -> that stage's id (works for a forward skip OR a backward loop edge)

The generator builds a name->stageid map (first step with a given name wins) so you can
reference any stage by the name you gave it. **A name that matches no stage stops the build
with `FlowError`** (strict mode). Never "fix" that by passing `strict=False`; fix the name.

## 3. Decisions
```python
pg.decision('Item Available?', '[g_txt_Item ID] <> ""',
            true_target='NEXT',                    # continue processing
            false_target='Update Bot Status Offline')  # jump away by name
```
Use decisions for: guard clauses, flag checks, "is there another item", branch by request
type, verification gates.

## 4. Loops -- two kinds

### (a) ForEach over a collection -> use loop_start/loop_end
When you literally have a collection to iterate:
```python
pg.loop_start('Users', 'Users Loop Start')
pg.action('Process User', ...)
pg.action('Record Result', ...)   # write an audit row per iteration
pg.loop_end('Users Loop End')
```
Nest by opening a second loop before closing the first (they stack). The loop's collection
must be a Collection stage (`data('Users', 'collection')` or a collection output).

### (b) while-True / claim loop -> decision + backward edge (NOT a ForEach)
When there is no collection -- e.g. "claim the next work item until none left" -- model it as
a body of steps whose ends jump BACK to the first body stage by name, with a Decision
providing the only exit:
```python
pg.action('Get Next Item', 'Work Queues', 'Get Next Item', ...)   # loop body start
pg.decision('Item Available?', '[g_txt_Item ID] <> ""',  # empty queue returns Item ID = ""
            true_target='NEXT',
            false_target='Go Offline')                # the ONLY exit
# ... process the item ...
pg.action('Mark Done', ..., goto='Get Next Item')     # happy back-edge
pg.action('Mark Failed', ..., goto='Get Next Item')   # fail back-edge
pg.action('Go Offline', ...)                          # reached only when no item is left
```
Key rule: BOTH the happy end and the fail/skip end back-edge to the body start; only the
decision's false branch leaves the loop. Every such loop also needs a bound (item limit /
time limit / `Continue To Work`), see estate-conventions.md.

## 5. goto on an action/code stage
`goto='Some Stage Name'` overrides that stage's fall-through `onsuccess`. Use it for
back-edges (above) and for merging branches back together (two paths that both `goto` the
same convergence stage). A convergence target may be any stage name, **including a
`LoopEnd` name** -- gotoing the loop-end merges a branch back into the ForEach so it
continues to the next iteration.

## 5a. Expressions and text literals
`expr=` values are Blue Prism expressions, not raw Python:
- Data item reference: `'[MyItem]'`
- Number / flag / date: written bare, e.g. `'5'`, `'True'`, `'[Today]'`
- **Text literal:** must be double-quoted, with inner quotes doubled. Use the built-in
  helper `bp_gen.lit(...)` instead of hand-quoting:
  ```python
  from bp_gen import lit
  pg.action('Log', 'Utility - General', 'Nothing',
            inputs=[('text', 'Message', lit('Item "A" failed'))])
  ```
A boolean decision like `[Status]="Completed"` needs the literal quoted too:
`pg.decision('Done?', '[Status]=' + lit('Completed'))`.
Concatenation uses `&` inside the expression; build it from `lit()` pieces:
`lit('unknown kind ') + ' & [Kind]'` -> `"unknown kind " & [Kind]`.

## 6. Error handling: Recover/Resume
`recover_action(...)` adds steps to a parallel handler that catches ANY exception on the
page. You do not wire it into the main flow -- Blue Prism jumps there automatically. Keep
handlers short: log / assign-to-ops / update status, then End. To rethrow, end the handler
with `exception('Rethrow', use_current=True)`.

For estate-native work, scope each fallible unit inside a Block named after the work and
place recovery around that unit. A page may have multiple independently recoverable Blocks.
Capture exception type, detail, and stage together before routing or rethrowing. New
failures must use exactly `System Exception` or `Business Exception`; rethrows must preserve
the current exception. Pure calculation pages do not need a ceremonial Recover.

## 7. Orchestration vs object
- **Object** (`type="object"`): reusable capability. All pages are subsheets. Its first page
  is `Clean Up`; Main contains only globals; each public action has its own published page;
  `Attach` and other helper pages stay unpublished. Put reusable application operations and
  focused code stages here. Declare `code_options()` once if any page uses `code()`.
- **Process** (`type="process"`): orchestration. The first page is the implicit main page.
  Main owns declarations, environment and credential loading, queue/claim control, stop
  controls, top-level recovery, reporting, and calls to named pages. Put application
  interaction on named pages or in objects. "Orchestration-focused" does not mean an empty
  Main page.

> **Calling a page from another page (`page_ref`).** A process may split work across
> subsheet pages. Invoke one with:
> ```python
> main.page_ref('Validate Item', page='Validate Item',
>               inputs=[('text', 'ItemId', '[ItemId]')],
>               outputs=[('flag', 'IsValid', 'IsValid')])
> ```
> This emits a real Blue Prism SubSheet stage whose `<processid>` points at the target page's
> `subsheetid`; `inputs` map to that page's Start parameters and `outputs` receive its End
> parameters. The validator FAILS on any process page that is never called (unreachable).
> Objects do not use `page_ref` -- their pages are invoked externally by action name. See
> [examples/minimal_orchestration.py](../examples/minimal_orchestration.py).

## 7a. Choice (3+ known alternatives)
```python
v.choice('Item Type?', [('Account', '[l_txt_Item Type]="Account"', 'Revoke Account'),
                        ('Entitlement', '[l_txt_Item Type]="Entitlement"', 'Revoke Entitlement'),
                        ('Role', '[l_txt_Item Type]="Role"', 'Revoke Role')],
         otherwise='Reject Unknown Type')
```
Emits a ChoiceStart + ChoiceEnd pair (verified 7.x shape, shared groupid). Choices are
tested in order; the first true one wins; `otherwise` is the ChoiceEnd path. Use it instead
of long decision chains (an estate anti-pattern).

## 7b. Work blocks = recovery scope
```python
v.work_block('Load Item Data', 'Load Rows', 'Parse Rows',
             capture=('l_txt_Ex Type', 'l_txt_Ex Detail', 'l_txt_Ex Stage'),   # optional;
             # any slot may be None: capture=('l_txt_Ex Type', 'l_txt_Ex Detail', None)
             handler=[('Log Load Failure', 'Utility - General', 'Log',
                       [('text', 'Message', lit('Load failed'))])],
             then='RETHROW')          # or 'END', or a stage name (retry counter, claim loop)
```
Blue Prism decides which Recover catches an exception by Block membership (geometry). The
generator draws the Block around steps first..last with its Recover INSIDE; the chain runs in
the left lane OUTSIDE the block, in this order:

    Recover -> capture (Multiple Calculation) -> handler actions ->
        then='RETHROW': rethrow (preserve current exception)   [still in recovery mode]
        otherwise:      Resume -> continue at `then`

**Recovery mode rule (verified on the official MS Excel VBO):** `ExceptionType()`,
`ExceptionDetail()`, `ExceptionStage()` and the "preserve current exception" rethrow only
work between Recover and Resume. After Resume they return nothing. So: capture the details
BEFORE Resume (`capture=`), and decide on them after. `validate.py --strict` fails any stage
that reads these functions or rethrows outside recovery mode. The page-level
`recover_action` handler runs after Resume: logging only, no details, no rethrow.

## 7d. Business vs system exception, bounded retry (the recipe)
See `examples/minimal_orchestration.py` -- copy it rather than re-deriving:
- **The retry max**: an Environment Variable when operations should be able to tune it; a
  local data item with an initial value when the requirement fixes it ("up to 3").
- **Why the call has `goto='END'`**: the happy path leaves the page right after the call;
  everything after it on the page is only reached through the block's Resume (`then=`).
- **Per call, retry**: wrap the fallible call in a work block with
  `capture=(type, detail, None)` and `then='Retry Allowed?'`. The decision
  `[type] = "System Exception" AND [attempt] < [max]` loops back to an `Count Attempt`
  calculation before the call; otherwise re-raise: a business failure as
  `Business Exception` with the captured detail, a system failure as `System Exception`.
  A business exception is never retried.
- **Per item, in Main**: wrap the page call in a work block with full `capture`, then a
  `Business Exception?` decision: business -> `Mark Exception` with `Retry = False`;
  system -> `Mark Exception` with `Retry = True`, then the consecutive-failure counter and a
  `Too Many Consecutive Failures?` decision that throws to stop the process. A completed
  item resets the counter.
- **Continue To Work**: `IsStopRequested()` OR a session flag, item/time limits from
  Environment variables, `Now()`/`Hour()` for working hours. Checked before every claim.

## 7e. Page calls and code-stage names
- `page_ref(..., inputs=[(type, NAME, expr)])`: NAME must be exactly a Start input of the
  called page (`add_input` on that page); outputs likewise map the page's End outputs. The
  validator checks this.
- Inside a code stage, a parameter called `Default Domain` is the identifier
  `Default_Domain` (spaces -> underscores); keyword-like names are escaped by Blue Prism.

## 7c. Layout (automatic)
Main path straight down; long jumps/back-edges through named anchors in lanes to the right
(shortest spans innermost, so nested jumps never cross); recovery lanes to the left; data
items sorted in named Blocks; notes far right. Do not hand-place stages -- if a page reads
badly in `preview.py`, change the step order or split the page.

## 7f. UI stages and the Application Modeller
```python
o.application('Portal', 'Win32Launch', {...})            # NEW object: empty model (option B)
o.element('Window - Login - Win32', 'Window')             # parents first
o.element('Window - Login - Win32/Textbox - User - Win32', 'Edit')
# ...or for an EXISTING object:  o.use_model('BPA Object - Portal.xml')   (option A)
pg.wait_for('Wait For Login', [('Window - Login - Win32', 'CheckExists', 'NEXT')],
            '[Login Timeout]', on_timeout='Login Window Missing')
pg.write('Enter User', [('Textbox - User - Win32', '[User Name]')])
pg.navigate('Press Log In', [('Button - Log In - Win32', 'Press')])
pg.wait('Throttle', '[Retry Wait Seconds]')                # plain pause, no conditions
pg.read('Read Status', [('Label - Status - Win32', 'GetWindowText', 'Status', 'text')])
```
- Elements are referenced by full path or unique leaf name; an unknown name stops the build.
- Option B: after import, open Application Modeller and Identify each listed element
  (`validate.py` prints the "NOT SPIED yet" list). The element id stays, the stages stay wired.
  Spying can change an element's type: re-check the action of each stage that uses it.
- Action ids: the generator warns on any id not seen in real exports (verified: Press,
  SelectItem, ActivateApp, AttachApplication, DetachApplication, Launch, Terminate,
  SendKeyEvents, GetWindowText, GetWindowIdentifier, IsConnected, CheckExists).
  Argument-taking actions are not generated yet. Only app type `Win32Launch` is verified;
  for a browser or another type, run the Application Modeller wizard after import.
- `wait()` is Blue Prism's sleep idiom (verified: WaitStart with no conditions + timeout).

## 8. Audit visibility trade-off (workaround pattern)
Logic hidden inside a `code()` stage or a code-stage inner loop is invisible to Blue Prism's
step-level MI. When that matters, emit an audit row per iteration to a tracker/collection (a
`status`/`reason` column). This recovers most of the lost visibility cheaply without
exploding the diagram into hundreds of native stages.
