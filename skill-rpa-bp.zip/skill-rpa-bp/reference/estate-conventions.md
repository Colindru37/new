# Estate conventions (mandatory default)

These rules are derived from the in-house Blue Prism estate, not generic Blue Prism
guidance. Apply them to all newly generated artifacts unless the task names an existing
reference artifact or project contract that demonstrably uses a different architecture.

Object rules are measured in [object-conventions.md](object-conventions.md) (counts per
rule); where it disagrees with this file on objects, it wins.

## Precedence

When instructions conflict, use this order:

1. Importability and Blue Prism schema correctness.
2. The user's explicit requirements.
3. Existing project XML named as the source of truth.
4. Project-specific runtime contracts and compatibility constraints.
5. These estate conventions.
6. Generic examples in this skill.

Do not silently blend incompatible architectures. State the exception in the handover. For
example, GK Revoke explicitly uses raw WebDriver plus per-bot INI files and no Application
Modeller; preserve that design. An estate-native UI object without such a contract uses the
Application Modeller conventions below.

## Artifact and page structure

- **MUST** give every business object a first page named `Clean Up`, typed as a cleanup
  page. The observed estate does this in 8/8 objects.
- **MUST** keep object Main free of action logic. It may contain only the
  ProcessInfo/Start/End/Note stages and global Data stages grouped in a named variables
  Block. Put each public action on its own page.
- **MUST** make one object page represent one externally callable action. Publish public
  action pages; keep `Attach` and other implementation helpers unpublished.
- **MUST** make process Main the control framework: declarations, environment and
  credential loading, queue/claim loop, stop controls, top-level recovery, reporting, and
  calls to business/application pages. Keep application-specific interaction and reusable
  operations on named pages or in objects.
- **MUST** give every long-running process a `Continue To Work` page and a
  `Reset Global Data` page. The observed estate does this in 5/5 processes.
- **MUST** split process pages by application boundary or case-lifecycle step, not merely
  because code became long. Reuse pages through SubSheet calls rather than copying logic.
- **MUST** group declarations in named Blocks such as `Global Variables`,
  `Input Variables`, `Output Variables`, `Page Variables`, and `Local Variables`.
- **MUST** wrap each recoverable unit of work in a Block named after the work so its
  recovery scope is visible.

## Naming

- **MUST** name a process `<PREFIX><nnn> - <Area> - <Business Task>` (the estate's registered process
  prefix) when the number and area are known. Do not invent a number; request it or retain the
  existing registered name. Until it is known, use `PRC000` (a placeholder, NOT the estate's prefix) and list it as an
  open item.
- **MUST** start every public object action name with a verb. Established verbs include
  `Get`, `Execute`, `Set`, `Add`, `Remove`, `Close`, `Start`, `Initialize`, `Build`,
  `Flush`, `Click`, `Cancel`, `Read`, `Open`, `Create`, `Send`, `Calculate`, `Refresh`,
  `Paste`, `Verify`, `Enter`, and `Extract`.
- **MUST** name Decision stages as questions ending in `?`.
- **MUST** name Calculation stages `<Verb> <Target>` in Title Case.
- **MUST** name Multiple Calculation stages after the group of values they set, such as
  `Get Exception Details`, `System & Process Settings`, or `Reset Data`.
- **MUST** give generated Anchors purpose names (`Back To Claim Next Item`). Generic numbered
  anchors exist in 7/8 objects but are listed as an anti-pattern (object-conventions.md s.10).
- **MUST** leave Note stage names at Blue Prism defaults (`Note`, `Note1`, ...) and put the
  note text in the narrative.
- **MUST** prefix collection Data stages with `col_`, optionally preceded by a scope prefix
  (`g_col_`, `i_col_`, `o_col_`, `t_col_`).
- **MUST** name object action parameters in Title Case or as a single capitalized word. Do
  not expose internal `i_`/`o_`/type prefixes across the object interface. Preserve domain
  acronyms such as `PID`, `DB-ID`, and `URL`.

Data-item naming beyond collections is contested in the estate. Match the nearest reference
artifact. For NEW work use: `<scope>_<type>_<Meaning>` for process and page data items
(`g_txt_Item ID`, `l_num_Attempt`, `i_col_Item Data`), but Title Case WITHOUT prefixes for an
OBJECT's action parameters (the caller-facing interface: `Ticket ID`, `Note`), and the exact
System Manager name for Environment/Session items. These do not contradict: prefixes are for
internals, never for an interface.

## Exceptions and retry

- **MUST** put recovery on pages that interact with applications or other fallible external
  systems. Pure calculation/service pages do not require a ceremonial Recover.
- **MUST** scope recovery to the work Block. A page may have multiple recovery regions when
  it contains multiple independently recoverable Blocks.
- **MUST** classify new failures as exactly `System Exception` or `Business Exception`. Use
  `Runtime Exception` only for an object programming or initialization contract violation.
  Do not introduce spelling variants.
- **MUST** capture exception type, detail, and stage together before routing or rethrowing.
  Use a Multiple Calculation named `Get Exception Details` or `Exception Data`.
- **MUST** preserve the current exception type/detail when rethrowing from a Recover stage.
- **MUST** construct useful exception details from fixed context plus the captured detail.
  Never use an empty catch, silent failure, or unexplained generic message.
- **MUST** implement retry with an explicit counter, explicit maximum, an increment
  Calculation, and a Decision ending in `?`. Do not rely on queue maximum attempts as the
  diagram's retry mechanism.
- **MUST** bound every retry, polling, lock-acquisition, and scroll loop. A loop with no
  counter/time limit is invalid.
- **MUST** use a consecutive-exception guard in long-running queue processes: compare the
  current failure with the previous one, increment a counter, and terminate when the
  configured limit is reached.

## Objects and UI applications

- **MUST** separate launch/start from attach. Put `Attach` on an unpublished helper page and
  call it from actions that require an attached application.
- **SHOULD** follow the element-name grammar of sibling elements in the same model branch. The
  measured set mixes control type, business label and spying-technology markers in no
  uniform order; `<Control Kind> - <Label or Purpose> - <Technology>` (e.g. `Button - Refresh - AA`)
  is the default only for a brand-new model.
- **MUST** match the object's existing timeout style (measured split: 2/8 data-item timeouts,
  3/8 literals). A NEW object uses a named timeout Data item.
- **MUST** pair each WaitStart with a WaitEnd named `Time Out - <Wait stage name>`.
- **MUST** type parameters honestly: secrets as `password`, booleans as `flag`, and tabular
  values as `collection`.
- **MUST** match the failure contract of sibling actions in the same object. Both contracts
  are established (6/8 objects expose success/result flags, 6/8 throw); never mix both for
  equivalent actions. For a NEW object: return the payload and throw on failure; use a flag
  only when a negative result is a valid business answer (`Found?`).

Wait naming and object run mode are not established estate conventions. Match the nearest
in-house reference artifact and the application's concurrency needs.

## Code stages

- **MUST** use the language already declared by the object being changed (measured: 5/8 VB,
  3/8 C#). A NEW object uses C# (recommendation, not an estate fact; compile_check covers
  C# only).
- **MUST** keep the root `<globalcode>` empty. When shared project code is required, place
  it in the ProcessInfo/Code Options stage's `<code>` body using the exact shape proven by
  the project's source XML.
- **MUST** declare object-level language, Namespace Imports, and External References in the
  ProcessInfo/Code Options stage, never as ad-hoc root tags.
- **MUST** include the estate baseline references `System.dll`, `System.Data.dll`,
  `System.Xml.dll`, and `System.Drawing.dll`, plus baseline imports `System`, `System.Data`,
  and `System.Drawing`, when emitting Code Options. Add only assemblies actually used.
- **MUST** use `Newtonsoft.Json` for JSON when matching this estate. Do not add
  `System.Text.Json` without an explicit project requirement and compatible runtime proof.
- **MUST** keep ordinary Code stages focused on one operation. Put orchestration and branch
  visibility in the diagram.
- **MUST** pass `lib/compile_check.py` before import (see SKILL.md workflow step 7).

Code-stage naming is contested (PascalCase versus Title Case). Match the nearest project XML
rather than imposing one style.

## Configuration, queues, and credentials

- **MUST** use Blue Prism Environment Variables for estate-native process configuration.
  Load them on Main into local settings before processing.
- **MUST** use an Environment Variable for every external config-file path when a project
  contract requires a file. Do not hardcode deployment paths, URLs, selectors, queue names,
  or credentials in generated XML.
- **MUST** fetch secrets through Credential Manager and type them as `password`. Never
  preserve plaintext credentials copied from a source script or INI.
- **MUST** serialize shared resources with Environment Locking and release the lock on
  success, handled failure, and rethrow paths.
- **MUST** deduplicate before queueing, provide a stable unique key, and carry the
  source-system identifier as `Item Key` or the project's established key field.
- **MUST** use queue status for resumable progress and tags for exception or business
  classification when the process follows the estate queue pattern.
- **MUST** reserve Session variables for Control Room stop/limit controls. Do not expose
  ordinary configuration or business data as Session variables.
- **MUST** provide long-running processes with a `Continue To Work` control that evaluates
  stop request, item limit, time limit, and permitted working hours.
- **MUST** route progress and errors through the project's house logging object
  (`<HOUSE_LOG_OBJECT>.Save Event` / `<HOUSE_LOG_OBJECT> - Logging [S].Event String` when available) rather
  than inventing a new logger.

## Documentation and validation

- **MUST** use descriptive stage and page names; stage narratives are optional and are not a
  substitute for readable names.
- **MUST** put explanatory Note text in the narrative while retaining the default Note
  stage name.
- **MUST** keep artifact version `1.0` and omit narrative version histories when creating
  work for this estate, unless release governance explicitly supplies another version.
- **MUST** validate every cross-object object/action string by exact match and every
  SubSheet reference by ID/name before import. `validate.py` does this automatically for
  objects present in the same directory -- put the called objects next to the callers.
- **MUST** run structural and flow validation and inspect the resolved-link report.
  Importability is necessary but not sufficient: verify retries, recovery exits, lock
  releases, queue dedupe, and stop-control paths.
