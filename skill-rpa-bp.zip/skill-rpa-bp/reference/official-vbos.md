# Official VBO signatures (verified)

Generated from the official objects in a real Blue Prism release (training release, 6.x).
Names and parameters are EXACT -- use them as written; the validator checks calls against
an object only when its XML is beside yours (or passed with `--with`).
Your estate may run newer versions of these VBOs: if an action is missing or differs on the
Blue Prism machine, the object there wins -- open its Action stage and read it.


## MS Excel VBO  (69 actions)

| Action | Inputs | Outputs |
|---|---|---|
| Activate Workbook | handle (number), Workbook Name (text) |  |
| Activate Worksheet | handle (number), Workbook Name (text), Worksheet Name (text), Create If Missing? (flag) |  |
| Attach | Enable Events (flag) | handle (number) |
| Attach to workbook | File name (text), Enable Events (flag) | handle (number) |
| Close All Instances |  |  |
| Close Current Workbook | handle (number) |  |
| Close Instance | handle (number), Save Changes (flag) |  |
| Close Workbook | handle (number), Workbook Name (text), Save Data (flag) |  |
| Copy | Handle (number), Workbook (text) |  |
| Copy and Paste Worksheet Range | Handle (number), Source Workbook (text), Source Worksheet (text), Source Range (text), Destination Workbook (text), Destination Worksheet (text), Destination Range (text) |  |
| Create Instance | Enable Events (flag) | handle (number) |
| Create Workbook | handle (number) | Workbook Name (text) |
| Create Worksheet | handle (number), Workbook Name (text), Worksheet Name (text) |  |
| Cut | Handle (number), Workbook (text) |  |
| Delete | Handle (number), Workbook (text), Shift (Left or Up) (text) |  |
| Delete Worksheet | handle (number), Workbook Name (text), Worksheet Name (text) |  |
| Exit |  |  |
| Find Next Empty Cell | handle (number), Direction (text), Activate Cell? (flag) | Cell Reference (text) |
| Format Cell | handle (number), Cell Reference (text), Cell Format (text) |  |
| Format Current Cell | handle (number), Cell Format (text) |  |
| Get Active Cell | handle (number) | Cell Reference (text) |
| Get Active Cell Value | handle (number) | Value (text) |
| Get Cell Value | handle (number), Cell Reference (text) | Value (text) |
| Get Formatted Cell Value | handle (number), Cell Reference (text) | Value (text) |
| Get Number Of Rows | handle (number), Workbook Name (text), Worksheet Name (text) | Number of rows (number) |
| Get Worksheet As Collection | handle (number), Workbook Name (text), Worksheet Name (text) | Data (collection) |
| Get Worksheet As Collection (Fast) |  | Data (collection) |
| Get Worksheet Name | Handle (number), Workbook (text), Worksheet Position (number) | Worksheet (text) |
| Get Worksheet Names | handle (number), Workbook Name (text) | Worksheet Names (collection) |
| Get Worksheet Position | Handle (number), Workbook (text), Worksheet (text) | Position (number) |
| Get Worksheet Range As Collection | handle (number), Workbook Name (text), Worksheet Name (text), StartCell (text), EndCell (text) | Data (collection) |
| Get Worksheet as Collection Offset | handle (number), Workbook Name (text), Worksheet Name (text), StartCell (text), Use Header (flag) | Data (collection) |
| Go To Cell | handle (number), Cell Reference (text) |  |
| Go To Next Cell | handle (number), Rows (number), Columns (number) | Cell Reference (text) |
| Go To Next Empty Cell Down | handle (number) | Cell Reference (text) |
| Go To Next Empty Cell Left | handle (number) | Cell Reference (text) |
| Go To Next Empty Cell Right | handle (number) | Cell Reference (text) |
| Go To Next Empty Cell Up | handle (number) | Cell Reference (text) |
| Hide | handle (number) |  |
| Hide Other Worksheets | Handle (number), Workbook (text), Worksheet (text) |  |
| Hide Worksheet | Handle (number), Workbook (text), Worksheet (text) |  |
| Import CSV | Destination Handle (number), Destination Workbook (text), Destination Worksheet (text), Destination Range (text), Source File Path (text), Source Text Qualifier (text) |  |
| Insert | Handle (number), Workbook (text), Shift (Left or Up) (text) |  |
| Is Read Only | handle (number), Workbook Name (text) | Read Only? (flag) |
| Move Worksheet | Handle (number), Source Workbook (text), Source Worksheet (text), Destination Workbook (text), Destination Position (number), Copy (flag) |  |
| Open Instance | Workbook Name (text), Enable Events? (flag) | handle (number) |
| Open Workbook | handle (number), File name (text) | Workbook Name (text) |
| Paste | Handle (number), Workbook (text), Values Only (flag) |  |
| Protect Workbook | Handle (number), Workbook (text), Password (password) |  |
| Release Instance | handle (number) |  |
| Remove Blank Rows | handle (number) |  |
| Run Macro | Handle (number), Macro Name (text) |  |
| Save Current Workbook |  |  |
| Save Current Workbook As | handle (number), File name (text) | New Workbook Name (text) |
| Save Workbook | handle (number), Workbook Name (text) |  |
| Save Workbook As | handle (number), Workbook Name (text), Filename (text) | New Workbook Name (text) |
| Select | Handle (number), Workbook (text), Worksheet (text), Cell Reference (text) |  |
| Set Cell Value | handle (number), Cell Reference (text), Value (text) |  |
| Set Current Instance | handle (number) |  |
| Set Events Enabled | handle (number), Enable Events (flag) |  |
| Set Window Location | handle (number), X (number), Y (number) |  |
| Set Window Size | handle (number), Width (number), Height (number) |  |
| Set Window State | handle (number), State (text) |  |
| Show | handle (number) |  |
| Split Worksheet | handle (number), Rows per worksheet (number), Workbook Name (text), Worksheet Name (text), No Title Row (flag), Path (text) |  |
| Worksheet Exists | handle (number), Workbook Name (text), Worksheet Name (text) | Worksheet Exists (flag) |
| Write Collection | handle (number), Collection (collection), Workbook Name (text), Worksheet Name (text), Cell Reference (text), Include Column Names (flag) |  |
| Write To Clipboard | Value (text) |  |

## Utility - Environment  (16 actions)

| Action | Inputs | Outputs |
|---|---|---|
| Clear Clipboard |  |  |
| Font Smoothing Enabled |  | Enabled (flag) |
| Get Clipboard |  | Clipboard (text) |
| Get Machine Name |  | Machine Name (text) |
| Get Screen Resolution |  | Horizontal Resolution (number), Vertical Resolution (number) |
| Get User Name |  | User Name (text) |
| Kill Process | Process Name (text) |  |
| Read Memory Stats | Process Names (collection) | Process Statistics (collection) |
| Read Process Working Set | Process Name (text) | Working Set (number) |
| Run Process Until Ended | Application (text), Arguments (text), Working Folder (text), Timeout (timespan) |  |
| Set Clipboard | Clipboard (text) |  |
| Start Process | Application (text), Arguments (text) |  |
| Start Process Read Stderr and Stdout | Arguments (text), Process Name (text) | Standard Output (text), Standard Error (text) |
| Wait for Process | Maximum wait time (seconds) (number), Process Name (text) | Found? (flag) |
| Wait for Process Window | Process Name (text), Window Title (text), Wait (number) | Found (flag) |

## Utility - File Management  (24 actions)

| Action | Inputs | Outputs |
|---|---|---|
| Append to Text File | File Name (text), Text (text) | Success (flag), Message (text) |
| Combine Path | Folder (text), File Name (text) | Path (text) |
| Configure | Raise exception on any failure (flag) |  |
| Copy File | File Path (text), Destination Path (text) | Success (flag), Message (text) |
| Create Directory | Directory Path (text), Error If Already Exists (flag) | Success (flag), Message (text) |
| Delete Directory | Directory Path (text), Error If Not Exists (flag), Recursive (flag) | Success (flag), Message (text) |
| Delete File | File Name (text) | Success (flag), Message (text) |
| Delete Files | Folder (text), Pattern (text) |  |
| Directory Exists | Directory Name (text) | Exists (flag) |
| Download File | Source URL (text), Destination Path (text) |  |
| File Exists | File Name (text) | Exists (flag) |
| Get CSV Text As Collection | CSV File Path (text), First Line Is Header (flag) | CSV Values (collection) |
| Get File Size | File Path (text) | Size (number) |
| Get Files | Folder (text), Patterns CSV (text) | Success (flag), Message (text), Files (collection) |
| Get Folders | Folder (text) | Success (flag), Message (text), Folders (collection) |
| Get Special Folder Path | Special Folder Name (text) | Folder Path (text) |
| Move File | File Path (text), Destination Path (text) | Success (flag), Message (text) |
| Read All Text from File | File Name (text) | Success (flag), Message (text), Text (text) |
| Read Lines From File | File Path (text), Start Line (number), End Line (number) | Success (flag), Message (text), Lines (collection), Line Count (number), End of File (flag) |
| Split Path | File Path (text) | File Name (text), Folder (text) |
| Sub Directory Exists | Directory Path (text) | Exists (flag), Success (flag), Message (text) |
| Write Binary Data | Binary Data (binary), File Name (text) | Success (flag), Message (text) |
| Write Text File | File Name (text), Text (text) | Success (flag), Message (text) |

## Utility - Collection Manipulation
See estate-objects.md (full table there).

## Recipe: read an Excel sheet into a collection (as the official training solution does)
`Utility - File Management`.`File Exists`(File Name) -> decision on `Exists` -> throw System
Exception "file not found" -> `MS Excel VBO`.`Create Instance` -> `Open Workbook`(handle,
File name) -> `Get Worksheet As Collection`(handle, Workbook Name from Open Workbook,
Worksheet Name) -> `Close Workbook`/`Exit`. (The training solution uses the `(Fast)` variant,
which takes NO inputs and relies on the object's hidden state -- prefer the explicit one.) Recovery: if an Excel instance was created, `Utility -
Environment`.`Kill Process`(Process Name "Excel"), then rethrow. The first row becomes the
collection's field names. Load the rows into the work queue with `Add To Queue`.

## Recipe: start an application cleanly
`Utility - Environment`.`Kill Process`(Process Name = the exe name without .exe) before
`Launch`, so a stale instance from a crashed run cannot be attached to by mistake.

