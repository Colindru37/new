# Estate objects, variables and built-in functions

What a generated process calls for the standard plumbing. Everything here is either a
Blue Prism built-in or was read from real exported XML. **Do not invent object or action
names**: a call to a name that does not exist imports fine and fails at runtime. When a
needed object is not listed here, ask for its exact name (and open its Action stage to
read the parameter list) before generating.

## Work Queues (internal object, verified)
Object name `Work Queues` (internal class `Blueprism.Automate.clsWorkQueuesActions`).
Signatures from a real export; confirm optional inputs once in the Action stage dialog.

| Action | Inputs | Outputs |
|---|---|---|
| Add To Queue | Queue Name (text), Data (collection), Defer Until (datetime), Priority (number), Tags (text), Status (text) | Item IDs (collection) |
| Get Next Item | Queue Name (text), Key Filter (text), Tag Filter (text) | Item ID (text), Data (collection), Status (text), Attempts (number) |
| Mark Completed | Item ID (text) | |
| Mark Exception | Item ID (text), Exception Reason (text), Retry (flag), Keep Locked (flag) | New Item ID (text) |
| Update Status | Item ID (text), Status (text) | |
| Tag Item | Item ID (text), Tag (text) | |
| Defer | Item ID (text), Until (datetime) | |
| Set Data | Item ID (text), Data (collection) | |
| Get Item Data | Item ID (text) | Key, Priority, Status, Attempts, Worktime, ..., Exception Reason, Tags, Data |

Rules that bite:
- **There is no "Has Work" output.** An empty queue returns `Item ID = ""`; the claim-loop
  decision is `[Item ID] <> ""`.
- Each ROW of the Data collection becomes one item. The item key is not an input: it is the
  queue's "Key Name" (System Manager) and must equal a column of Data.
- Mark Completed / Mark Exception only work on an item this session got from Get Next Item.
- Mark Exception with `Retry = True` creates a NEW item; the retry limit is set on the queue.
  Business exceptions: `Retry = False`. System exceptions: `Retry = True`.
- Tags: one text, `;`-separated. Tag Filter: `+A;-B`, `*` wildcard. Lower priority = first.

## Environment and Session variables (verified shapes)
They are **data items**, not actions. Generator: `data(name, dtype, exposure=...)`.
- `exposure='Environment'`: the item reads the Environment Variable **of the same name**,
  defined in System Manager. No initial value. Use for every setting (queue names, limits,
  paths, URLs) instead of literals.
- `exposure='Session'`: a session variable Control Room can change while the process runs
  (e.g. `Stop After Next Item`). Give it an initial value.
The generator groups them in `Environment Variables` / `Session Variables` blocks and the
validator never reports them as unused.

## Built-in functions for the control framework
- `IsStopRequested()` -- true when Control Room asked the process to stop. Real usage:
  `[Stop After Next Case] OR IsStopRequested()` in a Decision.
- `ExceptionType()`, `ExceptionDetail()`, `ExceptionStage()` -- ONLY in recovery mode (after
  a Recover, before its Resume). Use `work_block(..., capture=(...))`.
- `Now()`, `Today()`, `Hour(...)`, `MakeTimeSpan(...)` -- time limits / working hours.
- Text: `Trim`, `Upper`, `Lower`, `Len`, `InStr`, `Mid`, `Replace`, `NewLine()`.

## Official utility VBOs (exist in the standard install; names verified)
`Utility - Collection Manipulation`, `Utility - Environment`, `Utility - File Management`,
`MS Excel VBO`. Read the exact action and input names from the object before calling one
(the validator checks them when the object's XML sits in the same folder). Example verified
signature: `Utility - Collection Manipulation`.`Copy Rows` -- in: Start Row (number),
Number of Rows to Copy (number), Source Collection (collection); out: Output Collection.

## House objects (estate-specific: ask)
- Logging: the estate routes events through its house logging object (see
  estate-conventions.md). The examples use `Utility - General`.`Log` as a **placeholder**.
- Application objects (ticket system, target apps): exact names from the project.

## Checking calls to objects you do not have
`validate.py` only checks a call when the called object's XML is in the same folder;
otherwise it prints `external objects (not in dir, unchecked)`. Put the real exported object
-- or, if it does not exist yet, a STUB generated with the agreed interface (pages with the
exact Start inputs / End outputs, no logic) -- in a SEPARATE folder and pass it with
`--with`: `python lib/validate.py out --with stubs --strict`. Calls are then checked
against the contract; the stub is never validated as yours and never shipped.

## Reading the claimed item's data
`Get Next Item` returns `Data` (a one-row collection). Read a field with
`[g_col_Item Data.Field Name]` where `Field Name` is the queue item's column name exactly as
the feeder wrote it with Add To Queue. Agree the column names with whoever feeds the queue.

## Waiting between retries
Blue Prism's idiom for "sleep N seconds" is a Wait stage with NO conditions and a timeout
(verified on the official Utility - Environment object): `pg.wait('Throttle', '[Seconds]')`.
No code stage needed.
