# Estate objects, variables and built-in functions

What a generated process calls for the standard plumbing. Everything here is either a
Blue Prism built-in or was read from real exported XML. **Do not invent object or action
names**: a call to a name that does not exist imports fine and fails at runtime. When a
needed object is not listed here, ask for its exact name (and open its Action stage to
read the parameter list) before generating.

## Work Queues (internal object, verified)
Object name `Work Queues` (internal class `Blueprism.Automate.clsWorkQueuesActions`).
Signatures from a real export; confirm optional inputs once in the Action stage dialog.

| Action | Inputs | Outputs |
|---|---|---|
| Add To Queue | Queue Name (text), Data (collection), Defer Until (datetime), Priority (number), Tags (text), Status (text) | Item IDs (collection) |
| Get Next Item | Queue Name (text), Key Filter (text), Tag Filter (text) | Item ID (text), Data (collection), Status (text), Attempts (number) |
| Mark Completed | Item ID (text) | |
| Mark Exception | Item ID (text), Exception Reason (text), Retry (flag), Keep Locked (flag) | New Item ID (text) |
| Update Status | Item ID (text), Status (text) | |
| Tag Item | Item ID (text), Tag (text) | |
| Defer | Item ID (text), Until (datetime) | |
| Set Data | Item ID (text), Data (collection) | |
| Get Item Data | Item ID (text) | Key, Priority, Status, Attempts, Worktime, ..., Exception Reason, Tags, Data |

Rules that bite:
- **There is no "Has Work" output.** An empty queue returns `Item ID = ""`; the claim-loop
  decision is `[Item ID] <> ""`.
- Each ROW of the Data collection becomes one item. The item key is not an input: it is the
  queue's "Key Name" (System Manager) and must equal a column of Data.
- Mark Completed / Mark Exception only work on an item this session got from Get Next Item.
- Mark Exception with `Retry = True` creates a NEW item; the retry limit is set on the queue.
  Business exceptions: `Retry = False`. System exceptions: `Retry = True`.
- Tags: one text, `;`-separated. Tag Filter: `+A;-B`, `*` wildcard. Lower priority = first.

## Environment and Session variables (verified shapes)
They are **data items**, not actions. Generator: `data(name, dtype, exposure=...)`.
- `exposure='Environment'`: the item reads the Environment Variable **of the same name**,
  defined in System Manager. No initial value. Use for every setting (queue names, limits,
  paths, URLs) instead of literals.
- `exposure='Session'`: a session variable Control Room can change while the process runs
  (e.g. `Stop After Next Item`). Give it an initial value.
The generator groups them in `Environment Variables` / `Session Variables` blocks and the
validator never reports them as unused.

## Utility - Collection Manipulation (official VBO, every action verified from the release)
No "Add Row" action exists. To build a collection row by row: put the new row in a one-row
collection and use `Append Rows to Collection`; or set fields with `Set Collection Field`.

| Action | Inputs | Outputs |
|---|---|---|
| Append Rows to Collection | Main Collection, Collection to Append | Combined Collection |
| Append Field (Text) / (Number) | Collection, Field Name, Value (text) | Appended Collection |
| Copy Rows | Start Row (number, 0-based), Number of Rows to Copy (number), Source Collection | Output Collection |
| Read Collection Field | Row Index (number), Collection, Field Name | Value Read (text) |
| Set Collection Field | Row Index (number), Collection, Field Name, New Value (text) | Updated Collection |
| Filter Collection | Collection In, Filter (text) | Collection Out |
| Field Exists | Input Collection, Field | Exists (flag) |
| Collection Contains Value | Collection, Column Name, Exact Value, Regex | Contains Search Term (flag), Groups |
| Sort Collection | Collection, Sort Field, Ascending Order (flag) | Sorted Collection, Success, Message |
| Remove Empty Rows | Collection In | Collection Out |
| Merge Collection | Collection 1, Collection 2 | Collection 3 |
| Get Collection Fields | Input Collection | Collection Fields |
| Delete Field / Rename Field | Collection In, Field Name (, New Name) | Collection Out |
(Others: Delete Column, Fill Blanks, Remove Null Rows, Reverse/Transpose/Split Collection,
Rename Collection Fields, Set Column Names From First Row / From Expected Collection.)

## Built-in functions for the control framework
- `IsStopRequested()` -- true when Control Room asked the process to stop. Real usage:
  `[Stop After Next Case] OR IsStopRequested()` in a Decision.
- `ExceptionType()`, `ExceptionDetail()`, `ExceptionStage()` -- ONLY in recovery mode (after
  a Recover, before its Resume). Use `work_block(..., capture=(...))`.
- `Now()`, `Today()`, `Hour(...)`, `MakeTimeSpan(...)` -- time limits / working hours.
- Text: `Trim`, `Upper`, `Lower`, `Len`, `InStr`, `Mid`, `Replace`, `NewLine()`.
- Conversion and time used across the estate's processes (process conventions report):
  `ToNumber()`, `Now()`, `Today()`, `LocalTime()`, `MakeTimeSpan()`.

## Official utility VBOs -- see official-vbos.md for every action signature
`MS Excel VBO`, `Utility - Environment` (Kill Process, ...), `Utility - File Management`
(File Exists, Move File, ...) are listed action by action in
[official-vbos.md](official-vbos.md), with the Excel-to-queue and clean-start recipes.

## Credentials (internal object, verified on the estate machine)
Secrets come from Blue Prism Credential Manager through the internal object `Credentials`.

| Action | Inputs | Outputs |
|---|---|---|
| Get | Credentials Name (text) | Username (text), Password (password), Expiry Date (date), Status (text) |

Note the exact input name: `Credentials Name` (plural). Type the password data item as
`password`; never write it to a log, note, queue item, exception detail or screenshot. The
credential itself is created in System Manager > Security > Credentials and must grant
access to the process/object that reads it. Put the credential NAME in an Environment
Variable, not in the XML.
```python
main.data('Portal Credential Name', 'text', exposure='Environment')
main.action('Get Portal Credentials', 'Credentials', 'Get',
            inputs=[('text', 'Credentials Name', '[Portal Credential Name]')],
            outputs=[('text', 'Username', 'g_txt_User'), ('password', 'Password', 'g_pwd_Password')])
```
A stub you write from a GUESS for any other object makes `--with` pass against your guess --
it remains an OPEN ITEM in the handover.

## Official utility VBOs (exist in the standard install; names verified)
`Utility - Collection Manipulation`, `Utility - Environment`, `Utility - File Management`,
`MS Excel VBO`. Read the exact action and input names from the object before calling one
(the validator checks them when the object's XML sits in the same folder). Example verified
signature: `Utility - Collection Manipulation`.`Copy Rows` -- in: Start Row (number),
Number of Rows to Copy (number), Source Collection (collection); out: Output Collection.

## House objects (estate-specific: ask)
- Logging: the estate routes events through its house logging object (see
  estate-conventions.md). The examples use `Utility - General`.`Log` as a **placeholder**.
- Application objects (ticket system, target apps): exact names from the project.

## Checking calls to objects you do not have
`validate.py` only checks a call when the called object's XML is in the same folder;
otherwise it prints `external objects (not in dir, unchecked)`. Put the real exported object
-- or, if it does not exist yet, a STUB generated with the agreed interface (pages with the
exact Start inputs / End outputs, no logic) -- in a SEPARATE folder and pass it with
`--with`: `python lib/validate.py out --with stubs --strict`. Calls are then checked
against the contract; the stub is never validated as yours and never shipped.

## Reading the claimed item's data
`Get Next Item` returns `Data` (a one-row collection). Read a field with
`[g_col_Item Data.Field Name]` where `Field Name` is the queue item's column name exactly as
the feeder wrote it with Add To Queue. Agree the column names with whoever feeds the queue.

## Waiting between retries
Blue Prism's idiom for "sleep N seconds" is a Wait stage with NO conditions and a timeout
(verified on the official Utility - Environment object): `pg.wait('Throttle', '[Seconds]')`.
No code stage needed.
