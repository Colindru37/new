# Dev Prompt - Port Another GK Revoke Bot to Blue Prism

Paste this whole file (or just the **Prompt** section) into a fresh AI coding-agent chat to
port one of the other 8 GK Revoke Python bots (see the fill-in table at the end) to Blue Prism.

The Alice-Global and BlueSpace pair was shipped end-to-end (Maker + Checker + Master
Populate Queue, all green in test mode). Read the notes below carefully before you start --
they list every trap we hit so you do not hit them again.

> Items marked **[NEW]** were added after the first real (non-test) runs. They are traps
> that test mode cannot show.

---

## 0. READ THIS FIRST - what is (and is not) the source of truth

> Placeholders: `<WORK_ROOT>` = the dev folder that holds `minim\` and `scripts\`;
> `<PROD_SHARE>` = the prod file share already in the INIs; `<LABEL_ID>` = the `LabelID=`
> value in `Master_Maker\config.ini`.

- **Source of truth is the XML in `<WORK_ROOT>\minim\`.**
  The Python builder scripts under `<WORK_ROOT>\` (`gk_build_*.py`,
  `build_all.py`, `final_validate.py`, `write_guide.py`) are STALE. They produced the first
  cut and were then edited past by hand. Do NOT re-run them - you will overwrite live fixes.
  Use them only as a reference for the general shape, and even then verify against the XML.
- The shipped deliverable in `minim\`:
  - `BPA Object - GK Revoke Browser - Generic.xml` (36 subsheets, ~47 KB of C# in one Code
    Options stage - see section 3)
  - `BPA Object - IDAM Common - Generic.xml` (Build Evidence Doc, Apply Sensitivity Label,
    Send Outlook Template Email, Upload Attachment To SNOW)
  - `BPA Object - Word.xml`, `BPA Object - Email SMTP.xml`
  - 5 processes: `Alice Maker`, `Alice Checker`, `BlueSpace Maker`, `BlueSpace Checker`,
    `Master Populate Queue`
  - `config\` with 7 per-bot INIs (Alice Maker/Checker, BlueSpace Maker/Checker, Master
    Maker/Checker, plus a shared sample)
  - `excel\` with test trackers, seed files, and a test log
- **Original Python** lives at `<WORK_ROOT>\scripts\scripts\<app>\`
  and its INIs at `<WORK_ROOT>\scripts\config\<app>\`.

## 1. Working constraints (Windows, no VS Code workspace)

- `<WORK_ROOT>\` is OUTSIDE the AI workspace. `read_file` on files under it
  WILL FAIL. Use PowerShell (`run_in_terminal`) with `[IO.File]::ReadAllText()` /
  `WriteAllText()` and ABSOLUTE paths. `create_file`, `replace_string_in_file`, and
  `multi_replace_string_in_file` DO work on absolute paths.
- CRLF line endings throughout. Preserve them on writes.
- Files are large; batch reads via PowerShell `Select-String` or slicing rather than a
  hundred small `read_file` calls.
- `create_file` fails if the file already exists - either delete first with `Remove-Item`,
  or use `[IO.File]::WriteAllText()`.

## 2. Architecture in one paragraph

The Browser object drives Edge by speaking the W3C WebDriver protocol directly to a
locally-running `msedgedriver.exe` over HTTP, using `System.Net.HttpWebRequest` +
`Newtonsoft.Json` (both ship with Blue Prism). **No Selenium DLLs, no Application Modeller
spying.** Every locator comes from an `[XPATHS]` section in a per-bot `config.ini`, read at
runtime via `X("key")` / `GetSetting("key")` helpers. Each orchestration process is a thin
Blue Prism process that calls Browser + IDAM Common actions in the same order as the Python
`main()`.

## 3. Blue Prism XML gotchas that cost us hours

If you ignore any of these, BP will throw `Object reference not set to an instance of an
object` at the Action stage with no other clue. Every one of these was a real bug we hit.

1. **Global C# code MUST live inside a `Code Options` ProcessInfo stage**, not at the root of
   `<process>`. The Code Options stage carries `<language>`, `<references>`, `<imports>`
   (NOT `<namespaces>`), `<globalcode/>`, and `<code>`. If any of these tags sit at the root
   `<process>` element, BP silently fails to compile the object and every action throws a
   null-ref. Look at any shipped subsheet for the exact shape.
2. **Object internal `name=` attribute must NOT carry the `BPA Object -` filename prefix.**
   That prefix is filename-only. Leaking it breaks all cross-object action resolution.
3. **Text literals in `expr=` must be quoted** (`"foo"`, not `foo`).
4. **Collections are `type="Collection"` stages**, not `type="Data"` with a collection datatype.
5. **Cross-object references resolve by EXACT string match** on
   `<resource object="..." action="...">`. Rename anything - repoint every reference.
6. **Any compile failure = null-ref at runtime, at the Action call, with no clue as to why.**
   Missing input mapping, output mapping to a stage that doesn't exist, unbalanced braces in
   a code stage - all present the same way. If a stage null-refs, first suspect a compile
   problem in the object it calls, not a data problem.
7. **PowerShell's XML adapter has a footgun**: `$node.<childtag>` returns the `name`
   attribute value if a child has a `name` attribute, instead of the child element. Use
   `GetElementsByTagName()` and check `LocalName` when walking BP XML. This wasted an entire
   session before we caught it.
8. **`<imports>` not `<namespaces>`** - the tag name matters.
9. **[NEW] Run the gates before every import** (from the `skill-rpa-bp` skill):
   `python lib\validate.py <dir> --flow` (catches 1-5 and the output-mapping half of 6) and
   `python lib\compile_check.py <dir> --ref-dir "<Blue Prism install dir>"` (catches the
   compile half of 6, with stage name and line). Put the called objects in the same folder
   as the processes so cross-object calls are checked too.

## 4. Runtime traps (data / IO / test-mode) that cost us hours

1. **ACE OLEDB `UPDATE` silently no-ops against these .xlsx files.** The
   `Microsoft.ACE.OLEDB.12.0` provider reports `rows=1` and the file timestamp never changes.
   `INSERT` works, `UPDATE` does not. The Browser object ships an OOXML writer
   (`XlsxSetCell(path, setCol, setVal, whereCol, whereVal)` in the global code) built on
   `System.IO.Compression.DeflateStream` - only use it for any in-place cell update. Do not
   add new `UPDATE` OLE-DB calls thinking they will work.
2. **`Update RITM Tracker` takes a `StatusColumn` input** (default `"Maker Task Status"`).
   Checkers MUST pass `"Checker Task Status"`, or the checker will overwrite the maker's
   status column. Wire this on every process.
3. **`AttachmentFile` in ReadSheet / OleDb calls needs the FULL path**, not
   `Path.GetFileName(...)`. The original Python had this bug too - do not copy it.
4. **The trailing/off-by-one in `Update CT Status`** silently skipped the last row. Use
   `for i in range(0, len(rows))`, not `range(0, len(rows)-1)`.
5. **Scroll loops on `pos += viewport - 100`** hang if `innerHeight <= 100` (headless / small
   viewport). Guard with a max-iteration cap AND a `pos <= lastPos` bail.
6. **`Username` must be assigned from the config** before any `email == Username`
   comparison. The Python original never assigned it in one branch - the bot would report
   success while revoking nothing.
7. **`TrackerPath` must be passed to `Add Result To Tracker` in every process** (4 processes
   originally missed this). Missing = `""` + `".lock"` = write to BP install dir.
8. **`AcquireLock` must have a timeout**, not `while(true)`. Cap at ~30s and fail loudly.
9. **`Add Result To Tracker` must be fed the tracker's real schema**, not the role dictionary
   (`RITMNumber | Maker Task ID | Application | Current Date | Current Time | Request_Type |
   Owner | Role_Name | Request_Id | Remarks | SC_Updation_Time | MTStatus | Comment`).
10. **`Add To Queue` needs a unique key** or Master Populate re-queues the same RITMs. Use
    `RITM + Application` or the SNOW sys_id.
11. **Tracker dedupe on FILTER stage must only skip TERMINAL statuses**
    (`pass|fail|success|completed|complete|closed|done|closed complete`), or new "Open"
    tickets get skipped forever.
12. **Prepare Revoke Requests must dedupe on a logical request key**
    (`acct | reqType | role | reqId | region`) or you emit N copies per run. We saw 12x
    duplicates after 12 runs before this landed.
13. **`BS Check User` (and any "user still present?" check): blank/mismatched `GetText`
    result means the account is NOT there = already revoked = success.** The original code
    treated blank as "still there" and routed everything to Ops. Sibling
    `BS Check User And Role` has the correct pattern.
14. **`Upload Evidence Files` must take an explicit `FilePath` input.** Do not glob the
    attachment folder - you will pick up unrelated files.
15. **Never use bare `catch (Exception) {}`.** Log with `TestLog()` at minimum. This is how we
    lost 5 rounds of debugging on Build Evidence Doc.
16. **[NEW] Python `{}` format slots in `[XPATHS]` are not C# format slots.** Keys like
    `(//table[@id="roles"]//tr/td[2])[{}]/...` or `...[@record_class="u_recertification"][{}]/td[10]`
    are filled with `.format(i)` in Python. In C#, `string.Format(x, i)` with `{}` throws
    `FormatException`. Fill them with `x.Replace("{}", i.ToString())`. Run
    `python lib\ini_lint.py <bot>\config.ini` - it lists every `{}`, `%%`, continuation line
    and duplicate key the C# reader must handle.
17. **[NEW] Frame context resets on refresh and navigation.** Python's per-region loop
    (switch tab -> refresh -> into frame -> into iframe) only works because each step starts
    from the top. In raw WebDriver, after `refresh`/`navigate` you are at the top document;
    switch to top (`{"id":null}`), then down the frame path, every time. Symptom: the first
    region works, the second fails with "no such element".
18. **[NEW] Re-find elements after any click that reloads a frame.** Clicking a region link
    (e.g. `User Admin`) reloads the `content` iframe; any element found before the click is
    stale. Never cache element ids across a reload.
19. **[NEW] Downloads need Edge prefs at session start.** Pass
    `"ms:edgeOptions": {"prefs": {"download.default_directory": "<per-RITM folder>",
    "download.prompt_for_download": false}}` in `StartSession`, or download directly: read the
    attachment link `href` (`sys_attachment.do?sys_id=...`), copy the session cookies
    (`GET /session/{id}/cookie`) onto an `HttpWebRequest`, and save the bytes. The direct
    route avoids folder polling and "first file in the folder" ambiguity.
20. **[NEW] A guard must check what it guards.** The "has work?" stage did not depend on
    whether Alice was actually open, so the bot proceeded with no application. Every
    precondition decision must read the real state it claims to check (page heading present,
    frame reachable), not a flag set earlier.

## 5. Test-mode seam (already shipped - keep it)

The Browser object global code contains a `TestMode()` helper. When `config.ini`
`[SETTINGS] test_mode = True`, the following short-circuit:

- `WdSend()` returns canned JSON from `TestReply()` instead of hitting HTTP
- `GetText()` returns `TestTextFor()` (looks up `test_text_<xpath_key>` in config)
- `IsEnabled()` returns true
- `ExecJs()` / `ExecJsEl()` return `""` or `test_js_text`
- `DoubleClickRetry` short-circuits
- Every subsheet that navigates or scrapes has an explicit `if (TestMode())` early-out that
  logs and returns canned data

**When porting a new bot: mirror this pattern.** Every new subsheet that talks to a browser
MUST have a test-mode branch, or the whole test-mode run collapses the first time the new
subsheet is entered. See `Open Snow Url`, `Open Alice Url`, `BS Maker Task Function`,
`Scrape Open RITMs` for the shape.

Seeds used by test mode:
- `test_ritm_file` - RITM feed for scraping
- `test_attachment_file` - a real .xlsx to copy into the attachment folder
- `test_maker_task_id` - canned TASK id
- `test_log_file` - single-file log for the whole run

**[NEW] Test mode is not enough.** It proves wiring, not behaviour against real pages. Before
any live run: (a) the flight recorder is in the Browser object (`WdSend` trace + frame
breadcrumb + `DumpOnFailure` html/png), and (b) run once with `run_mode = dryrun` - real
navigation and reads, every mutating click skipped and logged as `WOULD ...`. See the
skill's `reference/runtime-conventions.md`.

## 6. Handover of dev-hardcoded paths (must be repointed for prod)

Two places carry local dev paths that MUST be flipped to prod UNC before ship:

**A. Process XML data items** (per process):
`ConfigPath`, `TrackerPath`, `MakerTrackerPath`, `CheckerTrackerPath`, `StatusFile`,
`ScreenshotFolder`, `EvidencePath`, `TemplatePath`, `AttachmentFolder`, `NarIdMapPath`. All
currently under `<WORK_ROOT>\minim\`.

**B. Config .ini `[PATHS]` and `[SETTINGS]`**:
`attachment_folder_path`, `screenshot_folder_path`, `Attchment` (sic - typo kept for
compatibility), `driver_location`, plus **flip `test_mode = True` to `False`** in every ini.

The `<PROD_SHARE>\...` values already in the INIs are the real prod paths - they were
untouched.

## 7. Deferred / cut items (documented; not blockers)

- Edge / msedgedriver version pairing is out of scope on the dev box (no download rights).
  The bot uses raw WebDriver HTTP.
- **Sensitivity labelling.** Labelling happens INSIDE the `Build Evidence Doc` code stage, in
  `ApplyAipLabel()` - there is no separate action to call. It tries three routes in order
  until one succeeds:
  1. **Word COM** `Document.SensitivityLabel.SetLabel(...)` - PREFERRED. Uses the MIP runtime
     that ships with Office (`msipc.dll`, already present on this dev box). No extra client
     install, no retired module. Requires Word installed AND the runtime account signed into
     Office at least once so Word has cached the tenant label policy. **[NEW]** `SetLabel`
     takes a `LabelInfo` created with `doc.SensitivityLabel.CreateLabelInfo()`; set
     `LabelId`, `AssignmentMethod` and **`SiteId` (the Azure tenant GUID)** - a missing
     `SiteId` is the usual reason this route fails.
  2. PowerShell `Set-AIPFileLabel` - legacy AIP client, retired 2024-03-31. **[NEW]** This is
     what the Python Checker used successfully; if the RPA VM still has the client, this
     route is the proven one.
  3. PowerShell `Set-Label` - Purview Information Protection module.

  All COM is late-bound via reflection, so **no extra DLL references** are needed (no
  `Microsoft.Office.Interop.Word`, no `Microsoft.CSharp`/`dynamic`).

  The label GUID `<LABEL_ID>` ("internal use only") is the ONLY
  label used anywhere in the Python estate, and is already present as `LabelID=` in
  `Master_Maker` / `Master_Checker` `config.ini`. Feed it in as the `LabelId` input - do NOT
  hardcode it the way the Python Checkers did.

  `RequireLabel = False` (dev): a labelling failure is recorded in `LabelError` and flagged
  as a WARNING in `BuildError`, but the build still succeeds. `RequireLabel = True` (prod):
  an unlabelled document is not acceptable evidence and `Built` comes back `False`.

  **The label IS mandatory in prod** (confirmed). Do **not** attempt to forge the label by
  writing `MSIP_Label_*` properties into `docProps/custom.xml` - it looks right in Word but
  fails signature verification, and Purview will re-label or quarantine the file.
- Outlook COM automation in `Send Outlook Template Email` needs desktop Outlook on the
  runtime machine.
- xpath assertions in test mode are canned. A UAT run against real SNOW / Alice / BlueSpace
  instances is required before signoff.

---

## Prompt

> You are a senior automation engineer. Port the **{BOT_NAME}** GK Revoke Python bot to Blue
> Prism as importable XML, using the shipped Alice-Global and BlueSpace pair in
> `<WORK_ROOT>\minim\` as your reference shape.
>
> **Before writing anything, read sections 0-7 above.** They list every trap we hit shipping
> the first two bots. Failing to internalise them will cost you the same days it cost us.
>
> **Inputs you have**
>
> - Maker script: `scripts\scripts\{MAKER_PY}` (e.g. `UWQ_Maker_Task_V2.0.py`).
> - Checker script: `scripts\scripts\{CHECKER_PY}`.
> - Maker config: `scripts\config\{FOLDER}\Maker_Task\config.ini`.
> - Checker config: `scripts\config\{FOLDER}\Checker_Task\config.ini`.
> - Shipped bots in `minim\` as reference for shape, naming, wrapping, and test-mode seams.
>
> **What you must deliver**
>
> 1. Two new process XMLs, written by hand-editing (not by re-running the stale Python
>    builders) into `minim\`:
>    - `BPA Process - GK Revoke - {BOT_NAME} Maker.xml`
>    - `BPA Process - GK Revoke - {BOT_NAME} Checker.xml`
> 2. Two new per-bot config files (byte-faithful copies of the source `config.ini` files) in
>    `minim\config\`:
>    - `GK Revoke - {BOT_NAME} Maker.ini`
>    - `GK Revoke - {BOT_NAME} Checker.ini`
>    Preserve `%%`-escaped percents in `snow_url`, `{}` row-index placeholders, both `#` and
>    `;` comment styles, and any quirks (e.g. BlueSpace Maker put `driver_location` under
>    `[URLS]`).
> 3. If the bot needs new xpaths / URL keys that are not already in the Browser object's
>    `[XPATHS]` handling, add them to the per-bot config, NOT by hardcoding into the process
>    XML. Every locator MUST come from `X("...")`. Every URL from `GetSetting("...")`.
> 4. Wire the new process into `Master Populate Queue` if the bot contributes RITMs to the
>    shared queue (verify against the Python `main()` and the Master INIs).
> 5. Add a section to any deployment README you find in `minim\` (or create a short one)
>    covering: portal URL, config filename, Python -> BP page map, and any quirks (iframe
>    scoping, weird XPath row indexes, etc.).
> 6. **Do NOT** create a new Browser object, a new WebDriver library, add any new DLL
>    references, or introduce Selenium. Reuse `GK Revoke Browser - Generic` and
>    `IDAM Common - Generic` as-is. If the bot needs a locator that isn't in the current
>    Browser object's action set, add a new subsheet to the Browser object using the same
>    DLL-free primitives.
>
> **Method - follow this order**
>
> 1. **Read the two Python scripts end-to-end.** List the real high-level steps (`setConfig`,
>    `launchBrowser`, `loginPortal`, `snowGetTask`, `doTheRevocation`, `snowUpdateTask`,
>    `emailOnError`, `closeBrowser`, etc.). Map each to Browser / IDAM Common actions and/or
>    process code stages. Preserve the exact order, guard conditions, and recovery paths.
>    Count Selenium operations (`find_element` / `click` / `send_keys` / `clear` /
>    `switch_to.frame` / `switch_to.window` / `execute_script` / `ActionChains`) to know
>    whether the current Browser action set covers them.
> 2. **Read the two config.ini files verbatim** with PowerShell (they are OUTSIDE the AI
>    workspace). Copy them byte-faithfully. Do NOT normalise, reorder, "fix" key-name drift,
>    or drop commented keys. **[NEW]** Run `ini_lint.py` on both and handle every finding in
>    the reader (or note why it does not apply).
> 3. **Build the two processes by copying an Alice or BlueSpace process XML, then
>    hand-editing.** Rename the process. Replace the subsheet list with the mapped steps.
>    Repoint every xpath / URL key to the ones actually in this bot's config (they drift:
>    `snow_` vs `SN_`, `alice_` vs `BS_` vs bot-specific, `user_id` vs `username`).
> 4. **For every new subsheet you add to the Browser object, add a `TestMode()` early-out.**
>    No exceptions. See section 5.
> 5. **Repoint every path.** All the same data items as in the Alice / BlueSpace processes
>    (section 6.A) MUST be present and MUST default to the dev paths under
>    `<WORK_ROOT>\minim\` for test runs - prod repointing is done at deployment.
> 6. **Wire tracker updates correctly**: Maker passes `"Maker Task Status"`, Checker passes
>    `"Checker Task Status"` to Update RITM Tracker. Both pass `TrackerPath`.
> 7. **Run the process in test mode end-to-end.** Use the same `_reset*.ps1` / `_all.ps1` audit
>    pattern used for Alice/BlueSpace (grep for `_audit`, `_reset`, `_stub` scripts in
>    `try\`). Every audit must be clean; every stub call must be legitimate (only `Clean Up`
>    is allowed as a Start->End no-op).
> 8. **Prove no Selenium regression.** After the run, grep the new XML for executable
>    Selenium tokens (`OpenQA`, `IWebElement`, `By\.XPath`, `WebDriver\.dll`) - count must be
>    `0`. The word "Selenium" may appear only in prose comments describing the Python source.
> 9. **[NEW] Run the gates**: `validate.py <minim> --flow` and
>    `compile_check.py <minim> --ref-dir "<Blue Prism install dir>"` - both must be clean.
> 10. **[NEW] Dry run before live**: one run with `run_mode = dryrun` against real
>     SNOW/app on a test ticket; attach the flight-recorder trace to your report.
>
> **Definition of done**
>
> - Both processes run end-to-end in test mode with zero unhandled exceptions and zero rows
>   routed to Ops (unless the seed actually calls for it).
> - Tracker updates land (verify with a direct OOXML read - do NOT trust the ACE OLEDB
>   `UPDATE` row count).
> - `minim\` contains the two new process XMLs plus the two new ini files.
> - Zero executable Selenium tokens in any XML. Zero new DLL references. Zero hardcoded
>   XPaths / URLs in the new process XML.
> - **[NEW]** `validate.py` ALL CLEAN and `compile_check.py` ALL COMPILED on `minim\`.
> - Report back: files created, line counts, audit output, and any Python-side quirks you
>   had to work around (call them out - do not hide them).

---

## Fill-in table (one row per candidate bot)

| Placeholder | Bot 1 | Bot 2 | Bot 3 | Bot 4 | Bot 5 | Bot 6 | Bot 7 | Bot 8 |
|---|---|---|---|---|---|---|---|---|
| `{BOT_NAME}` | <BOT_1> | <BOT_2> | <BOT_3> | <BOT_4> | <BOT_5> | <BOT_6> | <BOT_7> | <BOT_8> |
| `{FOLDER}` (under `scripts\config\`) | <FOLDER_1> | ... | | | | | | |
| `{MAKER_PY}` | <MAKER_PY_1> | ... | | | | | | |
| `{CHECKER_PY}` | <CHECKER_PY_1> | ... | | | | | | |
| `{bot}` (lowercase, builder filenames) | <bot_1> | ... | | | | | | |

Fill the table from `Master_Maker\config.ini` / `Master_Checker\config.ini`.
Verify against the folder before starting - a few Python filenames had typos (`Cheker` for
`Checker`) that are load-bearing. (Values live in those two INIs; the table is a convenience copy.)

---

## Runtime prerequisites (client environment, unchanged from Alice/BlueSpace)

- `msedgedriver.exe` on the RPA VM at the path in each bot's `driver_location` (default
  `C:\Users\{}\dev\msedgedriver.exe`, `{}` = Windows username), version-matched to the
  installed Edge build, running on a localhost port BEFORE the process calls `Set Driver`.
- `Newtonsoft.Json.dll` (ships with Blue Prism - no action needed).
- Blue Prism Credential Manager entries for portal + ServiceNow accounts (prefer over the
  plaintext `user_id` / `pass` keys the Python configs use).
- The per-bot ini deployed next to the process (or path fed via a session variable), and the
  file-share paths in `[ELEMENTS]` reachable from the RPA VM.
- Desktop Outlook installed (for `Send Outlook Template Email`).
- A working sensitivity-labelling route for evidence docs (see section 7). Preferred:
  **Word installed + the RPA service account signed into Office once**, so
  `Document.SensitivityLabel.SetLabel` can use the Office MIP runtime (`msipc.dll`).
  Alternatives are the retired AIP client (`Set-AIPFileLabel`) or the Purview Information
  Protection module (`Set-Label`). Note: Word COM is single-instance per user session - no
  other session may be driving Word when the bot runs, same rule as Outlook COM.
- `test_mode` flipped to `False` in every ini before prod cutover.
- `RequireLabel` flipped to `True` on `Build Evidence Doc` before prod cutover.
