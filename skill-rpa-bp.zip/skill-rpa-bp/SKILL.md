# Skill: Blue Prism object/process generator

Generate **importable Blue Prism XML** (business objects and orchestration processes)
programmatically, with schema-verified stages, correct flow wiring, and C# that has
already been compiled once before it reaches Blue Prism.

Before designing or generating anything, read
[reference/estate-conventions.md](reference/estate-conventions.md) and, for objects,
[reference/object-conventions.md](reference/object-conventions.md). Its `MUST` rules are the
default for this estate. A named project's existing XML and runtime contract may override
them; document every override instead of silently mixing architectures.

**Porting a Python bot?** This skill is the engine (how to write correct BP XML). If your
project has a Dev Prompt, it is the procedure -- read it first.
`DEV_PROMPT_port_gk_revoke_bot.md` next to this file is ONLY for the GK Revoke bots; skip it
for anything else and follow the Workflow below.

**Calling standard plumbing** (work queues, environment/session variables, stop requests,
exception details): use only what [reference/estate-objects.md](reference/estate-objects.md)
lists. Never invent an object or action name.

## When to use this skill
- Port an existing script, bot, macro, or utility into Blue Prism.
- Produce many similar objects/processes from a template or data.
- Build estate-native UI objects: Write/Read/Navigate/Wait stages wired to Application
  Modeller elements BY NAME. New object: the generator writes the model with empty element
  slots and you spy them after import (option B). Existing object: `use_model()` reads its
  spied model from the export (option A). Spying itself always happens in Blue Prism.
- Build no-spying/code-driven UI objects only when a named existing project explicitly
  requires that architecture.
- Generate XML that must be correct-by-construction and validated.

Do not use this skill for general Blue Prism Studio usage questions.

## Choose the architecture profile first

### Estate-native (default)
Use Application Modeller for UI interaction, Environment Variables for configuration,
Credential Manager for secrets, an unpublished `Attach` helper, named Wait timeouts, one
public action per object page, and the standard process control framework on Main. Follow
every applicable `MUST` in [reference/estate-conventions.md](reference/estate-conventions.md).

### Project-compatible exception
Use a different architecture only when the user identifies existing XML as the source of
truth or supplies a runtime contract that requires it. For example, GK Revoke uses raw W3C
WebDriver HTTP, per-bot INI files, no Application Modeller, and shared code in the
ProcessInfo/Code Options stage. Preserve those choices for that project; do not promote
them to defaults for unrelated estate work. See [reference/config-contract.md](reference/config-contract.md).

Record the selected profile and exceptions before generating files.

## Mental model
1. A **file** is a `Proc` with `type="object"` (reusable capability, all pages are
   subsheets) or `type="process"` (orchestration, first page is main).
2. A **page** (`Proc.page(...)`) holds an ordered list of **steps**.
3. **Steps** are: `action` (call a VBO), `code` (.NET), `decision`, `choice` (3+ known
   alternatives), `loop_start`/`loop_end` (ForEach), `page_ref` (call another page of a
   process), `calc`/`multi_calc`, `exception`, plus `data`, `note`, `recover_action`
   (page-level error handler) and `work_block` (a named Block with its OWN Recover = the
   estate's recovery-scope pattern). Happy-path flow is the list order; jumps use stage
   **names**.
4. **Layout is automatic** and follows the estate's recommended standard: one main
   direction (top to bottom), happy path straight down the main column, long jumps and
   back-edges routed through **named** anchors in lanes to the right (short spans inside,
   lanes reused when spans don't overlap), recovery in lanes to the left, data items sorted
   inside `Input Variables` / `Output Variables` / `Local Variables` (`Global Variables` on
   process Main) Blocks, notes on the far right. Coordinates were measured on a real
   release: stage x,y = centre, Block x,y = top-left (Block membership = recovery scope).
5. `write()` renders correct `<process>` XML; `validate.py` proves the structure;
   `compile_check.py` proves the code; `preview.py` draws each page as SVG so the layout can
   be reviewed in a browser before import.

Multi-page processes and objects are supported. A process calls a subsheet with
`page_ref(...)`; the validator flags a process page that is never called. See
[reference/flow-conventions.md](reference/flow-conventions.md#7-orchestration-vs-object).

## Workflow
1. **Select the profile.** Read the target project's XML/source of truth and state
   `estate-native` or `project-compatible exception`, with the reasons.
2. **Model the source.** List the real steps. Decide object(s) vs process. Keep reusable
   application operations in objects. Put declarations, configuration, queue/claim
   control, stop controls, top-level recovery, reporting, and page dispatch on process
   Main; put application interaction on named pages or in objects.
3. **Pick constructs** using [reference/flow-conventions.md](reference/flow-conventions.md):
   linear steps, decisions for guards/branches, ForEach for real collections, a
   decision+back-edge for while/claim loops, Recover for error handling.
4. **Apply the estate checklist** in [reference/estate-conventions.md](reference/estate-conventions.md),
   recording any project-specific overrides.
5. **Build** with `lib/bp_gen.py` (see [examples/minimal_process.py](examples/minimal_process.py)).
   The generator is STRICT: a goto/decision target that names no stage stops the build.
6. **Validate** with `python lib/validate.py <outdir> --flow --estate --strict`; use `--flow
   --strict` without `--estate` only for a recorded project-compatible exception. Fix until
   `ALL CLEAN`. `--strict` is the estate review checklist made mechanical (unique names,
   no generic/numbered names, no unreachable stages or dead ends, no unused data items,
   explicit initial values, no leftover breakpoints, Choice/Wait pairing, exception types,
   boolean hygiene). On legacy exports it lists the debt; on generated XML it must be clean.
7. **Compile** with `python lib/compile_check.py <outdir> --ref-dir "<Blue Prism install dir>"`.
   C# and VB.NET (the object's own `<language>`; 5/8 estate objects are VB). Fix until
   `ALL COMPILED`. The printed compiler line must say `(Blue Prism's own compiler)` for the
   result to count. On a machine without Blue Prism (a dev box), a pass is only indicative --
   say so in the handover and rerun on the Blue Prism machine before import. Run `python lib/compile_check.py --self-test` once per machine
   first; if it does not print `SELF-TEST PASS`, the gate is blind -- do not trust it.
8. **Eyeball the resolved link report** (`--flow`, follows anchors to the real target):
   confirm each decision/goto/loop points where you intend; links marked `*(End)` are the
   usual sign of a mistyped target. Then `python lib/preview.py <file.xml>` and look at the
   pages.
9. **Review runtime safety**: bounded retries/locks/polling, recovery exits, lock release on
   every path, queue dedupe/key, Credential Manager use, Control Room stop/limit handling,
   and the runtime conventions in [reference/runtime-conventions.md](reference/runtime-conventions.md)
   (test-mode seam, failure dump, dry-run).
10. **Import into Blue Prism.** With step 7 green, a compile-fix pass after import should be
    rare; if one is still needed, record what the gate missed in
    [reference/gotchas.md](reference/gotchas.md).

## Files in this skill
| Path | Purpose |
|---|---|
| [reference/estate-conventions.md](reference/estate-conventions.md) | Mandatory estate defaults and override precedence. |
| [reference/estate-objects.md](reference/estate-objects.md) | Work Queues signatures, Environment/Session variables, IsStopRequested(), exception functions, stubbing objects you do not have. |
| [reference/object-conventions.md](reference/object-conventions.md) | MEASURED object rules (X of 8 counts), anti-patterns, object review checklist. Wins over estate-conventions for objects. |
| [reference/runtime-conventions.md](reference/runtime-conventions.md) | Test-mode seam, failure dump, dry-run mode -- what makes a BP bot debuggable. |
| [lib/bp_gen.py](lib/bp_gen.py) | Generator API (`Proc` / `Page`). |
| [lib/validate.py](lib/validate.py) | Structural, flow, data-item, cross-object, `--estate` and `--strict` validator. |
| [lib/preview.py](lib/preview.py) | Draws each page as SVG (real coordinates) for layout review in a browser. |
| [lib/compile_check.py](lib/compile_check.py) | Compiles every C#/VB code stage + shared code before import (calibrated on official BP VBOs). |
| [lib/ini_lint.py](lib/ini_lint.py) | Lists Python-ConfigParser features a C# INI reader must handle. |
| [reference/stage-schemas.md](reference/stage-schemas.md) | Verified XML stage shapes. |
| [reference/flow-conventions.md](reference/flow-conventions.md) | Decisions, loops, back-edges, recovery, and page calls. |
| [reference/config-contract.md](reference/config-contract.md) | Explicit no-spying/INI project exception. |
| [reference/gotchas.md](reference/gotchas.md) | Encoding, Code Options, DLL, and validator pitfalls. |
| [examples/minimal_process.py](examples/minimal_process.py) | Minimal object example. |
| [examples/minimal_orchestration.py](examples/minimal_orchestration.py) | THE process recipe: Reset Global Data, Continue To Work (IsStopRequested, session/env variables), claim loop on Work Queues, business vs system exceptions decided in recovery mode, consecutive-failure guard, Choice, ForEach, bounded retry. Copy it, then change the work. |
| [examples/minimal_ui_object.py](examples/minimal_ui_object.py) | UI object: Application Modeller slots + Wait/Write/Navigate/Read wired by element name, spy after import. |
| [selftest.py](selftest.py) | Proves every file arrived intact (per-file hashes) and every tool still behaves as tested (golden outputs). Run first after any copy. |

## Quick start
```python
import sys, os
sys.path.insert(0, 'lib')
from bp_gen import Proc, lit

p = Proc('My Object', 'object', 'What this object does.')
p.code_options()                                   # only if you use code() stages
p.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
m = p.page('Get Status', 'Read and return the current status.')
m.add_input('text', 'URL')
m.data('Loaded', 'flag')
m.action('Navigate', 'MS Edge Browser', 'Navigate', inputs=[('text', 'URL', '[URL]')])
m.decision('Loaded?', '[Loaded]', true_target='NEXT', false_target='END')
m.code('Read Status', 'Loaded = true;', outputs=[('flag', 'Loaded', 'Loaded')])
m.recover_action('Log', 'Utility - General', 'Nothing',
                 inputs=[('text', 'Message', lit('Get Status failed'))])
p.write('BPA Object - My Object.xml', outdir='out')
```
```
python lib/validate.py out --flow --estate
python lib/compile_check.py out
```

## Golden rules (do not skip)
- Read `estate-conventions.md`, select an architecture profile, and record every
  project-specific override before generating XML.
- Write UTF-8 with `newline='\n'`; keep narratives ASCII-safe (the generator refuses
  non-ASCII). Never round-trip generated XML through PowerShell `Set-Content` or `Out-File`.
- Give every object a first `Clean Up` page typed `CleanUp`, keep object Main free of
  action logic, and put each public action on its own page.
- Keep processes orchestration-focused, not empty: Main owns the standard control
  framework; objects and named pages own reusable application work.
- Wrap each recoverable unit of work in `work_block(name, first, last, handler, then, capture)`:
  Recover inside the Block; capture + handler + rethrow run in RECOVERY MODE (before Resume),
  because ExceptionType()/Detail()/Stage() and "preserve current exception" stop working at
  Resume. To decide on the failure afterwards (business vs system, retry), capture it.
- Use `choice()` for 3+ known alternatives instead of a chain of decisions.
- Model while/claim loops as a Decision plus backward edge, not ForEach. Both
  handled-success and handled-failure paths return to the claim stage; only the
  Decision's no-work branch exits.
- Name Decisions as questions ending in `?`. Use exact `System Exception` and
  `Business Exception` types. Preserve the current exception when rethrowing.
- Bound retries, polling, lock acquisition, and scrolling. Never emit an unbounded loop.
- Use Environment Variables and Credential Manager by default. Use INI-based selectors and
  URLs only under an explicit no-spying project contract; externally configure the INI path.
- Keep root `<globalcode>` empty. Put shared project code in the proven ProcessInfo/Code
  Options `<code>` shape only when required by the reference project.
- Run `validate.py <dir> --flow --estate` for estate-native work and inspect the
  resolved-link report before import. Omit `--estate` only for a recorded
  project-compatible exception.
- Run `compile_check.py` on anything with code stages. "Imports cleanly" is not "compiles".
- Never name two stages on a page the same, never use `Stage1`/`Anchor2`/`Try++`-style names:
  the generator refuses them, `--strict` reports them in hand-edited XML.
- Text literals in `expr=` must be quoted (`lit()`); outputs auto-create their Data stage,
  so declaring `data()` for an output is optional.
