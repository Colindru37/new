# What changed vs the version on the work laptop (2026-10-06)

Rebuilt from photos, then improved. Everything below was run here: examples build,
validate ALL CLEAN, compile ALL COMPILED, self-test PASS, and each new check was
proven by a deliberately broken input (negative control).

## New files
- lib/compile_check.py  -- compiles every C# code stage + shared code BEFORE import
  (Windows: built-in csc.exe, no install). Errors name object/page/stage + line.
  `--self-test` = positive control. THE big one: kills "null-ref with no clue".
- lib/ini_lint.py       -- lists every Python-ConfigParser feature in an INI that a
  C# reader must handle: {} format slots, %%, continuation lines, ":" separators,
  case-duplicate keys, exact-space text() XPaths.
- reference/runtime-conventions.md -- test / dryrun / live modes, flight recorder,
  failure dump, re-find after reload, positive control for every gate.

## bp_gen.py
- STRICT flow targets: unknown goto/decision name raises FlowError (was: warn + End).
- Refuses non-ASCII names/narratives, 'BPA Object - ' internal names, unknown
  datatypes, code() without code_options(), unbalanced loop_start/loop_end.
- New (UNVERIFIED, import once to confirm): calc(), multi_calc(), exception().

## validate.py (new checks)
- <globalcode>/<code>/<references>/<imports> at <process> root; any <namespaces>.
- 'BPA Object -' prefix in internal name; duplicate stageids.
- output stage="X" with no data item on the page (gotcha #6 half).
- Data stage with datatype collection; ForEach loopdata not a Collection;
  LoopStart/LoopEnd groupid 1:1 pairing.
- Cross-object: called object in same dir -> action must exist, be published, and
  every input name must be a Start input (exact match).
- string.Format with Python '{}' slot in code bodies.
- WARN: [refs] with no data item, non-ASCII names.

## Docs
- SKILL.md workflow: compile step + self-test; points to the Dev Prompt for porting.
- gotchas.md: Selenium DLL line scoped to non-GK projects (was a contradiction).
- config-contract.md: Python-INI traps section.
- DEV_PROMPT: traps 16-20 + gates + dryrun + label SiteId/AIP notes, marked [NEW].

## Round 2 (object conventions report, 2026-10-06 late)
- NEW reference/object-conventions.md: measured object rules with counts, anti-patterns,
  object review checklist.
- estate-conventions.md: 5 rules corrected by the counts -- anchors get purpose names;
  App Modeller naming = follow siblings; wait timeout = match object (new: data item);
  failure contract = match siblings (both flags and throws are established); code
  language = object's own (5/8 VB, 3/8 C#; new object: C#).
- stage-schemas.md: verified 7.x shapes for Calculation, MultipleCalculation, Exception,
  Block, Anchor, ChoiceStart/End, WaitStart/End, Navigate, Read, Write, App Modeller element.
- bp_gen.py: Exception stage uses the verified shape; objects default runmode Exclusive
  (7/8), runmode validated.

## Round 3 (2026-10-07): strict checks + VB compile
- validate.py --strict: duplicate stage names per page (End/Note exempt), generic/numbered/++
  names, unreachable stages (walk from Start/Recover, implicit Loop/Choice/Wait End entry,
  Notes in flow), dead ends, unused data items, flags/numbers without initial value,
  leftover breakpoints, Choice/Wait groupid pairing, empty exception types, flag=True
  comparisons, AND/OR without parentheses. Page/stage name-collision check now
  processes-only (objects name code stages after their page -- official VBOs do).
  Calibrated on the real 6.x training release: 3 unreachable findings, each verified dead.
- bp_gen.py: refuses duplicate/reserved stage names, stage-vs-data name clashes, generic
  names (Stage1, Anchor2, Try++); flags default False, numbers default 0.
- compile_check.py: VB.NET support (vbc.exe on Windows, Roslyn vbc on mono); methods named
  after stages; keyword-safe identifiers; import dedupe; case-insensitive refs. Self-test
  runs both languages. Official VBOs: 6/6 objects, 118 VB stages compile; an injected error
  in MS Excel VBO is caught and named.

## Round 4 (2026-10-07): layout, choice, work blocks, preview, selftest
- bp_gen.py: automatic layout -- main path straight down; long jumps/back-edges via NAMED
  anchors in right-hand lanes (shortest spans innermost, lanes reused when spans don't
  overlap); data items sorted in Input/Output/Local (Global on process Main) Variables
  Blocks; recovery lanes left; notes far right. Coordinates measured on a real release
  (stage = centre, Block = top-left; Block membership = recovery scope).
- bp_gen.py: choice() (ChoiceStart/ChoiceEnd), work_block() (named Block with its own
  Recover inside, Resume + handler outside, then RETHROW/END/stage).
- validate.py: --flow follows anchors to the real target; no backslash line continuations
  (a trailing space after one is a syntax error after a retype).
- NEW lib/preview.py: pages as SVG at real coordinates, for review in a browser.
- NEW selftest.py (generated): per-file hashes with 25-line block localisation, 12 golden
  outputs, positive control, C#/VB compile gate. Tolerates CRLF/trailing spaces; a
  one-character code change fails and points at its block.
- prompts/flight_recorder.md moved into the skill (one transfer).
- Checked: no Python 3.12+ syntax (tokenizer check, positive-controlled).

## Round 5 (2026-10-07): weaker-model eval (Sonnet, two rounds)
- Round 1 found a REAL generator bug: work_block put Resume before the handler/rethrow, so
  exception details were unreadable and RETHROW ran outside recovery mode. Fixed: Recover ->
  capture -> handler -> rethrow (no Resume) | Resume -> then. New capture=. --strict now fails
  ExceptionType()/Detail()/Stage() or rethrow outside recovery mode.
- data(exposure='Environment'|'Session') (verified shapes); NEW reference/estate-objects.md
  (Work Queues signatures, no "Has Work" output, IsStopRequested(), stubs via --with).
- validate: page-call inputs checked against the called page's Start; --with DIR for stubs.
- examples/minimal_orchestration.py rewritten as the full estate process recipe.
- compile_check: warns on non-BP compilers and on a missing --ref-dir.
- calc(), multi_calc(), exception(): all VERIFIED (7.x shapes from the estate report), the
  "UNVERIFIED" note in Round 1 is obsolete.
- Round 2 (fixed skill): gates green on the first build, retry/exception logic correct.

## Round 6 (2026-10-07): UI stages + Application Modeller
- bp_gen: write/read/navigate/wait_for/wait, elements by name; application()+element()
  (option B: empty slots, spy after import) or use_model(export) (option A: spied model).
  All stage shapes compared tag-by-tag with the real training release: identical.
- validate: element ids must exist in the object's model; "NOT SPIED yet" checklist.
- NEW examples/minimal_ui_object.py. OPEN: Blue Prism importing an element with empty
  <attributes /> is unverified (no real export contains one) -- import test pending.
