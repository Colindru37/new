"""
preview.py -- draw Blue Prism pages as SVG, to review a generated layout without Blue Prism.

Stages are drawn at their real coordinates (stage x,y = centre; Block x,y = top-left,
measured on a real release), links as arrows, anchors as dots, Blocks as rectangles.
Open the .svg in Edge/any browser. Stdlib only.

Run:  python preview.py file.xml [outdir]        -> one <page>.svg per page
"""
import os, re, sys
import xml.etree.ElementTree as ET
from html import escape

FILL = {'Start': '#c8e6c9', 'End': '#c8e6c9', 'Decision': '#fff59d', 'ChoiceStart': '#fff59d',
        'ChoiceEnd': '#fff59d', 'Action': '#bbdefb', 'SubSheet': '#d1c4e9', 'Code': '#ffe0b2',
        'Calculation': '#e1f5fe', 'MultipleCalculation': '#e1f5fe', 'Exception': '#ffcdd2',
        'Recover': '#ffcdd2', 'Resume': '#ffcdd2', 'LoopStart': '#f0f4c3', 'LoopEnd': '#f0f4c3',
        'Data': '#eeeeee', 'Collection': '#e0e0e0', 'Note': '#f1f8e9', 'WaitStart': '#fff59d',
        'WaitEnd': '#fff59d', 'Navigate': '#bbdefb', 'Read': '#bbdefb', 'Write': '#bbdefb'}


def geom(st):
    d = st.find('display')
    if d is not None:
        g = [d.get(k) for k in ('x', 'y', 'w', 'h')]
    else:   # 6.x export format
        g = [st.findtext(k) for k in ('displayx', 'displayy', 'displaywidth', 'displayheight')]
    x, y = float(g[0] or 0), float(g[1] or 0)
    w, h = float(g[2] or 60), float(g[3] or 30)
    return x, y, w, h


def render_page(stages, title):
    boxes, links, blocks = {}, [], []
    groups = {}          # groupid -> {'start': sid, 'end': sid, 'choices': [(name, distance, target)]}
    for st in stages:
        t = st.get('type')
        if t in ('SubSheetInfo', 'ProcessInfo'):
            continue
        x, y, w, h = geom(st)
        if t == 'Block':
            blocks.append((st.get('name'), x, y, w, h))
            continue
        if t == 'Anchor':
            w = h = 10
        boxes[st.get('stageid')] = (st.get('name'), t, x, y, w, h)
        if t in ('ChoiceStart', 'ChoiceEnd', 'WaitStart', 'WaitEnd'):
            # Blue Prism draws an implicit line Start -> End (same groupid) and puts each
            # choice on it at <distance>; a choice's ontrue leaves from that point.
            g = groups.setdefault((st.findtext('groupid') or '').strip(), {'choices': []})
            g['end' if t.endswith('End') else 'start'] = st.get('stageid')
            if t.endswith('Start'):
                for ch in st.iter('choice'):
                    tgt = (ch.findtext('ontrue') or '').strip()
                    g['choices'].append((ch.findtext('name') or '', float(ch.findtext('distance') or 0), tgt))
            if t.endswith('Start'):
                continue                 # its links are drawn from the choice points below
        for tag in ('onsuccess', 'ontrue', 'onfalse'):
            for el in st.iter(tag):
                if el.text:
                    links.append((st.get('stageid'), el.text.strip(), tag))
    if not boxes:
        return None
    xs = [b[2] - b[4] / 2 for b in boxes.values()] + [b[1] for b in blocks]
    xe = [b[2] + b[4] / 2 for b in boxes.values()] + [b[1] + b[3] for b in blocks]
    ys = [b[3] - b[5] / 2 for b in boxes.values()] + [b[2] for b in blocks]
    ye = [b[3] + b[5] / 2 for b in boxes.values()] + [b[2] + b[4] for b in blocks]
    pad = 40
    minx, miny = min(xs) - pad, min(ys) - pad - 20
    W, H = max(xe) - minx + pad, max(ye) - miny + pad
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{minx} {miny} {W} {H}" '
         f'width="{W}" height="{H}" font-family="Segoe UI, sans-serif" font-size="9">',
         '<defs><marker id="a" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" '
         'markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#555"/></marker></defs>',
         f'<rect x="{minx}" y="{miny}" width="{W}" height="{H}" fill="white"/>',
         f'<text x="{minx + 10}" y="{miny + 16}" font-size="13" font-weight="bold">{escape(title)}</text>']
    for name, x, y, w, h in blocks:
        o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#7FB2E5" fill-opacity="0.15" '
                 f'stroke="#7FB2E5"/><text x="{x + 4}" y="{y + 11}" fill="#3b6ea5">{escape(name)}</text>')
    choice_pts = []
    for g in groups.values():
        if 'start' not in g or 'end' not in g:
            continue
        _, _, sx, sy, _, _ = boxes[g['start']]
        _, _, ex, ey, _, _ = boxes[g['end']]
        o.append(f'<line x1="{sx}" y1="{sy}" x2="{ex}" y2="{ey}" stroke="#555" stroke-dasharray="3,2"/>')
        length = ((ex - sx) ** 2 + (ey - sy) ** 2) ** 0.5 or 1
        for name, dist, tgt in g['choices']:
            px, py = sx + (ex - sx) * dist / length, sy + (ey - sy) * dist / length
            choice_pts.append((name, px, py))
            boxes['pt:' + name + str(dist)] = (name, 'ChoicePoint', px, py, 0, 0)
            links.append(('pt:' + name + str(dist), tgt, 'ontrue'))
    for a, b, tag in links:
        if a not in boxes or b not in boxes:
            continue
        _, _, x1, y1, _, h1 = boxes[a]
        _, tb, x2, y2, _, h2 = boxes[b]
        colour = {'ontrue': '#2e7d32', 'onfalse': '#c62828'}.get(tag, '#555')
        # leave from bottom edge, arrive at top edge (anchors: centre)
        y1e = y1 + (h1 / 2 if boxes[a][1] != 'Anchor' else 0)
        y2e = y2 - (h2 / 2 if tb != 'Anchor' else 0)
        if y2e < y1e and x1 == x2:   # straight upward edge over the column: draw it offset
            o.append(f'<path d="M{x1},{y1e} C{x1 + 60},{y1e} {x2 + 60},{y2e} {x2},{y2e}" fill="none" '
                     f'stroke="{colour}" marker-end="url(#a)"/>')
        else:
            o.append(f'<line x1="{x1}" y1="{y1e}" x2="{x2}" y2="{y2e}" stroke="{colour}" '
                     f'marker-end="url(#a)"/>')
    for name, px, py in choice_pts:
        o.append(f'<circle cx="{px}" cy="{py}" r="5" fill="#fff59d" stroke="#666"/>'
                 f'<text x="{px}" y="{py - 8}" text-anchor="middle" fill="#555">{escape(name)}</text>')
    for sid, (name, t, x, y, w, h) in boxes.items():
        if t == 'ChoicePoint':
            continue
        if t == 'Anchor':
            o.append(f'<circle cx="{x}" cy="{y}" r="4" fill="#555"><title>{escape(name)}</title></circle>')
            continue
        fill = FILL.get(t, '#ffffff')
        shape = (f'<polygon points="{x},{y - h / 2} {x + w / 2},{y} {x},{y + h / 2} {x - w / 2},{y}" '
                 if t in ('Decision', 'ChoiceStart', 'WaitStart') else
                 f'<rect x="{x - w / 2}" y="{y - h / 2}" width="{w}" height="{h}" rx="{8 if t in ("Start", "End") else 2}" ')
        o.append(shape + f'fill="{fill}" stroke="#666"><title>{escape(t)}</title></' +
                 ('polygon>' if t in ('Decision', 'ChoiceStart', 'WaitStart') else 'rect>'))
        label = name if len(name) <= 26 else name[:24] + '..'
        o.append(f'<text x="{x}" y="{y + 3}" text-anchor="middle">{escape(label)}</text>')
    o.append('</svg>')
    return '\n'.join(o)


def preview(path, outdir='preview'):
    root = ET.parse(path).getroot()
    for el in root.iter():                       # strip a default xmlns (Blue Prism exports)
        if isinstance(el.tag, str) and '}' in el.tag:
            el.tag = el.tag.split('}', 1)[1]
    stages = list(root.iter('stage'))
    pages = {None: 'Main'}
    for st in stages:
        if st.get('type') == 'SubSheetInfo':
            pages[st.find('subsheetid').text] = st.get('name')
    os.makedirs(outdir, exist_ok=True)
    written = []
    for ssid, pname in pages.items():
        sts = [st for st in stages if ((st.find('subsheetid').text if st.find('subsheetid') is not None
                                        else None) == ssid)]
        svg = render_page(sts, f'{root.get("name")} / {pname}')
        if svg is None:
            continue
        fn = os.path.join(outdir, re.sub(r'[^A-Za-z0-9 _-]', '_', f'{root.get("name")} - {pname}') + '.svg')
        with open(fn, 'w', encoding='utf-8', newline='\n') as f:
            f.write(svg)
        written.append(fn)
    return written


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    for fn in preview(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 'preview'):
        print(fn)
