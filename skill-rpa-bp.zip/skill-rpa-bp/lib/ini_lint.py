"""
ini_lint.py -- flag the Python-ConfigParser features a C# INI reader must handle.

A bot's config.ini was written for Python's ConfigParser. A hand-rolled C# reader
usually gets the easy case right and silently mis-reads the rest. This lists every
place in the file where the easy case is NOT the only case, so you can check the
reader handles it (or fix the INI).

Run:  python ini_lint.py path\\to\\config.ini [more.ini ...]
Exit code 0 = nothing that needs special handling, 1 = review the listed lines.
"""
import sys, re


def lint(path):
    findings = []
    section, keys = None, {}
    prev_key = None
    with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
        lines = f.read().splitlines()
    for n, raw in enumerate(lines, 1):
        if not raw.strip():
            prev_key = None
            continue
        s = raw.strip()
        if s[0] in '#;':
            continue
        if raw[0] in ' \t' and prev_key:
            findings.append((n, 'CONTINUATION', f'indented line continues [{section}] {prev_key} '
                             f'(ConfigParser joins it with \\n; a line reader drops it)'))
            continue
        if s.startswith('[') and s.endswith(']'):
            section = s[1:-1]
            keys = {}
            prev_key = None
            continue
        m = re.match(r'^([^=:]+?)\s*([=:])\s*(.*)$', s)
        if not m:
            findings.append((n, 'UNPARSED', s[:80]))
            continue
        key, sep, val = m.group(1), m.group(2), m.group(3)
        prev_key = key
        low = key.lower()
        if low in keys:
            other = keys[low]
            kind = 'DUPLICATE' if other == key else 'CASE-DUP'
            findings.append((n, kind, f'[{section}] {key} also defined as {other!r}'))
        keys[low] = key
        if sep == ':':
            findings.append((n, 'COLON-SEP', f'[{section}] {key} uses ":" not "="'))
        if '{}' in val or re.search(r'\{\d*\}', val):
            findings.append((n, 'FORMAT-SLOT', f'[{section}] {key} has a .format slot: fill with '
                             f'.Replace("{{}}", ...), never string.Format'))
        if '%%' in val:
            findings.append((n, 'PERCENT', f'[{section}] {key} has %% (reader must turn it into %)'))
        elif re.search(r'%\(\w+\)s', val):
            findings.append((n, 'INTERPOLATION', f'[{section}] {key} uses %(name)s interpolation'))
        if val != val.strip() or (val[:1] in '"\'' and val[-1:] == val[:1]):
            findings.append((n, 'QUOTES/SPACE', f'[{section}] {key} value is quoted or padded; '
                             f'ConfigParser keeps quotes literally'))
        if re.search(r"text\(\)\s*=\s*['\"]\s|\s['\"]\]", val):
            findings.append((n, 'EXACT-SPACE', f'[{section}] {key} matches text with leading/trailing '
                             f'spaces; fragile if the page uses &nbsp;'))
    return findings


if __name__ == '__main__':
    bad = False
    for p in sys.argv[1:]:
        f = lint(p)
        print(f'{p}: {len(f)} finding(s)')
        for n, kind, msg in f:
            print(f'  line {n:4}  {kind:13} {msg}')
        bad = bad or bool(f)
    sys.exit(1 if bad else 0)
