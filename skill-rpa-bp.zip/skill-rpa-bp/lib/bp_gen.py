"""
bp_gen.py -- a small, verified generator for Blue Prism importable XML.

Produces a <process> root (works for both type="process" orchestrations and
type="object" business objects) whose stage XML has been schema-verified against
real Blue Prism 7.x release files. Emits Action, Code (.NET), Decision, ForEach
Loop, SubSheet (page call), Recover/Resume, Data, Collection, Note and Start/End
stages with correctly resolved flow links (onsuccess / ontrue / onfalse / loop
groupid).

Calculation, MultipleCalculation and Exception shapes were verified against
scrubbed 7.x estate exports (bp_object_conventions report, section 12).

Design rules baked in (do not "improve" these away):
  * ASCII-safe narrative text only -- no smart quotes / arrows -> avoids mojibake
    on import. Keep source and writes UTF-8; write with newline='\\n'.
  * Code-stage bodies are passed through verbatim inside CDATA (never escaped).
  * Every flow target is resolved to a real stageid at render time. Targets may
    be 'NEXT' (the following stage), 'END' (the page End), or the exact NAME of
    any other step -- which enables forward skips AND backward loop edges.
  * STRICT by default: a target name that matches no stage RAISES at build time.
    (The old behaviour -- warn and fall back to End -- produced valid-looking XML
    with a silently wrong flow. Pass strict=False to Proc only if you must.)

Usage sketch:
    from bp_gen import Proc, lit
    p = Proc('My Object', 'object', 'What this object does.')
    p.code_options()                       # only if you use code() stages
    p.page('Clean Up', 'Standard first object page.', page_type='CleanUp')
    pg = p.page('Get Status', 'Read and return the current status.')
    pg.add_input('text', 'URL')
    pg.action('Navigate', 'MS Edge Browser', 'Navigate', inputs=[('text', 'URL', '[URL]')])
    p.write('BPA Object - My Object.xml', outdir='out')
"""
import uuid, os, html

# Deterministic ids: same logical stage -> same GUID across rebuilds. This keeps
# diffs clean and lets Blue Prism treat re-imports as updates, not duplicates.
NS = uuid.UUID('12345678-1234-5678-1234-567812345678')


class FlowError(ValueError):
    """A goto/decision target names no stage on the page."""


def gid(*parts):
    return str(uuid.uuid5(NS, '|'.join(parts)))


def esc(t):
    return html.escape(str(t), quote=True)


def cdata(t):
    # Safe CDATA: split any accidental ']]>' so the block never closes early.
    return '<![CDATA[' + str(t).replace(']]>', ']]]]><![CDATA[>') + ']]>'


def lit(s):
    """Build a Blue Prism TEXT LITERAL for use inside an expr= expression.
    BP expressions quote strings with double quotes and escape an inner quote by
    doubling it, so lit('ab') -> the expr value "ab" (with the quotes), and any
    inner quote is doubled. Numbers/flags/dates are written bare (e.g. '5',
    'True', '[SomeItem]') and do NOT use lit().
    Example: inputs=[('text', 'Msg', lit('hello'))]."""
    return '"' + str(s).replace('"', '""') + '"'


def _ascii_check(where, text):
    bad = sorted({c for c in str(text) if ord(c) > 126})
    if bad:
        raise ValueError(f"{where}: non-ASCII characters {bad!r} -- use plain ASCII "
                         f"(e.g. '->' not an arrow glyph); they garble on import.")


FONT = '<font family="Segoe UI" size="10" style="Regular" color="000000" />'
FONT_TITLE = '<font family="Segoe UI" size="10" style="Bold" color="3366FF" />'
FONT_NOTE = '<font family="Segoe UI" size="10" style="Regular" color="008000" />'

DATATYPES = {'text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan',
             'password', 'collection', 'binary', 'image'}
EXCEPTION_TYPES = {'System Exception', 'Business Exception', 'Runtime Exception'}

# A minimal, generic .NET code environment. Override per project by passing your
# own references/imports to Proc.code_options(...).
DEFAULT_REFERENCES = [
    'System.dll', 'System.Data.dll', 'System.Xml.dll',
    'System.Drawing.dll', 'System.Core.dll',
]
DEFAULT_IMPORTS = [
    'System', 'System.Data', 'System.Linq',
    'System.Collections.Generic',
]


# Application Modeller action ids seen in REAL exports (official training release + the
# estate object report). Anything else is allowed but reported as unverified.
VERIFIED_ACTIONS = {
    'navigate': {'Press', 'SelectItem', 'ActivateApp', 'AttachApplication', 'DetachApplication',
                 'Launch', 'Terminate', 'SendKeyEvents'},
    'read': {'GetWindowText', 'GetWindowIdentifier', 'IsConnected'},
    'wait': {'CheckExists'},
}

# Explicit initial values (estate checklist: "flags and counters have explicit initial values").
DEFAULT_INIT = {'flag': 'False', 'number': '0'}

# Names the estate reports list as anti-patterns: Stage1, End1, Recover1, Anchor2, Code3, Try++ ...
import re as _re
GENERIC_NAME_RE = _re.compile(
    r'^(Stage|Action|Calc|Calculation|Multiple ?Calculation|Decision|Code|Anchor|Block|Recover|'
    r'Resume|End|Start|Loop ?Start|Loop ?End|Choice|Wait|Exception|Navigate|Read|Write|Data|'
    r'Collection|Process ?Info|SubSheet|Page)\d+$', _re.I)


def _check_name(where, name):
    if GENERIC_NAME_RE.match(name) or name.rstrip().endswith('++'):
        raise ValueError(f"{where}: generic name {name!r} is an estate anti-pattern; "
                         f"name the stage after what it does")


def _dt(dtype, where):
    if dtype not in DATATYPES:
        raise ValueError(f"{where}: unknown datatype {dtype!r}; use one of {sorted(DATATYPES)}")
    return dtype


class Page:
    """One subsheet (page). The first page of a type="process" becomes the
    implicit main page (no SubSheetInfo/subsheetid)."""

    def __init__(self, proc, name, narrative, page_type='Normal', published=None):
        _ascii_check(f'page {name!r}', name + narrative)
        self.proc = proc
        self.name = name
        self.narrative = narrative
        self.page_type = page_type
        self.published = (proc.ptype == 'object') if published is None else published
        self.ssid = gid(proc.name, 'subsheet', name)
        self.inputs = []
        self.outputs = []
        self.extra_data = []      # (name, dtype, initial)
        self.steps = []           # ordered flow: action / code / decision / loop / ...
        self.notes = []
        self.recover_steps = []   # error-handler chain (Recover -> Resume -> ...)
        self.work_blocks = []     # named Blocks with their own Recover (recovery scope)
        self.exposures = {}       # data item name -> 'Environment' | 'Session'
        self.is_main = False      # process main page: no SubSheetInfo/subsheetid
        self._loopgrp_stack = []

    def _ss(self):
        return '' if self.is_main else f'\n  <subsheetid>{self.ssid}</subsheetid>'

    # ---- declarations -------------------------------------------------
    def add_input(self, dtype, name):
        self.inputs.append((_dt(dtype, name), name)); return self

    def add_output(self, dtype, name):
        self.outputs.append((_dt(dtype, name), name)); return self

    def data(self, name, dtype, initial=None, exposure=None):
        """A data item. exposure='Environment' reads a Blue Prism Environment Variable OF THE
        SAME NAME (no initial value; set it in System Manager); exposure='Session' is a
        Control Room session variable (stop/limit controls). Verified shapes from a real release."""
        _dt(dtype, name)
        _check_name(f'data on page {self.name!r}', name)
        if exposure not in (None, 'Environment', 'Session'):
            raise ValueError(f"data {name!r}: exposure must be None, 'Environment' or 'Session'")
        if exposure == 'Environment':
            if initial:
                raise ValueError(f"data {name!r}: an Environment item takes its value from System "
                                 f"Manager; do not give it an initial value")
            initial = ''
        elif initial is None:
            initial = DEFAULT_INIT.get(dtype, '')
        self.extra_data.append((name, dtype, initial))
        if exposure:
            self.exposures[name] = exposure
        return self

    def note(self, name, text):
        _ascii_check(f'note {name!r}', text)
        self.notes.append((name, text)); return self

    def _auto_data(self, outputs):
        # Any output 'stagename' that is not already a declared data item is
        # auto-created as a Data stage of that type, so you do NOT need data().
        for dt, nm, st in (outputs or []):
            _dt(dt, f'output {nm}')
            if st and st not in [d[0] for d in self.extra_data]:
                self.extra_data.append((st, dt, DEFAULT_INIT.get(dt, '')))

    def _sid(self, kind, name):
        return gid(self.proc.name, self.name, kind, name, str(len(self.steps)))

    # ---- steps --------------------------------------------------------
    def action(self, name, obj, act, inputs=None, outputs=None, goto=None):
        """Call another VBO/object action. inputs=[(type,name,expr)],
        outputs=[(type,name,stagename)]. goto overrides the default fall-through."""
        self.steps.append({'kind': 'action', 'sid': self._sid('action', name), 'name': name,
                           'obj': obj, 'act': act, 'goto': goto,
                           'inputs': inputs or [], 'outputs': outputs or []})
        self._auto_data(outputs); return self

    def code(self, name, code, inputs=None, outputs=None, goto=None):
        """A .NET code stage. Requires Proc.code_options() to have been set.
        inputs=[(type,name,expr)], outputs=[(type,name,stagename)]."""
        self.steps.append({'kind': 'code', 'sid': self._sid('code', name), 'name': name,
                           'code': code, 'goto': goto,
                           'inputs': inputs or [], 'outputs': outputs or []})
        self._auto_data(outputs); return self

    def calc(self, name, expr, target, goto=None):
        """A Calculation stage (verified 7.x shape): target := expr."""
        self.steps.append({'kind': 'calc', 'sid': self._sid('calc', name), 'name': name,
                           'expr': expr, 'target': target, 'goto': goto}); return self

    def multi_calc(self, name, pairs, goto=None):
        """Multiple Calculation (verified 7.x shape): pairs=[(expr, target), ...]."""
        self.steps.append({'kind': 'mcalc', 'sid': self._sid('mcalc', name), 'name': name,
                           'pairs': pairs, 'goto': goto}); return self

    def decision(self, name, expr, true_target='NEXT', false_target='END'):
        """A real Blue Prism Decision stage. expr is a BP boolean expression,
        e.g. '[Item ID] <> ""' or 'Not([Updated])'. Targets resolve at render time
        ('NEXT', 'END', or any stage name -- backward names make loop exits)."""
        self.steps.append({'kind': 'decision', 'sid': self._sid('decision', name), 'name': name,
                           'expr': expr, 'true': true_target, 'false': false_target}); return self

    def loop_start(self, collection, name=None):
        """Open a ForEach loop over [collection]. Pair with loop_end()."""
        name = name or (collection + ' Loop Start')
        grp = gid(self.proc.name, self.name, 'loopgrp', collection, str(len(self.steps)))
        self.steps.append({'kind': 'loopstart', 'sid': self._sid('loopstart', name),
                           'name': name, 'coll': collection, 'grp': grp})
        self._loopgrp_stack.append(grp); return self

    def loop_end(self, name=None):
        """Close the innermost open ForEach loop (shares its groupid)."""
        if not self._loopgrp_stack:
            raise FlowError(f'[{self.proc.name}/{self.name}] loop_end() without loop_start()')
        grp = self._loopgrp_stack.pop()
        name = name or 'Loop End'
        self.steps.append({'kind': 'loopend', 'sid': self._sid('loopend', name),
                           'name': name, 'grp': grp}); return self

    def page_ref(self, name, page, inputs=None, outputs=None, goto=None):
        """Call another PAGE (subsheet) of this same process -- a real Blue Prism
        page-reference stage (type="SubSheet"). `page` is the exact name of the
        target page (as passed to Proc.page(...)); it is resolved to that page's
        subsheetid. Only valid in a type="process"; the target page must exist."""
        self.steps.append({'kind': 'pageref', 'sid': self._sid('pageref', name), 'name': name,
                           'page': page, 'target_ssid': gid(self.proc.name, 'subsheet', page),
                           'goto': goto, 'inputs': inputs or [], 'outputs': outputs or []})
        self._auto_data(outputs); return self

    def exception(self, name, ex_type=None, detail=None, use_current=False):
        """Exception stage (verified 7.x raise shape). Throw. Either preserve the current exception
        (use_current=True, inside a Recover handler) or raise ex_type with a
        detail EXPRESSION (wrap literal text with lit())."""
        if not use_current and ex_type not in EXCEPTION_TYPES:
            raise ValueError(f'exception {name!r}: type must be one of {sorted(EXCEPTION_TYPES)}')
        self.steps.append({'kind': 'exception', 'sid': self._sid('exception', name),
                           'name': name, 'type': ex_type, 'detail': detail or '""',
                           'cur': use_current}); return self

    def choice(self, name, choices, otherwise='NEXT', otherwise_name=None):
        """Choice (verified 7.x ChoiceStart/ChoiceEnd shape). Use for 3+ known alternatives
        instead of a decision chain. choices=[(label, expr, target), ...] -- first true
        expression wins; otherwise= target when none is true (the ChoiceEnd path)."""
        if len(choices) < 2:
            raise ValueError(f'choice {name!r}: needs at least 2 choices (use decision())')
        grp = gid(self.proc.name, self.name, 'choicegrp', name)
        self.steps.append({'kind': 'choice', 'sid': self._sid('choice', name), 'name': name,
                           'choices': list(choices), 'otherwise': otherwise, 'grp': grp,
                           'otherwise_name': otherwise_name or f'{name} - Otherwise'})
        return self

    def work_block(self, name, first, last, handler=None, then='RETHROW', capture=None):
        """Wrap steps first..last (by name, in list order) in a Block named after the work,
        with its OWN Recover inside the block -- the estate's recovery-scope pattern.

        Order (Blue Prism rule: ExceptionType()/ExceptionDetail()/ExceptionStage() and the
        'preserve current exception' rethrow only work in RECOVERY MODE, i.e. after Recover
        and BEFORE Resume -- verified on the official MS Excel VBO):
          Recover -> capture (Multiple Calculation) -> handler actions ->
            then='RETHROW': rethrow the current exception (still in recovery, no Resume)
            otherwise:      Resume -> continue at `then` ('END' or a stage name)
        capture = (type_item, detail_item, stage_item): data item names that receive the
        exception's type/detail/stage (None to skip one). Needed whenever the continuation
        must decide on the failure (business vs system, retry) -- after Resume the functions
        no longer return the exception.
        handler = [(name, obj, act, inputs), ...] actions (logging, mark item) run in recovery."""
        if capture is not None and (len(capture) != 3 or not any(capture)):
            raise ValueError(f'work_block {name!r}: capture=(type_item, detail_item, stage_item)')
        hs = []
        for h in (handler or []):
            hname, obj, act = h[0], h[1], h[2]
            ins = h[3] if len(h) > 3 else []
            hs.append({'sid': gid(self.proc.name, self.name, 'blockhandler', name, hname),
                       'name': hname, 'obj': obj, 'act': act, 'inputs': ins})
        self.work_blocks.append({'name': name, 'first': first, 'last': last, 'handler': hs,
                                 'then': then, 'recover_name': f'Recover {name}',
                                 'resume_name': f'Resume {name}',
                                 'rethrow_name': f'Rethrow {name}',
                                 'capture': tuple(capture) if capture else None,
                                 'capture_name': f'Get {name} Exception Details'})
        return self

    # ---- Application Modeller stages (elements by name; see Proc.element / use_model) ----
    def _act_check(self, kind, action, where):
        if action not in VERIFIED_ACTIONS[kind]:
            import sys as _sys
            print(f"WARNING [{self.proc.name}/{self.name}] {where}: action id {action!r} not seen in "
                  f"real exports (verified: {sorted(VERIFIED_ACTIONS[kind])}) -- check it in "
                  f"Application Modeller after import", file=_sys.stderr)

    def write(self, name, steps, goto=None):
        """Write stage (verified shape). steps=[(element, expr), ...]: element is the
        Application Modeller element name or path ('Window: Login/Textbox: User'); expr a BP
        expression ([Item] or lit('text')). Write steps carry no action id."""
        self.steps.append({'kind': 'write', 'sid': self._sid('write', name), 'name': name,
                           'items': list(steps), 'goto': goto}); return self

    def read(self, name, steps, goto=None):
        """Read stage (verified shape). steps=[(element, action_id, data_item, dtype), ...],
        e.g. ('Label: Error', 'GetWindowText', 'l_txt_Error', 'text'). The data item is
        auto-created like an output."""
        for el, act, item, dt in steps:
            self._act_check('read', act, name)
            self._auto_data([(dt, item, item)])
        self.steps.append({'kind': 'read', 'sid': self._sid('read', name), 'name': name,
                           'items': list(steps), 'goto': goto}); return self

    def navigate(self, name, steps, goto=None):
        """Navigate stage (verified shape). steps=[(element, action_id), ...] in order, e.g.
        ('Button: Log In', 'Press'). Argument-taking actions are not supported yet."""
        for el, act in steps:
            self._act_check('navigate', act, name)
        self.steps.append({'kind': 'navigate', 'sid': self._sid('navigate', name), 'name': name,
                           'items': list(steps), 'goto': goto}); return self

    def wait(self, name, timeout):
        """A pause: Wait stage with NO conditions + timeout (Blue Prism's sleep idiom, verified
        on the official Utility - Environment object). timeout = seconds or an expression,
        e.g. '[Retry Wait Seconds]'. The pair is named <name> / 'Time Out - <name>'."""
        self.steps.append({'kind': 'wait', 'sid': self._sid('wait', name), 'name': name,
                           'conds': [], 'timeout': str(timeout), 'on_timeout': 'NEXT',
                           'grp': gid(self.proc.name, self.name, 'waitgrp', name),
                           'end_name': f'Time Out - {name}'}); return self

    def wait_for(self, name, conditions, timeout, on_timeout):
        """Wait for an element (verified shape). conditions=[(element, 'CheckExists', target)]
        -- the first condition met continues at its target ('NEXT' or a stage name).
        on_timeout = stage name (e.g. an Exception) taken when nothing happens in time."""
        for el, cond, tgt in conditions:
            self._act_check('wait', cond, name)
        self.steps.append({'kind': 'wait', 'sid': self._sid('wait', name), 'name': name,
                           'conds': list(conditions), 'timeout': str(timeout),
                           'on_timeout': on_timeout,
                           'grp': gid(self.proc.name, self.name, 'waitgrp', name),
                           'end_name': f'Time Out - {name}'}); return self

    def recover_action(self, name, obj, act, inputs=None):
        """Add an action to the Recover/Resume error handler. The Recover stage
        catches any exception on the page, Resume clears recovery mode, then
        these actions run before End. Rendered as a parallel flow (x offset)."""
        sid = gid(self.proc.name, self.name, 'recover-action', name, str(len(self.recover_steps)))
        self.recover_steps.append({'kind': 'action', 'sid': sid, 'name': name,
                                   'obj': obj, 'act': act, 'inputs': inputs or []}); return self

    # ---- rendering helpers ---------------------------------------------
    def _render_action_inputs(self, ins):
        out = ['  <inputs>']
        for dt, nm, expr in ins:
            out.append(f'    <input type="{dt}" name="{esc(nm)}" friendlyname="{esc(nm)}" expr="{esc(expr)}" />')
        out.append('  </inputs>'); return out

    def _render_inputs(self, ins):           # code-style: name + expr
        out = ['  <inputs>']
        for dt, nm, expr in ins:
            out.append(f'    <input type="{dt}" name="{esc(nm)}" expr="{esc(expr)}" />')
        out.append('  </inputs>'); return out

    def _render_action_outputs(self, outs):
        out = ['  <outputs>']
        for dt, nm, st in outs:
            out.append(f'    <output type="{dt}" name="{esc(nm)}" friendlyname="{esc(nm)}" stage="{esc(st)}" />')
        out.append('  </outputs>'); return out

    def _render_outputs(self, outs):         # code-style: name + stage
        out = ['  <outputs>']
        for dt, nm, st in outs:
            out.append(f'    <output type="{dt}" name="{esc(nm)}" stage="{esc(st)}" />')
        out.append('  </outputs>'); return out

    def _stage(self, sid, name, stype, x, y, w=150, h=30, font=FONT, loginhibit=None):
        p = [f'<stage stageid="{sid}" name="{esc(name)}" type="{stype}">{self._ss()}']
        if loginhibit == 'bare':
            p.append('  <loginhibit />')
        elif loginhibit == 'true':
            p.append('  <loginhibit onsuccess="true" />')
        p.append(f'  <display x="{x}" y="{y}" w="{w}" h="{h}" />')
        p.append(f'  {font}')
        return p

    def _check_unique_names(self):
        # Two stages with one name make every name-based jump ambiguous (the old
        # "first one wins" rule hid that) and are an estate anti-pattern.
        reserved = {'Start', 'End'} | ({'Recover', 'Resume'} if self.recover_steps else set())
        names = [s['name'] for s in self.steps] + [s['name'] for s in self.recover_steps]
        names += [s['otherwise_name'] for s in self.steps if s['kind'] == 'choice']
        names += [s['end_name'] for s in self.steps if s['kind'] == 'wait']
        for b in self.work_blocks:
            names += [b['name'], b['recover_name']] + [h['name'] for h in b['handler']]
            names.append(b['rethrow_name'] if b['then'] == 'RETHROW' else b['resume_name'])
            if b['capture']:
                names.append(b['capture_name'])
        names += ['Input Variables', 'Output Variables', 'Global Variables' if self.is_main
                  else 'Local Variables', 'Environment Variables', 'Session Variables']
        for nm in names:
            _check_name(f'page {self.name!r}', nm)
        dups = sorted({n for n in names if names.count(n) > 1} | (set(names) & reserved))
        # (data-block names are fixed; a stage may not reuse one)
        if dups:
            raise FlowError(f'[{self.proc.name}/{self.name}] duplicate or reserved stage name(s): {dups}')
        clash = sorted(set(names) & {d[0] for d in self.extra_data})
        if clash:
            raise FlowError(f'[{self.proc.name}/{self.name}] stage name(s) equal a data item name: {clash}')

    # ---- layout --------------------------------------------------------
    # Coordinates (measured on a real release): a stage's x,y is its CENTRE; a Block's
    # x,y is its TOP-LEFT corner. Block membership is geometric and decides recovery
    # scope, so blocks are computed from stage positions, never guessed.
    # Lanes (left -> right): page recovery | block-recovery handlers | main path |
    # anchor lanes for long jumps/back-edges | data blocks | notes. Grid = 15.
    MAIN_X, STEP_DY = 15, 60
    PAGE_REC_X, BLOCK_HANDLER_X, BLOCK_RECOVER_X = -510, -330, -150
    REC_W = 120                      # Recover/Resume boxes wide enough for 'Recover <work>'
    LANE0, LANE_DX = 150, 30
    BLOCK_COLOUR = '7FB2E5'

    def render(self):
        self._check_unique_names()
        if self._loopgrp_stack:
            raise FlowError(f'[{self.proc.name}/{self.name}] {len(self._loopgrp_stack)} '
                            f'loop_start() without loop_end()')
        p = []
        start_id = gid(self.proc.name, self.name, 'start')
        end_id = gid(self.proc.name, self.name, 'end')
        if not self.is_main:
            info_id = gid(self.proc.name, 'info', self.name)
            p += [f'<stage stageid="{info_id}" name="{esc(self.name)}" type="SubSheetInfo">',
                  f'  <subsheetid>{self.ssid}</subsheetid>',
                  f'  <narrative>{esc(self.narrative)}</narrative>',
                  '  <display x="-345" y="-135" w="220" h="120" />',
                  # verified shape: SubSheetInfo always carries <published>true</published>;
                  # real publication is the <subsheet published=...> declaration.
                  f'  {FONT_TITLE}', '  <published>true</published>', '</stage>']

        # positions of main-column stages (centre coordinates)
        n = len(self.steps)
        pos = {start_id: (self.MAIN_X, -30)}
        for i, s in enumerate(self.steps):
            pos[s['sid']] = (self.MAIN_X, 30 + self.STEP_DY * i)
        end_y = 30 + self.STEP_DY * n
        pos[end_id] = (self.MAIN_X, end_y)
        names = {start_id: 'Start', end_id: 'End'}
        names.update({s['sid']: s['name'] for s in self.steps})

        # label -> stageid (names are unique: _check_unique_names enforces it)
        label_to_sid = {s['name']: s['sid'] for s in self.steps}

        def resolve(target, i):
            if target == 'NEXT':
                return self.steps[i + 1]['sid'] if i + 1 < n else end_id
            if target == 'END':
                return end_id
            if target not in label_to_sid:
                msg = (f"[{self.proc.name}/{self.name}] flow target '{target}' matches no "
                       f"stage name on this page. Known: {sorted(label_to_sid)}")
                if self.proc.strict:
                    raise FlowError(msg)
                import sys as _sys
                print('WARNING ' + msg + ' -- falling back to End.', file=_sys.stderr)
                return end_id
            return label_to_sid[target]

        # choice ends sit to the right of their ChoiceStart; lanes start after the widest one
        choice_end_x = {}
        for s in self.steps:
            if s['kind'] == 'choice':
                choice_end_x[s['sid']] = self.MAIN_X + 75 * (len(s['choices']) + 1)
            if s['kind'] == 'wait':
                choice_end_x[s['sid']] = self.MAIN_X + 75 * (len(s['conds']) + 1)
        lane_base = max([self.LANE0] + [x + 60 for x in choice_end_x.values()])
        routes = []           # long jumps; lanes are assigned after all links are known
        short_hop = {}        # wait-end id -> next stage id (drawn direct, no anchors)
        used_anchor_names = set(names.values())

        def link(src_sid, tag, tgt_sid, src_xy=None):
            """Return the id the source should point at. Adjacent main-column targets link
            directly; everything else is routed through two named anchors in its own lane
            so no connector crosses the main path."""
            sx, sy = src_xy or pos[src_sid]
            tx, ty = pos[tgt_sid]
            if sx == tx == self.MAIN_X and ty == sy + self.STEP_DY:
                return tgt_sid
            if sx == tx and ty == sy + self.STEP_DY and tgt_sid == end_id:
                return tgt_sid
            if src_sid in short_hop and tgt_sid == short_hop[src_sid]:
                return tgt_sid          # a pause's time-out end -> the very next stage
            base = f'{names.get(src_sid, "?")} {tag} to {names.get(tgt_sid, "?")}'
            nm_out, nm_in = base, base + ' (arrive)'
            k = 2
            while nm_out in used_anchor_names or nm_in in used_anchor_names:
                nm_out, nm_in = f'{base} {k}', f'{base} {k} (arrive)'
                k += 1
            used_anchor_names.update({nm_out, nm_in})
            a_out = gid(self.proc.name, self.name, 'anchor', nm_out)
            a_in = gid(self.proc.name, self.name, 'anchor', nm_in)
            routes.append({'out': (a_out, nm_out, sy, a_in), 'in': (a_in, nm_in, ty, tgt_sid),
                           'lo': min(sy, ty), 'hi': max(sy, ty)})
            return a_out

        first = self.steps[0]['sid'] if self.steps else end_id
        p += [f'<stage stageid="{start_id}" name="Start" type="Start">{self._ss()}',
              '  <display x="15" y="-30" w="60" h="30" />', f'  {FONT}']
        if self.inputs:
            p.append('  <inputs>')
            for dt, nm in self.inputs:
                p.append(f'    <input type="{dt}" name="{esc(nm)}" friendlyname="{esc(nm)}" stage="{esc(nm)}" />')
            p.append('  </inputs>')
        p += [f'  <onsuccess>{link(start_id, "next", first)}</onsuccess>', '</stage>']

        for i, s in enumerate(self.steps):
            x, y = pos[s['sid']]
            nxt = self.steps[i + 1]['sid'] if i + 1 < n else end_id
            k = s['kind']
            if k == 'decision':
                t_id, f_id = resolve(s['true'], i), resolve(s['false'], i)
                p += self._stage(s['sid'], s['name'], 'Decision', x, y, loginhibit='bare')
                p += [f'  <decision expression="{esc(s["expr"])}" />',
                      f'  <ontrue>{link(s["sid"], "yes", t_id)}</ontrue>',
                      f'  <onfalse>{link(s["sid"], "no", f_id)}</onfalse>', '</stage>']
                continue
            if k == 'choice':
                # verified 7.x shape (ChoiceStart/ChoiceEnd share a groupid; ChoiceEnd = otherwise)
                ce_id = gid(self.proc.name, self.name, 'choiceend', s['name'])
                ce_x = choice_end_x[s['sid']]
                pos[ce_id] = (ce_x, y)
                names[ce_id] = s['otherwise_name']
                p += [f'<stage stageid="{s["sid"]}" name="{esc(s["name"])}" type="ChoiceStart">{self._ss()}',
                      '  <loginhibit />', f'  <display x="{x}" y="{y}" />',
                      f'  <groupid>{s["grp"]}</groupid>', '  <choices>']
                for j, (label, expr, target) in enumerate(s['choices']):
                    tid = link(s['sid'], label, resolve(target, i))
                    p += [f'    <choice expression="{esc(expr)}">',
                          f'      <name>{esc(label)}</name><distance>{75 * (j + 1)}</distance>'
                          f'<ontrue>{tid}</ontrue>', '    </choice>']
                p += ['  </choices>', '</stage>']
                o_id = link(ce_id, 'otherwise', resolve(s['otherwise'], i))
                p += [f'<stage stageid="{ce_id}" name="{esc(s["otherwise_name"])}" type="ChoiceEnd">{self._ss()}',
                      '  <loginhibit />', f'  <display x="{ce_x}" y="{y}" />',
                      f'  <onsuccess>{o_id}</onsuccess>', f'  <groupid>{s["grp"]}</groupid>', '</stage>']
                continue
            if k == 'wait':
                we_id = gid(self.proc.name, self.name, 'waitend', s['name'])
                we_x = choice_end_x[s['sid']]
                pos[we_id] = (we_x, y)
                names[we_id] = s['end_name']
                p += [f'<stage stageid="{s["sid"]}" name="{esc(s["name"])}" type="WaitStart">{self._ss()}',
                      '  <loginhibit />', f'  <display x="{x}" y="{y}" w="30" h="30" />', f'  {FONT}',
                      f'  <groupid>{s["grp"]}</groupid>']
                if not s['conds']:
                    p.append('  <choices />')
                else:
                    p.append('  <choices>')
                    for j, (el, cond, tgt) in enumerate(s['conds']):
                        eid = self.proc.element_id(el, f'{self.name}/{s["name"]}')
                        tid = link(s['sid'], f'{el.split("/")[-1]} {cond}', resolve(tgt, i))
                        p += ['    <choice reply="True">',
                              f'      <name>{esc(el.split("/")[-1])} {esc(cond)}</name>'
                              f'<distance>{75 * (j + 1)}</distance><ontrue>{tid}</ontrue>',
                              f'      <element id="{eid}" />',
                              f'      <condition><id>{esc(cond)}</id></condition>',
                              '      <comparetype>Equal</comparetype>', '    </choice>']
                    p.append('  </choices>')
                p += [f'  <timeout>{esc(s["timeout"])}</timeout>', '</stage>']
                to_tgt = resolve(s['on_timeout'], i)
                if not s['conds'] and s['on_timeout'] == 'NEXT':
                    short_hop[we_id] = to_tgt
                p += [f'<stage stageid="{we_id}" name="{esc(s["end_name"])}" type="WaitEnd">{self._ss()}',
                      '  <loginhibit />', f'  <display x="{we_x}" y="{y}" w="30" h="30" />', f'  {FONT}',
                      f'  <onsuccess>{link(we_id, "timeout", to_tgt)}</onsuccess>',
                      f'  <groupid>{s["grp"]}</groupid>', '</stage>']
                continue
            if k in ('write', 'read', 'navigate'):
                succ = link(s['sid'], 'next', resolve(s['goto'], i) if s.get('goto') else nxt)
                p += self._stage(s['sid'], s['name'], k.capitalize(), x, y, loginhibit='bare')
                p.append(f'  <onsuccess>{succ}</onsuccess>')
                where = f'{self.name}/{s["name"]}'
                for item in s['items']:
                    if k == 'write':
                        el, expr = item
                        p.append(f'  <step expr="{esc(expr)}"><element id="{self.proc.element_id(el, where)}" /></step>')
                    elif k == 'read':
                        el, act, target, dt = item
                        p.append(f'  <step stage="{esc(target)}"><element id="{self.proc.element_id(el, where)}" />'
                                 f'<action><id>{esc(act)}</id></action></step>')
                    else:
                        el, act = item
                        p.append(f'  <step><element id="{self.proc.element_id(el, where)}" />'
                                 f'<action><id>{esc(act)}</id></action></step>')
                p.append('</stage>')
                continue
            if k == 'loopstart':
                p += self._stage(s['sid'], s['name'], 'LoopStart', x, y, loginhibit='bare')
                p += [f'  <onsuccess>{link(s["sid"], "next", nxt)}</onsuccess>',
                      f'  <groupid>{s["grp"]}</groupid>',
                      '  <looptype>ForEach</looptype>', f'  <loopdata>{esc(s["coll"])}</loopdata>',
                      '</stage>']
                continue
            if k == 'loopend':
                p += self._stage(s['sid'], s['name'], 'LoopEnd', x, y, loginhibit='bare')
                p += [f'  <onsuccess>{link(s["sid"], "next", nxt)}</onsuccess>',
                      f'  <groupid>{s["grp"]}</groupid>', '</stage>']
                continue
            if k == 'exception':
                # verified 7.x shape: <loginhibit onsuccess="true" />; raise carries type+detail;
                # rethrow (verified on a 6.x export) is localized/empty type/usecurrent.
                p += self._stage(s['sid'], s['name'], 'Exception', x, y, loginhibit='true')
                if s['cur']:
                    p.append('  <exception localized="yes" type="" detail="" usecurrent="yes" />')
                else:
                    p.append(f'  <exception type="{esc(s["type"])}" detail="{esc(s["detail"])}" />')
                p.append('</stage>')
                continue
            succ = link(s['sid'], 'next', resolve(s['goto'], i) if s.get('goto') else nxt)
            if k == 'pageref':
                p += self._stage(s['sid'], s['name'], 'SubSheet', x, y, font=FONT_TITLE, loginhibit='true')
                if s['inputs']:
                    p += self._render_inputs(s['inputs'])
                if s['outputs']:
                    p += self._render_outputs(s['outputs'])
                p += [f'  <onsuccess>{succ}</onsuccess>',
                      f'  <processid>{s["target_ssid"]}</processid>', '</stage>']
                continue
            if k == 'action':
                p += self._stage(s['sid'], s['name'], 'Action', x, y)
                if s['inputs']:
                    p += self._render_action_inputs(s['inputs'])
                if s['outputs']:
                    p += self._render_action_outputs(s['outputs'])
                p += [f'  <onsuccess>{succ}</onsuccess>',
                      f'  <resource object="{esc(s["obj"])}" action="{esc(s["act"])}" />', '</stage>']
                continue
            if k == 'calc':
                p += self._stage(s['sid'], s['name'], 'Calculation', x, y, loginhibit='bare')
                p += [f'  <onsuccess>{succ}</onsuccess>',
                      f'  <calculation expression="{esc(s["expr"])}" stage="{esc(s["target"])}" />',
                      '</stage>']
                continue
            if k == 'mcalc':
                p += self._stage(s['sid'], s['name'], 'MultipleCalculation', x, y, loginhibit='bare')
                p += [f'  <onsuccess>{succ}</onsuccess>', '  <steps>']
                for expr, tgt in s['pairs']:
                    p.append(f'    <calculation expression="{esc(expr)}" stage="{esc(tgt)}" />')
                p += ['  </steps>', '</stage>']
                continue
            # code stage
            p += self._stage(s['sid'], s['name'], 'Code', x, y)
            if s['inputs']:
                p += self._render_inputs(s['inputs'])
            if s['outputs']:
                p += self._render_outputs(s['outputs'])
            p += [f'  <onsuccess>{succ}</onsuccess>', f'  <code>{cdata(s["code"])}</code>', '</stage>']

        p += [f'<stage stageid="{end_id}" name="End" type="End">{self._ss()}',
              f'  <display x="15" y="{end_y}" w="60" h="30" />', f'  {FONT}']
        if self.outputs:
            p.append('  <outputs>')
            for dt, nm in self.outputs:
                p.append(f'    <output type="{dt}" name="{esc(nm)}" friendlyname="{esc(nm)}" stage="{esc(nm)}" />')
            p.append('  </outputs>')
        p.append('</stage>')

        # --- work blocks with their own recovery (Block = recovery scope) -----------
        for b in self.work_blocks:
            idx = [i for i, s in enumerate(self.steps) if s['name'] in (b['first'], b['last'])]
            if len(idx) != 2 and b['first'] != b['last']:
                raise FlowError(f"[{self.proc.name}/{self.name}] work block {b['name']!r}: "
                                f"first/last step not found")
            lo, hi = min(idx), max(idx)
            top = pos[self.steps[lo]['sid']][1] - 30
            bottom = pos[self.steps[hi]['sid']][1] + 30
            bx = self.BLOCK_RECOVER_X - self.REC_W // 2 - 15
            bw = (self.MAIN_X + 90) - bx
            rec_id = gid(self.proc.name, self.name, 'blockrecover', b['name'])
            res_id = gid(self.proc.name, self.name, 'blockresume', b['name'])
            ry = pos[self.steps[lo]['sid']][1]
            then_id = end_id if b['then'] == 'END' else resolve(b['then'], -1) if b['then'] != 'RETHROW' else None
            p += [f'<stage stageid="{gid(self.proc.name, self.name, "block", b["name"])}" '
                  f'name="{esc(b["name"])}" type="Block">{self._ss()}',
                  f'  <display x="{bx}" y="{top}" w="{bw}" h="{bottom - top}" />',
                  f'  <font family="Segoe UI" size="10" style="Regular" color="{self.BLOCK_COLOUR}" />',
                  '</stage>']
            # Recover INSIDE the block (catches its stages); the recovery chain runs in the
            # left lane OUTSIDE the block, all of it in recovery mode until Resume.
            chain = []                                  # (sid, kind, payload)
            if b['capture']:
                pairs = [(fn, it) for fn, it in zip(('ExceptionType()', 'ExceptionDetail()',
                                                     'ExceptionStage()'), b['capture']) if it]
                chain.append((gid(self.proc.name, self.name, 'blockcapture', b['name']), 'capture', pairs))
            for st_ in b['handler']:
                chain.append((st_['sid'], 'action', st_))
            if b['then'] == 'RETHROW':
                chain.append((gid(self.proc.name, self.name, 'blockrethrow', b['name']), 'rethrow', None))
            else:
                chain.append((res_id, 'resume', None))
            p += [f'<stage stageid="{rec_id}" name="{esc(b["recover_name"])}" type="Recover">{self._ss()}',
                  '  <loginhibit onsuccess="true" />',
                  f'  <display x="{self.BLOCK_RECOVER_X}" y="{ry}" w="{self.REC_W}" h="30" />', f'  {FONT}',
                  f'  <onsuccess>{chain[0][0]}</onsuccess>', '</stage>']
            hy = ry
            for j, (sid, kind, payload) in enumerate(chain):
                nx = chain[j + 1][0] if j + 1 < len(chain) else None
                if kind == 'capture':
                    p += self._stage(sid, b['capture_name'], 'MultipleCalculation', self.BLOCK_HANDLER_X, hy,
                                     w=self.REC_W, loginhibit='bare')
                    p += [f'  <onsuccess>{nx}</onsuccess>', '  <steps>']
                    for fn, it in payload:
                        p.append(f'    <calculation expression="{fn}" stage="{esc(it)}" />')
                    p += ['  </steps>', '</stage>']
                elif kind == 'action':
                    p += [f'<stage stageid="{sid}" name="{esc(payload["name"])}" type="Action">{self._ss()}',
                          f'  <display x="{self.BLOCK_HANDLER_X}" y="{hy}" w="150" h="30" />', f'  {FONT}']
                    if payload['inputs']:
                        p += self._render_action_inputs(payload['inputs'])
                    p += [f'  <onsuccess>{nx}</onsuccess>',
                          f'  <resource object="{esc(payload["obj"])}" action="{esc(payload["act"])}" />', '</stage>']
                elif kind == 'rethrow':
                    p += self._stage(sid, b['rethrow_name'], 'Exception', self.BLOCK_HANDLER_X, hy,
                                     w=self.REC_W, loginhibit='true')
                    p += ['  <exception localized="yes" type="" detail="" usecurrent="yes" />', '</stage>']
                else:   # resume, then continue at `then`
                    p += [f'<stage stageid="{res_id}" name="{esc(b["resume_name"])}" type="Resume">{self._ss()}',
                          '  <loginhibit onsuccess="true" />',
                          f'  <display x="{self.BLOCK_HANDLER_X}" y="{hy}" w="{self.REC_W}" h="30" />', f'  {FONT}',
                          f'  <onsuccess>{then_id}</onsuccess>', '</stage>']
                hy += self.STEP_DY

        # --- anchors (routed long jumps / back-edges), verified 7.x shape ----------
        # Lane assignment: shortest spans innermost, a lane reused only by jumps whose
        # vertical spans do not overlap -> nested jumps never cross each other.
        lanes = []            # per lane: list of (lo, hi)
        anchors = []
        for r in sorted(routes, key=lambda r: (r['hi'] - r['lo'], r['lo'])):
            k = 0
            while k < len(lanes) and any(not (r['hi'] < lo or r['lo'] > hi) for lo, hi in lanes[k]):
                k += 1
            if k == len(lanes):
                lanes.append([])
            lanes[k].append((r['lo'], r['hi']))
            ax = lane_base + self.LANE_DX * k
            a_out, nm_out, sy, a_in = r['out']
            a_in2, nm_in, ty, tgt = r['in']
            anchors.append((a_out, nm_out, ax, sy, a_in))
            anchors.append((a_in2, nm_in, ax, ty, tgt))
        for sid, nm, ax, ay, tgt in anchors:
            p += [f'<stage stageid="{sid}" name="{esc(nm)}" type="Anchor">{self._ss()}',
                  '  <loginhibit />', f'  <display x="{ax}" y="{ay}" w="10" h="10" />',
                  f'  <onsuccess>{tgt}</onsuccess>', '</stage>']

        # --- data items, sorted, inside named Blocks to the right ------------------
        lanes_right = lane_base + self.LANE_DX * max(len(lanes), 1)
        data_x = lanes_right + 120
        input_names = [nm for _, nm in self.inputs]
        output_names = [nm for _, nm in self.outputs]
        allitems = ([(nm, dt, DEFAULT_INIT.get(dt, '')) for dt, nm in self.inputs] +
                    [(nm, dt, DEFAULT_INIT.get(dt, '')) for dt, nm in self.outputs] + self.extra_data)
        seen, items = set(), []
        for nm, dt, init in allitems:
            if nm not in seen:
                seen.add(nm)
                items.append((nm, dt, init))
        local_label = 'Global Variables' if self.is_main else 'Local Variables'
        plain = [it for it in items if it[0] not in self.exposures]
        groups = [('Input Variables', [it for it in plain if it[0] in input_names]),
                  ('Output Variables', [it for it in plain if it[0] in output_names and it[0] not in input_names]),
                  (local_label, [it for it in plain if it[0] not in input_names and it[0] not in output_names]),
                  ('Environment Variables', [it for it in items if self.exposures.get(it[0]) == 'Environment']),
                  ('Session Variables', [it for it in items if self.exposures.get(it[0]) == 'Session'])]
        cur = -60
        for label, group in groups:
            if not group:
                continue
            group = sorted(group, key=lambda it: it[0].lower())
            top = cur
            p += [f'<stage stageid="{gid(self.proc.name, self.name, "datablock", label)}" '
                  f'name="{label}" type="Block">{self._ss()}',
                  f'  <display x="{data_x - 90}" y="{top}" w="180" h="{45 * len(group) + 30}" />',
                  f'  <font family="Segoe UI" size="10" style="Regular" color="{self.BLOCK_COLOUR}" />',
                  '</stage>']
            dy = top + 30
            for nm, dt, init in group:
                did = gid(self.proc.name, self.name, 'data', nm)
                if dt == 'collection':
                    # Blue Prism uses a dedicated Collection stage (verified against a
                    # real process export); ForEach <loopdata> and [Coll.Field]
                    # references depend on this, so a collection must NOT be a plain
                    # Data stage. Collection stages carry no <initialvalue>.
                    p += [f'<stage stageid="{did}" name="{esc(nm)}" type="Collection">{self._ss()}',
                          f'  <display x="{data_x}" y="{dy}" w="120" h="30" />', f'  {FONT}',
                          '  <datatype>collection</datatype>', '  <private />', '  <alwaysinit />', '</stage>']
                elif nm in self.exposures:
                    # verified shapes (real release): Environment = empty initial value, no
                    # private/alwaysinit; Session = initial value + exposure
                    iv = ('  <initialvalue />' if self.exposures[nm] == 'Environment'
                          else f'  <initialvalue>{esc(init)}</initialvalue>')
                    p += [f'<stage stageid="{did}" name="{esc(nm)}" type="Data">{self._ss()}',
                          f'  <display x="{data_x}" y="{dy}" w="120" h="30" />', f'  {FONT}',
                          f'  <datatype>{dt}</datatype>', iv,
                          f'  <exposure>{self.exposures[nm]}</exposure>', '</stage>']
                else:
                    p += [f'<stage stageid="{did}" name="{esc(nm)}" type="Data">{self._ss()}',
                          f'  <display x="{data_x}" y="{dy}" w="120" h="30" />', f'  {FONT}',
                          f'  <datatype>{dt}</datatype>', f'  <initialvalue>{esc(init)}</initialvalue>',
                          '  <private />', '  <alwaysinit />', '</stage>']
                dy += 45
            cur = top + 45 * len(group) + 30 + 30

        ny = -60
        for j, (nm, text) in enumerate(self.notes):
            nid = gid(self.proc.name, self.name, 'note', nm, str(j))
            p += [f'<stage stageid="{nid}" name="{esc(nm)}" type="Note">{self._ss()}',
                  f'  <display x="{data_x + 300}" y="{ny}" w="330" h="80" />', f'  {FONT_NOTE}',
                  f'  <narrative>{esc(text)}</narrative>', '</stage>']
            ny += 90

        # --- page-level Recover / Resume error handler (left lane) --------------------
        if self.recover_steps:
            rec_id = gid(self.proc.name, self.name, 'recover')
            res_id = gid(self.proc.name, self.name, 'resume')
            first_handler = self.recover_steps[0]['sid']
            ry = 30
            p += [f'<stage stageid="{rec_id}" name="Recover" type="Recover">{self._ss()}',
                  '  <loginhibit onsuccess="true" />',
                  f'  <display x="{self.PAGE_REC_X}" y="{ry}" w="{self.REC_W}" h="30" />', f'  {FONT}',
                  f'  <onsuccess>{res_id}</onsuccess>', '</stage>']
            ry += self.STEP_DY
            p += [f'<stage stageid="{res_id}" name="Resume" type="Resume">{self._ss()}',
                  '  <loginhibit onsuccess="true" />',
                  f'  <display x="{self.PAGE_REC_X}" y="{ry}" w="{self.REC_W}" h="30" />', f'  {FONT}',
                  f'  <onsuccess>{first_handler}</onsuccess>', '</stage>']
            for i, s in enumerate(self.recover_steps):
                ry += self.STEP_DY
                nxt = self.recover_steps[i + 1]['sid'] if i + 1 < len(self.recover_steps) else end_id
                p += [f'<stage stageid="{s["sid"]}" name="{esc(s["name"])}" type="Action">{self._ss()}',
                      f'  <display x="{self.PAGE_REC_X}" y="{ry}" w="150" h="30" />', f'  {FONT}']
                if s['inputs']:
                    p += self._render_action_inputs(s['inputs'])
                p += [f'  <onsuccess>{nxt}</onsuccess>',
                      f'  <resource object="{esc(s["obj"])}" action="{esc(s["act"])}" />', '</stage>']
        return '\n'.join(p)


class Proc:
    """A whole importable file. type='process' for orchestrations (has a main
    page), type='object' for business objects (all pages are subsheets)."""

    def __init__(self, name, ptype, narrative, runmode=None, strict=True):
        if ptype not in ('process', 'object'):
            raise ValueError("ptype must be 'process' or 'object'")
        for pre in ('BPA Object - ', 'BPA Process - '):
            if name.startswith(pre):
                raise ValueError(f"internal name {name!r} must NOT carry the '{pre}' filename "
                                 f"prefix -- it breaks cross-object action resolution.")
        _ascii_check(f'proc {name!r}', name + narrative)
        # Measured: 7/8 estate objects run Exclusive, 1/8 Background, 0/8 Foreground.
        # Preserve an existing object's mode by passing it explicitly.
        if runmode is None:
            runmode = 'Exclusive' if ptype == 'object' else 'Background'
        if runmode not in ('Exclusive', 'Background', 'Foreground'):
            raise ValueError(f'runmode {runmode!r} must be Exclusive, Background or Foreground')
        self.name = name; self.ptype = ptype
        self.narrative = narrative; self.runmode = runmode
        self.strict = strict
        self.pages = []
        self.code_env = None   # dict: language, references, imports, globalcode
        self.app = None        # generated Application Modeller: {'name', 'apptype', 'params'}
        self.elements = {}     # path -> {'id', 'type', 'datatype', 'spied': bool}
        self.model_xml = None  # appdef copied verbatim from an exported (spied) object

    # ---- Application Modeller -------------------------------------------------
    def application(self, name, apptype='Win32Launch', params=None):
        """Start a NEW Application Modeller for this object (option B: generate first, spy
        after). Elements added with element() are empty slots: after import, open Application
        Modeller and Identify each one -- Blue Prism keeps the element id, so every stage wired
        to it stays connected. apptype/params: the app type info; only Win32Launch is
        verified -- for anything else run the Application Modeller wizard after import."""
        if self.ptype != 'object':
            raise ValueError('application(): only business objects have an Application Modeller')
        self.app = {'name': name, 'apptype': apptype, 'params': dict(params or {})}
        return self

    def element(self, path, el_type, datatype='text'):
        """Declare an element slot. path = 'Window: Login/Textbox: User' (parents first)."""
        if self.app is None:
            raise ValueError('element(): call application() first (or use_model())')
        parent = path.rsplit('/', 1)[0] if '/' in path else None
        if parent and parent not in self.elements:
            raise ValueError(f'element({path!r}): declare parent {parent!r} first')
        _ascii_check(f'element {path!r}', path)
        self.elements[path] = {'id': gid(self.name, 'element', path), 'type': el_type,
                               'datatype': datatype, 'spied': False}
        return self

    def use_model(self, exported_xml):
        """Option A: take the Application Modeller from an exported object that is already
        spied (extending an existing object). Elements are referenced by name/path as usual."""
        import xml.etree.ElementTree as ET
        root = ET.parse(exported_xml).getroot()
        for el in root.iter():
            if isinstance(el.tag, str) and '}' in el.tag:
                el.tag = el.tag.split('}', 1)[1]
        ad = root.find('appdef')
        if ad is None:
            raise ValueError(f'{exported_xml}: no Application Modeller (<appdef>) in it')

        def walk(e, prefix):
            for c in e.findall('element'):
                path = f'{prefix}/{c.get("name")}' if prefix else c.get('name')
                attrs = c.find('attributes')
                self.elements[path] = {'id': c.findtext('id'), 'type': c.findtext('type'),
                                       'datatype': c.findtext('datatype'),
                                       'spied': attrs is not None and len(attrs) > 0}
                walk(c, path)
        top = ad.find('element')
        walk(top, '')                         # children of the application root
        self.model_xml = ET.tostring(ad, encoding='unicode')
        return self

    def element_id(self, ref, where):
        """Resolve an element by full path or by unique leaf name."""
        if ref in self.elements:
            return self.elements[ref]['id']
        hits = [p for p in self.elements if p.split('/')[-1] == ref]
        if len(hits) == 1:
            return self.elements[hits[0]]['id']
        known = sorted(p.split('/')[-1] for p in self.elements)
        raise FlowError(f"[{self.name}/{where}] element {ref!r} " +
                        ('is ambiguous: ' + ', '.join(hits) if hits else f'not found. Known: {known}'))

    def _render_appdef(self):
        if self.model_xml is not None:
            return self.model_xml
        def render_el(path, depth):
            e = self.elements[path]
            kids = [p for p in self.elements if p.rsplit('/', 1)[0] == path and '/' in p]
            out = [f'<element name="{esc(path.split("/")[-1])}">', f'<id>{e["id"]}</id>']
            for k in kids:
                out += render_el(k, depth + 1)
            # verified order: id, child elements, type, basetype, datatype, diagnose, attributes
            out += [f'<type>{esc(e["type"])}</type>', f'<basetype>{esc(e["type"])}</basetype>',
                    f'<datatype>{esc(e["datatype"])}</datatype>', '<diagnose>False</diagnose>',
                    '<attributes />', '</element>']
            return out
        tops = [p for p in self.elements if '/' not in p]
        out = ['<appdef>', f'<element name="{esc(self.app["name"])}">',
               f'<id>{gid(self.name, "element-root")}</id>']
        for t in tops:
            out += render_el(t, 1)
        out += ['<type>Application</type>', '<basetype>Application</basetype>',
                '<datatype>unknown</datatype>', '<diagnose>False</diagnose>', '</element>',
                f'<apptypeinfo><id>{esc(self.app["apptype"])}</id><parameters>']
        for k, v in self.app['params'].items():
            out.append(f'<parameter><name>{esc(k)}</name>' +
                       (f'<value>{esc(v)}</value>' if v else '<value />') + '</parameter>')
        out += ['</parameters></apptypeinfo>', '</appdef>']
        return '\n'.join(out)

    def spy_checklist(self):
        """Elements still to Identify in Application Modeller after import."""
        return [p for p, e in self.elements.items() if not e['spied']]

    def code_options(self, language='csharp', references=None, imports=None, globalcode=''):
        """Declare the object-level .NET code environment. Call once if any page
        uses code() stages."""
        self.code_env = {
            'language': language,
            'references': references if references is not None else DEFAULT_REFERENCES,
            'imports': imports if imports is not None else DEFAULT_IMPORTS,
            'globalcode': globalcode,
        }
        return self

    def page(self, name, narrative, page_type='Normal', published=None):
        """Add a page. Object action pages publish by default; process subsheets
        do not. Use page_type='CleanUp' for the required first object page and
        published=False for Attach/internal helper pages."""
        if any(pg.name == name for pg in self.pages):
            raise ValueError(f'duplicate page name {name!r}')
        pg = Page(self, name, narrative, page_type=page_type, published=published)
        self.pages.append(pg)
        return pg

    def _render_processinfo(self):
        env = self.code_env
        p = [f'<stage stageid="{gid(self.name, "processinfo")}" name="Code Options" type="ProcessInfo">',
             '  <display x="-345" y="-255" w="150" h="90" />', '  <references>']
        for r in env['references']:
            p.append(f'    <reference>{esc(r)}</reference>')
        p.append('  </references>')
        p.append('  <imports>')
        for im in env['imports']:
            p.append(f'    <import>{esc(im)}</import>')
        p.append('  </imports>')
        p.append(f'  <language>{esc(env["language"])}</language>')
        # Real Blue Prism stores object-level shared code in the ProcessInfo
        # <code> element, NOT <globalcode> (verified against a real release:
        # thousands of populated <code>, zero populated <globalcode>; the shipped
        # MS Excel VBO also uses <code>). <globalcode> is present-but-empty. Code
        # placed in <globalcode> is ignored by BP, so shared helpers/fields would
        # be missing and every code stage referencing them fails to compile.
        p.append('  <globalcode><![CDATA[]]></globalcode>')
        p.append(f'  <code>{cdata(env["globalcode"])}</code>')
        p.append('</stage>')
        return '\n'.join(p)

    def render(self):
        if not self.pages:
            raise ValueError('no pages')
        uses_code = any(s['kind'] == 'code' for pg in self.pages for s in pg.steps)
        if uses_code and self.code_env is None:
            raise ValueError('code() stages present but code_options() was never called')
        pid = gid('preferredid', self.name)
        parts = ['<?xml version="1.0" encoding="utf-8"?>',
                 f'<process name="{esc(self.name)}" version="1.0" bpversion="7.2.1.15451" '
                 f'narrative="{esc(self.narrative)}" byrefcollection="true" '
                 f'processrunningmessage="" disableversioning="false" '
                 f'type="{self.ptype}" runmode="{self.runmode}" preferredid="{pid}">']
        if self.app is not None or self.model_xml is not None:
            parts.append(self._render_appdef())      # verified: first child of <process>
        if self.ptype == 'process':
            parts += ['<view><camerax>0</camerax><cameray>0</cameray>'
                      '<zoom version="2">1.00</zoom></view>',
                      '<preconditions />', '<endpoint narrative="" />']
            self.pages[0].is_main = True
        for pg in self.pages:
            if pg.is_main:
                continue
            published = str(pg.published).lower()
            parts += [f'<subsheet subsheetid="{pg.ssid}" type="{esc(pg.page_type)}" '
                      f'published="{published}">', f'  <name>{esc(pg.name)}</name>']
            if self.ptype == 'process':
                parts.append('  <view><camerax>0</camerax><cameray>0</cameray>'
                             '<zoom version="2">1.00</zoom></view>')
            parts.append('</subsheet>')
        # Object-level code environment lives on the (main) sheet as ProcessInfo.
        if self.code_env is not None:
            parts.append(self._render_processinfo())
        for pg in self.pages:
            parts.append(pg.render())
        parts.append('</process>')
        return '\n'.join(parts)

    def write(self, filename, outdir='out'):
        os.makedirs(outdir, exist_ok=True)
        path = os.path.join(outdir, filename)
        xml = self.render()
        # newline='\n' + utf-8: never let the host shell rewrite line endings or
        # re-encode; that is what corrupts BP imports (mojibake / broken CDATA).
        with open(path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(xml)
        return path


if __name__ == '__main__':
    print('bp_gen module loaded')
