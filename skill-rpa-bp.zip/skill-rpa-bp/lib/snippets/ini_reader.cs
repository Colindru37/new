// Code stage body: read a Python-ConfigParser INI into a Section/Key/Value collection.
// Inputs:  Config_Path (text)          Outputs: Config (collection), Error_Text (text)
// Semantics match Python's configparser (BasicInterpolation) for what bot INIs use:
//   [section] headers; '#' / ';' full-line comments; key = value or key: value (first of = or :);
//   indented non-empty lines continue the previous value (joined with "\n");
//   keys case-insensitive (stored lower-case); duplicate key in a section = error;
//   values: "%%" -> "%", "%(name)s" -> value of name in the same section or [DEFAULT]
//   (recursive, depth 10), any other '%' = error -- exactly like Python.
// Look values up with Section + lower-case Key; fall back to Section "DEFAULT".
Config = new System.Data.DataTable();
Config.Columns.Add("Section", typeof(string));
Config.Columns.Add("Key", typeof(string));
Config.Columns.Add("Value", typeof(string));
Error_Text = "";
try
{
    var raw = new System.Collections.Generic.Dictionary<string, string>();   // "section|key" -> raw value
    var order = new System.Collections.Generic.List<string>();
    string section = null, lastId = null;
    foreach (string line0 in System.IO.File.ReadAllLines(Config_Path))
    {
        string line = line0.TrimEnd();
        string t = line.TrimStart();
        if (t.Length == 0) { lastId = null; continue; }
        if (t[0] == '#' || t[0] == ';') continue;
        if (line.Length > 0 && (line[0] == ' ' || line[0] == '\t') && lastId != null)
        { raw[lastId] = raw[lastId] + "\n" + t; continue; }
        if (t[0] == '[' && t.EndsWith("]")) { section = t.Substring(1, t.Length - 2).Trim(); lastId = null; continue; }
        if (section == null) { Error_Text = "Line before any [section]: " + t; break; }
        int cut = -1;
        for (int i = 0; i < t.Length; i++) if (t[i] == '=' || t[i] == ':') { cut = i; break; }
        if (cut < 1) { Error_Text = "Line has no = or : : " + t; break; }
        string key = t.Substring(0, cut).Trim().ToLowerInvariant();
        string id = section + "|" + key;
        if (raw.ContainsKey(id)) { Error_Text = "Duplicate key [" + section + "] " + key; break; }
        raw[id] = t.Substring(cut + 1).Trim();
        order.Add(id); lastId = id;
    }
    System.Func<string, string, int, string> expand = null;
    expand = (sec, v, depth) =>
    {
        if (depth > 10) throw new Exception("Interpolation too deep in [" + sec + "]");
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < v.Length; i++)
        {
            if (v[i] != '%') { sb.Append(v[i]); continue; }
            if (i + 1 < v.Length && v[i + 1] == '%') { sb.Append('%'); i++; continue; }
            if (i + 1 < v.Length && v[i + 1] == '(')
            {
                int close = v.IndexOf(")s", i + 2);
                if (close < 0) throw new Exception("Bad %( in [" + sec + "]: " + v);
                string name = v.Substring(i + 2, close - i - 2).ToLowerInvariant();
                string hit;
                if (!raw.TryGetValue(sec + "|" + name, out hit) && !raw.TryGetValue("DEFAULT|" + name, out hit))
                    throw new Exception("Interpolation key '" + name + "' not found in [" + sec + "]");
                sb.Append(expand(sec, hit, depth + 1));
                i = close + 1; continue;
            }
            throw new Exception("'%' must be followed by '%' or '(' in [" + sec + "]: " + v);
        }
        return sb.ToString();
    };
    if (Error_Text == "")
        foreach (string id in order)
        {
            string sec = id.Substring(0, id.IndexOf('|'));
            string key = id.Substring(id.IndexOf('|') + 1);
            Config.Rows.Add(sec, key, expand(sec, raw[id], 0));
        }
}
catch (Exception ex) { Error_Text = "Reading config failed: " + ex.Message; }
