"""The Blue Prism internal objects as bprun simulates them: every action once, outputs and exception texts checked.
Run: python test/internal_test.py  (prints INTERNAL-TEST PASS)"""
import os, sys, datetime
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'lib'))
import bprun
from bprun import Runtime, Collection, BPException, internal_name
from decimal import Decimal

fails = []
def ok(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  | ' + str(detail)[:300]))
    if not cond:
        fails.append(name)
def throws(fn, text):
    try:
        fn(); return False
    except BPException as e:
        return text in e.detail or (text, e.detail)

logs = []
estate = {'locks': {'Held Elsewhere': 'robot 2'}, 'calendars': {'Bank': {'working_days': [0, 1, 2, 3, 4], 'holidays': ['2026-12-25']}}}
rt = Runtime([], None, {}, {'App Login': ['alice', 's3cret'], 'Api': {'username': 'svc', 'password': 'p', 'expiry': '2027-01-01', 'properties': {'Token': 'abc'}}},
             log=logs.append, queues={'Orders': {'key': 'Ref', 'attempts': 2, 'items': [{'Ref': 'A1', 'Amount': '10'}, {'Ref': 'A2', 'Amount': '20'}]}, 'Empty': []}, estate=estate)
call = rt.call_object
C = lambda rows, cols=None: Collection(cols or [(k, 'text') for k in rows[0]], rows)

# --- names
ok('internal: class names resolve', internal_name('Blueprism.Automate.clsWorkQueuesActions') == 'Work Queues' and internal_name('BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject') == 'Environment Locking'
   and internal_name('Blueprism.AutomateProcessCore.clsCollectionActions') == 'Collections' and internal_name('Blueprism.Automate.clsEventLogActions') == 'Event Log' and internal_name('Utility - Strings') is None)

# --- Work Queues
WQ = 'Blueprism.Automate.clsWorkQueuesActions'
r = call(WQ, 'Add To Queue', {'Queue Name': 'Orders', 'Data': C([{'Ref': 'B1', 'Amount': '5'}]), 'Priority': Decimal(1), 'Tags': 'urgent;de', 'Status': 'new'})
ok('wq: Add To Queue returns the ids', len(r['Item IDs'].rows) == 1 and r['Item ID'] == r['Item IDs'].rows[0]['Item ID'])
pend = call(WQ, 'Get Pending Items', {'Queue Name': 'Orders'})['Items']
ok('wq: seed items + added one are pending, keyed by the key field', [x['Key'] for x in pend.rows] == ['A1', 'A2', 'B1'] and pend.rows[2]['Tags'] == 'de;urgent', pend.rows)
g = call(WQ, 'Get Next Item', {'Queue Name': 'Orders'})
ok('wq: Get Next Item takes the lowest priority number first, then the oldest', g['Key Value'] == 'A1' and g['Attempt'] == Decimal(1) and g['Data'].rows[0]['Amount'] == '10', g)
g2 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Tag Filter': '+urgent'})
ok('wq: tag filter', g2['Key Value'] == 'B1', g2)
ok('wq: locked items are listed as locked', len(call(WQ, 'Get Locked Items', {'Queue Name': 'Orders'})['Items'].rows) == 2)
g3 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Key Filter': 'nope'})
ok('wq: no match = empty id, empty data, no exception', g3['Item ID'] == '' and g3['Data'].rows == [])
call(WQ, 'Update Status', {'Item ID': g['Item ID'], 'Status': 'half'}); call(WQ, 'Tag Item', {'Item ID': g['Item ID'], 'Tag': 'seen'})
d = call(WQ, 'Get Item Data', {'Item ID': g['Item ID']})
ok('wq: Update Status / Tag Item / Get Item Data', d['Status'] == 'half' and d['Tags'] == 'seen' and d['Data'].rows[0]['Ref'] == 'A1', d)
call(WQ, 'Set Data', {'Item ID': g['Item ID'], 'Data': C([{'Ref': 'A1', 'Amount': '11'}])})
ok('wq: Set Data replaces the data', call(WQ, 'Get Item Data', {'Item ID': g['Item ID']})['Data'].rows[0]['Amount'] == '11')
call(WQ, 'Mark Completed', {'Item ID': g['Item ID']})
ok('wq: Mark Completed', [x['Key'] for x in call(WQ, 'Get Completed Items', {'Queue Name': 'Orders'})['Items'].rows] == ['A1'])
ok('wq: Mark Completed twice = not locked', throws(lambda: call(WQ, 'Mark Completed', {'Item ID': g['Item ID']}), 'is not locked') is True)
ok('wq: unknown item id', throws(lambda: call(WQ, 'Mark Completed', {'Item ID': 'xyz'}), 'No queue item found with ID xyz') is True)
me = call(WQ, 'Mark Exception', {'Item ID': g2['Item ID'], 'Exception Reason': 'boom', 'Retry': True})
ok('wq: Mark Exception with retry under max attempts gives a new pending item with the attempt count carried', me['New Item ID'] != '' and call(WQ, 'Get Item Data', {'Item ID': me['New Item ID']})['Attempts'] == Decimal(1))
g4 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders', 'Key Filter': 'B1'})
me2 = call(WQ, 'Mark Exception', {'Item ID': g4['Item ID'], 'Exception Reason': 'boom again', 'Retry': True})
ok('wq: retry stops at max attempts (2 for Orders)', g4['Attempt'] == Decimal(2) and me2['New Item ID'] == '', (g4['Attempt'], me2))
ok('wq: exception items listed with the reason', [x['Exception Reason'] for x in call(WQ, 'Get Exception Items', {'Queue Name': 'Orders'})['Items'].rows] == ['boom', 'boom again'])
g5 = call(WQ, 'Get Next Item', {'Queue Name': 'Orders'}); call(WQ, 'Defer', {'Item ID': g5['Item ID'], 'Until': '2999-01-01'})
ok('wq: a deferred item is not served', g5['Key Value'] == 'A2' and call(WQ, 'Get Next Item', {'Queue Name': 'Orders'})['Item ID'] == '')
ok('wq: Is Item In Queue by key', call(WQ, 'Is Item In Queue', {'Queue Name': 'Orders', 'Key': 'A2'})['Result'] is True and call(WQ, 'Is Item In Queue', {'Queue Name': 'Orders', 'Key': 'Z'})['Result'] is False)
rep = call(WQ, 'Get Report Data', {'Queue Name': 'Orders'})
ok('wq: Get Report Data counts', (rep['Total Items'], rep['Completed'], rep['Exceptioned'], rep['Pending']) == (4, 1, 2, 1), rep)
cp = call(WQ, 'Copy To Queue', {'Item ID': g['Item ID'], 'Queue Name': 'Empty'})
ok('wq: Copy To Queue', cp['New Item ID'] and len(call(WQ, 'Get Pending Items', {'Queue Name': 'Empty'})['Items'].rows) == 1)
dl = call(WQ, 'Delete Processed Items', {'Queue Name': 'Orders'})
ok('wq: Delete Processed Items removes completed + exceptioned', dl['Count'] == Decimal(3) and call(WQ, 'Get Report Data', {'Queue Name': 'Orders'})['Total Items'] == Decimal(1))
ok('wq: an unknown action says so', throws(lambda: call('Work Queues', 'Frobnicate', {}), 'Work Queues.Frobnicate not simulated') is True)

# --- Credentials
CR = 'Blueprism.Automate.clsCredentialsActions'
ok('cred: Get (list form)', call(CR, 'Get', {'Credentials Name': 'App Login'}) == {'Username': 'alice', 'Password': 's3cret', 'Expiry Date': ''})
ok('cred: Get (dict form) + Get Property', call(CR, 'Get', {'Credentials Name': 'Api'})['Expiry Date'] == '2027-01-01' and call(CR, 'Get Property', {'Credentials Name': 'Api', 'Property Name': 'Token'})['Property Value'] == 'abc')
ok('cred: missing', throws(lambda: call(CR, 'Get', {'Credentials Name': 'Nope'}), "Credential 'Nope' not found") is True)
call(CR, 'Set Property', {'Credentials Name': 'Api', 'Property Name': 'Token', 'Property Value': 'new'})
ok('cred: Set Property', call(CR, 'Get Property', {'Credentials Name': 'Api', 'Property Name': 'Token'})['Property Value'] == 'new')

# --- Environment Locking
EL = 'BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject'
ok('lock: acquire / query / release', call(EL, 'Acquire Lock', {'Name': 'L1', 'Comment': 'me'})['Result'] is True and call(EL, 'Query Lock', {'Name': 'L1'})['Status'] == 'Locked' and call(EL, 'Release Lock', {'Name': 'L1'})['Result'] is True and call(EL, 'Query Lock', {'Name': 'L1'})['Status'] == 'Free')
ok('lock: a lock the estate says another session holds cannot be acquired', call(EL, 'Acquire Lock', {'Name': 'Held Elsewhere'})['Result'] is False and call(EL, 'Query Lock', {'Name': 'Held Elsewhere'})['Comment'] == 'robot 2')
ok('lock: acquiring twice in the same run fails the second time', call(EL, 'Acquire Lock', {'Name': 'L2'})['Result'] is True and call(EL, 'Acquire Lock', {'Name': 'L2'})['Result'] is False)

# --- Calendars
CA = 'Blueprism.Automate.clsCalendarsActions'
ok('cal: default is Mon-Fri', call(CA, 'Is Working Day', {'Date': '2026-11-14'})['Result'] is False and call(CA, 'Is Working Day', {'Date': '2026-11-16'})['Result'] is True)
ok('cal: holidays from the estate', call(CA, 'Is Working Day', {'Calendar Name': 'Bank', 'Date': '2026-12-25'})['Result'] is False and call(CA, 'Is Working Day', {'Date': '2026-12-25'})['Result'] is True)
ok('cal: Add Working Days skips the holiday', call(CA, 'Add Working Days', {'Calendar Name': 'Bank', 'Date': '2026-12-24', 'Days': 1})['Result'] == '2026-12-28')
ok('cal: Get Working Days In Range', call(CA, 'Get Working Days In Range', {'Calendar Name': 'Bank', 'Start Date': '2026-12-21', 'End Date': '2026-12-27'})['Result'] == Decimal(4))

# --- Event Log, Data Gateways, Encryption, Collections
call('Event Log', 'Write Event', {'Event Type': 'Information', 'Message': 'hello'})
ok('event log: written to the run log', any('[event log] Information: hello' in l for l in logs))
call('Data Gateways', 'Send Custom Data', {'Data': C([{'k': 'v'}])})
ok('data gateways: logged, no exception', any('[data gateway]' in l for l in logs))
enc = call('Encryption', 'Encrypt', {'Encryption Scheme': 'Default', 'Plain Text': 'Pa$$ wörd'})
ok('encryption: round trip', call('Encryption', 'Decrypt', {'Encrypted Text': enc['Encrypted Text']})['Plain Text'] == 'Pa$$ wörd')
ok('encryption: a real Blue Prism value cannot be decrypted here (said so)', throws(lambda: call('Encryption', 'Decrypt', {'Encrypted Text': 'AQID'}), 'not produced by this run') is True)
ok('collections: Count Rows by class', call('Blueprism.AutomateProcessCore.clsCollectionActions', 'Count Rows', {'Collection': C([{'a': 1}, {'a': 2}])})['Count'] == Decimal(2))
ok('an internal object with nothing simulated says which', throws(lambda: call('Blueprism.Automate.clsSessionVariablesActions', 'Set', {}), 'Session Variables.Set not simulated') is True)
ok('a plain unknown object is still "not loaded"', throws(lambda: call('Utility - Nope', 'X', {}), "Object 'Utility - Nope' not loaded") is True)

print('INTERNAL-TEST ' + ('PASS' if not fails else 'FAIL ' + str(fails)))
sys.exit(1 if fails else 0)
