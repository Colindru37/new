// mordecai: the Application Modeller of a Blue Prism object, read and written outside Studio.
// Works on the <appdef>...</appdef> text of an export. Every edit is a splice: only the bytes of what changed move,
// the rest of the appdef (and of the file) stays exactly as Blue Prism wrote it.
//
//   find(xml)                      -> { start, end } of the appdef in an export (null when the object has none)
//   parse(appdef)                  -> { app: { mode, params }, list: [element...], byId }   (list is in file order, with depth)
//   setAttribute(appdef, id, name, { value, inuse, cmp })   rename(appdef, id, name)   remove(appdef, id)
//   add(appdef, parentId, name, { like: <element id> | kind: 'win32' | 'aa' | 'uia' | 'web' | 'html' | 'sap' | 'region' })
//   usedBy(xml)                    -> { elementId: [stage names] }
// Kinds are told apart the way the estate's own objects are (read from real exports, 2026-11-13).
(function (root) {
'use strict';
const ent = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unent = s => String(s == null ? '' : s).replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCharCode(parseInt(h, 16))).replace(/&#(\d+);/g, (m, d) => String.fromCharCode(+d)).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
function guid() { const h = '0123456789abcdef'; let g = ''; for (let i = 0; i < 36; i++) g += (i === 8 || i === 13 || i === 18 || i === 23) ? '-' : (i === 14 ? '4' : i === 19 ? h[8 + Math.floor(Math.random() * 4)] : h[Math.floor(Math.random() * 16)]); return g; }

// ---- what each spy mode records. [name, datatype, matched by default]. Parent copies and state flags are generated below. ----
const WIN32 = [['WindowText', 'text', 1], ['ClassName', 'text', 1], ['CtrlID', 'number', 0], ['X', 'number', 0], ['Y', 'number', 0], ['Width', 'number', 0], ['Height', 'number', 0], ['Visible', 'flag', 1], ['ScreenVisible', 'flag', 1], ['Enabled', 'flag', 1], ['Active', 'flag', 0], ['Ordinal', 'number', 0], ['ChildCount', 'number', 0], ['AncestorsText', 'text', 0], ['AncestorCount', 'number', 0], ['TypeName', 'text', 0], ['ScreenBounds', 'text', 0], ['Style', 'number', 0]];
const WIN32_PARENT = ['WindowText', 'ClassName', 'CtrlID', 'X', 'Y', 'Width', 'Height', 'Visible', 'ScreenVisible', 'Enabled', 'Active', 'Ordinal', 'ChildCount', 'Style'];
const AA_FLAGS = ['Unavailable', 'Selected', 'Focused', 'Pressed', 'aChecked', 'Mixed', 'ReadOnly', 'Hottracked', 'Default', 'Expanded', 'Collapsed', 'Busy', 'Floating', 'Marqueed', 'Animated', 'Invisible', 'Offscreen', 'Sizeable', 'Moveable', 'SelfVoicing', 'Focusable', 'Selectable', 'Linked', 'Traversed', 'Multiselectable', 'Extselectable', 'Alert_low', 'Alert_medium', 'Alert_high'];
const AA_OWN = [['aX', 'number', 0], ['aY', 'number', 0], ['aWidth', 'number', 0], ['aHeight', 'number', 0], ['Name', 'text', 1], ['Description', 'text', 0], ['Role', 'text', 1], ['ID', 'text', 0], ['State', 'text', 0], ['Value2', 'text', 0], ['KeyboardShortcut', 'text', 0], ['DefaultAction', 'text', 0], ['ElementCount', 'number', 0], ['aAncestorCount', 'number', 0]];
const AA_PARENT = [['paX', 'number'], ['paY', 'number'], ['paWidth', 'number'], ['paHeight', 'number'], ['pName', 'text'], ['pDescription', 'text'], ['pRole', 'text'], ['pID', 'text'], ['pState', 'text'], ['pValue2', 'text'], ['pKeyboardShortcut', 'text'], ['pDefaultAction', 'text'], ['pElementCount', 'number']];
const typeOf = Object.fromEntries(WIN32.map(a => [a[0], a[1]]));
const KINDS = {
  win32: { label: 'Win32', base: 'Window', attrs: WIN32.concat(WIN32_PARENT.map(n => ['p' + n, typeOf[n], 0]), [['MatchIndex', 'number', 0], ['MatchReverse', 'flag', 0]]) },
  aa: { label: 'Active Accessibility', base: 'AAElement',
        attrs: WIN32.map(a => [a[0], a[1], a[0] === 'WindowText' || a[0] === 'ClassName' || a[0] === 'Visible' || a[0] === 'ScreenVisible' ? 1 : 0]).concat(AA_OWN, AA_FLAGS.map(f => [f, 'flag', 0]),
          AA_PARENT.map(a => [a[0], a[1], a[0] === 'pRole' ? 1 : 0]), AA_FLAGS.map(f => ['p' + (f === 'aChecked' ? 'aChecked' : f), 'flag', 0]), [['matchindex', 'number', 1], ['matchreverse', 'flag', 0]]) },
  uia: { label: 'UI Automation', base: 'UIAElement',
         attrs: [['uX', 'number', 0], ['uY', 'number', 0], ['uWidth', 'number', 0], ['uHeight', 'number', 0], ['uClassName', 'text', 1], ['uAutomationId', 'text', 0], ['uControlType', 'text', 1], ['uLocalizedControlType', 'text', 0], ['uIsPassword', 'flag', 0], ['uIsRequiredForForm', 'flag', 0], ['uName', 'text', 1], ['uOrientation', 'text', 0], ['uItemStatus', 'text', 0], ['uItemType', 'text', 0], ['uOffscreen', 'flag', 0], ['uTopLevelWindowId', 'text', 0], ['uLabeledBy', 'text', 0], ['uEnabled', 'text', 0], ['uAcceleratorKey', 'text', 0], ['uAccessKey', 'text', 0], ['uHasKeyboardFocus', 'text', 0], ['uHelpText', 'text', 0], ['uProcessId', 'text', 0], ['puControlType', 'text', 0], ['puLocalizedControlType', 'text', 0], ['puClassName', 'text', 0], ['puName', 'text', 0], ['puAutomationId', 'text', 0], ['MatchIndex', 'number', 1]] },
  web: { label: 'Browser', base: 'WebElement',
         attrs: [['wX', 'number', 0], ['wY', 'number', 0], ['wWidth', 'number', 0], ['wHeight', 'number', 0], ['wClientX', 'number', 0], ['wClientY', 'number', 0], ['wClientWidth', 'number', 0], ['wClientHeight', 'number', 0], ['wOffsetX', 'number', 0], ['wOffsetY', 'number', 0], ['wOffsetWidth', 'number', 0], ['wOffsetHeight', 'number', 0], ['wScrollX', 'number', 0], ['wScrollY', 'number', 0], ['wScrollWidth', 'number', 0], ['wScrollHeight', 'number', 0], ['wElementType', 'text', 1], ['wXPath', 'text', 1], ['wCssSelector', 'text', 0], ['wValue', 'text', 0], ['wPageAddress', 'text', 1], ['wClass', 'text', 0], ['wChildCount', 'number', 0], ['wIsEditable', 'flag', 0], ['wStyle', 'text', 0], ['wTabIndex', 'number', 0], ['wInputType', 'text', 0], ['wAccessKey', 'text', 0], ['wInnerText', 'text', 0], ['wSource', 'text', 0], ['wTargetAddress', 'text', 0], ['wAlt', 'text', 0], ['wPattern', 'text', 0], ['wRel', 'text', 0], ['wLinkTarget', 'text', 0], ['wPlaceholder', 'text', 0], ['matchindex', 'number', 0]] },
  html: { label: 'HTML (IE mode)', base: 'HTML',
          attrs: [['X', 'number', 0], ['Y', 'number', 0], ['Width', 'number', 0], ['Height', 'number', 0], ['Path', 'text', 1], ['TagName', 'text', 1], ['ClassName', 'text', 0], ['ID', 'text', 1], ['Title', 'text', 0], ['Link', 'text', 0], ['InputType', 'text', 0], ['InputIdentifier2', 'text', 0], ['AncestorCount', 'number', 0], ['Value', 'text', 0], ['Enabled', 'flag', 0], ['Checked', 'flag', 0], ['pURL', 'text', 0], ['ScreenBounds', 'text', 0], ['MatchIndex', 'number', 1], ['MatchReverse', 'flag', 0]] },
  sap: { label: 'SAP', base: 'SAPComponent', attrs: [['ID', 'text', 1], ['ComponentType', 'text', 0]] },
  region: { label: 'Region', base: 'Region',
            attrs: [['StartX', 'number', 1], ['StartY', 'number', 1], ['EndX', 'number', 1], ['EndY', 'number', 1], ['ElementSnapshot', 'image', 1], ['FontName', 'text', 1], ['LocationMethod', 'text', 1], ['RegionPosition', 'text', 1], ['ImageSearchPadding', 'text', 1], ['ColourTolerance', 'number', 1], ['Greyscale', 'flag', 1]]
              .concat(WIN32.map(a => [a[0], a[1], a[0] === 'ClassName' || a[0] === 'Visible' || a[0] === 'ScreenVisible' || a[0] === 'Enabled' ? 1 : 0]), WIN32_PARENT.map(n => ['p' + n, typeOf[n], 0]), [['MatchIndex', 'number', 1], ['MatchReverse', 'flag', 0]]) }
};
const REGION_DEFAULT = { LocationMethod: 'Coordinates', RegionPosition: 'Fixed', ImageSearchPadding: '0, 0, 0, 0', ColourTolerance: '0', Greyscale: 'False' };
const COMPARISONS = ['Equal', 'NotEqual', 'Wildcard', 'RegEx', 'Range', 'GreaterThan', 'GreaterThanOrEqual', 'LessThan', 'LessThanOrEqual'];
/// Which spy mode an element belongs to: its base type first, its attribute names when the base type is a plain one.
function kindOf(el) {
  const b = el.base || el.type || '', names = new Set(el.attrs.map(a => a.name));
  if (b === 'Application') return 'application';
  if (!el.attrs.length) return 'none';
  if (/^SAP/.test(b) || names.has('ComponentType')) return 'sap';
  if (/^UIA/.test(b) || names.has('uControlType')) return 'uia';
  if (/^Web/.test(b) || names.has('wXPath')) return 'web';
  if (names.has('ElementSnapshot') || names.has('RegionPosition') || /Region/.test(b)) return 'region';
  if (/^AA/.test(b) || names.has('Role')) return 'aa';
  if (/^HTML/.test(b) || names.has('TagName')) return 'html';
  return 'win32';
}

function find(xml) { const s = xml.indexOf('<appdef'); if (s < 0) return null; const e = xml.indexOf('</appdef>', s); return e < 0 ? null : { start: s, end: e + '</appdef>'.length }; }

/// The element tree with the offsets every edit needs. Never throws on odd content: what it does not know it leaves alone.
function parse(appdef) {
  const list = [], byId = {}, stack = [];
  const re = /<(\/?)(element|attributes|attribute|ProcessValue|id|type|basetype|datatype|diagnose|apptypeinfo)\b((?:"[^"]*"|[^>"])*?)(\/?)>/g; let m, app = { mode: '', params: [] }, curAttr = null;
  while ((m = re.exec(appdef))) {
    const close = m[1] === '/', tag = m[2], rest = m[3], self = m[4] === '/', top = stack[stack.length - 1];
    if (tag === 'apptypeinfo' && !close) {
      const e = appdef.indexOf('</apptypeinfo>', m.index); if (e < 0) continue; const body = appdef.slice(m.index, e);
      app.mode = (/<id>([^<]*)<\/id>/.exec(body) || [])[1] || ''; const rp = /<parameter>\s*<name>([^<]*)<\/name>\s*<value>([^<]*)<\/value>/g; let p; while ((p = rp.exec(body))) app.params.push({ name: unent(p[1]), value: unent(p[2]) });
      re.lastIndex = e; continue;
    }
    if (tag === 'element') {
      if (close) { const el = stack.pop(); if (el) el.end = m.index + m[0].length; continue; }
      const nm = /\bname="([^"]*)"/.exec(rest);
      const el = { name: nm ? unent(nm[1]) : '', id: '', type: '', base: '', dtype: '', attrs: [], depth: stack.length, parent: top ? top : null, children: [], start: m.index, openEnd: m.index + m[0].length, end: -1, typeAt: -1, attrsAt: null };
      if (top) top.children.push(el); list.push(el); if (!self) stack.push(el); else el.end = el.openEnd; continue;
    }
    if (!top) continue;
    if (tag === 'attributes') { if (self) top.attrsAt = { start: m.index, end: m.index + m[0].length, empty: true }; else if (!close) top.attrsAt = { start: m.index, innerStart: m.index + m[0].length, end: -1 }; else if (top.attrsAt) { top.attrsAt.innerEnd = m.index; top.attrsAt.end = m.index + m[0].length; } continue; }
    if (tag === 'attribute') {
      if (close) { if (curAttr) { curAttr.end = m.index + m[0].length; curAttr = null; } continue; }
      const g = k => { const x = new RegExp('\\b' + k + '="([^"]*)"').exec(rest); return x ? unent(x[1]) : null; };
      curAttr = { name: g('name') || '', inuse: /^true$/i.test(g('inuse') || ''), cmp: g('comparisontype') || '', type: '', value: '', start: m.index, openEnd: m.index + m[0].length, end: self ? m.index + m[0].length : -1, pv: null };
      top.attrs.push(curAttr); if (self) curAttr = null; continue;
    }
    if (tag === 'ProcessValue') { if (curAttr && !close) { const dt = /\bdatatype="([^"]*)"/.exec(rest), v = /\bvalue="([^"]*)"/.exec(rest); curAttr.type = dt ? dt[1] : ''; curAttr.value = v ? unent(v[1]) : ''; curAttr.pv = { start: m.index, end: m.index + m[0].length }; } continue; }
    if (close || self) continue;
    // id / type / basetype / datatype: the element's own only (a child's are seen while the child is on top of the stack)
    const e = appdef.indexOf('</' + tag + '>', m.index); if (e < 0) continue; const text = unent(appdef.slice(m.index + m[0].length, e));
    if (tag === 'id' && !top.id) { top.id = text.trim(); top.idEnd = e + 5; byId[top.id] = top; }
    else if (tag === 'type' && top.typeAt < 0) { top.type = text.trim(); top.typeAt = m.index; }
    else if (tag === 'basetype' && !top.base) top.base = text.trim();
    else if (tag === 'datatype' && !top.dtype) top.dtype = text.trim();
    re.lastIndex = e;
  }
  for (const el of list) el.kind = kindOf(el);
  return { app, list, byId };
}

function need(appdef, id) { const el = parse(appdef).byId[id]; if (!el) throw new Error('no element ' + id + ' in the application model'); return el; }
function setTagAttr(open, name, value) {   // value null removes it; the other attributes of the tag are not touched
  const re = new RegExp('\\s' + name + '="[^"]*"');
  if (value == null) return open.replace(re, '');
  if (re.test(open)) return open.replace(re, ' ' + name + '="' + ent(value) + '"');
  return open.replace(/(\s*\/?>)$/, ' ' + name + '="' + ent(value) + '"$1');
}
/// One attribute of one element: patch = { value?, inuse?, cmp? }. cmp '' or 'Equal' = Blue Prism's default (the attribute is not written).
function setAttribute(appdef, id, name, patch) {
  const el = need(appdef, id), at = el.attrs.find(a => a.name === name); if (!at) throw new Error('element "' + el.name + '" has no attribute ' + name);
  let out = appdef;
  if (patch.value !== undefined && at.pv) { const pv = appdef.slice(at.pv.start, at.pv.end); out = out.slice(0, at.pv.start) + setTagAttr(pv, 'value', patch.value) + out.slice(at.pv.end); }
  let open = appdef.slice(at.start, at.openEnd), o2 = open;
  if (patch.inuse !== undefined) o2 = setTagAttr(o2, 'inuse', patch.inuse ? 'True' : null);
  if (patch.cmp !== undefined) o2 = setTagAttr(o2, 'comparisontype', patch.cmp && patch.cmp !== 'Equal' ? patch.cmp : null);
  if (o2 !== open) out = out.slice(0, at.start) + o2 + out.slice(at.openEnd);   // the opening tag sits before the ProcessValue: its offsets are still good
  return out;
}
function rename(appdef, id, name) {
  if (!name || !/\S/.test(name)) throw new Error('name is empty');
  const el = need(appdef, id), open = appdef.slice(el.start, el.openEnd);
  return appdef.slice(0, el.start) + setTagAttr(open, 'name', name.trim()) + appdef.slice(el.openEnd);
}
/// Remove an element and everything under it.
function remove(appdef, id) {
  const el = need(appdef, id); if (!el.parent) throw new Error('the application itself cannot be removed');
  let s = el.start; while (s > 0 && /[ \t]/.test(appdef[s - 1])) s--; if (appdef[s - 1] === '\n') { s--; if (appdef[s - 1] === '\r') s--; }
  return appdef.slice(0, s) + appdef.slice(el.end);
}
function elementXml(name, id, base, dtype, attrs) {
  return '<element name="' + ent(name) + '"><id>' + id + '</id><type>' + ent(base) + '</type><basetype>' + ent(base) + '</basetype><datatype>' + ent(dtype || 'text') + '</datatype><diagnose>False</diagnose>'
    + (attrs.length ? '<attributes>' + attrs.map(a => '<attribute name="' + ent(a.name) + '"' + (a.cmp && a.cmp !== 'Equal' ? ' comparisontype="' + ent(a.cmp) + '"' : '') + (a.inuse ? ' inuse="True"' : '') + '><ProcessValue datatype="' + ent(a.type) + '" value="' + ent(a.value) + '" /></attribute>').join('') + '</attributes>' : '<attributes />') + '</element>';
}
/// A new element under parentId. opts.like = an element to copy (its type, attribute set, values and match flags: the usual way,
/// "one more like this one"); opts.kind = a blank one of that spy mode with the attributes that mode records. Returns { appdef, id }.
function add(appdef, parentId, name, opts) {
  opts = opts || {}; if (!name || !/\S/.test(name)) throw new Error('name is empty');
  const model = parse(appdef), parent = model.byId[parentId]; if (!parent) throw new Error('no parent element ' + parentId);
  if (model.list.some(e => e.name.toLowerCase() === name.trim().toLowerCase())) throw new Error('an element named "' + name.trim() + '" already exists');
  const id = guid(); let xml;
  if (opts.like) {
    const src = model.byId[opts.like]; if (!src) throw new Error('no element ' + opts.like + ' to copy');
    xml = elementXml(name.trim(), id, src.base || src.type, src.dtype, src.attrs);
    if (src.type && src.type !== src.base) xml = xml.replace('<type>' + ent(src.base) + '</type>', '<type>' + ent(src.type) + '</type>');
  } else {
    const k = KINDS[opts.kind]; if (!k) throw new Error('unknown kind ' + opts.kind);
    xml = elementXml(name.trim(), id, opts.base || k.base, 'text', k.attrs.map(a => ({ name: a[0], type: a[1], inuse: !!a[2], cmp: '',
      value: opts.kind === 'region' && REGION_DEFAULT[a[0]] != null ? REGION_DEFAULT[a[0]] : a[1] === 'flag' ? (/Visible$|Enabled$/.test(a[0]) ? 'True' : 'False') : a[1] === 'number' ? (/^(Match|match)index$/i.test(a[0]) ? '1' : '0') : '' })));
  }
  const at = parent.typeAt >= 0 ? parent.typeAt : parent.end - '</element>'.length;   // children sit between <id> and <type>
  // in a pretty-printed file the new element takes its own line: the line break + indent in front of the insert point is repeated after it
  let w = at; while (w > 0 && /[ \t]/.test(appdef[w - 1])) w--; if (appdef[w - 1] === '\n') { w--; if (appdef[w - 1] === '\r') w--; } else w = at;
  return { appdef: appdef.slice(0, at) + xml + appdef.slice(w, at) + appdef.slice(at), id };
}
/// One more attribute on an element (a spy reported something this element does not carry yet, e.g. SubType on a SAP grid).
function addAttribute(appdef, id, name, type, value, inuse) {
  const el = need(appdef, id); if (el.attrs.some(a => a.name === name)) return setAttribute(appdef, id, name, { value });
  const x = '<attribute name="' + ent(name) + '"' + (inuse ? ' inuse="True"' : '') + '><ProcessValue datatype="' + ent(type || 'text') + '" value="' + ent(value) + '" /></attribute>';
  if (!el.attrsAt) throw new Error('element "' + el.name + '" has no attribute list');
  if (el.attrsAt.empty) return appdef.slice(0, el.attrsAt.start) + '<attributes>' + x + '</attributes>' + appdef.slice(el.attrsAt.end);
  return appdef.slice(0, el.attrsAt.innerEnd) + x + appdef.slice(el.attrsAt.innerEnd);
}
/// Values from a spy (docs/copilot_mordecai_spy_handoff.md): { attributeName: value }. Only attributes the element already has are
/// written, match ticks and comparison types stay as they are, and a value marked dynamic is left alone. Returns { appdef, set, skipped }.
function fill(appdef, id, values, opts) {
  let out = appdef; const set = [], skipped = [];
  for (const name of Object.keys(values || {})) {
    const at = need(out, id).attrs.find(a => a.name === name);
    if (!at && opts && opts.addMissing && opts.addMissing.includes(name)) { out = addAttribute(out, id, name, typeof values[name] === 'boolean' ? 'flag' : typeof values[name] === 'number' ? 'number' : 'text', values[name] === true ? 'True' : values[name] === false ? 'False' : String(values[name]), false); set.push(name); continue; }
    if (!at || /^dynamic$/i.test(at.cmp)) { skipped.push(name); continue; }
    const v = values[name] === true ? 'True' : values[name] === false ? 'False' : String(values[name] == null ? '' : values[name]);
    if (v !== at.value) { out = setAttribute(out, id, name, { value: v }); set.push(name); }
  }
  return { appdef: out, set, skipped };
}
/// Which stages use which element (Navigate / Read / Write / Wait): { elementId: [stage names] }.
function usedBy(xml) {
  const out = {}; const rs = /<stage stageid="[^"]*" name="([^"]*)" type="[^"]*">([\s\S]*?)<\/stage>/g; let s;
  while ((s = rs.exec(xml))) { const seen = new Set(); const re = /<element id="([^"]+)"/g; let e; while ((e = re.exec(s[2]))) { if (seen.has(e[1])) continue; seen.add(e[1]); (out[e[1]] = out[e[1]] || []).push(unent(s[1])); } }
  return out;
}

const api = { find, parse, kindOf, setAttribute, addAttribute, rename, remove, add, fill, usedBy, guid, KINDS, COMPARISONS };
if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.MORDECAI = api;
})(typeof window !== 'undefined' ? window : this);
