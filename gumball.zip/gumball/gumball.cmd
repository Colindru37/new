@echo off
rem Double-click: starts gumball and opens it in the browser. Keep the window open while you work.
node "%~dp0gumball.js" %*
if errorlevel 1 pause
