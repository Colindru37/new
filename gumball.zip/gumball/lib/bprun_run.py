"""gumball's Run: extract every object's code-stage class, start a stage host when one can be built here, run bprun.

python bprun_run.py --xml <dir> [<dir>...] --run "<process>" [--action <name> --inputs '<json>'] [--env env.json] --json out.json [--bp <Blue Prism folder>]

Stage host, in this order: Windows -> stage_host.ps1 (Add-Type, in-process, nothing written to disk but .cs files);
elsewhere with mcs + mono -> a host built in the run folder; neither -> no host, bprun skips Code stages and says so.
"""
import sys, os, json, glob, shutil, subprocess, argparse
import xml.etree.ElementTree as ET
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import compile_check as cc
import bprun


def extract(xml_dirs, out, ref_dirs):
    """One .cs per object/process with code; returns (count, refs, problems)."""
    os.makedirs(out, exist_ok=True)
    refs, problems, n, seen = set(), [], 0, set()
    for d in xml_dirs:
        for p in sorted(glob.glob(os.path.join(d, '*.xml'))):
            try:
                root = bprun.parse_xml(p)
            except ET.ParseError as e:
                problems.append(f'{os.path.basename(p)}: {e}'); continue
            cc.strip_ns(root)
            name = root.get('name') or os.path.basename(p)
            if name in seen:
                continue           # two copies of one object (a release can carry both): the first one hosts the code
            seen.add(name)
            src, lang, cnt, _ = cc.build_source(root, name)
            if src is None:
                continue
            if lang != 'csharp':
                problems.append(f'{name}: {lang} code stages cannot be hosted (C# only)'); continue
            r, missing = cc.resolve_refs(root, ref_dirs)
            refs.update(r)
            for m in missing:
                problems.append(f'{name}: reference {m} not found (code stages that need it will fail)')
            with open(os.path.join(out, f'{n:02d}_{cc.ident(name)}.cs'), 'w', encoding='utf-8') as f:
                f.write(src)
            n += 1
    return n, sorted(refs), problems


def host_for(srcdir, refs, workdir):
    """A command list for the stage host, or (None, why)."""
    shutil.copy(os.path.join(HERE, 'StageServer.cs'), os.path.join(srcdir, 'zz_StageServer.cs'))
    reffile = os.path.join(workdir, 'refs.txt')
    with open(reffile, 'w', encoding='utf-8') as f:
        f.write('\n'.join(refs))
    if os.name == 'nt':
        ps = shutil.which('powershell') or shutil.which('pwsh')
        if not ps:
            return None, 'PowerShell not found'
        return [ps, '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', os.path.join(HERE, 'stage_host.ps1'), srcdir, reffile], ''
    mcs, mono = shutil.which('mcs'), shutil.which('mono')
    if not (mcs and mono):
        return None, 'no C# compiler here (mcs + mono): code stages skipped'
    out = os.path.join(workdir, 'stage_host.bin')
    cmd = [mcs, '-langversion:5', '-nowarn:0162,0168,0219,0414,0649', '-target:exe', '-out:' + out] + ['-r:' + r for r in refs] + sorted(glob.glob(os.path.join(srcdir, '*.cs')))
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return None, 'stage host did not compile:\n' + (r.stdout + r.stderr).strip()[:2000]
    return [mono, out], ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--xml', nargs='+', required=True)
    ap.add_argument('--run', required=True)
    ap.add_argument('--action')
    ap.add_argument('--inputs')
    ap.add_argument('--env')
    ap.add_argument('--json', required=True)
    ap.add_argument('--bp', help='Blue Prism install folder (for referenced DLLs)')
    ap.add_argument('--no-host', action='store_true', help='skip code stages even if a host could be built')
    a = ap.parse_args()
    work = os.path.dirname(os.path.abspath(a.json))
    srcdir = os.path.join(work, 'src')
    ref_dirs = [a.bp] if a.bp and os.path.isdir(a.bp) else []
    n, refs, problems = extract(a.xml, srcdir, ref_dirs)
    host, why = (None, 'code stages skipped on request') if a.no_host else ((None, 'no code stages') if n == 0 else host_for(srcdir, refs, work))
    cmd = [sys.executable, '-I', os.path.join(HERE, 'bprun.py'), '--xml'] + a.xml + ['--run', a.run, '--json', a.json]
    if a.action:
        cmd += ['--action', a.action]
    if a.inputs:
        cmd += ['--inputs', a.inputs]
    if a.env:
        cmd += ['--env', a.env]
    if host:
        cmd += ['--server-cmd', json.dumps(host)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    try:
        with open(a.json, encoding='utf-8') as f:
            res = json.load(f)
    except Exception:
        res = {'ok': False, 'exception': {'type': 'bprun', 'detail': (r.stdout + r.stderr).strip()[-3000:], 'stage': ''}, 'log': []}
    res['host'] = {'code_objects': n, 'used': bool(host), 'note': why, 'problems': problems}
    if r.stderr.strip() and not res.get('ok'):
        res['stderr'] = r.stderr.strip()[-3000:]
    with open(a.json, 'w', encoding='utf-8') as f:
        json.dump(res, f)
    print('HOST:', 'yes' if host else 'no (' + why + ')', '| RESULT:', 'ok' if res.get('ok') else 'failed')
    sys.exit(0)


if __name__ == '__main__':
    main()
