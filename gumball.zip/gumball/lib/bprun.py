"""bprun -- a flow interpreter for the Blue Prism XML our generator emits.

Runs processes and objects end to end on this machine: every Action stage calls the real object
page, every Code stage runs the real C# in the stage host (the exact source compile_check gates),
decisions/calculations use a Blue Prism expression evaluator, loops, choices, waits, blocks with
Recover/Resume and the recovery-mode functions all behave as in Blue Prism. Work Queues and
Credentials are simulated in Python. Not a Blue Prism replacement: a way to execute the flows
against mock applications before the laptop ever sees them.

Usage (library): see run_e2e.py. CLI: python bprun.py --xml DIR... [--server <stage host> | --server-cmd '<json list>']
                                      [--env env.json] --run "<process name>" [--action <name> --inputs '<json>'] [--json out.json]
Without a stage host, Code stages are skipped (logged, outputs left at their defaults) so the flow still runs.
"""
import sys, os, json, re, subprocess, time, glob, uuid, datetime, fnmatch, base64
from decimal import Decimal, InvalidOperation
import xml.etree.ElementTree as ET


# =========================================================================================
class BPException(Exception):
    def __init__(self, etype, detail, stage=''):
        super().__init__(f'{etype}: {detail}')
        self.etype, self.detail, self.stage = etype, detail, stage


class Collection:
    """A Blue Prism collection: typed columns, rows of dicts, a current-row pointer."""
    def __init__(self, columns=None, rows=None):
        self.columns = list(columns or [])          # [(name, type)]
        self.rows = list(rows or [])                # [dict]
        self.current = 0

    @staticmethod
    def from_json(d):
        if not d:
            return Collection()
        return Collection([(c['name'], c.get('type', 'string')) for c in d.get('columns', [])], d.get('rows', []))

    def to_json(self):
        return {'columns': [{'name': n, 'type': t} for n, t in self.columns], 'rows': self.rows}

    def field(self, name):
        if not self.rows:
            raise BPException('System Exception', 'Internal : The collection has no current row')   # real text (bank CSV 2026-10-22)
        row = self.rows[min(self.current, len(self.rows) - 1)]
        if name not in row:
            raise BPException('System Exception', f'Field {name!r} not in collection (columns: {[c for c, _ in self.columns]})')
        v = row[name]
        if v is None:
            return ''
        ty = dict(self.columns).get(name, 'string')
        if ty in ('decimal', 'double', 'int'):
            return Decimal(str(v))
        return v

    def __repr__(self):
        return f'<Collection {len(self.rows)} rows {[c for c, _ in self.columns]}>'


# =========================================================================================
class Expr:
    """Blue Prism expression evaluator (the subset the generated flows use)."""
    TOK = re.compile(r'''\s*(?:("(?:[^"]|"")*")|(\[[^\]]+\])|(\d+(?:\.\d+)?)|(<>|<=|>=|[=<>&+\-*/(),])|([A-Za-z_][A-Za-z0-9_]*))''')

    def __init__(self, runtime, frame):
        self.rt, self.frame = runtime, frame

    def tokens(self, s):
        pos, out = 0, []
        s = s.strip()
        while pos < len(s):
            m = self.TOK.match(s, pos)
            if not m or m.end() == pos:
                raise BPException('System Exception', f'Cannot tokenise expression at {s[pos:pos+20]!r} in {s!r}')
            pos = m.end()
            if m.group(1) is not None:
                out.append(('str', m.group(1)[1:-1].replace('""', '"')))
            elif m.group(2) is not None:
                out.append(('ref', m.group(2)[1:-1]))
            elif m.group(3) is not None:
                out.append(('num', Decimal(m.group(3))))
            elif m.group(4) is not None:
                out.append(('op', m.group(4)))
            else:
                out.append(('id', m.group(5)))
        return out

    def eval(self, s):
        self.t = self.tokens(s)
        self.i = 0
        v = self.p_or()
        if self.i != len(self.t):
            raise BPException('System Exception', f'Trailing tokens in expression {s!r}')
        return v

    def peek(self, kind=None, val=None):
        if self.i >= len(self.t):
            return None
        k, v = self.t[self.i]
        if kind and k != kind:
            return None
        if val is not None and (v if k != 'id' else v.upper()) != val:
            return None
        return v

    def take(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def p_or(self):
        v = self.p_and()
        while self.peek('id', 'OR') is not None:
            self.take(); r = self.p_and(); v = bool(v) or bool(r)   # always consume the right side
        return v

    def p_and(self):
        v = self.p_not()
        while self.peek('id', 'AND') is not None:
            self.take(); r = self.p_not(); v = bool(v) and bool(r)
        return v

    def p_not(self):
        if self.peek('id', 'NOT') is not None:
            self.take(); return not bool(self.p_not())
        return self.p_cmp()

    def p_cmp(self):
        v = self.p_concat()
        while self.peek('op') in ('=', '<>', '<', '>', '<=', '>='):
            op = self.take()[1]; r = self.p_concat()
            a, b = self.coerce_pair(v, r)
            v = {'=': a == b, '<>': a != b, '<': a < b, '>': a > b, '<=': a <= b, '>=': a >= b}[op]
        return v

    def p_concat(self):
        v = self.p_add()
        while self.peek('op') == '&':
            self.take(); r = self.p_add(); v = self.text(v) + self.text(r)
        return v

    def p_add(self):
        v = self.p_mul()
        while self.peek('op') in ('+', '-'):
            op = self.take()[1]; r = self.p_mul()
            v = self.num(v) + self.num(r) if op == '+' else self.num(v) - self.num(r)
        return v

    def p_mul(self):
        v = self.p_unary()
        while self.peek('op') in ('*', '/'):
            op = self.take()[1]; r = self.p_unary()
            v = self.num(v) * self.num(r) if op == '*' else self.num(v) / self.num(r)
        return v

    def p_unary(self):
        if self.peek('op') == '-':
            self.take(); return -self.num(self.p_unary())
        return self.p_atom()

    def p_atom(self):
        k, v = self.take()
        if k == 'str':
            return v
        if k == 'num':
            return v
        if k == 'ref':
            return self.frame.get(v)
        if k == 'op' and v == '(':
            r = self.p_or()
            if self.take() != ('op', ')'):
                raise BPException('System Exception', 'Expected )')
            return r
        if k == 'id':
            if v.upper() == 'TRUE':
                return True
            if v.upper() == 'FALSE':
                return False
            if self.peek('op') == '(':
                self.take(); args = []
                if self.peek('op') != ')':
                    args.append(self.p_or())
                    while self.peek('op') == ',':
                        self.take(); args.append(self.p_or())
                if self.take() != ('op', ')'):
                    raise BPException('System Exception', f'Expected ) after {v}(')
                return self.call(v, args)
        raise BPException('System Exception', f'Unexpected token {k} {v!r}')

    def num(self, v):
        if isinstance(v, bool):
            raise BPException('System Exception', 'Flag used as number')
        if isinstance(v, Decimal):
            return v
        try:
            return Decimal(str(v).strip())
        except InvalidOperation:
            raise BPException('System Exception', f'Not a number: {v!r}')

    def text(self, v):
        if isinstance(v, bool):
            return 'True' if v else 'False'
        if isinstance(v, Decimal):
            return fmt_num(v)
        return '' if v is None else str(v)

    def coerce_pair(self, a, b):
        if isinstance(a, bool) or isinstance(b, bool):
            return bool(a), bool(b)
        if isinstance(a, Decimal) or isinstance(b, Decimal):
            return self.num(a), self.num(b)
        return self.text(a), self.text(b)

    def call(self, name, args):
        n = name.lower()
        if n == 'upper': return self.text(args[0]).upper()
        if n == 'lower': return self.text(args[0]).lower()
        if n == 'trim': return self.text(args[0]).strip()
        if n == 'len': return Decimal(len(self.text(args[0])))
        if n == 'instr': return Decimal(self.text(args[0]).find(self.text(args[1])) + 1)
        if n == 'tonumber': return self.num(args[0])
        if n == 'isstoprequested': return self.rt.stop_requested
        if n == 'exceptiontype': return self.frame.recovery.etype if self.frame.recovery else ''
        if n == 'exceptiondetail': return self.frame.recovery.detail if self.frame.recovery else ''
        if n == 'exceptionstage': return self.frame.recovery.stage if self.frame.recovery else ''
        if n == 'now': return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if n == 'today': return datetime.date.today().isoformat()
        if n == 'hour': return Decimal(datetime.datetime.now().hour)
        if n == 'newline': return '\n'
        if n == 'replace': return self.text(args[0]).replace(self.text(args[1]), self.text(args[2]))
        if n == 'left': return self.text(args[0])[:int(self.num(args[1]))]
        if n == 'right':
            k = int(self.num(args[1])); t = self.text(args[0])
            return t[-k:] if k > 0 else ''
        if n == 'mid':
            s, start = self.text(args[0]), int(self.num(args[1]))
            return s[start - 1:start - 1 + int(self.num(args[2]))] if len(args) > 2 else s[start - 1:]
        raise BPException('System Exception', f'Unknown function {name}()')


def fmt_num(d):
    s = format(d.normalize(), 'f') if d == d.to_integral() else format(d, 'f')
    return s.rstrip('0').rstrip('.') if '.' in s else s


# =========================================================================================
class Frame:
    """One page execution: its data items, loop state, recovery state."""
    def __init__(self, page, parent_stage=''):
        self.page = page
        self.items = {}
        self.types = {}
        self.loops = {}            # groupid -> row index
        self.recovery = None       # BPException while in recovery mode (Recover..Resume)
        self.parent_stage = parent_stage
        for st in page.stages.values():
            if st.type in ('Data', 'Collection'):
                self.types[st.name] = st.datatype
                self.items[st.name] = initial_value(st.datatype, st.initial, st.exposure, page.proc.rt, st.name)

    def get(self, ref):
        if '.' in ref:
            coll, field = ref.split('.', 1)
            c = self.items.get(coll)
            if not isinstance(c, Collection):
                raise BPException('System Exception', f'[{coll}] is not a collection on page {self.page.name!r}')
            return c.field(field)
        if ref not in self.items:
            obj = self.page.proc.object_items
            if ref in obj:
                return obj[ref]
            raise BPException('System Exception', f'Data item [{ref}] not found on page {self.page.name!r}')
        return self.items[ref]

    def set(self, name, value, dtype=None):
        if name not in self.items and name in self.page.proc.object_items:
            dt = dtype or self.page.proc.object_types.get(name, 'text')
            self.page.proc.object_items[name] = coerce(value, dt, name)
            return
        dtype = dtype or self.types.get(name, 'text')
        self.types.setdefault(name, dtype)
        self.items[name] = coerce(value, dtype, name)


def initial_value(dtype, initial, exposure, rt, name):
    if exposure == 'Environment':
        if name not in rt.env:
            raise BPException('System Exception', f'Environment Variable {name!r} is not defined')
        return coerce(rt.env[name], dtype, name)
    if dtype == 'collection':
        return Collection()
    if initial is None or initial == '':
        return {'number': Decimal(0), 'flag': False}.get(dtype, '')
    return coerce(initial, dtype, name)


def coerce(v, dtype, name=''):
    if dtype == 'collection':
        if isinstance(v, Collection):
            return v
        if isinstance(v, dict):
            return Collection.from_json(v)
        return Collection()
    if dtype == 'number':
        if isinstance(v, bool):
            raise BPException('System Exception', f'Flag assigned to number [{name}]')
        try:
            return Decimal(str(v).strip() or '0')
        except InvalidOperation:
            raise BPException('System Exception', f'Non-numeric value {v!r} assigned to number [{name}]')
    if dtype == 'flag':
        if isinstance(v, bool):
            return v
        return str(v).strip().lower() == 'true'
    if isinstance(v, Decimal):
        return fmt_num(v)
    if isinstance(v, bool):
        return 'True' if v else 'False'
    return '' if v is None else str(v)


def to_json_value(v):
    if isinstance(v, Collection):
        return v.to_json()
    if isinstance(v, Decimal):
        return float(v)
    return v


# =========================================================================================
class Stage:
    def __init__(self, el):
        self.el = el
        self.id = el.get('stageid')
        self.name = el.get('name')
        self.type = el.get('type')
        d = el.find('display')
        self.x = float(d.get('x', 0)) if d is not None else 0
        self.y = float(d.get('y', 0)) if d is not None else 0
        self.w = float(d.get('w', 0)) if d is not None else 0
        self.h = float(d.get('h', 0)) if d is not None else 0
        self.onsuccess = el.findtext('onsuccess')
        self.ontrue = el.findtext('ontrue')
        self.onfalse = el.findtext('onfalse')
        self.datatype = el.findtext('datatype')
        self.initial = el.findtext('initialvalue')
        self.exposure = el.findtext('exposure')
        self.groupid = el.findtext('groupid')

    def inside(self, block):
        """Stage centre inside the block rectangle (Block x,y = top-left; stage x,y = centre)."""
        return block.x <= self.x <= block.x + block.w and block.y <= self.y <= block.y + block.h


class Page:
    def __init__(self, proc, ssid, name):
        self.proc, self.ssid, self.name = proc, ssid, name
        self.stages = {}

    def start(self):
        return next(s for s in self.stages.values() if s.type == 'Start')

    def recover_for(self, stage):
        """Innermost Block containing the stage -> its Recover; else the page-level Recover."""
        all_blocks = [b for b in self.stages.values() if b.type == 'Block']

        def owner(st):          # the innermost Block containing a stage (None = page level)
            inside = [b for b in all_blocks if st.inside(b)]
            return min(inside, key=lambda b: b.w * b.h) if inside else None

        recovers = [r for r in self.stages.values() if r.type == 'Recover']
        # Blue Prism: Blocks never nest (validation error), so the scopes are exactly
        # "inside this Block" or "the page". A Block without a Recover falls to the page's.
        for b in (owner(stage), None):
            for r in recovers:
                if owner(r) is b:
                    return r
        return None


def parse_xml(path):
    """Blue Prism exports may carry raw control characters (a 0x1B in a narrative was seen in a real release): dropped before parsing."""
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read()
    return ET.fromstring(re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text.lstrip('\ufeff')))


class ProcFile:
    def __init__(self, rt, path):
        self.rt = rt
        root = parse_xml(path)
        for el in root.iter():
            if '}' in el.tag:
                el.tag = el.tag.split('}', 1)[1]
        self.name = root.get('name')
        self.ptype = root.get('type')
        self.pages = {}
        names = {}
        for st in root.iter('stage'):
            if st.get('type') == 'SubSheetInfo':
                names[st.findtext('subsheetid')] = st.get('name')
        for ssid, nm in names.items():
            self.pages[nm] = Page(self, ssid, nm)
        if self.ptype == 'process':
            self.pages['Main'] = Page(self, None, 'Main')
        byid = {ssid: pg for pg in self.pages.values() for ssid in [pg.ssid]}
        for st in root.iter('stage'):
            s = Stage(st)
            ssid = st.findtext('subsheetid')
            pg = byid.get(ssid)
            if pg is None:
                continue
            pg.stages[s.id] = s
        self.by_ssid = byid
        # Object-level data items (Initialise page of an object, no subsheetid): one instance per object per
        # session in Blue Prism, visible to every action page, values persist between action calls.
        self.object_items, self.object_types = {}, {}
        if self.ptype == 'object':
            for st in root.iter('stage'):
                if st.get('type') in ('Data', 'Collection') and not st.findtext('subsheetid'):
                    s = Stage(st)
                    self.object_types[s.name] = s.datatype
                    self.object_items[s.name] = initial_value(s.datatype, s.initial, s.exposure, rt, s.name)
        # Application Modeller: element id -> element name (the mock app is keyed by name)
        self.elements = {}
        appdef = root.find('appdef')
        if appdef is not None:
            for el in appdef.iter('element'):
                eid = el.findtext('id')
                if eid:
                    self.elements[eid] = el.get('name')
            top = appdef.find('element')
            self.app_root = top.findtext('id') if top is not None else None
        else:
            self.app_root = None


MISSING = object()   # apps={obj: {element name: MISSING}} = the element is not on screen


# =========================================================================================
class QueueItem:
    FIELDS = ('Item ID', 'Key', 'Priority', 'Status', 'Tags', 'Attempts', 'Created', 'Last Updated', 'Deferred Until', 'Exception Reason')

    def __init__(self, queue, data, key, priority=0, tags=(), status='', defer=None):
        now = datetime.datetime.now()
        self.id, self.queue, self.data, self.key = str(uuid.uuid4()), queue, data, key
        self.priority, self.tags, self.status = int(priority or 0), set(t for t in tags if t), status or ''
        self.attempts, self.locked, self.exception, self.deferred = 0, False, '', defer
        self.created = self.updated = now
        self.finished = None
        self.state = 'Pending'            # Pending | Completed | Exception

    def touch(self):
        self.updated = datetime.datetime.now()

    def row(self):
        return {'Item ID': self.id, 'Key': self.key, 'Priority': Decimal(self.priority), 'Status': self.status, 'Tags': ';'.join(sorted(self.tags)),
                'Attempts': Decimal(self.attempts), 'Created': self.created.strftime('%Y-%m-%d %H:%M:%S'), 'Last Updated': self.updated.strftime('%Y-%m-%d %H:%M:%S'),
                'Deferred Until': self.deferred.strftime('%Y-%m-%d %H:%M:%S') if self.deferred else '', 'Exception Reason': self.exception}


class WorkQueues:
    """Work Queues, in memory: one queue = a list of items; the key field, max attempts and seed items come from the
    estate (internal/estate.json: "queues": {name: [rows]} or {name: {"key": field, "attempts": 3, "items": [rows]}}),
    a release's own work-queue items on top. Action names / parameters are Blue Prism's documented ones; the
    exception texts are approximations until a real one is seen (the real ones go in as they are found)."""
    ITEMS_COLS = [(f, 'number' if f in ('Priority', 'Attempts') else 'text') for f in QueueItem.FIELDS]

    def __init__(self, log):
        self.queues, self.cfg, self.log = {}, {}, log

    def configure(self, name, key_field='', attempts=3):
        self.cfg[name] = {'key': key_field or '', 'attempts': int(attempts or 3)}
        self.q(name)

    def q(self, name):
        if not name:
            raise BPException('System Exception', 'Internal : No queue name supplied')
        return self.queues.setdefault(name, [])

    def _cfg(self, name):
        return self.cfg.get(name, {'key': '', 'attempts': 3})

    def _key(self, name, row):
        k = self._cfg(name)['key']
        v = row.get(k, '') if k else ''
        return '' if v is None else str(v)

    @staticmethod
    def _when(v):
        if v in (None, ''):
            return None
        if isinstance(v, datetime.datetime):
            return v
        s = str(v).strip()
        for f in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%Y-%m-%dT%H:%M:%S', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y'):
            try:
                return datetime.datetime.strptime(s[:19], f)
            except ValueError:
                pass
        raise BPException('System Exception', f'Internal : Invalid date value {s!r}')

    @staticmethod
    def _tags(v):
        return [t.strip() for t in str(v or '').replace(',', ';').split(';') if t.strip()]

    @staticmethod
    def _tag_ok(item, tag_filter):
        """Blue Prism's tag filter: "+tag" must be present, "-tag" must be absent, '*' and '?' are wildcards."""
        for t in WorkQueues._tags(tag_filter):
            want = not t.startswith('-')
            pat = t[1:] if t[0] in '+-' else t
            hit = any(fnmatch.fnmatchcase(x, pat) for x in item.tags)
            if hit != want:
                return False
        return True

    def _match(self, item, key_filter='', tag_filter=''):
        if key_filter not in (None, '') and item.key != str(key_filter):
            return False
        return self._tag_ok(item, tag_filter)

    def add(self, name, data, priority=0, tags='', status='', defer=None):
        items = self.q(name); ids = []
        for row in data.rows:
            it = QueueItem(name, Collection(data.columns, [dict(row)]), self._key(name, row), priority, self._tags(tags), status, self._when(defer))
            items.append(it); ids.append(it.id)
        self.log(f'  [queue {name}] +{len(ids)} item(s)')
        return ids

    def get_next(self, name, key_filter='', tag_filter=''):
        now = datetime.datetime.now()
        cands = [i for i in self.q(name) if i.state == 'Pending' and not i.locked and (i.deferred is None or i.deferred <= now) and self._match(i, key_filter, tag_filter)]
        if not cands:
            self.log(f'  [queue {name}] no pending item' + (f' for key {key_filter!r}' if key_filter else '') + (f' tags {tag_filter!r}' if tag_filter else ''))
            return None
        cands.sort(key=lambda i: (i.priority, i.created))      # lowest priority number first, then oldest (Blue Prism's order)
        it = cands[0]; it.locked = True; it.attempts += 1; it.touch()
        self.log(f'  [queue {name}] claimed {it.id[:8]} key={it.key!r} attempt {it.attempts}')
        return it

    def find(self, item_id):
        for items in self.queues.values():
            for it in items:
                if it.id == item_id:
                    return it
        raise BPException('System Exception', f'Internal : No queue item found with ID {item_id}')

    def _locked(self, item_id):
        it = self.find(item_id)
        if not it.locked:
            raise BPException('System Exception', f'Internal : The item {item_id} is not locked')
        return it

    def mark_completed(self, item_id):
        it = self._locked(item_id); it.state, it.locked, it.finished = 'Completed', False, datetime.datetime.now(); it.touch()
        self.log(f'  [queue {it.queue}] completed {item_id[:8]}')

    def mark_exception(self, item_id, reason, retry, keep_locked=False):
        it = self._locked(item_id); it.state, it.locked, it.exception, it.finished = 'Exception', False, reason, datetime.datetime.now(); it.touch()
        self.log(f'  [queue {it.queue}] exception {item_id[:8]} retry={retry}: {str(reason)[:120]}')
        if retry and it.attempts < self._cfg(it.queue)['attempts']:
            new = QueueItem(it.queue, Collection(it.data.columns, [dict(r) for r in it.data.rows]), it.key, it.priority, it.tags, it.status)
            new.attempts, new.locked = it.attempts, bool(keep_locked)
            self.queues[it.queue].append(new)
            self.log(f'  [queue {it.queue}] retry as {new.id[:8]} (attempt {new.attempts} of {self._cfg(it.queue)["attempts"]})')
            return new.id
        return ''

    def items(self, name, pred):
        return Collection(self.ITEMS_COLS, [i.row() for i in self.q(name) if pred(i)])

    def call(self, action, inputs):
        g = inputs.get
        if action == 'Add To Queue':
            ids = self.add(g('Queue Name'), g('Data') if isinstance(g('Data'), Collection) else Collection(), g('Priority', 0), g('Tags', ''), g('Status', ''), g('Defer Until'))
            return {'Item IDs': Collection([('Item ID', 'text')], [{'Item ID': i} for i in ids]), 'Item ID': ids[0] if ids else ''}
        if action == 'Get Next Item':
            it = self.get_next(g('Queue Name'), g('Key Filter', ''), g('Tag Filter', ''))
            if it is None:
                return {'Item ID': '', 'Data': Collection(), 'Status': '', 'Attempt': Decimal(0), 'Attempts': Decimal(0), 'Key Value': ''}
            return {'Item ID': it.id, 'Data': it.data, 'Status': it.status, 'Attempt': Decimal(it.attempts), 'Attempts': Decimal(it.attempts), 'Key Value': it.key}
        if action == 'Mark Completed':
            self.mark_completed(g('Item ID', '')); return {}
        if action == 'Mark Exception':
            return {'New Item ID': self.mark_exception(g('Item ID', ''), g('Exception Reason', ''), bool(g('Retry', False)), bool(g('Keep Locked', False)))}
        if action == 'Defer':
            it = self._locked(g('Item ID', '')); it.deferred, it.locked = self._when(g('Until')) or datetime.datetime.now(), False; it.touch()
            self.log(f'  [queue {it.queue}] deferred {it.id[:8]} until {it.deferred}'); return {}
        if action == 'Set Data':
            it = self._locked(g('Item ID', '')); d = g('Data')
            if isinstance(d, Collection):
                it.data = Collection(d.columns, [dict(r) for r in d.rows]); it.key = self._key(it.queue, d.rows[0]) if d.rows else it.key
            it.touch(); return {}
        if action == 'Get Item Data':
            it = self.find(g('Item ID', ''))
            return {'Data': it.data, 'Status': it.status, 'Tags': ';'.join(sorted(it.tags)), 'Attempts': Decimal(it.attempts), 'Key Value': it.key}
        if action == 'Update Status':
            it = self.find(g('Item ID', '')); it.status = str(g('Status', '')); it.touch(); return {}
        if action == 'Set Priority':
            it = self.find(g('Item ID', '')); it.priority = int(g('Priority', 0) or 0); it.touch(); return {}
        if action == 'Tag Item':
            it = self.find(g('Item ID', '')); it.tags.update(self._tags(g('Tag', ''))); it.touch(); return {}
        if action == 'Untag Item':
            it = self.find(g('Item ID', '')); it.tags.difference_update(self._tags(g('Tag', ''))); it.touch(); return {}
        if action == 'Unlock Item':
            it = self.find(g('Item ID', '')); it.locked = False; it.touch(); return {}
        if action == 'Is Item In Queue':
            hits = [i for i in self.q(g('Queue Name')) if i.key == str(g('Key', '')) and self._tag_ok(i, g('Tag Filter', ''))]
            return {'Result': bool(hits), 'Item ID': hits[0].id if hits else ''}
        if action == 'Get Pending Items':
            return {'Items': self.items(g('Queue Name'), lambda i: i.state == 'Pending' and not i.locked and self._match(i, g('Key Filter', ''), g('Tag Filter', '')))}
        if action == 'Get Locked Items':
            return {'Items': self.items(g('Queue Name'), lambda i: i.locked and self._match(i, g('Key Filter', ''), g('Tag Filter', '')))}
        if action in ('Get Completed Items', 'Get Exception Items'):
            want = 'Completed' if action == 'Get Completed Items' else 'Exception'
            a, b = self._when(g('Start Date')), self._when(g('End Date'))
            return {'Items': self.items(g('Queue Name'), lambda i: i.state == want and (a is None or (i.finished or i.updated) >= a) and (b is None or (i.finished or i.updated) <= b) and self._match(i, g('Key Filter', ''), g('Tag Filter', '')))}
        if action == 'Get Report Data':
            items = [i for i in self.q(g('Queue Name')) if self._match(i, g('Key Filter', ''), g('Tag Filter', ''))]
            n = lambda s: Decimal(sum(1 for i in items if i.state == s))
            return {'Total Items': Decimal(len(items)), 'Pending': n('Pending'), 'Completed': n('Completed'), 'Exceptioned': n('Exception'), 'Locked': Decimal(sum(1 for i in items if i.locked)),
                    'Items': Collection(self.ITEMS_COLS, [i.row() for i in items])}
        if action == 'Copy To Queue':
            it = self.find(g('Item ID', '')); target = g('Queue Name') or g('Target Queue Name') or g('New Queue Name') or it.queue
            ids = self.add(target, it.data, g('Priority', it.priority), g('Tags', ';'.join(it.tags)), g('Status', it.status), g('Defer Until'))
            return {'New Item ID': ids[0] if ids else ''}
        if action == 'Delete Processed Items':
            thr = self._when(g('Date Threshold') or g('Threshold')) ; items = self.q(g('Queue Name'))
            gone = [i for i in items if i.state in ('Completed', 'Exception') and (thr is None or (i.finished or i.updated) < thr)]
            for i in gone:
                items.remove(i)
            return {'Count': Decimal(len(gone)), 'Items Deleted': Decimal(len(gone))}
        raise BPException('System Exception', f'Work Queues.{action} not simulated')


class Credentials:
    """Credentials from the estate: {name: [user, pass]} or {name: {"username", "password", "expiry", "properties": {..}}}."""
    def __init__(self, creds):
        self.creds = {}
        for name, v in (creds or {}).items():
            if isinstance(v, dict):
                self.creds[name] = {'username': v.get('username', ''), 'password': v.get('password', ''), 'expiry': v.get('expiry', ''), 'properties': dict(v.get('properties', {}))}
            else:
                self.creds[name] = {'username': v[0] if len(v) > 0 else '', 'password': v[1] if len(v) > 1 else '', 'expiry': '', 'properties': {}}

    def _c(self, name):
        if name not in self.creds:
            raise BPException('System Exception', f'Internal : Credential {name!r} not found')
        return self.creds[name]

    def call(self, action, inputs):
        name = inputs.get('Credentials Name') or inputs.get('Name', '')
        if action == 'Get':
            c = self._c(name); return {'Username': c['username'], 'Password': c['password'], 'Expiry Date': c['expiry']}
        if action == 'Get Property':
            c = self._c(name); p = inputs.get('Property Name', '')
            if p not in c['properties']:
                raise BPException('System Exception', f'Internal : Property {p!r} not found on credential {name!r}')
            return {'Property Value': c['properties'][p]}
        if action == 'Set':
            c = self.creds.setdefault(name, {'username': '', 'password': '', 'expiry': '', 'properties': {}})
            c['username'] = str(inputs.get('Username', c['username'])); c['password'] = str(inputs.get('Password', c['password'])); c['expiry'] = str(inputs.get('Expiry Date', c['expiry']))
            return {}
        if action == 'Set Property':
            self._c(name)['properties'][str(inputs.get('Property Name', ''))] = str(inputs.get('Property Value', '')); return {}
        if action in ('Get Credential Names', 'List'):
            return {'Credentials': Collection([('Name', 'text')], [{'Name': n} for n in sorted(self.creds)])}
        raise BPException('System Exception', f'Credentials.{action} not simulated')


class EnvLocks:
    """Environment Locking: locks this run holds, plus locks the estate says another session holds
    (internal/estate.json "locks": {name: comment}); those can only be queried, never acquired."""
    def __init__(self, log, foreign=None):
        self.held, self.foreign, self.log = {}, dict(foreign or {}), log

    def call(self, action, inputs):
        name = str(inputs.get('Name', '') or inputs.get('Lock Name', ''))
        if action == 'Acquire Lock':
            if name in self.held or name in self.foreign:
                self.log(f'  [lock] {name!r} already held' + (' by another session' if name in self.foreign else '')); return {'Result': False, 'Acquired': False}
            self.held[name] = str(inputs.get('Comment', '')); self.log(f'  [lock] acquired {name!r}'); return {'Result': True, 'Acquired': True}
        if action == 'Release Lock':
            ok = self.held.pop(name, None) is not None; self.log(f'  [lock] released {name!r}' if ok else f'  [lock] {name!r} was not held by this session'); return {'Result': ok}
        if action == 'Query Lock':
            held = name in self.held or name in self.foreign
            return {'Result': held, 'Status': 'Locked' if held else 'Free', 'Comment': self.held.get(name, self.foreign.get(name, '')), 'Held By This Session': name in self.held}
        if action in ('Delete Lock', 'Clear Lock'):
            self.held.pop(name, None); self.foreign.pop(name, None); return {}
        if action == 'Get Locks':
            rows = [{'Name': n, 'Comment': c, 'Held By This Session': True} for n, c in self.held.items()] + [{'Name': n, 'Comment': c, 'Held By This Session': False} for n, c in self.foreign.items()]
            return {'Locks': Collection([('Name', 'text'), ('Comment', 'text'), ('Held By This Session', 'flag')], rows)}
        raise BPException('System Exception', f'Environment Locking.{action} not simulated')


class Calendars:
    """Calendars: Monday to Friday unless the estate defines one (internal/estate.json "calendars":
    {name: {"working_days": [0..6, Monday = 0], "holidays": ["YYYY-MM-DD", ...]}}). An unknown calendar name = the default."""
    def __init__(self, cfg=None):
        self.cfg = {}
        for n, c in (cfg or {}).items():
            self.cfg[n] = {'days': set(int(d) for d in c.get('working_days', [0, 1, 2, 3, 4])), 'holidays': set(str(h)[:10] for h in c.get('holidays', []))}

    @staticmethod
    def _d(v):
        if isinstance(v, datetime.datetime):
            return v.date()
        if isinstance(v, datetime.date):
            return v
        s = str(v).strip()[:10]
        for f in ('%Y-%m-%d', '%d/%m/%Y'):
            try:
                return datetime.datetime.strptime(s, f).date()
            except ValueError:
                pass
        raise BPException('System Exception', f'Internal : Invalid date value {v!r}')

    def working(self, cal, d):
        c = self.cfg.get(cal, {'days': {0, 1, 2, 3, 4}, 'holidays': set()})
        return d.weekday() in c['days'] and d.isoformat() not in c['holidays']

    def call(self, action, inputs):
        cal = str(inputs.get('Calendar Name', '') or inputs.get('Calendar', ''))
        d = self._d(inputs.get('Date') or inputs.get('Start Date') or datetime.date.today())
        if action == 'Is Working Day':
            return {'Result': self.working(cal, d)}
        if action in ('Get Next Working Day', 'Get Previous Working Day', 'Add Working Days'):
            n = int(inputs.get('Days', 0) or 0) if action == 'Add Working Days' else (1 if action == 'Get Next Working Day' else -1)
            step, left = (1 if n >= 0 else -1), abs(n)
            while left > 0:
                d += datetime.timedelta(days=step)
                if self.working(cal, d):
                    left -= 1
            return {'Result': d.isoformat(), 'Date': d.isoformat()}
        if action in ('Get Working Days In Range', 'Get Working Days', 'Count Working Days'):
            e = self._d(inputs.get('End Date', d)); n = 0; x = d; days = []
            while x <= e:
                if self.working(cal, x):
                    n += 1; days.append({'Date': x.isoformat()})
                x += datetime.timedelta(days=1)
            return {'Result': Decimal(n), 'Count': Decimal(n), 'Working Days': Collection([('Date', 'date')], days)}
        if action == 'Get Calendar Names':
            return {'Calendars': Collection([('Name', 'text')], [{'Name': n} for n in sorted(self.cfg)])}
        raise BPException('System Exception', f'Calendars.{action} not simulated')


class EventLog:
    """Event Log / Data Gateways: writes go to the run log (nothing leaves the run)."""
    def __init__(self, log):
        self.log, self.events = log, []

    def call(self, obj, action, inputs):
        if obj == 'Event Log' and action in ('Write Event', 'Write'):
            e = {'Type': str(inputs.get('Event Type', inputs.get('Type', 'Information'))), 'Message': str(inputs.get('Message', inputs.get('Event Message', '')))}
            self.events.append(e); self.log(f'  [event log] {e["Type"]}: {e["Message"][:200]}'); return {}
        if obj == 'Data Gateways' and action in ('Send Custom Data', 'Send'):
            d = inputs.get('Data'); self.log(f'  [data gateway] custom data: {repr(d)[:200]}'); return {}
        raise BPException('System Exception', f'{obj}.{action} not simulated')


class Encryption:
    """Encryption: a reversible stand-in (base64 of the text, tagged with the scheme name): Decrypt(Encrypt(x)) == x."""
    def call(self, action, inputs):
        scheme = str(inputs.get('Encryption Scheme', inputs.get('Scheme', 'Default')))
        if action == 'Encrypt':
            raw = str(inputs.get('Plain Text', inputs.get('Text', inputs.get('Value', '')))).encode('utf-8')
            return {'Encrypted Text': 'sim:' + scheme + ':' + base64.b64encode(raw).decode('ascii')}
        if action == 'Decrypt':
            s = str(inputs.get('Encrypted Text', inputs.get('Text', inputs.get('Value', ''))))
            if not s.startswith('sim:'):
                raise BPException('System Exception', 'Internal : The encrypted text was not produced by this run (a real Blue Prism value cannot be decrypted here)')
            return {'Plain Text': base64.b64decode(s.split(':', 2)[2]).decode('utf-8')}
        raise BPException('System Exception', f'Encryption.{action} not simulated')


INTERNAL_ALIASES = {
    'Work Queues': ('Work Queues', 'Blueprism.Automate.clsWorkQueuesActions'),
    'Credentials': ('Credentials', 'Blueprism.Automate.clsCredentialsActions'),
    'Environment Locking': ('Environment Locking', 'Blueprism.Automate.clsEnvironmentLockingActions', 'BluePrism.AutomateAppCore.clsEnvironmentLockingBusinessObject'),
    'Calendars': ('Calendars', 'Blueprism.Automate.clsCalendarsActions'),
    'Collections': ('Collections', 'Blueprism.AutomateProcessCore.clsCollectionActions'),
    'Event Log': ('Event Log',), 'Data Gateways': ('Data Gateways',), 'Encryption': ('Encryption',),
}
INTERNAL_BY_NAME = {alias.lower(): canon for canon, aliases in INTERNAL_ALIASES.items() for alias in aliases}


def internal_name(obj):
    """The canonical internal object for a name an Action stage uses (display name or .NET class), else None."""
    n = str(obj or '').lower()
    if n in INTERNAL_BY_NAME:
        return INTERNAL_BY_NAME[n]
    m = re.match(r'^blueprism\.(?:automate|automateprocesscore|automateappcore)\.cls(\w+?)(?:actions|businessobject)?$', str(obj or ''), re.I)
    if m:
        return re.sub(r'([a-z])([A-Z])', r'\1 \2', m.group(1))      # clsSessionVariablesActions -> Session Variables
    return None


def collections_call(action, inputs):
    """Collections (internal object): the row/column actions on a collection value."""
    c = inputs.get('Collection')
    if not isinstance(c, Collection):
        c = Collection()
    if action == 'Count Rows':
        return {'Count': Decimal(len(c.rows))}
    if action == 'Count Columns':
        return {'Count': Decimal(len(c.columns))}
    if action == 'Remove All Rows':
        return {'Collection': Collection(c.columns, [])}
    if action == 'Copy Rows':
        return {'Collection': Collection(c.columns, [dict(r) for r in c.rows])}
    if action == 'Add Row':
        return {'Collection': Collection(c.columns, [dict(r) for r in c.rows] + [{n: '' for n, _ in c.columns}])}
    if action == 'Remove Row':
        return {'Collection': Collection(c.columns, [dict(r) for r in c.rows[:-1]])}
    raise BPException('System Exception', f'Collections.{action} not simulated')


# =========================================================================================
class Runtime:
    def __init__(self, xml_dirs, server, env, credentials=None, log=None, wait_scale=1.0, apps=None, queues=None, estate=None):
        self.env = env
        self.trace = []        # (process, page, stage, seq) for every stage executed, in order
        self.throws = []       # (process, page, stage, type, detail) for every exception raised, innermost first
        self.skipped = []      # code stages not run (no stage host)
        # Application Modeller doubles: {object name: {element name: current value}}. A missing
        # key or MISSING value = the element is not on screen; Write/Read/Navigate then fail the
        # way Blue Prism does (System Exception, the stage name in ExceptionStage()).
        self.apps = apps if apps is not None else {}
        self.app_log = []
        self.stop_requested = False
        self.wait_scale = wait_scale
        self.logf = log or (lambda s: print(s))
        self.files = {}
        for d in xml_dirs:
            for path in sorted(glob.glob(os.path.join(d, '*.xml'))):
                pf = ProcFile(self, path)
                self.files[pf.name] = pf
        self.queues = WorkQueues(self.logf)
        for qn, spec in (queues or {}).items():
            rows = spec.get('items', []) if isinstance(spec, dict) else (spec or [])
            self.queues.configure(qn, spec.get('key', '') if isinstance(spec, dict) else '', spec.get('attempts', 3) if isinstance(spec, dict) else 3)
            if rows:
                cols = [(k, 'text') for k in rows[0].keys()]
                self.queues.add(qn, Collection(cols, [dict(r) for r in rows]))
        estate = estate or {}
        self.credentials = Credentials(credentials or {})
        self.locks = EnvLocks(self.logf, estate.get('locks', {}))
        self.calendars = Calendars(estate.get('calendars', {}))
        self.events = EventLog(self.logf)
        self.encryption = Encryption()
        # stage host: None (code stages skipped), a command list, or a path (run with mono off Windows)
        self.server = None
        if server:
            cmd = server if isinstance(server, list) else ([server] if os.name == 'nt' else ['mono', server])
            self.server = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
            self.rpc('__ping__', '', {})
        self.depth = 0
        self.stage_count = 0

    def close(self):
        if self.server is None:
            return
        try:
            self.server.stdin.close(); self.server.wait(5)
        except Exception:
            self.server.kill()

    def rpc(self, obj, stage, args):
        if self.server is None:
            self.skipped.append((obj, stage))
            self.log(f'  # code stage {stage!r} not run (no stage host): outputs left at their defaults')
            return {}
        self.server.stdin.write(json.dumps({'obj': obj, 'stage': stage, 'args': args}) + '\n')
        self.server.stdin.flush()
        line = self.server.stdout.readline()
        if not line:
            raise BPException('System Exception', 'stage server died')
        reply = json.loads(line)
        if not reply.get('ok'):
            # real Errors-Only log text (bank CSV, 2026-10-22):
            # "ERROR: Internal : Could not execute code stage because exception thrown by code stage: <ex.Message>"
            raise BPException('System Exception', 'Internal : Could not execute code stage because exception thrown by code stage: '
                              + reply.get('error', 'code stage failed'), stage)
        return reply['out']

    def log(self, msg):
        self.logf('  ' * self.depth + msg)

    # ---- running ---------------------------------------------------------------------
    def run_process(self, name, inputs=None):
        pf = self.files[name]
        if pf.ptype != 'process':
            raise ValueError(f'{name} is not a process')
        return self.run_page(pf, pf.pages['Main'], inputs or {})

    def call_object(self, obj, action, inputs):
        pf = self.files.get(obj)
        if pf is None:
            canon = internal_name(obj)
            if canon == 'Work Queues':
                return self.queues.call(action, inputs)
            if canon == 'Credentials':
                return self.credentials.call(action, inputs)
            if canon == 'Environment Locking':
                return self.locks.call(action, inputs)
            if canon == 'Calendars':
                return self.calendars.call(action, inputs)
            if canon == 'Collections':
                return collections_call(action, inputs)
            if canon in ('Event Log', 'Data Gateways'):
                return self.events.call(canon, action, inputs)
            if canon == 'Encryption':
                return self.encryption.call(action, inputs)
            if canon:
                raise BPException('System Exception', f'{canon}.{action} not simulated (Blue Prism internal object; see internal/internal.json)')
            raise BPException('System Exception', f'Object {obj!r} not loaded')
        if action not in pf.pages:
            raise BPException('System Exception', f'Object {obj!r} has no action {action!r}')
        return self.run_page(pf, pf.pages[action], inputs)

    def run_page(self, pf, page, inputs):
        self.depth += 1
        self.log(f'> {pf.name} / {page.name} {({k: (v if not isinstance(v, Collection) else repr(v)) for k, v in inputs.items()} if inputs else "")}')
        frame = Frame(page)
        start = page.start()
        for inp in start.el.iter('input'):
            nm, dest, dt = inp.get('name'), inp.get('stage'), inp.get('type')
            if nm not in inputs:
                raise BPException('System Exception', f'Input {nm!r} not supplied to {pf.name}/{page.name}')
            frame.set(dest, inputs[nm], dt)
        try:
            outputs = self.exec_page(pf, page, frame, start)
        finally:
            self.depth -= 1
        return outputs

    def exec_page(self, pf, page, frame, start):
        cur = start
        guard = 0
        while True:
            guard += 1
            self.stage_count += 1
            if guard > 200000:
                raise BPException('System Exception', f'Runaway loop on {pf.name}/{page.name}')
            self.trace.append((pf.name, page.name, cur.name, self.stage_count))
            try:
                nxt = self.exec_stage(pf, page, frame, cur)
            except BPException as ex:
                if not ex.stage:
                    ex.stage = cur.name
                if not getattr(ex, 'seen', False):
                    ex.seen = True
                    self.throws.append((pf.name, page.name, cur.name, ex.etype, ex.detail))
                rec = page.recover_for(cur)
                if rec is None or cur.type in ('Recover',):
                    raise
                if frame.recovery is not None and cur.type not in ('Resume',):
                    # already in recovery mode: a second failure propagates (Blue Prism behaviour)
                    raise
                self.log(f'  ! {ex.etype} at {cur.name!r}: {ex.detail[:200]} -> {rec.name}')
                frame.recovery = ex
                nxt = rec
                frame.recovery_from = cur
            if nxt is None:
                end = cur
                outs = {}
                for o in end.el.iter('output'):
                    outs[o.get('name')] = frame.items.get(o.get('stage'))
                self.log(f'< {page.name} {({k: (v if not isinstance(v, Collection) else repr(v)) for k, v in outs.items()} if outs else "")}')
                return outs
            cur = nxt

    def goto(self, page, sid, what):
        if sid is None:
            raise BPException('System Exception', f'{what} has no link')
        st = page.stages.get(sid)
        if st is None:
            raise BPException('System Exception', f'{what} links to unknown stage {sid}')
        return st

    def exec_stage(self, pf, page, frame, st):
        ex = Expr(self, frame)
        t = st.type
        if t in ('Start', 'Anchor'):
            return self.goto(page, st.onsuccess, st.name)
        if t == 'End':
            return None
        if t == 'Decision':
            v = ex.eval(st.el.find('decision').get('expression'))
            self.log(f'? {st.name} -> {bool(v)}')
            return self.goto(page, st.ontrue if v else st.onfalse, st.name)
        if t == 'Calculation':
            c = st.el.find('calculation')
            frame.set(c.get('stage'), ex.eval(c.get('expression')))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'MultipleCalculation':
            for c in st.el.find('steps').iter('calculation'):
                frame.set(c.get('stage'), ex.eval(c.get('expression')))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'ChoiceStart':
            for ch in st.el.find('choices').iter('choice'):
                if ex.eval(ch.get('expression')):
                    self.log(f'? {st.name} -> {ch.findtext("name")}')
                    return self.goto(page, ch.findtext('ontrue'), st.name)
            end = next(s for s in page.stages.values() if s.type == 'ChoiceEnd' and s.groupid == st.groupid)
            self.log(f'? {st.name} -> otherwise')
            return self.goto(page, end.onsuccess, end.name)
        if t == 'ChoiceEnd':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'LoopStart':
            coll = frame.get(st.el.findtext('loopdata'))
            end = next(s for s in page.stages.values() if s.type == 'LoopEnd' and s.groupid == st.groupid)
            if not coll.rows:
                return self.goto(page, end.onsuccess, end.name)
            frame.loops[st.groupid] = 0
            coll.current = 0
            return self.goto(page, st.onsuccess, st.name)
        if t == 'LoopEnd':
            start = next(s for s in page.stages.values() if s.type == 'LoopStart' and s.groupid == st.groupid)
            coll = frame.get(start.el.findtext('loopdata'))
            i = frame.loops.get(st.groupid, 0) + 1
            if i < len(coll.rows):
                frame.loops[st.groupid] = i; coll.current = i
                return self.goto(page, start.onsuccess, start.name)
            coll.current = 0
            return self.goto(page, st.onsuccess, st.name)
        if t == 'WaitStart':
            model = self.apps.get(pf.name, {})
            for ch in st.el.iter('choice'):
                name = pf.elements.get(ch.find('element').get('id'), '?')
                cond = ch.findtext('condition/id')
                exists = name in model and model[name] is not MISSING
                want = (ch.findtext('comparetype') or 'Equal') != 'NotEqual'
                if cond == 'CheckExists' and exists == want:
                    self.app_log.append((pf.name, st.name, 'wait', name, 'met'))
                    return self.goto(page, ch.findtext('ontrue'), st.name)
            secs = float(ex.num(ex.eval(st.el.findtext('timeout'))))
            time.sleep(secs * self.wait_scale)
            end = next(s for s in page.stages.values() if s.type == 'WaitEnd' and s.groupid == st.groupid)
            return self.goto(page, end.onsuccess, end.name)
        if t in ('Write', 'Read', 'Navigate'):
            model = self.apps.setdefault(pf.name, {})
            for n, step in enumerate(st.el.iter('step'), 1):
                eid = step.find('element').get('id')
                name = pf.elements.get(eid, eid)
                act = step.findtext('action/id') or ''
                if t == 'Navigate' and eid == pf.app_root and act in ('Launch', 'AttachApplication', 'ActivateApp', 'DetachApplication', 'Terminate', 'IsConnected'):
                    self.app_log.append((pf.name, st.name, 'navigate', name, act))
                    continue
                if name not in model or model[name] is MISSING:
                    self.app_log.append((pf.name, st.name, t.lower(), name, 'NOT FOUND'))
                    raise BPException('System Exception',
                                      f"Internal : Failed to perform step {n} in {t} Stage '{st.name}' on page '{page.name}' - Element not found", st.name)
                if t == 'Write':
                    model[name] = ex.text(ex.eval(step.get('expr')))
                    self.app_log.append((pf.name, st.name, 'write', name, model[name]))
                elif t == 'Read':
                    v = True if act == 'IsConnected' else model[name]
                    frame.set(step.get('stage'), v)
                    self.app_log.append((pf.name, st.name, 'read', name, v))
                else:
                    self.app_log.append((pf.name, st.name, 'navigate', name, act))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'WaitEnd':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Exception':
            e = st.el.find('exception')
            if (e.get('usecurrent') or '').lower() in ('yes', 'true') and frame.recovery is not None:
                raise BPException(frame.recovery.etype, frame.recovery.detail, frame.recovery.stage)
            raise BPException(e.get('type'), ex.text(ex.eval(e.get('detail') or '""')), st.name)
        if t == 'Recover':
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Resume':
            frame.recovery = None
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Code':
            args = {}
            for inp in st.el.iter('input'):
                args[inp.get('name')] = to_json_value(ex.eval(inp.get('expr')))
            out = self.rpc(pf.name, st.name, args)
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(out.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'Action':
            r = st.el.find('resource')
            inputs = {}
            for inp in st.el.iter('input'):
                inputs[inp.get('name')] = ex.eval(inp.get('expr'))
            try:
                outs = self.call_object(r.get('object'), r.get('action'), inputs)
            except BPException as e:
                e.stage = st.name      # Blue Prism: ExceptionStage() in the caller = the calling Action stage (estate 2026-10-23)
                raise
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(outs.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        if t == 'SubSheet':
            target = pf.by_ssid[st.el.findtext('processid')]
            inputs = {}
            for inp in st.el.iter('input'):
                inputs[inp.get('name')] = ex.eval(inp.get('expr'))
            try:
                outs = self.run_page(pf, target, inputs)
            except BPException as e:
                e.stage = st.name
                raise
            for o in st.el.iter('output'):
                frame.set(o.get('stage'), coerce(outs.get(o.get('name')), o.get('type'), o.get('stage')), o.get('type'))
            return self.goto(page, st.onsuccess, st.name)
        raise BPException('System Exception', f'Stage type {t} not supported ({st.name})')


# =========================================================================================
if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--xml', nargs='+', required=True)
    ap.add_argument('--server', help='stage host: a path (mono off Windows) or nothing = code stages skipped')
    ap.add_argument('--server-cmd', help='stage host as a JSON command list')
    ap.add_argument('--env', help='JSON file: {"environment": {name: value}, "credentials": {name: [user, pass]}, "queues": {name: [rows]}} (or a flat name -> value map)')
    ap.add_argument('--run', required=True, help='process name, or object name with --action')
    ap.add_argument('--action', help='run this action of the object named by --run')
    ap.add_argument('--inputs', help='JSON: input name -> value for the action / process')
    ap.add_argument('--json', help='write the run as JSON here (trace, throws, exception, log)')
    a = ap.parse_args()
    env = {}
    if a.env:
        with open(a.env, encoding='utf-8') as f:
            env = json.load(f)
    nested = isinstance(env, dict) and ('environment' in env or 'credentials' in env or 'queues' in env)
    lines = []
    def logboth(msg):
        lines.append(msg); print(msg)
    server = json.loads(a.server_cmd) if a.server_cmd else a.server
    inputs = json.loads(a.inputs) if a.inputs else {}
    rt = None
    result = {'ok': False, 'run': a.run, 'action': a.action}
    try:
        rt = Runtime(a.xml, server, env.get('environment', {}) if nested else env, env.get('credentials', {}) if nested else {}, log=logboth,
                     queues=env.get('queues', {}) if nested else {}, estate=env if nested else {})
        outs = rt.call_object(a.run, a.action, inputs) if a.action else rt.run_process(a.run, inputs)
        result.update(ok=True, outputs={k: to_json_value(v) for k, v in (outs or {}).items()})
        print('RUN FINISHED, stages executed:', rt.stage_count)
    except BPException as e:
        result['exception'] = {'type': e.etype, 'detail': e.detail, 'stage': e.stage}
        print(f'RUN FAILED: {e.etype} at {e.stage!r}: {e.detail}')
    except Exception as e:
        result['exception'] = {'type': type(e).__name__, 'detail': str(e), 'stage': ''}
        print(f'RUN BROKE: {type(e).__name__}: {e}')
    finally:
        if rt is not None:
            rt.close()
            result.update(stages=rt.stage_count, trace=[list(t) for t in rt.trace], throws=[list(t) for t in rt.throws], skipped=[list(t) for t in rt.skipped],
                          queues={n: [{'id': it['id'], 'status': it['status'], 'attempts': it['attempts'], 'exception': it['exception'], 'data': it['data'].rows[0] if it['data'].rows else {}} for it in items] for n, items in rt.queues.queues.items()})
        result['log'] = lines
        if a.json:
            with open(a.json, 'w', encoding='utf-8') as f:
                json.dump(result, f, default=str)
    sys.exit(0 if result['ok'] else 1)
