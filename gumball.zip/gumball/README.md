# gumball: Studio-lite for a Blue Prism export, offline, with history

gumball was called bluewindow until 2026-11. A `bluewindow.json` next to `gumball.js` is still read, and when the old
`bluewindow` folder sits next to this one the home page offers to copy its projects over (the old folder is left as it is).
Single exports come in as `.xml`, `.bpprocess` or `.bpobject` (the same XML inside); Save writes the next version in the
kind it came in as, next to the working `.xml`.

One export .xml in, one self-contained .html out: every page drawn the way Studio draws it, a properties sheet
per stage, and editing: move stages, draw links, delete, change expressions, inputs, outputs, exception type and
detail, data item type and initial value, descriptions, logging. Save produces the next version's .xml; render it
and the history grows by one .html with a diff ribbon against the previous version. Needs node only; the browser
is Edge or anything else, no network.

## Everyday use (standalone: this folder is all it needs, plus node; python for the two checks)
1. Double-click `gumball.cmd` (or run `node gumball.js`). A window stays open and Edge opens the home page.
   If .cmd files are blocked: make a desktop shortcut to `node.exe "<this folder>\gumball.js"`, or type that command.
2. Put Blue Prism exports in `inbox\` (or drag them onto the home page), as many as you like. Each one is rendered by
   itself, one after the other, and appears under Projects; the page updates live. **Open** opens a project in a new tab.
   A file that is not a process/object export stays in the inbox marked skipped. Same name again = the next version.
3. Edit, click **Save**: the next version goes straight into `projects\<name>\<name>.vN.xml`, renders, and reopens
   with the diff against the previous one. Import that .vN.xml into Blue Prism. The home page lists every project
   with its versions.
Releases: a `.bprelease` in the inbox becomes a release (home page, Releases). Its page lists every member; **Open** a
member to see/edit it like any export (its objects fill the action catalog), Save as usual, then **Build release**:
`release.vN.bprelease` = the original with only the edited members' definitions replaced, every other byte identical
(other items, BOM, line endings, odd control characters). Release checks: each Action stage of a process member must
call an object in the release (warning otherwise) and an action that object publishes (error). Blue Prism internal
objects are skipped. Links are drawn straight, as Studio does; only a link whose straight line would cross another stage gets an elbow route
around it (and two such routes never share a stretch). If no clean route exists it stays straight. Loop back-links keep their curve.
A release whose processes use every object it carries is rendered completely as it is. A release with unused objects
(e.g. one process + a whole folder of objects) is trimmed on arrival: "<name> trimmed" holds the processes and only the
objects they use (followed through), and that copy is rendered and worked on; the original stays as dropped in.
Rendering runs in the background, one member at a time, and resumes after a restart.
Inside a release every member page has a **Release** list at the top left (filter, click to go to any member; hover an
object for its actions), and an Action stage whose object is reachable has an **Open <object> / <action>** button that
opens that object on the action's page. "Objects known" only lists objects that are not members (and shows on pages
outside a release, where an object opened on its own is clickable too). All of this also works on a page opened straight
from the `projects` folder: pages link to their neighbours through each folder's `index.html` (always the newest version).
Only Save differs there: it downloads, because a file on disk cannot write to disk. Leaving unsaved changes asks first.
**Trim**: the release page shows how many objects the processes actually use (following what those objects call in
turn) and builds a release with only those (other items kept as they are, edits included). Import the built release into a DEV environment first.

**Other items** (environment variables, work queues, credentials, calendars, ... packaged in the release): listed by kind
with an **xml** link to the raw bytes. **drop** marks one for removal, the form adds an environment variable or a work
queue; both are applied by Build (count follows). A new item copies the shape of a sibling of its kind already in the
release, so every attribute Blue Prism wrote is kept and only the typed fields change. When the release carries none of
that kind the item is written in the shape Blue Prism's own exports use (env var: id = name, type + value attributes, a
description child; queue: next numeric id, name, key-field). Import the built release into DEV first.
Credentials are not authored (their secrets never travel in a release anyway).

## Mordecai: the Application Modeller

An object's page has an **Application Modeller** list at the left: the element tree of the object, each element tagged
with its spy mode (W32, AA, UIA, WEB, HTML, SAP, RGN) and greyed when no stage uses it. Click one: the sheet shows what
Blue Prism **matches on** (ticked attributes, with comparison type and value) and, folded away, everything else that was
recorded. Tick / untick, change the comparison (Equal, Wildcard, RegEx, GreaterThan, ...; one Blue Prism wrote that is not
in the list, such as dynamic, is kept), edit a value, rename. **+ one like this** adds an element with the same type,
attributes and ticks next to it; **+ blank child** adds an empty element of a chosen mode with exactly the attributes
that mode records; **remove** takes an element and what is under it out (it tells you which stages still use it).
On a served page the spy runs from the sheet: **Spy this element** counts down 5 seconds (switch to the application, hold
the mouse on the control), reads the control in the element's own mode and, after you confirm what it found, puts the
values into the element (ticks and comparison types stay; Ctrl+Z undoes it). **Spy a new element** does the same and adds
the control as a new element, inside the selected window or next to the selected control, in the mode picked in the list.
**Launch application** (on the top element) starts the application from the Path in the model; a browser object's Edge is
started with the debugging port the web spy reads through (`spyPort` in gumball.json, 9222) in a profile of its own.
The buttons show for all seven kinds, and the script reads all of them: Win32, AA, UIA, SAP (GUI Scripting), Region (two
corners, one after the other), HTML (IE mode) and Browser (the Edge started by Launch application). The formats are in
`docs\copilot_mordecai_spy_handoff.md`.
**fill from spy** takes the JSON a spy printed for a control and puts its values into the attributes. The spy is
`mordecai-spy.ps1` (Windows PowerShell, nothing installed): hover a control, press Ctrl, and it prints and copies the JSON.
`-Mode win32 | aa | uia | sap | html | web | region | point` picks the spy mode, `-Seconds 3` or `-X -Y` replace the
hotkey; a region takes `-X1 -Y1 -X2 -Y2`, web takes `-Port`. Only `attrs` is filled; `unconfirmed` lists values whose
Blue Prism format is not proven yet (CtrlID, top-level Ordinal, AA State and ID, uTopLevelWindowId, a region's
window-relative corners, HTML X/Y/Width/Height, InputIdentifier2, AncestorCount), to compare with an element Studio
spied. Password values are never read. Undo / redo and Save cover all of it; in the file only
the `<appdef>` block changes, and inside it only the bytes of what was edited (`mordecai.js`).

`node gumball.js appdef <object or release>` prints the digest: launch mode, one element per shape, attribute census.

## Run (served pages)

**Run** on a page executes the flow here, no Blue Prism needed: `lib\bprun.py` interprets the XML stage by stage
(calculations, decisions, choices, loops, collections, Action stages into the real object pages, Blocks with
Recover / Resume, Wait / Navigate / Read / Write against an empty Application Modeller double) and Code stages run
their real C# in a stage host: on Windows `lib\stage_host.ps1` compiles the code-stage classes in-process with
Add-Type (nothing is written but .cs files), elsewhere a mono build. Without a host the Code stages are skipped
and the run says so. A process runs from its Main Page (inputs asked for); an object runs one action (asked, with
its inputs). The run's trace lands on the drawing the way a Radar incident does (numbered path, the failing stage
marked), the log and the queue state show in the panel, **clear** removes the overlay. Everything about one run
is in `projects\_runs\<stamp>\` (xml used, env.json, out.json, src).

The estate is simulated: `internal\estate.json` holds environment variables, credentials and queue contents
(`{"environment": {name: value}, "credentials": {name: ["user", "pass"]}, "queues": {name: [{"Col": "v"}, ...]}}`);
inside a release its own environment variables and queues are added on top. Work Queues, Credentials, Environment
Locking, Calendars (Monday to Friday) and Collections are built in; the other internal objects fail their Action
stage with a System Exception, as a missing object would.

## internal\

What every process and object can see in Blue Prism without it being in the release: `internal.json` lists Blue
Prism's built-in objects with their actions (seeded from memory; `docs\copilot_internal_objects_handoff.md` gets the
real list out of the install, after which release checks verify their action names too) and any export of the Blue
Prism supplied objects (Utility - Strings, MS Excel VBO, ...) dropped there is known on every page and runnable.
Settings (all optional) in `gumball.json`, see `gumball.json.example`: `bp` = Blue Prism install folder for the
exact compile check (otherwise found in Program Files automatically), `with` = folders of object exports for the
action catalog, `inbox`, `projects`, `port` (7788), `browser`. No environment variables needed.
`lib\validate.py` + `lib\compile_check.py` are copies of the rpa-bp skill's (the test checks they are identical).

Scripted use, unchanged:
```
node gumball.js render "BPA Process - X.xml" [--out <folder>] [--incident incident.json] [--with <objects folder>] [--bp "<Blue Prism folder>"]
   -> <folder>/X/X.v1.xml  (copied)   <folder>/X/X.v1.html  (the editor)
node gumball.js watch <folder> [--downloads %USERPROFILE%\Downloads]
   -> every X.vN.xml the editor saved is picked up (moved out of Downloads when told) and rendered as X.vN.html
```
An .html opened straight from disk (no server) still saves as a download, as before.

Keys: V select/move, L link, D delete, A place an Action, Ctrl+Z undo, Ctrl+Y redo, Del deletes the selection, Esc cancels/closes.
The Checks button opens two columns: the live rules the browser checks while you edit (errors block Save) and
the full `validate.py --flow --estate --strict` verdict for this version, run when the page was rendered.
Each version shows what changed: added, removed, renamed, changed, moved; changed stages are outlined orange.

What the round trip guarantees: every stage keeps its original XML and only the edited parts are rewritten, so an
untouched stage is byte-identical after any number of versions, and the rest of the file (application model, code
options, page declarations) is never touched. The test proves it on a real export.

Rules checked live, errors block Save: Code Options stage present; no Code stage in a process; Decision names end
with `?`; exception types are System / Business / Runtime; exactly one Start on every page (the palette refuses a second one) and an End; every flow stage has an
outgoing link, Decisions both Yes and No; links point at stages that exist; WaitStart has its WaitEnd. Warnings:
`col_` prefix on collections, Title Case calculations, stages nothing links to. `validate.py --flow --estate --strict`
runs on every render when python and the skill lib are reachable (this folder lives in the skill, so it is).

Adding (slice 2): `+ page` makes a page with its declaration, SubSheetInfo, Start and End. The palette under the
pages lists every stage kind (templates = the verified shapes in reference/stage-schemas.md): click a kind, click
the page, the stage is there and its sheet opens; `A` is the shortcut for an Action. An Action's sheet offers the
Business Object and Action as pick-lists with the inputs/outputs the action really has, from the catalog: every
object export found next to the .xml, in the out folder, or in `--with <folder>` at render time. A Page call's
sheet offers the pages of this process, parameters from that page's Start/End. New stages are inserted after the
last stage of their page, new pages after the last declaration; the rest of the file still never moves.

Geometry (slice 3): drag on empty canvas selects many (Shift+click adds), the selection moves together and Del
removes it. A Block moves what is inside it (membership is geometric, as in Studio) and has a corner handle to
resize, so does a Note. Placing a Loop start places its Loop end with the same groupid; deleting one removes
the pair; the loop's collection is in its sheet. `- page` removes the open page, its declaration goes with it
and page calls that pointed at it turn into an error in Checks. The `?` button lists the keys.

Info boxes and code: the page info box (SubSheetInfo) and the object's Code Options (ProcessInfo) are drawn like
Studio draws them and open in the sheet: description, language, references, namespaces, shared code. On every
render of an object `compile_check.py` compiles its code stages + shared code; pass `--bp "<Blue Prism install
folder>"` (or set BP_HOME) and it uses Blue Prism's own Roslyn csc.exe and DLLs from that folder, exactly what
Studio compiles; without it a development compiler answers and the Checks panel says so. A compile failure
counts as a problem on the Checks button.

Grid: on by default, G toggles. Stages snap to Studio's 15px grid on move and resize and the dots show it. Off =
free placement; Blue Prism imports either, the grid is only how Studio looks. Shift+L toggles the light look, which
uses Blue Prism Studio's own plain shapes and colours; dark is the default. Ctrl+wheel zooms.

Not yet: new application model elements (spying stays in Studio).

Sheriff's sketch and this editor share the renderer (bpdraw.js). Sheriff ships its own frozen copy.
