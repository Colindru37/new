<#
mordecai-spy.ps1 : read ONE UI element's attributes from the screen, in the names Blue Prism stores them under.
Prints one JSON object and copies it to the clipboard. Paste it into gumball: Mordecai > element > "fill from spy".

  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode uia            # hover a control, press Ctrl
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode win32 -Seconds 3
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode aa -X 640 -Y 400
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode sap -Seconds 3      # SAP GUI Scripting
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode html -Seconds 3     # Edge IE mode
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode web -Seconds 3 -Port 9222   # Edge started by gumball
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode point -Seconds 3    # only where the mouse is
  powershell -ExecutionPolicy Bypass -File .\mordecai-spy.ps1 -Mode region -X1 425 -Y1 268 -X2 625 -Y2 328

Read-only: no click, no typing, no hook. Text is read with WM_GETTEXT (a read the system answers for the window), the
rest with the Win32 API, Active Accessibility (oleacc) or UI Automation. The C# below is compiled in memory by Add-Type.

"attrs" holds only values whose format is certain (from the handoff, or checked against elements Blue Prism spied).
"unconfirmed" holds values whose Blue Prism format is not proven yet. "fill from spy" ignores them; compare them with
an element Studio spied on the same control and report which ones match.
#>
param(
    [ValidateSet('win32', 'aa', 'uia', 'sap', 'html', 'web', 'region', 'point')][string]$Mode = 'uia',
    [int]$X = -1,
    [int]$Y = -1,
    [int]$Seconds = 0,
    [int]$X1 = -1, [int]$Y1 = -1, [int]$X2 = -1, [int]$Y2 = -1,
    [int]$Port = 9222,
    [switch]$NoClipboard
)
$ErrorActionPreference = 'Stop'

$src = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Text;
using System.Windows.Automation;

public static class MordecaiSpy
{
    // ---------------- user32 / oleacc ----------------
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; public POINT(int x, int y) { X = x; Y = y; } }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vk);
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
    [DllImport("user32.dll")] static extern IntPtr ChildWindowFromPointEx(IntPtr parent, POINT p, uint flags);
    [DllImport("user32.dll")] static extern bool ScreenToClient(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr h, ref POINT p);
    [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h, uint flags);
    [DllImport("user32.dll")] static extern IntPtr GetDesktopWindow();
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "SendMessageTimeoutW")]
    static extern IntPtr SendMessageTimeoutText(IntPtr h, uint msg, IntPtr wParam, StringBuilder lParam, uint flags, uint timeout, out IntPtr result);
    [DllImport("user32.dll", EntryPoint = "SendMessageTimeoutW")]
    static extern IntPtr SendMessageTimeoutLen(IntPtr h, uint msg, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsWindowEnabled(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int index);
    [DllImport("user32.dll")] static extern int GetDlgCtrlID(IntPtr h);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int n);
    [DllImport("oleacc.dll")] static extern int AccessibleObjectFromPoint(POINT pt, [MarshalAs(UnmanagedType.Interface)] out Accessibility.IAccessible acc, out object child);
    [DllImport("oleacc.dll")] static extern int WindowFromAccessibleObject(Accessibility.IAccessible acc, out IntPtr h);

    const uint GA_PARENT = 1, GA_ROOT = 2, GW_HWNDNEXT = 2, GW_CHILD = 5, GW_HWNDFIRST = 0;
    const uint CWP_SKIPINVISIBLE = 0x1, CWP_SKIPTRANSPARENT = 0x4, WM_GETTEXT = 0x000D, WM_GETTEXTLENGTH = 0x000E, SMTO_ABORTIFHUNG = 0x2;
    const int GWL_STYLE = -16, ES_PASSWORD = 0x20;

    // ---------------- entry points used by the script ----------------
    public static void DpiAware() { try { SetProcessDPIAware(); } catch (Exception) { } }
    public static POINT Cursor() { POINT p; GetCursorPos(out p); return p; }
    public static bool KeyDown(int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; }

    /// One element at screen point (x, y) in the given mode, as one JSON object. Never throws: failures go into "errors".
    public static int Port = 9222;   // web: Edge's debugging port on 127.0.0.1
    public static string Spy(string mode, int x, int y)
    {
        var attrs = new List<KeyValuePair<string, object>>(); var unconf = new List<KeyValuePair<string, object>>(); var errors = new List<string>();
        string name = null, b = null;
        try
        {
            if (mode == "point") return "{ \"mode\": \"point\", \"point\": { \"x\": " + x + ", \"y\": " + y + " } }";
            if (mode == "sap") Sap(x, y, attrs, unconf, errors, out name, out b);
            else if (mode == "html") Html(x, y, attrs, unconf, errors, out name, out b);
            else if (mode == "web") Web(x, y, attrs, unconf, errors, out name, out b);
            else
            if (mode == "win32") { IntPtr h = DeepestWindow(x, y); Win32(h, attrs, unconf, errors, "", true); b = Win32Base(h); name = b + " - " + Label(Text(h), Class(h)); }
            else if (mode == "aa") Aa(x, y, attrs, unconf, errors, out name, out b);
            else if (mode == "uia") Uia(x, y, attrs, unconf, errors, out name, out b);
            else errors.Add("unknown mode " + mode);
        }
        catch (Exception ex) { errors.Add(ex.GetType().Name + ": " + ex.Message); }
        return Write(mode, name, b, ", \"point\": { \"x\": " + x + ", \"y\": " + y + " }", attrs, unconf, errors);
    }
    static string Write(string mode, string name, string b, string extra, List<KeyValuePair<string, object>> attrs, List<KeyValuePair<string, object>> unconf, List<string> errors)
    {
        var sb = new StringBuilder();
        sb.Append("{ \"mode\": ").Append(J(mode)).Append(", \"name\": ").Append(J(name)).Append(", \"base\": ").Append(J(b))
          .Append(extra).Append(",\n  \"attrs\": ");
        Obj(sb, attrs);
        sb.Append(",\n  \"unconfirmed\": "); Obj(sb, unconf);
        if (errors.Count > 0) { sb.Append(",\n  \"errors\": ["); for (int i = 0; i < errors.Count; i++) sb.Append(i > 0 ? ", " : " ").Append(J(errors[i])); sb.Append(" ]"); }
        return sb.Append(" }").ToString();
    }

    // ---------------- win32 ----------------
    /// The window under the point, then down through children Windows would skip (disabled ones), invisible ones excluded.
    static IntPtr DeepestWindow(int x, int y)
    {
        IntPtr h = WindowFromPoint(new POINT(x, y));
        for (int guard = 0; h != IntPtr.Zero && guard < 50; guard++)
        {
            var p = new POINT(x, y); if (!ScreenToClient(h, ref p)) break;
            IntPtr c = ChildWindowFromPointEx(h, p, CWP_SKIPINVISIBLE | CWP_SKIPTRANSPARENT);
            if (c == IntPtr.Zero || c == h) break;
            h = c;
        }
        return h;
    }
    static string Class(IntPtr h) { var sb = new StringBuilder(256); GetClassName(h, sb, sb.Capacity); return sb.ToString(); }
    /// Blue Prism keeps the first two parts of a WinForms class ("WindowsForms10.EDIT"): the rest changes on every run.
    static string BpClass(string c)
    {
        if (c.StartsWith("WindowsForms10.", StringComparison.Ordinal)) { int i = c.IndexOf('.', "WindowsForms10.".Length); return i < 0 ? c : c.Substring(0, i); }
        return c;
    }
    static bool IsWinForms(string c) { return c.StartsWith("WindowsForms10.", StringComparison.Ordinal); }
    /// Window text by WM_GETTEXT (an edit's content too), 300 ms limit so a hung window cannot stall the spy.
    static string Text(IntPtr h)
    {
        try
        {
            IntPtr len; if (SendMessageTimeoutLen(h, WM_GETTEXTLENGTH, IntPtr.Zero, IntPtr.Zero, SMTO_ABORTIFHUNG, 300, out len) == IntPtr.Zero) return "";
            int n = Math.Min(Math.Max(len.ToInt32(), 0), 32767); if (n == 0) return "";
            var sb = new StringBuilder(n + 1); IntPtr got;
            if (SendMessageTimeoutText(h, WM_GETTEXT, new IntPtr(n + 1), sb, SMTO_ABORTIFHUNG, 300, out got) == IntPtr.Zero) return "";
            return sb.ToString();
        }
        catch (Exception) { return ""; }
    }
    static bool IsDesktop(IntPtr h) { return h == IntPtr.Zero || h == GetDesktopWindow(); }
    static int ChildCount(IntPtr h) { int n = 0; for (IntPtr c = GetWindow(h, GW_CHILD); c != IntPtr.Zero && n < 10000; c = GetWindow(c, GW_HWNDNEXT)) n++; return n; }
    /// 1-based place among the parent's children in z-order. Matches the dialogs Blue Prism spied (OK = 1, message text = 3).
    static int Ordinal(IntPtr h)
    {
        int i = 0; for (IntPtr c = GetWindow(h, GW_HWNDFIRST); c != IntPtr.Zero && i < 10000; c = GetWindow(c, GW_HWNDNEXT)) { i++; if (c == h) return i; }
        return 0;
    }
    static bool OnScreen(RECT r)
    {
        int vx = GetSystemMetrics(76), vy = GetSystemMetrics(77), vw = GetSystemMetrics(78), vh = GetSystemMetrics(79);
        return r.Right > vx && r.Bottom > vy && r.Left < vx + vw && r.Top < vy + vh;
    }

    /// The Win32 attributes of one window, with prefix "" or "p". Formats checked against Blue Prism's own spied elements:
    /// X/Y = window rect relative to the parent's client area (screen for a top-level window), Width/Height = window rect,
    /// ScreenBounds = CLIENT rect on screen as RECT:left,top,bottom,right, AncestorsText = each ancestor's text + " ", the
    /// desktop as "<UNKNOWN>", AncestorCount counts the desktop, Active = it is the foreground window.
    static void Win32(IntPtr h, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, string pre, bool withParent)
    {
        if (h == IntPtr.Zero) { err.Add("no window at the point"); return; }
        IntPtr parent = GetAncestor(h, GA_PARENT);
        bool top = IsDesktop(parent);
        string cls = Class(h);
        RECT wr; GetWindowRect(h, out wr);
        var tl = new POINT(wr.Left, wr.Top); if (!top) ScreenToClient(parent, ref tl);
        Add(a, pre + "WindowText", Text(h));
        Add(a, pre + "ClassName", BpClass(cls));
        Add(a, pre + "X", tl.X); Add(a, pre + "Y", tl.Y); Add(a, pre + "Width", wr.Right - wr.Left); Add(a, pre + "Height", wr.Bottom - wr.Top);
        bool vis = IsWindowVisible(h);
        Add(a, pre + "Visible", vis); Add(a, pre + "ScreenVisible", vis && OnScreen(wr)); Add(a, pre + "Enabled", IsWindowEnabled(h));
        Add(a, pre + "Active", h == GetForegroundWindow());
        Add(a, pre + "ChildCount", ChildCount(h));
        Add(a, pre + "Style", GetWindowLong(h, GWL_STYLE));
        if (top) Add(u, pre + "Ordinal", Ordinal(h)); else Add(a, pre + "Ordinal", Ordinal(h));   // top-level: what Blue Prism counts is not proven
        Add(u, pre + "CtrlID", GetDlgCtrlID(h));   // Blue Prism wrote 0 even for a message box OK button, so not GetDlgCtrlID as such
        if (pre.Length > 0) return;
        var anc = new StringBuilder(); int count = 0;
        for (IntPtr p = parent; count < 100; p = GetAncestor(p, GA_PARENT))
        {
            count++;
            if (IsDesktop(p)) { anc.Append("<UNKNOWN> "); break; }
            string t = Text(p); anc.Append(t.Length == 0 ? "<UNKNOWN>" : t).Append(' ');
        }
        Add(a, "AncestorsText", anc.ToString()); Add(a, "AncestorCount", count);
        if (!IsWinForms(cls)) Add(a, "TypeName", cls);   // a WinForms window's .NET type name cannot be read without writing into its process
        RECT cr; GetClientRect(h, out cr);
        var c1 = new POINT(0, 0); ClientToScreen(h, ref c1);
        Add(a, "ScreenBounds", "RECT:" + c1.X + "," + c1.Y + "," + (c1.Y + cr.Bottom) + "," + (c1.X + cr.Right));
        if (!top && withParent) Win32(parent, a, u, err, "p", false);
    }
    /// Blue Prism's Win32 element types seen in the estate: Window, Button, Edit, Password, Label, ComboBox.
    static string Win32Base(IntPtr h)
    {
        string c = BpClass(Class(h)).ToLowerInvariant();
        if (c.EndsWith("edit") || c.StartsWith("richedit")) return (GetWindowLong(h, GWL_STYLE) & ES_PASSWORD) != 0 ? "Password" : "Edit";
        if (c.EndsWith("button")) return "Button";
        if (c.EndsWith("static")) return "Label";
        if (c.EndsWith("combobox")) return "ComboBox";
        return "Window";
    }

    // ---------------- Active Accessibility ----------------
    static readonly string[] AaFlags = { "Unavailable", "Selected", "Focused", "Pressed", "aChecked", "Mixed", "ReadOnly", "Hottracked", "Default", "Expanded",
        "Collapsed", "Busy", "Floating", "Marqueed", "Animated", "Invisible", "Offscreen", "Sizeable", "Moveable", "SelfVoicing", "Focusable", "Selectable",
        "Linked", "Traversed", "Multiselectable", "Extselectable", "Alert_low", "Alert_medium", "Alert_high" };   // STATE_SYSTEM_* bits 0x1 .. 0x10000000, in order

    static void Aa(int x, int y, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, out string name, out string b)
    {
        name = null; b = "AAElement";
        Accessibility.IAccessible acc; object child;
        int hr = AccessibleObjectFromPoint(new POINT(x, y), out acc, out child);
        if (hr != 0 || acc == null) { err.Add("AccessibleObjectFromPoint failed, hr 0x" + hr.ToString("X8")); return; }
        IntPtr h = IntPtr.Zero; try { WindowFromAccessibleObject(acc, out h); } catch (Exception) { }
        if (h == IntPtr.Zero) h = DeepestWindow(x, y);
        Win32(h, a, u, err, "", false);   // the AA element type has no pWindowText etc.: its parent copies are the accessible parent's
        if (child == null) child = 0;
        int cid = child is int ? (int)child : 0;
        AaProps(acc, child, "", a, u);
        // the accessible parent: for a simple child (id > 0) the object that holds it, otherwise accParent
        Accessibility.IAccessible pacc = null; object pchild = 0;
        if (cid > 0) pacc = acc; else { try { pacc = acc.accParent as Accessibility.IAccessible; } catch (Exception) { } }
        if (pacc != null) AaProps(pacc, pchild, "p", a, u);
        int depth = cid > 0 ? 1 : 0;
        try { var p = acc; for (int i = 0; i < 100; i++) { var q = p.accParent as Accessibility.IAccessible; if (q == null) break; depth++; p = q; } } catch (Exception) { }
        Add(a, "aAncestorCount", depth);
        string role = Str(a, "Role"), nm = Str(a, "Name");
        b = role == "PushButton" ? "AAButton" : role == "Text" ? "AAEdit" : "AAElement";
        name = b + " - " + Label(nm, role);
    }
    static void AaProps(Accessibility.IAccessible acc, object child, string pre, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u)
    {
        int l = 0, t = 0, w = 0, hh = 0;
        try { acc.accLocation(out l, out t, out w, out hh, child); } catch (Exception) { }
        Add(a, pre + "aX", l); Add(a, pre + "aY", t); Add(a, pre + "aWidth", w); Add(a, pre + "aHeight", hh);
        Add(a, pre + "Name", Safe(delegate { return acc.get_accName(child); }));
        Add(a, pre + "Description", Safe(delegate { return acc.get_accDescription(child); }));
        object r = SafeObj(delegate { return acc.get_accRole(child); });
        if (r is int) Add(a, pre + "Role", RoleName((int)r)); else if (r != null) Add(a, pre + "Role", Convert.ToString(r, CultureInfo.InvariantCulture));
        Add(a, pre + "Value2", Safe(delegate { return acc.get_accValue(child); }));
        Add(a, pre + "KeyboardShortcut", Safe(delegate { return acc.get_accKeyboardShortcut(child); }));
        Add(a, pre + "DefaultAction", Safe(delegate { return acc.get_accDefaultAction(child); }));
        int kids = 0; if (!(child is int) || (int)child == 0) { try { kids = acc.accChildCount; } catch (Exception) { } }
        Add(a, pre + "ElementCount", kids);
        object st = SafeObj(delegate { return acc.get_accState(child); });
        long s = 0; if (st is int) s = (uint)(int)st; else if (st != null) long.TryParse(Convert.ToString(st, CultureInfo.InvariantCulture), out s);
        for (int i = 0; i < AaFlags.Length; i++) Add(a, pre + AaFlags[i], (s & (1L << i)) != 0);
        Add(u, pre + "State", s);                                                           // number or text in Blue Prism: not proven
        Add(u, pre + "ID", child is int ? ((int)child).ToString(CultureInfo.InvariantCulture) : "");   // child id: not proven
    }
    /// ROLE_SYSTEM_* as Blue Prism names them (Window, Client, Pane, PushButton, Text ...): the names of the same constants
    /// in System.Windows.Forms.AccessibleRole.
    static string RoleName(int r)
    {
        try { var n = Enum.GetName(typeof(System.Windows.Forms.AccessibleRole), r); if (n != null) return n; } catch (Exception) { }
        return r.ToString(CultureInfo.InvariantCulture);
    }

    // ---------------- UI Automation ----------------
    static void Uia(int x, int y, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, out string name, out string b)
    {
        name = null; b = "UIAElement";
        AutomationElement e = AutomationElement.FromPoint(new System.Windows.Point(x, y));
        if (e == null) { err.Add("no UI Automation element at the point"); return; }
        var c = e.Current;
        var r = c.BoundingRectangle;
        if (!r.IsEmpty) { Add(a, "uX", (int)Math.Round(r.X)); Add(a, "uY", (int)Math.Round(r.Y)); Add(a, "uWidth", (int)Math.Round(r.Width)); Add(a, "uHeight", (int)Math.Round(r.Height)); }
        Add(a, "uClassName", c.ClassName ?? "");
        Add(a, "uAutomationId", c.AutomationId ?? "");
        string ct = ShortType(c.ControlType);
        Add(a, "uControlType", ct);
        Add(a, "uLocalizedControlType", c.LocalizedControlType ?? "");
        Add(a, "uIsPassword", c.IsPassword);
        Add(a, "uIsRequiredForForm", c.IsRequiredForForm);
        Add(a, "uName", c.Name ?? "");
        Add(a, "uOrientation", c.Orientation.ToString());
        Add(a, "uItemStatus", c.ItemStatus ?? "");
        Add(a, "uItemType", c.ItemType ?? "");
        Add(a, "uOffscreen", c.IsOffscreen);
        try { var lb = c.LabeledBy; Add(a, "uLabeledBy", lb == null ? "" : (lb.Current.Name ?? "")); } catch (Exception) { }
        Add(a, "uEnabled", c.IsEnabled ? "True" : "False");
        Add(a, "uAcceleratorKey", c.AcceleratorKey ?? "");
        Add(a, "uAccessKey", c.AccessKey ?? "");
        Add(a, "uHasKeyboardFocus", c.HasKeyboardFocus ? "True" : "False");
        Add(a, "uHelpText", c.HelpText ?? "");
        Add(a, "uProcessId", c.ProcessId.ToString(CultureInfo.InvariantCulture));
        try
        {
            IntPtr top = GetAncestor(WindowFromPoint(new POINT(x, y)), GA_ROOT);
            Add(u, "uTopLevelWindowId", top.ToInt64().ToString(CultureInfo.InvariantCulture));   // a handle? an id? not proven
        }
        catch (Exception) { }
        try
        {
            AutomationElement p = TreeWalker.ControlViewWalker.GetParent(e);
            if (p != null)
            {
                var pc = p.Current;
                Add(a, "puControlType", ShortType(pc.ControlType)); Add(a, "puLocalizedControlType", pc.LocalizedControlType ?? "");
                Add(a, "puClassName", pc.ClassName ?? ""); Add(a, "puName", pc.Name ?? ""); Add(a, "puAutomationId", pc.AutomationId ?? "");
            }
        }
        catch (Exception ex) { err.Add("parent: " + ex.GetType().Name); }
        b = ct == "Button" ? "UIAButton" : ct == "Edit" ? "UIAEdit" : "UIAElement";
        name = b + " - " + Label(c.Name, ct);
    }
    /// "ControlType.Button" -> "Button".
    static string ShortType(ControlType t)
    {
        if (t == null) return "";
        string n = t.ProgrammaticName ?? ""; int i = n.LastIndexOf('.');
        return i < 0 ? n : n.Substring(i + 1);
    }


    // ======================================== part 2 ========================================
    // Late-bound COM (SAP GUI Scripting, the IE-mode HTML document): IDispatch through reflection, every call guarded.
    static object Get(object o, string n) { if (o == null) return null; try { return o.GetType().InvokeMember(n, BindingFlags.GetProperty, null, o, null); } catch (Exception) { return null; } }
    static object Call(object o, string n, params object[] a) { if (o == null) return null; try { return o.GetType().InvokeMember(n, BindingFlags.InvokeMethod, null, o, a); } catch (Exception) { return null; } }
    static string S(object v) { return v == null ? "" : Convert.ToString(v, CultureInfo.InvariantCulture); }
    static int N(object v) { try { return v == null ? 0 : (int)Math.Round(Convert.ToDouble(v, CultureInfo.InvariantCulture)); } catch (Exception) { return 0; } }
    static double D(object v) { try { return v == null ? 0 : Convert.ToDouble(v, CultureInfo.InvariantCulture); } catch (Exception) { return 0; } }
    static bool Bo(object v) { try { return v != null && Convert.ToBoolean(v, CultureInfo.InvariantCulture); } catch (Exception) { return false; } }

    // ---------------- sap: SAP GUI Scripting, no Win32 reading ----------------
    static object SapEngine(List<string> err)
    {
        object rot = null;
        try { var t = Type.GetTypeFromProgID("SapROTWr.SapROTWrapper"); if (t != null) rot = Call(Activator.CreateInstance(t), "GetROTEntry", "SAPGUI"); } catch (Exception) { }
        if (rot == null) try { rot = Marshal.BindToMoniker("SAPGUI"); } catch (Exception) { }
        if (rot == null) { err.Add("SAP GUI is not running, or it does not register for scripting"); return null; }
        object eng = Call(rot, "GetScriptingEngine");
        if (eng == null) err.Add("SAP GUI gave no scripting engine: scripting is disabled (client option or server parameter sapgui/user_scripting)");
        return eng;
    }
    static readonly string[,] SapBases = { { "GuiTextField", "SAPTextBox", "Textbox" }, { "GuiCTextField", "SAPTextBox", "Textbox" }, { "GuiPasswordField", "SAPPasswordField", "Password" },
        { "GuiButton", "SAPButton", "Button" }, { "GuiCheckBox", "SAPCheckBox", "Checkbox" }, { "GuiRadioButton", "SAPRadioButton", "Radio button" },
        { "GuiComboBox", "SAPComboBox", "Combobox" }, { "GuiOkCodeField", "SAPOkCodeField", "OK code" }, { "GuiStatusbar", "SAPStatusBar", "Status bar" } };
    static void Sap(int x, int y, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, out string name, out string b)
    {
        name = null; b = "SAPComponent";
        object eng = SapEngine(err); if (eng == null) return;
        object comp = null; int sessions = 0;
        object cons = Get(eng, "Children");
        for (int ci = 0; ci < N(Get(cons, "Count")) && comp == null; ci++)
        {
            object ses = Get(Call(cons, "ElementAt", ci), "Children");
            for (int si = 0; si < N(Get(ses, "Count")) && comp == null; si++)
            {
                object s = Call(ses, "ElementAt", si); if (s == null) continue; sessions++;
                object w = Get(s, "ActiveWindow");   // only the session whose window holds the point
                if (w != null)
                {
                    int l = N(Get(w, "ScreenLeft")), t = N(Get(w, "ScreenTop")), ww = N(Get(w, "Width")), hh = N(Get(w, "Height"));
                    if (ww > 0 && hh > 0 && (x < l || y < t || x >= l + ww || y >= t + hh)) continue;
                }
                object hit = Call(s, "FindByPosition", x, y, false);
                if (hit == null) continue;
                // the collection's content is not documented: take the first item that reads as a component id, then ask the session
                for (int k = 0; k < N(Get(hit, "Count")) && comp == null; k++)
                {
                    string id = S(Call(hit, "ElementAt", k));
                    if (id.IndexOf("wnd[", StringComparison.Ordinal) < 0) continue;
                    comp = Call(s, "FindById", id, false);
                }
            }
        }
        if (comp == null) { err.Add(sessions == 0 ? "SAP GUI has no open session" : "no SAP component at the point (" + sessions + " session(s) asked)"); return; }
        string fid = S(Get(comp, "Id")), type = S(Get(comp, "Type")), sub = type == "GuiShell" ? S(Get(comp, "SubType")) : "";
        Add(a, "ID", fid);
        Add(a, "ComponentType", type);
        if (sub.Length > 0) Add(a, "SubType", sub);
        string label = "Component";
        for (int i = 0; i < SapBases.GetLength(0); i++) if (SapBases[i, 0] == type) { b = SapBases[i, 1]; label = SapBases[i, 2]; }
        if (type == "GuiShell" && sub == "GridView") { b = "SAPGridView"; label = "Grid"; }
        if (type == "GuiModalWindow" || type == "GuiMainWindow") label = "Window";
        // the field name = the id's last segment without its 3-letter type prefix (txtRSYST-MANDT -> RSYST-MANDT)
        string last = fid.Substring(fid.LastIndexOf('/') + 1);
        if (last.Length > 3 && char.IsLower(last[0]) && char.IsLower(last[1]) && char.IsLower(last[2])) last = last.Substring(3);
        name = label + " - " + Label(last, type);
    }

    // ---------------- region: a rectangle of the screen inside a window ----------------
    public static string SpyRegion(int x1, int y1, int x2, int y2)
    {
        var a = new List<KeyValuePair<string, object>>(); var u = new List<KeyValuePair<string, object>>(); var err = new List<string>();
        string name = null;
        try
        {
            if (x2 <= x1 || y2 <= y1) { err.Add("the second corner has to be below and to the right of the first"); }
            else
            {
                // the container: the window under the first corner, widened up the parents until it holds the whole rectangle
                IntPtr h = DeepestWindow(x1, y1);
                for (int g = 0; h != IntPtr.Zero && g < 50; g++)
                {
                    RECT r; GetWindowRect(h, out r);
                    if (r.Left <= x1 && r.Top <= y1 && r.Right >= x2 && r.Bottom >= y2) break;
                    IntPtr p = GetAncestor(h, GA_PARENT); if (IsDesktop(p)) break; h = p;
                }
                var c1 = new POINT(x1, y1); var c2 = new POINT(x2, y2); ScreenToClient(h, ref c1); ScreenToClient(h, ref c2);
                Add(a, "StartX", c1.X); Add(a, "StartY", c1.Y); Add(a, "EndX", c2.X); Add(a, "EndY", c2.Y);
                RECT wr; GetWindowRect(h, out wr);
                Add(u, "StartX", x1 - wr.Left); Add(u, "StartY", y1 - wr.Top); Add(u, "EndX", x2 - wr.Left); Add(u, "EndY", y2 - wr.Top);   // window-rect relative: which one Blue Prism uses is not proven
                string png = Snapshot(x1, y1, x2 - x1, y2 - y1, err); if (png != null) Add(a, "ElementSnapshot", png);
                Win32(h, a, u, err, "", true);
                name = "Region " + (x2 - x1) + "x" + (y2 - y1) + " in " + Label(Text(h), Class(h));
            }
        }
        catch (Exception ex) { err.Add(ex.GetType().Name + ": " + ex.Message); }
        return Write("region", name, "Region", ", \"screen\": { \"left\": " + x1 + ", \"top\": " + y1 + ", \"right\": " + x2 + ", \"bottom\": " + y2 + " }", a, u, err);
    }
    /// The pixels as a one-line base64 PNG (the process is DPI aware, so these are real screen pixels).
    static string Snapshot(int x, int y, int w, int h, List<string> err)
    {
        try
        {
            using (var bmp = new System.Drawing.Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
            {
                using (var g = System.Drawing.Graphics.FromImage(bmp)) g.CopyFromScreen(x, y, 0, 0, new System.Drawing.Size(w, h));
                using (var ms = new MemoryStream()) { bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png); return Convert.ToBase64String(ms.ToArray()); }
            }
        }
        catch (Exception ex) { err.Add("snapshot: " + ex.GetType().Name + ": " + ex.Message); return null; }
    }

    // ---------------- html: the IE-mode page (Internet Explorer_Server window) ----------------
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern uint RegisterWindowMessage(string s);
    [DllImport("oleacc.dll")] static extern int ObjectFromLresult(UIntPtr lResult, ref Guid riid, IntPtr wParam, [MarshalAs(UnmanagedType.IUnknown)] out object obj);
    static object IeDocument(IntPtr h)
    {
        uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT"); IntPtr res;
        if (SendMessageTimeoutLen(h, msg, IntPtr.Zero, IntPtr.Zero, SMTO_ABORTIFHUNG, 1000, out res) == IntPtr.Zero || res == IntPtr.Zero) return null;
        var iid = new Guid("332C4425-26CB-11D0-B483-00C04FD90119");   // IHTMLDocument2
        object doc; return ObjectFromLresult((UIntPtr)(ulong)res.ToInt64(), ref iid, IntPtr.Zero, out doc) == 0 ? doc : null;
    }
    /// One step per element from the document's HTML down: "/HTML" without an index, the rest TAG(n), n = 1-based among
    /// siblings with the same tag (sourceIndex tells two elements apart).
    static string IePath(object el)
    {
        var steps = new List<string>();
        for (object e = el; e != null && steps.Count < 200; )
        {
            string tag = S(Get(e, "tagName")).ToUpperInvariant();
            object parent = Get(e, "parentElement");
            if (tag == "HTML" || parent == null) { steps.Add("/HTML"); break; }
            int n = 0, mine = N(Get(e, "sourceIndex")); object kids = Get(parent, "children");
            for (int i = 0; i < N(Get(kids, "length")); i++)
            {
                object k = Call(kids, "item", i);
                if (S(Get(k, "tagName")).ToUpperInvariant() != tag) continue;
                n++; if (N(Get(k, "sourceIndex")) == mine) break;
            }
            steps.Add("/" + tag + "(" + n + ")");
            e = parent;
        }
        steps.Reverse(); return string.Join("", steps.ToArray());
    }
    static void Html(int x, int y, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, out string name, out string b)
    {
        name = null; b = "HTML";
        IntPtr h = DeepestWindow(x, y);
        if (Class(h) != "Internet Explorer_Server") { err.Add("no IE-mode page under the point (the window there is " + Class(h) + ")"); return; }
        object doc = IeDocument(h); if (doc == null) { err.Add("the IE-mode page did not hand over its document"); return; }
        var o = new POINT(0, 0); ClientToScreen(h, ref o);
        object scr = Get(Get(doc, "parentWindow"), "screen");
        double ratio = D(Get(scr, "deviceXDPI")) > 0 && D(Get(scr, "logicalXDPI")) > 0 ? D(Get(scr, "deviceXDPI")) / D(Get(scr, "logicalXDPI")) : 1;
        double cx = (x - o.X) / ratio, cy = (y - o.Y) / ratio, offX = 0, offY = 0;   // CSS pixels of the current document
        string path = ""; object el = null; int ancestors = 0;
        for (int depth = 0; depth < 10; depth++)
        {
            el = Call(doc, "elementFromPoint", (int)cx, (int)cy);
            if (el == null) { err.Add("no element at the point"); return; }
            string tag = S(Get(el, "tagName")).ToUpperInvariant();
            if (tag != "IFRAME" && tag != "FRAME") break;
            object inner = Get(Get(el, "contentWindow"), "document");
            if (inner == null) { err.Add("the element is inside a frame of another site, which cannot be read: the frame itself is returned"); break; }
            object fr = Call(el, "getBoundingClientRect");
            double fl = D(Get(fr, "left")) + D(Get(el, "clientLeft")), ft = D(Get(fr, "top")) + D(Get(el, "clientTop"));
            path += IePath(el); ancestors += Depth(el) + 1;
            offX += fl; offY += ft; cx -= fl; cy -= ft; doc = inner;
        }
        string t = S(Get(el, "tagName")).ToUpperInvariant(), type = t == "INPUT" ? S(Get(el, "type")).ToLowerInvariant() : "";
        path += IePath(el); ancestors += Depth(el);
        Add(a, "Path", path);
        Add(a, "TagName", t);
        Add(a, "ID", S(Get(el, "id")));
        Add(a, "ClassName", S(Get(el, "className")));
        Add(a, "InputType", type);
        bool field = t == "INPUT" || t == "SELECT" || t == "TEXTAREA" || t == "BUTTON";
        if (type == "password") err.Add("a password field: its value is not read");
        else if (field) Add(a, "Value", S(Get(el, "value")));
        else Add(u, "Value", Label(S(Get(el, "innerText")), ""));   // a link button's caption was its text on the one example: confirm
        Add(a, "Title", S(Get(el, "title")));
        Add(a, "Link", t == "A" ? S(Get(el, "href")) : "");
        Add(a, "pURL", S(Get(doc, "URL")));
        Add(a, "Enabled", !Bo(Get(el, "disabled")));
        Add(a, "Checked", (type == "checkbox" || type == "radio") && Bo(Get(el, "checked")));
        Add(u, "InputIdentifier2", S(Get(el, "name")));
        Add(u, "AncestorCount", ancestors);
        Add(u, "X", N(Get(el, "offsetLeft"))); Add(u, "Y", N(Get(el, "offsetTop"))); Add(u, "Width", N(Get(el, "offsetWidth"))); Add(u, "Height", N(Get(el, "offsetHeight")));
        object r = Call(el, "getBoundingClientRect");
        if (r != null)
        {
            Func<double, double, int> sx = (v, off) => (int)Math.Round((v + off) * ratio);
            int l = o.X + sx(D(Get(r, "left")), offX), tp = o.Y + sx(D(Get(r, "top")), offY), rt = o.X + sx(D(Get(r, "right")), offX), bt = o.Y + sx(D(Get(r, "bottom")), offY);
            Add(a, "ScreenBounds", "RECT:" + l + "," + tp + "," + bt + "," + rt);
        }
        b = t == "INPUT" && (type == "" || type == "text") ? "HTMLEdit" : "HTML";
        string what = b == "HTMLEdit" ? "Textbox" : t == "A" ? "Link" : t;
        name = what + " - " + Label(S(Get(el, "id")).Length > 0 ? S(Get(el, "id")) : S(Get(el, "innerText")), t);
    }
    static int Depth(object el) { int n = 0; for (object e = Get(el, "parentElement"); e != null && n < 500; e = Get(e, "parentElement")) n++; return n; }

    // ---------------- web: Edge (started by gumball) through its debugging port on 127.0.0.1 ----------------
    // The page knows what is hovered: the innermost :hover element, descending into same-origin frames. When nothing is
    // hovered (the mouse has not moved over the page yet) it falls back to elementFromPoint with the screen point mapped
    // into the viewport, and says so.
    const string WebJs = @"(function(sx,sy){
var out={errors:[]},doc=document,win=window,el=null,frames=[],viaHover=true;
function hov(d){var l=d.querySelectorAll(':hover');return l.length?l[l.length-1]:null;}
el=hov(doc);
if(!el){viaHover=false;var r=win.devicePixelRatio||1,bx=(win.outerWidth-win.innerWidth)/2;
 el=doc.elementFromPoint(sx/r-win.screenX-bx,sy/r-win.screenY-(win.outerHeight-win.innerHeight)+bx);
 out.errors.push('nothing was hovered in the page: the element was found from the mouse position instead');}
while(el&&(el.tagName=='IFRAME'||el.tagName=='FRAME')){var d=null;try{d=el.contentDocument;}catch(e){}
 if(!d){out.errors.push('the element is inside a frame of another site, which cannot be read: the frame itself is returned');break;}
 frames.push(xp(el));var h=hov(d);if(!h)break;doc=d;el=h;}
if(!el){out.errors.push('no element under the mouse');return JSON.stringify({errors:out.errors,visible:doc.visibilityState=='visible'});}
function xp(e){var s=[];for(;e&&e.nodeType==1;e=e.parentNode){var n=1,t=e.tagName;for(var p=e.previousElementSibling;p;p=p.previousElementSibling)if(p.tagName==t)n++;s.unshift(t.toUpperCase()+'['+n+']');}return '/'+s.join('/');}
function at(n){var v=el.getAttribute(n);return v==null?'':v;}
var b=el.getBoundingClientRect(),tag=el.tagName.toUpperCase(),typ=tag=='INPUT'?(el.type||'').toLowerCase():'';
var a={wXPath:xp(el),wElementType:tag,wPageAddress:location.href,wClass:at('class'),wInnerText:(el.innerText||'').slice(0,4000),
 wChildCount:el.children.length,wIsEditable:!!(el.isContentEditable||((tag=='INPUT'||tag=='TEXTAREA')&&!el.readOnly&&!el.disabled)),
 wTabIndex:el.tabIndex,wInputType:typ,wAccessKey:el.accessKey||'',wSource:at('src'),wTargetAddress:tag=='A'?(el.href||''):at('href'),wAlt:at('alt'),
 wPattern:at('pattern'),wRel:at('rel'),wLinkTarget:at('target'),wPlaceholder:at('placeholder'),
 wX:Math.round(b.left),wY:Math.round(b.top),wWidth:Math.round(b.width),wHeight:Math.round(b.height),
 wClientX:el.clientLeft,wClientY:el.clientTop,wClientWidth:el.clientWidth,wClientHeight:el.clientHeight,
 wOffsetX:el.offsetLeft||0,wOffsetY:el.offsetTop||0,wOffsetWidth:el.offsetWidth||0,wOffsetHeight:el.offsetHeight||0,
 wScrollX:el.scrollLeft,wScrollY:el.scrollTop,wScrollWidth:el.scrollWidth,wScrollHeight:el.scrollHeight};
if(typ=='password')out.errors.push('a password field: its value is not read');else a.wValue=(el.value==null?'':String(el.value));
out.attrs=a;out.unconfirmed={};if(frames.length){out.unconfirmed.wFramePath=frames.join(' > ');out.unconfirmed.wFrameAddress=doc.location.href;a.wPageAddress=top.location.href;}
out.viaHover=viaHover;out.visible=document.visibilityState=='visible';out.focused=document.hasFocus();
out.label=(el.innerText||el.id||at('name')||'').replace(/\s+/g,' ').trim().slice(0,60);return JSON.stringify(out);})";

    static string Http(string url) { var rq = (HttpWebRequest)WebRequest.Create(url); rq.Timeout = 3000; rq.Proxy = null; using (var rs = rq.GetResponse()) using (var rd = new StreamReader(rs.GetResponseStream(), Encoding.UTF8)) return rd.ReadToEnd(); }
    /// One Runtime.evaluate over the tab's web socket; returns the string the page returned, or null.
    static string Evaluate(string wsUrl, string expr, List<string> err)
    {
        try
        {
            using (var ws = new ClientWebSocket())
            {
                var cts = new CancellationTokenSource(6000);
                ws.ConnectAsync(new Uri(wsUrl), cts.Token).Wait();
                string req = "{\"id\":1,\"method\":\"Runtime.evaluate\",\"params\":{\"expression\":" + J(expr) + ",\"returnByValue\":true}}";
                var bytes = Encoding.UTF8.GetBytes(req);
                ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, cts.Token).Wait();
                var buf = new byte[65536];
                for (int guard = 0; guard < 100; guard++)
                {
                    var ms = new MemoryStream(); WebSocketReceiveResult rr;
                    do { rr = ws.ReceiveAsync(new ArraySegment<byte>(buf), cts.Token).Result; ms.Write(buf, 0, rr.Count); } while (!rr.EndOfMessage);
                    var msg = new System.Web.Script.Serialization.JavaScriptSerializer { MaxJsonLength = int.MaxValue }.DeserializeObject(Encoding.UTF8.GetString(ms.ToArray())) as Dictionary<string, object>;
                    if (msg == null || !msg.ContainsKey("id") || N(msg["id"]) != 1) continue;
                    var res = msg.ContainsKey("result") ? msg["result"] as Dictionary<string, object> : null;
                    var inner = res != null && res.ContainsKey("result") ? res["result"] as Dictionary<string, object> : null;
                    if (res != null && res.ContainsKey("exceptionDetails")) { err.Add("the page script failed"); return null; }
                    return inner != null && inner.ContainsKey("value") ? inner["value"] as string : null;
                }
            }
        }
        catch (Exception ex) { var e = ex is AggregateException && ex.InnerException != null ? ex.InnerException : ex; err.Add("debugging connection: " + e.GetType().Name + ": " + e.Message); }
        return null;
    }
    static void Web(int x, int y, List<KeyValuePair<string, object>> a, List<KeyValuePair<string, object>> u, List<string> err, out string name, out string b)
    {
        name = null; b = "WebElement";
        var js = new System.Web.Script.Serialization.JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        object[] tabs;
        try { tabs = js.DeserializeObject(Http("http://127.0.0.1:" + Port + "/json")) as object[]; }
        catch (Exception) { err.Add("no Edge on port " + Port + ": start the application with gumball's Launch application (Edge needs its debugging port)"); return; }
        if (tabs == null) { err.Add("Edge on port " + Port + " listed no tabs"); return; }
        Dictionary<string, object> best = null; int bestScore = -1; var notes = new List<string>();
        foreach (var t in tabs)
        {
            var tab = t as Dictionary<string, object>;
            if (tab == null || S(tab.ContainsKey("type") ? tab["type"] : null) != "page" || !tab.ContainsKey("webSocketDebuggerUrl")) continue;
            var e = new List<string>();
            string raw = Evaluate(S(tab["webSocketDebuggerUrl"]), WebJs + "(" + x + "," + y + ")", e);
            var r = raw == null ? null : js.DeserializeObject(raw) as Dictionary<string, object>;
            if (r == null) { notes.AddRange(e); continue; }
            // the tab in front: visible, with a hovered element, focused if several qualify
            int score = (Bo(Get2(r, "visible")) ? 4 : 0) + (r.ContainsKey("attrs") ? 2 : 0) + (Bo(Get2(r, "viaHover")) ? 2 : 0) + (Bo(Get2(r, "focused")) ? 1 : 0);
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best == null) { err.Add("no page tab answered"); err.AddRange(notes); return; }
        var errs = Get2(best, "errors") as object[]; if (errs != null) foreach (var e in errs) err.Add(S(e));
        var attrs = Get2(best, "attrs") as Dictionary<string, object>; if (attrs == null) return;
        foreach (var kv in attrs) Add(a, kv.Key, Plain(kv.Value));
        var un = Get2(best, "unconfirmed") as Dictionary<string, object>; if (un != null) foreach (var kv in un) Add(u, kv.Key, Plain(kv.Value));
        name = S(attrs["wElementType"]) + " - " + Label(S(Get2(best, "label")), S(attrs["wElementType"]));
    }
    static object Get2(Dictionary<string, object> d, string k) { object v; return d != null && d.TryGetValue(k, out v) ? v : null; }
    /// JSON numbers come back as int or decimal: whole numbers stay numbers, the rest as written.
    static object Plain(object v)
    {
        if (v is bool || v is string || v is int || v is long) return v;
        if (v is decimal || v is double) { double d = Convert.ToDouble(v, CultureInfo.InvariantCulture); return d == Math.Floor(d) && Math.Abs(d) < int.MaxValue ? (object)(int)d : Convert.ToString(v, CultureInfo.InvariantCulture); }
        return v == null ? "" : Convert.ToString(v, CultureInfo.InvariantCulture);
    }

    // ---------------- small helpers ----------------
    delegate string StrFn(); delegate object ObjFn();
    static string Safe(StrFn f) { try { return f() ?? ""; } catch (Exception) { return ""; } }
    static object SafeObj(ObjFn f) { try { return f(); } catch (Exception) { return null; } }
    static string Label(string text, string fallback) { string s = string.IsNullOrEmpty(text) ? fallback : text; s = (s ?? "").Replace("\r", " ").Replace("\n", " "); return s.Length > 60 ? s.Substring(0, 60) : s; }
    static void Add(List<KeyValuePair<string, object>> l, string k, object v) { l.Add(new KeyValuePair<string, object>(k, v)); }
    static string Str(List<KeyValuePair<string, object>> l, string k) { foreach (var kv in l) if (kv.Key == k) return kv.Value as string; return null; }
    static void Obj(StringBuilder sb, List<KeyValuePair<string, object>> l)
    {
        sb.Append('{');
        for (int i = 0; i < l.Count; i++) sb.Append(i > 0 ? ",\n    " : "\n    ").Append(J(l[i].Key)).Append(": ").Append(V(l[i].Value));
        sb.Append(l.Count > 0 ? "\n  }" : "}");
    }
    static string V(object v)
    {
        if (v == null) return "null";
        if (v is bool) return (bool)v ? "true" : "false";
        if (v is int || v is long || v is uint) return Convert.ToString(v, CultureInfo.InvariantCulture);
        return J(Convert.ToString(v, CultureInfo.InvariantCulture));
    }
    static string J(string s)
    {
        if (s == null) return "null";
        var sb = new StringBuilder("\"");
        foreach (char ch in s)
        {
            if (ch == '"') sb.Append("\\\""); else if (ch == '\\') sb.Append("\\\\");
            else if (ch == '\n') sb.Append("\\n"); else if (ch == '\r') sb.Append("\\r"); else if (ch == '\t') sb.Append("\\t");
            else if (ch < 0x20) sb.Append("\\u").Append(((int)ch).ToString("x4"));
            else sb.Append(ch);
        }
        return sb.Append('"').ToString();
    }
}
'@

# Compile the helper once per PowerShell session (Add-Type cannot redefine a type).
if (-not ('MordecaiSpy' -as [type])) {
    $names = 'UIAutomationClient', 'UIAutomationTypes', 'WindowsBase', 'Accessibility', 'System.Windows.Forms', 'System.Drawing', 'System.Web.Extensions'
    foreach ($n in $names) { Add-Type -AssemblyName $n }
    $refs = foreach ($n in $names) { ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq $n } | Select-Object -First 1).Location }
    Add-Type -TypeDefinition $src -ReferencedAssemblies $refs -Language CSharp
}

# Same coordinates as Blue Prism on a scaled display (this PowerShell process only).
[MordecaiSpy]::DpiAware()
[MordecaiSpy]::Port = $Port

function Out-Spy([string]$json) {
    Write-Output $json
    if (-not $NoClipboard) {
        try { Set-Clipboard -Value $json; Write-Host "(copied to the clipboard)" } catch { Write-Host ("(clipboard failed: {0})" -f $_.Exception.Message) }
    }
}

if ($Mode -eq 'region') {
    if ($X1 -lt 0 -or $Y1 -lt 0 -or $X2 -lt 0 -or $Y2 -lt 0) { Write-Host "region needs -X1 -Y1 -X2 -Y2 (top-left and bottom-right, screen pixels)"; exit 1 }
    Out-Spy ([MordecaiSpy]::SpyRegion($X1, $Y1, $X2, $Y2))
    exit 0
}

if ($X -ge 0 -and $Y -ge 0) {
    $px = $X; $py = $Y
} elseif ($Seconds -gt 0) {
    Write-Host ("hover the control; reading in {0} s ..." -f $Seconds)
    Start-Sleep -Seconds $Seconds
    $p = [MordecaiSpy]::Cursor(); $px = $p.X; $py = $p.Y
} else {
    $VK_CONTROL = 0x11; $VK_ESCAPE = 0x1B
    while ([MordecaiSpy]::KeyDown($VK_CONTROL)) { Start-Sleep -Milliseconds 30 }   # a Ctrl still held from starting the script
    Write-Host "hover the control and press Ctrl (Esc cancels, 2 min limit)"
    $deadline = (Get-Date).AddMinutes(2); $got = $false
    while ((Get-Date) -lt $deadline) {
        if ([MordecaiSpy]::KeyDown($VK_ESCAPE)) { Write-Host "cancelled"; exit 1 }
        if ([MordecaiSpy]::KeyDown($VK_CONTROL)) { $p = [MordecaiSpy]::Cursor(); $got = $true; break }
        Start-Sleep -Milliseconds 30
    }
    if (-not $got) { Write-Host "timed out"; exit 1 }
    while ([MordecaiSpy]::KeyDown($VK_CONTROL)) { Start-Sleep -Milliseconds 30 }
    $px = $p.X; $py = $p.Y
}

Out-Spy ([MordecaiSpy]::Spy($Mode, $px, $py))
