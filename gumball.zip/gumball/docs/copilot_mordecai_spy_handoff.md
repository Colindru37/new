# Handoff: Mordecai's live spy (read one UI element's attributes from the screen)

For: whoever writes or changes the spy. Output: a PowerShell script, `mordecai-spy.ps1`, that prints JSON.
Status: all modes are written (the script is next to `gumball.js`). web was run against a real Chromium through its
debugging port (plain element, password field, element in a same-origin frame, no browser on the port); win32 / aa / uia /
sap / html / region are compiled and checked for their JSON, not yet run against real applications. This file is the
specification for all of them.
Why: gumball can already read, edit and write an object's Application Modeller (`mordecai.js`). What it cannot do
is look at a running application. This script is that missing half: point at a control, get its attributes in
the exact names Blue Prism stores, paste them into gumball ("fill from spy" on an element).

## What it does

1. Wait for the user to hover a control and press a hotkey (Ctrl by itself is fine), or take `-X -Y` screen
   coordinates, or `-Seconds 3` and then use the cursor position.
2. Read that control in the requested mode (`-Mode win32 | aa | uia`).
3. Print one JSON object to stdout and copy it to the clipboard.

No clicking, no typing into the application, no hooks left installed: it reads and exits.

## Output

```json
{ "mode": "uia", "name": "Button - OK", "base": "UIAButton",
  "attrs": { "uControlType": "Button", "uName": "OK", "uClassName": "MdTextButton", "uAutomationId": "",
             "uX": 622, "uY": 189, "uWidth": 68, "uHeight": 32, "puControlType": "Pane" } }
```

`attrs` uses Blue Prism's attribute names exactly. Flags are JSON booleans, numbers are numbers, the rest strings.
Leave out what cannot be read; gumball ignores names an element does not have. A value whose Blue Prism format is not
proven goes into a second object, `"unconfirmed": { ... }`, which gumball does not use: a guess must never overwrite a
correct value.

## Attribute names per mode (from real objects in this estate)

**win32** (Win32 API on the window handle under the point): `WindowText ClassName CtrlID X Y Width Height Visible
ScreenVisible Enabled Active Ordinal ChildCount AncestorsText AncestorCount TypeName ScreenBounds Style`, the parent
window's copy with a `p` prefix (`pWindowText pClassName pCtrlID pX pY pWidth pHeight pVisible pScreenVisible pEnabled
pActive pOrdinal pChildCount pStyle`). Formats, checked against elements Blue Prism itself spied (Foundation Training
release):
- `X` / `Y` = the window rect relative to the parent's CLIENT area (the screen for a top-level window); `Width` / `Height` =
  the whole window rect.
- `ScreenBounds` = the CLIENT rect on screen, written `RECT:left,top,bottom,right` (so it is smaller than Width x Height).
- `ClassName` of a WinForms window is cut to its first two parts (`WindowsForms10.EDIT`); the rest changes on every run.
- `AncestorsText` = each ancestor's text followed by a space, the desktop as `<UNKNOWN> `; `AncestorCount` counts the desktop
  (a top-level window has `"<UNKNOWN> "` and 1).
- `Ordinal` = 1-based place among the parent's children. `CtrlID` was 0 on everything Blue Prism spied, a message box OK
  button included, so it is not simply the dialog control id: report it as unconfirmed.
- Element type: `Window | Button | Edit | Password | Label | ComboBox`; a Password is an Edit whose style has the password
  bit (0x20) set.
- `TypeName` is the .NET type for WinForms (`System.Windows.Forms.TextBox`) and the class name otherwise; the .NET name
  cannot be read from outside the process, leave it out for WinForms.

**aa** (IAccessible from the point): the win32 attributes of the owning window WITHOUT the `p`-prefixed window copies (an AA
element's parent copies are the accessible parent's, listed below), plus `aX aY aWidth aHeight Name
Description Role ID State Value2 KeyboardShortcut DefaultAction ElementCount aAncestorCount` and one flag per state bit:
`Unavailable Selected Focused Pressed aChecked Mixed ReadOnly Hottracked Default Expanded Collapsed Busy Floating
Marqueed Animated Invisible Offscreen Sizeable Moveable SelfVoicing Focusable Selectable Linked Traversed
Multiselectable Extselectable Alert_low Alert_medium Alert_high`; the accessible parent's copy as `paX paY paWidth
paHeight pName pDescription pRole pID pState pValue2 pKeyboardShortcut pDefaultAction pElementCount` + the same flags
with a `p` prefix. `Role` is the role text (`Window`, `PushButton`, `Text`, `Pane`, `Client`).

**uia** (UI Automation from the point): `uX uY uWidth uHeight uClassName uAutomationId uControlType
uLocalizedControlType uIsPassword uIsRequiredForForm uName uOrientation uItemStatus uItemType uOffscreen
uTopLevelWindowId uLabeledBy uEnabled uAcceleratorKey uAccessKey uHasKeyboardFocus uHelpText uProcessId` and the
parent's `puControlType puLocalizedControlType puClassName puName puAutomationId`. `uControlType` is the short name
(`Button`, `Edit`, `Pane`), not `ControlType.Button`.

`base` (optional): the Blue Prism element type: win32 `Window | Edit | Button | Label | ComboBox | ...` from the class,
aa `AAElement | AAEdit | AAButton`, uia `UIAElement | UIAEdit | UIAButton`.

## How to check it

Hover the OK button of any dialog, run with `-Mode uia`, compare with an element Blue Prism spied on the same
control (gumball shows it under Application Modeller, or `node gumball.js appdef <object>` prints it). Names and
values should match attribute for attribute; differences in X/Y only mean the window moved.

## Part 2: the four other modes (specified 2026-11-14, written 2026-11-14)

gumball already calls them: the Spy buttons send `-Mode sap | html | web | region | point` exactly as below, and its
attribute tables hold every name listed. Order of work: sap, region (+ point), html, web. Same rules as part 1: read
only, one JSON object on stdout, `attrs` for proven formats, `unconfirmed` for the rest, `errors` instead of throwing.
Every format below was read off elements Blue Prism spied in this estate (digest photos, 2026-11-13); where a rule is a
deduction from one or two examples it is marked **confirm**, and the script should put that value in `unconfirmed`
until one comparison with a Studio-spied element says it matches.

### How gumball calls the script

```
-Mode sap|html|web  -Seconds N -NoClipboard          one point, read after N seconds (as win32 / aa / uia today)
-Mode web           -Seconds N -NoClipboard -Port 9222
-Mode point         -Seconds N -NoClipboard          no element: { "mode": "point", "point": { "x": .., "y": .. } }
-Mode region        -NoClipboard -X1 .. -Y1 .. -X2 .. -Y2 ..     screen pixels, top-left and bottom-right
```

A region is three calls (point, point, region): the page tells the user which corner to hold the mouse on and waits
for each answer, so nothing has to be timed between the browser and the script.

### sap

Source: SAP GUI Scripting (the COM object the running SAP GUI registers as `SAPGUI`, then its scripting engine,
connection, session). It answers "which component is at this screen point" itself (a find-by-position call on the
session's window), and the component gives its `Id` and `Type`. No Win32 reading at all.

```json
{ "mode": "sap", "name": "Textbox - Mandant", "base": "SAPTextBox",
  "attrs": { "ID": "/app/con[0]/ses[0]/wnd[0]/usr/txtRSYST-MANDT", "ComponentType": "GuiTextField" } }
```

- `ID` = the component id exactly as SAP gives it, starting at `/app/`. It is the only attribute Blue Prism matches on.
- `ComponentType` = the component's type name (`GuiTextField GuiPasswordField GuiButton GuiCheckBox GuiRadioButton
  GuiComboBox GuiOkCodeField GuiStatusbar GuiModalWindow GuiMainWindow GuiShell ...`).
- `SubType` only for a `GuiShell`: its sub type (`GridView`, ...). gumball adds the attribute to the element.
- `base` from the type: GuiTextField > `SAPTextBox`, GuiPasswordField > `SAPPasswordField`, GuiButton > `SAPButton`,
  GuiCheckBox > `SAPCheckBox`, GuiRadioButton > `SAPRadioButton`, GuiComboBox > `SAPComboBox`, GuiOkCodeField >
  `SAPOkCodeField`, GuiStatusbar > `SAPStatusBar`, GuiShell with SubType GridView > `SAPGridView`, everything else >
  `SAPComponent` (seen for GuiModalWindow).
- `name`: a readable label + the field name from the id's last segment.
- Scripting disabled or no session: say so in `errors` (Blue Prism needs the same setting, so it is on where SAP
  objects run).

### region (and point)

`point`: wait, read the cursor, print it. Nothing else.

`region`: the rectangle (X1,Y1)-(X2,Y2) in screen pixels.

```json
{ "mode": "region", "name": "Region 200x60 in KYC - Hinweis", "base": "Region",
  "screen": { "left": 425, "top": 268, "right": 625, "bottom": 328 },
  "attrs": { "StartX": 135, "StartY": 92, "EndX": 335, "EndY": 152, "ElementSnapshot": "<base64 PNG>",
             "ClassName": "CpGuiDlg", "WindowText": "", "X": 0, "Y": 0, "Width": 997, "Height": 720, "...": "..." } }
```

- The container is the window under the first corner (the deepest one that holds the whole rectangle). Its win32
  attributes go into `attrs` with the same names and formats as `-Mode win32`, parent copies included: that is how a
  Region element is stored (the region's own attributes first, then the window's).
- `ElementSnapshot` = the rectangle's pixels as a PNG, base64, one line (the stored values start `iVBOR` and end
  `SUVORK5CYII=`). Capture with the screen at its real scale (the script is already DPI aware).
- `StartX StartY EndX EndY` = the rectangle relative to the container window. **confirm**: relative to its window rect
  or to its client area. Report the client-relative numbers in `attrs` and the window-relative ones in `unconfirmed`
  until one Studio-spied region on a window with a title bar settles it; always include `screen`.
- Not spied, left as the element has them: `FontName LocationMethod RegionPosition ImageSearchPadding ColourTolerance
  Greyscale` (settings; gumball writes Coordinates / Fixed / 0 padding / 0 / False on a new region).

### html (Edge in IE mode, the old HTML mode)

Source: the page document of the Internet Explorer window under the point (the IE-mode tab is a real
`Internet Explorer_Server` window; its HTML document object is reachable from the window handle), then the element at
the point, descending into frames: an element inside an iframe is found by asking the frame's own document.

```json
{ "mode": "html", "name": "Textbox - Hauptforderung", "base": "HTMLEdit",
  "attrs": { "Path": "/HTML/BODY(1)/DIV(1)/DIV(3)/IFRAME(1)/HTML/BODY(1)/FORM(1)/DIV(3)/.../INPUT(1)",
             "TagName": "INPUT", "ID": "Hauptforderung", "ClassName": "floattpinput numberinput", "InputType": "text",
             "Value": "0,00", "Title": "", "Link": "", "Enabled": true, "Checked": false,
             "pURL": "https://.../pfaendungsforderunganlage01.jsp?...", "X": 0, "Y": 0, "Width": 104, "Height": 19 } }
```

- `Path`: from the top document down. `/HTML` has no index; every other step is the tag in upper case + `(n)`, n = the
  1-based place among the siblings WITH THE SAME TAG. Crossing a frame: the `IFRAME(n)` (or `FRAME(n)`) step, then
  `/HTML/BODY(1)/...` of the frame's document. This is what Blue Prism matches on first.
- `TagName` upper case. `ID` = the id attribute. `ClassName` = the class attribute. `InputType` = type of an INPUT,
  else empty. `Value` = the value (a button's caption for `<a class="button">` was its text: **confirm**).
- `Link` = href for a link, else empty. `Title` = title attribute. `pURL` = the URL of the document the element is in
  (the frame's, not the top page's).
- `InputIdentifier2`: equal to the id on the one example seen; probably the name attribute. **confirm**.
- `AncestorCount`: 15 and 19 on the two examples, close to the number of steps in the path. **confirm**.
- `X Y Width Height`: the element's box; X/Y were 0 or small on the examples, so not screen coordinates. **confirm**.
  `ScreenBounds` as in win32 (`RECT:left,top,bottom,right`).
- `base`: `HTMLEdit` for a text INPUT; `HTML` for the rest (seen: a link). Other HTML types exist in Studio
  (buttons, combo boxes, check boxes, tables): **confirm** their names from one spied element each before using them.

### web (Edge, Blue Prism's browser mode)

Blue Prism reads these through its browser extension. From outside, the same facts come from Edge's debugging port:
gumball's **Launch application** starts a browser object's Edge with `--remote-debugging-port=9222` and a profile
folder of its own (`projects\_spyprofile`), because an Edge that is already running ignores the port. The script
connects to `-Port` on 127.0.0.1 only, picks the tab that is in front, and asks the page which element the mouse is on.
No screen-to-page coordinate maths is needed: the page already knows what is hovered (the innermost element matching
`:hover`, descending into same-origin frames), so one evaluation in the page returns everything below.

```json
{ "mode": "web", "name": "SPAN - Welcome to the WebPortal", "base": "WebElement",
  "attrs": { "wXPath": "/HTML[1]/BODY[1]/DIV[2]/TABLE[1]/TBODY[1]/TR[1]/TD[2]/DIV[1]/DIV[1]/DIV[1]/DIV[1]/SPAN[1]",
             "wElementType": "SPAN", "wPageAddress": "https://.../Portal/welcome.jsf", "wClass": "headerText",
             "wInnerText": "Welcome to the WebPortal of ...", "wValue": "", "wChildCount": 0, "wIsEditable": false,
             "wTabIndex": -1, "wX": 233, "wY": 151, "wWidth": 457, "wHeight": 17 } }
```

- `wXPath`: every step upper-case tag + `[n]`, n = 1-based place among same-tag siblings, `HTML[1]` included.
- `wElementType` = the tag, upper case. `wPageAddress` = the page URL. These three are what Blue Prism matches on.
- `wClass` class attribute, `wValue` value, `wInnerText` inner text, `wChildCount` number of child elements,
  `wIsEditable`, `wTabIndex`, `wInputType`, `wAccessKey`, `wSource` (src), `wTargetAddress` (href), `wAlt`, `wPattern`,
  `wRel`, `wLinkTarget` (target), `wPlaceholder`.
- Geometry: `wX wY wWidth wHeight` = the bounding box in the page; `wClientX/Y/Width/Height`, `wOffsetX/Y/Width/Height`,
  `wScrollX/Y/Width/Height` = the element's client*, offset*, scroll* properties (Left/Top for X/Y).
- `wCssSelector` was empty on the example: leave it out. `wStyle` (a dump of every CSS property) is never needed:
  leave it out, the element keeps what it has.
- An element inside a cross-origin frame cannot be reached from the top page: report it in `errors` and return the
  frame element.
- No Edge on the port: `errors` = "start the application with gumball's Launch application (Edge needs its debugging
  port)".

### How to check part 2

For each mode: spy a control Blue Prism already spied (any object of that kind, shown in gumball under Application
Modeller) with **Spy this element** on a copy of that element made with "+ one like this". The values Studio wrote
and the values the spy wrote should be the same attribute for attribute; every difference is either a format to fix
or a **confirm** item answered.

## Constraints

PowerShell only, .NET types through `Add-Type` and COM; nothing is built, installed or copied. The script and its
output stay on the machine. The web mode talks to 127.0.0.1 only, and only to the Edge that gumball started.
