# Internal objects: the plan

Blue Prism's internal business objects (Work Queues, Credentials, Environment Locking, Calendars, Collections,
Session Variables, Sessions, Event Log, Encryption, Data Gateways, Licensing, Environment) are compiled into
Blue Prism itself. They are never in a release, cannot be exported from Studio and nothing is ever imported for them.
An Action stage names one by its CLASS: `<resource object="Blueprism.Automate.clsWorkQueuesActions" action="Get Next Item" />`;
Studio shows the display name. "Making" them means two things only:

1. gumball knows them: the Objects known list, the Action picker, the release checks (a wrong action name is an error,
   a call to one is never "not in this release"), the calls census.
2. Run simulates them: bprun answers each action the way Blue Prism would, including the exception text on failure.

## Where it stands (2026-11-14)

- `internal/internal.json`: 12 objects with their documented actions and parameters, `verified: false` (not yet
  checked against a Studio action list), `classes` for the five seen in real exports. Unknown classes still count as
  internal by pattern (`Blueprism.Automate.cls*`, `Blueprism.AutomateProcessCore.cls*`, `BluePrism.AutomateAppCore.cls*`).
- The checks skip internal objects until the list is verified; the census (`node gumball.js calls <release>`) puts
  internal calls in their own section, by count.
- bprun simulates (test/internal_test.py, 40 checks): **Work Queues** in full (20 actions: add / get next with key +
  tag filters, priority and age order, deferral, lock state, mark completed / exception with retry up to the queue's
  max attempts and the attempt count carried, set data, item data, status, priority, tags, unlock, is-in-queue,
  pending / locked / completed / exception lists, report counts, copy to queue, delete processed), **Credentials**
  (get, get / set property, set, names), **Environment Locking** (acquire / release / query / delete / list, plus
  locks the estate says another session holds), **Calendars** (working days + holidays per calendar from the
  estate), **Collections**, **Event Log** and **Data Gateways** (to the run log), **Encryption** (reversible stand-in).
  Session Variables, Sessions, Environment, Licensing: no action list yet, a call says `<object>.<action> not simulated`.
- Exception texts are approximations until a real one is seen; the real ones replace them as they turn up in
  incident folders / the Errors-Only log.

## Steps, in order

1. **Census on the bank's releases.** `node gumball.js calls r.bprelease` on the real releases; the `== internal`
   section is the list of actions that matter and the order to build them in. One photo per release is enough.
2. **Verified action list.** Two ways, either is fine:
   - Copilot on the bank machine with `docs/copilot_internal_objects_handoff.md` (PowerShell reflection over
     AutomateAppCore.dll, reads type metadata only) -> `internal.json` with `verified: true` and `class` for every object.
   - By hand in Studio: an Action stage, Business Object dropdown, each internal object, each action's inputs/outputs
     tab. Photos are fine; they get transcribed into `internal.json`. The class name comes from any export that calls
     the object (Action stage's `resource object`).
   Once verified, the checks start reporting wrong action names on internal objects as errors, like Studio.
3. **Correct the simulation against the verified list.** Action and parameter names that differ get renamed (the
   simulation accepts the old and the new name for a while), exception texts get the real wording as incident folders
   show them, and the four objects without an action list (Session Variables, Sessions, Environment, Licensing) get
   theirs.
4. **Estate file.** `internal/estate.json` grows: holidays, credentials with properties, queue seed items, lock state.
   A release's own env vars and queues keep being added on top when running one of its members.
5. **Tests.** One small fixture process per object in `test/`, run through `lib/bprun_run.py`, asserting outputs and
   the exception text. The existing suite stays green on every step.

Out of scope: anything that changes Blue Prism. If a process needs a real queue or a real lock, that is a DEV run.
