# Handoff: list Blue Prism's internal business objects with their actions and parameters

For: Copilot on the Blue Prism machine. Output: one JSON file, `internal/internal.json` for gumball.
Why: these objects (Work Queues, Credentials, Environment Locking, Calendars, ...) are compiled into Blue
Prism and cannot be exported from Studio. gumball needs their action names and parameters so an
Action stage pointing at them resolves, checks can verify the action exists, and Run can simulate them.

## What to produce

`internal.json`, this shape (the current file is a hand-written seed, same shape, `"source": "seed"`):

```json
{ "source": "AutomateAppCore 7.2.1 <date>",
  "objects": [
    { "object": "Work Queues", "verified": true,
      "actions": [
        { "name": "Get Next Item",
          "inputs":  [ { "name": "Queue Name", "type": "text" }, { "name": "Key Filter", "type": "text" }, { "name": "Tag Filter", "type": "text" } ],
          "outputs": [ { "name": "Item ID", "type": "text" }, { "name": "Data", "type": "collection" }, { "name": "Status", "type": "text" }, { "name": "Attempt", "type": "number" }, { "name": "Key Value", "type": "text" } ] }
      ] }
  ] }
```

Rules: `object` is the display name exactly as an Action stage's `<resource object="...">` writes it.
`type` is the Blue Prism data type in lower case (`text`, `number`, `flag`, `date`, `datetime`, `time`, `timespan`,
`password`, `collection`, `image`, `binary`). Every object gets `"verified": true`. Include objects with no actions.

## Where it comes from

The internal objects live in `AutomateAppCore.dll` in the Blue Prism install folder. Each is a class derived from
the internal business object base class (name contains `InternalBusinessObject`); each exposes its actions
(a method like `GetActions()` returning action objects with a name and a parameter list, each parameter with a
name, a direction in/out and a data type). PowerShell can load the assembly with reflection, walk those types
and write the JSON. Nothing runs, nothing is written to the database, no process is started: it only reads type
metadata. The display name of an object may be a localized resource rather than the class name: take the name
an Action stage uses (compare with one Action stage in any exported process that calls Work Queues).

If a type needs a live connection to construct, do not construct it: read the action list statically
(the method that lists actions is usually callable on an instance created with a null session; if not, the
action classes themselves carry the names and parameters as fields).

## How to check it

Put the file at `gumball/internal/internal.json`, start gumball, open any process that calls Work Queues:
the Objects known list shows Work Queues tagged `I` with the action count, and the release checks stop skipping
internal objects (an Action stage naming a wrong action is then an error, as it would be in Studio).

## Constraints

No executable is built or copied. PowerShell only. The script and the JSON stay on the machine; only the JSON
travels to gumball.
