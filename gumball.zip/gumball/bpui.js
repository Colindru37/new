// bpui: the browser side of gumball. Draws every page from the model, lets you move stages, draw links,
// delete, edit a stage's properties in the sheet, checks the estate rules live, and saves the next version.
// Expects globals: BW_XML (string), BW_BASE (name), BW_VER (number), BW_DIFF (json or null), BW_INCIDENT (json or null).
(function () {
'use strict';
var D = window.BPDRAW, E = window.BPEDIT;
var M = E.modelFrom(BW_XML), mode = 'select', sel = null, linkFrom = null, scale = 1, undo = [], cur = 0;
var OBJ = (typeof BW_OBJECTS !== 'undefined' && BW_OBJECTS) || [], place = null, multi = [];
var ov = { pages: {}, changed: new Set(BW_DIFF ? BW_DIFF.changedIds : []) };
if (BW_INCIDENT) { var o2 = D.overlayFrom(BW_INCIDENT); ov.pages = o2.pages; }
function $(id) { return document.getElementById(id); }
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

// ---------- pages ----------
function label(pg) { return pg === 'Main Page' && M.type === 'object' ? 'Initialise' : pg; }
function pages() { return E.pagesOf(M).sort(function (a, b) { return (a === 'Main Page' ? 0 : 1) - (b === 'Main Page' ? 0 : 1) || a.localeCompare(b); }); }
function renderAll() {
  var pg = pages(), list = '', panes = '';
  for (var i = 0; i < pg.length; i++) {
    ov.studio = !document.body.classList.contains('dark');
    var svg = D.renderPage(E.bpOf(M), pg[i], ov) || '<p>(empty page)</p>';
    list += '<li data-i="' + i + '" class="' + (i === cur ? 'on' : '') + '">' + esc(label(pg[i])) + '</li>';
    panes += '<section id="p' + i + '"' + (i === cur ? '' : ' hidden') + '><h2>' + esc(M.name) + ' / ' + esc(pg[i]) + '</h2>' + svg + '</section>';
  }
  $('pages').innerHTML = list; $('panes').innerHTML = panes; palette();
  [].forEach.call(document.querySelectorAll('#pages li'), function (li) { li.onclick = function () { cur = +li.dataset.i; renderAll(); }; });
  applyScale(); rules(); if (sel) highlight(sel);
}
function renderPage() { ov.studio = !document.body.classList.contains('dark'); var pg = pages()[cur]; var sec = $('p' + cur); sec.innerHTML = '<h2>' + esc(M.name) + ' / ' + esc(label(pg)) + '</h2>' + (D.renderPage(E.bpOf(M), pg, ov) || ''); applyScale(); rules(); if (sel) highlight(sel); }
function applyScale() { [].forEach.call(document.querySelectorAll('svg'), function (s) { s.style.transform = 'scale(' + scale + ')'; }); }
window.z = function (f) { scale = f ? Math.min(3, Math.max(0.25, scale * f)) : 1; applyScale(); };
document.addEventListener('wheel', function (e) { if (!e.ctrlKey) return; var m = e.target.closest && e.target.closest('main'); if (!m) return; e.preventDefault(); window.z(e.deltaY < 0 ? 1.1 : 0.9); }, { passive: false });
function highlight(id) { [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); var ids = id ? [id] : []; ids = ids.concat(multi); ids.forEach(function (i) { [].forEach.call(document.querySelectorAll('[data-sid="' + i + '"]'), function (g) { g.classList.add('on'); }); }); }

// ---------- undo ----------
// One state = which stages exist (by reference), each stage's changeable fields (copied), and the page lists.
// Undo and redo both restore a whole state, so added/removed stages and pages come back either way.
var redo = [];
function capture() {
  return { stages: M.stages.slice(), fields: JSON.stringify(M.stages.map(function (s) { return { x: s.x, y: s.y, w: s.w, h: s.h, name: s.name, deleted: s.deleted, edits: s.edits }; })),
           pages: JSON.stringify(M.pages), added: JSON.stringify(M.addedPages || []), removed: JSON.stringify(M.removedPages || []), appdef: M.appdef == null ? null : M.appdef };
}
function restore(st) {
  var f = JSON.parse(st.fields); M.stages = st.stages.slice(); M.byId = {};
  for (var i = 0; i < M.stages.length; i++) { var s = M.stages[i], v = f[i]; s.x = v.x; s.y = v.y; s.w = v.w; s.h = v.h; s.name = v.name; s.deleted = v.deleted; s.edits = v.edits; M.byId[s.id] = s; }
  M.pages = JSON.parse(st.pages); M.addedPages = JSON.parse(st.added); M.removedPages = JSON.parse(st.removed);
  if ((st.appdef == null ? null : st.appdef) !== (M.appdef == null ? null : M.appdef)) { M.appdef = st.appdef; if (typeof moSync === 'function') moSync(); }
  if (sel && (!M.byId[sel] || M.byId[sel].deleted)) { sel = null; closeSheet(); } multi = [];
  if (cur >= pages().length) cur = 0; renderAll(); if (sel) openSheet(sel);
}
function snap() { undo.push(capture()); if (undo.length > 50) undo.shift(); redo = []; }   // a new change ends the redo line
window.doUndo = function () { if (!undo.length) { toast('nothing to undo'); return; } redo.push(capture()); restore(undo.pop()); toast(undo.length ? 'undone (' + undo.length + ' more, Ctrl+Y redoes)' : 'undone (Ctrl+Y redoes)'); };
window.doRedo = function () { if (!redo.length) { toast('nothing to redo'); return; } undo.push(capture()); restore(redo.pop()); toast(redo.length ? 'redone (' + redo.length + ' more)' : 'redone'); };

// ---------- palette: add a stage (click a kind, then click the canvas), add a page ----------
var NICE = { Action: 'Action', Decision: 'Decision', Calculation: 'Calc', MultipleCalculation: 'Multi Calc', SubSheet: 'Page call', Code: 'Code', Data: 'Data', Collection: 'Collection', Exception: 'Exception', Recover: 'Recover', Resume: 'Resume', Anchor: 'Anchor', LoopStart: 'Loop start', LoopEnd: 'Loop end', Note: 'Note', Block: 'Block', Start: 'Start', End: 'End' };
function palette() {
  var el = $('palette'); if (!el) return;
  var kinds = E.PALETTE.filter(function (k) { return !(M.type === 'process' && k === 'Code'); });
  el.innerHTML = kinds.map(function (k) { return '<button data-k="' + k + '" class="' + (place === k ? 'on' : '') + '">' + esc(NICE[k] || k) + '</button>'; }).join('');
  [].forEach.call(el.querySelectorAll('button'), function (b) { b.onclick = function () { startPlace(b.dataset.k); }; });
}
function startPlace(k) { place = place === k ? null : k; palette(); linkFrom = null; if (place) toast('click on the page where the ' + (NICE[place] || place) + ' goes'); document.body.classList.toggle('placing', !!place); }
function svgPoint(svg, e, raw) { var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var p = pt.matrixTransform(svg.getScreenCTM().inverse()); return raw ? { x: p.x, y: p.y } : { x: Math.round(p.x / 15) * 15, y: Math.round(p.y / 15) * 15 }; }
window.removePage = function () {
  var pg = pages()[cur]; if (pg === 'Main Page' || M.stages.some(function (s) { return !s.deleted && s.page === pg && s.type === 'ProcessInfo'; })) { toast('the main page stays'); return; }
  if (!confirm('Remove the page "' + pg + '" and everything on it?')) return;
  snap(); E.removePage(M, pg); cur = 0; multi = []; closeSheet(); renderAll(); toast('page removed - page calls to it are flagged in Checks');
};
window.toggleHelp = function () { $('help').hidden = !$('help').hidden; };
window.addPage = function (given) {
  var name = given || prompt('Name of the new page'); if (!name) return; name = name.trim(); if (!name) return;
  if (pages().indexOf(name) >= 0) { toast('there is a page called that already'); return; }
  snap(); E.addPage(M, name); cur = pages().indexOf(name); renderAll(); toast('page "' + name + '" added with Start and End');
};

// ---------- modes ----------
window.setMode = function (m) { var was = mode; mode = m; linkFrom = null; if (place) { place = null; palette(); document.body.classList.remove('placing'); } [].forEach.call(document.querySelectorAll('.tb button[data-mode]'), function (b) { b.classList.toggle('on', b.dataset.mode === m); }); if (m !== was && m !== 'select') toast({ link: 'click the stage the link leaves, then where it goes', delete: 'click a stage to remove it' }[m]); };

// ---------- mouse: drag / link / delete ----------
var drag = null;
var band = null;
function gOf(id) { return document.querySelector('section:not([hidden]) [data-sid="' + id + '"]'); }
function groupFor(st) {   // what moves with a stage: the multi selection if it is in it, a block's members, a pair's partner
  var ids = multi.indexOf(st.id) >= 0 ? multi.slice() : [st.id];
  var out = {}; ids.forEach(function (i) { out[i] = 1; var s = M.byId[i]; if (!s) return; if (s.type === 'Block') E.membersOf(M, s).forEach(function (q) { out[q.id] = 1; }); });
  return Object.keys(out);
}
document.addEventListener('mousedown', function (e) {
  if (mode !== 'select' || place || e.button !== 0) return;
  var h = e.target.closest && e.target.closest('.rsz');
  if (h) { var rs = M.byId[h.getAttribute('data-sid')]; if (rs) { drag = { resize: rs, x0: e.clientX, y0: e.clientY, moved: false, w0: rs.w, h0: rs.h }; e.preventDefault(); } return; }
  var g = e.target.closest && e.target.closest('g.st,g.blk');
  if (!g) { var svg = e.target.closest && e.target.closest('svg'); if (!svg) return; var p0 = svgPoint(svg, e, true); band = { svg: svg, x0: p0.x, y0: p0.y, el: null }; e.preventDefault(); return; }
  var st = M.byId[g.getAttribute('data-sid')]; if (!st) return;
  if (e.shiftKey) { var i = multi.indexOf(st.id); if (i >= 0) multi.splice(i, 1); else multi.push(st.id); sel = null; highlight(null); e.preventDefault(); return; }
  if (multi.indexOf(st.id) < 0) { multi = []; }
  drag = { st: st, ids: groupFor(st), x0: e.clientX, y0: e.clientY, moved: false }; e.preventDefault();
});
document.addEventListener('mousemove', function (e) {
  if (band) { var p = svgPoint(band.svg, e, true); if (!band.el) { band.el = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); band.el.setAttribute('class', 'band'); band.svg.appendChild(band.el); } band.el.setAttribute('x', Math.min(p.x, band.x0)); band.el.setAttribute('y', Math.min(p.y, band.y0)); band.el.setAttribute('width', Math.abs(p.x - band.x0)); band.el.setAttribute('height', Math.abs(p.y - band.y0)); return; }
  if (!drag) return; var dx = (e.clientX - drag.x0) / scale, dy = (e.clientY - drag.y0) / scale;
  if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true;
  if (drag.resize) { var r = gOf(drag.resize.id).querySelector('rect.shape,rect.blkr'); if (r) { r.setAttribute('width', Math.max(30, drag.w0 + dx)); r.setAttribute('height', Math.max(20, drag.h0 + dy)); } return; }
  drag.ids.forEach(function (i) { var g = gOf(i); if (g) g.setAttribute('transform', 'translate(' + dx + ',' + dy + ')'); });
});
document.addEventListener('mouseup', function (e) {
  if (band) { var b = band; band = null; if (!b.el) return; var x = +b.el.getAttribute('x'), y = +b.el.getAttribute('y'), w = +b.el.getAttribute('width'), h = +b.el.getAttribute('height'); b.el.remove(); if (w < 4 && h < 4) return;
    var pg = pages()[cur]; multi = M.stages.filter(function (s) { return !s.deleted && s.page === pg && s.type !== 'Block' && s.x >= x && s.x <= x + w && s.y >= y && s.y <= y + h; }).map(function (s) { return s.id; });
    sel = null; closeSheet(); highlight(null); if (multi.length) toast(multi.length + ' selected - drag them together, Del removes them'); return; }
  if (!drag) return; var d = drag; drag = null;
  var dx = (e.clientX - d.x0) / scale, dy = (e.clientY - d.y0) / scale;
  if (!d.moved) return;
  snap();
  if (d.resize) { E.resize(d.resize, Math.max(30, Math.round((d.w0 + dx) / 15) * 15), Math.max(20, Math.round((d.h0 + dy) / 15) * 15)); renderPage(); return; }
  var snapG = document.body.classList.contains('grid') ? function (v) { return Math.round(v / 15) * 15; } : function (v) { return v; };
  d.ids.forEach(function (i) { var s = M.byId[i]; E.move(s, snapG(s.x + dx), snapG(s.y + dy)); });
  if (d.ids.length === 1) sel = d.st.id; renderPage();
});
document.addEventListener('click', function (e) {
  if (place) {
    var svg = e.target.closest && e.target.closest('svg'); if (!svg) return;
    var p = svgPoint(svg, e), k = place;
    if (k === 'Start' && M.stages.some(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'Start'; })) { toast('this page already has a Start: Blue Prism allows exactly one'); place = null; palette(); document.body.classList.remove('placing'); setMode('select'); return; }
    snap();
    var st = E.addStage(M, k, pages()[cur], p.x, p.y);
    if (k === 'Action' && OBJ.length && OBJ[0].actions.length) E.setResource(st, OBJ[0].object, OBJ[0].actions[0].name, OBJ[0].actions[0].inputs, OBJ[0].actions[0].outputs);
    if (k === 'SubSheet') { var other = pages().filter(function (q) { return q !== pages()[cur]; })[0]; if (other) { E.rename(st, other); E.setPageCall(M, st, other); } }
    if (k === 'LoopStart') { var gid = /<groupid>([^<]*)</.exec(st.orig.body)[1]; var le = E.addStage(M, 'LoopEnd', pages()[cur], p.x, p.y + 120, { groupid: gid }); E.setLink(st, 'onsuccess', le.id); }
    if (k === 'LoopEnd') { var open = M.stages.filter(function (s) { return !s.deleted && s.page === pages()[cur] && s.type === 'LoopStart' && !E.partnerOf(M, s); })[0]; if (open) { st.orig.body = st.orig.body.replace(/<groupid>[^<]*<\/groupid>/, '<groupid>' + /<groupid>([^<]*)</.exec(open.orig.body)[1] + '</groupid>'); } else { toast('place the Loop start first'); } }
    place = null; palette(); document.body.classList.remove('placing'); setMode('select'); sel = st.id; renderPage(); openSheet(st.id); toast(NICE[k] + ' added' + (/^(Data|Collection|Note|Block|End|LoopEnd)$/.test(k) ? '' : ' - wire it with L')); return;
  }
  var g = e.target.closest && e.target.closest('g.st,g.blk'); if (!g) return;
  var id = g.getAttribute('data-sid'), st = M.byId[id]; if (!st) return;
  if (mode === 'delete') { if (/^(Start|End)$/.test(st.type)) { toast('Start and End stay'); return; } snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); return; }
  if (mode === 'link') {
    if (!linkFrom) { linkFrom = st; highlight(id); toast('now click where "' + st.name + '" goes'); return; }
    if (linkFrom.type === 'Decision') { askYesNo(function (kind) { snap(); E.setLink(linkFrom, kind, st.id); linkFrom = null; setMode('link'); renderPage(); }); return; }
    if (/^(End|Exception|Note|Data|Collection|Block)$/.test(linkFrom.type)) { toast(linkFrom.type + ' has no outgoing link'); linkFrom = null; setMode('link'); return; }
    snap(); E.setLink(linkFrom, 'onsuccess', st.id); linkFrom = null; setMode('link'); renderPage(); return;
  }
  sel = id; highlight(id); openSheet(id);
});
document.addEventListener('keydown', function (e) { var typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName); if ((e.ctrlKey || e.metaKey) && !typing && (e.key.toLowerCase() === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) { e.preventDefault(); doRedo(); return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); doUndo(); return; } if (!typing && !e.ctrlKey && !e.altKey) { if (e.shiftKey) { if (e.key === 'L') { toggleTheme(); return; } } else { var km = { v: 'select', l: 'link', d: 'delete' }[e.key.toLowerCase()]; if (km) { setMode(km); return; } if (e.key.toLowerCase() === 'a') { startPlace('Action'); return; } if (e.key.toLowerCase() === 'g') { toggleGrid(); return; } } } if (e.key === 'Delete' && !typing) { if (multi.length) { snap(); multi.forEach(function (i) { var s = M.byId[i]; if (s && !/^(Start|End)$/.test(s.type)) removeWithPartner(s); }); multi = []; closeSheet(); renderPage(); return; } if (sel) { var st = M.byId[sel]; if (st && !/^(Start|End)$/.test(st.type)) { snap(); removeWithPartner(st); sel = null; closeSheet(); renderPage(); } } } if (e.key === 'Escape') { linkFrom = null; if (place) startPlace(place); else closeSheet(); } });
function removeWithPartner(st) { var p = E.partnerOf(M, st); E.remove(M, st); if (p) { E.remove(M, p); toast(st.type + ' and ' + p.type + ' removed together'); } }
function askYesNo(cb) { var d = $('yesno'); d.hidden = false; d.querySelector('.y').onclick = function () { d.hidden = true; cb('ontrue'); }; d.querySelector('.n').onclick = function () { d.hidden = true; cb('onfalse'); }; }
function toast(t) { var el = $('toast'); el.textContent = t; el.hidden = false; clearTimeout(el._t); el._t = setTimeout(function () { el.hidden = true; }, 2200); }

// ---------- sheet (editable) ----------
function field(label, id, value, kind) { return '<dt>' + esc(label) + '</dt><dd>' + (kind === 'area' ? '<textarea data-f="' + id + '">' + esc(value) + '</textarea>' : '<input data-f="' + id + '" value="' + esc(value) + '">') + '</dd>'; }
function openSheet(id) {
  var st = M.byId[id]; if (!st || st.deleted) return;
  if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); }
  var bp = E.bpOf(M), idName = {}; for (var i = 0; i < bp.stages.length; i++) idName[bp.stages[i].id] = bp.stages[i].name;
  var cur = bp.stages.filter(function (s) { return s.id === id; })[0]; var info = D.stageInfo(cur, bp, idName);
  $('sh-type').textContent = st.type; $('sh-name').textContent = st.name;
  var h = '<h4>Stage</h4><dl>' + (st.type === 'SubSheetInfo' || st.type === 'ProcessInfo' ? '<dt>Name</dt><dd>' + esc(st.name) + '</dd>' : field('Name', 'name', st.name)) + field('Description', 'narrative', info.desc, 'area') + '<dt>Page</dt><dd>' + esc(st.page) + '</dd>';
  var b = cur.body;
  if (st.type === 'Action') {
    var r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b), ro = r ? D.unx(r[1]) : '', ra = r ? D.unx(r[2]) : '';
    if (OBJ.length) {
      var known = OBJ.some(function (o) { return o.object === ro; });
      h += '<dt>Business Object</dt><dd><select id="pick-obj" onchange="pickAction(\'' + id + '\')">' + (known ? '' : '<option selected>' + esc(ro || '(choose)') + '</option>') + OBJ.map(function (o) { return '<option' + (o.object === ro ? ' selected' : '') + '>' + esc(o.object) + '</option>'; }).join('') + '</select></dd>';
      var acts = (OBJ.filter(function (o) { return o.object === ro; })[0] || { actions: [] }).actions, knownA = acts.some(function (a) { return a.name === ra; });
      h += '<dt>Action</dt><dd><select id="pick-act" onchange="pickAction(\'' + id + '\')">' + (knownA ? '' : '<option selected>' + esc(ra || '(choose)') + '</option>') + acts.map(function (a) { return '<option' + (a.name === ra ? ' selected' : '') + '>' + esc(a.name) + '</option>'; }).join('') + '</select></dd>';
    } else h += '<dt>Business Object</dt><dd>' + esc(ro) + '</dd><dt>Action</dt><dd>' + esc(ra) + ' <span class="muted">(drop the object exports next to the xml and re-render to pick actions)</span></dd>';
    var ourl = objUrl(ro, ra);
    if (ourl) h += '<dt></dt><dd><a class="jump" href="' + esc(ourl) + '" onclick="return leaveOk()">Open ' + esc(ro) + ' / ' + esc(ra) + ' &#8599;</a></dd>';
    else if (ro) h += '<dt></dt><dd><span class="muted">' + esc(ro) + (MEMBERS.length ? ' is not in this release' : ' is not open in gumball: drop its export in the inbox to open it from here') + '</span></dd>';
  }
  if (st.type === 'SubSheet') { var tgt = M.pages[D.tag(b, 'processid')] || ''; h += '<dt>Page called</dt><dd><select id="pick-page" onchange="pickPage(\'' + id + '\')">' + (tgt ? '' : '<option selected>(choose)</option>') + pages().filter(function (q) { return q !== st.page; }).map(function (q) { return '<option' + (q === tgt ? ' selected' : '') + '>' + esc(q) + '</option>'; }).join('') + '</select></dd>'; }
  if (st.type === 'Decision') h += field('Expression', 'decision', D.attr((/<decision ([^>]*)\/>/.exec(b) || ['', ''])[1], 'expression')) + '<dt>Yes</dt><dd>' + esc(idName[E.linkOf(st, 'ontrue')] || '-') + '</dd><dt>No</dt><dd>' + esc(idName[E.linkOf(st, 'onfalse')] || '-') + '</dd>';
  if (st.type === 'Exception') { var ex = (/<exception ([^>]*)\/>/.exec(b) || ['', ''])[1]; h += '<dt>Type</dt><dd><select data-f="ex.type"><option' + (D.attr(ex, 'type') === 'System Exception' ? ' selected' : '') + '>System Exception</option><option' + (D.attr(ex, 'type') === 'Business Exception' ? ' selected' : '') + '>Business Exception</option><option' + (D.attr(ex, 'type') === 'Runtime Exception' ? ' selected' : '') + '>Runtime Exception</option></select></dd>' + field('Detail', 'ex.detail', D.attr(ex, 'detail')); }
  if (st.type === 'Data') h += '<dt>Data Type</dt><dd><select data-f="datatype">' + ['text', 'number', 'flag', 'date', 'datetime', 'time', 'timespan', 'password', 'binary', 'image'].map(function (t) { return '<option' + (t === D.tag(b, 'datatype') ? ' selected' : '') + '>' + t + '</option>'; }).join('') + '</select></dd>' + field('Initial Value', 'initialvalue', D.unx(D.tag(b, 'initialvalue'))) + '<dt>Exposure</dt><dd>' + esc(D.tag(b, 'exposure') || 'none') + '</dd>';
  if (st.type === 'ProcessInfo') {
    var lang = D.tag(b, 'language'), refs = (b.match(/<reference>[^<]*<\/reference>/g) || []).map(function (r) { return D.unx(r.slice(11, -12)); }), imps = (b.match(/<import>[^<]*<\/import>/g) || []).map(function (r) { return D.unx(r.slice(8, -9)); });
    h += '<dt>Language</dt><dd><select data-f="language"><option value="csharp"' + (lang === 'csharp' ? ' selected' : '') + '>C#</option><option value="visualbasic"' + (lang === 'visualbasic' ? ' selected' : '') + '>VB.NET</option></select></dd>';
    h += '<dt>References</dt><dd><textarea data-f="references" title="one .dll per line">' + esc(refs.join('\n')) + '</textarea></dd><dt>Namespaces</dt><dd><textarea data-f="imports" title="one namespace per line">' + esc(imps.join('\n')) + '</textarea></dd>';
  }
  if (st.type === 'LoopStart') h += field('Collection', 'loopdata', D.unx(D.tag(b, 'loopdata'))) + '<dt>Loop end</dt><dd>' + esc((E.partnerOf(M, st) || {}).name || '(missing)') + '</dd>';
  if (st.type === 'Block') h += '<dt>Holds</dt><dd>' + esc(E.membersOf(M, st).map(function (q) { return q.name; }).join(', ') || '(nothing: drag stages inside)') + '</dd>';
  if (!/^(Decision|Start|End|Data|Collection|Note|Block|SubSheetInfo|ProcessInfo)$/.test(st.type)) h += '<dt>Next</dt><dd>' + esc(idName[E.linkOf(st, 'onsuccess')] || '-') + '</dd>';
  var isInfo = /^(SubSheetInfo|ProcessInfo|Block|Note|Data|Collection)$/.test(st.type);
  var li = /<loginhibit\s*\/>/.test(b) ? 'off' : /<loginhibit onsuccess="true"/.test(b) ? 'error' : 'on';
  if (isInfo) h += '</dl>'; else h += '<dt>Logging</dt><dd><select data-f="loginhibit"><option value="on"' + (li === 'on' ? ' selected' : '') + '>Logged</option><option value="error"' + (li === 'error' ? ' selected' : '') + '>Log only on error</option><option value="off"' + (li === 'off' ? ' selected' : '') + '>Don\'t log this stage</option></select></dd></dl>';
  if (st.type === 'Calculation' || st.type === 'MultipleCalculation') {
    var rows = []; var re = /<calculation expression="([^"]*)" stage="([^"]*)"/g, m; while ((m = re.exec(b))) rows.push([D.unx(m[1]), D.unx(m[2])]);
    if (st.type === 'MultipleCalculation') rows.push(['', '']);
    h += '<h4>Calculations</h4><table id="calcs"><tr><th>Expression</th><th>Store In</th></tr>' + rows.map(function (r) { return '<tr><td><input value="' + esc(r[0]) + '"></td><td><input value="' + esc(r[1]) + '"></td></tr>'; }).join('') + '</table>';
  }
  var ins = []; var rin = /<input ([^>]*)\/>/g; while ((m = rin.exec(b))) ins.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'expr')]);
  var outs = []; var rout = /<output ([^>]*)\/>/g; while ((m = rout.exec(b))) outs.push([D.attr(m[1], 'name'), D.attr(m[1], 'type'), D.attr(m[1], 'stage')]);
  if (ins.length && st.type !== 'Start') h += '<h4>Inputs</h4><table><tr><th>Name</th><th>Type</th><th>Value</th></tr>' + ins.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="in:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  if (outs.length && st.type !== 'End') h += '<h4>Outputs</h4><table><tr><th>Name</th><th>Type</th><th>Store In</th></tr>' + outs.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td><input data-f="out:' + esc(r[0]) + '" value="' + esc(r[2]) + '"></td></tr>'; }).join('') + '</table>';
  for (var t = 0; t < info.tables.length; t++) { var tb = info.tables[t]; if (/^(Inputs|Outputs|Calculations)$/.test(tb.title)) continue; h += '<h4>' + esc(tb.title) + '</h4><table><tr>' + tb.cols.map(function (c) { return '<th>' + esc(c) + '</th>'; }).join('') + '</tr>' + tb.rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>'; }
  if (st.type === 'Code') h += '<h4>Code</h4><textarea data-f="code" class="code">' + esc(info.code) + '</textarea>';
  if (st.type === 'ProcessInfo') h += '<h4>Shared code</h4><p class="muted">fields and helpers every code stage of this object can use (Blue Prism keeps them in the Code Options stage)</p><textarea data-f="code" class="code">' + esc(D.tag(b, 'code').replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, '')) + '</textarea>';
  h += '<p class="apply"><button onclick="applySheet(\'' + id + '\')">Apply</button></p>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false;
  [].forEach.call($('sh-body').querySelectorAll('input'), function (i) { i.onkeydown = function (e) { if (e.key === 'Enter') applySheet(id); }; });
}
window.applySheet = function (id) {
  var st = M.byId[id]; if (!st) return; snap();
  var ex = {};
  [].forEach.call($('sh-body').querySelectorAll('[data-f]'), function (el) {
    var f = el.dataset.f, v = el.value;
    if (f === 'name') { if (v !== st.name) E.rename(st, v); }
    else if (f === 'ex.type') ex.type = v; else if (f === 'ex.detail') ex.detail = v;
    else if (f === 'narrative') { if (v !== D.unx(D.tag(st.orig.body, 'narrative'))) E.setField(st, 'narrative', v); }
    else if (f === 'references' || f === 'imports') E.setField(st, f, v.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean));
    else E.setField(st, f, v);
  });
  if (ex.type !== undefined) E.setField(st, 'exception', ex);
  var calcs = $('calcs'); if (calcs) E.setField(st, 'calcs', [].map.call(calcs.querySelectorAll('tr'), function (tr) { var i = tr.querySelectorAll('input'); return i.length ? [i[0].value, i[1].value] : null; }).filter(Boolean));
  renderPage(); openSheet(id); toast('applied');
};
window.pickAction = function (id) {
  var st = M.byId[id]; if (!st) return; var o = $('pick-obj').value, acts = (OBJ.filter(function (x) { return x.object === o; })[0] || { actions: [] }).actions;
  var cur = $('pick-act').value, a = acts.filter(function (x) { return x.name === cur; })[0] || acts[0]; if (!a) return;
  snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setResource(st, o, a.name, a.inputs, a.outputs); renderPage(); openSheet(id);
};
window.pickPage = function (id) { var st = M.byId[id]; if (!st) return; var q = $('pick-page').value; if (pages().indexOf(q) < 0) return; snap(); for (var k in st.edits) if (/^(in|out):/.test(k)) delete st.edits[k]; E.setPageCall(M, st, q); renderPage(); openSheet(id); };
window.closeSheet = function () { $('sheet').hidden = true; sel = null; if (typeof selEl !== 'undefined' && selEl) { selEl = null; if (typeof moTree === 'function') moTree(); } [].forEach.call(document.querySelectorAll('g.st.on,g.blk.on'), function (g) { g.classList.remove('on'); }); };

// ---------- rules + save ----------
function rules() {
  var r = E.checkRules(M), errs = r.filter(function (x) { return x.level === 'error'; }), warns = r.filter(function (x) { return x.level === 'warn'; });
  $('rules').innerHTML = (r.length ? r.map(function (x) { return '<li class="' + x.level + '">' + esc(x.page ? x.page + ' / ' : '') + (x.stage ? '<b>' + esc(x.stage) + '</b>: ' : '') + esc(x.msg) + '</li>'; }).join('') : '<li class="ok">all rules pass</li>');
  $('rulecount').textContent = errs.length ? errs.length + ' problem' + (errs.length === 1 ? '' : 's') + (warns.length ? ', ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : '') : warns.length ? 'ok, ' + warns.length + ' warning' + (warns.length === 1 ? '' : 's') : 'all rules pass';
  var stat = (typeof BW_STATIC !== 'undefined' && BW_STATIC) || {}; if (stat.compile === false) { $('rulecount').textContent += ' - code does not compile'; errs.push(1); } else if (stat.validate === false) { $('rulecount').textContent += ' - validate found problems'; errs.push(1); }
  $('checks').className = errs.length ? 'bad' : warns.length ? 'meh' : 'good';
  $('save').disabled = errs.length > 0; $('save').title = errs.length ? 'fix the errors first' : (window.BW_SERVE ? 'save as ' : 'download ') + nextName();
}
function nextName() { return BW_BASE + '.v' + (BW_VER + 1) + '.xml'; }
window.saveXml = function () {
  var xml = E.serialize(M);
  if (window.BW_SERVE) {   // served by gumball: the next version goes straight into the project folder and opens with its diff
    try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
    toast('saving...');
    fetch('/save?base=' + encodeURIComponent(window.BW_SERVE.base) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST', body: xml }).then(function (r) { return r.json(); })
      .then(function (j) { if (j.error) { toast('save failed: ' + j.error); return; } toast('saved ' + j.name); location.href = j.url; }, function (e) { toast('save failed: is gumball still running? ' + e); });
    return;
  } var blob = new Blob([xml], { type: 'text/xml' }); var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nextName(); document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  try { localStorage.setItem('gumball:' + BW_BASE, xml); } catch (e) { }
  toast('downloaded ' + nextName() + ' - drop it next to this file and run gumball render on it');
};
window.copyXml = function () { var xml = E.serialize(M); if (navigator.clipboard) navigator.clipboard.writeText(xml).then(function () { toast('XML copied'); }, function () { toast('copy refused'); }); };
window.toggleGrid = function () { var g = document.body.classList.toggle('grid'); try { localStorage.setItem('gumball:grid', g ? '1' : '0'); } catch (e) { } $('gridb').classList.toggle('on', g); toast(g ? 'grid on: stages snap to the 15px Studio grid' : 'grid off: free placement'); };
window.toggleTheme = function () { var d = document.body.classList.toggle('dark'); try { localStorage.setItem('gumball:theme', d ? 'dark' : 'light'); } catch (e) { } renderAll(); toast(d ? 'dark' : 'light: Blue Prism Studio look'); };
window.openSheet = openSheet;
window.toggleChecks = function () { $('checkpanel').hidden = !$('checkpanel').hidden; };
window.toggleDiff = function () { $('diff').hidden = !$('diff').hidden; };

// ---------- search ----------
$('q').onkeydown = function (e) { if (e.key !== 'Enter') return; var q = this.value.toLowerCase(); if (!q) return; var pg = pages(); for (var i = 0; i < pg.length; i++) { var hit = M.stages.some(function (s) { return !s.deleted && s.page === pg[i] && s.name.toLowerCase().indexOf(q) >= 0; }); if (hit) { cur = i; renderAll(); return; } } toast('no stage named like that'); };

// ---------- release navigation (served releases): every member one click away; Action stages jump to their object's action ----------
var SERVED = !!window.BW_SERVE, LINKS = (typeof BW_LINKS !== 'undefined' && BW_LINKS) || {};
var MEMBERS = (SERVED && window.BW_SERVE.members) || (typeof BW_MEMBERS !== 'undefined' && BW_MEMBERS) || [];
var RELNAME = (SERVED && window.BW_SERVE.relName) || (typeof BW_RELNAME !== 'undefined' && BW_RELNAME) || '';
function objUrl(name, pageName) {   // address of an object's page, on the page of one action. Served: through gumball; from the folder: the neighbour's file
  if (!name) return null; var k = '~' + String(name).replace(/\s+/g, ' ').trim().toLowerCase();
  var so = SERVED && window.BW_SERVE.objects, u = (so && (so[name] || so[k])) || LINKS[name] || LINKS[k]; if (!u) return null;
  return u + (pageName ? '#page=' + encodeURIComponent(pageName) : '');
}
function actionsOf(name) { for (var i = 0; i < OBJ.length; i++) if (OBJ[i].object === name) return OBJ[i].actions; return null; }
function actionsText(acts) { return acts.length + ' published action' + (acts.length === 1 ? '' : 's') + (acts.length ? ': ' + acts.map(function (a) { return a.name; }).slice(0, 14).join(', ') + (acts.length > 14 ? ', ...' : '') : ''); }
window.leaveOk = function () { return !undo.length || confirm('You have changes that are not saved. Leave this page anyway?'); };
function miniList(boxId, title, items, onRender) {
  var box = $(boxId); if (!box) return;
  var openKey = 'gumball:open:' + boxId, isOpen = true; try { isOpen = localStorage.getItem(openKey) !== '0'; } catch (e) { }
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">' + title + '</summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul');
  det.ontoggle = function () { try { localStorage.setItem(openKey, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var q = inp.value.toLowerCase(), hit = items.filter(function (it) { return it.text.toLowerCase().indexOf(q) >= 0; });
    ul.innerHTML = hit.slice(0, 300).map(function (it, i) { return '<li class="' + (it.on ? 'on' : '') + '" title="' + esc(it.title || it.text) + '" data-i="' + items.indexOf(it) + '"><b>' + esc(it.tag || '') + '</b>' + esc(it.text) + '</li>'; }).join('') + (hit.length > 300 ? '<li class="more">' + (hit.length - 300) + ' more: filter</li>' : '') + (hit.length ? '' : '<li class="more">nothing matches</li>');
    [].forEach.call(ul.querySelectorAll('li[data-i]'), function (li) { li.onclick = function () { onRender(items[+li.dataset.i]); }; });
  };
  inp.oninput = draw; draw();
}
// one list: inside a release, the Release list is the list (objects show their actions on hover);
// "Objects known" only shows objects that are NOT members, and on pages outside a release.
var memberNames = {};
if (MEMBERS.length) {
  for (var mi = 0; mi < MEMBERS.length; mi++) memberNames[MEMBERS[mi].name] = 1;
  miniList('relnav', 'Release <span class="muted">' + esc(RELNAME) + ' (' + MEMBERS.length + ')</span>',
    MEMBERS.map(function (m) { var acts = m.type === 'object' ? actionsOf(m.name) : null; return { text: m.name, tag: m.type === 'object' ? 'O' : 'P', title: (m.type === 'object' ? 'object: ' : 'process: ') + m.name + (acts ? ' - ' + actionsText(acts) : ''), on: m.base === BW_BASE, url: m.url }; }),
    function (it) { if (!it.on && leaveOk()) location.href = it.url; });
}
var others = OBJ.filter(function (o) { return !(MEMBERS.length && (memberNames[o.object] || objUrl(o.object))); });
if (others.length) {
  miniList('objknown', (MEMBERS.length ? 'Other objects known' : 'Objects known') + ' <span class="muted">(' + others.length + ')</span>',
    others.map(function (o) { var u = objUrl(o.object); return { text: o.object, tag: o.internal ? 'I' : u ? 'O' : '', title: o.object + ' - ' + (o.internal ? 'Blue Prism internal object (' + (o.verified ? 'verified list' : 'seed list, see internal/README.txt') + ') - ' : '') + actionsText(o.actions) + (o.internal ? '' : u ? ' - click to open it' : MEMBERS.length ? ' - not in this release' : ' - not open in gumball'), url: u }; }),
    function (it) { if (it.url) { if (leaveOk()) location.href = it.url; } else toast(it.title); });
}
// ---------- mordecai: the Application Modeller (objects only) ----------
var MO = window.MORDECAI, selEl = null, MOTAG = { win32: 'W32', aa: 'AA', uia: 'UIA', web: 'WEB', html: 'HTML', sap: 'SAP', region: 'RGN', application: 'APP', none: '' };
function moText() { if (M.appdef != null) return M.appdef; var f = MO && MO.find(M.xml); return f ? M.xml.slice(f.start, f.end) : null; }
function moUsed() { var out = {}, st = E.bpOf(M).stages; for (var i = 0; i < st.length; i++) { var re = /<element id="([^"]+)"/g, m, seen = {}; while ((m = re.exec(st[i].body))) { if (seen[m[1]]) continue; seen[m[1]] = 1; (out[m[1]] = out[m[1]] || []).push(st[i].name); } } return out; }
function moSync() {   // after any change of the model: what stages show for an element, the tree, the open sheet
  var t = moText(); if (!t) return; var p = MO.parse(t); M.elements = {};
  for (var i = 0; i < p.list.length; i++) { var e = p.list[i]; if (e.id) M.elements[e.id] = { name: e.name, type: e.type, attrs: e.attrs.filter(function (a) { return a.inuse; }).map(function (a) { return a.name + '=' + a.value; }) }; }
  moTree(); if (selEl) { if (p.byId[selEl]) openElement(selEl); else { selEl = null; $('sheet').hidden = true; } }
}
function moApply(fn) { try { var t = fn(moText()); snap(); M.appdef = typeof t === 'string' ? t : t.appdef; if (t && t.id) selEl = t.id; moSync(); renderPage(); return true; } catch (e) { toast(e.message); return false; } }
function moTree() {
  var box = $('appmodel'), t = moText(); if (!box || !t) return; var p = MO.parse(t), used = moUsed();
  var spied = p.list.filter(function (e) { return e.attrs.length; }).length, key = 'gumball:open:appmodel', isOpen = true; try { isOpen = localStorage.getItem(key) !== '0'; } catch (e) { }
  var q = (box.querySelector('input') || {}).value || '';
  box.innerHTML = '<details' + (isOpen ? ' open' : '') + '><summary class="navh">Application Modeller <span class="muted">(' + spied + ' spied' + (p.app.mode ? ', ' + esc(p.app.mode) : '') + ')</span></summary><div class="mini"><input placeholder="filter"><ul></ul></div></details>';
  var det = box.querySelector('details'), inp = box.querySelector('input'), ul = box.querySelector('ul'); inp.value = q;
  det.ontoggle = function () { try { localStorage.setItem(key, det.open ? '1' : '0'); } catch (e) { } };
  var draw = function () {
    var f = inp.value.toLowerCase(), hit = p.list.filter(function (e) { return !f || e.name.toLowerCase().indexOf(f) >= 0; });
    ul.innerHTML = hit.map(function (e) { var u = used[e.id]; return '<li class="el' + (e.id === selEl ? ' on' : '') + (e.kind !== 'application' && !u ? ' unused' : '') + '" data-id="' + esc(e.id) + '" style="padding-left:' + (6 + (f ? 0 : e.depth * 10)) + 'px" title="' + esc(e.name + ' - ' + (MO.KINDS[e.kind] ? MO.KINDS[e.kind].label : e.kind) + (u ? ' - used by ' + u.length + ' stage' + (u.length === 1 ? '' : 's') : e.kind === 'application' ? '' : ' - no stage uses it')) + '">' + (MOTAG[e.kind] ? '<i>' + MOTAG[e.kind] + '</i>' : '') + esc(e.name) + '</li>'; }).join('') || '<li class="more">nothing matches</li>';
    [].forEach.call(ul.querySelectorAll('li.el'), function (li) { li.onclick = function () { openElement(li.dataset.id); }; });
  };
  inp.oninput = draw; draw();
}
function openElement(id) {
  var t = moText(); if (!t) return; var p = MO.parse(t), e = p.byId[id]; if (!e) return;
  sel = null; highlight(null); selEl = id; var used = moUsed()[id] || [], K = MO.KINDS[e.kind];
  $('sh-type').textContent = K ? K.label : e.kind === 'application' ? 'Application' : 'Element'; $('sh-name').textContent = e.name;
  var h = '<h4>Element</h4><dl><dt>Name</dt><dd><input value="' + esc(e.name) + '" onchange="moRename(this.value)"></dd><dt>Type</dt><dd>' + esc(e.type || e.base) + (e.base && e.base !== e.type ? ' (' + esc(e.base) + ')' : '') + (e.dtype ? ', ' + esc(e.dtype) : '') + '</dd>'
    + '<dt>Used by</dt><dd>' + (used.length ? used.map(esc).join(', ') : '<span class="muted">no stage</span>') + '</dd></dl>';
  if (e.kind === 'application') h += '<h4>Application</h4><dl><dt>Mode</dt><dd>' + esc(p.app.mode || '(not set)') + '</dd>' + p.app.params.map(function (x) { return '<dt>' + esc(x.name) + '</dt><dd>' + esc(x.value) + '</dd>'; }).join('') + '</dl>';
  var row = function (a) {
    var long = a.value.length > 300, cmps = MO.COMPARISONS.indexOf(a.cmp || 'Equal') >= 0 ? MO.COMPARISONS : MO.COMPARISONS.concat([a.cmp]);
    return '<tr><td><input type="checkbox"' + (a.inuse ? ' checked' : '') + ' onchange="moSet(\'' + esc(a.name) + '\',{inuse:this.checked})" title="match on this attribute"></td><td class="n">' + esc(a.name) + '</td><td><select onchange="moSet(\'' + esc(a.name) + '\',{cmp:this.value})">' + cmps.map(function (c) { return '<option' + ((a.cmp || 'Equal') === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') + '</select></td><td>'
      + (long ? '<span class="muted">' + esc(a.value.slice(0, 40)) + '... (' + a.value.length + ' chars, kept as is)</span>' : '<input value="' + esc(a.value) + '" onchange="moSet(\'' + esc(a.name) + '\',{value:this.value})">') + '</td></tr>';
  };
  if (e.attrs.length) {
    var on = e.attrs.filter(function (a) { return a.inuse; }), off = e.attrs.filter(function (a) { return !a.inuse; });
    h += '<h4>Matched on (' + on.length + ')</h4>' + (on.length ? '<table class="mo">' + on.map(row).join('') + '</table>' : '<div class="muted">nothing ticked: Blue Prism would match the first element it finds</div>');
    h += '<details' + (window._moOpen ? ' open' : '') + ' ontoggle="window._moOpen=this.open"><summary><h4 style="display:inline-block;cursor:pointer">Recorded, not matched (' + off.length + ')</h4></summary><table class="mo">' + off.map(row).join('') + '</table></details>';
  }
  h += '<h4>Model</h4><div class="mobtn">' + (e.attrs.length ? '<button onclick="moAddLike()" title="a new element next to this one with the same type, attributes and match ticks">+ one like this</button>' : '')
    + '<select id="mo-kind">' + Object.keys(MO.KINDS).map(function (k) { return '<option value="' + k + '"' + (k === e.kind ? ' selected' : '') + '>' + esc(MO.KINDS[k].label) + '</option>'; }).join('') + '</select><button onclick="moAddBlank()" title="a new, empty element of that spy mode under this one">+ blank child</button>'
    + (e.attrs.length ? '<button onclick="moFill()" title="paste the JSON a spy printed for this element: its values go into the attributes, ticks stay">fill from spy</button>' : '')
    + (SERVED && MO.KINDS[e.kind] ? '<button onclick="moSpy(false)" style="background:#2f5f9e;color:#fff;border-color:#2f5f9e" title="5 seconds to switch to the application and put the mouse on the control (a region: its two corners, one after the other); the values then fill this element">Spy this element</button>' : '')
    + (SERVED ? '<button onclick="moSpy(true)" title="spy a control (mode from the list on the left) and add it as a new element: inside this window, or next to this control">Spy a new element</button>' : '')
    + (SERVED && e.kind === 'application' ? '<button onclick="moLaunch()" title="start the application from the Path in this model (the last saved version)">Launch application</button>' : '')
    + (e.parent ? '<button onclick="moRemove()" style="margin-left:auto;color:#c62828">remove</button>' : '') + '</div><div class="muted">Values typed here are what Blue Prism will look for. "fill from spy" takes the JSON of a spied element (docs: copilot_mordecai_spy_handoff.md).</div>';
  $('sh-body').innerHTML = h; $('sheet').hidden = false; moTree();
}
window.moSet = function (name, patch) { var id = selEl; moApply(function (t) { return MO.setAttribute(t, id, name, patch); }); };
window.moRename = function (name) { var id = selEl; moApply(function (t) { return MO.rename(t, id, name); }); };
window.moAddLike = function () { var id = selEl, e = MO.parse(moText()).byId[id], n = prompt('Name of the new element:', e.name + ' 2'); if (!n) return; moApply(function (t) { return MO.add(t, e.parent ? e.parent.id : id, n, { like: id }); }); };
window.moAddBlank = function () { var id = selEl, k = $('mo-kind').value, n = prompt('Name of the new ' + MO.KINDS[k].label + ' element:', ''); if (!n) return; moApply(function (t) { return MO.add(t, id, n, { kind: k }); }); };
window.moFill = function () { var id = selEl, raw = prompt('Paste the spy JSON for this element ({"attrs": {...}} or just {name: value}):', ''); if (!raw) return; var j; try { j = JSON.parse(raw); } catch (e) { return toast('not JSON: ' + e.message); }
  var res = null; if (moApply(function (t) { res = MO.fill(t, id, j.attrs || j); return res.appdef; })) toast(res.set.length + ' value(s) set' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : '')); };
// the spy, run by gumball: countdown here, the reading happens in PowerShell, the result lands in the element
var SPY_HINT = { sap: 'the SAP field', html: 'the element in the page (IE mode)', web: 'the element in the Edge page', region: 'the corner' };
function spyCall(mode, secs, say, extra) {   // one run of the spy with a countdown; resolves with its JSON
  var t = $('toast'), left = secs, tick = function () { t.hidden = false; clearTimeout(t._t); t.textContent = left > 0 ? say + ' ... ' + left : 'reading: keep the mouse there until this message changes'; };
  tick(); var iv = setInterval(function () { left--; tick(); if (left <= 0) clearInterval(iv); }, 1000);
  return fetch('/spy?mode=' + mode + '&seconds=' + secs + (extra || ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { clearInterval(iv); t.hidden = true; if (r.error) throw new Error(r.error); return r.spy; }, function (e) { clearInterval(iv); t.hidden = true; throw e; });
}
function spyRegion() {   // two corners, each held under the mouse, then the rectangle is captured
  var a;
  return spyCall('point', 5, 'REGION 1/2: switch to the application and hold the mouse on the TOP-LEFT corner').then(function (p1) { a = p1.point;
    return spyCall('point', 4, 'REGION 2/2: now hold the mouse on the BOTTOM-RIGHT corner'); }).then(function (p2) { var b = p2.point;
    if (!a || !b || b.x <= a.x || b.y <= a.y) throw new Error('the second corner has to be below and to the right of the first (got ' + JSON.stringify(a) + ' then ' + JSON.stringify(b) + ')');
    return spyCall('region', 0, 'capturing', '&x1=' + a.x + '&y1=' + a.y + '&x2=' + b.x + '&y2=' + b.y); });
}
window.moSpy = function (asNew) {
  var id = selEl, e = MO.parse(moText()).byId[id], pick = $('mo-kind') ? $('mo-kind').value : 'uia', ok = function (k) { return !!MO.KINDS[k]; };
  var mode = asNew ? (ok(pick) ? pick : ok(e.kind) ? e.kind : 'uia') : e.kind;
  var run = mode === 'region' ? spyRegion() : spyCall(mode, 5, 'SPY (' + MO.KINDS[mode].label + '): switch to the application and hold the mouse on ' + (SPY_HINT[mode] || 'the control'));
  run.then(function (j) {
    var n = Object.keys(j.attrs || {}).length, extra = mode === 'sap' ? ['SubType'] : [];
    if (!n) { alert('The spy found nothing readable there' + (j.errors ? ':\n' + j.errors.join('\n') : '.')); return; }
    var what = 'Found: ' + (j.name || '(no name)') + ' [' + (j.base || mode) + ']' + (j.errors && j.errors.length ? '\nNotes: ' + j.errors.join('; ') : '');
    if (asNew) {
      var name = prompt(what + '\nName of the new element:', j.name || ''); if (!name) return;
      var under = (e.kind === 'application' || e.children.length || /Window$/.test(e.base) || !e.parent) ? id : e.parent.id;   // next to a control, inside a window
      moApply(function (x) { var a = MO.add(x, under, name, { kind: mode, base: j.base || undefined }); var f = MO.fill(a.appdef, a.id, j.attrs, { addMissing: extra }); return { appdef: f.appdef, id: a.id }; });
      toast('added "' + name + '" with ' + n + ' values');
    } else {
      if (!confirm(what + '\n\nPut its ' + n + ' values into "' + e.name + '"? (ticks and comparison types stay; Ctrl+Z undoes it)')) return;
      var res = null; if (moApply(function (x) { res = MO.fill(x, id, j.attrs, { addMissing: extra }); return res.appdef; })) toast(res.set.length + ' value(s) changed' + (res.skipped.length ? ', ' + res.skipped.length + ' not in this element' : ''));
    }
    var un = Object.keys(j.unconfirmed || {}); if (un.length) console.log('spy, unconfirmed values (not used):', j.unconfirmed);
  }, function (err) { alert('Spy failed:\n\n' + (err && err.message || err)); });
};
window.moLaunch = function () {
  if (undo.length && !confirm('The application is started from the last SAVED version of this object. Continue?')) return;
  fetch('/launch?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : ''), { method: 'POST' }).then(function (r) { return r.json(); }).then(function (r) { if (r.error) alert(r.error); else toast('started ' + r.started); });
};
window.moRemove = function () { var id = selEl, e = MO.parse(moText()).byId[id], u = moUsed(), hit = []; (function walk(x) { if (u[x.id]) hit = hit.concat(u[x.id]); x.children.forEach(walk); })(e);
  if (!confirm('Remove "' + e.name + '"' + (e.children.length ? ' and the ' + e.children.length + ' element(s) under it' : '') + '?' + (hit.length ? '\n\nStill used by: ' + hit.slice(0, 12).join(', ') + (hit.length > 12 ? ', ...' : '') + '\nThose stages will point at nothing.' : ''))) return;
  selEl = null; $('sheet').hidden = true; moApply(function (t) { return MO.remove(t, id); }); };
if (MO && M.type === 'object' && moText()) moTree();
if (SERVED && window.BW_SERVE.problem) toast(window.BW_SERVE.problem);
// ---------- Run (served only): bprun executes the flow, the trace lands on the drawing like a Radar incident ----------
if (SERVED && $('runb')) $('runb').hidden = false;
function startInputs(pageName) {   // the Start stage's inputs of a page: [{name, type}]
  var bp = E.bpOf(M), st = bp.stages.filter(function (s) { return s.type === 'Start' && s.page === pageName; })[0], out = [];
  if (!st) return out; var re = /<input ([^>]*)\/>/g, m; while ((m = re.exec(st.body))) out.push({ name: D.attr(m[1], 'name'), type: D.attr(m[1], 'type') });
  return out;
}
window.clearRun = function () { ov.pages = {}; $('runpanel').hidden = true; $('runb').classList.remove('on'); renderAll(); };
window.runFlow = function () {
  if (!SERVED) return toast('Run works from the served page (gumball.cmd)');
  if (undo.length && !confirm('Run the last SAVED version? You have unsaved changes.')) return;
  var o = {}, pg = pages()[cur];
  if (M.type === 'object') {
    var act = prompt('Action to run (a page of this object):', pg === 'Main Page' ? (pages()[1] || '') : pg); if (!act) return; o.action = act;
    var ins = startInputs(act), inputs = {};
    for (var i = 0; i < ins.length; i++) { var v = prompt('Input "' + ins[i].name + '" (' + ins[i].type + '):', ''); if (v === null) return; inputs[ins[i].name] = ins[i].type === 'flag' ? /^true$/i.test(v) : ins[i].type === 'number' ? Number(v || 0) : ins[i].type === 'collection' ? { columns: [], rows: [] } : v; }
    o.inputs = inputs;
  } else {
    var pins = startInputs('Main Page'), pin = {};
    for (var k = 0; k < pins.length; k++) { var pv = prompt('Process input "' + pins[k].name + '" (' + pins[k].type + '):', ''); if (pv === null) return; pin[pins[k].name] = pins[k].type === 'flag' ? /^true$/i.test(pv) : pins[k].type === 'number' ? Number(pv || 0) : pv; }
    if (pins.length) o.inputs = pin;
  }
  var panel = $('runpanel'); panel.hidden = false; $('run-status').textContent = 'running...'; $('run-sum').textContent = ''; $('run-log').textContent = ''; $('runb').classList.add('on');
  var url = '/run?base=' + encodeURIComponent(BW_BASE) + (window.BW_SERVE.rel ? '&rel=' + encodeURIComponent(window.BW_SERVE.rel) : '');
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }).then(function (r) { return r.json(); }).then(function (r) {
    $('runb').classList.remove('on');
    if (r.error) { $('run-status').textContent = 'could not run'; $('run-log').textContent = r.error; return; }
    $('run-status').textContent = (r.ok ? 'finished' : 'FAILED') + ' after ' + r.stages + ' stages' + (r.exception ? ': ' + r.exception.type + ' at "' + r.exception.stage + '": ' + r.exception.detail : '');
    var sum = [];
    if (r.host) sum.push(r.host.used ? 'code stages ran (' + r.host.code_objects + ' objects with code)' : 'code stages skipped: ' + (r.host.note || 'no stage host'));
    if (r.host && r.host.problems && r.host.problems.length) sum.push(r.host.problems.join('; '));
    if (r.skipped.length) sum.push(r.skipped.length + ' code stage calls skipped');
    var qn = Object.keys(r.queues || {}); if (qn.length) sum.push('queues: ' + qn.map(function (q) { var it = r.queues[q]; return q + ' ' + it.length + ' item' + (it.length === 1 ? '' : 's') + (it.length ? ' (' + it.filter(function (x) { return x.status === 'Completed'; }).length + ' completed, ' + it.filter(function (x) { return x.status === 'Exception'; }).length + ' exception)' : ''); }).join(', '));
    var on = Object.keys(r.outputs || {}); if (on.length) sum.push('outputs: ' + on.map(function (k) { return k + ' = ' + JSON.stringify(r.outputs[k]); }).join(', '));
    sum.push('run folder: ' + r.dir);
    $('run-sum').textContent = sum.join('  |  ');
    $('run-log').textContent = (r.log || []).join('\n') + (r.stderr ? '\n--- stderr ---\n' + r.stderr : '');
    if (r.incident) { var o2 = D.overlayFrom(r.incident); ov.pages = o2.pages; renderAll(); }
    toast(r.ok ? 'run finished: the path is on the drawing' : 'run failed at "' + (r.exception && r.exception.stage) + '"');
  }, function (e) { $('runb').classList.remove('on'); $('run-status').textContent = 'failed: ' + e; });
};
// arriving from an Action stage: open the page that implements the action
(function () { var m = /[#&]page=([^&]+)/.exec(location.hash || ''); if (!m) return; var want = decodeURIComponent(m[1]), pg = pages(); for (var i = 0; i < pg.length; i++) if (pg[i] === want || label(pg[i]) === want) { cur = i; return; } toast('no page "' + want + '" in this object'); })();

// ---------- go ----------
if (BW_DIFF) {
  var d = BW_DIFF, parts = [];
  if (d.added.length) parts.push('<b>added</b> ' + d.added.map(esc).join(', '));
  if (d.removed.length) parts.push('<b>removed</b> ' + d.removed.map(esc).join(', '));
  if (d.renamed.length) parts.push('<b>renamed</b> ' + d.renamed.map(function (r) { return esc(r[0]) + ' &rarr; ' + esc(r[1]); }).join(', '));
  if (d.changed.length) parts.push('<b>changed</b> ' + d.changed.map(esc).join(', '));
  if (d.moved.length) parts.push('<b>moved</b> ' + d.moved.length + ' stage' + (d.moved.length === 1 ? '' : 's'));
  $('diff').innerHTML = parts.length ? 'v' + (BW_VER - 1) + ' &rarr; v' + BW_VER + ': ' + parts.join(' &middot; ') : 'v' + BW_VER + ': no changes against v' + (BW_VER - 1);
}
if (window.BW_SERVE) { var br = document.querySelector('.tb .brand'); if (br) { br.style.cursor = 'pointer'; br.title = window.BW_SERVE.home ? 'back to the release' : 'back to the inbox and projects'; br.onclick = function () { location.href = window.BW_SERVE.home || '/'; }; } }
setMode('select'); renderAll(); $('gridb').classList.toggle('on', document.body.classList.contains('grid'));
window.bw = { snap: snap, multi: function (ids) { multi = ids; highlight(null); }, model: M, redraw: renderAll, place: startPlace, open: openSheet, pages: pages, current: function () { return cur; } };   // for scripts and tests
})();
