// bpdraw: Blue Prism pages from export XML, as SVG. Browser and node. No dependencies.
// Shared by Sheriff's sketch and by gumball (the editor). Generated from sheriff/ext/sketch.js, then kept here.
(function (root) {
'use strict';

function parseBp(xml) {
  const head = /<process [^>]*>/.exec(xml);
  const name = head ? attr(head[0], 'name') : '?';
  const type = head ? attr(head[0], 'type') : '?';
  const pages = {};
  const reSub = /<subsheet subsheetid="([^"]+)"[^>]*>\s*<name>([^<]*)<\/name>/g;
  let m;
  while ((m = reSub.exec(xml))) pages[m[1]] = unx(m[2]);
  const stages = [];
  const reStage = /<stage stageid="([^"]+)" name="([^"]*)" type="([^"]+)">([\s\S]*?)<\/stage>/g;
  while ((m = reStage.exec(xml))) {
    const b = m[4], sid = tag(b, 'subsheetid');
    stages.push({ id: m[1], name: unx(m[2]), type: m[3], ssid: sid, page: sid ? (pages[sid] || sid) : 'Main Page', body: b });
  }
  const elements = {};
  const reEl = /<element name="([^"]*)">\s*<id>([^<]+)<\/id>([\s\S]*?)(?=<element name=|<\/element>\s*<\/element>|<\/appdef>)/g;
  while ((m = reEl.exec(xml))) {
    const attrs = [];
    const reA = /<attribute name="([^"]+)" inuse="True">\s*<ProcessValue[^>]*value="([^"]*)"/g;
    let a; while ((a = reA.exec(m[3]))) attrs.push(a[1] + '=' + unx(a[2]));
    elements[m[2]] = { name: unx(m[1]), attrs, type: tag(m[3], 'type') };
  }
  return { name, type, pages, stages, elements };
}
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const unx = s => String(s || '').replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const tag = (s, n) => { const m = new RegExp('<' + n + '>([\\s\\S]*?)</' + n + '>').exec(s); return m ? m[1] : ''; };
const attr = (s, n) => { const m = new RegExp('\\b' + n + '="([^"]*)"').exec(s); return m ? unx(m[1]) : ''; };

// Studio-like palette per stage type (fill, stroke)
const LOOK = {
  Start: ['#ffffff', '#2e7d32'], End: ['#ffffff', '#c62828'], Decision: ['#fffdf5', '#c49000'],
  Exception: ['#fff5f5', '#c62828'], Data: ['#f7f7f7', '#8a8f99'], Collection: ['#f7f7f7', '#8a8f99'], Note: ['#fffbe6', '#b09a3a'], Recover: ['#f3f0fa', '#6a4fb3'], Resume: ['#f3f0fa', '#6a4fb3'],
};
const DEFAULT_LOOK = ['#ffffff', '#5c6370'];
// Blue Prism Studio's own look for the light theme: plain shapes (rounded Start/End/Data, diamond Decision, everything else a box)
const STUDIO_LOOK = { Start: ['#e6f4ea', '#2e7d32'], End: ['#fdecea', '#c62828'], Decision: ['#fff8d6', '#b8860b'], ChoiceStart: ['#fff8d6', '#b8860b'],
  Exception: ['#fde7e7', '#c62828'], Data: ['#eef4fb', '#4f7fc4'], Collection: ['#eef4fb', '#4f7fc4'], Note: ['#fff9c4', '#9e9238'], Block: ['#ffffff', '#33cccc'] };
const STUDIO_DEFAULT = ['#ffffff', '#3f6db3'];
const STUDIO_SHAPES = { Start: 'round', End: 'round', LoopStart: 'round', LoopEnd: 'round', Decision: 'diamond', ChoiceStart: 'diamond', Data: 'para', Collection: 'para' };
const SHAPES = { Start: 'pill', End: 'pill', LoopStart: 'pill', LoopEnd: 'pill', Decision: 'diamond', ChoiceStart: 'diamond', ChoiceEnd: 'rect',
  WaitStart: 'hex', WaitEnd: 'rect', Data: 'para', Collection: 'para', Calculation: 'chamfer', MultipleCalculation: 'chamfer', Note: 'note',
  Recover: 'catch', Resume: 'resume' };
const GLYPH = { Code: '</>', Navigate: '\u2794', Read: '\u25C9', Write: '\u270E', Exception: '\u2716', Alert: '!', LoopStart: '\u21BB', LoopEnd: '\u21BA',
  WaitStart: '\u25F7', WaitEnd: '\u23F1', Calculation: '\u0192', MultipleCalculation: '\u0192', Action: '\u2699', Skill: '\u2699' };
const DIAMOND = new Set(['Decision', 'ChoiceStart']);
const ROUND = new Set(['Start', 'End', 'LoopStart', 'LoopEnd', 'Data', 'Collection']);

function geom(body) {
  const d = /<display x="([^"]*)" y="([^"]*)"(?: w="([^"]*)")?(?: h="([^"]*)")?/.exec(body);
  if (d) return { x: +d[1] || 0, y: +d[2] || 0, w: +d[3] || 60, h: +d[4] || 30 };
  return { x: +tag(body, 'displayx') || 0, y: +tag(body, 'displayy') || 0, w: +tag(body, 'displaywidth') || 60, h: +tag(body, 'displayheight') || 30 };
}

// one-paragraph description of a stage for the tooltip
function describe(st, bp, idName) {
  const b = st.body, L = [st.type + '  ' + st.name];
  const ins = [...b.matchAll(/<input [^>]*name="([^"]*)"[^>]*expr="([^"]*)"/g)].map(m => unx(m[1]) + ' = ' + unx(m[2]));
  const outs = [...b.matchAll(/<output [^>]*name="([^"]*)"[^>]*stage="([^"]*)"/g)].map(m => unx(m[1]) + ' -> ' + unx(m[2]));
  const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b); if (r) L.push('calls ' + unx(r[1]) + ' :: ' + unx(r[2]));
  if (st.type === 'SubSheet') L.push('calls page ' + (bp.pages[tag(b, 'processid')] || '?'));
  const dec = /<decision expression="([^"]*)"/.exec(b); if (dec) L.push('if ' + unx(dec[1]));
  for (const c of b.matchAll(/<calculation expression="([^"]*)" stage="([^"]*)"/g)) L.push(unx(c[2]) + ' = ' + unx(c[1]));
  const ex = /<exception [^>]*type="([^"]*)"[^>]*detail="([^"]*)"/.exec(b); if (ex) L.push('throw ' + unx(ex[1]) + ': ' + unx(ex[2]));
  if (/usecurrent="(yes|true)"/i.test(b)) L.push('rethrow current exception');
  if (st.type === 'Data' || st.type === 'Collection') L.push('type ' + (tag(b, 'datatype') || attr(b, 'datatype') || '?') + ' initial ' + JSON.stringify(unx(tag(b, 'initialvalue'))) + (/<alwaysinit/.test(b) ? ' (always init)' : ''));
  for (const s of b.matchAll(/<step([^>]*)>\s*<element id="([^"]+)"[^>]*\/>\s*(?:<action><id>([^<]+)<\/id><\/action>)?/g)) {
    const el = bp.elements[s[2]];
    L.push((s[3] ? s[3] + ' ' : '') + 'element "' + (el ? el.name : s[2]) + '"' + (attr(s[1], 'expr') ? ' expr=' + attr(s[1], 'expr') : '') + (attr(s[1], 'stage') ? ' -> ' + attr(s[1], 'stage') : ''));
  }
  for (const ch of b.matchAll(/<choice [^>]*>\s*<name>([^<]*)<\/name>[\s\S]*?<element id="([^"]+)"[\s\S]*?<condition><id>([^<]+)<\/id><\/condition>/g)) {
    const el = bp.elements[ch[2]]; L.push('choice "' + unx(ch[1]) + '": wait ' + ch[3] + ' on "' + (el ? el.name : ch[2]) + '"');
  }
  if (ins.length) L.push('in: ' + ins.join('; '));
  if (outs.length) L.push('out: ' + outs.join('; '));
  const code = tag(b, 'code'); if (code) { const lines = unx(code.replace(/<!\[CDATA\[|\]\]>/g, '')).trim().split('\n'); L.push('code: ' + lines.slice(0, 12).join('\n      ') + (lines.length > 12 ? '\n      ... (' + lines.length + ' lines)' : '')); }
  const nar = tag(b, 'narrative'); if (nar) L.push(unx(nar));
  const nt = /<note>([\s\S]*?)<\/note>/.exec(b) || null; if (nt) L.push(unx(nt[1]));
  return L.join('\n');
}


// ---------- the properties sheet of a stage (what Studio shows when you open it) ----------
function stageInfo(st, bp, idName) {
  const b = st.body, info = { id: st.id, name: st.name, type: st.type, page: st.page, desc: unx(tag(b, 'narrative')), fields: [], tables: [], code: '' };
  const F = (k, v) => { if (v !== undefined && v !== null && String(v) !== '') info.fields.push([k, String(v)]); };
  const T = (title, cols, rows) => { if (rows.length) info.tables.push({ title, cols, rows }); };
  const ins = [...b.matchAll(/<input ([^>]*)\/>/g)].map(m => [attr(m[1], 'friendlyname') || attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'expr')]);
  const outs = [...b.matchAll(/<output ([^>]*)\/>/g)].map(m => [attr(m[1], 'friendlyname') || attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]);
  const next = tag(b, 'onsuccess').trim();
  switch (st.type) {
    case 'Action': { const r = /<resource object="([^"]*)" action="([^"]*)"/.exec(b); if (r) { F('Business Object', unx(r[1])); F('Action', unx(r[2])); } break; }
    case 'SubSheet': F('Page', bp.pages[tag(b, 'processid')] || tag(b, 'processid')); break;
    case 'Decision': { const d = /<decision expression="([^"]*)"/.exec(b); F('Expression', d ? unx(d[1]) : ''); F('Yes', idName[tag(b, 'ontrue').trim()]); F('No', idName[tag(b, 'onfalse').trim()]); break; }
    case 'Calculation': case 'MultipleCalculation': T('Calculations', ['Expression', 'Store In'], [...b.matchAll(/<calculation expression="([^"]*)" stage="([^"]*)"/g)].map(m => [unx(m[1]), unx(m[2])])); break;
    case 'Data': F('Data Type', tag(b, 'datatype') || attr(b, 'datatype')); F('Initial Value', unx(tag(b, 'initialvalue'))); F('Exposure', tag(b, 'exposure')); F('Private', /<private\s*\/>/.test(b) ? 'yes' : ''); F('Always init', /<alwaysinit\s*\/>/.test(b) ? 'yes' : ''); break;
    case 'Collection': F('Initial rows', tag(b, 'initialvalue') ? 'yes' : ''); F('Private', /<private\s*\/>/.test(b) ? 'yes' : ''); T('Fields', ['Name', 'Type', 'Description'], [...b.matchAll(/<field ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'narrative')])); break;
    case 'Exception': { const e = /<exception ([^>]*)\/>/.exec(b); if (e) { F('Type', attr(e[1], 'type')); F('Detail', attr(e[1], 'detail')); F('Use current exception', /usecurrent="(yes|true)"/i.test(e[1]) ? 'yes' : ''); F('Preserve type', /preserve="(yes|true)"/i.test(e[1]) ? 'yes' : ''); } break; }
    case 'WaitStart': case 'ChoiceStart': {
      F('Timeout', unx(tag(b, 'timeout')));
      const rows = [];
      for (const ch of b.matchAll(/<choice [^>]*>([\s\S]*?)<\/choice>/g)) {
        const c = ch[1], el = bp.elements[(/<element id="([^"]+)"/.exec(c) || [])[1]];
        rows.push([unx(tag(c, 'name')), el ? el.name : (tag(c, 'expression') ? unx(tag(c, 'expression')) : ''), tag(c, 'condition').replace(/<\/?id>/g, ''), tag(c, 'comparetype'), unx(attr(c, 'expr') || tag(c, 'expr'))]);
      }
      T('Conditions', ['Name', 'Element / Expression', 'Condition', 'Compare', 'Value'], rows); break;
    }
    case 'LoopStart': F('Collection', unx(tag(b, 'loopdata'))); break;
    case 'Note': F('Note', unx(tag(b, 'note'))); break;
    case 'Alert': F('Alert', unx(tag(b, 'alert'))); break;
  }
  if (/^(Navigate|Read|Write)$/.test(st.type)) {
    const rows = [];
    for (const s of b.matchAll(/<step([^>]*)>([\s\S]*?)<\/step>/g)) {
      const eid = (/<element id="([^"]+)"/.exec(s[2]) || [])[1], el = bp.elements[eid];
      const act = (/<action>\s*<id>([^<]+)<\/id>/.exec(s[2]) || [])[1] || '';
      const args = [...s[2].matchAll(/<arguments>[\s\S]*?<\/arguments>/g)].map(a => [...a[0].matchAll(/<argument name="([^"]*)">\s*<ProcessValue[^>]*value="([^"]*)"/g)].map(m => m[1] + '=' + unx(m[2])).join(', ')).join(' ');
      rows.push([el ? el.name : (eid || '?'), act, attr(s[1], 'expr'), attr(s[1], 'stage'), args, el ? (el.attrs.length ? el.attrs.join(', ') : 'NOT SPIED (no attributes)') : '']);
    }
    T('Steps', ['Element', 'Action', 'Value', 'Store In', 'Arguments', 'Element attributes (spy)'], rows);
  }
  if (st.type === 'Start' || st.type === 'End') {
    if (st.type === 'Start') T('Page inputs', ['Name', 'Type', 'Store In'], [...b.matchAll(/<input ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]));
    else T('Page outputs', ['Name', 'Type', 'From'], [...b.matchAll(/<output ([^>]*)\/>/g)].map(m => [attr(m[1], 'name'), attr(m[1], 'type'), attr(m[1], 'stage')]));
  } else {
    T('Inputs', ['Name', 'Data Type', 'Value'], ins);
    T('Outputs', ['Name', 'Data Type', 'Store In'], outs);
  }
  const code = tag(b, 'code'); if (code) info.code = unx(code.replace(/<!\[CDATA\[|\]\]>/g, '')).trim();
  info.logging = /<loginhibit\s*\/>/.test(b) ? "Don't log this stage" : /<loginhibit onsuccess="true"/.test(b) ? 'Log only on error' : 'Logged';
  if (next && st.type !== 'Decision') info.next = idName[next] || '';
  return info;
}

// overlay for one page: { fail: Set(stageName), path: Map(stageName -> [n,...]), values: Map(dataItem -> value), log: Map(stageName -> [seq,...]), chain: bool }
function pageOverlay(ov, procName, pageName) {
  const k = (procName + '|' + pageName).toLowerCase();
  return ov && ov.pages[k] ? ov.pages[k] : null;
}

// ---- link routing: a straight link that would cross another stage gets an elbow route around it; every other link is untouched ----
function segHitsRect(x1, y1, x2, y2, r) {   // Liang-Barsky: does the segment touch the rectangle?
  let t0 = 0, t1 = 1; const dx = x2 - x1, dy = y2 - y1;
  for (const [p, q] of [[-dx, x1 - r.l], [dx, r.r - x1], [-dy, y1 - r.t], [dy, r.b - y1]]) {
    if (p === 0) { if (q < 0) return false; continue; }
    const t = q / p; if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
  }
  return t0 <= t1;
}
function routeLink(a, b, x1, y1, x2, y2, obstacles, dot, taken) {
  taken = taken || [];
  const rect = (o, m) => ({ l: o.x - o.w / 2 - m, r: o.x + o.w / 2 + m, t: o.y - o.h / 2 - m, b: o.y + o.h / 2 + m, o });
  const others = obstacles.filter(o => o !== a && o !== b).map(o => rect(o, 4));
  const hits = (pts) => {
    for (let i = 1; i < pts.length; i++) {
      const [ax, ay] = pts[i - 1], [bx, by] = pts[i];
      for (const r of others) if (segHitsRect(ax, ay, bx, by, r)) return true;
      // middle segments must not run through the two ends either
      if (i > 1 && i < pts.length - 1) { if (segHitsRect(ax, ay, bx, by, rect(a, 2)) || segHitsRect(ax, ay, bx, by, rect(b, 2))) return true; }
      if (pts.length > 2 && i === pts.length - 1 && segHitsRect(ax, ay, bx, by, rect(a, 2)) && !dot(a.st.type)) return true;
      if (pts.length > 2 && i === 1 && segHitsRect(ax, ay, bx, by, rect(b, 2)) && !dot(b.st.type)) return true;
    }
    return false;
  };
  if (!hits([[x1, y1], [x2, y2]])) return null;                         // the straight line is clean: keep it
  const sx = (o, tx) => dot(o.st.type) ? o.x : o.x + Math.sign(tx - o.x || 1) * o.w / 2;
  const sy = (o, ty) => dot(o.st.type) ? o.y : o.y + Math.sign(ty - o.y || 1) * o.h / 2;
  const cands = [];
  cands.push([[sx(a, b.x), a.y], [b.x, a.y], [b.x, sy(b, a.y)]]);        // L: across, then down/up into b
  cands.push([[a.x, sy(a, b.y)], [a.x, b.y], [sx(b, a.x), b.y]]);        // L: down/up, then across into b
  const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, zh = x => [[sx(a, x), a.y], [x, a.y], [x, b.y], [sx(b, x), b.y]], zv = y => [[a.x, sy(a, y)], [a.x, y], [b.x, y], [b.x, sy(b, y)]];
  cands.push(zh(mx), zv(my));
  for (let d = 15; d <= 180; d += 15) {
    const right = Math.max(a.x + a.w / 2, b.x + b.w / 2), left = Math.min(a.x - a.w / 2, b.x - b.w / 2);
    const below = Math.max(a.y + a.h / 2, b.y + b.h / 2), above = Math.min(a.y - a.h / 2, b.y - b.h / 2);
    cands.push(zh(mx + d), zh(mx - d), zv(my + d), zv(my - d), zh(right + d), zh(left - d), zv(below + d), zv(above - d));
  }
  const len = pts => pts.reduce((t, p, i) => i ? t + Math.abs(p[0] - pts[i - 1][0]) + Math.abs(p[1] - pts[i - 1][1]) : 0, 0);
  // a route must not run along a stretch an earlier route already uses (same line, overlapping range)
  const along = pts => { for (let i = 1; i < pts.length; i++) { const [ax, ay] = pts[i - 1], [bx, by] = pts[i];
    for (const t of taken) {
      if (Math.abs(ay - by) < 1 && Math.abs(t.y1 - t.y2) < 1 && Math.abs(ay - t.y1) < 4 && Math.min(Math.max(ax, bx), Math.max(t.x1, t.x2)) - Math.max(Math.min(ax, bx), Math.min(t.x1, t.x2)) > 6) return true;
      if (Math.abs(ax - bx) < 1 && Math.abs(t.x1 - t.x2) < 1 && Math.abs(ax - t.x1) < 4 && Math.min(Math.max(ay, by), Math.max(t.y1, t.y2)) - Math.max(Math.min(ay, by), Math.min(t.y1, t.y2)) > 6) return true;
    } } return false; };
  const clean = cands.filter(p => p.every(q => isFinite(q[0]) && isFinite(q[1])) && !hits(p));
  const free = clean.filter(p => !along(p));
  const ok = (free.length ? free : clean).sort((p, q) => len(p) + p.length * 20 - len(q) - q.length * 20);
  if (!ok.length) return null;                                           // nothing clean: stay straight, as before
  for (let i = 1; i < ok[0].length; i++) taken.push({ x1: ok[0][i - 1][0], y1: ok[0][i - 1][1], x2: ok[0][i][0], y2: ok[0][i][1] });
  return ok[0];
}

function renderPage(bp, pageName, ov) {
  const stages = bp.stages.filter(s => s.page === pageName);
  if (!stages.length) return null;
  const infos = [];
  const idName = {}; for (const s of bp.stages) idName[s.id] = s.name;
  const boxes = {}, links = [], blocks = [], groups = {};
  for (const st of stages) {
    const g = geom(st.body);
    if (st.type === 'Block') { blocks.push({ id: st.id, name: st.name, ...g }); continue; }
    if (st.type === 'SubSheetInfo' || st.type === 'ProcessInfo') { infos.push({ st, ...g }); continue; }
    if (st.type === 'Anchor') { g.w = g.h = 8; }
    boxes[st.id] = { st, ...g };
    if (/^(ChoiceStart|ChoiceEnd|WaitStart|WaitEnd|LoopStart|LoopEnd)$/.test(st.type)) {
      const gid = (tag(st.body, 'groupid') || '').trim();
      const grp = groups[gid] = groups[gid] || { choices: [] };
      grp[/End$/.test(st.type) ? 'end' : 'start'] = st.id;
      if (/Start$/.test(st.type) && st.type !== 'LoopStart') {
        for (const ch of st.body.matchAll(/<choice [^>]*>\s*<name>([^<]*)<\/name>[\s\S]*?<distance>([^<]*)<\/distance>[\s\S]*?<ontrue>([^<]*)<\/ontrue>/g)) grp.choices.push({ name: unx(ch[1]), dist: +ch[2] || 0, target: ch[3].trim() });
        continue;
      }
    }
    for (const t of ['onsuccess', 'ontrue', 'onfalse']) { const v = tag(st.body, t).trim(); if (v) links.push({ from: st.id, to: v, kind: t }); }
  }
  for (const b of infos) {   // the lines each info box shows, and the height they need
    const st = b.st;
    b.lines = st.type === 'ProcessInfo' ? ['language: ' + (tag(st.body, 'language') || '?'), (st.body.match(/<reference>/g) || []).length + ' references, ' + (st.body.match(/<import>/g) || []).length + ' imports', (tag(st.body, 'code').replace(/<!\[CDATA\[|\]\]>/g, '').trim() ? 'shared code: yes' : 'shared code: none')]
                                        : wrap(unx(tag(st.body, 'narrative')), Math.max(8, Math.floor((b.w - 16) / 4.3)));
    const need = 20 + 14 + Math.max(0, b.lines.length - 1) * 11 + 8;
    if (need > b.h) { b.y += (need - b.h) / 2; b.h = need; b.grown = true; }   // grows downward from its own top edge
  }
  const all = Object.values(boxes);
  const allB = all.concat(infos);
  const xs = allB.map(b => b.x - b.w / 2).concat(blocks.map(b => b.x)), xe = allB.map(b => b.x + b.w / 2).concat(blocks.map(b => b.x + b.w));
  const ys = allB.map(b => b.y - b.h / 2).concat(blocks.map(b => b.y)), ye = allB.map(b => b.y + b.h / 2).concat(blocks.map(b => b.y + b.h));
  const pad = 45, g15 = v => Math.floor(v / 15) * 15;   // bounds on the 15px grid so a grid background lines up with the stages
  // a Studio-like canvas: at least this much room in every direction, so moving a stage does not visibly grow a box around the drawing
  const floor = (ov && ov.canvas) || { x0: -480, y0: -330, x1: 1200, y1: 960 };
  const minx = g15(Math.min(Math.min(...xs) - pad, floor.x0)), miny = g15(Math.min(Math.min(...ys) - pad, floor.y0));
  const W = Math.ceil((Math.max(Math.max(...xe) + pad, floor.x1) - minx) / 15) * 15, H = Math.ceil((Math.max(Math.max(...ye) + pad, floor.y1) - miny) / 15) * 15;
  const gid = 'grid-' + String(pageName).replace(/[^A-Za-z0-9]/g, '_') + '-' + W;
  const o = [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minx} ${miny} ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI, Arial, sans-serif" font-size="9">`,
    '<defs><marker id="arr" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#555"/></marker>',
    '<marker id="arrR" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#c62828"/></marker></defs>',
    `<pattern id="${gid}" x="0" y="0" width="15" height="15" patternUnits="userSpaceOnUse"><circle class="gdot" cx="0.5" cy="0.5" r="0.9" fill="#c9ced6"/></pattern>`,
    `<rect class="bg" x="${minx}" y="${miny}" width="${W}" height="${H}" fill="#fafafa"/><rect class="grid" x="${minx}" y="${miny}" width="${W}" height="${H}" fill="url(#${gid})"/>`];
  for (const b of blocks) o.push(`<g class="blk" data-sid="${esc(b.id)}"><rect class="blkr" x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" fill="#7fb2e5" fill-opacity="0.08" stroke="#7fb2e5" stroke-dasharray="4,3"/><text class="blkt" x="${b.x + 4}" y="${b.y + 11}" fill="#3b6ea5" font-weight="bold">${esc(b.name)}</text><rect class="rsz" data-sid="${esc(b.id)}" x="${b.x + b.w - 7}" y="${b.y + b.h - 7}" width="7" height="7"/></g>`);
  // the page's info box (SubSheetInfo) and the object's Code Options (ProcessInfo), as Studio draws them: a titled rectangle with the description
  for (const b of infos) {
    const st = b.st, L = b.x - b.w / 2, T = b.y - b.h / 2, isCode = st.type === 'ProcessInfo';
    const text = b.lines;
    const hb = 20, r = 4;
    o.push(`<g class="st info" data-sid="${esc(st.id)}" style="cursor:pointer"><rect class="infor" x="${L}" y="${T}" width="${b.w}" height="${b.h}" rx="${r}" fill="#f7f9fd" stroke="#8fa6d6" stroke-width="0.8"><title>${esc(st.name)}</title></rect>`);
    o.push(`<path class="infoh" d="M${L},${T + hb} V${T + r} a${r},${r} 0 0 1 ${r},-${r} H${L + b.w - r} a${r},${r} 0 0 1 ${r},${r} V${T + hb} Z" fill="#3f6db3"/>`);
    o.push(`<text class="infot" x="${L + 8}" y="${T + 13.5}" font-size="9" font-weight="bold" fill="#ffffff">${esc(isCode ? 'Code Options' : st.name)}</text>`);
    text.forEach((ln, i) => o.push(`<text class="infod" x="${L + 8}" y="${T + hb + 14 + i * 11}" font-size="8" fill="#3a4250">${esc(ln)}</text>`));
    o.push('</g>');
  }
  // choice / wait / loop group lines
  for (const grp of Object.values(groups)) {
    if (!grp.start || !grp.end || !boxes[grp.start] || !boxes[grp.end]) continue;
    const s = boxes[grp.start], e = boxes[grp.end];
    const isLoop = boxes[grp.start].st.type === 'LoopStart';   // a loop's pair line is the only loop-back drawn: faint, straight, start to end
    o.push(`<line class="grp${isLoop ? ' loop' : ''}" x1="${s.x}" y1="${s.y}" x2="${e.x}" y2="${e.y}" stroke="${isLoop ? '#6a1b9a' : '#777'}" stroke-dasharray="3,2"${isLoop ? ' stroke-opacity="0.35"' : ''}/>`);
    const len = Math.hypot(e.x - s.x, e.y - s.y) || 1;
    for (const c of grp.choices) {
      const px = s.x + (e.x - s.x) * c.dist / len, py = s.y + (e.y - s.y) * c.dist / len, id = 'pt:' + grp.start + ':' + c.dist;
      boxes[id] = { st: { id, name: c.name, type: 'ChoicePoint', body: '' }, x: px, y: py, w: 0, h: 0 };
      links.push({ from: id, to: c.target, kind: 'ontrue', label: c.name });
    }
  }
  const pov = ov ? pageOverlay(ov, bp.name, pageName) : null;
  const pathEdges = new Set();
  if (pov && pov.pathOrder.length > 1) for (let i = 1; i < pov.pathOrder.length; i++) pathEdges.add(pov.pathOrder[i - 1] + '>' + pov.pathOrder[i]);
  const taken = [];
  const obstacles = Object.values(boxes).filter(x => x.st.type !== 'ChoicePoint' && x.st.type !== 'Anchor').concat(infos);
  for (const l of links) {
    const a = boxes[l.from], b = boxes[l.to]; if (!a || !b) continue;
    const colour = { ontrue: '#2e7d32', onfalse: '#c62828', loop: '#6a1b9a' }[l.kind] || '#555';
    const red = pathEdges.has(a.st.name + '>' + b.st.name);
    const stroke = red ? '#c62828' : colour, sw = red ? 2.5 : 1, mk = red ? 'arrR' : 'arr';
    const lc = 'lnk ' + (red ? 'red' : { ontrue: 'yes', onfalse: 'no', loop: 'loop' }[l.kind] || 'next');
    const dot = t => t === 'Anchor' || t === 'ChoicePoint';
    const dx = b.x - a.x, dy = b.y - a.y, horizontal = Math.abs(dx) > Math.abs(dy);
    let x1 = a.x, y1 = a.y, x2 = b.x, y2 = b.y;
    if (!dot(a.st.type)) { if (horizontal) x1 = a.x + Math.sign(dx) * a.w / 2; else y1 = a.y + Math.sign(dy || 1) * a.h / 2; }
    if (!dot(b.st.type)) { if (horizontal) x2 = b.x - Math.sign(dx) * b.w / 2; else y2 = b.y - Math.sign(dy || 1) * b.h / 2; }
    {
      const route = routeLink(a, b, x1, y1, x2, y2, obstacles, dot, taken);
      if (route) { o.push(`<polyline class="${lc} routed" points="${route.map(p => p[0] + ',' + p[1]).join(' ')}" fill="none" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round" marker-end="url(#${mk})"/>`); x1 = route[0][0]; y1 = route[0][1]; x2 = route[1][0]; y2 = route[1][1]; }
      else o.push(`<line class="${lc}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${sw}" marker-end="url(#${mk})"/>`);
    }
    const lab = l.label || { ontrue: 'Yes', onfalse: 'No' }[l.kind];
    if (lab && a.st.type !== 'ChoicePoint') o.push(`<text class="lab ${l.kind === 'ontrue' ? 'yes' : l.kind === 'onfalse' ? 'no' : 'next'}" x="${(x1 + x2) / 2 + 4}" y="${(y1 + y2) / 2 - 2}" fill="${colour}" font-size="8">${esc(lab)}</text>`);
  }
  for (const b of all.concat(Object.values(boxes).filter(x => x.st.type === 'ChoicePoint'))) {
    const st = b.st, t = st.type;
    if (t === 'ChoicePoint') { o.push(`<circle class="cpt" cx="${b.x}" cy="${b.y}" r="4" fill="#fff59d" stroke="#666"/><text class="cptl" x="${b.x}" y="${b.y - 7}" text-anchor="middle" fill="#555" font-size="8">${esc(st.name)}</text>`); continue; }
    if (t === 'Anchor') { o.push(`<g class="st" data-sid="${esc(st.id)}" style="cursor:pointer"><circle class="anchor" cx="${b.x}" cy="${b.y}" r="3.5" fill="#555"><title>${esc(st.name)}</title></circle></g>`); continue; }
    const studio = !!(ov && ov.studio);
    const [fill, stroke] = studio ? (STUDIO_LOOK[t] || STUDIO_DEFAULT) : (LOOK[t] || DEFAULT_LOOK);
    const fail = pov && pov.fail.has(st.name), onPath = pov && pov.path.has(st.name), logSeq = pov && pov.log.get(st.name);
    const changed = ov && ov.changed && ov.changed.has(st.id);
    const f = fail ? '#ff5252' : fill, s = fail ? '#b71c1c' : onPath ? '#c62828' : changed ? '#ef6c00' : stroke, sw = fail ? 3 : (onPath || changed) ? 2 : (t === 'Exception' ? 1.8 : 1);
    const title = `<title>${esc(describe(st, bp, idName))}</title>`;
    o.push(`<g class="st" data-sid="${esc(st.id)}" style="cursor:pointer">`);
    const cls = `shape t-${t}${fail ? ' fail' : ''}${onPath ? ' path' : ''}${changed ? ' changed' : ''}`;
    const L = b.x - b.w / 2, T = b.y - b.h / 2, R = b.x + b.w / 2, B = b.y + b.h / 2, A = `fill="${f}" stroke="${s}" stroke-width="${sw}"`;
    const shape = studio ? (STUDIO_SHAPES[t] || 'rect') : (SHAPES[t] || 'rect');
    const skew = shape === 'para' ? Math.round(Math.min(10, b.h * 0.35, b.w * 0.2)) : 0;
    // 2. what sits beside the name (glyph, collection grid, recover/resume chevron, action bars) only stays if the name still has room:
    //    a stage someone made small keeps its name readable and loses the decoration, never the other way round
    const CW = 5.2, glyph0 = studio ? null : GLYPH[t];
    let padL = shape === 'catch' ? 10 : skew ? skew * 0.6 : (t === 'Action' || t === 'Skill') ? 6 : 2, padR = shape === 'resume' ? 10 : skew ? skew * 0.6 : (t === 'Action' || t === 'Skill') ? 6 : 2;
    const decoL = glyph0 ? ((t === 'Action' || t === 'Skill') ? 12 : 13) : t === 'Collection' ? 15 : shape === 'catch' ? 8 : 0, decoR = shape === 'resume' ? 8 : 0;
    const roomFor = n => b.w - padL - padR - decoL - decoR >= Math.min(st.name.length, n) * CW;
    const deco = (decoL || decoR) ? (b.h >= 16 && roomFor(st.name.length <= 12 ? st.name.length : 9)) : false;
    if (deco) { padL += decoL; padR += decoR; }
    if (shape === 'diamond') o.push(`<polygon class="${cls}" points="${b.x},${T} ${R},${b.y} ${b.x},${B} ${L},${b.y}" ${A}>${title}</polygon>`);
    else if (shape === 'pill') o.push(`<rect class="${cls}" x="${L}" y="${T}" width="${b.w}" height="${b.h}" rx="${b.h / 2}" ${A}>${title}</rect>`);
    else if (shape === 'round') o.push(`<rect class="${cls}" x="${L}" y="${T}" width="${b.w}" height="${b.h}" rx="7" ${A}>${title}</rect>`);
    else if (shape === 'para') o.push(`<polygon class="${cls}" points="${L + skew},${T} ${R},${T} ${R - skew},${B} ${L},${B}" ${A}>${title}</polygon>`);
    else if (shape === 'chamfer') o.push(`<polygon class="${cls}" points="${L + 6},${T} ${R - 6},${T} ${R},${T + 6} ${R},${B - 6} ${R - 6},${B} ${L + 6},${B} ${L},${B - 6} ${L},${T + 6}" ${A}>${title}</polygon>`);
    else if (shape === 'hex') o.push(`<polygon class="${cls}" points="${L + 7},${T} ${R - 7},${T} ${R},${b.y} ${R - 7},${B} ${L + 7},${B} ${L},${b.y}" ${A}>${title}</polygon>`);
    else if (shape === 'note') o.push(`<polygon class="${cls}" points="${L},${T} ${R - 8},${T} ${R},${T + 8} ${R},${B} ${L},${B}" ${A}>${title}</polygon><polyline class="deco" points="${R - 8},${T} ${R - 8},${T + 8} ${R},${T + 8}" fill="none" stroke="${s}" stroke-width="0.8"/>`);
    else if (shape === 'catch') o.push(`<polygon class="${cls}" points="${L + 10},${T} ${R},${T} ${R},${B} ${L + 10},${B} ${L},${b.y}" ${A}>${title}</polygon>` + (deco ? `<polyline class="deco" points="${L + 16},${T + 4} ${L + 10},${b.y} ${L + 16},${B - 4}" fill="none" stroke="${s}" stroke-width="1.2"/>` : ''));
    else if (shape === 'resume') o.push(`<polygon class="${cls}" points="${L},${T} ${R - 10},${T} ${R},${b.y} ${R - 10},${B} ${L},${B}" ${A}>${title}</polygon>` + (deco ? `<polyline class="deco" points="${R - 16},${T + 4} ${R - 10},${b.y} ${R - 16},${B - 4}" fill="none" stroke="${s}" stroke-width="1.2"/>` : ''));
    else o.push(`<rect class="${cls}" x="${L}" y="${T}" width="${b.w}" height="${b.h}" rx="2" ${A}>${title}</rect>`);
    // the second line that tells the kinds apart, as Studio does: side bars = calls an object, top bar = calls a page, stacked = many calculations
    if (t === 'Action' || t === 'Skill') o.push(`<line class="deco" x1="${L + 5}" y1="${T}" x2="${L + 5}" y2="${B}" stroke="${s}" stroke-width="0.9"/><line class="deco" x1="${R - 5}" y1="${T}" x2="${R - 5}" y2="${B}" stroke="${s}" stroke-width="0.9"/>`);
    if (t === 'SubSheet') o.push(`<line class="deco" x1="${L}" y1="${T + 5}" x2="${R}" y2="${T + 5}" stroke="${s}" stroke-width="0.9"/>`);
    if (t === 'MultipleCalculation') o.push(`<polyline class="deco" points="${L + 9},${T - 3} ${R - 3},${T - 3} ${R + 3},${T + 3} ${R + 3},${B - 9}" fill="none" stroke="${s}" stroke-width="0.8"/>`);
    if (t === 'Collection' && deco) { const gx = L + skew * 0.6 + 4, gy = b.y - 6; o.push(`<path class="deco" d="M${gx},${gy + 2} h10 M${gx},${gy + 6} h10 M${gx},${gy + 10} h10 M${gx + 3},${gy} v12 M${gx + 7},${gy} v12" fill="none" stroke="${s}" stroke-width="0.8"/>`); }
    const glyph = deco ? glyph0 : null;
    if (glyph) o.push(`<text class="glyph" x="${L + (t === 'Action' || t === 'Skill' ? 11 : 7)}" y="${b.y + 3.5}" font-size="9" fill="${s}">${glyph}</text>`);
    const max = Math.max(3, Math.floor((b.w - padL - padR) / CW));
    const label = st.name.length > max ? st.name.slice(0, Math.max(1, max - 2)) + '..' : st.name;
    const lx = (L + padL + R - padR) / 2;
    o.push(`<text class="lbl${fail ? ' fail' : ''}" x="${lx}" y="${b.y + 3}" text-anchor="middle" font-size="9"${fail ? ' fill="#fff" font-weight="bold"' : ''}>${esc(label)}</text>`);
    if (t === 'Note' || t === 'Block') o.push(`<rect class="rsz" data-sid="${esc(st.id)}" x="${R - 7}" y="${B - 7}" width="7" height="7"/>`);
    if (pov && (t === 'Data' || t === 'Collection') && pov.values.has(st.name)) {
      const v = String(pov.values.get(st.name)); const vv = v.length > 28 ? v.slice(0, 26) + '..' : v;
      o.push(`<text class="val" x="${b.x}" y="${b.y + b.h / 2 + 10}" text-anchor="middle" fill="#1565c0" font-size="8"><title>${esc(st.name + ' = ' + v)}</title>= ${esc(vv)}</text>`);
    }
    if (onPath) for (const [i, n] of [...pov.path.get(st.name)].entries()) o.push(`<circle cx="${b.x + b.w / 2 - 2 + i * 14}" cy="${b.y - b.h / 2 - 2}" r="7" fill="#c62828"/><text x="${b.x + b.w / 2 - 2 + i * 14}" y="${b.y - b.h / 2 + 1}" text-anchor="middle" fill="#fff" font-size="8" font-weight="bold">${n}</text>`);
    if (logSeq && logSeq.length) o.push(`<text class="seq" x="${b.x - b.w / 2 - 3}" y="${b.y + 3}" text-anchor="end" fill="#777" font-size="7">#${logSeq.join(',#')}</text>`);
    o.push('</g>');
  }
  o.push('</svg>');
  return o.join('\n');
}

// Build the overlay index from a Radar incident.json: pages[proc|page] = {fail, path, pathOrder, values, log, chain}
function wrap(s, n) { const out = []; for (const para of String(s || '').split(/\r?\n/)) { let line = ''; for (let w of para.split(/\s+/)) {
      while (w.length > n) { if (line) { out.push(line); line = ''; } out.push(w.slice(0, n)); w = w.slice(n); }   // a link or path longer than the box breaks, it never runs outside
      if ((line + ' ' + w).trim().length > n && line) { out.push(line); line = w; } else line = (line + ' ' + w).trim(); } out.push(line); } return out.filter((l, i, a) => l || i < a.length - 1); }
function overlayFrom(inc) {
  if (!inc) return null;
  const pages = {}, norm = s => String(s || '').trim();
  const get = (p, g) => { const k = (norm(p) + '|' + norm(g)).toLowerCase(); return pages[k] = pages[k] || { fail: new Set(), path: new Map(), pathOrder: [], values: new Map(), log: new Map(), chain: false }; };
  const ex = inc.exception || {};
  if (inc.process && ex.stage) get(inc.process, inc.page || 'Main Page').fail.add(ex.stage);
  // throws name the object class and the stage (hook strips the generated Run_ prefix); the page is resolved in sketch()
  const throwsAt = [];
  for (const t of inc.throws || []) if (t.object && t.stage) throwsAt.push({ object: String(t.object).replace(/_/g, ' ').toLowerCase(), stage: t.stage });
  let n = 0;
  for (const e of inc.exception_path || []) if (e.process && e.page && e.stage) { n++; const p = get(e.process, e.page); if (!p.path.has(e.stage)) p.path.set(e.stage, []); p.path.get(e.stage).push(n); p.pathOrder.push(e.stage); }
  for (const c of inc.data_chain || []) {
    if (!c.process || !c.page) continue;
    const p = get(c.process, c.page); p.chain = true;
    if (c.stage) p.path.has(c.stage) || p.pathOrder.length || p.path.set(c.stage, []);
    const items = c.items || c.data_items || {};
    if (Array.isArray(items)) for (const it of items) p.values.set(it.name, it.value); else for (const k of Object.keys(items)) p.values.set(k, items[k]);
  }
  if (inc.process && inc.data_items && typeof inc.data_items === 'object') { const p = get(inc.process, inc.page || 'Main Page'); for (const k of Object.keys(inc.data_items)) if (!/^expr:/.test(k) && !p.values.has(k)) p.values.set(k, inc.data_items[k]); }
  for (const r of (inc.stage_log || []).slice(-60)) if (r.process && r.page && r.stage) { const p = get(r.process, r.page); if (!p.log.has(r.stage)) p.log.set(r.stage, []); if (p.log.get(r.stage).length < 3) p.log.get(r.stage).push(r.seq); }
  return { pages, throwsAt };
}

function pageOverlayCreate(ov, proc, page) { const k = (proc + '|' + page).toLowerCase(); return ov.pages[k] = ov.pages[k] || { fail: new Set(), path: new Map(), pathOrder: [], values: new Map(), log: new Map(), chain: false }; }


const api = { parseBp, renderPage, segHitsRect, routeLink, stageInfo, describe, overlayFrom, pageOverlay, pageOverlayCreate, geom, tag, attr, unx, esc, LOOK };
if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.BPDRAW = api;
})(typeof window !== 'undefined' ? window : this);
