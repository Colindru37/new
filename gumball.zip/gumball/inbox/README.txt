Drop .xml / .bpprocess / .bpobject exports or .bprelease files here while gumball.cmd is running; they render on their own.
