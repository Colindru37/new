Drop Blue Prism exports (.xml) or releases (.bprelease) here while bluewindow is running: each is picked up by itself.
