# edgecli — Edge as a CLI

On a machine where nothing can be installed, Edge is the one runtime you have:
JS engine, network, your SSO sessions, renderer, PDF printer. This makes all of it
reachable from a PowerShell prompt, so Edge is an engine you script, not an app
you look at. The Copilot web chat is one verb (`edge ask`), not the point.

Files
- `EdgeCli.cs`  W3C WebDriver client, .NET 4.8 BCL only, C# 5 (Add-Type loads it).
  Superset of `pythontoc/webdriver/WebDriverClient.cs`: + ExecuteScript, Screenshot,
  PrintToPdf, page source, elements/count, tabs, EnsureSingleFreshTab.
- `edge.ps1`  dot-source it; `edge <verb>`; config blocks `$EdgeCfg` + `$AskCfg` at the top.
- `edge.selftest.ps1`  run on the target machine, proves the PS layer on `selftest/page.html`.
- `selftest/Program.cs`  the same checks as a mono program (what was executed here).

Proven on the build box (Linux, mono, geckodriver + headless Firefox 157): 19/19, see selftest/Program.cs.
NOT executed on the build box: `edge.ps1` / `edge.selftest.ps1` (no PowerShell there). They are
written for 5.1 and mirror the C# test line for line; the first run on the target is the test.

Target setup
1. Put the folder anywhere; set `$EdgeCfg.Driver` to the msedgedriver.exe the bots use and
   `$EdgeCfg.Profile` to the profile copy. Driver major version must match Edge.
2. `powershell -ExecutionPolicy Bypass -File .\edge.selftest.ps1` → expect 15/15.
3. `. .\edge.ps1`, then `edge open copilot...`, `edge probe` → fill `$AskCfg.Input/Reply`
   with the XPaths you see (F12 helps). Then `edge ask "hi"`.
4. Think Deeper: `$AskCfg.Mode` is clicked before EVERY send unless `$AskCfg.ModeVerify`
   already matches; if it cannot be activated, ask refuses to send (never silently auto).
   If the mode lives in a dropdown, set `$AskCfg.ModeOpen` to the opener. Confirm the
   labels with `edge probe` (it lists think/deep/quick/mode/model controls with their
   aria-pressed/checked state). copilot.microsoft.com now redirects to the M365 sign-in,
   so the real DOM was NOT read here; the labels are a guess until probed.

Session model: one shell = one Edge (Add-Type state lives as long as the shell).
Start closes the news/start tab and any restored tabs: exactly one fresh tab, always.
