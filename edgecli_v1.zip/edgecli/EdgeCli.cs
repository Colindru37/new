using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace EdgeCli
{
    // Edge as a CLI: a W3C WebDriver client, .NET Framework 4.8 BCL only
    // (System.Net.Http + System.Web.Extensions). No Selenium, no third-party DLL,
    // no exe beyond the driver the estate already runs. Loaded by edge.ps1 with
    // Add-Type, so the source must stay C# 5 (no $"", no ?., no => members).
    //
    // Superset of pythontoc/webdriver/WebDriverClient.cs: same proven core, plus
    // the verbs a terminal needs: run JavaScript, screenshot, print to PDF, page
    // source, tabs. Any W3C driver works (msedgedriver on the estate, geckodriver
    // here); only the capabilities block differs.
    public sealed class Browser : IDisposable
    {
        private const string ElementKey = "element-6066-11e4-a52e-4f735466cecf";
        public const string EnterKey = "\uE007";

        private readonly HttpClient _http = new HttpClient();
        private readonly JavaScriptSerializer _json = new JavaScriptSerializer();
        private Process _driver;
        private string _baseUrl;
        private string _sessionId;

        public static Browser Current;

        public string SessionId { get { return _sessionId; } }
        public bool IsOpen { get { return _sessionId != null; } }

        // ---- lifecycle -------------------------------------------------------

        public void Start(string driverExePath, int port, bool headless, string browser)
        {
            Start(driverExePath, port, headless, browser, null);
        }

        // extraArgs go to the browser binary (e.g. Edge: "--user-data-dir=C:\x",
        // Firefox: "-profile", "C:\x"). After the session opens, the browser is
        // reduced to exactly ONE fresh tab: the start/news tab and any restored
        // tabs are closed. Every later verb acts on that tab.
        public void Start(string driverExePath, int port, bool headless, string browser, string[] extraArgs)
        {
            _json.MaxJsonLength = int.MaxValue;
            var psi = new ProcessStartInfo
            {
                FileName = driverExePath,
                Arguments = "--port=" + port,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };
            _driver = Process.Start(psi);
            _baseUrl = "http://127.0.0.1:" + port;
            _http.Timeout = TimeSpan.FromSeconds(180);

            WaitForDriverUp(10000);

            object caps = BuildCapabilities(browser, headless, extraArgs);
            var body = new Dictionary<string, object> { { "capabilities", caps } };
            var resp = PostJson("/session", body);
            var value = (Dictionary<string, object>)resp["value"];
            _sessionId = (string)value["sessionId"];

            EnsureSingleFreshTab();
        }

        private static object BuildCapabilities(string browser, bool headless, string[] extraArgs)
        {
            var always = new Dictionary<string, object>();
            var args = new List<string>();
            if (extraArgs != null) args.AddRange(extraArgs);
            if (string.Equals(browser, "edge", StringComparison.OrdinalIgnoreCase))
            {
                always["browserName"] = "MicrosoftEdge";
                if (headless) { args.Add("--headless=new"); args.Add("--disable-gpu"); }
                args.Add("--no-first-run");
                always["ms:edgeOptions"] = new Dictionary<string, object> { { "args", args.ToArray() } };
            }
            else
            {
                always["browserName"] = "firefox";
                if (headless) args.Add("-headless");
                always["moz:firefoxOptions"] = new Dictionary<string, object> { { "args", args.ToArray() } };
            }
            return new Dictionary<string, object> { { "alwaysMatch", always } };
        }

        // Open one new blank tab, close everything else, land on the new one.
        public void EnsureSingleFreshTab()
        {
            var fresh = NewTab();
            foreach (var h in GetWindowHandles())
            {
                if (h == fresh) continue;
                SwitchToWindow(h);
                DeleteJson(Sess("/window"));
            }
            SwitchToWindow(fresh);
        }

        public void Quit()
        {
            try { if (_sessionId != null) _http.DeleteAsync(Sess("")).GetAwaiter().GetResult(); }
            catch { }
            _sessionId = null;
            try { if (_driver != null && !_driver.HasExited) _driver.Kill(); }
            catch { }
        }

        public void Dispose()
        {
            Quit();
            _http.Dispose();
        }

        // ---- navigation -------------------------------------------------------

        public void Navigate(string url)
        {
            PostJson(Sess("/url"), new Dictionary<string, object> { { "url", url } });
        }

        public string GetUrl()
        {
            return Convert.ToString(GetJson(Sess("/url"))["value"]);
        }

        public string GetTitle()
        {
            return Convert.ToString(GetJson(Sess("/title"))["value"]);
        }

        public string GetPageSource()
        {
            return Convert.ToString(GetJson(Sess("/source"))["value"]);
        }

        // ---- the universal verb ------------------------------------------------

        // Runs `script` in the page (a function body; use `return` and
        // arguments[0..n]). Returns the JSON value: string/number/bool/null,
        // Dictionary<string,object> for objects, ArrayList for arrays.
        public object ExecuteScript(string script, params object[] args)
        {
            var body = new Dictionary<string, object>
            {
                { "script", script },
                { "args", args ?? new object[0] }
            };
            return PostJson(Sess("/execute/sync"), body)["value"];
        }

        // ---- elements ----------------------------------------------------------

        public void Click(string xpath)
        {
            string id = FindElement(xpath);
            PostJson(Sess("/element/" + id + "/click"), new Dictionary<string, object>());
        }

        public void SendKeys(string xpath, string text)
        {
            string id = FindElement(xpath);
            PostJson(Sess("/element/" + id + "/value"),
                new Dictionary<string, object> { { "text", text } });
        }

        public void SendKeysAndEnter(string xpath, string text)
        {
            SendKeys(xpath, text + EnterKey);
        }

        public void Clear(string xpath)
        {
            string id = FindElement(xpath);
            PostJson(Sess("/element/" + id + "/clear"), new Dictionary<string, object>());
        }

        public string GetElementText(string xpath)
        {
            string id = FindElement(xpath);
            return Convert.ToString(GetJson(Sess("/element/" + id + "/text"))["value"]);
        }

        // Text of every match, in document order.
        public List<string> GetElementsText(string xpath)
        {
            var list = new List<string>();
            foreach (var id in FindElements(xpath))
                list.Add(Convert.ToString(GetJson(Sess("/element/" + id + "/text"))["value"]));
            return list;
        }

        public int Count(string xpath)
        {
            return FindElements(xpath).Count;
        }

        public bool IsEnabled(string xpath)
        {
            string id = FindElement(xpath);
            return Convert.ToBoolean(GetJson(Sess("/element/" + id + "/enabled"))["value"]);
        }

        public void SwitchToFrame(string xpath)
        {
            string id = FindElement(xpath);
            var reference = new Dictionary<string, object> { { ElementKey, id } };
            PostJson(Sess("/frame"), new Dictionary<string, object> { { "id", reference } });
        }

        public void SwitchToDefaultContent()
        {
            PostJson(Sess("/frame"), new Dictionary<string, object> { { "id", null } });
        }

        public bool WaitForElement(string xpath, int timeoutMs)
        {
            int waited = 0;
            while (waited < timeoutMs)
            {
                try { FindElement(xpath); return true; }
                catch (WebDriverException) { Thread.Sleep(250); waited += 250; }
            }
            return false;
        }

        // ---- capture ------------------------------------------------------------

        public void Screenshot(string pngPath)
        {
            string b64 = Convert.ToString(GetJson(Sess("/screenshot"))["value"]);
            File.WriteAllBytes(pngPath, Convert.FromBase64String(b64));
        }

        public void PrintToPdf(string pdfPath)
        {
            var body = new Dictionary<string, object> { { "background", true } };
            string b64 = Convert.ToString(PostJson(Sess("/print"), body)["value"]);
            File.WriteAllBytes(pdfPath, Convert.FromBase64String(b64));
        }

        // ---- tabs -------------------------------------------------------------------

        public List<string> GetWindowHandles()
        {
            var list = new List<string>();
            foreach (var h in (ArrayList)GetJson(Sess("/window/handles"))["value"]) list.Add((string)h);
            return list;
        }

        public string GetWindowHandle()
        {
            return Convert.ToString(GetJson(Sess("/window"))["value"]);
        }

        public void SwitchToWindow(string handle)
        {
            PostJson(Sess("/window"), new Dictionary<string, object> { { "handle", handle } });
        }

        public string NewTab()
        {
            var v = (Dictionary<string, object>)PostJson(Sess("/window/new"),
                new Dictionary<string, object> { { "type", "tab" } })["value"];
            return (string)v["handle"];
        }

        // Closes the current tab and lands on the first remaining one.
        public void CloseTab()
        {
            var remaining = (ArrayList)DeleteJson(Sess("/window"))["value"];
            if (remaining.Count > 0) SwitchToWindow((string)remaining[0]);
        }

        // ---- internals ---------------------------------------------------------------

        private string FindElement(string xpath)
        {
            var resp = PostJson(Sess("/element"),
                new Dictionary<string, object> { { "using", "xpath" }, { "value", xpath } });
            var value = (Dictionary<string, object>)resp["value"];
            return (string)value[ElementKey];
        }

        private List<string> FindElements(string xpath)
        {
            var resp = PostJson(Sess("/elements"),
                new Dictionary<string, object> { { "using", "xpath" }, { "value", xpath } });
            var list = new List<string>();
            foreach (var e in (ArrayList)resp["value"])
                list.Add((string)((Dictionary<string, object>)e)[ElementKey]);
            return list;
        }

        private string Sess(string tail)
        {
            return "/session/" + _sessionId + tail;
        }

        private Dictionary<string, object> PostJson(string path, object body)
        {
            string payload = _json.Serialize(body);
            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            var r = _http.PostAsync(_baseUrl + path, content).GetAwaiter().GetResult();
            return ReadResponse(r);
        }

        private Dictionary<string, object> GetJson(string path)
        {
            var r = _http.GetAsync(_baseUrl + path).GetAwaiter().GetResult();
            return ReadResponse(r);
        }

        private Dictionary<string, object> DeleteJson(string path)
        {
            var r = _http.DeleteAsync(_baseUrl + path).GetAwaiter().GetResult();
            return ReadResponse(r);
        }

        private Dictionary<string, object> ReadResponse(HttpResponseMessage r)
        {
            string text = r.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var parsed = _json.Deserialize<Dictionary<string, object>>(text);
            if (!r.IsSuccessStatusCode)
            {
                string reason = text;
                try
                {
                    var v = (Dictionary<string, object>)parsed["value"];
                    reason = Convert.ToString(v["error"]) + ": " + Convert.ToString(v["message"]);
                }
                catch { }
                throw new WebDriverException(reason);
            }
            return parsed;
        }

        private void WaitForDriverUp(int timeoutMs)
        {
            int waited = 0;
            while (waited < timeoutMs)
            {
                try
                {
                    var r = _http.GetAsync(_baseUrl + "/status").GetAwaiter().GetResult();
                    if (r.IsSuccessStatusCode) return;
                }
                catch { }
                Thread.Sleep(200);
                waited += 200;
            }
            throw new WebDriverException("driver did not come up on " + _baseUrl);
        }
    }

    public sealed class WebDriverException : Exception
    {
        public WebDriverException(string message) : base(message) { }
    }
}
