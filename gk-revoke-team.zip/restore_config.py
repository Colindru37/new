r"""Restore the real values; then the package is ready to run.

1. Fill restore_values.txt: one line per token, TOKEN = value (SCRUB_SHEET.md says where each
   value is in the original Python INIs). No quotes.
2. python restore_config.py
   - config/*.ini : tokens replaced, each file proved byte-identical to the build machine's.
                    Every file/folder path in them is already absolute under this folder (env\...).
   - env/         : trackers\ seeded (RITM list, Bot_Status, application list), attachments\,
                    screenshots\, logs\ created, ENV_VARS.txt = every Environment Variable value.
   python restore_config.py --check   -> only checks the package arrived intact (MANIFEST.sha256)
Standard library only. Scrubbed originals are kept in _scrubbed_backup/, so fix a typo and run again."""
import configparser, hashlib, json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
BACKUP = os.path.join(HERE, '_scrubbed_backup')


def sha(path):
    with open(path, 'rb') as f:                         # line endings do not count (git / editors change them)
        return hashlib.sha256(f.read().replace(b'\r\n', b'\n')).hexdigest()


def read_hashes(name):
    out = {}
    with open(os.path.join(HERE, name), encoding='utf-8') as f:
        for line in f:
            if line.strip():
                h, p = line.rstrip('\n').split('  ', 1)
                out[p] = h
    return out


def check_package():
    bad = 0
    for rel, h in read_hashes('MANIFEST.sha256').items():
        if rel == 'restore_values.txt':      # you fill this one in
            continue
        p = os.path.join(HERE, rel)
        src = os.path.join(BACKUP, rel) if os.path.exists(os.path.join(BACKUP, rel)) else p
        if not os.path.exists(src):
            print('MISSING ', rel); bad += 1
        elif sha(src) != h:
            print('CHANGED ', rel); bad += 1
    print('PACKAGE OK' if bad == 0 else f'PACKAGE DAMAGED: {bad} file(s)')
    return bad == 0


CHECKS = {
    'SHARE_ROOT': (r'^\\\\[^\\]+\\.+[^\\]$', 'starts with \\\\server\\ and has no trailing \\'),
    'SNOW_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'ALICE_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'BLUESPACE_BASE_URL': (r'^https://[^/]+$', 'https://host, no trailing /'),
    'ALICE_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'BLUESPACE_MAKER_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'BLUESPACE_CHECKER_BOT_ACCOUNT': (r'^[^@\s]+@[^@\s]+$', 'an account like name@domain'),
    'LABEL_GUID': (r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', 'a lower-case GUID'),
}


def main():
    if '--check' in sys.argv:
        sys.exit(0 if check_package() else 1)
    with open(os.path.join(HERE, 'scrub_counts.json'), encoding='utf-8') as fh:
        sheet = json.load(fh)
    tokens, files = sheet['tokens'], sheet['files']        # files: {rel: {TOKEN: count}}
    values = {}
    with open(os.path.join(HERE, 'restore_values.txt'), encoding='utf-8') as f:
        for n, line in enumerate(f, 1):
            s = line.rstrip('\r\n')
            if not s.strip() or s.lstrip().startswith('#'):
                continue
            if '=' not in s:
                sys.exit(f'restore_values.txt line {n}: no "=": {s!r}')
            k, v = s.split('=', 1)
            values[k.strip()] = v.strip()
    errors = []
    for t in tokens:
        v = values.get(t, '')
        if not v:
            errors.append(f'{t}: empty')
        elif t in CHECKS and not re.match(CHECKS[t][0], v):
            errors.append(f'{t}: {v!r} does not look right ({CHECKS[t][1]})')
        elif '{{' in v or v.startswith('"') or v.startswith("'"):
            errors.append(f'{t}: {v!r} (no quotes, no tokens)')
    for k in values:
        if k not in tokens:
            errors.append(f'{k}: not a token of this package (typo?)')
    if errors:
        print('restore_values.txt is not ready:'); [print('  ' + e) for e in errors]; sys.exit(1)

    # start from the scrubbed originals every time (a second run after a typo fix is safe)
    for rel in files:
        p, b = os.path.join(HERE, rel), os.path.join(BACKUP, rel)
        if os.path.exists(b):
            shutil.copyfile(b, p)
        else:
            os.makedirs(os.path.dirname(b), exist_ok=True); shutil.copyfile(p, b)
    expected = read_hashes('restored.sha256')
    ok_all = True
    for rel, counts in files.items():
        p = os.path.join(HERE, rel)
        with open(p, encoding='utf-8', newline='') as f:
            text = f.read()
        for t, c in counts.items():
            found = text.count('{{' + t + '}}')
            if found != c:
                print(f'STOP {rel}: {{{{{t}}}}} found {found} times, expected {c} (file edited after scrub?)'); sys.exit(1)
            text = text.replace('{{' + t + '}}', values[t])
        if '{{' in text and re.search(r'\{\{[A-Z_]+\}\}', text):
            print(f'STOP {rel}: a token is left: {re.search(r"{{[A-Z_]+}}", text).group(0)}'); sys.exit(1)
        with open(p, 'w', encoding='utf-8', newline='') as f:
            f.write(text)
        good = sha(p) == expected.get(rel)
        ok_all &= good
        print(('OK      ' if good else 'DIFFERS ') + rel + ('' if good else '   check: ' + ', '.join(sorted(counts))))
    if ok_all:
        print('RESTORED: every file is byte-identical to the build machine\'s config.')
        team = os.path.exists(os.path.join(HERE, 'PACKAGE_MODE.txt')) and open(os.path.join(HERE, 'PACKAGE_MODE.txt')).read().strip() == 'team'
        make_env(team)
    else:
        print('RESTORED WITH DIFFERENCES: a value above is mistyped (or the estate value changed since).\n'
              'Fix restore_values.txt and run again; the scrubbed copies are in _scrubbed_backup/.')
        sys.exit(2)


# ---- the run folders ----------------------------------------------------------------------------
def make_env(team=False):
    J = os.path.join
    cp = configparser.RawConfigParser(); cp.optionxform = str
    cp.read(J(HERE, 'config', 'master_populate.ini'), encoding='utf-8')
    if team:                                    # configs keep the share paths: no local folders, variables only
        return write_env_vars(cp, J(HERE, 'config') + '\\', J(HERE, 'ENV_VARS.txt'),
                              '<a folder the bot can write to, e.g. next to the master log_path>')
    root = cp.get('ELEMENTS', 'Bot_status_file').replace('/', '\\').split('\\env\\')[0]
    if os.path.normcase(os.path.normpath(root)) != os.path.normcase(os.path.normpath(HERE)):
        print(f'WARNING: the configs expect this folder at {root} but it is at {HERE}. Move it there (or ask for a rebuild).')
    env = J(HERE, 'env')
    for d in ['config', 'trackers', 'logs', 'templates', 'attachments\\alice', 'attachments\\bluespace', 'screenshots\\alice', 'screenshots\\bluespace',
              'logs\\master_populate', 'logs\\alice_maker', 'logs\\alice_checker', 'logs\\bluespace_maker', 'logs\\bluespace_checker']:
        os.makedirs(J(env, *d.split('\\')), exist_ok=True)
    for f in ['RITM_List_Tracker.xlsx', 'Bot_Status.xlsx', 'Revocation_Application_list.xlsx']:
        if not os.path.exists(J(env, 'trackers', f)):
            shutil.copyfile(J(env, 'seed', f), J(env, 'trackers', f))
    write_env_vars(cp, root + '\\config\\', J(env, 'ENV_VARS.txt'), root + '\\env\\logs')
    print('READY: configs in', root + '\\config\\', '| trackers seeded in', root + '\\env\\trackers', '| variables:', root + '\\env\\ENV_VARS.txt')


def write_env_vars(cp, C, out, log_folder):
    label = cp.get('ELEMENTS', 'LabelID') if cp.has_option('ELEMENTS', 'LabelID') else '<LabelID from master_populate.ini>'
    rows = [
        ('GK Revoke Run Mode', 'test', 'test = no browser; dryrun = browser, every click only logged; live = real'),
        ('GK Revoke Browser Kind', 'edge', ''),
        ('GK Revoke Driver Path', 'C:\\...\\msedgedriver.exe', 'FILL: the real msedgedriver.exe'),
        ('GK Revoke Profile Root', 'C:\\Users\\<bot user>\\tep', 'the Edge user-data folder (the Python copied it there)'),
        ('GK Revoke Log Folder', log_folder, ''),
        ('GK Revoke Master Config Path', C + 'master_populate.ini', ''),
        ('GK Revoke Alice Maker Config Path', C + 'alice_maker.ini', ''),
        ('GK Revoke Alice Checker Config Path', C + 'alice_checker.ini', ''),
        ('GK Revoke BlueSpace Maker Config Path', C + 'bluespace_maker.ini', ''),
        ('GK Revoke BlueSpace Checker Config Path', C + 'bluespace_checker.ini', ''),
        ('GK Revoke Alice Maker Queue Name', 'GK Revoke Alice Maker', 'create the queue with this name, key column RITM Number'),
        ('GK Revoke Alice Checker Queue Name', 'GK Revoke Alice Checker', 'same'),
        ('GK Revoke BlueSpace Maker Queue Name', 'GK Revoke BlueSpace Maker', 'same'),
        ('GK Revoke BlueSpace Checker Queue Name', 'GK Revoke BlueSpace Checker', 'same'),
        ('GK Revoke Alice Credential Name', 'GK Revoke Alice', 'Credential Manager entry: the Alice bot account + password'),
        ('GK Revoke BlueSpace Credential Name', 'GK Revoke BlueSpace', 'Credential Manager entry: the BlueSpace bot account + password'),
        ('GK Revoke Max Consecutive Failures', '3', 'number'),
        ('GK Revoke Label ID', label, 'the sensitivity label GUID'),
        ('GK Revoke SMTP Server', '', 'FILL: the estate relay ("host" or "host:port"); empty = Outlook .msg template (not in this package)'),
        ('GK Revoke Email From', '', 'FILL: sender address (with SMTP)'),
        ('GK Revoke Email To', '', 'FILL: team addresses, ; separated (with SMTP)'),
    ]
    with open(out, 'w', encoding='utf-8') as f:
        f.write('Environment Variables (System > Processes > Environment Variables), all text unless noted.\n'
                'Config paths assume the config folder stays where it is now; change them if you move it.\n'
                'Session variable: GK Revoke Stop After Next Item (flag, False) lives in the processes, not here.\n\n')
        for n, v, note in rows:
            f.write(f'{n} = {v}' + (f'      # {note}' if note else '') + '\n')
    print('READY: variables in', out)


if __name__ == '__main__':
    main()
