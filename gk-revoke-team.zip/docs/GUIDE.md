# GK Revoke on Blue Prism: objects, processes, configuration

The five GK Revoke Python/Selenium bots (Master Populate, Alice Maker, Alice Checker, BlueSpace
Maker, BlueSpace Checker) rebuilt as Blue Prism. Proven end to end on UAT on 2026-10-17 (all five
processes, real ServiceNow / Alice / BlueSpace / Edge / Word / SMTP). This is the reference for
whoever runs, reconfigures or extends it. The import set is 12 XML files: 7 business objects and
5 processes.

Nothing is installed on the machine: no Selenium, no interop DLLs, no PowerShell. The Browser
object speaks the W3C WebDriver protocol to `msedgedriver.exe` over HTTP with .NET Framework
classes only; Excel files are read and written as OOXML zip + XML (no Excel); Word is driven
late-bound through COM for the evidence documents; mail goes over plain SMTP.

## 1. Shape

```
Process (one per bot)                      Objects it calls
  Main: queue loop, failure handling  ---> Work Queues / Credentials (Blue Prism internal)
  Work RITM: one ticket end to end   ---> GK Revoke ServiceNow   (task, RCRT list, attachments)
                                     ---> GK Revoke Alice / GK Revoke BlueSpace (the portal)
                                     ---> GK Revoke Tracker     (the shared xlsx trackers)
                                     ---> GK Revoke Evidence    (Word docs + sensitivity label)
                                     ---> GK Revoke Common      (email, folders, and the
                                                                 process logic as code actions)
  every portal object               ---> GK Revoke Browser      (WebDriver client, config reader)
```

Rules that hold everywhere:

- Every locator is an `[XPATHS]` key of the bot's INI, every URL a `[URLS]` key, every path or
  setting an `[ELEMENTS]` key. The objects never hard-code a locator. The INI is the Python
  team's file with the same keys; `{}` in an XPath is the row index slot, filled by the `Index`
  input of a Browser action.
- A process holds no code. Every piece of logic the Python did in Python lives in a
  `GK Revoke Common` action named `<Process> - <Stage>` (Blue Prism processes cannot run Code
  stages).
- Every object page that touches the browser starts by switching to its window and re-entering
  its frames from the top, so a page never depends on where the previous action left the browser.
- A failure inside one ticket goes to the process's `Handle RITM Failure` page (tracker row
  marked Fail with the reason, task reassigned to the group in the INI); a failure outside the
  ticket loop goes to `Report Fatal` (exception email, bot Offline, browser closed).

## 2. Objects

### GK Revoke Browser

The WebDriver client and the config reader. Actions take an `XPath Key` (INI key, or a literal
XPath starting with `/`, `(` or `.`) and an `Index` (fills the key's `{}` slot, 0 when none).

| Action | What it does |
|---|---|
| Load Config | Reads the INI (Python ConfigParser rules: `%%`, case-insensitive keys, `#`/`;` comments, continuation lines). Once per run. |
| Get Setting / Get Setting Or Default / Has Setting / Get XPath | Config reads. `Or Default` is for optional keys. |
| Launch Browser / Close Browser | Start `msedgedriver`, open one tab; Run Mode `live`, `dryrun` (reads only, every mutation logged as `WOULD`) or `test` (no browser). Profile Root = Edge user data folder copied for SSO. |
| Navigate / Refresh Page / Get Title / Get URL | Navigation; both reset the frame breadcrumb to top. |
| Wait For Element | present / visible / clickable / absent, `Found` = False on timeout, never raises. |
| Click / Double Click / Send Keys / Upload File | Click retries once after scrolling when intercepted, then clicks via script. Upload File waits for presence only (file inputs are hidden). |
| Get Text / Get Attribute / Count Elements / Is Displayed / Is Enabled / Get Selected Option | Reads. `Count Elements` with `Wait For One` = Selenium `find_elements`. |
| Switch To Frame / Switch To Top / Get Windows / Switch To Window / Switch To Last Window / New Tab / Close Window / Maximize Window | Frame and window handling. Frame switch retries while a frame is reloading. |
| Execute Script / Scroll To Element / Scroll Page / Get Page Heights | JavaScript. |
| Accept Alert / Take Screenshot / Wait For Download / Dump Page / Log / Get Trace | Alerts, evidence, downloads, diagnostics. |

Built in: a site `confirm()` or `alert()` that opens while a command is in flight is accepted and
the command re-sent (up to three times), so the Alice "designed for Internet Explorer 11" popups
never stop a run.

Log: `<Log Folder>\browser-YYYY-MM-DD.log`, one line per WebDriver call
(`time | frames | call | ms | status | reply`), plus `RCRT columns: ...` and other diagnostics. On
a failure the object writes `dump-<timestamp>-<action>.png/.txt` (screenshot, page source, last
calls) and the exception text names the dump.

### GK Revoke ServiceNow

| Action | What it does |
|---|---|
| Login | Portal in the current tab, one-time pop-up dismissed, `gsft_main` frame entered. |
| Open Task | Opens the RITM by URL, takes its first **active** catalog task, opens the task by its own URL (the related-list link gives a read-only form on UAT), reads the State. `Found` = False with a `Reason` when no task, none active, or the state is not accepted (`snow_accepted_task_states`, default `Open`). |
| Set Task State | Work in progress / Closed complete + work note, Save & Stay or Save & Exit. |
| Download Attachment | Clicks the Request Item Attachment link, waits for the xlsx in the folder. |
| Update RCRT Status | Pages through the Recertification Remediation list; for every row whose Request number is in `Requests` writes the comment and sets MT Done (Status Kind MT) or CT Done (CT) true. Columns are located **by header text** at run time, see section 4.3. |
| Assign To Ops | Assignment group + work note + Save & Stay (the failure path). |
| Upload Attachments | Attachment dialog, disclaimer tick, one file at a time, waits for each row. |
| Get Open RITMs | Scrapes the Master's task list URL: RITM numbers in page order. |
| Read RITM Details | Opens the RITM by URL, reads the NAR ID (`_(digits-digits)` regex on Additional Information) and the task assignment group. |

### GK Revoke Alice

Login (new tab, SSO or user id + Next, up to 5 attempts), Open Region (EMEA / AMER / APAC =
1st / 2nd / 3rd User Admin link), Find User (Listed / Found / Email), Select User, **Get Roles**
(the whole roles table in one script call: Index, Role Name, Key, Checked; header rows skipped;
a user can have 1000+ roles), Revoke Roles (untick the wanted ticked roles, Update once), Check
Roles (checker compare, no browser), Delete User, Open User Info / Capture Page Evidence (scroll
and screenshot the info window) / Close User Info, Capture Screenshot.

Role matching rule, from the Python: table name with spaces removed and upper-cased equals the
attachment entitlement trimmed and upper-cased, with the `_EMEA` / `_APAC` / `_AMER` suffix cut
off to pick the region (no suffix = all three regions).

### GK Revoke BlueSpace

Login (credential from Credential Manager when the form shows), Open User Admin (Settings, User
tab, grid iframe), Find User (user id filter; Listed / Found / Status / **Edit Available**), Open
User Edit, Set User Inactive, Save User (re-reads the status), Get Memberships (groups and teams,
Key = the number before `:` without leading zeros), Remove Membership, Check Memberships, Capture
Screenshot.

`Edit Available` = the row has an Edit link. Some accounts show none for the bot's account; the
Maker and the Checker both judge such a user "already revoked" and move on.

### GK Revoke Tracker

The shared Excel files, read and written as OOXML without Excel, every write under a `.lock`
file next to the tracker (stale after 10 minutes). Actions: Claim Next RITM, Update RITM Status,
Append Rows (creates the file with the headers when missing), Read Rows (optional filter, all
cells as text, `4711` matches a numeric cell), Update Field, Add RITMs (Master: new tickets with
both statuses Open), Read Attachment (the ticket's xlsx, whole numbers without `.0`), Update Bot
Status. **A tracker open in Excel fails the write**: close Excel during runs.

### GK Revoke Evidence

Build Evidence Docs: one `.docx` per `Batch Size` screenshots (0 = 40), named
`<stem>_batch_<n>.docx`, built through Word COM, **labelled before the first save** (a
mandatory-label policy makes Word refuse to save an unlabelled document). Apply Sensitivity
Label: label an existing file, skipped when it already carries that label. Errors name the Word
member (`Word SaveAs2: ...`, `Word SetLabel: ...`).

### GK Revoke Common

Send Email (plain SMTP, `host` or `host:port`, `;` lists), Send Exception Email (SMTP when a
server is configured, else the Outlook `.msg` template like the Python), Clear Folder (deletes
**everything** in the folder, used on the attachment folder), Get Computer Name, plus every
process code stage as an action named `<Process> - <Stage>`.

## 3. Processes

All five share the same skeleton: `Reset Global Data`, `Initialise Session` (config, browser,
logins, bot Running), a queue loop (`Continue To Work`, Get Next Item, `Work RITM`, Mark
Completed / Mark Exception), `Shut Down Session` (browser closed, bot Offline), `Report Fatal`,
`Handle RITM Failure`. `GK Revoke Max Consecutive Failures` stops the run after that many
failed tickets in a row; the session flag `GK Revoke Stop After Next Item` or a Control Room stop
request ends the loop after the current ticket.

### Master Populate Queue

For every RITM on the ServiceNow task list URL: skip when the ticket is already in the RITM List
tracker; else read its NAR ID and assignment group, look the NAR ID up in the application list
(must be Active) and require the task group to equal `assignment_group` from the INI; register
the ticket in the tracker and add it to the Alice Maker or BlueSpace Maker queue; otherwise mark
both statuses Fail "RITM not in Bot scope". The key column of every queue is `RITM Number`.

### Alice Maker

Per ticket: RITM tracker In Progress, attachment folder emptied, maker task opened (state must
be accepted), RCRT tab checked, task set Work in progress, attachment downloaded and read. Per
user in the attachment: regions and roles planned from the entitlements (or the account when the
action is `revoke account` or the `AliceUser` entitlement is requested), roles unticked / user
deleted per region, results combined per request id, RCRT rows updated (comment = status, MT Done
true), maker tracker rows appended (`MTStatus` Done). After the last user: task Closed complete
"Maker Task Done", maker tracker Comment `<pc> - Done`, RITM tracker Completed, and a Checker
queue item added.

Statuses written: `Entitlement/revoke completed`, `Role already revoked`,
`User access already revoked`.

### Alice Checker

Per ticket: checker task opened, the maker tracker rows of the ticket grouped by owner; per owner
and region the user is searched and the roles compared (a role still ticked =
`Entitlement not revoked, RITM Skipped.`), or for accounts the user must be absent; evidence
screenshots of the user info page (or of the empty search); checker tracker rows appended; RCRT
rows get CT Done true. Then the screenshots become labelled Word documents, uploaded to the task,
the task is closed "CT Done", checker tracker Task Complete Closed = Done, RITM tracker Completed.
Anything still present = Business Exception, the task goes to the ops group.

### BlueSpace Maker

Per ticket as the Alice Maker, then per (account, action) group of the attachment: `revoke
account` = user set Inactive; `revoke entitlement` = each requested group / team number removed
from the memberships (the user becomes Inactive when its only group goes). A user without an Edit
link is "already revoked". Then the Python's ServiceNow update: every RCRT row gets MT Done true,
matched rows get the remark as comment, unmatched rows `role already revoked`; task closed
"MT Done"; tracker rows stamped; RITM tracker Completed.

### BlueSpace Checker

Per ticket and owner: user searched; for entitlements the Edit form's groups and teams must not
contain the requested numbers (no Edit link = all revoked); for accounts the user must be Inactive
or absent. One evidence screenshot per owner, CT Done, documents, upload, close, same as Alice.

## 4. Configuration

### 4.1 Environment Variables (System > Environment Variables)

| Name | Value |
|---|---|
| GK Revoke Master Config Path, Alice Maker / Alice Checker / BlueSpace Maker / BlueSpace Checker Config Path | Full path of each INI. |
| GK Revoke Run Mode | `live` for real runs; `dryrun` logs every mutation as WOULD; `test` = no browser. |
| GK Revoke Browser Kind | `edge` (`firefox` only on the dev box). |
| GK Revoke Driver Path | Full path of `msedgedriver.exe` (must match the installed Edge major version). |
| GK Revoke Profile Root | Edge user data folder to copy for SSO; empty = fresh profile. |
| GK Revoke Log Folder | Where `browser-*.log` and dumps go. |
| GK Revoke Label ID | The sensitivity label GUID applied to evidence documents. |
| GK Revoke SMTP Server, Email From, Email To | Exception mail over SMTP (`host` or `host:port`; To is a `;` list). Leave SMTP Server empty to use the Outlook `.msg` template instead. |
| GK Revoke Alice Credential Name, BlueSpace Credential Name | Names of the two Credential Manager entries (bot account + password). |
| GK Revoke Alice Maker / Alice Checker / BlueSpace Maker / BlueSpace Checker Queue Name | The four Work Queues (key column `RITM Number`). |
| GK Revoke Max Consecutive Failures | Stop after N failed tickets in a row (3). |

### 4.2 The INIs

One per bot, the Python team's files with the same sections and keys. What matters when moving
between environments:

- `[URLS]`: `snow_url` (the portal / the Master's task list URL), `alice_url`, `bluespace_url`
  (and the BlueSpace Maker's aliases `URLFile`, `BluespaceApplicationURL`, `blueSpace_url`).
- `[ELEMENTS]` paths: `log_path`, `Bot_status_file`, `RITM_list_tracker_path`,
  `revocation_application_list` (Master), `Maker_task_internal_tracker_path`,
  `checker_task_internal_tracker_path`, `attachment_folder_path` (BlueSpace Maker also
  `Attchment`), `screenshot_folder_path`, `sample_email_file_path`.
- `[ELEMENTS]` behaviour: `implicit_delay`, `explicit_delay` .. `explicit_delay4` (seconds;
  `explicit_delay4` is the upload wait), `screenshot_file_count` (docs batch size), `bot_name`
  (the Bot_Status row), Master `assignment_group` (the task group that is "ours") and
  `ticketing_tool` (the text written into the RITM tracker).
- `snow_assignment_group_name` / `SN_assignment_group_name`: the group a failed ticket is
  reassigned to. **On UAT set it to your own group**, or a failed run moves the ticket out of
  your reach.
- `snow_accepted_task_states` (optional, default `Open`): comma list of task states the bot
  will work, e.g. `Open, Work in progress` to rerun a ticket a previous run left in progress.
  Keep it absent in prod.
- `rcrt_header_number`, `rcrt_header_request`, `rcrt_header_comment`, `rcrt_header_mt`,
  `rcrt_header_ct` (optional): the header texts of the RCRT list columns when they differ from
  `Number`, `Request number`, `Task assignee comments`, `MT Done`, `CT Done`.
- `label_site_id` (optional, checker INIs): the Azure tenant GUID for the label, only if Word
  rejects the label without it (it did not on UAT).
- `[XPATHS]`: the locators. `{}` = row index. Keys ending in `/td[n]` under the RCRT list are
  only a fallback now (see 4.3).

Keys are case-insensitive and must not be duplicated with a different case.

### 4.3 ServiceNow list views (the thing that bit three times)

The Recertification Remediation related list is read by column. The INI's `td[n]` numbers were
the positions in the prod bot accounts' personalised views, and the maker and checker views
differed because they were two accounts. The object therefore reads the header row once per
visit and finds the columns by name, calibrated on the `Number` column. Requirements:

- The columns `Number`, `Request number`, `Task assignee comments` (makers), `MT Done` (makers)
  and `CT Done` (checkers) must be visible in the list view of **every task form the bot opens**
  (maker task and checker task can show different views). Personalize List Columns on each.
- When a required column is missing the bot stops with
  `The RCRT list view has no 'Request number' column (...) Columns shown: ...` instead of writing
  nothing.
- The resolution is logged in the browser log as `RCRT columns: headers: ... -- request: td[n]
  by header ...`.

### 4.4 Trackers (xlsx, first sheet, header row 1)

| File | Columns | Written by |
|---|---|---|
| RITM List tracker | Date, Time, Ticketing Tool, Application, UseCase, Ticket, Maker Task Status, Checker Task Status, Comment | Master adds; makers / checkers set their status column + Comment |
| Bot_Status | Bot Name, Status | every process (Running / Offline) |
| Revocation application list | NAR ID, Application_Name, Status | hand kept; headers matched ignoring case, spaces, underscores |
| Maker internal tracker | RITMNumber, Maker Task ID, Attachd File Name, Current Date, Current Time, Request_Type, Owner, Role_Name, Region Name, Request_Id, Remarks, SC_Updation_Time, MTStatus, Comment | makers; the checker reads it to know what to check |
| Checker internal tracker | RITM Number, Task Id, Processing Date, Processing Time, Owner, Entitlement, Action, Request Id, Checker Task ID, Set CT Status, Task Complete Closed, Remark | checkers |
| Ticket attachment | account, action, entitlement, application, request_no (any case) | the requester |

Dates are written as text. Delete a ticket's row from the RITM List tracker to make the Master
queue it again; leave the maker tracker rows, their `Not Done` status makes the maker process the
request again.

### 4.5 Machine prerequisites

Edge + matching `msedgedriver.exe` in a folder the bot may read; Word installed and the account
signed in once so the label policy is cached; the Edge download folder policy must allow the
attachment folder; the bot account's ServiceNow views as in 4.3; SMTP relay reachable or the
Outlook template present; the trackers in the configured folders (seeds in `env/trackers`).

## 5. Operating

- **Order of a full cycle**: Master Populate Queue, then the Maker, then the Checker of each
  application. The Maker adds the Checker's queue item itself.
- **Rerun a ticket**: its row out of the RITM List tracker, Master again (or re-add the queue
  item), the task state accepted (`snow_accepted_task_states` on UAT), Excel closed. RCRT writes
  are overwrites, running twice leaves the rows the same; the maker tracker gets a second set of
  rows (cosmetic).
- **Reading a stop**: the Blue Prism session log names the stage; the exception text of a
  browser failure names the dump file; the browser log shows the last calls. Three lines are
  enough for a diagnosis: the session log stage, the exception text, the last browser log lines.
- **Single actions in Object Studio** are the fast loop: Tracker `Read Rows` on a tracker,
  Evidence `Build Evidence Docs` on two PNGs with the Label ID, Common `Send Email` to yourself,
  Browser `Load Config` + `Launch Browser` + `Navigate` + `Close Browser`.
- **Mock pack** (`gk-revoke-mock.zip`): fake ServiceNow / Alice / BlueSpace served by the Python
  already on the machine, with a setup script that rewrites the INIs; proves the whole pipeline
  plus Edge / Word / SMTP in minutes, not the real sites' locators.
- **UAT to prod**: the URLs, the Master `assignment_group` and the task list URL's group id, the
  ops group keys, `snow_accepted_task_states` removed, the list views on the prod account, the
  label GUID, SMTP addresses, the queue and credential names.

## 6. Deliberate differences from the Python

- Task and RITM records are opened by URL, not through the banner search (slow on UAT).
- RCRT columns are found by header text, not by position.
- The Alice roles table is read in one script call, not row by row.
- A BlueSpace user without an Edit link is "already revoked" in the Checker too (the Python
  checker failed the ticket).
- The Alice checker matches role names with the same rule as the maker (the Python checker
  compared raw text).
- Site popups are accepted automatically; the Python had no alert handling.
- Evidence documents are labelled before their first save.
- Exception mail goes over SMTP when a server is configured (no Outlook object-model prompt).
- The Master stamps "now" as the created time (the Python's created-date read was commented out).

## 7. Known limits

- Row-by-row reads remain for the BlueSpace groups / teams lists, the RCRT rows (inherent, each
  row is edited) and the Master's queue list. Sizes on prod were not measured; above ~50 rows
  they should become one-call reads like Get Roles.
- The Word label path was proven on UAT with the Label ID only; `label_site_id` exists for a
  tenant that demands it.
- Screenshots are browser viewport captures: Edge must not be minimised.
- Stress testing (many tickets, long runs, parallel resources on the same trackers) is not done.
