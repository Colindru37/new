# For Copilot: "windows at failure" section for Radar (C# 5, .NET Framework, BCL + user32 P/Invoke only)

Context: Radar is a Blue Prism 7.2.1 business object; its shared code is core/Radar.cs (`public static class RadarCore`).
Dump Incident writes incident.txt. Add ONE section to it: the top-level windows visible at the moment of failure,
so a surprise dialog ("Session expired", "Are you sure?", an update prompt) is visible as text even when the
screenshot is unclear. Also add whether the workstation is locked.

Write these, inside RadarCore, C# 5 (no `?.`, no `$""`, no `nameof`), every call guarded by try/catch, never throws:

1. `static List<string> TopWindows()` -> one line per VISIBLE top-level window with a non-empty title:
   `"<title, max 100 chars>" | <process name> pid <pid> | <owner window title or -> | flags`
   flags: `FOCUS` for the foreground window, `MODAL` if it has an owner and the owner is disabled, `TOPMOST`.
   Use user32 EnumWindows / IsWindowVisible / GetWindowText / GetWindowThreadProcessId / GetForegroundWindow /
   GetWindow(GW_OWNER) / IsWindowEnabled / GetWindowLong(GWL_EXSTYLE) & WS_EX_TOPMOST. Max 40 lines, 300 ms budget.
2. `static bool? ScreenLocked()` -> true when the input desktop is not the default desktop
   (OpenInputDesktop + GetUserObjectInformation(UOI_NAME) != "Default"; null when the call fails).
3. In `Configure(...)`: remember the set of window titles+process names at that moment (static field, per process).
4. In `DumpCore`, after the network-paths section, append:
   ```
   --- windows at failure ---
   screen: locked | unlocked | unknown
   "Session expired" | chrome pid 4120 | - | FOCUS MODAL NEW
   ...
   ```
   `NEW` = not in the set remembered at Configure. Same lines into incident.json as `"windows": [ "...", ... ]`.
5. Mask every title with the existing `Mask(...)` (IBAN / card / CNP masking already in Radar.cs).

Test (PowerShell, core/RadarSelfTest.ps1 already compiles Radar.cs with Add-Type): open Notepad, call
`RadarCore.Configure(root, 50)`, open a second Notepad, `RadarCore.Dump(...)`, check incident.txt has the section,
both Notepads listed, the second one marked NEW, one line marked FOCUS.
