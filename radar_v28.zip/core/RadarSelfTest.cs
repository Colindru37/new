// Self-test for RadarCore.cs: simulates the Blue Prism runtime path
//   action entry -> Record ... -> write stage dies -> Recover -> Dump(page data items) -> folder.
// Exit code 0 = PASS. Run: ./build.sh
using System;
using System.IO;
using System.Collections.Generic;
using System.Web.Script.Serialization;

public static class RadarSelfTest
{
    // stand-ins for the frames Blue Prism produces: the generated object class with its Run_<stage> method,
    // and the resource connection thread whose socket errors are noise
    internal sealed class Demo_API { public void Run_JSON_To_Customer() { throw new ArgumentException("Invalid JSON primitive: ."); } [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)] public string Run_Frames() { return RadarCore.FramesForTest(); } }
    sealed class PersistentConnection { public void CommsThread() { throw new System.Net.Sockets.SocketException(11001); } }

    // ---- stand-ins for the v15 layers: shaped like LoggingEngine / ProcessStage / BluePrismProcess / ProcessValue ----
    public abstract class FakeLoggingEngine
    {
        public object Ctx;
        protected FakeLoggingEngine(object ctx) { Ctx = ctx; }
        public abstract void ProcessPrologue(object info, object stage, object inputs);
        public abstract void ProcessEpilogue(object info, object stage, object outputs);
        public abstract void SubSheetPrologue(object info, object stage, object inputs);
        public abstract void SubSheetEpilogue(object info, object stage, object outputs);
        public abstract void ActionPrologue(object info, object stage, string objectName, string actionName, object inputs);
        public abstract void ActionEpilogue(object info, object stage, string objectName, string actionName, object outputs);
        public abstract void ObjectPrologue(object info, object stage, string objectName, string actionName, object inputs);
        public abstract void ObjectEpilogue(object info, object stage, string objectName, string actionName, object outputs);
        public abstract void CodePrologue(object info, object stage, object inputs);
        public abstract void CodeEpilogue(object info, object stage, object inputs, object outputs);
        public abstract void CalculationEpilogue(object info, object stage, FakeValue resultValue);
        public abstract void LogError(object info, object stage, string errMessage);
        public abstract void RecoverPrologue(object info, object stage);
        public abstract void WritePrologue(object info, object stage, object inputs);
        public abstract void ExceptionPrologue(object info, object stage);
        public abstract void ResumePrologue(object info, object stage);
        public abstract void LogStatistic(Guid sessionId, string statisticName, FakeValue value);
        public abstract int Pending { get; }
    }
    public class FakeValue { public string DataType = "text"; public string FormattedValue; public FakeCollection Collection; }
    public class FakeCollection { public List<Dictionary<string, FakeValue>> Rows = new List<Dictionary<string, FakeValue>>(); public int Count { get { return Rows.Count; } } }
    public class FakeArg { public string Name; public FakeValue Value; }
    public class FakeSubSheet { public string Name; }
    public class FakeProcess
    {
        public string Name; public List<FakeStage> All = new List<FakeStage>();
        public List<FakeStage> GetStages(Guid pageId) { return All.FindAll(x => x.Page == pageId); }
        public string Version = "7";
        public Guid ExceptionSource, RecoverySource; public string RecoveryType, RecoveryDetail; public bool RecoveryMode;
        public FakeStage GetStage(Guid id) { return All.Find(x => x.Id == id); }
        public FakeAppDef _applicationDefinition = new FakeAppDef();
    }
    public class FakeAttr { public string Name; public string Value; public bool Dynamic, InUse = true; }
    public class FakeType { public string Name; }
    public class FakeElement { public string Name, FullPath; public FakeType Type; public List<FakeAttr> ActiveAttributes = new List<FakeAttr>(); }
    public class FakeParam { public string Name, Expression; }
    public class FakeStep { public Guid ElementId; public string ActionName; public List<FakeParam> Parameters = new List<FakeParam>(); }
    public class FakeAppDef { public Dictionary<Guid, FakeElement> Els = new Dictionary<Guid, FakeElement>(); public FakeElement FindElement(Guid id) { FakeElement e; return Els.TryGetValue(id, out e) ? e : null; } }
    public class FakeInfo { public long AutomateWorkingSet = 123456789; public long TargetAppWorkingSet = 987654321; }
    public class ExceptionStage : FakeStage { public string ExceptionType, ExceptionDetail; public bool UseCurrentException, SaveScreenCapture; }
    public class RecoverStage : FakeStage { public int Attempts, MaxAttempts; public bool LimitAttempts, AttemptsExceeded; }
    public class AppStage : FakeStage { public List<object> Steps = new List<object>(); public List<Guid> Used = new List<Guid>(); public List<Guid> GetElementsUsed() { return Used; } public int Timeout = 30; }
    public class FakeStage
    {
        public string Name { get; set; }
        public string StageType { get; set; }
        public FakeSubSheet SubSheet;
        public FakeProcess Process;
        public Guid Page; public Guid Id = Guid.NewGuid();
        public Guid GetSubSheetID() { return Page; }
    }
    public class DataStage : FakeStage { public FakeValue Value; }
    public class FakeWait : FakeStage { public double Timeout; }
    public class CollectionStage : DataStage { public FakeCollection CurrentCollection; }
    static FakeStage St(FakeProcess p, Guid page, string pageName, string name, string type)
    {
        var s = new FakeStage { Name = name, StageType = type, SubSheet = new FakeSubSheet { Name = pageName }, Process = p, Page = page };
        p.All.Add(s); return s;
    }
    static List<FakeArg> Args(params string[] kv)
    {
        var l = new List<FakeArg>();
        for (int i = 0; i + 1 < kv.Length; i += 2) l.Add(new FakeArg { Name = kv[i], Value = new FakeValue { FormattedValue = kv[i + 1] } });
        return l;
    }

    // the bank-machine chain in miniature: view (form) events -> runner -> listener -> list -> record on this thread
    public class FakeView { public event EventHandler CloseRequested; public void Touch() { if (CloseRequested != null) CloseRequested(this, EventArgs.Empty); } }
    public class FakeRecord { public System.Threading.Thread mRunnerThread; }
    public class FakeListener { public List<FakeRecord> mList = new List<FakeRecord>(); }
    public class FakeRunner { public FakeListener _mListener = new FakeListener(); public FakeRunner(FakeView v) { v.CloseRequested += (s, e) => { }; v.CloseRequested += OnClose; } void OnClose(object s, EventArgs e) { } }

    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint = "CreateWindowExW", CharSet = System.Runtime.InteropServices.CharSet.Unicode, SetLastError = true)]
    static extern IntPtr CreateWindowEx(int exStyle, string cls, string title, int style, int x, int y, int w, int h, IntPtr parent, IntPtr menu, IntPtr inst, IntPtr param);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool DestroyWindow(IntPtr h);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool EnableWindow(IntPtr h, bool enable);
    const int WS_VISIBLE = 0x10000000, WS_CAPTION = 0x00C00000, WS_EX_TOPMOST = 0x8;
    static int fails = 0;
    static void Ok(string name, bool cond, string info = "")
    {
        if (!cond) fails++;
        Console.WriteLine((cond ? "PASS " : "FAIL ") + name + (info.Length > 0 ? " | " + info : ""));
    }

    public static int Main()
    {
        var root = Path.Combine(Path.GetTempPath(), "radar_selftest_" + Guid.NewGuid().ToString("N").Substring(0, 8));
        RadarCore.Configure(root, 50);
        Ok("configure: root + capacity", RadarCore.Root == root && RadarCore.Capacity == 50);

        // 1. ring semantics: 60 records into capacity 50 -> 50 kept, 10 dropped, oldest kept is #11
        for (int i = 1; i <= 60; i++) RadarCore.Record("step " + i, "value=" + i);
        Ok("ring: keeps capacity", RadarCore.Count == 50, "count=" + RadarCore.Count);
        Ok("ring: counts dropped", RadarCore.Dropped == 10, "dropped=" + RadarCore.Dropped);
        var trail = RadarCore.Trail();
        Ok("ring: oldest kept is #11", trail.StartsWith("") && trail.Contains("| #11 |") && !trail.Contains("| #10 |"));
        Ok("ring: newest is #60", trail.TrimEnd('\n').EndsWith("value=60"));

        // 2. newline in detail does not break the one-line-per-entry trail
        RadarCore.Record("multi", "a\nb\r\nc");
        Ok("trail: newlines escaped", RadarCore.Trail().Split('\n').Length == 51, "lines=" + RadarCore.Trail().Split('\n').Length);

        // 3. the write-failure path: action entry recorded, write dies, recover dumps page data items
        RadarCore.Record("action:Enter Transfer", "Account=DE123;Amount=50,00");
        string exDetail = "Internal : Failed to perform step 2 in Write Stage 'Enter Amount' on page 'Enter Transfer' - Element not found";
        string data = "i_txt_Account=DE123\ni_txt_Amount=50,00\nflg_Window Ready=True\nexpr:Enter Amount/2=[i_txt_Amount] & \" EUR\"";
        string folder = RadarCore.Dump("RAD001 - Radar - Write Failure Demo", "Enter Transfer", "System Exception", exDetail, "Enter Amount", data, true);
        Ok("dump: returns a folder", !folder.StartsWith("ERROR") && Directory.Exists(folder), folder);
        var txtPath = Path.Combine(folder, "incident.txt");
        var jsPath = Path.Combine(folder, "incident.json");
        Ok("dump: incident.txt written", File.Exists(txtPath));
        Ok("dump: incident.json written", File.Exists(jsPath));
        var txt = File.Exists(txtPath) ? File.ReadAllText(txtPath) : "";
        Ok("txt: names the failing stage", txt.Contains("stage     : Enter Amount"));
        Ok("txt: carries the write input (the thing Errors Only loses)", txt.Contains("i_txt_Amount=50,00"));
        Ok("txt: carries the inline expression text", txt.Contains("expr:Enter Amount/2="));
        Ok("txt: carries the trail with action inputs", txt.Contains("action:Enter Transfer | Account=DE123"));
        Ok("txt: trail header counts", txt.Contains("50 kept, 12 dropped, capacity 50"));
        Ok("txt: env fingerprint line (culture, date pattern, decimal, os)", System.Text.RegularExpressions.Regex.IsMatch(txt, @"env       : culture [A-Za-z-]* \(ui [A-Za-z-]*\) date \S+ decimal .+ \| os "), txt.Split((char)10)[10]);
        Ok("json: env field", File.ReadAllText(jsPath).Contains("\"env\": \"culture "));
        bool win = Environment.OSVersion.Platform == PlatformID.Win32NT;
        Ok(win ? "txt: screenshot taken" : "txt: screenshot skipped with reason (not Windows)",
           win ? txt.Contains("screenshot: screenshot.png") && File.Exists(Path.Combine(folder, "screenshot.png"))
               : txt.Contains("screenshot: skipped (not Windows"));

        // 3b. environment snapshot: present, every section answered (value or reason), bounded in time, env.txt beside it
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var env = RadarCore.EnvSnapshot();
            sw.Stop();
            Ok("format 6: apps list has no instance tally, no windowless non-BP entry, no shell", !env.Text.Contains("most instances") && !System.Text.RegularExpressions.Regex.IsMatch(env.Text, @"\n  (cmd|powershell|conhost|notepad|bash|mono) pid") && !System.Text.RegularExpressions.Regex.IsMatch(env.Text, @"\n  (?!automate|automatec|appman)[^\n]*\(no main window\)"), env.Text);
            Ok("format 7: frames keep object, stage class, first outside frame; nested action calls collapsed",
               new BluePrism.AutomateProcessCore.clsProcess().RunAction(2) == "RadarSelfTest+Demo_API.Run_Frames\nBluePrism.AutomateProcessCore.Stages.CodeStage.Execute\n... (2 nested action calls)\nRadarSelfTest.Main\n",
               new BluePrism.AutomateProcessCore.clsProcess().RunAction(2));
            Ok("env: every section present", env.Text.Contains("session   : ") && env.Text.Contains("memory    : ") && env.Text.Contains("this proc : ") && env.Text.Contains("disk      : ")
                                             && env.Text.Contains("network   : ") && env.Text.Contains("clock     : ") && env.Text.Contains("apps      : ") && env.Text.Contains("event log : "), env.Text);
            Ok("env: bounded (< 8 s)", sw.ElapsedMilliseconds < 8000, sw.ElapsedMilliseconds + " ms");
            Ok("env: this process is described", env.Text.Contains(" pid " + System.Diagnostics.Process.GetCurrentProcess().Id + " working set "));
            Ok("env: fields carry session + processes", env.Field("session") != null && env.Field("processes") != null && env.Field("snapshot_ms") != null);
            Ok("env: non-Windows sections say why", win || (env.Text.Contains("memory    : unavailable") && env.Text.Contains("event log : unavailable")));
            Ok("dump: environment section in incident.txt", txt.Contains("--- environment at failure (also env.txt) ---") && txt.Contains("\nsession   : "));
            Ok("dump: env.txt written", File.Exists(Path.Combine(folder, "env.txt")) && File.ReadAllText(Path.Combine(folder, "env.txt")).Contains("snapshot  : took "));
            Ok("json: environment object", File.ReadAllText(jsPath).Contains("\"environment\": { ") && File.ReadAllText(jsPath).Contains("\"file\": \"env.txt\" }"));
        }

        // 4. json is parseable and round-trips the fields
        try
        {
            var ser = new JavaScriptSerializer();
            var obj = ser.DeserializeObject(File.ReadAllText(jsPath)) as System.Collections.Generic.Dictionary<string, object>;
            var ex = obj["exception"] as System.Collections.Generic.Dictionary<string, object>;
            var di = obj["data_items"] as System.Collections.Generic.Dictionary<string, object>;
            var tr = obj["trail"] as object[];
            Ok("json: parses", obj != null);
            Ok("json: exception.stage", ex != null && (string)ex["stage"] == "Enter Amount");
            Ok("json: data_items keyed", di != null && (string)di["i_txt_Amount"] == "50,00" && (string)di["expr:Enter Amount/2"] == "[i_txt_Amount] & \" EUR\"");
            Ok("json: trail length", tr != null && tr.Length == 50, "len=" + (tr == null ? -1 : tr.Length));
            var envj = obj["environment"] as System.Collections.Generic.Dictionary<string, object>;
            Ok("json: environment parses with fields", envj != null && envj.ContainsKey("session") && envj.ContainsKey("processes"));
        }
        catch (Exception e) { Ok("json: parses", false, e.Message); }

        // 5. dump clears the ring; a second failure starts a fresh trail
        Ok("dump: ring cleared", RadarCore.Count == 0 && RadarCore.Dropped == 0);

        // 6. dump never throws: unwritable root -> ERROR string, no exception
        RadarCore.Configure(Path.Combine(txtPath, "not_a_dir"), 0);   // a file as parent -> CreateDirectory fails
        string bad = "threw";
        try { bad = RadarCore.Dump("p", "pg", "System Exception", "d", "s", "", false); } catch (Exception) { }
        Ok("dump: never throws, reports ERROR", bad.StartsWith("ERROR:"), bad);
        Ok("configure: zero capacity keeps previous", RadarCore.Capacity == 50);

        // 7b. two sessions (threads) on one resource never mix, and one dump leaves the other alone
        RadarCore.Configure(root, 50);
        RadarCore.Clear();
        string otherTrail = null; int otherCountAfter = -1;
        var gate = new System.Threading.ManualResetEvent(false);
        var t = new System.Threading.Thread(() =>
        {
            RadarCore.Record("other-session", "x");
            RadarCore.Record("other-session", "y");
            otherTrail = RadarCore.Trail();
            gate.WaitOne();                      // wait until the main session has dumped
            otherCountAfter = RadarCore.Count;
        });
        t.Start();
        while (otherTrail == null) System.Threading.Thread.Sleep(5);
        RadarCore.Record("main-session", "a");
        Ok("sessions: main sees only its own entry", RadarCore.Count == 1 && RadarCore.Trail().Contains("main-session") && !RadarCore.Trail().Contains("other-session"), RadarCore.Trail());
        Ok("sessions: other sees only its own two", otherTrail.Split('\n').Length == 3 && !otherTrail.Contains("main-session"), otherTrail);
        string f3 = RadarCore.Dump("p", "pg", "System Exception", "d", "s", "", false);
        gate.Set(); t.Join();
        Ok("sessions: main dump cleared main only", RadarCore.Count == 0 && otherCountAfter == 2, "other after=" + otherCountAfter);
        Ok("dump: folder is <root>/<machine>/<stamp>_<process>_<stage>", f3.StartsWith(Path.Combine(root, Environment.MachineName.Replace('-', '_'))) || Directory.GetParent(f3).Name.Length > 0, f3);
        Ok("dump: folder sits under the machine subfolder", Directory.GetParent(f3).Parent.FullName == root, f3);

        // 7c. the same exception dumped twice in a row (object, then the process logger) = one folder
        RadarCore.Configure(root, 50);
        RadarCore.Record("step", "before");
        string d1 = RadarCore.Dump("p", "pg", "System Exception", "same detail", "Same Stage", "", false);
        string d2 = RadarCore.Dump("p", "", "System Exception", "same detail", "Same Stage", "", false);
        Ok("dedupe: second dump of the same exception returns the first folder", d1 == d2 && Directory.Exists(d1), d1 + " / " + d2);
        string d2b = RadarCore.Dump("p", "", "System Exception", "same detail", "Calling Action Stage", "", false);
        Ok("dedupe: same detail reported at the PROCESS level (different stage) = same folder", d2b == d1, d2b);
        string d2c = RadarCore.Dump("p", "", "System Exception", "same detail", "Calling Action Stage", "", true);
        bool winShot = Environment.OSVersion.Platform == PlatformID.Win32NT;
        Ok("dedupe: a later dump asking for the screenshot adds it to the existing folder",
           d2c == d1 && (winShot ? File.Exists(Path.Combine(d1, "screenshot.png")) : File.ReadAllText(Path.Combine(d1, "incident.txt")).Contains("skipped (not Windows")), d2c);
        string d3 = RadarCore.Dump("p", "", "System Exception", "other detail", "Same Stage", "", false);
        Ok("dedupe: a different exception gets its own folder", d3 != d1 && Directory.Exists(d3));

        // 7. no-screenshot request is noted, and dump works with empty data/trail
        RadarCore.Configure(root, 5);
        string f2 = RadarCore.Dump("p", "pg", "Business Exception", "d", "s", "", false);
        Ok("dump: empty trail + no capture ok", Directory.Exists(f2) && File.ReadAllText(Path.Combine(f2, "incident.txt")).Contains("skipped (not requested)"));
        Ok("configure: shrink trims ring", RadarCore.Capacity == 5);

        // ---- the runtime hook (live only on .NET Framework; mono never raises FirstChanceException) ----
        RadarCore.Configure(root, 50);
        Ok("hook: status readable", RadarCore.HookStatus.Length > 0, RadarCore.HookStatus);
        if (!RadarCore.HookLive)
        {
            Console.WriteLine("SKIP hook checks: " + RadarCore.HookStatus);
        }
        else
        {
            RadarCore.Clear(); RadarCore.Configure(root, 50);
            RadarCore.Record("action:Parse", "start");
            try { new Demo_API().Run_JSON_To_Customer(); } catch (ArgumentException) { }
            try { new PersistentConnection().CommsThread(); } catch (System.Net.Sockets.SocketException) { }
            var tr = RadarCore.Trail();
            Ok("hook: the code-stage throw is in the trail with object + stage", tr.Contains("throw:ArgumentException | Invalid JSON primitive: . | ") && tr.Contains("Demo_API.JSON To Customer"), tr);
            Ok("hook: the socket noise from the resource connection is ignored", !tr.Contains("SocketException"), tr);
            Ok("hook: counters", RadarCore.HookStatus.Contains("recorded 1"), RadarCore.HookStatus);
            var fh = RadarCore.Dump("p", "pg", "System Exception", "JSON To Customer: Invalid JSON primitive: .", "Get Customer Name", "", false);
            var th = File.ReadAllText(Path.Combine(fh, "incident.txt"));
            Ok("hook: dump lists the throw with its frames", th.Contains("System.ArgumentException: Invalid JSON primitive: .") && th.Contains("thrown in: ") && th.Contains("Demo_API.Run_JSON_To_Customer"), th);
            Ok("hook: throw-time screenshot attached on Windows / noted otherwise", th.Contains("at throw  : screenshot_at_throw.png") || th.Contains("at throw  : none"), th);
            Ok("hook: json carries throws", File.ReadAllText(Path.Combine(fh, "incident.json")).Contains("\"throws\": [\n    { \"at\""));
            Ok("hook: ring of throws cleared by the dump", !RadarCore.Trail().Contains("throw:"), RadarCore.Trail());
        }

        // ---- blank Type/Detail: Radar fills them from the hook's throws and dedupes on its own ----
        {
            RadarCore.Clear(); RadarCore.Configure(root, 50);
            var f0 = RadarCore.Dump("p", "pg", "", "", "", "", false);
            Ok("blank dump: no throw seen -> folder, header says so", Directory.Exists(f0) && File.ReadAllText(Path.Combine(f0, "incident.txt")).Contains("the hook saw no exception"));
            var fb = RadarCore.Dump("p", "pg", "", "", "", "", false);
            Ok("blank dump: nothing new thrown -> same incident folder", fb == f0, fb);
            System.Threading.Thread.Sleep(5);
            RadarCore.ThrowForTest("System.ArgumentException", "Invalid JSON primitive: .", "JSON To Customer");
            var fn = RadarCore.Dump("p", "pg", "", "", "", "", false);
            var tn = File.ReadAllText(Path.Combine(fn, "incident.txt"));
            Ok("blank dump: a new throw -> its own folder", fn != f0 && Directory.Exists(fn), fn);
            Ok("blank dump: header filled from the hook", tn.Contains("exception : System.ArgumentException") && tn.Contains("detail    : Invalid JSON primitive: .") && tn.Contains("stage     : JSON To Customer") && tn.Contains("taken from the last exception Radar's hook saw"), tn);
            var fn2 = RadarCore.Dump("p", "pg", "", "", "", "", false);
            Ok("blank dump: logger reporting it again -> same folder", fn2 == fn, fn2);
            RadarCore.ThrowForTest("System.ArgumentException", "Invalid JSON primitive: .", "Action Stage");   // BP rethrow at the Action level
            var fr = RadarCore.Dump("p", "pg", "", "", "", "", false);
            Ok("blank dump: the rethrow of the same exception -> same folder", fr == fn, fr);
            System.Threading.Thread.Sleep(5);
            RadarCore.ThrowForTest("System.InvalidOperationException", "Second, different failure", "Read Result");
            var fn3 = RadarCore.Dump("p", "pg", "", "", "", "", false);
            Ok("blank dump: a different failure inside 2 minutes -> new folder", fn3 != fn && File.ReadAllText(Path.Combine(fn3, "incident.txt")).Contains("Second, different failure"), fn3);
            var fp = RadarCore.Dump("p", "pg", "Business Exception", "passed in", "s", "", false);
            Ok("passed-in type/detail still win", fp != fn3 && !File.ReadAllText(Path.Combine(fp, "incident.txt")).Contains("not passed in"), fp);
        }

        // ---- the stage log and data chain layers ----
        Console.WriteLine("---- the stage log and data chain layers ----");
        {
            // flags off by default: Configure(root, cap) ran many times above, the handle probe never ran
            Ok("layers: off by default", RadarCore.HookStatus.Contains("stage log: off") && RadarCore.HookStatus.Contains("data chain: off"), RadarCore.HookStatus);
            Ok("layers: no probe while off", RadarCore.StageProbeCount == 0, "probes=" + RadarCore.StageProbeCount);

            // on, without Blue Prism: not available with a reason, dump still complete, arrays present and empty
            RadarCore.Clear();
            RadarCore.Configure(root, 50, true, true);
            var hs = RadarCore.HookStatus;
            Ok("layers: on without BP -> stage log not available (reason)", hs.Contains("stage log: not available (") && hs.Contains("AutomateProcessCore not loaded"), hs);
            Ok("layers: on without BP -> data chain not available (reason)", hs.Contains("data chain: not available ("), hs);
            Ok("layers: the probe ran once", RadarCore.StageProbeCount == 1, "probes=" + RadarCore.StageProbeCount);
            string fl = RadarCore.Dump("p", "pg", "System Exception", "layers off-runtime", "s", "a=1", false);
            Ok("layers: dump still writes a folder", !fl.StartsWith("ERROR") && File.Exists(Path.Combine(fl, "incident.txt")) && File.Exists(Path.Combine(fl, "env.txt")), fl);
            try
            {
                var o = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fl, "incident.json"))) as Dictionary<string, object>;
                var sl = o["stage_log"] as object[]; var dc = o["data_chain"] as object[];
                Ok("layers: json parses, stage_log and data_chain present and empty", sl != null && sl.Length == 0 && dc != null && dc.Length == 0 && o.ContainsKey("trail"));
            }
            catch (Exception e) { Ok("layers: json parses, stage_log and data_chain present and empty", false, e.Message); }
            var tl = File.ReadAllText(Path.Combine(fl, "incident.txt"));
            Ok("layers: txt sections present with status", tl.Contains("--- stage log (last 0 stages, oldest first;") && tl.Contains("---\nstatus: not available (") && tl.Contains("--- data chain at failure ---\nstatus: not available ("), tl);
            Ok("session: not available with the probe's reason", tl.Contains("--- session ---\nnot available (AutomateProcessCore not loaded") && tl.Contains("session   : not available ("), tl);
            Ok("exception path: section present and empty", tl.Contains("--- exception path (oldest first") && tl.Contains("resumed) ---\n(none)\n"), tl);

            // the handle route: forms' event handlers -> runner -> listener -> record whose thread is this one
            {
                var view = new FakeView(); var runner = new FakeRunner(view);
                runner._mListener.mList.Add(new FakeRecord { mRunnerThread = new System.Threading.Thread(() => { }) });
                var mine = new FakeRecord { mRunnerThread = System.Threading.Thread.CurrentThread };
                runner._mListener.mList.Add(mine);
                var allowed = new List<System.Reflection.Assembly> { typeof(RadarSelfTest).Assembly };
                int scanned;
                var hit = RadarCore.FindReachable(new object[] { view }, o => o is FakeRecord && ((FakeRecord)o).mRunnerThread == System.Threading.Thread.CurrentThread, allowed, 7, out scanned);
                Ok("handle route: view event -> runner -> listener -> this thread's record", ReferenceEquals(hit, mine), "scanned=" + scanned);
                var none = RadarCore.FindReachable(new object[] { view }, o => o is FakeRecord && ((FakeRecord)o).mRunnerThread == null, allowed, 7, out scanned);
                Ok("handle route: no match -> null, bounded", none == null && scanned < 50, "scanned=" + scanned);
                var shallow = RadarCore.FindReachable(new object[] { view }, o => ReferenceEquals(o, mine), allowed, 3, out scanned);
                Ok("handle route: depth limit respected", shallow == null);
            }

            // the Emit path against the stand-in abstract class
            string err;
            var ft = RadarCore.BuildStageForwarder(typeof(FakeLoggingEngine), out err);
            Ok("emit: subclass built", ft != null && ft.BaseType == typeof(FakeLoggingEngine) && !ft.IsAbstract, err ?? "");
            var eng = RadarCore.CreateStageForwarder(typeof(FakeLoggingEngine), null, out err) as FakeLoggingEngine;
            Ok("emit: instance created without a constructor", eng != null, err ?? "");
            if (eng != null)
            {
                var proc = new FakeProcess { Name = "PRC000 - Radar - Demo" };
                var obj = new FakeProcess { Name = "Radar Demo Bank" };
                Guid main = Guid.NewGuid(), pay = Guid.NewGuid(), enter = Guid.NewGuid();
                var mainStart = St(proc, main, "Main Page", "Start", "Start");
                var payStart = St(proc, pay, "Pay", "Start", "Start");
                var payEnd = St(proc, pay, "Pay", "End", "End");
                var act = St(proc, pay, "Pay", "Enter Transfer", "Action");
                var objStart = St(obj, enter, "Enter Transfer", "Start", "Start");
                var objEnd = St(obj, enter, "Enter Transfer", "End", "End");
                var code = St(obj, enter, "Enter Transfer", "Format Amount", "Code");
                var calc = St(obj, enter, "Enter Transfer", "Calc Total", "Calculation");
                proc.All.Add(new DataStage { Name = "Item Count", StageType = "Data", Page = main, Process = proc, Value = new FakeValue { DataType = "number", FormattedValue = "3" } });
                proc.All.Add(new DataStage { Name = "Account", StageType = "Data", Page = pay, Process = proc, Value = new FakeValue { FormattedValue = "RO49AAAA1B31007593840000" } });
                proc.All.Add(new DataStage { Name = "Login Password", StageType = "Data", Page = pay, Process = proc, Value = new FakeValue { DataType = "password", FormattedValue = "hunter2" } });
                var coll = new FakeCollection();
                for (int i = 0; i < 7; i++) coll.Rows.Add(new Dictionary<string, FakeValue> { { "Id", new FakeValue { FormattedValue = "R" + i } } });
                obj.All.Add(new CollectionStage { Name = "Rows", StageType = "Collection", Page = enter, Process = obj, CurrentCollection = coll });
                obj.All.Add(new DataStage { Name = "Amount", StageType = "Data", Page = enter, Process = obj, Value = new FakeValue { FormattedValue = "50,00" } });

                RadarCore.Clear();
                RadarCore.Configure(root, 50, true, true);        // still no BP: reason set until the first event arrives
                FakeLoggingEngine b = eng;                        // every call goes through the abstract base type
                b.ProcessPrologue(null, mainStart, Args("Batch", "7"));
                b.SubSheetPrologue(null, payStart, Args());
                b.ActionPrologue(null, act, "Radar Demo Bank", "Enter Transfer",
                                 Args("IBAN", "RO49AAAA1B31007593840000", "CNP", "1850101123451", "PAN", "4111111111111111",
                                      "Ref13", "0000000000017", "Short", "12345", "Password", "s3cret", "Html", "<b>&amp;</b>"));
                b.ObjectPrologue(null, objStart, "Radar Demo Bank", "Enter Transfer", Args());
                b.CodePrologue(null, calc, Args());
                b.CalculationEpilogue(null, calc, new FakeValue { FormattedValue = "150" });
                b.CodePrologue(new FakeInfo(), code, Args("Amount", "50,00"));
                b.LogError(null, code, "Format failed");
                b.LogStatistic(Guid.Empty, "stat", new FakeValue { FormattedValue = "1" });
                Ok("emit: abstract property returns default", b.Pending == 0);

                var hs2 = RadarCore.HookStatus;
                Ok("stage log: live after the first event", hs2.Contains("stage log: live (") && hs2.Contains(" stages)"), hs2);
                Ok("data chain: live with depth 4", hs2.Contains("data chain: live (depth 4)"), hs2);

                string fd = RadarCore.Dump("PRC000 - Radar - Demo", "Pay", "System Exception", "Format failed", "Format Amount", "", false);
                var t2 = File.ReadAllText(Path.Combine(fd, "incident.txt"));
                Ok("stage log: method + stage name in incident.txt", t2.Contains("| Enter Transfer (Action) | ActionPrologue | Radar Demo Bank.Enter Transfer"), t2);
                Ok("stage log: error attached to the open stage", t2.Contains("Format Amount (Code) | CodePrologue") && t2.Contains("result: ERROR: Format failed"), t2);
                Ok("stage log: epilogue closes the calculation with its result", t2.Contains("Calc Total (Calculation) | CodePrologue | result: 150"), t2);
                Ok("timing: closed rows carry a duration", System.Text.RegularExpressions.Regex.IsMatch(t2, @"-> [0-9:.]+ [0-9]+\.[0-9]{3} s \| #\d+ \| Radar Demo Bank \| Enter Transfer \| Calc Total"), t2);
                Ok("timing: open rows carry none", t2.Contains("-> (open) | #") && !t2.Contains("(open) 0."), t2);
                Ok("memory: LogInfo working sets on the row", t2.Contains("Format Amount (Code) | CodePrologue") && t2.Contains("| mem 123456789 / 987654321"), t2);
                Ok("exception path: LogError is where it was thrown", t2.Contains("| LogError | Radar Demo Bank / Enter Transfer / Format Amount | ERROR: Format failed"), t2);
                Ok("format 1: parameters as in: name=value; unescaped", t2.Contains(" | in: IBAN=RO49****; CNP=[CNP masked]; PAN=[PAN ****1111]; Ref13=0000000000017; Short=12345; Password=***; Html=<b>&amp;</b>") && !t2.Contains("<parameters>"), t2);
                Ok("mask: IBAN", t2.Contains("IBAN=RO49****") && !t2.Contains("RO49AAAA1B31007593840000"));
                Ok("mask: CNP", t2.Contains("CNP=[CNP masked]") && !t2.Contains("1850101123451"));
                Ok("mask: Luhn PAN", t2.Contains("PAN=[PAN ****1111]") && !t2.Contains("4111111111111111"));
                Ok("mask: 13-digit non-CNP left alone", t2.Contains("Ref13=0000000000017"));
                Ok("mask: short number left alone", t2.Contains("Short=12345"));
                Ok("mask: password-named parameter", t2.Contains("Password=***") && !t2.Contains("s3cret"));
                Ok("mask: credential tokens", RadarCore.Mask("Automate.exe /user bob pw1 /password=xyz") == "Automate.exe /user bob *** /password=***", RadarCore.Mask("Automate.exe /user bob pw1 /password=xyz"));

                // the chain, outermost first: Main -> Pay -> Enter Transfer action -> object page -> current code stage
                int iMain = t2.IndexOf("PRC000 - Radar - Demo / Main Page / Start (Process)");
                int iPay = t2.IndexOf("PRC000 - Radar - Demo / Pay / Start (SubSheet)");
                int iAct = t2.IndexOf("PRC000 - Radar - Demo / Pay / Enter Transfer (Action)  [same page as above]");
                int iObj = t2.IndexOf("Radar Demo Bank / Enter Transfer / Start (Object)");
                int iCur = t2.IndexOf("Radar Demo Bank / Enter Transfer / Format Amount (Code)  [same page as above]");
                Ok("chain: outermost first in incident.txt", iMain > 0 && iMain < iPay && iPay < iAct && iAct < iObj && iObj < iCur, iMain + "," + iPay + "," + iAct + "," + iObj + "," + iCur);
                Ok("chain: page data items read, masked, password not read", t2.Contains("    Item Count=3\n") && t2.Contains("    Account=RO49****\n") && t2.Contains("    Login Password=***\n") && !t2.Contains("hunter2"), t2);
                Ok("chain: collection = row count + first 5 rows", t2.Contains("    Rows=rows=7 [Id=R0] [Id=R1] [Id=R2] [Id=R3] [Id=R4] ...\n") && t2.Contains("    Amount=50,00\n"), t2);

                try
                {
                    var o = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fd, "incident.json"))) as Dictionary<string, object>;
                    var dc = o["data_chain"] as object[]; var sl = o["stage_log"] as object[];
                    var f0 = dc[0] as Dictionary<string, object>; var f4 = dc[dc.Length - 1] as Dictionary<string, object>;
                    var it = f0["items"] as Dictionary<string, object>;
                    Ok("chain: json outermost first", dc.Length == 5 && (string)f0["page"] == "Main Page" && (string)f4["stage"] == "Format Amount" && (string)it["Item Count"] == "3");
                    Ok("stage log: json array", sl != null && sl.Length >= 7 && sl[0] is Dictionary<string, object> && ((Dictionary<string, object>)sl[0]).ContainsKey("in"));
                    var ep = o["exception_path"] as object[]; var se = o["session"] as Dictionary<string, object>;
                    Ok("json: exception_path + session objects", ep != null && ep.Length == 1 && (string)((Dictionary<string, object>)ep[0])["method"] == "LogError" && se != null);
                    bool msOk = false; foreach (var row in sl) { var d = (Dictionary<string, object>)row; if (d.ContainsKey("ms") && d["ms"] != null && d.ContainsKey("mem_automate")) msOk = true; }
                    Ok("json: ms + mem fields on rows", msOk);
                }
                catch (Exception e) { Ok("chain: json outermost first", false, e.Message); }

                // pop: the object action ends, then the action stage -> back to Main/Pay
                b.ObjectEpilogue(null, objEnd, "Radar Demo Bank", "Enter Transfer", Args());
                Ok("chain: object epilogue pops to depth 3", RadarCore.ChainDepth == 3, "depth=" + RadarCore.ChainDepth);
                b.ActionEpilogue(null, act, "Radar Demo Bank", "Enter Transfer", Args("Done", "True"));
                b.SubSheetEpilogue(null, payEnd, Args());
                Ok("chain: back to the main page", RadarCore.ChainDepth == 1, "depth=" + RadarCore.ChainDepth);

                // bounds: 1000 stage events keep the ring at capacity, with a dropped count
                for (int i = 0; i < 1000; i++) { b.CodePrologue(null, code, Args("i", i.ToString())); b.CodeEpilogue(null, code, Args(), Args()); }
                Ok("bounds: stage log at Configure capacity 50", RadarCore.StageLogCount == 50 && RadarCore.StageCapacity == 50, "count=" + RadarCore.StageLogCount + " cap=" + RadarCore.StageCapacity);
                Ok("bounds: dropped counted", RadarCore.StageLogDropped >= 950, "dropped=" + RadarCore.StageLogDropped);
                RadarCore.Configure(root, 2000, true, true);
                for (int i = 0; i < 1500; i++) { b.CodePrologue(null, code, Args("i", i.ToString())); b.CodeEpilogue(null, code, Args(), Args()); }
                Ok("bounds: bigger Configure capacity grows the stage log", RadarCore.StageCapacity == 2000 && RadarCore.StageLogCount > 1000, "count=" + RadarCore.StageLogCount);
                RadarCore.Configure(root, 0, true, true);
                Ok("bounds: zero capacity keeps the stage log capacity", RadarCore.StageCapacity == 2000);
                RadarCore.Configure(root, 100, true, true);
                Ok("bounds: smaller Configure capacity trims the stage log", RadarCore.StageLogCount == 100, "count=" + RadarCore.StageLogCount);
                RadarCore.Configure(root, 50, true, true);

                // Recover on Pay: the action, the object page and its code stage were unwound without Epilogues
                RadarCore.Clear();
                RadarCore.Configure(root, 50, true, true);
                b.ProcessPrologue(null, mainStart, Args());
                b.SubSheetPrologue(null, payStart, Args());
                b.ActionPrologue(null, act, "Radar Demo Bank", "Enter Transfer", Args());
                b.ObjectPrologue(null, objStart, "Radar Demo Bank", "Enter Transfer", Args());
                b.CodePrologue(null, code, Args());
                b.LogError(null, code, "Format failed");
                var rec = St(proc, pay, "Pay", "Recover", "Recover");
                b.RecoverPrologue(null, rec);
                Ok("unwind: chain back to the recovering page", RadarCore.HookStatus.Contains("data chain: live (depth 2)"), RadarCore.HookStatus);
                // a hidden (Radar) object's stages stay out of the log
                var radar = new FakeProcess { Name = "Radar" }; Guid rpg = Guid.NewGuid();
                var rStart = St(radar, rpg, "Dump Incident", "Start", "Start");
                b.ObjectPrologue(null, rStart, "Radar", "Dump Incident", Args("Process", "x"));
                var logObj = new FakeProcess { Name = "Utility - Logging" }; Guid lpg = Guid.NewGuid();
                b.ObjectPrologue(null, St(logObj, lpg, "Write Log", "Start", "Start"), "Utility - Logging", "Write Log", Args("Message", "x"));
                string fu = RadarCore.Dump("PRC000 - Radar - Unwind", "Pay", "System Exception", "Format failed", "Recover", "", false);
                var t3 = File.ReadAllText(Path.Combine(fu, "incident.txt"));
                Ok("unwind: action row closed as unwound", System.Text.RegularExpressions.Regex.IsMatch(t3, @"-> [0-9:.]+ \(unwound\) [0-9.]+ s \| #\d+ \| PRC000 - Radar - Demo \| Pay \| Enter Transfer \(Action\)"), t3);
                Ok("unwind: no open rows below the recover", !System.Text.RegularExpressions.Regex.IsMatch(t3, @"\(open\) \| #\d+ \| [^|]+\| [^|]+\| (Enter Transfer \(Action\)|Start \(Start\) \| ObjectPrologue|Format Amount)"), t3);
                Ok("unwind: object frame gone from the chain", !t3.Contains("Radar Demo Bank / Enter Transfer / Start (Object)") && t3.Contains("PRC000 - Radar - Demo / Pay / Start (SubSheet)"), t3);
                Ok("format 2: logging object's stage hidden, counted apart", !t3.Contains("| Utility - Logging |") && t3.Contains("logging object 1)") && !t3.Contains("Utility - Logging / Write Log"), t3);
                Ok("format 3: no LogInfo in this log -> no mem on rows, one status note", !t3.Contains("| mem ") && t3.Contains("; memory per stage: not available") && !t3.Contains("mem = Automate") && System.Text.RegularExpressions.Regex.IsMatch(t3, @"[0-9]+\.[0-9]{3} s \| #"), t3);
                Ok("format 4: data items section points at the live chain", t3.Contains("--- data items at failure ---\n(see data chain; Data Items input ignored)\n"), t3);
                Ok("format 5: trail section points at the live stage log", t3.Contains("--- trail ---\n(see stage log; ") && t3.Contains(" ring entries dropped)\n") && !t3.Contains("--- trail (oldest first"), t3);
                Ok("format 8: header counts stages in log and hidden", System.Text.RegularExpressions.Regex.IsMatch(t3, @"\nsession   : [^\n]*\nstages    : \d+ in log, 2 hidden\n"), t3);
                Ok("hide: Radar's own stage not logged, counted", !t3.Contains("| Radar | Dump Incident | Start") && t3.Contains("hidden 2 (Radar 1, logging object 1)") && !t3.Contains("Radar / Dump Incident / Start (Object)"), t3);
                try
                {
                    var o3 = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fu, "incident.json"))) as Dictionary<string, object>;
                    { var sl3 = o3["stage_log"] as object[]; bool noMem = sl3 != null && sl3.Length > 0, ms3 = false; foreach (var row in sl3) { var d = (Dictionary<string, object>)row; if (d.ContainsKey("mem_automate")) noMem = false; if (d["ms"] != null) ms3 = true; }
                      Ok("format 3: json drops mem fields, keeps ms, says memory_per_stage false", noMem && ms3 && o3["memory_per_stage"].Equals(false) && ((Dictionary<string, object>)o3["stage_log_hidden"])["logging_object"].Equals(1)); }
                    Ok("unwind: json has unwound flag", File.ReadAllText(Path.Combine(fu, "incident.json")).Contains("\"unwound\": true") && o3 != null);
                }
                catch (Exception e) { Ok("unwind: json has unwound flag", false, e.Message); }

                // exception path + recovery state + element lookup: thrown in a Write stage, rethrown by an Exception stage, caught, resumed
                RadarCore.Clear();
                RadarCore.Configure(root, 50, true, true);
                var el = Guid.NewGuid(); obj._applicationDefinition.Els[el] = new FakeElement { Name = "Amount", FullPath = "Main Window/Transfer/Amount", Type = new FakeType { Name = "Win32 Edit" },
                    ActiveAttributes = { new FakeAttr { Name = "Name", Value = "Amount" }, new FakeAttr { Name = "Class", Value = "Edit" }, new FakeAttr { Name = "Match Index", Value = "1", Dynamic = true }, new FakeAttr { Name = "Text", Value = "RO49AAAA1B31007593840000", InUse = false } } };
                var write = new AppStage { Name = "Enter Amount", StageType = "Write", SubSheet = new FakeSubSheet { Name = "Enter Transfer" }, Process = obj, Page = enter };
                write.Steps.Add(new FakeStep { ElementId = el, ActionName = "Set Text", Parameters = { new FakeParam { Name = "Index", Expression = "1" } } }); obj.All.Add(write);
                var wait = new AppStage { Name = "Wait Amount", StageType = "WaitStart", SubSheet = new FakeSubSheet { Name = "Enter Transfer" }, Process = obj, Page = enter }; wait.Used.Add(el); obj.All.Add(wait);
                var exs = new ExceptionStage { Name = "Rethrow", StageType = "Exception", SubSheet = new FakeSubSheet { Name = "Enter Transfer" }, Process = obj, Page = enter, UseCurrentException = true, SaveScreenCapture = true };
                var exn = new ExceptionStage { Name = "Give Up", StageType = "Exception", SubSheet = new FakeSubSheet { Name = "Pay" }, Process = proc, Page = pay, ExceptionType = "System Exception", ExceptionDetail = "Transfer failed for IBAN RO49AAAA1B31007593840000" };
                var rec2 = new RecoverStage { Name = "Recover", StageType = "Recover", SubSheet = new FakeSubSheet { Name = "Pay" }, Process = proc, Page = pay, Attempts = 2, MaxAttempts = 3, LimitAttempts = true };
                proc.All.Add(rec2);
                var resume = St(proc, pay, "Pay", "Resume", "Resume");
                obj.ExceptionSource = write.Id; proc.RecoverySource = rec2.Id; proc.RecoveryType = "System Exception"; proc.RecoveryDetail = "Element not found"; proc.RecoveryMode = true;
                b.ProcessPrologue(null, mainStart, Args());
                b.SubSheetPrologue(null, payStart, Args());
                b.ActionPrologue(null, act, "Radar Demo Bank", "Enter Transfer", Args());
                b.ObjectPrologue(null, objStart, "Radar Demo Bank", "Enter Transfer", Args());
                b.WritePrologue(null, write, Args());
                b.LogError(null, write, "Element not found");
                b.ExceptionPrologue(null, exs);
                // first dump from the object's own Recover-less failure: the object frame and the write stage are still open
                string fw = RadarCore.Dump("PRC000 - Radar - Demo", "Pay", "System Exception", "Element not found", "Enter Amount", "", false);
                var tw = File.ReadAllText(Path.Combine(fw, "incident.txt"));
                Ok("recovery: the object frame names the stage that raised", tw.Contains("[recovery] exception source Enter Amount (" + write.Id + ")"), tw);
                Ok("elements: the open write stage is in the chain and lists its element, resolved with attributes",
                   tw.Contains("Radar Demo Bank / Enter Transfer / Enter Amount (Write)  [same page as above]\n    [elements] steps 1; timeout 30; step 1 Set Text element " + el + " 'Main Window/Transfer/Amount' (Win32 Edit) [Name=Amount; Class=Edit; Match Index~1] params {Index=1}"), tw);
                Ok("attribute not in use is skipped (its IBAN never printed)", !tw.Contains("RO49AAAA") && !tw.Contains("Text="));
                Ok("wait stage lists GetElementsUsed with the resolved element", RadarCore.ElementsText(wait, obj) == "steps 0; timeout 30; element " + el + " 'Main Window/Transfer/Amount' (Win32 Edit) [Name=Amount; Class=Edit; Match Index~1]", RadarCore.ElementsText(wait, obj) ?? "null");
                Ok("elements: the current (exception) stage follows it", tw.IndexOf("Enter Amount (Write)") < tw.IndexOf("Rethrow (Exception)"), tw);
                Ok("elements: non-app frames carry none", !System.Text.RegularExpressions.Regex.IsMatch(tw, @"Start \(Process\)\n    \[elements\]"), tw);
                try
                {
                    var ow = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fw, "incident.json"))) as Dictionary<string, object>;
                    var dcw = ow["data_chain"] as object[];
                    bool elOk = false, rcOk = false; foreach (var fr in dcw) { var d = (Dictionary<string, object>)fr; if (d["elements"] != null && ((string)d["elements"]).Contains("Main Window/Transfer/Amount")) elOk = true; if (d["recovery"] != null && ((string)d["recovery"]).Contains("exception source")) rcOk = true; }
                    Ok("json: chain frames carry elements + recovery", elOk && rcOk);
                }
                catch (Exception e) { Ok("json: chain frames carry elements + recovery", false, e.Message); }
                b.RecoverPrologue(null, rec2);
                b.ResumePrologue(null, resume);
                b.ExceptionPrologue(null, exn);
                string fe = RadarCore.Dump("PRC000 - Radar - Demo", "Pay", "System Exception", "Transfer failed", "Give Up", "", false);
                var t4 = File.ReadAllText(Path.Combine(fe, "incident.txt"));
                int pThrown = t4.IndexOf("| LogError | Radar Demo Bank / Enter Transfer / Enter Amount | ERROR: Element not found");
                int pRethrow = t4.IndexOf("| ExceptionPrologue | Radar Demo Bank / Enter Transfer / Rethrow | rethrow (current exception) (save screen capture)");
                int pCaught = t4.IndexOf("| RecoverPrologue | PRC000 - Radar - Demo / Pay / Recover | caught; attempts 2/3 (limited)");
                int pResumed = t4.IndexOf("| ResumePrologue | PRC000 - Radar - Demo / Pay / Resume | resumed");
                int pNew = t4.IndexOf("| ExceptionPrologue | PRC000 - Radar - Demo / Pay / Give Up | new exception type=System Exception detail=Transfer failed for IBAN RO49****");
                Ok("exception path: thrown -> rethrow -> caught -> resumed -> new, in order, masked", pThrown > 0 && pThrown < pRethrow && pRethrow < pCaught && pCaught < pResumed && pResumed < pNew && !t4.Contains("RO49AAAA1B31007593840000"), t4);
                Ok("recovery: the process frame reports its recovery state", t4.Contains("[recovery] recovery source Recover (" + rec2.Id + "); recovery type System Exception; detail Element not found; recovery mode True"), t4);
                var chain4 = t4.Substring(t4.IndexOf("--- data chain at failure ---"));
                Ok("unwind: after the Recover the object frame and the write stage are gone from the chain", !chain4.Contains("(Write)") && !chain4.Contains("exception source") && chain4.Contains("[recovery] recovery source Recover ("), chain4);
                try
                {
                    var o4 = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fe, "incident.json"))) as Dictionary<string, object>;
                    var ep4 = o4["exception_path"] as object[];
                    Ok("json: exception_path has 5 events", ep4 != null && ep4.Length == 5);
                }
                catch (Exception e) { Ok("json: exception_path has 5 events", false, e.Message); }

                // off again: the forwarder stays attached but nothing of the layer runs
                RadarCore.Configure(root, 50, false, false);
                long before = RadarCore.StageLogCount;
                b.CodePrologue(null, code, Args());
                Ok("layers: flag off -> events ignored", RadarCore.StageLogCount == before && RadarCore.HookStatus.Contains("stage log: off"), RadarCore.HookStatus);
            }
            RadarCore.Clear();
        }

        // ---- v25 context layers: work-queue item, good-run baseline, slowest stages, network paths ----
        Console.WriteLine("---- context layers ----");
        {
            RadarCore.Clear(); RadarCore.Configure(root, 50, true, true); RadarCore.StageLogOnForTest();
            var gni = new FakeStage { Name = "Get Next Item", StageType = "Action" };
            var dec = new FakeStage { Name = "Account Found?", StageType = "Decision" };
            var rd = new FakeStage { Name = "Read Result", StageType = "Read" };
            var popup = new FakeStage { Name = "Handle Popup", StageType = "Navigate" };
            const string P = "Payments In Process";
            Action<string> item = key =>
            {
                RadarCore.ContextForTest("ActionPrologue", "Action", "Work Queues", "Get Next Item", gni, gni.Name, gni.StageType, "Main Page", P, null,
                    "<parameters><p name=\"Queue Name\" type=\"text\" value=\"Payments In\"/></parameters>");
                RadarCore.ContextForTest("ActionEpilogue", "Action", "Work Queues", "Get Next Item", gni, gni.Name, gni.StageType, "Main Page", P, null,
                    "<parameters><p name=\"Item ID\" type=\"text\" value=\"4f1c\"/><p name=\"Item Key\" type=\"text\" value=\"" + key + "\"/><p name=\"Data\" type=\"collection\" value=\"rows=1 [IBAN=DE89****]\"/></parameters>");
            };
            Action<FakeStage, string> run = (st, outcome) =>
            {
                RadarCore.ContextForTest(st.StageType + "Prologue", st.StageType, null, null, st, st.Name, st.StageType, "Work", P, null, null);
                RadarCore.ContextForTest(st.StageType + "Epilogue", st.StageType, null, null, st, st.Name, st.StageType, "Work", P, outcome, null);
            };
            // no baseline yet
            item("K-0"); run(dec, "True");
            var f0 = RadarCore.Dump(P, "Work", "System Exception", "first", "Read Result", "", false);
            var t0 = File.ReadAllText(Path.Combine(f0, "incident.txt"));
            Ok("item: incident names the queue item", t0.Contains("--- work-queue item ---") && t0.Contains("Item Key=K-0") && t0.Contains("Queue Name=Payments In"), t0);
            Ok("baseline: none yet -> says how to start one", t0.Contains("no baseline yet: call Radar's Mark Run OK"));
            Ok("slowest: section present", t0.Contains("--- slowest stages (stage log) ---"));
            // six good runs, three items each, the Decision always True
            for (int r = 0; r < 6; r++)
            {
                for (int i = 0; i < 3; i++) { item("K-" + r + i); run(dec, "True"); run(rd, null); RadarCore.ContextForTest("ActionEpilogue", "Action", "Work Queues", "Mark Completed", gni, gni.Name, "Action", "Main Page", P, null, null); }
                var ok = RadarCore.MarkRunOk();
                if (r == 0) Ok("mark run ok: writes the baseline", ok.StartsWith("ok: ") && Directory.GetFiles(Path.Combine(Path.Combine(root, "_baselines"), P.Replace(' ', '_')), "*.txt").Length == 1, ok + " | " + string.Join(",", Directory.GetDirectories(Path.Combine(root, "_baselines"))));
                if (r == 5) Ok("mark run ok: counts runs", ok.Contains("6 good runs"), ok);
            }
            // a failing item: the Decision goes False for the first time, a stage no good run used
            item("K-FAIL"); run(dec, "False"); run(popup, null);
            RadarCore.ContextForTest("ActionEpilogue", "Action", "Work Queues", "Mark Exception", gni, gni.Name, "Action", "Main Page", P, null, null);
            var f1 = RadarCore.Dump(P, "Work", "System Exception", "second", "Handle Popup", "Out Folder=\\\\radar-nohost-test\\share\\in", false);
            var t1 = File.ReadAllText(Path.Combine(f1, "incident.txt"));
            Ok("item: the failing item, marked", t1.Contains("Item Key=K-FAIL") && t1.Contains("Mark Exception at"), t1);
            Ok("baseline: compared with 6 good runs", t1.Contains("compared with 6 good run(s) on 1 machine(s)"), t1);
            Ok("baseline: unusual decision outcome", t1.Contains("decision    \"Work / Account Found?\" went False; good runs: True 100% (18 times)"), t1);
            Ok("baseline: first-time stage", t1.Contains("first time  \"Work / Handle Popup\" never ran in a good run"), t1);
            Ok("baseline: usual stage not flagged", !t1.Contains("\"Work / Read Result\""), t1);
            Ok("net paths: dead share reported", t1.Contains("--- network paths in the data ---") && t1.Contains("[!!] \\\\radar-nohost-test\\share\\in"), t1);
            Ok("json: queue item + compare", File.ReadAllText(Path.Combine(f1, "incident.json")).Contains("\"queue_item\"") && File.ReadAllText(Path.Combine(f1, "incident.json")).Contains("\"compared_with_good_runs\""));
            // the failed item never reaches the baseline
            item("K-NEXT"); run(dec, "True");
            RadarCore.MarkRunOk();
            item("K-FAIL2"); run(dec, "False");
            var fx2 = RadarCore.Dump(P, "Work", "System Exception", "third", "x", "", false);
            Ok("baseline: a dumped item is not learned as good", File.ReadAllText(Path.Combine(fx2, "incident.txt")).Contains("went False; good runs: True 100%"));
            // a new release: most stages unknown -> baseline restarts
            var n1 = new FakeStage { Name = "New A", StageType = "Calculation" }; var n2 = new FakeStage { Name = "New B", StageType = "Calculation" }; var n3 = new FakeStage { Name = "New C", StageType = "Calculation" };
            run(n1, null); run(n2, null); run(n3, null);
            var rel = RadarCore.MarkRunOk();
            Ok("baseline: new release restarts it", rel.Contains("baseline started again") && rel.Contains("1 good runs"), rel);
            // compact baseline file: one typical duration per stage, no sample lists
            {
                var bf = Directory.GetFiles(Path.Combine(Path.Combine(root, "_baselines"), P.Replace(' ', '_')), "*.txt")[0];
                bool compact = true; foreach (var l in File.ReadAllLines(bf)) if (l.StartsWith("S\t") && !System.Text.RegularExpressions.Regex.IsMatch(l.Split('\t')[8], @"^\d+:\d+$")) compact = false;
                Ok("baseline file: typical:samples per stage", compact, File.ReadAllText(bf));
            }
            // Wait stages: timeout shown, TIMED OUT when the wait ran its whole timeout
            {
                var w1 = new FakeWait { Name = "Wait For Window", StageType = "WaitStart", Timeout = 30, SubSheet = new FakeSubSheet { Name = "Work" }, Process = new FakeProcess { Name = P } };
                var w2 = new FakeWait { Name = "Wait For Result", StageType = "WaitStart", Timeout = 0.3, SubSheet = new FakeSubSheet { Name = "Work" }, Process = new FakeProcess { Name = P } };
                RadarCore.OnStageEvent("WaitStartPrologue", new object[] { null, w1 }); RadarCore.OnStageEvent("WaitStartEpilogue", new object[] { null, w1 });
                RadarCore.OnStageEvent("WaitStartPrologue", new object[] { null, w2 }); System.Threading.Thread.Sleep(350); RadarCore.OnStageEvent("WaitStartEpilogue", new object[] { null, w2 });
                var fw = RadarCore.Dump(P, "Work", "System Exception", "wait", "Wait For Result", "", false);
                var tw = File.ReadAllText(Path.Combine(fw, "incident.txt"));
                Ok("wait: timeout shown, not timed out", tw.Contains("Wait For Window (WaitStart)") && System.Text.RegularExpressions.Regex.IsMatch(tw, @"\(timeout 30 s\) \| #\d+ \| " + P + @" \| Work \| Wait For Window"), tw);
                Ok("wait: TIMED OUT when it ran its whole timeout", tw.Contains("(timeout 0.3 s, TIMED OUT) | #"), tw);
                Ok("wait: slowest section carries it", tw.Contains("Work / Wait For Result (WaitStart)(timeout 0.3 s, TIMED OUT)") || tw.Contains("Wait For Result (WaitStart) (timeout 0.3 s, TIMED OUT)") || tw.Contains("Wait For Result (WaitStart)(timeout"), tw.Substring(tw.IndexOf("--- slowest")));
            }
            Ok("env: cpu line sampled", RadarCore.EnvSnapshot().Text.Contains("cpu       : ") && RadarCore.EnvSnapshot().Text.Contains("ms sample)"), RadarCore.EnvSnapshot().Text);
            RadarCore.Configure(root, 50, false, false);
            Ok("mark run ok: stage log off -> skipped, no throw", RadarCore.MarkRunOk().StartsWith("skipped"));
            RadarCore.Clear();
        }

        // windows at failure: own test windows (not Notepad: Windows 11 opens a second Notepad as a tab of the first,
        // and two "Untitled - Notepad" windows share a title). A is on screen at Configure; B appears after, owned by
        // A with A disabled (a modal dialog), topmost, an IBAN in its title.
        {
            RadarCore.Clear();
            bool w = Environment.OSVersion.Platform == PlatformID.Win32NT;
            IntPtr a = IntPtr.Zero, bwin = IntPtr.Zero;
            string aTitle = "Radar Test Before " + Guid.NewGuid().ToString("N").Substring(0, 6), bTitle = "Radar Test After RO49AAAA1B31007593840000";
            try
            {
                if (w) a = CreateWindowEx(0, "STATIC", aTitle, WS_VISIBLE | WS_CAPTION, 50, 50, 300, 120, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
                RadarCore.Configure(root, 50);
                if (w)
                {
                    bwin = CreateWindowEx(WS_EX_TOPMOST, "STATIC", bTitle, WS_VISIBLE | WS_CAPTION, 80, 80, 300, 120, a, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
                    EnableWindow(a, false);
                }
                var fw = RadarCore.Dump("PRC000 - Radar - Windows", "Main", "System Exception", "windows test " + Guid.NewGuid().ToString("N"), "Wait", "", false);
                var tw = File.ReadAllText(Path.Combine(fw, "incident.txt")).Replace("\r\n", "\n");
                int i0 = tw.IndexOf("\n--- windows at failure"), i1 = i0 < 0 ? -1 : tw.IndexOf("\n--- ", i0 + 5);
                string sec = i0 < 0 ? "" : (i1 < 0 ? tw.Substring(i0) : tw.Substring(i0, i1 - i0));
                Ok("windows: section in incident.txt with a screen line", sec.Contains("\nscreen: locked") || sec.Contains("\nscreen: unlocked") || sec.Contains("\nscreen: unknown"), sec);
                var oj = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(Path.Combine(fw, "incident.json"))) as Dictionary<string, object>;
                var wj = oj != null && oj.ContainsKey("windows") ? oj["windows"] as object[] : null;
                Ok("windows: json carries screen + windows array", oj != null && oj.ContainsKey("screen") && wj != null, oj == null ? "no json" : string.Join(",", new List<string>(oj.Keys).ToArray()));
                if (!w)
                {
                    Ok("windows: off Windows the section says so", sec.Contains("screen: unknown (not Windows)") && sec.Contains("(not Windows)") && sec.Contains("baseline: none") && wj != null && wj.Length == 0, sec);
                }
                else
                {
                    string la = null, lb = null; int focus = 0;
                    foreach (var line in sec.Split('\n')) { if (line.Contains(aTitle)) la = line; if (line.Contains("Radar Test After")) lb = line; if (line.EndsWith(" FOCUS") || line.Contains("| FOCUS")) focus++; }
                    Ok("windows: the window from before Configure is listed, not NEW", la != null && !la.Contains("NEW"), la ?? sec);
                    Ok("windows: the window opened after is NEW, MODAL, TOPMOST with its owner", lb != null && lb.Contains("NEW") && lb.Contains("MODAL") && lb.Contains("TOPMOST") && lb.Contains("| \"" + aTitle + "\" |"), lb ?? sec);
                    Ok("windows: title masked", lb != null && lb.Contains("RO49****") && !tw.Contains("RO49AAAA"), lb ?? sec);
                    string fg = RadarCore.ForegroundTitleForTest();
                    Ok("windows: one line marked FOCUS (none only when the foreground window has no title)", focus == 1 || (focus == 0 && fg.Length == 0), "focus lines " + focus + ", foreground \"" + fg + "\"");
                    Ok("windows: baseline counted", sec.Contains("baseline: ") && !sec.Contains("baseline: none"), sec);
                }
            }
            catch (Exception e) { Ok("windows: no exception", false, e.ToString()); }
            finally
            {
                if (bwin != IntPtr.Zero) try { DestroyWindow(bwin); } catch (Exception) { }
                if (a != IntPtr.Zero) try { DestroyWindow(a); } catch (Exception) { }
            }
        }
        try { Directory.Delete(root, true); } catch (Exception) { }
        Console.WriteLine(fails == 0 ? "SELF-TEST PASS" : "SELF-TEST FAIL (" + fails + ")");
        return fails == 0 ? 0 : 1;
    }
}

// stand-ins for the Blue Prism call chain between the UI and a code stage: Main -> RunAction -> DoDoAction -> ActionStage.Execute (per nesting) -> CodeStage.Execute -> Run_<Stage>
namespace BluePrism.AutomateProcessCore
{
    public class clsProcess
    {
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        public string RunAction(int depth) { return DoDoAction(depth); }
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        public string DoDoAction(int depth) { return new Stages.ActionStage().Execute(depth); }
    }
    namespace Stages
    {
        public class ActionStage
        {
            [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
            public string Execute(int depth) { return depth > 1 ? new clsProcess().RunAction(depth - 1) : new CodeStage().Execute(); }
        }
        public class CodeStage
        {
            [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
            public string Execute() { return new RadarSelfTest.Demo_API().Run_Frames(); }
        }
    }
}
