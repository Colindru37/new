# Radar on the Blue Prism machine (scope from 2026-11-10: Radar + Two Stage Demo only)

Nothing here produces or starts a binary. C# runs in-process through PowerShell Add-Type or inside Blue Prism.

In this zip
- `bp\BPA Object - Radar.xml`: the recorder.
- `bp\BPA Process - PRC000 - Radar - Two Stage Demo.xml`: the test process (Configure on Main, Dump in the Recover block).
- `bp\BPA Object - Demo API.xml`: only because Two Stage Demo calls it (the failing API stage). Already imported? Skip it.
House Logging, the Demo Bank objects, Probe / Discover and bpwatch are put away (kept on the dev side, not shipped).
`Mark Run OK` is in the Radar object but nothing calls it: the baseline section says "no baseline yet". That is expected.

Steps
1. `python selftest.py` -> MANIFEST OK.
2. `powershell -ExecutionPolicy Bypass -File core\RadarSelfTest.ps1` -> SELF-TEST PASS.
3. Import `BPA Object - Radar.xml` (overwrite), then Two Stage Demo (and Demo API if missing).
4. Environment variables: `Radar Root Folder` (text), `Demo API Response` (any HTML = failure, `{"id":"C1","name":"Ana Pop"}` = clean).
5. Run Two Stage Demo from Control Room with HTML in `Demo API Response` -> one folder under `<root>\<machine>\`.
6. In incident.txt check:
   - `stages : N in log` never above the Capacity the process passes to Configure (50 in Two Stage Demo);
   - `--- slowest stages ---` and `--- work-queue item ---` present (the item section says none seen: Two Stage Demo has no queue);
   - `--- compared with good runs ---` says no baseline yet;
   - env section has a `cpu       :` line; a Wait stage in the stage log shows `(timeout N s)` (Two Stage Demo has none: check it on a real process).
7. Blank exception check: in Two Stage Demo's Dump Radar Incident stage, clear Exception Type / Detail / Stage, run again.
   Expect the header filled with `(not passed in: taken from the last exception Radar's hook saw ...)`.
   Demo API dumps first (it passes its own exception), then the process dumps blank. Expect ONE folder. If you get TWO,
   photograph the second header: it shows what Blue Prism threw on the rethrow, and the dedupe gets taught that shape.
