"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "7bfdc32a5c16fd73e3587a345ddaa6aa38410591dcf5ca36db54b45156c37a95",
 "README.md": "27c84ac208fcda18c2563eb37f60e6fe9f617d6defc73237340f33bc24607b6a",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Radar.xml": "18439c267abf07bc19167641dfbfe4b39eb5b941c78d2057e0005c73ee180e18",
 "bp/BPA Process - PRC000 - Radar - Two Stage Demo.xml": "5117028ee5f2c4a5488d52dc7d7cd94ea7d6f00a5f03cd759c2bc4c1ea672456",
 "bp/gen_radar.py": "141b40cad717f87faf67e6f6d8b1b25c5886b23dbd5583b74213225c24228212",
 "core/Radar.cs": "40f8889c33bba06c4010033e5a636586b1ead5c763a826a1d50e0c45de8aadb9",
 "core/RadarSelfTest.cs": "0b744f1dfda57a30fc1ed25139f6fb2d1717dd677629ced74841f44ae8d35cc9",
 "core/RadarSelfTest.ps1": "2a7af51a2e6b798ab6cc67a4fd34ab8d7b9e9ba5d2e150a67bea2ebbee442ffe",
 "docs/copilot_windows_handoff.md": "985946e9354c42d1d08b4d9678fe27e77157a013be0ca8e0e06054728fd16d56"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
