"""Radar release selftest: every shipped file hashes as at the source (CRLF-insensitive)."""
import hashlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = {
 "IMPORT.md": "fe1bafe8e9cf8fc88fd1a9365a292420d50d7405808dc3a0395abcfa2fa3c41f",
 "README.md": "3cb6348c17e32ff658b31638cb80b16975f13023adda2ae772eb5f5913e35edd",
 "bp/BPA Object - Demo API.xml": "7a9532a0a421e3d0977f77cf35dbc8fa71df0d111b1a75d704a8e310692cbe86",
 "bp/BPA Object - Demo Bank Plain.xml": "354e1fd86502e65808b3b6be3bc05bc372c9373525f3ba83691b93ac5880a49a",
 "bp/BPA Object - House Logging.xml": "30b15194260cb30e60462aba0639e809bbd8f592f002242e1f51a3e3114eda39",
 "bp/BPA Object - Radar Demo Bank.xml": "e8ddbe599b2ca5373f3bfcfd661566b9d125d41868087790271fe3fbbe248629",
 "bp/BPA Object - Radar.xml": "0dda956bcd392293a75c71d84a3d41f071251d3d6ee23bc44bd804454fba419b",
 "bp/BPA Process - PRC000 - Radar - API Failure Demo.xml": "f7c140e3e53388a8d44fb1d6bfe7e40a2c9a3703f80abc4702f8c9711dabeac7",
 "bp/BPA Process - PRC000 - Radar - House Logging Demo.xml": "4ecf9ede3530ebaac689a8069af49682388fde61cf25ab6aacd7332fe0884f4e",
 "bp/BPA Process - PRC000 - Radar - Write Failure Demo.xml": "746eab6f06a70a6e453aed18f3f98c2de58fcb238cc9a4c092187ad9f6385c97",
 "core/Radar.cs": "989c184ac82c0f381ed0721d08a6f654d187861cf3677dc8766cdb13f6ceaff4",
 "core/RadarSelfTest.cs": "19a4100b6e9a7314ebf4b42b3fe032300507339948f544b9fa361fc8a77f38b6",
 "core/RadarSelfTest.ps1": "2a7af51a2e6b798ab6cc67a4fd34ab8d7b9e9ba5d2e150a67bea2ebbee442ffe",
 "tools/bpwatch.ps1": "601b4043ab5eddcbe3bd519f469d4cfb6c8ea16476ed6900fe8ba38a46fc386f"
}
bad = []
for rel, h in MANIFEST.items():
    p = os.path.join(HERE, *rel.split("/"))
    if not os.path.exists(p): bad.append("MISSING " + rel); continue
    if hashlib.sha256(open(p, "rb").read().replace(b"\r\n", b"\n")).hexdigest() != h: bad.append("CHANGED " + rel)
print("MANIFEST OK (%d files)" % len(MANIFEST) if not bad else "MANIFEST FAIL: " + ", ".join(bad))
sys.exit(1 if bad else 0)
