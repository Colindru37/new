// Radar: in-memory flight recorder for Blue Prism objects. BCL-only, C# 5 (Blue Prism code stage / mono mcs).
// Nothing leaves memory on the happy path. Dump() writes one incident folder and never throws.
// This file is the single source: gen_radar.py embeds it as the Radar VBO's shared code (Code Options).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public static class RadarCore
{
    public class Entry
    {
        public long Seq;
        public DateTime At;
        public string Label;
        public string Detail;
    }

    // One ring per session. A Blue Prism resource runs each session on its own thread, so the
    // ring is keyed by the calling thread: two sessions on one resource never mix trails.
    // (To verify on the first BP run: that every action call of one session arrives on the same thread.)
    class Ring
    {
        public readonly List<Entry> Entries = new List<Entry>();
        public long Seq = 0;
        public long Dropped = 0;
        public string LastDumpKey;      // exception detail+stage of the last dump of this session
        public string LastDumpFolder;
        public DateTime LastDumpAt;
    }
    const int DedupeSeconds = 120;

    static readonly object Gate = new object();
    static readonly Dictionary<int, Ring> Rings = new Dictionary<int, Ring>();
    static int _capacity = 50;
    static string _root = null;

    static Ring Mine()
    {
        int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
        Ring r;
        if (!Rings.TryGetValue(id, out r)) { r = new Ring(); Rings[id] = r; }
        return r;
    }

    static void Trim(Ring r)
    {
        while (r.Entries.Count > _capacity) { r.Entries.RemoveAt(0); r.Dropped++; }
    }

    public static int Capacity { get { lock (Gate) return _capacity; } }
    public static string Root { get { lock (Gate) return _root ?? Path.Combine(Path.GetTempPath(), "Radar"); } }
    public static int SessionCount { get { lock (Gate) return Rings.Count; } }

    /// Set the incident root folder (a UNC share in production) and the ring capacity. Empty/zero keep the defaults.
    public static void Configure(string rootFolder, int capacity)
    {
        lock (Gate)
        {
            if (!string.IsNullOrEmpty(rootFolder)) _root = rootFolder;
            if (capacity > 0) _capacity = capacity;
            foreach (var r in Rings.Values) Trim(r);
        }
    }

    /// Append one entry to this session's ring; the oldest falls off past Capacity. Cheap: no I/O.
    public static void Record(string label, string detail)
    {
        lock (Gate)
        {
            var r = Mine();
            r.Seq++;
            r.Entries.Add(new Entry { Seq = r.Seq, At = DateTime.Now, Label = label ?? "", Detail = detail ?? "" });
            Trim(r);
        }
    }

    public static int Count { get { lock (Gate) return Mine().Entries.Count; } }
    public static long Dropped { get { lock (Gate) return Mine().Dropped; } }

    /// This session's trail as text, oldest first, one line per entry.
    public static string Trail()
    {
        lock (Gate)
        {
            var sb = new StringBuilder();
            foreach (var e in Mine().Entries)
                sb.Append(Line(e)).Append('\n');
            return sb.ToString();
        }
    }

    /// Forget this session's ring (called after a dump; also the right call at Clean Up).
    public static void Clear()
    {
        lock (Gate) { Rings.Remove(System.Threading.Thread.CurrentThread.ManagedThreadId); }
    }

    static string Line(Entry e)
    {
        return e.At.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture) + " | #" + e.Seq + " | " + e.Label + " | " + e.Detail.Replace("\r", "").Replace("\n", " \\n ");
    }

    /// Write one incident folder: incident.txt + incident.json (+ screenshot.png on Windows), then clear this session's ring.
    /// Returns the folder path, or "ERROR: ..." when even the folder could not be written. Never throws.
    public static string Dump(string process, string page, string exType, string exDetail, string exStage, string dataItems, bool captureScreen)
    {
        try
        {
            var now = DateTime.Now;
            List<Entry> snapshot; long dropped; int cap;
            string key = (exDetail ?? "") + "\u0001" + (exStage ?? "");
            lock (Gate)
            {
                var r = Mine();
                // The same exception reaches Dump twice when an instrumented object dumps and then the
                // process's logger dumps on the rethrow: one incident folder, not two.
                if (r.LastDumpKey == key && (now - r.LastDumpAt).TotalSeconds < DedupeSeconds && r.LastDumpFolder != null)
                    return r.LastDumpFolder;
                snapshot = new List<Entry>(r.Entries); dropped = r.Dropped; cap = _capacity;
            }
            // <root>\<resource machine>\<time>_<process>_<stage>: the Control Room row (time, resource, stage) finds it
            var folder = Path.Combine(Path.Combine(Root, Safe(Environment.MachineName)),
                                      now.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture) + "_" + Safe(process) + "_" + Safe(exStage));
            for (int n = 2; Directory.Exists(folder); n++)          // two incidents in the same millisecond never share a folder
                folder = folder.TrimEnd('0','1','2','3','4','5','6','7','8','9','~') + "~" + n;
            Directory.CreateDirectory(folder);

            string shotNote;
            string shotFile = null;
            if (captureScreen)
            {
                shotFile = Path.Combine(folder, "screenshot.png");
                shotNote = Screenshot(shotFile);
                if (shotNote != "ok") shotFile = null;
            }
            else shotNote = "not requested";

            var txt = new StringBuilder();
            txt.Append("RADAR INCIDENT ").Append(now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture)).Append('\n');
            txt.Append("process   : ").Append(process).Append('\n');
            txt.Append("page      : ").Append(page).Append('\n');
            txt.Append("machine   : ").Append(Environment.MachineName).Append(" / ").Append(Environment.UserName).Append('\n');
            txt.Append("exception : ").Append(exType).Append('\n');
            txt.Append("stage     : ").Append(exStage).Append('\n');
            txt.Append("detail    : ").Append(exDetail).Append('\n');
            txt.Append("screenshot: ").Append(shotFile != null ? "screenshot.png" : "skipped (" + shotNote + ")").Append('\n');
            txt.Append("\n--- data items at failure ---\n").Append(dataItems ?? "").Append(dataItems != null && dataItems.EndsWith("\n") ? "" : "\n");
            txt.Append("\n--- trail (oldest first; ").Append(snapshot.Count).Append(" kept, ").Append(dropped).Append(" dropped, capacity ").Append(cap).Append(") ---\n");
            foreach (var e in snapshot) txt.Append(Line(e)).Append('\n');
            File.WriteAllText(Path.Combine(folder, "incident.txt"), txt.ToString(), new UTF8Encoding(false));

            var js = new StringBuilder();
            js.Append("{\n");
            js.Append("  \"at\": ").Append(J(now.ToString("o"))).Append(",\n");
            js.Append("  \"process\": ").Append(J(process)).Append(",\n");
            js.Append("  \"page\": ").Append(J(page)).Append(",\n");
            js.Append("  \"machine\": ").Append(J(Environment.MachineName)).Append(",\n");
            js.Append("  \"user\": ").Append(J(Environment.UserName)).Append(",\n");
            js.Append("  \"exception\": { \"type\": ").Append(J(exType)).Append(", \"stage\": ").Append(J(exStage)).Append(", \"detail\": ").Append(J(exDetail)).Append(" },\n");
            js.Append("  \"screenshot\": ").Append(shotFile != null ? J("screenshot.png") : "null").Append(",\n");
            js.Append("  \"screenshot_note\": ").Append(J(shotNote)).Append(",\n");
            js.Append("  \"data_items\": ").Append(DataItemsJson(dataItems)).Append(",\n");
            js.Append("  \"dropped\": ").Append(dropped).Append(",\n");
            js.Append("  \"trail\": [\n");
            for (int i = 0; i < snapshot.Count; i++)
            {
                var e = snapshot[i];
                js.Append("    { \"seq\": ").Append(e.Seq).Append(", \"at\": ").Append(J(e.At.ToString("o")))
                  .Append(", \"label\": ").Append(J(e.Label)).Append(", \"detail\": ").Append(J(e.Detail)).Append(" }")
                  .Append(i + 1 < snapshot.Count ? ",\n" : "\n");
            }
            js.Append("  ]\n}\n");
            File.WriteAllText(Path.Combine(folder, "incident.json"), js.ToString(), new UTF8Encoding(false));

            lock (Gate)
            {
                Rings.Remove(System.Threading.Thread.CurrentThread.ManagedThreadId);
                var fresh = Mine();
                fresh.LastDumpKey = key; fresh.LastDumpFolder = folder; fresh.LastDumpAt = now;
            }
            return folder;
        }
        catch (Exception ex)
        {
            return "ERROR: " + ex.GetType().Name + ": " + ex.Message;
        }
    }

    /// "name=value" lines -> JSON object. A line without '=' becomes a key with null.
    static string DataItemsJson(string dataItems)
    {
        var sb = new StringBuilder("{");
        bool first = true;
        foreach (var raw in (dataItems ?? "").Replace("\r", "").Split('\n'))
        {
            var line = raw.Trim();
            if (line.Length == 0) continue;
            int eq = line.IndexOf('=');
            string k = eq < 0 ? line : line.Substring(0, eq).Trim();
            string v = eq < 0 ? null : line.Substring(eq + 1);
            sb.Append(first ? " " : ", ").Append(J(k)).Append(": ").Append(v == null ? "null" : J(v));
            first = false;
        }
        return sb.Append(first ? "}" : " }").ToString();
    }

    static string J(string s)
    {
        if (s == null) return "null";
        var sb = new StringBuilder("\"");
        foreach (var c in s)
        {
            switch (c)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < ' ') sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.Append('"').ToString();
    }

    static string Safe(string s)
    {
        if (string.IsNullOrEmpty(s)) return "x";
        var sb = new StringBuilder();
        foreach (var c in s)
            sb.Append(char.IsLetterOrDigit(c) ? c : '_');
        var r = sb.ToString().Trim('_');
        return r.Length > 40 ? r.Substring(0, 40) : (r.Length == 0 ? "x" : r);
    }

    // ---- screenshot: whole virtual desktop via GDI+, Windows only; any failure is reported, never thrown ----
    [DllImport("user32.dll")] static extern int GetSystemMetrics(int n);
    const int SM_XVIRTUALSCREEN = 76, SM_YVIRTUALSCREEN = 77, SM_CXVIRTUALSCREEN = 78, SM_CYVIRTUALSCREEN = 79;

    static string Screenshot(string file)
    {
        if (Environment.OSVersion.Platform != PlatformID.Win32NT) return "not Windows (" + Environment.OSVersion.Platform + ")";
        try
        {
            int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
            int w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
            if (w <= 0 || h <= 0) return "no screen (" + w + "x" + h + ")";
            using (var bmp = new System.Drawing.Bitmap(w, h))
            {
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                    g.CopyFromScreen(x, y, 0, 0, new System.Drawing.Size(w, h));
                bmp.Save(file, System.Drawing.Imaging.ImageFormat.Png);
            }
            return "ok";
        }
        catch (Exception ex)
        {
            return ex.GetType().Name + ": " + ex.Message;
        }
    }
}
